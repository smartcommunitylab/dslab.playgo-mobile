"use strict";
(self["webpackChunkapp"] = self["webpackChunkapp"] || []).push([["src_app_pages_trips_trip-detail_trip-detail_module_ts"],{

/***/ 9835:
/*!******************************************************************************!*\
  !*** ./node_modules/@bluehalo/ngx-leaflet/fesm2022/bluehalo-ngx-leaflet.mjs ***!
  \******************************************************************************/
/***/ ((__unused_webpack___webpack_module__, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   LeafletBaseLayersDirective: () => (/* binding */ LeafletBaseLayersDirective),
/* harmony export */   LeafletControlLayersChanges: () => (/* binding */ LeafletControlLayersChanges),
/* harmony export */   LeafletControlLayersConfig: () => (/* binding */ LeafletControlLayersConfig),
/* harmony export */   LeafletControlLayersWrapper: () => (/* binding */ LeafletControlLayersWrapper),
/* harmony export */   LeafletDirective: () => (/* binding */ LeafletDirective),
/* harmony export */   LeafletDirectiveWrapper: () => (/* binding */ LeafletDirectiveWrapper),
/* harmony export */   LeafletLayerDirective: () => (/* binding */ LeafletLayerDirective),
/* harmony export */   LeafletLayersControlDirective: () => (/* binding */ LeafletLayersControlDirective),
/* harmony export */   LeafletLayersDirective: () => (/* binding */ LeafletLayersDirective),
/* harmony export */   LeafletModule: () => (/* binding */ LeafletModule),
/* harmony export */   LeafletTileLayerDefinition: () => (/* binding */ LeafletTileLayerDefinition),
/* harmony export */   LeafletUtil: () => (/* binding */ LeafletUtil)
/* harmony export */ });
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! @angular/core */ 34205);
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @angular/core */ 12481);
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @angular/core */ 37580);
/* harmony import */ var leaflet__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! leaflet */ 67381);
var _staticBlock, _staticBlock2, _staticBlock3, _staticBlock4, _staticBlock5, _staticBlock6;



class LeafletUtil {
  static mapToArray(map) {
    const toReturn = [];
    for (const k in map) {
      if (map.hasOwnProperty(k)) {
        toReturn.push(map[k]);
      }
    }
    return toReturn;
  }
  static handleEvent(zone, eventEmitter, event) {
    // Don't want to emit if there are no observers
    if (0 < eventEmitter.observers.length) {
      zone.run(() => {
        eventEmitter.emit(event);
      });
    }
  }
}
class LeafletDirective {
  constructor(element, zone) {
    this.element = element;
    this.zone = zone;
    this.DEFAULT_ZOOM = 1;
    this.DEFAULT_CENTER = (0,leaflet__WEBPACK_IMPORTED_MODULE_3__.latLng)(38.907192, -77.036871);
    this.DEFAULT_FPZ_OPTIONS = {};
    this.fitBoundsOptions = this.DEFAULT_FPZ_OPTIONS;
    this.panOptions = this.DEFAULT_FPZ_OPTIONS;
    this.zoomOptions = this.DEFAULT_FPZ_OPTIONS;
    this.zoomPanOptions = this.DEFAULT_FPZ_OPTIONS;
    // Default configuration
    this.options = {};
    // Configure callback function for the map
    this.mapReady = new _angular_core__WEBPACK_IMPORTED_MODULE_1__.EventEmitter();
    this.zoomChange = new _angular_core__WEBPACK_IMPORTED_MODULE_1__.EventEmitter();
    this.centerChange = new _angular_core__WEBPACK_IMPORTED_MODULE_1__.EventEmitter();
    // Mouse Map Events
    this.onClick = new _angular_core__WEBPACK_IMPORTED_MODULE_1__.EventEmitter();
    this.onDoubleClick = new _angular_core__WEBPACK_IMPORTED_MODULE_1__.EventEmitter();
    this.onMouseDown = new _angular_core__WEBPACK_IMPORTED_MODULE_1__.EventEmitter();
    this.onMouseUp = new _angular_core__WEBPACK_IMPORTED_MODULE_1__.EventEmitter();
    this.onMouseMove = new _angular_core__WEBPACK_IMPORTED_MODULE_1__.EventEmitter();
    this.onMouseOver = new _angular_core__WEBPACK_IMPORTED_MODULE_1__.EventEmitter();
    this.onMouseOut = new _angular_core__WEBPACK_IMPORTED_MODULE_1__.EventEmitter();
    // Map Move Events
    this.onMapMove = new _angular_core__WEBPACK_IMPORTED_MODULE_1__.EventEmitter();
    this.onMapMoveStart = new _angular_core__WEBPACK_IMPORTED_MODULE_1__.EventEmitter();
    this.onMapMoveEnd = new _angular_core__WEBPACK_IMPORTED_MODULE_1__.EventEmitter();
    // Map Zoom Events
    this.onMapZoom = new _angular_core__WEBPACK_IMPORTED_MODULE_1__.EventEmitter();
    this.onMapZoomStart = new _angular_core__WEBPACK_IMPORTED_MODULE_1__.EventEmitter();
    this.onMapZoomEnd = new _angular_core__WEBPACK_IMPORTED_MODULE_1__.EventEmitter();
    // Nothing here
  }
  ngOnInit() {
    // Create the map outside of angular so the various map events don't trigger change detection
    this.zone.runOutsideAngular(() => {
      // Create the map with some reasonable defaults
      this.map = (0,leaflet__WEBPACK_IMPORTED_MODULE_3__.map)(this.element.nativeElement, this.options);
      this.addMapEventListeners();
    });
    // Only setView if there is a center/zoom
    if (null != this.center && null != this.zoom) {
      this.setView(this.center, this.zoom);
    }
    // Set up all the initial settings
    if (null != this.fitBounds) {
      this.setFitBounds(this.fitBounds);
    }
    if (null != this.maxBounds) {
      this.setMaxBounds(this.maxBounds);
    }
    if (null != this.minZoom) {
      this.setMinZoom(this.minZoom);
    }
    if (null != this.maxZoom) {
      this.setMaxZoom(this.maxZoom);
    }
    this.doResize();
    // Fire map ready event
    this.mapReady.emit(this.map);
  }
  ngOnChanges(changes) {
    /*
     * The following code is to address an issue with our (basic) implementation of
     * zooming and panning. From our testing, it seems that a pan operation followed
     * by a zoom operation in the same thread will interfere with eachother. The zoom
     * operation interrupts/cancels the pan, resulting in a final center point that is
     * inaccurate. The solution seems to be to either separate them with a timeout or
      * to collapse them into a setView call.
     */
    // Zooming and Panning
    if (changes['zoom'] && changes['center'] && null != this.zoom && null != this.center) {
      this.setView(changes['center'].currentValue, changes['zoom'].currentValue);
    }
    // Set the zoom level
    else if (changes['zoom']) {
      this.setZoom(changes['zoom'].currentValue);
    }
    // Set the map center
    else if (changes['center']) {
      this.setCenter(changes['center'].currentValue);
    }
    // Other options
    if (changes['fitBounds']) {
      this.setFitBounds(changes['fitBounds'].currentValue);
    }
    if (changes['maxBounds']) {
      this.setMaxBounds(changes['maxBounds'].currentValue);
    }
    if (changes['minZoom']) {
      this.setMinZoom(changes['minZoom'].currentValue);
    }
    if (changes['maxZoom']) {
      this.setMaxZoom(changes['maxZoom'].currentValue);
    }
  }
  ngOnDestroy() {
    // If this directive is destroyed, the map is too
    if (null != this.map) {
      this.map.remove();
    }
  }
  getMap() {
    return this.map;
  }
  onResize() {
    this.delayResize();
  }
  addMapEventListeners() {
    const registerEventHandler = (eventName, handler) => {
      this.map.on(eventName, handler);
    };
    // Add all the pass-through mouse event handlers
    registerEventHandler('click', e => LeafletUtil.handleEvent(this.zone, this.onClick, e));
    registerEventHandler('dblclick', e => LeafletUtil.handleEvent(this.zone, this.onDoubleClick, e));
    registerEventHandler('mousedown', e => LeafletUtil.handleEvent(this.zone, this.onMouseDown, e));
    registerEventHandler('mouseup', e => LeafletUtil.handleEvent(this.zone, this.onMouseUp, e));
    registerEventHandler('mouseover', e => LeafletUtil.handleEvent(this.zone, this.onMouseOver, e));
    registerEventHandler('mouseout', e => LeafletUtil.handleEvent(this.zone, this.onMouseOut, e));
    registerEventHandler('mousemove', e => LeafletUtil.handleEvent(this.zone, this.onMouseMove, e));
    registerEventHandler('zoomstart', e => LeafletUtil.handleEvent(this.zone, this.onMapZoomStart, e));
    registerEventHandler('zoom', e => LeafletUtil.handleEvent(this.zone, this.onMapZoom, e));
    registerEventHandler('zoomend', e => LeafletUtil.handleEvent(this.zone, this.onMapZoomEnd, e));
    registerEventHandler('movestart', e => LeafletUtil.handleEvent(this.zone, this.onMapMoveStart, e));
    registerEventHandler('move', e => LeafletUtil.handleEvent(this.zone, this.onMapMove, e));
    registerEventHandler('moveend', e => LeafletUtil.handleEvent(this.zone, this.onMapMoveEnd, e));
    // Update any things for which we provide output bindings
    const outputUpdateHandler = () => {
      const zoom = this.map.getZoom();
      if (zoom !== this.zoom) {
        this.zoom = zoom;
        LeafletUtil.handleEvent(this.zone, this.zoomChange, zoom);
      }
      const center = this.map.getCenter();
      if (null != center || null != this.center) {
        if ((null == center || null == this.center) && center !== this.center || center.lat !== this.center.lat || center.lng !== this.center.lng) {
          this.center = center;
          LeafletUtil.handleEvent(this.zone, this.centerChange, center);
        }
      }
    };
    registerEventHandler('moveend', outputUpdateHandler);
    registerEventHandler('zoomend', outputUpdateHandler);
  }
  /**
   * Resize the map to fit it's parent container
   */
  doResize() {
    // Run this outside of angular so the map events stay outside of angular
    this.zone.runOutsideAngular(() => {
      // Invalidate the map size to trigger it to update itself
      if (null != this.map) {
        this.map.invalidateSize({});
      }
    });
  }
  /**
   * Manage a delayed resize of the component
   */
  delayResize() {
    if (null != this.resizeTimer) {
      clearTimeout(this.resizeTimer);
    }
    this.resizeTimer = setTimeout(this.doResize.bind(this), 200);
  }
  /**
   * Set the view (center/zoom) all at once
   * @param center The new center
   * @param zoom The new zoom level
   */
  setView(center, zoom) {
    if (null != this.map && null != center && null != zoom) {
      this.map.setView(center, zoom, this.zoomPanOptions);
    }
  }
  /**
   * Set the map zoom level
   * @param zoom the new zoom level for the map
   */
  setZoom(zoom) {
    if (null != this.map && null != zoom) {
      this.map.setZoom(zoom, this.zoomOptions);
    }
  }
  /**
   * Set the center of the map
   * @param center the center point
   */
  setCenter(center) {
    if (null != this.map && null != center) {
      this.map.panTo(center, this.panOptions);
    }
  }
  /**
   * Fit the map to the bounds
   * @param latLngBounds the boundary to set
   */
  setFitBounds(latLngBounds) {
    if (null != this.map && null != latLngBounds) {
      this.map.fitBounds(latLngBounds, this.fitBoundsOptions);
    }
  }
  /**
   * Set the map's max bounds
   * @param latLngBounds the boundary to set
   */
  setMaxBounds(latLngBounds) {
    if (null != this.map && null != latLngBounds) {
      this.map.setMaxBounds(latLngBounds);
    }
  }
  /**
   * Set the map's min zoom
   * @param number the new min zoom
   */
  setMinZoom(zoom) {
    if (null != this.map && null != zoom) {
      this.map.setMinZoom(zoom);
    }
  }
  /**
   * Set the map's min zoom
   * @param number the new min zoom
   */
  setMaxZoom(zoom) {
    if (null != this.map && null != zoom) {
      this.map.setMaxZoom(zoom);
    }
  }
  static #_ = _staticBlock = () => (this.ɵfac = function LeafletDirective_Factory(__ngFactoryType__) {
    return new (__ngFactoryType__ || LeafletDirective)(_angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵdirectiveInject"](_angular_core__WEBPACK_IMPORTED_MODULE_1__.ElementRef), _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵdirectiveInject"](_angular_core__WEBPACK_IMPORTED_MODULE_1__.NgZone));
  }, this.ɵdir = /* @__PURE__ */_angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵdefineDirective"]({
    type: LeafletDirective,
    selectors: [["", "leaflet", ""]],
    hostBindings: function LeafletDirective_HostBindings(rf, ctx) {
      if (rf & 1) {
        _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵlistener"]("resize", function LeafletDirective_resize_HostBindingHandler() {
          return ctx.onResize();
        }, _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵresolveWindow"]);
      }
    },
    inputs: {
      fitBoundsOptions: [0, "leafletFitBoundsOptions", "fitBoundsOptions"],
      panOptions: [0, "leafletPanOptions", "panOptions"],
      zoomOptions: [0, "leafletZoomOptions", "zoomOptions"],
      zoomPanOptions: [0, "leafletZoomPanOptions", "zoomPanOptions"],
      options: [0, "leafletOptions", "options"],
      zoom: [0, "leafletZoom", "zoom"],
      center: [0, "leafletCenter", "center"],
      fitBounds: [0, "leafletFitBounds", "fitBounds"],
      maxBounds: [0, "leafletMaxBounds", "maxBounds"],
      minZoom: [0, "leafletMinZoom", "minZoom"],
      maxZoom: [0, "leafletMaxZoom", "maxZoom"]
    },
    outputs: {
      mapReady: "leafletMapReady",
      zoomChange: "leafletZoomChange",
      centerChange: "leafletCenterChange",
      onClick: "leafletClick",
      onDoubleClick: "leafletDoubleClick",
      onMouseDown: "leafletMouseDown",
      onMouseUp: "leafletMouseUp",
      onMouseMove: "leafletMouseMove",
      onMouseOver: "leafletMouseOver",
      onMouseOut: "leafletMouseOut",
      onMapMove: "leafletMapMove",
      onMapMoveStart: "leafletMapMoveStart",
      onMapMoveEnd: "leafletMapMoveEnd",
      onMapZoom: "leafletMapZoom",
      onMapZoomStart: "leafletMapZoomStart",
      onMapZoomEnd: "leafletMapZoomEnd"
    },
    features: [_angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵNgOnChangesFeature"]]
  }));
}
_staticBlock();
(() => {
  (typeof ngDevMode === "undefined" || ngDevMode) && _angular_core__WEBPACK_IMPORTED_MODULE_1__.setClassMetadata(LeafletDirective, [{
    type: _angular_core__WEBPACK_IMPORTED_MODULE_1__.Directive,
    args: [{
      selector: '[leaflet]'
    }]
  }], () => [{
    type: _angular_core__WEBPACK_IMPORTED_MODULE_1__.ElementRef
  }, {
    type: _angular_core__WEBPACK_IMPORTED_MODULE_1__.NgZone
  }], {
    fitBoundsOptions: [{
      type: _angular_core__WEBPACK_IMPORTED_MODULE_1__.Input,
      args: ['leafletFitBoundsOptions']
    }],
    panOptions: [{
      type: _angular_core__WEBPACK_IMPORTED_MODULE_1__.Input,
      args: ['leafletPanOptions']
    }],
    zoomOptions: [{
      type: _angular_core__WEBPACK_IMPORTED_MODULE_1__.Input,
      args: ['leafletZoomOptions']
    }],
    zoomPanOptions: [{
      type: _angular_core__WEBPACK_IMPORTED_MODULE_1__.Input,
      args: ['leafletZoomPanOptions']
    }],
    options: [{
      type: _angular_core__WEBPACK_IMPORTED_MODULE_1__.Input,
      args: ['leafletOptions']
    }],
    mapReady: [{
      type: _angular_core__WEBPACK_IMPORTED_MODULE_1__.Output,
      args: ['leafletMapReady']
    }],
    zoom: [{
      type: _angular_core__WEBPACK_IMPORTED_MODULE_1__.Input,
      args: ['leafletZoom']
    }],
    zoomChange: [{
      type: _angular_core__WEBPACK_IMPORTED_MODULE_1__.Output,
      args: ['leafletZoomChange']
    }],
    center: [{
      type: _angular_core__WEBPACK_IMPORTED_MODULE_1__.Input,
      args: ['leafletCenter']
    }],
    centerChange: [{
      type: _angular_core__WEBPACK_IMPORTED_MODULE_1__.Output,
      args: ['leafletCenterChange']
    }],
    fitBounds: [{
      type: _angular_core__WEBPACK_IMPORTED_MODULE_1__.Input,
      args: ['leafletFitBounds']
    }],
    maxBounds: [{
      type: _angular_core__WEBPACK_IMPORTED_MODULE_1__.Input,
      args: ['leafletMaxBounds']
    }],
    minZoom: [{
      type: _angular_core__WEBPACK_IMPORTED_MODULE_1__.Input,
      args: ['leafletMinZoom']
    }],
    maxZoom: [{
      type: _angular_core__WEBPACK_IMPORTED_MODULE_1__.Input,
      args: ['leafletMaxZoom']
    }],
    onClick: [{
      type: _angular_core__WEBPACK_IMPORTED_MODULE_1__.Output,
      args: ['leafletClick']
    }],
    onDoubleClick: [{
      type: _angular_core__WEBPACK_IMPORTED_MODULE_1__.Output,
      args: ['leafletDoubleClick']
    }],
    onMouseDown: [{
      type: _angular_core__WEBPACK_IMPORTED_MODULE_1__.Output,
      args: ['leafletMouseDown']
    }],
    onMouseUp: [{
      type: _angular_core__WEBPACK_IMPORTED_MODULE_1__.Output,
      args: ['leafletMouseUp']
    }],
    onMouseMove: [{
      type: _angular_core__WEBPACK_IMPORTED_MODULE_1__.Output,
      args: ['leafletMouseMove']
    }],
    onMouseOver: [{
      type: _angular_core__WEBPACK_IMPORTED_MODULE_1__.Output,
      args: ['leafletMouseOver']
    }],
    onMouseOut: [{
      type: _angular_core__WEBPACK_IMPORTED_MODULE_1__.Output,
      args: ['leafletMouseOut']
    }],
    onMapMove: [{
      type: _angular_core__WEBPACK_IMPORTED_MODULE_1__.Output,
      args: ['leafletMapMove']
    }],
    onMapMoveStart: [{
      type: _angular_core__WEBPACK_IMPORTED_MODULE_1__.Output,
      args: ['leafletMapMoveStart']
    }],
    onMapMoveEnd: [{
      type: _angular_core__WEBPACK_IMPORTED_MODULE_1__.Output,
      args: ['leafletMapMoveEnd']
    }],
    onMapZoom: [{
      type: _angular_core__WEBPACK_IMPORTED_MODULE_1__.Output,
      args: ['leafletMapZoom']
    }],
    onMapZoomStart: [{
      type: _angular_core__WEBPACK_IMPORTED_MODULE_1__.Output,
      args: ['leafletMapZoomStart']
    }],
    onMapZoomEnd: [{
      type: _angular_core__WEBPACK_IMPORTED_MODULE_1__.Output,
      args: ['leafletMapZoomEnd']
    }],
    onResize: [{
      type: _angular_core__WEBPACK_IMPORTED_MODULE_1__.HostListener,
      args: ['window:resize', []]
    }]
  });
})();
class LeafletDirectiveWrapper {
  constructor(leafletDirective) {
    this.leafletDirective = leafletDirective;
  }
  init() {
    // Nothing for now
  }
  getMap() {
    return this.leafletDirective.getMap();
  }
}

/**
 * Layer directive
 *
 * This directive is used to directly control a single map layer. The purpose of this directive is to
 * be used as part of a child structural directive of the map element.
 *
 */
class LeafletLayerDirective {
  constructor(leafletDirective, zone) {
    this.zone = zone;
    // Layer Events
    this.onAdd = new _angular_core__WEBPACK_IMPORTED_MODULE_1__.EventEmitter();
    this.onRemove = new _angular_core__WEBPACK_IMPORTED_MODULE_1__.EventEmitter();
    this.leafletDirective = new LeafletDirectiveWrapper(leafletDirective);
  }
  ngOnInit() {
    // Init the map
    this.leafletDirective.init();
  }
  ngOnDestroy() {
    if (null != this.layer) {
      // Unregister the event handlers
      this.removeLayerEventListeners(this.layer);
      // Remove the layer from the map
      this.layer.remove();
    }
  }
  ngOnChanges(changes) {
    if (changes['layer']) {
      // Update the layer
      const p = changes['layer'].previousValue;
      const n = changes['layer'].currentValue;
      this.zone.runOutsideAngular(() => {
        if (null != p) {
          this.removeLayerEventListeners(p);
          p.remove();
        }
        if (null != n) {
          this.addLayerEventListeners(n);
          this.leafletDirective.getMap().addLayer(n);
        }
      });
    }
  }
  addLayerEventListeners(l) {
    this.onAddLayerHandler = e => LeafletUtil.handleEvent(this.zone, this.onAdd, e);
    l.on('add', this.onAddLayerHandler);
    this.onRemoveLayerHandler = e => LeafletUtil.handleEvent(this.zone, this.onRemove, e);
    l.on('remove', this.onRemoveLayerHandler);
  }
  removeLayerEventListeners(l) {
    l.off('add', this.onAddLayerHandler);
    l.off('remove', this.onRemoveLayerHandler);
  }
  static #_ = _staticBlock2 = () => (this.ɵfac = function LeafletLayerDirective_Factory(__ngFactoryType__) {
    return new (__ngFactoryType__ || LeafletLayerDirective)(_angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵdirectiveInject"](LeafletDirective), _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵdirectiveInject"](_angular_core__WEBPACK_IMPORTED_MODULE_1__.NgZone));
  }, this.ɵdir = /* @__PURE__ */_angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵdefineDirective"]({
    type: LeafletLayerDirective,
    selectors: [["", "leafletLayer", ""]],
    inputs: {
      layer: [0, "leafletLayer", "layer"]
    },
    outputs: {
      onAdd: "leafletLayerAdd",
      onRemove: "leafletLayerRemove"
    },
    features: [_angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵNgOnChangesFeature"]]
  }));
}
_staticBlock2();
(() => {
  (typeof ngDevMode === "undefined" || ngDevMode) && _angular_core__WEBPACK_IMPORTED_MODULE_1__.setClassMetadata(LeafletLayerDirective, [{
    type: _angular_core__WEBPACK_IMPORTED_MODULE_1__.Directive,
    args: [{
      selector: '[leafletLayer]'
    }]
  }], () => [{
    type: LeafletDirective
  }, {
    type: _angular_core__WEBPACK_IMPORTED_MODULE_1__.NgZone
  }], {
    layer: [{
      type: _angular_core__WEBPACK_IMPORTED_MODULE_1__.Input,
      args: ['leafletLayer']
    }],
    onAdd: [{
      type: _angular_core__WEBPACK_IMPORTED_MODULE_1__.Output,
      args: ['leafletLayerAdd']
    }],
    onRemove: [{
      type: _angular_core__WEBPACK_IMPORTED_MODULE_1__.Output,
      args: ['leafletLayerRemove']
    }]
  });
})();

/**
 * Layers directive
 *
 * This directive is used to directly control map layers. As changes are made to the input array of
 * layers, the map is synched to the array. As layers are added or removed from the input array, they
 * are also added or removed from the map. The input array is treated as immutable. To detect changes,
 * you must change the array instance.
 *
 * Important Note: The input layers array is assumed to be immutable. This means you need to use an
 * immutable array implementation or create a new copy of your array when you make changes, otherwise
 * this directive won't detect the change. This is by design. It's for performance reasons. Change
 * detection of mutable arrays requires diffing the state of the array on every DoCheck cycle, which
 * is extremely expensive from a time complexity perspective.
 *
 */
class LeafletLayersDirective {
  // Set/get the layers
  set layers(v) {
    this.layersValue = v;
    // Now that we have a differ, do an immediate layer update
    this.updateLayers();
  }
  get layers() {
    return this.layersValue;
  }
  constructor(leafletDirective, differs, zone) {
    this.differs = differs;
    this.zone = zone;
    this.leafletDirective = new LeafletDirectiveWrapper(leafletDirective);
    this.layersDiffer = this.differs.find([]).create();
  }
  ngDoCheck() {
    this.updateLayers();
  }
  ngOnInit() {
    // Init the map
    this.leafletDirective.init();
    // Update layers once the map is ready
    this.updateLayers();
  }
  ngOnDestroy() {
    this.layers = [];
  }
  /**
   * Update the state of the layers.
   * We use an iterable differ to synchronize the map layers with the state of the bound layers array.
   * This is important because it allows us to react to changes to the contents of the array as well
   * as changes to the actual array instance.
   */
  updateLayers() {
    const map = this.leafletDirective.getMap();
    if (null != map && null != this.layersDiffer) {
      const changes = this.layersDiffer.diff(this.layersValue);
      if (null != changes) {
        // Run outside angular to ensure layer events don't trigger change detection
        this.zone.runOutsideAngular(() => {
          changes.forEachRemovedItem(c => {
            map.removeLayer(c.item);
          });
          changes.forEachAddedItem(c => {
            map.addLayer(c.item);
          });
        });
      }
    }
  }
  static #_ = _staticBlock3 = () => (this.ɵfac = function LeafletLayersDirective_Factory(__ngFactoryType__) {
    return new (__ngFactoryType__ || LeafletLayersDirective)(_angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵdirectiveInject"](LeafletDirective), _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵdirectiveInject"](_angular_core__WEBPACK_IMPORTED_MODULE_2__.IterableDiffers), _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵdirectiveInject"](_angular_core__WEBPACK_IMPORTED_MODULE_1__.NgZone));
  }, this.ɵdir = /* @__PURE__ */_angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵdefineDirective"]({
    type: LeafletLayersDirective,
    selectors: [["", "leafletLayers", ""]],
    inputs: {
      layers: [0, "leafletLayers", "layers"]
    }
  }));
}
_staticBlock3();
(() => {
  (typeof ngDevMode === "undefined" || ngDevMode) && _angular_core__WEBPACK_IMPORTED_MODULE_1__.setClassMetadata(LeafletLayersDirective, [{
    type: _angular_core__WEBPACK_IMPORTED_MODULE_1__.Directive,
    args: [{
      selector: '[leafletLayers]'
    }]
  }], () => [{
    type: LeafletDirective
  }, {
    type: _angular_core__WEBPACK_IMPORTED_MODULE_2__.IterableDiffers
  }, {
    type: _angular_core__WEBPACK_IMPORTED_MODULE_1__.NgZone
  }], {
    layers: [{
      type: _angular_core__WEBPACK_IMPORTED_MODULE_1__.Input,
      args: ['leafletLayers']
    }]
  });
})();
class LeafletControlLayersChanges {
  constructor() {
    this.layersRemoved = 0;
    this.layersChanged = 0;
    this.layersAdded = 0;
  }
  changed() {
    return !(this.layersRemoved === 0 && this.layersChanged === 0 && this.layersAdded === 0);
  }
}
class LeafletControlLayersWrapper {
  constructor(zone, layersControlReady) {
    this.zone = zone;
    this.layersControlReady = layersControlReady;
  }
  getLayersControl() {
    return this.layersControl;
  }
  init(controlConfig, controlOptions) {
    const baseLayers = controlConfig.baseLayers || {};
    const overlays = controlConfig.overlays || {};
    // Create the control outside of angular to ensure events don't trigger change detection
    this.zone.runOutsideAngular(() => {
      this.layersControl = leaflet__WEBPACK_IMPORTED_MODULE_3__.control.layers(baseLayers, overlays, controlOptions);
    });
    this.layersControlReady.emit(this.layersControl);
    return this.layersControl;
  }
  applyBaseLayerChanges(changes) {
    let results = new LeafletControlLayersChanges();
    if (null != this.layersControl) {
      results = this.applyChanges(changes, this.layersControl.addBaseLayer);
    }
    return results;
  }
  applyOverlayChanges(changes) {
    let results = new LeafletControlLayersChanges();
    if (null != this.layersControl) {
      results = this.applyChanges(changes, this.layersControl.addOverlay);
    }
    return results;
  }
  applyChanges(changes, addFn) {
    const results = new LeafletControlLayersChanges();
    if (null != changes) {
      // All layer management is outside angular to avoid layer events from triggering change detection
      this.zone.runOutsideAngular(() => {
        changes.forEachChangedItem(c => {
          this.layersControl.removeLayer(c.previousValue);
          addFn.call(this.layersControl, c.currentValue, c.key);
          results.layersChanged++;
        });
        changes.forEachRemovedItem(c => {
          this.layersControl.removeLayer(c.previousValue);
          results.layersRemoved++;
        });
        changes.forEachAddedItem(c => {
          addFn.call(this.layersControl, c.currentValue, c.key);
          results.layersAdded++;
        });
      });
    }
    return results;
  }
}
class LeafletControlLayersConfig {
  constructor() {
    this.baseLayers = {};
    this.overlays = {};
  }
}

/**
 * Layers Control
 *
 * This directive is used to configure the layers control. The input accepts an object with two
 * key-value maps of layer name -> layer. Mutable changes are detected. On changes, a differ is
 * used to determine what changed so that layers are appropriately added or removed.
 *
 * To specify which layer to show as the 'active' baselayer, you will want to add it to the map
 * using the layers directive. Otherwise, the last one it sees will be used.
 */
class LeafletLayersControlDirective {
  set layersControlConfig(v) {
    // Validation/init stuff
    if (null == v) {
      v = new LeafletControlLayersConfig();
    }
    if (null == v.baseLayers) {
      v.baseLayers = {};
    }
    if (null == v.overlays) {
      v.overlays = {};
    }
    // Store the value
    this.layersControlConfigValue = v;
    // Update the map
    this.updateLayers();
  }
  get layersControlConfig() {
    return this.layersControlConfigValue;
  }
  constructor(leafletDirective, differs, zone) {
    this.differs = differs;
    this.zone = zone;
    this.layersControlReady = new _angular_core__WEBPACK_IMPORTED_MODULE_1__.EventEmitter();
    this.leafletDirective = new LeafletDirectiveWrapper(leafletDirective);
    this.controlLayers = new LeafletControlLayersWrapper(this.zone, this.layersControlReady);
    // Generate differs
    this.baseLayersDiffer = this.differs.find({}).create();
    this.overlaysDiffer = this.differs.find({}).create();
  }
  ngOnInit() {
    // Init the map
    this.leafletDirective.init();
    // Set up control outside of angular to avoid change detection when using the control
    this.zone.runOutsideAngular(() => {
      // Set up all the initial settings
      this.controlLayers.init({}, this.layersControlOptions).addTo(this.leafletDirective.getMap());
    });
    this.updateLayers();
  }
  ngOnDestroy() {
    this.layersControlConfig = {
      baseLayers: {},
      overlays: {}
    };
    this.controlLayers.getLayersControl().remove();
  }
  ngDoCheck() {
    this.updateLayers();
  }
  updateLayers() {
    const map = this.leafletDirective.getMap();
    const layersControl = this.controlLayers.getLayersControl();
    if (null != map && null != layersControl) {
      // Run the baselayers differ
      if (null != this.baseLayersDiffer && null != this.layersControlConfigValue.baseLayers) {
        const changes = this.baseLayersDiffer.diff(this.layersControlConfigValue.baseLayers);
        this.controlLayers.applyBaseLayerChanges(changes);
      }
      // Run the overlays differ
      if (null != this.overlaysDiffer && null != this.layersControlConfigValue.overlays) {
        const changes = this.overlaysDiffer.diff(this.layersControlConfigValue.overlays);
        this.controlLayers.applyOverlayChanges(changes);
      }
    }
  }
  static #_ = _staticBlock4 = () => (this.ɵfac = function LeafletLayersControlDirective_Factory(__ngFactoryType__) {
    return new (__ngFactoryType__ || LeafletLayersControlDirective)(_angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵdirectiveInject"](LeafletDirective), _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵdirectiveInject"](_angular_core__WEBPACK_IMPORTED_MODULE_2__.KeyValueDiffers), _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵdirectiveInject"](_angular_core__WEBPACK_IMPORTED_MODULE_1__.NgZone));
  }, this.ɵdir = /* @__PURE__ */_angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵdefineDirective"]({
    type: LeafletLayersControlDirective,
    selectors: [["", "leafletLayersControl", ""]],
    inputs: {
      layersControlConfig: [0, "leafletLayersControl", "layersControlConfig"],
      layersControlOptions: [0, "leafletLayersControlOptions", "layersControlOptions"]
    },
    outputs: {
      layersControlReady: "leafletLayersControlReady"
    }
  }));
}
_staticBlock4();
(() => {
  (typeof ngDevMode === "undefined" || ngDevMode) && _angular_core__WEBPACK_IMPORTED_MODULE_1__.setClassMetadata(LeafletLayersControlDirective, [{
    type: _angular_core__WEBPACK_IMPORTED_MODULE_1__.Directive,
    args: [{
      selector: '[leafletLayersControl]'
    }]
  }], () => [{
    type: LeafletDirective
  }, {
    type: _angular_core__WEBPACK_IMPORTED_MODULE_2__.KeyValueDiffers
  }, {
    type: _angular_core__WEBPACK_IMPORTED_MODULE_1__.NgZone
  }], {
    layersControlConfig: [{
      type: _angular_core__WEBPACK_IMPORTED_MODULE_1__.Input,
      args: ['leafletLayersControl']
    }],
    layersControlOptions: [{
      type: _angular_core__WEBPACK_IMPORTED_MODULE_1__.Input,
      args: ['leafletLayersControlOptions']
    }],
    layersControlReady: [{
      type: _angular_core__WEBPACK_IMPORTED_MODULE_1__.Output,
      args: ['leafletLayersControlReady']
    }]
  });
})();

/**
 * Baselayers directive
 *
 * This directive is provided as a convenient way to add baselayers to the map. The input accepts
 * a key-value map of layer name -> layer. Mutable changed are detected. On changes, a differ is
 * used to determine what changed so that layers are appropriately added or removed. This directive
 * will also add the layers control so users can switch between available base layers.
 *
 * To specify which layer to show as the 'active' baselayer, you will want to add it to the map
 * using the layers directive. Otherwise, the plugin will use the last one it sees.
 */
class LeafletBaseLayersDirective {
  // Set/get baseLayers
  set baseLayers(v) {
    this.baseLayersValue = v;
    this.updateBaseLayers();
  }
  get baseLayers() {
    return this.baseLayersValue;
  }
  constructor(leafletDirective, differs, zone) {
    this.differs = differs;
    this.zone = zone;
    // Output for once the layers control is ready
    this.layersControlReady = new _angular_core__WEBPACK_IMPORTED_MODULE_1__.EventEmitter();
    this.leafletDirective = new LeafletDirectiveWrapper(leafletDirective);
    this.controlLayers = new LeafletControlLayersWrapper(this.zone, this.layersControlReady);
    this.baseLayersDiffer = this.differs.find({}).create();
  }
  ngOnDestroy() {
    this.baseLayers = {};
    if (null != this.controlLayers.getLayersControl()) {
      this.controlLayers.getLayersControl().remove();
    }
  }
  ngOnInit() {
    // Init the map
    this.leafletDirective.init();
    // Create the control outside angular to prevent events from triggering chnage detection
    this.zone.runOutsideAngular(() => {
      // Initially configure the controlLayers
      this.controlLayers.init({}, this.layersControlOptions).addTo(this.leafletDirective.getMap());
    });
    this.updateBaseLayers();
  }
  ngDoCheck() {
    this.updateBaseLayers();
  }
  updateBaseLayers() {
    const map = this.leafletDirective.getMap();
    const layersControl = this.controlLayers.getLayersControl();
    if (null != map && null != layersControl && null != this.baseLayersDiffer) {
      const changes = this.baseLayersDiffer.diff(this.baseLayersValue);
      const results = this.controlLayers.applyBaseLayerChanges(changes);
      if (results.changed()) {
        this.syncBaseLayer();
      }
    }
  }
  /**
   * Check the current base layer and change it to the new one if necessary
   */
  syncBaseLayer() {
    const map = this.leafletDirective.getMap();
    const layers = LeafletUtil.mapToArray(this.baseLayers);
    let foundLayer;
    // Search all the layers in the map to see if we can find them in the baselayer array
    map.eachLayer(l => {
      foundLayer = layers.find(bl => l === bl);
    });
    // Did we find the layer?
    if (null != foundLayer) {
      // Yes - set the baselayer to the one we found
      this.baseLayer = foundLayer;
    } else {
      // No - set the baselayer to the first in the array and add it to the map
      if (layers.length > 0) {
        this.baseLayer = layers[0];
        // Add layers outside of angular to prevent events from triggering change detection
        this.zone.runOutsideAngular(() => {
          this.baseLayer.addTo(map);
        });
      }
    }
  }
  static #_ = _staticBlock5 = () => (this.ɵfac = function LeafletBaseLayersDirective_Factory(__ngFactoryType__) {
    return new (__ngFactoryType__ || LeafletBaseLayersDirective)(_angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵdirectiveInject"](LeafletDirective), _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵdirectiveInject"](_angular_core__WEBPACK_IMPORTED_MODULE_2__.KeyValueDiffers), _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵdirectiveInject"](_angular_core__WEBPACK_IMPORTED_MODULE_1__.NgZone));
  }, this.ɵdir = /* @__PURE__ */_angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵdefineDirective"]({
    type: LeafletBaseLayersDirective,
    selectors: [["", "leafletBaseLayers", ""]],
    inputs: {
      baseLayers: [0, "leafletBaseLayers", "baseLayers"],
      layersControlOptions: [0, "leafletLayersControlOptions", "layersControlOptions"]
    },
    outputs: {
      layersControlReady: "leafletLayersControlReady"
    }
  }));
}
_staticBlock5();
(() => {
  (typeof ngDevMode === "undefined" || ngDevMode) && _angular_core__WEBPACK_IMPORTED_MODULE_1__.setClassMetadata(LeafletBaseLayersDirective, [{
    type: _angular_core__WEBPACK_IMPORTED_MODULE_1__.Directive,
    args: [{
      selector: '[leafletBaseLayers]'
    }]
  }], () => [{
    type: LeafletDirective
  }, {
    type: _angular_core__WEBPACK_IMPORTED_MODULE_2__.KeyValueDiffers
  }, {
    type: _angular_core__WEBPACK_IMPORTED_MODULE_1__.NgZone
  }], {
    baseLayers: [{
      type: _angular_core__WEBPACK_IMPORTED_MODULE_1__.Input,
      args: ['leafletBaseLayers']
    }],
    layersControlOptions: [{
      type: _angular_core__WEBPACK_IMPORTED_MODULE_1__.Input,
      args: ['leafletLayersControlOptions']
    }],
    layersControlReady: [{
      type: _angular_core__WEBPACK_IMPORTED_MODULE_1__.Output,
      args: ['leafletLayersControlReady']
    }]
  });
})();
class LeafletModule {
  static #_ = _staticBlock6 = () => (this.ɵfac = function LeafletModule_Factory(__ngFactoryType__) {
    return new (__ngFactoryType__ || LeafletModule)();
  }, this.ɵmod = /* @__PURE__ */_angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵdefineNgModule"]({
    type: LeafletModule
  }), this.ɵinj = /* @__PURE__ */_angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵdefineInjector"]({}));
}
_staticBlock6();
(() => {
  (typeof ngDevMode === "undefined" || ngDevMode) && _angular_core__WEBPACK_IMPORTED_MODULE_1__.setClassMetadata(LeafletModule, [{
    type: _angular_core__WEBPACK_IMPORTED_MODULE_1__.NgModule,
    args: [{
      imports: [LeafletDirective, LeafletLayerDirective, LeafletLayersDirective, LeafletLayersControlDirective, LeafletBaseLayersDirective],
      exports: [LeafletDirective, LeafletLayerDirective, LeafletLayersDirective, LeafletLayersControlDirective, LeafletBaseLayersDirective]
    }]
  }], null, null);
})();
class LeafletTileLayerDefinition {
  constructor(type, url, options) {
    this.type = type;
    this.url = url;
    this.options = options;
  }
  /**
   * Creates a TileLayer from the provided definition. This is a convenience function
   * to help with generating layers from objects.
   *
   * @param layerDef The layer to create
   * @returns {TileLayer} The TileLayer that has been created
   */
  static createTileLayer(layerDef) {
    let layer;
    switch (layerDef.type) {
      case 'xyz':
        layer = (0,leaflet__WEBPACK_IMPORTED_MODULE_3__.tileLayer)(layerDef.url, layerDef.options);
        break;
      case 'wms':
      default:
        layer = leaflet__WEBPACK_IMPORTED_MODULE_3__.tileLayer.wms(layerDef.url, layerDef.options);
        break;
    }
    return layer;
  }
  /**
   * Creates a TileLayer for each key in the incoming map. This is a convenience function
   * for generating an associative array of layers from an associative array of objects
   *
   * @param layerDefs A map of key to tile layer definition
   * @returns {{[p: string]: TileLayer}} A new map of key to TileLayer
   */
  static createTileLayers(layerDefs) {
    const layers = {};
    for (const k in layerDefs) {
      if (layerDefs.hasOwnProperty(k)) {
        layers[k] = LeafletTileLayerDefinition.createTileLayer(layerDefs[k]);
      }
    }
    return layers;
  }
  /**
   * Create a Tile Layer from the current state of this object
   *
   * @returns {TileLayer} A new TileLayer
   */
  createTileLayer() {
    return LeafletTileLayerDefinition.createTileLayer(this);
  }
}

/**
 * Generated bundle index. Do not edit.
 */



/***/ }),

/***/ 11735:
/*!***************************************************************!*\
  !*** ./src/app/pages/trips/trip-detail/trip-detail.module.ts ***!
  \***************************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   TripDetailPageModule: () => (/* binding */ TripDetailPageModule)
/* harmony export */ });
/* harmony import */ var _ionic_angular__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! @ionic/angular */ 21507);
/* harmony import */ var _trip_detail_routing_module__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ./trip-detail-routing.module */ 48974);
/* harmony import */ var _trip_detail_page__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! ./trip-detail.page */ 76112);
/* harmony import */ var src_app_core_shared_shared_module__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! src/app/core/shared/shared.module */ 62657);
/* harmony import */ var _trip_detail_map_trip_detail_map_component__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! ./trip-detail-map/trip-detail-map.component */ 62676);
/* harmony import */ var _bluehalo_ngx_leaflet__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! @bluehalo/ngx-leaflet */ 9835);
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! @angular/core */ 34205);
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(/*! @angular/core */ 12481);
var _staticBlock;







class TripDetailPageModule {
  static #_ = _staticBlock = () => (this.ɵfac = function TripDetailPageModule_Factory(__ngFactoryType__) {
    return new (__ngFactoryType__ || TripDetailPageModule)();
  }, this.ɵmod = /*@__PURE__*/_angular_core__WEBPACK_IMPORTED_MODULE_7__["ɵɵdefineNgModule"]({
    type: TripDetailPageModule
  }), this.ɵinj = /*@__PURE__*/_angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵdefineInjector"]({
    imports: [src_app_core_shared_shared_module__WEBPACK_IMPORTED_MODULE_3__.PlayGoSharedModule, _trip_detail_routing_module__WEBPACK_IMPORTED_MODULE_1__.TripDetailPageRoutingModule, _bluehalo_ngx_leaflet__WEBPACK_IMPORTED_MODULE_5__.LeafletModule, _ionic_angular__WEBPACK_IMPORTED_MODULE_0__.IonicModule]
  }));
}
_staticBlock();
(function () {
  (typeof ngJitMode === "undefined" || ngJitMode) && _angular_core__WEBPACK_IMPORTED_MODULE_7__["ɵɵsetNgModuleScope"](TripDetailPageModule, {
    declarations: [_trip_detail_page__WEBPACK_IMPORTED_MODULE_2__.TripDetailPage, _trip_detail_map_trip_detail_map_component__WEBPACK_IMPORTED_MODULE_4__.TripDetailMapComponent],
    imports: [src_app_core_shared_shared_module__WEBPACK_IMPORTED_MODULE_3__.PlayGoSharedModule, _trip_detail_routing_module__WEBPACK_IMPORTED_MODULE_1__.TripDetailPageRoutingModule, _bluehalo_ngx_leaflet__WEBPACK_IMPORTED_MODULE_5__.LeafletModule, _ionic_angular__WEBPACK_IMPORTED_MODULE_0__.IonicModule]
  });
})();

/***/ }),

/***/ 34145:
/*!*******************************************************************!*\
  !*** ./node_modules/@googlemaps/polyline-codec/dist/index.esm.js ***!
  \*******************************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   decode: () => (/* binding */ decode),
/* harmony export */   encode: () => (/* binding */ encode),
/* harmony export */   polylineEncodeLine: () => (/* binding */ polylineEncodeLine)
/* harmony export */ });
/**
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *      http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
/**
 * Decodes an encoded path string into a sequence of LatLngs.
 *
 * See {@link https://developers.google.com/maps/documentation/utilities/polylinealgorithm}
 *
 *  #### Example
 *
 * ```js
 * import { decode } from "@googlemaps/polyline-codec";
 *
 * const encoded = "_p~iF~ps|U_ulLnnqC_mqNvxq`@";
 * console.log(decode(encoded, 5));
 * // [
 * //   [38.5, -120.2],
 * //   [40.7, -120.95],
 * //   [43.252, -126.453],
 * // ]
 * ```
 */
var decode = function (encodedPath, precision) {
  if (precision === void 0) {
    precision = 5;
  }
  var factor = Math.pow(10, precision);
  var len = encodedPath.length;
  // For speed we preallocate to an upper bound on the final length, then
  // truncate the array before returning.
  var path = new Array(Math.floor(encodedPath.length / 2));
  var index = 0;
  var lat = 0;
  var lng = 0;
  var pointIndex = 0;
  // This code has been profiled and optimized, so don't modify it without
  // measuring its performance.
  for (; index < len; ++pointIndex) {
    // Fully unrolling the following loops speeds things up about 5%.
    var result = 1;
    var shift = 0;
    var b = void 0;
    do {
      // Invariant: "result" is current partial result plus (1 << shift).
      // The following line effectively clears this bit by decrementing "b".
      b = encodedPath.charCodeAt(index++) - 63 - 1;
      result += b << shift;
      shift += 5;
    } while (b >= 0x1f); // See note above.
    lat += result & 1 ? ~(result >> 1) : result >> 1;
    result = 1;
    shift = 0;
    do {
      b = encodedPath.charCodeAt(index++) - 63 - 1;
      result += b << shift;
      shift += 5;
    } while (b >= 0x1f);
    lng += result & 1 ? ~(result >> 1) : result >> 1;
    path[pointIndex] = [lat / factor, lng / factor];
  }
  // truncate array
  path.length = pointIndex;
  return path;
};
/**
 * Polyline encodes an array of objects having lat and lng properties.
 *
 * See {@link https://developers.google.com/maps/documentation/utilities/polylinealgorithm}
 *
 * #### Example
 *
 * ```js
 * import { encode } from "@googlemaps/polyline-codec";
 *
 * const path = [
 *   [38.5, -120.2],
 *   [40.7, -120.95],
 *   [43.252, -126.453],
 * ];
 * console.log(encode(path, 5));
 * // "_p~iF~ps|U_ulLnnqC_mqNvxq`@"
 * ```
 */
var encode = function (path, precision) {
  if (precision === void 0) {
    precision = 5;
  }
  var factor = Math.pow(10, precision);
  var transform = function latLngToFixed(latLng) {
    if (!Array.isArray(latLng)) {
      latLng = [latLng.lat, latLng.lng];
    }
    return [round(latLng[0] * factor), round(latLng[1] * factor)];
  };
  return polylineEncodeLine(path, transform);
};
/**
 * Encodes a generic polyline; optionally performing a transform on each point
 * before encoding it.
 *
 * @ignore
 */
var polylineEncodeLine = function (array, transform) {
  var v = [];
  var start = [0, 0];
  var end;
  for (var i = 0, I = array.length; i < I; ++i) {
    // In order to prevent drift (from quantizing deltas), we explicitly convert
    // coordinates to fixed-precision to obtain integer deltas.
    end = transform(array[i]);
    // Push the next edge
    polylineEncodeSigned(round(end[0]) - round(start[0]), v); // lat
    polylineEncodeSigned(round(end[1]) - round(start[1]), v); // lng
    start = end;
  }
  return v.join("");
};
/**
 * Encodes the given value in our compact polyline format, appending the
 * encoded value to the given array of strings.
 *
 * @ignore
 */
var polylineEncodeSigned = function (value, array) {
  return polylineEncodeUnsigned(value < 0 ? ~(value << 1) : value << 1, array);
};
/**
 * Helper function for encodeSigned.
 *
 * @ignore
 */
var polylineEncodeUnsigned = function (value, array) {
  while (value >= 0x20) {
    array.push(String.fromCharCode((0x20 | value & 0x1f) + 63));
    value >>= 5;
  }
  array.push(String.fromCharCode(value + 63));
  return array;
};
/**
 * @ignore
 */
var round = function (v) {
  return Math.floor(Math.abs(v) + 0.5) * (v >= 0 ? 1 : -1);
};


/***/ }),

/***/ 48974:
/*!***********************************************************************!*\
  !*** ./src/app/pages/trips/trip-detail/trip-detail-routing.module.ts ***!
  \***********************************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   TripDetailPageRoutingModule: () => (/* binding */ TripDetailPageRoutingModule)
/* harmony export */ });
/* harmony import */ var _angular_router__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! @angular/router */ 34487);
/* harmony import */ var _trip_detail_page__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ./trip-detail.page */ 76112);
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @angular/core */ 34205);
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @angular/core */ 12481);
var _staticBlock;




const routes = [{
  path: '',
  component: _trip_detail_page__WEBPACK_IMPORTED_MODULE_1__.TripDetailPage,
  data: {
    title: 'tripDetailTitle',
    defaultHref: '/pages/tabs/trips'
  }
}];
class TripDetailPageRoutingModule {
  static #_ = _staticBlock = () => (this.ɵfac = function TripDetailPageRoutingModule_Factory(__ngFactoryType__) {
    return new (__ngFactoryType__ || TripDetailPageRoutingModule)();
  }, this.ɵmod = /*@__PURE__*/_angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵdefineNgModule"]({
    type: TripDetailPageRoutingModule
  }), this.ɵinj = /*@__PURE__*/_angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵdefineInjector"]({
    imports: [_angular_router__WEBPACK_IMPORTED_MODULE_0__.RouterModule.forChild(routes), _angular_router__WEBPACK_IMPORTED_MODULE_0__.RouterModule]
  }));
}
_staticBlock();
(function () {
  (typeof ngJitMode === "undefined" || ngJitMode) && _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵsetNgModuleScope"](TripDetailPageRoutingModule, {
    imports: [_angular_router__WEBPACK_IMPORTED_MODULE_0__.RouterModule],
    exports: [_angular_router__WEBPACK_IMPORTED_MODULE_0__.RouterModule]
  });
})();

/***/ }),

/***/ 62676:
/*!**************************************************************************************!*\
  !*** ./src/app/pages/trips/trip-detail/trip-detail-map/trip-detail-map.component.ts ***!
  \**************************************************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   TripDetailMapComponent: () => (/* binding */ TripDetailMapComponent)
/* harmony export */ });
/* harmony import */ var leaflet__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! leaflet */ 67381);
/* harmony import */ var leaflet__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(leaflet__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var rxjs__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! rxjs */ 10819);
/* harmony import */ var rxjs__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! rxjs */ 56042);
/* harmony import */ var rxjs_operators__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! rxjs/operators */ 70271);
/* harmony import */ var rxjs_operators__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! rxjs/operators */ 86301);
/* harmony import */ var rxjs_operators__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! rxjs/operators */ 33900);
/* harmony import */ var lodash_es__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! lodash-es */ 95110);
/* harmony import */ var lodash_es__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(/*! lodash-es */ 80524);
/* harmony import */ var lodash_es__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(/*! lodash-es */ 65644);
/* harmony import */ var src_app_core_shared_tracking_trip_model__WEBPACK_IMPORTED_MODULE_9__ = __webpack_require__(/*! src/app/core/shared/tracking/trip.model */ 23126);
/* harmony import */ var _googlemaps_polyline_codec__WEBPACK_IMPORTED_MODULE_10__ = __webpack_require__(/*! @googlemaps/polyline-codec */ 34145);
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_11__ = __webpack_require__(/*! @angular/core */ 12481);
/* harmony import */ var _angular_common__WEBPACK_IMPORTED_MODULE_12__ = __webpack_require__(/*! @angular/common */ 93683);
/* harmony import */ var _bluehalo_ngx_leaflet__WEBPACK_IMPORTED_MODULE_13__ = __webpack_require__(/*! @bluehalo/ngx-leaflet */ 9835);
var _staticBlock;









function TripDetailMapComponent_ng_container_1_Template(rf, ctx) {
  if (rf & 1) {
    _angular_core__WEBPACK_IMPORTED_MODULE_11__["ɵɵelementContainerStart"](0);
    _angular_core__WEBPACK_IMPORTED_MODULE_11__["ɵɵelement"](1, "div", 2);
    _angular_core__WEBPACK_IMPORTED_MODULE_11__["ɵɵelementContainerEnd"]();
  }
  if (rf & 2) {
    const layer_r1 = ctx.$implicit;
    _angular_core__WEBPACK_IMPORTED_MODULE_11__["ɵɵadvance"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_11__["ɵɵproperty"]("leafletLayer", layer_r1);
  }
}
class TripDetailMapComponent {
  set tripParts(tripParts) {
    console.log('tripParts', tripParts);
    this.tripPartsSubject.next(tripParts);
  }
  constructor() {
    this.tripPartsSubject = new rxjs__WEBPACK_IMPORTED_MODULE_2__.ReplaySubject(1);
    this.mapOptions = {
      layers: [(0,leaflet__WEBPACK_IMPORTED_MODULE_0__.tileLayer)('https://{s}.tile.openstreetmap.org/{z}/{x}/{y}.png', {
        maxZoom: 19,
        // for lower zooms there are no tiles!
        minZoom: 10,
        attribution: '&copy; <a href="http://www.openstreetmap.org/copyright">OpenStreetMap</a>'
      })]
    };
    this.tripPartsDecoded$ = this.tripPartsSubject.pipe((0,rxjs_operators__WEBPACK_IMPORTED_MODULE_3__.map)(tripParts => (0,lodash_es__WEBPACK_IMPORTED_MODULE_8__["default"])(tripParts, tripPart => {
      const decoded = (0,_googlemaps_polyline_codec__WEBPACK_IMPORTED_MODULE_10__.decode)(tripPart.polyline);
      return {
        ...tripPart,
        polyline: decoded
      };
    })), (0,rxjs_operators__WEBPACK_IMPORTED_MODULE_4__.shareReplay)(1));
    this.fullPolyLineCoords$ = this.tripPartsDecoded$.pipe((0,rxjs_operators__WEBPACK_IMPORTED_MODULE_3__.map)(tripParts => {
      const polylines = tripParts.map(tripPart => tripPart.polyline);
      const mergedParts = [].concat.apply([], polylines);
      return mergedParts;
    }));
    this.startMarker$ = this.fullPolyLineCoords$.pipe((0,rxjs_operators__WEBPACK_IMPORTED_MODULE_3__.map)(coords => (0,lodash_es__WEBPACK_IMPORTED_MODULE_6__["default"])(coords)), (0,rxjs_operators__WEBPACK_IMPORTED_MODULE_3__.map)(coordinate => (0,leaflet__WEBPACK_IMPORTED_MODULE_0__.marker)((0,leaflet__WEBPACK_IMPORTED_MODULE_0__.latLng)(coordinate), {
      icon: (0,leaflet__WEBPACK_IMPORTED_MODULE_0__.icon)({
        ...leaflet__WEBPACK_IMPORTED_MODULE_0__.Icon.Default.prototype.options,
        iconUrl: 'assets/images/map/markerStart-icon.png',
        iconRetinaUrl: 'assets/images/map/markerStart-icon-2x.png',
        shadowUrl: 'assets/images/map/marker-shadow.png'
      })
    })));
    this.endMarker$ = this.fullPolyLineCoords$.pipe((0,rxjs_operators__WEBPACK_IMPORTED_MODULE_3__.map)(lodash_es__WEBPACK_IMPORTED_MODULE_7__["default"]), (0,rxjs_operators__WEBPACK_IMPORTED_MODULE_3__.map)(coordinate => (0,leaflet__WEBPACK_IMPORTED_MODULE_0__.marker)((0,leaflet__WEBPACK_IMPORTED_MODULE_0__.latLng)(coordinate), {
      icon: (0,leaflet__WEBPACK_IMPORTED_MODULE_0__.icon)({
        ...leaflet__WEBPACK_IMPORTED_MODULE_0__.Icon.Default.prototype.options,
        // TODO: set proper svg icon
        iconUrl: 'assets/images/map/markerStop-icon.png',
        iconRetinaUrl: 'assets/images/map/markerStop-icon-2x.png',
        shadowUrl: 'assets/images/map/marker-shadow.png'
      })
    })));
    this.tripPartLineLayers$ = this.tripPartsDecoded$.pipe((0,rxjs_operators__WEBPACK_IMPORTED_MODULE_3__.map)(tripParts => (0,lodash_es__WEBPACK_IMPORTED_MODULE_8__["default"])(tripParts, eachPart => (0,leaflet__WEBPACK_IMPORTED_MODULE_0__.polyline)(eachPart.polyline, {
      color: src_app_core_shared_tracking_trip_model__WEBPACK_IMPORTED_MODULE_9__.transportTypeColors[eachPart.modeType]
    }))), (0,rxjs_operators__WEBPACK_IMPORTED_MODULE_4__.shareReplay)(1));
    this.tripBounds$ = this.fullPolyLineCoords$.pipe((0,rxjs_operators__WEBPACK_IMPORTED_MODULE_3__.map)(fullPolyLineCoords => {
      const bounds = (0,leaflet__WEBPACK_IMPORTED_MODULE_0__.polyline)(fullPolyLineCoords).getBounds();
      const southNorthDistance = bounds.getNorth() - bounds.getSouth();
      const boundsWithSpaceForDetail = (0,leaflet__WEBPACK_IMPORTED_MODULE_0__.latLngBounds)((0,leaflet__WEBPACK_IMPORTED_MODULE_0__.latLng)(bounds.getNorth() - 2 * southNorthDistance, bounds.getWest()), bounds.getNorthEast());
      return boundsWithSpaceForDetail;
    }));
    this.componentDestroyed$ = new rxjs__WEBPACK_IMPORTED_MODULE_1__.Subject();
  }
  onMapReady(mapInstance) {
    this.initMap(mapInstance);
    mapInstance.invalidateSize();
    setTimeout(() => {
      mapInstance.invalidateSize();
    }, 500);
  }
  initMap(mapInstance) {
    this.tripBounds$.pipe((0,rxjs_operators__WEBPACK_IMPORTED_MODULE_5__.takeUntil)(this.componentDestroyed$)).subscribe(bounds => {
      mapInstance.fitBounds(bounds);
    });
  }
  ngOnInit() {}
  ngOnDestroy() {}
  ionViewDidLeave() {
    this.componentDestroyed$.next(true);
    this.componentDestroyed$.complete();
  }
  static #_ = _staticBlock = () => (this.ɵfac = function TripDetailMapComponent_Factory(__ngFactoryType__) {
    return new (__ngFactoryType__ || TripDetailMapComponent)();
  }, this.ɵcmp = /*@__PURE__*/_angular_core__WEBPACK_IMPORTED_MODULE_11__["ɵɵdefineComponent"]({
    type: TripDetailMapComponent,
    selectors: [["app-trip-detail-map"]],
    inputs: {
      tripParts: "tripParts"
    },
    standalone: false,
    decls: 7,
    vars: 10,
    consts: [["leaflet", "", 1, "ngx-leaflet", 3, "leafletMapReady", "leafletOptions"], [4, "ngFor", "ngForOf"], [3, "leafletLayer"]],
    template: function TripDetailMapComponent_Template(rf, ctx) {
      if (rf & 1) {
        _angular_core__WEBPACK_IMPORTED_MODULE_11__["ɵɵelementStart"](0, "div", 0);
        _angular_core__WEBPACK_IMPORTED_MODULE_11__["ɵɵlistener"]("leafletMapReady", function TripDetailMapComponent_Template_div_leafletMapReady_0_listener($event) {
          return ctx.onMapReady($event);
        });
        _angular_core__WEBPACK_IMPORTED_MODULE_11__["ɵɵtemplate"](1, TripDetailMapComponent_ng_container_1_Template, 2, 1, "ng-container", 1);
        _angular_core__WEBPACK_IMPORTED_MODULE_11__["ɵɵpipe"](2, "async");
        _angular_core__WEBPACK_IMPORTED_MODULE_11__["ɵɵelement"](3, "div", 2);
        _angular_core__WEBPACK_IMPORTED_MODULE_11__["ɵɵpipe"](4, "async");
        _angular_core__WEBPACK_IMPORTED_MODULE_11__["ɵɵelement"](5, "div", 2);
        _angular_core__WEBPACK_IMPORTED_MODULE_11__["ɵɵpipe"](6, "async");
        _angular_core__WEBPACK_IMPORTED_MODULE_11__["ɵɵelementEnd"]();
      }
      if (rf & 2) {
        _angular_core__WEBPACK_IMPORTED_MODULE_11__["ɵɵproperty"]("leafletOptions", ctx.mapOptions);
        _angular_core__WEBPACK_IMPORTED_MODULE_11__["ɵɵadvance"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_11__["ɵɵproperty"]("ngForOf", _angular_core__WEBPACK_IMPORTED_MODULE_11__["ɵɵpipeBind1"](2, 4, ctx.tripPartLineLayers$));
        _angular_core__WEBPACK_IMPORTED_MODULE_11__["ɵɵadvance"](2);
        _angular_core__WEBPACK_IMPORTED_MODULE_11__["ɵɵproperty"]("leafletLayer", _angular_core__WEBPACK_IMPORTED_MODULE_11__["ɵɵpipeBind1"](4, 6, ctx.startMarker$));
        _angular_core__WEBPACK_IMPORTED_MODULE_11__["ɵɵadvance"](2);
        _angular_core__WEBPACK_IMPORTED_MODULE_11__["ɵɵproperty"]("leafletLayer", _angular_core__WEBPACK_IMPORTED_MODULE_11__["ɵɵpipeBind1"](6, 8, ctx.endMarker$));
      }
    },
    dependencies: [_angular_common__WEBPACK_IMPORTED_MODULE_12__.NgForOf, _bluehalo_ngx_leaflet__WEBPACK_IMPORTED_MODULE_13__.LeafletDirective, _bluehalo_ngx_leaflet__WEBPACK_IMPORTED_MODULE_13__.LeafletLayerDirective, _angular_common__WEBPACK_IMPORTED_MODULE_12__.AsyncPipe],
    styles: ["[_nghost-%COMP%] {\n  display: block;\n  height: 100%;\n  position: relative;\n}\n[_nghost-%COMP%]   .ngx-leaflet[_ngcontent-%COMP%] {\n  height: 100%;\n}\n/*# sourceMappingURL=data:application/json;charset=utf-8;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbIndlYnBhY2s6Ly8uL3NyYy9hcHAvcGFnZXMvdHJpcHMvdHJpcC1kZXRhaWwvdHJpcC1kZXRhaWwtbWFwL3RyaXAtZGV0YWlsLW1hcC5jb21wb25lbnQuc2NzcyJdLCJuYW1lcyI6W10sIm1hcHBpbmdzIjoiQUFBQTtFQUNFLGNBQUE7RUFDQSxZQUFBO0VBQ0Esa0JBQUE7QUFDRjtBQUFFO0VBQ0UsWUFBQTtBQUVKIiwic291cmNlc0NvbnRlbnQiOlsiOmhvc3Qge1xuICBkaXNwbGF5OiBibG9jaztcbiAgaGVpZ2h0OiAxMDAlO1xuICBwb3NpdGlvbjogcmVsYXRpdmU7XG4gIC5uZ3gtbGVhZmxldCB7XG4gICAgaGVpZ2h0OiAxMDAlO1xuICB9XG59XG4iXSwic291cmNlUm9vdCI6IiJ9 */"]
  }));
}
_staticBlock();

/***/ }),

/***/ 76112:
/*!*************************************************************!*\
  !*** ./src/app/pages/trips/trip-detail/trip-detail.page.ts ***!
  \*************************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   TripDetailPage: () => (/* binding */ TripDetailPage)
/* harmony export */ });
/* harmony import */ var _Users_smartcommunitylab_Desktop_newWork_playAndGo_playGo_node_modules_babel_runtime_helpers_esm_asyncToGenerator_js__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./node_modules/@babel/runtime/helpers/esm/asyncToGenerator.js */ 89204);
/* harmony import */ var rxjs__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! rxjs */ 70271);
/* harmony import */ var src_app_core_shared_tracking_trip_model__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! src/app/core/shared/tracking/trip.model */ 23126);
/* harmony import */ var src_app_core_shared_utils__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! src/app/core/shared/utils */ 7497);
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! @angular/core */ 34205);
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! @angular/core */ 12481);
/* harmony import */ var _angular_router__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! @angular/router */ 85422);
/* harmony import */ var src_app_core_shared_services_error_service__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(/*! src/app/core/shared/services/error.service */ 46078);
/* harmony import */ var src_app_core_shared_tracking_track_api_service__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(/*! src/app/core/shared/tracking/track-api.service */ 39499);
/* harmony import */ var src_app_core_shared_services_campaign_service__WEBPACK_IMPORTED_MODULE_9__ = __webpack_require__(/*! src/app/core/shared/services/campaign.service */ 76658);
/* harmony import */ var src_app_core_shared_services_alert_service__WEBPACK_IMPORTED_MODULE_10__ = __webpack_require__(/*! src/app/core/shared/services/alert.service */ 67406);
/* harmony import */ var _angular_common__WEBPACK_IMPORTED_MODULE_11__ = __webpack_require__(/*! @angular/common */ 93683);
/* harmony import */ var _ionic_angular__WEBPACK_IMPORTED_MODULE_12__ = __webpack_require__(/*! @ionic/angular */ 21507);
/* harmony import */ var _core_shared_layout_header_header_directive__WEBPACK_IMPORTED_MODULE_13__ = __webpack_require__(/*! ../../../core/shared/layout/header/header.directive */ 85039);
/* harmony import */ var _core_shared_layout_content_content_directive__WEBPACK_IMPORTED_MODULE_14__ = __webpack_require__(/*! ../../../core/shared/layout/content/content.directive */ 75855);
/* harmony import */ var _core_shared_ui_icon_icon_component__WEBPACK_IMPORTED_MODULE_15__ = __webpack_require__(/*! ../../../core/shared/ui/icon/icon.component */ 59621);
/* harmony import */ var _trip_detail_map_trip_detail_map_component__WEBPACK_IMPORTED_MODULE_16__ = __webpack_require__(/*! ./trip-detail-map/trip-detail-map.component */ 62676);
/* harmony import */ var _ngx_translate_core__WEBPACK_IMPORTED_MODULE_17__ = __webpack_require__(/*! @ngx-translate/core */ 48503);
/* harmony import */ var _core_shared_pipes_localDate_pipe__WEBPACK_IMPORTED_MODULE_18__ = __webpack_require__(/*! ../../../core/shared/pipes/localDate.pipe */ 86451);
/* harmony import */ var _core_shared_pipes_languageMap_pipe__WEBPACK_IMPORTED_MODULE_19__ = __webpack_require__(/*! ../../../core/shared/pipes/languageMap.pipe */ 69618);
/* harmony import */ var _core_shared_pipes_localNumber_pipe__WEBPACK_IMPORTED_MODULE_20__ = __webpack_require__(/*! ../../../core/shared/pipes/localNumber.pipe */ 16024);

var _staticBlock;



















const _c0 = () => ({
  year: "numeric",
  month: "short",
  day: "numeric",
  hour: "numeric",
  minute: "numeric"
});
const _c1 = a0 => [a0];
function TripDetailPage_ng_container_2_app_trip_detail_map_1_Template(rf, ctx) {
  if (rf & 1) {
    _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵelement"](0, "app-trip-detail-map", 14);
  }
  if (rf & 2) {
    const ctx_r0 = _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵnextContext"](2);
    _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵproperty"]("tripParts", _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵpureFunction1"](1, _c1, ctx_r0.tripDetail));
  }
}
function TripDetailPage_ng_container_2_ion_grid_2_Template(rf, ctx) {
  if (rf & 1) {
    _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵelementStart"](0, "ion-grid")(1, "ion-row")(2, "ion-col")(3, "div", 15)(4, "strong");
    _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵtext"](5);
    _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵpipe"](6, "translate");
    _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵelementEnd"]()()()()();
  }
  if (rf & 2) {
    _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵadvance"](5);
    _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵtextInterpolate1"](" ", _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵpipeBind1"](6, 1, "trip_detail.no_track"));
  }
}
function TripDetailPage_ng_container_2_span_16_Template(rf, ctx) {
  if (rf & 1) {
    _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵelementStart"](0, "span");
    _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵtext"](1);
    _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵpipe"](2, "localNumber");
    _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵpipe"](3, "translate");
    _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵelementEnd"]();
  }
  if (rf & 2) {
    const ctx_r0 = _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵnextContext"](2);
    _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵadvance"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵtextInterpolate3"]("", _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵpipeBind2"](2, 3, ctx_r0.tripDetail.distance / 1000, "0.0-1"), " ", _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵpipeBind1"](3, 6, "km"), " ", ctx_r0.durationLabel);
  }
}
function TripDetailPage_ng_container_2_ng_template_17_Template(rf, ctx) {
  if (rf & 1) {
    _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵelementStart"](0, "span");
    _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵtext"](1);
    _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵpipe"](2, "translate");
    _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵelementEnd"]();
  }
  if (rf & 2) {
    _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵadvance"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵtextInterpolate1"](" - ", _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵpipeBind1"](2, 1, "km"), " / - min ");
  }
}
function TripDetailPage_ng_container_2_ion_row_19_Template(rf, ctx) {
  if (rf & 1) {
    _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵelementStart"](0, "ion-row")(1, "span", 16);
    _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵtext"](2);
    _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵpipe"](3, "translate");
    _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵelementEnd"]()();
  }
  if (rf & 2) {
    _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵadvance"](2);
    _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵtextInterpolate1"](" ", _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵpipeBind1"](3, 1, "trip_detail.no_score"), " ");
  }
}
function TripDetailPage_ng_container_2_ion_row_20_ng_container_1_ng_container_2_Template(rf, ctx) {
  if (rf & 1) {
    _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵelementContainerStart"](0);
    _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵtext"](1);
    _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵpipe"](2, "localNumber");
    _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵpipe"](3, "translate");
    _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵelementContainerEnd"]();
  }
  if (rf & 2) {
    const campaign_r3 = _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵnextContext"](2).$implicit;
    _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵadvance"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵtextInterpolate2"](" ", _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵpipeBind2"](2, 2, campaign_r3.distance / 1000, "0.0-1"), " ", _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵpipeBind1"](3, 5, "km"), " ");
  }
}
function TripDetailPage_ng_container_2_ion_row_20_ng_container_1_ng_container_3_Template(rf, ctx) {
  if (rf & 1) {
    _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵelementContainerStart"](0);
    _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵelement"](1, "app-icon", 23);
    _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵelementStart"](2, "ion-text");
    _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵtext"](3);
    _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵpipe"](4, "localNumber");
    _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵelementEnd"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵelementContainerEnd"]();
  }
  if (rf & 2) {
    const campaign_r3 = _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵnextContext"](2).$implicit;
    const ctx_r0 = _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵnextContext"](2);
    _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵadvance"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵproperty"]("color", ctx_r0.campaignService.getCampaignColor(campaign_r3))("name", ctx_r0.campaignService.getCampaignScoreIcon(campaign_r3));
    _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵadvance"](2);
    _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵtextInterpolate"](_angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵpipeBind2"](4, 3, campaign_r3.virtualScore, "0.0-1"));
  }
}
function TripDetailPage_ng_container_2_ion_row_20_ng_container_1_ng_container_4_Template(rf, ctx) {
  if (rf & 1) {
    _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵelementContainerStart"](0);
    _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵelement"](1, "app-icon", 23);
    _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵelementStart"](2, "ion-text");
    _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵtext"](3);
    _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵpipe"](4, "localNumber");
    _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵelementEnd"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵelementContainerEnd"]();
  }
  if (rf & 2) {
    const campaign_r3 = _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵnextContext"](2).$implicit;
    const ctx_r0 = _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵnextContext"](2);
    _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵadvance"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵproperty"]("color", ctx_r0.campaignService.getCampaignColor(campaign_r3))("name", ctx_r0.campaignService.getCampaignScoreIcon(campaign_r3));
    _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵadvance"](2);
    _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵtextInterpolate"](_angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵpipeBind2"](4, 3, campaign_r3.score, "0.0-1"));
  }
}
function TripDetailPage_ng_container_2_ion_row_20_ng_container_1_Template(rf, ctx) {
  if (rf & 1) {
    const _r2 = _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵgetCurrentView"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵelementContainerStart"](0);
    _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵelementStart"](1, "ion-col", 18);
    _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵtemplate"](2, TripDetailPage_ng_container_2_ion_row_20_ng_container_1_ng_container_2_Template, 4, 7, "ng-container", 3)(3, TripDetailPage_ng_container_2_ion_row_20_ng_container_1_ng_container_3_Template, 5, 6, "ng-container", 3)(4, TripDetailPage_ng_container_2_ion_row_20_ng_container_1_ng_container_4_Template, 5, 6, "ng-container", 3);
    _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵelementEnd"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵelementStart"](5, "ion-col", 19)(6, "ion-text");
    _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵtext"](7);
    _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵpipe"](8, "translate");
    _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵelementEnd"]()();
    _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵelementStart"](9, "ion-col", 20)(10, "ion-text", 21)(11, "a", 22);
    _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵlistener"]("click", function TripDetailPage_ng_container_2_ion_row_20_ng_container_1_Template_a_click_11_listener() {
      _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵrestoreView"](_r2);
      const campaign_r3 = _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵnextContext"]().$implicit;
      const ctx_r0 = _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵnextContext"](2);
      return _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵresetView"](ctx_r0.openCampaign(campaign_r3));
    });
    _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵtext"](12);
    _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵpipe"](13, "languageMap");
    _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵelementEnd"]()()();
    _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵelementContainerEnd"]();
  }
  if (rf & 2) {
    const campaign_r3 = _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵnextContext"]().$implicit;
    const ctx_r0 = _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵnextContext"](2);
    _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵadvance"](2);
    _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵproperty"]("ngIf", campaign_r3.type === "personal");
    _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵadvance"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵproperty"]("ngIf", campaign_r3.type === "company");
    _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵadvance"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵproperty"]("ngIf", campaign_r3.type === "school" || campaign_r3.type === "city");
    _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵadvance"](3);
    _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵtextInterpolate1"]("", _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵpipeBind1"](8, 6, "trip_detail.gl_for"), " ");
    _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵadvance"](3);
    _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵproperty"]("color", ctx_r0.campaignService.getCampaignColor(campaign_r3));
    _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵadvance"](2);
    _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵtextInterpolate"](_angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵpipeBind1"](13, 8, campaign_r3.campaignName));
  }
}
function TripDetailPage_ng_container_2_ion_row_20_Template(rf, ctx) {
  if (rf & 1) {
    _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵelementStart"](0, "ion-row", 17);
    _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵtemplate"](1, TripDetailPage_ng_container_2_ion_row_20_ng_container_1_Template, 14, 10, "ng-container", 3);
    _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵelementEnd"]();
  }
  if (rf & 2) {
    const campaign_r3 = ctx.$implicit;
    _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵadvance"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵproperty"]("ngIf", campaign_r3.valid);
  }
}
function TripDetailPage_ng_container_2_Template(rf, ctx) {
  if (rf & 1) {
    _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵelementContainerStart"](0);
    _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵtemplate"](1, TripDetailPage_ng_container_2_app_trip_detail_map_1_Template, 1, 3, "app-trip-detail-map", 4)(2, TripDetailPage_ng_container_2_ion_grid_2_Template, 7, 3, "ion-grid", 3);
    _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵelementStart"](3, "ion-card", 5)(4, "ion-grid")(5, "ion-row")(6, "ion-col", 6);
    _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵelement"](7, "app-icon", 7);
    _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵelementEnd"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵelementStart"](8, "ion-col", 8)(9, "ion-row", 9);
    _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵtext"](10);
    _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵpipe"](11, "translate");
    _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵelementEnd"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵelementStart"](12, "ion-row", 10);
    _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵtext"](13);
    _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵpipe"](14, "localDate");
    _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵelementEnd"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵelementStart"](15, "ion-row", 11);
    _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵtemplate"](16, TripDetailPage_ng_container_2_span_16_Template, 4, 8, "span", 12)(17, TripDetailPage_ng_container_2_ng_template_17_Template, 3, 3, "ng-template", null, 0, _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵtemplateRefExtractor"]);
    _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵelementEnd"]()()();
    _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵtemplate"](19, TripDetailPage_ng_container_2_ion_row_19_Template, 4, 3, "ion-row", 3)(20, TripDetailPage_ng_container_2_ion_row_20_Template, 2, 1, "ion-row", 13);
    _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵelementEnd"]()();
    _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵelementContainerEnd"]();
  }
  if (rf & 2) {
    const noDistance_r4 = _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵreference"](18);
    const ctx_r0 = _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵnextContext"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵadvance"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵproperty"]("ngIf", ctx_r0.showMap);
    _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵadvance"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵproperty"]("ngIf", !ctx_r0.showMap);
    _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵadvance"](5);
    _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵproperty"]("name", ctx_r0.getTransportTypeIcon(ctx_r0.tripDetail.modeType));
    _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵadvance"](3);
    _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵtextInterpolate"](_angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵpipeBind1"](11, 9, ctx_r0.getTransportTypeLabel(ctx_r0.tripDetail.modeType)));
    _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵadvance"](3);
    _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵtextInterpolate"](_angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵpipeBind2"](14, 11, ctx_r0.tripDetail.startTime, _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵpureFunction0"](14, _c0)));
    _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵadvance"](3);
    _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵproperty"]("ngIf", ctx_r0.tripDetail.distance)("ngIfElse", noDistance_r4);
    _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵadvance"](3);
    _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵproperty"]("ngIf", ctx_r0.campaigns.length === 0);
    _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵadvance"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵproperty"]("ngForOf", ctx_r0.campaigns);
  }
}
class TripDetailPage {
  constructor(route, router, errorService, trackApiService, campaignService, alertService) {
    this.route = route;
    this.router = router;
    this.errorService = errorService;
    this.trackApiService = trackApiService;
    this.campaignService = campaignService;
    this.alertService = alertService;
    this.tripDetail = {};
    this.campaigns = [];
    this.showMap = false;
    this.durationLabel = '';
    this.getTransportTypeIcon = src_app_core_shared_tracking_trip_model__WEBPACK_IMPORTED_MODULE_2__.getTransportTypeIcon;
    this.getTransportTypeLabel = src_app_core_shared_tracking_trip_model__WEBPACK_IMPORTED_MODULE_2__.getTransportTypeLabel;
    this.campaignAvailability = [];
  }
  ngOnInit() {
    var _this = this;
    return (0,_Users_smartcommunitylab_Desktop_newWork_playAndGo_playGo_node_modules_babel_runtime_helpers_esm_asyncToGenerator_js__WEBPACK_IMPORTED_MODULE_0__["default"])(function* () {
      const tripId = _this.route.snapshot.paramMap.get('id');
      _this.subCampaign = _this.campaignService.myCampaigns$.subscribe(campaigns => {
        _this.campaignAvailability = campaigns.map(campaignContainer => campaignContainer.campaign.campaignId);
      });
      try {
        _this.tripDetail = yield _this.getTripDetail(tripId);
        _this.showMap = Boolean(_this.tripDetail.polyline);
        _this.campaigns = _this.tripDetail.campaigns.filter(campaign => campaign.valid);
        _this.durationLabel = (0,src_app_core_shared_utils__WEBPACK_IMPORTED_MODULE_3__.formatDurationToHoursAndMinutes)(_this.tripDetail.endTime - _this.tripDetail.startTime);
      } catch (e) {
        _this.errorService.handleError(e);
      }
    })();
  }
  openCampaign(campaign) {
    //check if campaign is valid
    if (!this.campaignAvailability.includes(campaign.campaignId)) {
      return this.alertService.showToast({
        messageTranslateKey: 'campaigns.removed'
      });
    }
    this.router.navigateByUrl('/pages/tabs/trips/campaign-detail/' + campaign.campaignId);
  }
  getTripDetail(id) {
    var _this2 = this;
    return (0,_Users_smartcommunitylab_Desktop_newWork_playAndGo_playGo_node_modules_babel_runtime_helpers_esm_asyncToGenerator_js__WEBPACK_IMPORTED_MODULE_0__["default"])(function* () {
      return yield _this2.trackApiService.getTrackedInstanceInfoDetail(id);
    })();
  }
  getLabelObs(campaign) {
    return this.campaignService.myCampaigns$.pipe((0,rxjs__WEBPACK_IMPORTED_MODULE_1__.map)(campaigns => campaigns.find(campaignContainer => campaignContainer.campaign.campaignId === campaign.campaignId)?.campaign?.specificData?.virtualScore?.label));
  }
  static #_ = _staticBlock = () => (this.ɵfac = function TripDetailPage_Factory(__ngFactoryType__) {
    return new (__ngFactoryType__ || TripDetailPage)(_angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵdirectiveInject"](_angular_router__WEBPACK_IMPORTED_MODULE_6__.ActivatedRoute), _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵdirectiveInject"](_angular_router__WEBPACK_IMPORTED_MODULE_6__.Router), _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵdirectiveInject"](src_app_core_shared_services_error_service__WEBPACK_IMPORTED_MODULE_7__.ErrorService), _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵdirectiveInject"](src_app_core_shared_tracking_track_api_service__WEBPACK_IMPORTED_MODULE_8__.TrackApiService), _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵdirectiveInject"](src_app_core_shared_services_campaign_service__WEBPACK_IMPORTED_MODULE_9__.CampaignService), _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵdirectiveInject"](src_app_core_shared_services_alert_service__WEBPACK_IMPORTED_MODULE_10__.AlertService));
  }, this.ɵcmp = /*@__PURE__*/_angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵdefineComponent"]({
    type: TripDetailPage,
    selectors: [["app-trip-detail"]],
    standalone: false,
    decls: 3,
    vars: 1,
    consts: [["noDistance", ""], ["appHeader", ""], ["appContent", ""], [4, "ngIf"], [3, "tripParts", 4, "ngIf"], [1, "absolute-wrapper"], ["size", "3", 1, "ion-text-center"], [1, "big-icon", 3, "name"], ["size", "9"], [1, "mean-label"], [1, "mean-date"], [1, "mean-hour"], [4, "ngIf", "ngIfElse"], ["class", "campaigns-validation", 4, "ngFor", "ngForOf"], [3, "tripParts"], [1, "no-map"], [1, "no-score"], [1, "campaigns-validation"], ["size", "3", 1, "ion-text-right"], ["size", "auto"], [1, "ellipsis"], [3, "color"], ["routerDirection", "forward", 1, "inherit-color", "underline", 3, "click"], [3, "color", "name"]],
    template: function TripDetailPage_Template(rf, ctx) {
      if (rf & 1) {
        _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵelement"](0, "ion-header", 1);
        _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵelementStart"](1, "ion-content", 2);
        _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵtemplate"](2, TripDetailPage_ng_container_2_Template, 21, 15, "ng-container", 3);
        _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵelementEnd"]();
      }
      if (rf & 2) {
        _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵadvance"](2);
        _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵproperty"]("ngIf", ctx.tripDetail);
      }
    },
    dependencies: [_angular_common__WEBPACK_IMPORTED_MODULE_11__.NgForOf, _angular_common__WEBPACK_IMPORTED_MODULE_11__.NgIf, _ionic_angular__WEBPACK_IMPORTED_MODULE_12__.IonCard, _ionic_angular__WEBPACK_IMPORTED_MODULE_12__.IonCol, _ionic_angular__WEBPACK_IMPORTED_MODULE_12__.IonContent, _ionic_angular__WEBPACK_IMPORTED_MODULE_12__.IonGrid, _ionic_angular__WEBPACK_IMPORTED_MODULE_12__.IonHeader, _ionic_angular__WEBPACK_IMPORTED_MODULE_12__.IonRow, _ionic_angular__WEBPACK_IMPORTED_MODULE_12__.IonText, _core_shared_layout_header_header_directive__WEBPACK_IMPORTED_MODULE_13__.HeaderDirective, _core_shared_layout_content_content_directive__WEBPACK_IMPORTED_MODULE_14__.ContentDirective, _core_shared_ui_icon_icon_component__WEBPACK_IMPORTED_MODULE_15__.IconComponent, _trip_detail_map_trip_detail_map_component__WEBPACK_IMPORTED_MODULE_16__.TripDetailMapComponent, _ngx_translate_core__WEBPACK_IMPORTED_MODULE_17__.TranslatePipe, _core_shared_pipes_localDate_pipe__WEBPACK_IMPORTED_MODULE_18__.LocalDatePipe, _core_shared_pipes_languageMap_pipe__WEBPACK_IMPORTED_MODULE_19__.LanguageMapPipe, _core_shared_pipes_localNumber_pipe__WEBPACK_IMPORTED_MODULE_20__.LocalNumberPipe],
    styles: ["[_nghost-%COMP%] {\n  height: 100%;\n}\n\nion-grid[_ngcontent-%COMP%] {\n  color: var(--dark-grey);\n}\n\n.inherit-color[_ngcontent-%COMP%] {\n  color: inherit !important;\n}\n\n.big-icon[_ngcontent-%COMP%] {\n  font-size: 64px;\n}\n\n.underline[_ngcontent-%COMP%] {\n  text-decoration: underline;\n  cursor: pointer;\n}\n\n.absolute-wrapper[_ngcontent-%COMP%] {\n  font-size: 18px;\n  position: absolute;\n  bottom: 1em;\n  z-index: 1000;\n  right: 0;\n  left: 0;\n}\n.absolute-wrapper[_ngcontent-%COMP%]   ion-row[_ngcontent-%COMP%] {\n  display: flex;\n  align-items: center !important;\n}\n.absolute-wrapper[_ngcontent-%COMP%]   ion-row[_ngcontent-%COMP%]   .mean-label[_ngcontent-%COMP%] {\n  font-weight: 500;\n  font-size: 17px;\n  line-height: 25px;\n}\n.absolute-wrapper[_ngcontent-%COMP%]   ion-row[_ngcontent-%COMP%]   .mean-date[_ngcontent-%COMP%] {\n  font-weight: 500;\n  font-size: 14px;\n  line-height: 25px;\n}\n.absolute-wrapper[_ngcontent-%COMP%]   ion-row[_ngcontent-%COMP%]   .mean-hour[_ngcontent-%COMP%] {\n  font-weight: 500;\n  font-size: 14px;\n  line-height: 25px;\n}\n.absolute-wrapper[_ngcontent-%COMP%]   ion-row[_ngcontent-%COMP%]   .no-score[_ngcontent-%COMP%] {\n  margin: 8px;\n}\n\n.ellipsis[_ngcontent-%COMP%] {\n  overflow: hidden;\n  text-overflow: ellipsis;\n  white-space: nowrap;\n}\n\n.campaigns-validation[_ngcontent-%COMP%]    > ion-col[_ngcontent-%COMP%] {\n  display: flex;\n  align-items: center;\n}\n\n.campaigns-validation[_ngcontent-%COMP%]    > ion-col[_ngcontent-%COMP%]:first-child {\n  flex-direction: row-reverse;\n}\n\n.no-map[_ngcontent-%COMP%] {\n  margin: auto;\n  padding: 8px;\n  font-size: 16px;\n  text-align: center;\n}\n/*# sourceMappingURL=data:application/json;charset=utf-8;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbIndlYnBhY2s6Ly8uL3NyYy9hcHAvcGFnZXMvdHJpcHMvdHJpcC1kZXRhaWwvdHJpcC1kZXRhaWwucGFnZS5zY3NzIl0sIm5hbWVzIjpbXSwibWFwcGluZ3MiOiJBQUFBO0VBQ0UsWUFBQTtBQUNGOztBQUNBO0VBQ0UsdUJBQUE7QUFFRjs7QUFBQTtFQUNFLHlCQUFBO0FBR0Y7O0FBREE7RUFDRSxlQUFBO0FBSUY7O0FBRkE7RUFDRSwwQkFBQTtFQUNBLGVBQUE7QUFLRjs7QUFIQTtFQUNFLGVBQUE7RUFDQSxrQkFBQTtFQUNBLFdBQUE7RUFDQSxhQUFBO0VBQ0EsUUFBQTtFQUNBLE9BQUE7QUFNRjtBQUxFO0VBQ0UsYUFBQTtFQUNBLDhCQUFBO0FBT0o7QUFOSTtFQUNFLGdCQUFBO0VBQ0EsZUFBQTtFQUNBLGlCQUFBO0FBUU47QUFOSTtFQUNFLGdCQUFBO0VBQ0EsZUFBQTtFQUNBLGlCQUFBO0FBUU47QUFOSTtFQUNFLGdCQUFBO0VBQ0EsZUFBQTtFQUNBLGlCQUFBO0FBUU47QUFOSTtFQUNFLFdBQUE7QUFRTjs7QUFKQTtFQUNFLGdCQUFBO0VBQ0EsdUJBQUE7RUFDQSxtQkFBQTtBQU9GOztBQUpBO0VBQ0UsYUFBQTtFQUNBLG1CQUFBO0FBT0Y7O0FBTEE7RUFDRSwyQkFBQTtBQVFGOztBQU5BO0VBQ0UsWUFBQTtFQUNBLFlBQUE7RUFDQSxlQUFBO0VBQ0Esa0JBQUE7QUFTRiIsInNvdXJjZXNDb250ZW50IjpbIjpob3N0IHtcbiAgaGVpZ2h0OiAxMDAlO1xufVxuaW9uLWdyaWQge1xuICBjb2xvcjogdmFyKC0tZGFyay1ncmV5KTtcbn1cbi5pbmhlcml0LWNvbG9yIHtcbiAgY29sb3I6IGluaGVyaXQgIWltcG9ydGFudDtcbn1cbi5iaWctaWNvbiB7XG4gIGZvbnQtc2l6ZTogNjRweDtcbn1cbi51bmRlcmxpbmUge1xuICB0ZXh0LWRlY29yYXRpb246IHVuZGVybGluZTtcbiAgY3Vyc29yOiBwb2ludGVyO1xufVxuLmFic29sdXRlLXdyYXBwZXIge1xuICBmb250LXNpemU6IDE4cHg7XG4gIHBvc2l0aW9uOiBhYnNvbHV0ZTtcbiAgYm90dG9tOiAxZW07XG4gIHotaW5kZXg6IDEwMDA7XG4gIHJpZ2h0OiAwO1xuICBsZWZ0OiAwO1xuICBpb24tcm93IHtcbiAgICBkaXNwbGF5OiBmbGV4O1xuICAgIGFsaWduLWl0ZW1zOiBjZW50ZXIgIWltcG9ydGFudDtcbiAgICAubWVhbi1sYWJlbCB7XG4gICAgICBmb250LXdlaWdodDogNTAwO1xuICAgICAgZm9udC1zaXplOiAxN3B4O1xuICAgICAgbGluZS1oZWlnaHQ6IDI1cHg7XG4gICAgfVxuICAgIC5tZWFuLWRhdGUge1xuICAgICAgZm9udC13ZWlnaHQ6IDUwMDtcbiAgICAgIGZvbnQtc2l6ZTogMTRweDtcbiAgICAgIGxpbmUtaGVpZ2h0OiAyNXB4O1xuICAgIH1cbiAgICAubWVhbi1ob3VyIHtcbiAgICAgIGZvbnQtd2VpZ2h0OiA1MDA7XG4gICAgICBmb250LXNpemU6IDE0cHg7XG4gICAgICBsaW5lLWhlaWdodDogMjVweDtcbiAgICB9XG4gICAgLm5vLXNjb3JlIHtcbiAgICAgIG1hcmdpbjogOHB4O1xuICAgIH1cbiAgfVxufVxuLmVsbGlwc2lzIHtcbiAgb3ZlcmZsb3c6IGhpZGRlbjtcbiAgdGV4dC1vdmVyZmxvdzogZWxsaXBzaXM7XG4gIHdoaXRlLXNwYWNlOiBub3dyYXA7XG59XG5cbi5jYW1wYWlnbnMtdmFsaWRhdGlvbiA+IGlvbi1jb2wge1xuICBkaXNwbGF5OiBmbGV4O1xuICBhbGlnbi1pdGVtczogY2VudGVyO1xufVxuLmNhbXBhaWducy12YWxpZGF0aW9uID4gaW9uLWNvbDpmaXJzdC1jaGlsZCB7XG4gIGZsZXgtZGlyZWN0aW9uOiByb3ctcmV2ZXJzZTtcbn1cbi5uby1tYXAge1xuICBtYXJnaW46IGF1dG87XG4gIHBhZGRpbmc6IDhweDtcbiAgZm9udC1zaXplOiAxNnB4O1xuICB0ZXh0LWFsaWduOiBjZW50ZXI7XG59XG4iXSwic291cmNlUm9vdCI6IiJ9 */"]
  }));
}
_staticBlock();

/***/ })

}]);
//# sourceMappingURL=src_app_pages_trips_trip-detail_trip-detail_module_ts.js.map