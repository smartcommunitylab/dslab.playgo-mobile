(self["webpackChunkapp"] = self["webpackChunkapp"] || []).push([["main"],{

/***/ 583:
/*!********************************************************************!*\
  !*** ./src/app/core/shared/directives/enter-viewport.directive.ts ***!
  \********************************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   EnterTheViewportNotifierDirective: () => (/* binding */ EnterTheViewportNotifierDirective)
/* harmony export */ });
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! @angular/core */ 12481);
var _staticBlock;


class EnterTheViewportNotifierDirective {
  constructor(elementRef) {
    this.elementRef = elementRef;
    this.visibilityChange = new _angular_core__WEBPACK_IMPORTED_MODULE_0__.EventEmitter();
    this.callback = (entries, observer) => {
      entries.forEach(entry => {
        //   console.log(entry.isIntersecting ? 'I am visible' : 'I am not visible');
        this.visibilityChange.emit(entry.isIntersecting ? 'VISIBLE' : 'HIDDEN');
        // Each entry describes an intersection change for one observed
        // target element:
        //   entry.boundingClientRect
        //   entry.intersectionRatio
        //   entry.intersectionRect
        //   entry.isIntersecting
        //   entry.rootBounds
        //   entry.target
        //   entry.time
      });
    };
  }
  ngAfterViewInit() {
    const options = {
      root: document.querySelector('#element'),
      rootMargin: '0px',
      threshold: 0.0
    };
    this.observer = new IntersectionObserver(this.callback, options);
    this.observer.observe(this.elementRef.nativeElement);
  }
  ngOnDestroy() {
    this.observer.disconnect();
  }
  static #_ = _staticBlock = () => (this.ɵfac = function EnterTheViewportNotifierDirective_Factory(__ngFactoryType__) {
    return new (__ngFactoryType__ || EnterTheViewportNotifierDirective)(_angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵdirectiveInject"](_angular_core__WEBPACK_IMPORTED_MODULE_0__.ElementRef, 1));
  }, this.ɵdir = /*@__PURE__*/_angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵdefineDirective"]({
    type: EnterTheViewportNotifierDirective,
    selectors: [["", "enterTheViewportNotifier", ""]],
    outputs: {
      visibilityChange: "visibilityChange"
    },
    standalone: false
  }));
}
_staticBlock();

/***/ }),

/***/ 666:
/*!**************************************************************************!*\
  !*** ./src/app/core/shared/infinite-scroll/infinite-scroll.component.ts ***!
  \**************************************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   InfiniteScrollComponent: () => (/* binding */ InfiniteScrollComponent),
/* harmony export */   InfiniteScrollContentDirective: () => (/* binding */ InfiniteScrollContentDirective),
/* harmony export */   isPageableErrorResponse: () => (/* binding */ isPageableErrorResponse),
/* harmony export */   isPageableSuccessResponse: () => (/* binding */ isPageableSuccessResponse)
/* harmony export */ });
/* harmony import */ var _Users_smartcommunitylab_Desktop_newWork_playAndGo_playGo_node_modules_babel_runtime_helpers_esm_asyncToGenerator_js__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./node_modules/@babel/runtime/helpers/esm/asyncToGenerator.js */ 89204);
/* harmony import */ var _ionic_angular__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @ionic/angular */ 21507);
/* harmony import */ var lodash_es__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! lodash-es */ 1261);
/* harmony import */ var lodash_es__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! lodash-es */ 65206);
/* harmony import */ var rxjs__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! rxjs */ 10819);
/* harmony import */ var rxjs__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! rxjs */ 63617);
/* harmony import */ var rxjs__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! rxjs */ 59400);
/* harmony import */ var rxjs_operators__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(/*! rxjs/operators */ 51567);
/* harmony import */ var rxjs_operators__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(/*! rxjs/operators */ 2435);
/* harmony import */ var rxjs_operators__WEBPACK_IMPORTED_MODULE_9__ = __webpack_require__(/*! rxjs/operators */ 70271);
/* harmony import */ var rxjs_operators__WEBPACK_IMPORTED_MODULE_10__ = __webpack_require__(/*! rxjs/operators */ 32112);
/* harmony import */ var rxjs_operators__WEBPACK_IMPORTED_MODULE_11__ = __webpack_require__(/*! rxjs/operators */ 63037);
/* harmony import */ var rxjs_operators__WEBPACK_IMPORTED_MODULE_12__ = __webpack_require__(/*! rxjs/operators */ 36647);
/* harmony import */ var rxjs_operators__WEBPACK_IMPORTED_MODULE_13__ = __webpack_require__(/*! rxjs/operators */ 15842);
/* harmony import */ var _rxjs_utils__WEBPACK_IMPORTED_MODULE_14__ = __webpack_require__(/*! ../rxjs.utils */ 86040);
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_15__ = __webpack_require__(/*! @angular/core */ 34205);
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_16__ = __webpack_require__(/*! @angular/core */ 12481);
/* harmony import */ var _angular_common__WEBPACK_IMPORTED_MODULE_17__ = __webpack_require__(/*! @angular/common */ 93683);

var _staticBlock, _staticBlock2;








const _c0 = ["infiniteScroll"];
const _c1 = ["*"];
const _c2 = a0 => ({
  item: a0
});
const _c3 = a0 => ({
  items: a0
});
function InfiniteScrollComponent_ng_container_2_ng_container_1_Template(rf, ctx) {
  if (rf & 1) {
    _angular_core__WEBPACK_IMPORTED_MODULE_16__["ɵɵelementContainerStart"](0);
    _angular_core__WEBPACK_IMPORTED_MODULE_16__["ɵɵelementContainer"](1, 5);
    _angular_core__WEBPACK_IMPORTED_MODULE_16__["ɵɵelementContainerEnd"]();
  }
  if (rf & 2) {
    const item_r2 = ctx.$implicit;
    const ctx_r2 = _angular_core__WEBPACK_IMPORTED_MODULE_16__["ɵɵnextContext"](2);
    _angular_core__WEBPACK_IMPORTED_MODULE_16__["ɵɵadvance"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_16__["ɵɵproperty"]("ngTemplateOutlet", ctx_r2.content.templateRef)("ngTemplateOutletContext", _angular_core__WEBPACK_IMPORTED_MODULE_16__["ɵɵpureFunction1"](2, _c2, item_r2));
  }
}
function InfiniteScrollComponent_ng_container_2_Template(rf, ctx) {
  if (rf & 1) {
    _angular_core__WEBPACK_IMPORTED_MODULE_16__["ɵɵelementContainerStart"](0);
    _angular_core__WEBPACK_IMPORTED_MODULE_16__["ɵɵtemplate"](1, InfiniteScrollComponent_ng_container_2_ng_container_1_Template, 2, 4, "ng-container", 4);
    _angular_core__WEBPACK_IMPORTED_MODULE_16__["ɵɵpipe"](2, "async");
    _angular_core__WEBPACK_IMPORTED_MODULE_16__["ɵɵelementContainerEnd"]();
  }
  if (rf & 2) {
    const ctx_r2 = _angular_core__WEBPACK_IMPORTED_MODULE_16__["ɵɵnextContext"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_16__["ɵɵadvance"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_16__["ɵɵproperty"]("ngForOf", _angular_core__WEBPACK_IMPORTED_MODULE_16__["ɵɵpipeBind1"](2, 1, ctx_r2.items$));
  }
}
function InfiniteScrollComponent_ng_container_3_Template(rf, ctx) {
  if (rf & 1) {
    _angular_core__WEBPACK_IMPORTED_MODULE_16__["ɵɵelementContainerStart"](0);
    _angular_core__WEBPACK_IMPORTED_MODULE_16__["ɵɵelementContainer"](1, 5);
    _angular_core__WEBPACK_IMPORTED_MODULE_16__["ɵɵpipe"](2, "async");
    _angular_core__WEBPACK_IMPORTED_MODULE_16__["ɵɵelementContainerEnd"]();
  }
  if (rf & 2) {
    const ctx_r2 = _angular_core__WEBPACK_IMPORTED_MODULE_16__["ɵɵnextContext"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_16__["ɵɵadvance"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_16__["ɵɵproperty"]("ngTemplateOutlet", ctx_r2.content.templateRef)("ngTemplateOutletContext", _angular_core__WEBPACK_IMPORTED_MODULE_16__["ɵɵpureFunction1"](4, _c3, _angular_core__WEBPACK_IMPORTED_MODULE_16__["ɵɵpipeBind1"](2, 2, ctx_r2.items$)));
  }
}
class InfiniteScrollContentDirective {
  constructor(templateRef) {
    this.templateRef = templateRef;
  }
  static #_ = _staticBlock = () => (this.ɵfac = function InfiniteScrollContentDirective_Factory(__ngFactoryType__) {
    return new (__ngFactoryType__ || InfiniteScrollContentDirective)(_angular_core__WEBPACK_IMPORTED_MODULE_16__["ɵɵdirectiveInject"](_angular_core__WEBPACK_IMPORTED_MODULE_16__.TemplateRef));
  }, this.ɵdir = /*@__PURE__*/_angular_core__WEBPACK_IMPORTED_MODULE_16__["ɵɵdefineDirective"]({
    type: InfiniteScrollContentDirective,
    selectors: [["", "appInfiniteScrollContent", ""]],
    standalone: false
  }));
}
_staticBlock();
class InfiniteScrollComponent {
  set response(response) {
    if (!(0,lodash_es__WEBPACK_IMPORTED_MODULE_2__["default"])(response)) {
      this.response$.next(response);
    }
    if (this.infiniteScrollComponent) {
      this.infiniteScrollComponent.complete();
    }
  }
  set resetItems(resetItems) {
    this.resetItems$.next();
  }
  constructor(ionContentElement) {
    var _this = this;
    this.ionContentElement = ionContentElement;
    this.allItemsInTemplate = false;
    this.response$ = new rxjs__WEBPACK_IMPORTED_MODULE_4__.Subject();
    this.successResponse$ = this.response$.pipe((0,rxjs_operators__WEBPACK_IMPORTED_MODULE_7__.filter)(isPageableSuccessResponse));
    this.resetItems$ = new rxjs__WEBPACK_IMPORTED_MODULE_4__.Subject();
    this.loadDataEvents$ = new rxjs__WEBPACK_IMPORTED_MODULE_4__.Subject();
    this.afterViewChecked = new rxjs__WEBPACK_IMPORTED_MODULE_4__.Subject();
    this.manualLoadWithNoScroll$ = this.response$.pipe((0,rxjs_operators__WEBPACK_IMPORTED_MODULE_12__.switchMap)(response => {
      if (!response || isPageableErrorResponse(response)) {
        return rxjs__WEBPACK_IMPORTED_MODULE_6__.EMPTY;
      }
      const page = response.number + 1;
      const notAllDataIsLoaded = page < response.totalPages;
      return this.afterViewChecked.pipe((0,rxjs_operators__WEBPACK_IMPORTED_MODULE_8__.first)(), (0,_rxjs_utils__WEBPACK_IMPORTED_MODULE_14__.asyncFilter)(/*#__PURE__*/(0,_Users_smartcommunitylab_Desktop_newWork_playAndGo_playGo_node_modules_babel_runtime_helpers_esm_asyncToGenerator_js__WEBPACK_IMPORTED_MODULE_0__["default"])(function* () {
        const noScroll = (yield _this.hasScroll()) === false;
        const shouldForceLoad = notAllDataIsLoaded && noScroll;
        return shouldForceLoad;
      })));
    }), (0,_rxjs_utils__WEBPACK_IMPORTED_MODULE_14__.tapLog)('Manually forced load of next page, because there is no scroll to trigger it'));
    this.request = (0,rxjs__WEBPACK_IMPORTED_MODULE_5__.merge)(this.loadDataEvents$, this.manualLoadWithNoScroll$).pipe((0,rxjs_operators__WEBPACK_IMPORTED_MODULE_13__.withLatestFrom)(this.successResponse$), (0,rxjs_operators__WEBPACK_IMPORTED_MODULE_9__.map)(([, response]) => {
      const page = response.number + 1;
      const size = response.size;
      if (page >= response.totalPages) {
        this.infiniteScrollComponent.disabled = true;
        return null;
      }
      this.infiniteScrollComponent.disabled = false;
      return {
        page,
        size
      };
    }), (0,rxjs_operators__WEBPACK_IMPORTED_MODULE_7__.filter)(request => request !== null));
    this.items$ = this.resetItems$.pipe((0,rxjs_operators__WEBPACK_IMPORTED_MODULE_11__.startWith)(undefined), (0,rxjs_operators__WEBPACK_IMPORTED_MODULE_12__.switchMap)(() => this.successResponse$.pipe((0,rxjs_operators__WEBPACK_IMPORTED_MODULE_7__.filter)((0,lodash_es__WEBPACK_IMPORTED_MODULE_3__["default"])(lodash_es__WEBPACK_IMPORTED_MODULE_2__["default"])), (0,rxjs_operators__WEBPACK_IMPORTED_MODULE_9__.map)(response => response.content), (0,rxjs_operators__WEBPACK_IMPORTED_MODULE_10__.scan)((acc, curr) => [...acc, ...curr], []), (0,rxjs_operators__WEBPACK_IMPORTED_MODULE_11__.startWith)([]))));
    /** For manual rendering */
    this.items = this.items$;
  }
  loadData(event) {
    this.loadDataEvents$.next();
  }
  ngOnInit() {}
  ngAfterViewChecked() {
    this.afterViewChecked.next();
  }
  hasScroll() {
    var _this2 = this;
    return (0,_Users_smartcommunitylab_Desktop_newWork_playAndGo_playGo_node_modules_babel_runtime_helpers_esm_asyncToGenerator_js__WEBPACK_IMPORTED_MODULE_0__["default"])(function* () {
      if (!_this2.ionContentElement) {
        return null;
      }
      const scrollElement = yield _this2.ionContentElement.getScrollElement();
      if (!scrollElement) {
        return null;
      }
      return scrollElement.scrollHeight > scrollElement.clientHeight;
    })();
  }
  static #_ = _staticBlock2 = () => (this.ɵfac = function InfiniteScrollComponent_Factory(__ngFactoryType__) {
    return new (__ngFactoryType__ || InfiniteScrollComponent)(_angular_core__WEBPACK_IMPORTED_MODULE_16__["ɵɵdirectiveInject"](_ionic_angular__WEBPACK_IMPORTED_MODULE_1__.IonContent, 8));
  }, this.ɵcmp = /*@__PURE__*/_angular_core__WEBPACK_IMPORTED_MODULE_16__["ɵɵdefineComponent"]({
    type: InfiniteScrollComponent,
    selectors: [["app-infinite-scroll"]],
    contentQueries: function InfiniteScrollComponent_ContentQueries(rf, ctx, dirIndex) {
      if (rf & 1) {
        _angular_core__WEBPACK_IMPORTED_MODULE_16__["ɵɵcontentQuery"](dirIndex, InfiniteScrollContentDirective, 5);
      }
      if (rf & 2) {
        let _t;
        _angular_core__WEBPACK_IMPORTED_MODULE_16__["ɵɵqueryRefresh"](_t = _angular_core__WEBPACK_IMPORTED_MODULE_16__["ɵɵloadQuery"]()) && (ctx.content = _t.first);
      }
    },
    viewQuery: function InfiniteScrollComponent_Query(rf, ctx) {
      if (rf & 1) {
        _angular_core__WEBPACK_IMPORTED_MODULE_16__["ɵɵviewQuery"](_c0, 5);
      }
      if (rf & 2) {
        let _t;
        _angular_core__WEBPACK_IMPORTED_MODULE_16__["ɵɵqueryRefresh"](_t = _angular_core__WEBPACK_IMPORTED_MODULE_16__["ɵɵloadQuery"]()) && (ctx.infiniteScrollComponent = _t.first);
      }
    },
    inputs: {
      allItemsInTemplate: "allItemsInTemplate",
      response: "response",
      resetItems: "resetItems"
    },
    outputs: {
      request: "request",
      items: "items"
    },
    standalone: false,
    ngContentSelectors: _c1,
    decls: 7,
    vars: 2,
    consts: [["infiniteScroll", ""], [4, "ngIf"], ["threshold", "100px", 3, "ionInfinite"], ["loadingSpinner", "bubbles", "loadingText", "Loading more data..."], [4, "ngFor", "ngForOf"], [3, "ngTemplateOutlet", "ngTemplateOutletContext"]],
    template: function InfiniteScrollComponent_Template(rf, ctx) {
      if (rf & 1) {
        const _r1 = _angular_core__WEBPACK_IMPORTED_MODULE_16__["ɵɵgetCurrentView"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_16__["ɵɵprojectionDef"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_16__["ɵɵelementStart"](0, "div");
        _angular_core__WEBPACK_IMPORTED_MODULE_16__["ɵɵprojection"](1);
        _angular_core__WEBPACK_IMPORTED_MODULE_16__["ɵɵtemplate"](2, InfiniteScrollComponent_ng_container_2_Template, 3, 3, "ng-container", 1)(3, InfiniteScrollComponent_ng_container_3_Template, 3, 6, "ng-container", 1);
        _angular_core__WEBPACK_IMPORTED_MODULE_16__["ɵɵelementStart"](4, "ion-infinite-scroll", 2, 0);
        _angular_core__WEBPACK_IMPORTED_MODULE_16__["ɵɵlistener"]("ionInfinite", function InfiniteScrollComponent_Template_ion_infinite_scroll_ionInfinite_4_listener($event) {
          _angular_core__WEBPACK_IMPORTED_MODULE_15__["ɵɵrestoreView"](_r1);
          return _angular_core__WEBPACK_IMPORTED_MODULE_15__["ɵɵresetView"](ctx.loadData($event));
        });
        _angular_core__WEBPACK_IMPORTED_MODULE_16__["ɵɵelement"](6, "ion-infinite-scroll-content", 3);
        _angular_core__WEBPACK_IMPORTED_MODULE_16__["ɵɵelementEnd"]()();
      }
      if (rf & 2) {
        _angular_core__WEBPACK_IMPORTED_MODULE_16__["ɵɵadvance"](2);
        _angular_core__WEBPACK_IMPORTED_MODULE_16__["ɵɵproperty"]("ngIf", ctx.allItemsInTemplate === false);
        _angular_core__WEBPACK_IMPORTED_MODULE_16__["ɵɵadvance"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_16__["ɵɵproperty"]("ngIf", ctx.allItemsInTemplate === true);
      }
    },
    dependencies: [_angular_common__WEBPACK_IMPORTED_MODULE_17__.NgForOf, _angular_common__WEBPACK_IMPORTED_MODULE_17__.NgIf, _angular_common__WEBPACK_IMPORTED_MODULE_17__.NgTemplateOutlet, _ionic_angular__WEBPACK_IMPORTED_MODULE_1__.IonInfiniteScroll, _ionic_angular__WEBPACK_IMPORTED_MODULE_1__.IonInfiniteScrollContent, _angular_common__WEBPACK_IMPORTED_MODULE_17__.AsyncPipe],
    styles: ["/*# sourceMappingURL=data:application/json;charset=utf-8;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbXSwibmFtZXMiOltdLCJtYXBwaW5ncyI6IiIsInNvdXJjZVJvb3QiOiIifQ== */"]
  }));
}
_staticBlock2();
function isPageableErrorResponse(response) {
  return response.error !== undefined;
}
function isPageableSuccessResponse(response) {
  return !isPageableErrorResponse(response);
}

/***/ }),

/***/ 1146:
/*!*******************************************************************************************************************************************!*\
  !*** ./src/app/core/shared/campaigns/home-widget-types/home-campaign-school/home-school-progression/comparison-modal/comparison.modal.ts ***!
  \*******************************************************************************************************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   ComparisonModalPage: () => (/* binding */ ComparisonModalPage)
/* harmony export */ });
/* harmony import */ var luxon__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! luxon */ 45967);
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @angular/core */ 34205);
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @angular/core */ 12481);
/* harmony import */ var _ionic_angular__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @ionic/angular */ 21507);
/* harmony import */ var _angular_common__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! @angular/common */ 93683);
/* harmony import */ var _ui_icon_icon_component__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! ../../../../../ui/icon/icon.component */ 59621);
/* harmony import */ var _ngx_translate_core__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! @ngx-translate/core */ 48503);
/* harmony import */ var _pipes_localDate_pipe__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(/*! ../../../../../pipes/localDate.pipe */ 86451);
/* harmony import */ var _pipes_localNumber_pipe__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(/*! ../../../../../pipes/localNumber.pipe */ 16024);
/* harmony import */ var _pipes_SafeHtml_pipe__WEBPACK_IMPORTED_MODULE_9__ = __webpack_require__(/*! ../../../../../pipes/SafeHtml.pipe */ 30052);
var _staticBlock;









const _c0 = (a0, a1) => ({
  dateFrom: a0,
  dateTo: a1
});
function ComparisonModalPage_div_4_Template(rf, ctx) {
  if (rf & 1) {
    _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵelementStart"](0, "div");
    _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵelement"](1, "div", 6);
    _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵpipe"](2, "localDate");
    _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵpipe"](3, "localDate");
    _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵpipe"](4, "translate");
    _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵpipe"](5, "safeHtml");
    _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵelementStart"](6, "div", 7);
    _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵtext"](7);
    _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵpipe"](8, "translate");
    _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵelementStart"](9, "div");
    _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵtext"](10);
    _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵpipe"](11, "localNumber");
    _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵelement"](12, "app-icon", 8);
    _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵelementEnd"]()();
    _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵelementStart"](13, "div", 7);
    _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵtext"](14);
    _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵpipe"](15, "translate");
    _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵelementStart"](16, "div");
    _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵtext"](17);
    _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵpipe"](18, "localNumber");
    _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵelement"](19, "app-icon", 8);
    _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵelementEnd"]()();
    _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵelementStart"](20, "div", 7);
    _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵtext"](21);
    _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵpipe"](22, "translate");
    _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵelementStart"](23, "div");
    _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵtext"](24);
    _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵpipe"](25, "localNumber");
    _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵelement"](26, "app-icon", 8);
    _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵelementEnd"]()();
    _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵelement"](27, "div", 9);
    _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵpipe"](28, "translate");
    _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵelementEnd"]();
  }
  if (rf & 2) {
    const ctx_r1 = _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵnextContext"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵadvance"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵproperty"]("innerHTML", _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵpipeBind1"](5, 15, _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵpipeBind2"](4, 12, "campaigns.detail.modalTeam", _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵpureFunction2"](34, _c0, _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵpipeBind1"](2, 8, ctx_r1.referenceDate.startOf("week")), _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵpipeBind1"](3, 10, ctx_r1.referenceDate.endOf("week"))))), _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵsanitizeHtml"]);
    _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵadvance"](6);
    _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵtextInterpolate1"]("", _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵpipeBind1"](8, 17, "campaigns.detail.modalBestTeam"), " ");
    _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵadvance"](3);
    _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵtextInterpolate"](_angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵpipeBind2"](11, 19, ctx_r1.stat.max, "0.0-1"));
    _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵadvance"](4);
    _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵtextInterpolate1"]("", _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵpipeBind1"](15, 22, "campaigns.detail.modalActualTeam"), " ");
    _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵadvance"](3);
    _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵtextInterpolate"](ctx_r1.stat.value === 0 ? "- " : _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵpipeBind2"](18, 24, ctx_r1.stat.value, "0.0-1"));
    _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵadvance"](4);
    _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵtextInterpolate"](_angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵpipeBind1"](22, 27, "campaigns.detail.modalMinTeam"));
    _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵadvance"](3);
    _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵtextInterpolate1"]("", _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵpipeBind2"](25, 29, ctx_r1.stat.min, "0.0-1"), " ");
    _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵadvance"](3);
    _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵproperty"]("innerHTML", _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵpipeBind1"](28, 32, "campaigns.detail.modalTeamValid"), _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵsanitizeHtml"]);
  }
}
function ComparisonModalPage_ng_template_5_Template(rf, ctx) {
  if (rf & 1) {
    _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵelementStart"](0, "div");
    _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵelement"](1, "div", 6);
    _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵpipe"](2, "localDate");
    _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵpipe"](3, "localDate");
    _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵpipe"](4, "translate");
    _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵpipe"](5, "safeHtml");
    _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵelementStart"](6, "div", 7);
    _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵtext"](7);
    _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵpipe"](8, "translate");
    _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵelementStart"](9, "div");
    _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵtext"](10);
    _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵpipe"](11, "localNumber");
    _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵelement"](12, "app-icon", 8);
    _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵelementEnd"]()();
    _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵelementStart"](13, "div", 7);
    _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵtext"](14);
    _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵpipe"](15, "translate");
    _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵelementStart"](16, "div");
    _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵtext"](17);
    _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵpipe"](18, "localNumber");
    _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵelement"](19, "app-icon", 8);
    _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵelementEnd"]()();
    _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵelementStart"](20, "div", 7);
    _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵtext"](21);
    _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵpipe"](22, "translate");
    _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵelementStart"](23, "div");
    _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵtext"](24);
    _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵpipe"](25, "localNumber");
    _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵelement"](26, "app-icon", 8);
    _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵelementEnd"]()();
    _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵelement"](27, "div", 9);
    _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵpipe"](28, "translate");
    _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵelementEnd"]();
  }
  if (rf & 2) {
    const ctx_r1 = _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵnextContext"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵadvance"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵproperty"]("innerHTML", _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵpipeBind1"](5, 15, _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵpipeBind2"](4, 12, "campaigns.detail.modalPersonal", _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵpureFunction2"](34, _c0, _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵpipeBind1"](2, 8, ctx_r1.referenceDate.startOf("week")), _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵpipeBind1"](3, 10, ctx_r1.referenceDate.endOf("week"))))), _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵsanitizeHtml"]);
    _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵadvance"](6);
    _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵtextInterpolate"](_angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵpipeBind1"](8, 17, "campaigns.detail.modalBestPersonal"));
    _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵadvance"](3);
    _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵtextInterpolate1"]("", _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵpipeBind2"](11, 19, ctx_r1.stat.max, "0.0-1"), " ");
    _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵadvance"](4);
    _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵtextInterpolate1"]("", _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵpipeBind1"](15, 22, "campaigns.detail.modalActualPersonal"), " ");
    _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵadvance"](3);
    _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵtextInterpolate"](ctx_r1.stat.value === 0 ? "- " : _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵpipeBind2"](18, 24, ctx_r1.stat.value, "0.0-1"));
    _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵadvance"](4);
    _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵtextInterpolate1"]("", _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵpipeBind1"](22, 27, "campaigns.detail.modalMinPersonal"), " ");
    _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵadvance"](3);
    _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵtextInterpolate"](_angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵpipeBind2"](25, 29, ctx_r1.stat.min, "0.0-1"));
    _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵadvance"](3);
    _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵproperty"]("innerHTML", _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵpipeBind1"](28, 32, "campaigns.detail.modalPersonalValid"), _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵsanitizeHtml"]);
  }
}
class ComparisonModalPage {
  constructor(modalController) {
    this.modalController = modalController;
    this.referenceDate = luxon__WEBPACK_IMPORTED_MODULE_0__.DateTime.local();
  }
  ngOnInit() {}
  close() {
    this.modalController.dismiss(false);
  }
  static #_ = _staticBlock = () => (this.ɵfac = function ComparisonModalPage_Factory(__ngFactoryType__) {
    return new (__ngFactoryType__ || ComparisonModalPage)(_angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵdirectiveInject"](_ionic_angular__WEBPACK_IMPORTED_MODULE_3__.ModalController));
  }, this.ɵcmp = /*@__PURE__*/_angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵdefineComponent"]({
    type: ComparisonModalPage,
    selectors: [["app-comparison-modal"]],
    standalone: false,
    decls: 11,
    vars: 5,
    consts: [["personal", ""], ["color", "playgo"], [1, "ion-text-center"], [4, "ngIf", "ngIfElse"], ["color", "playgo", 1, "ion-text-center"], ["expand", "block", "color", "light", 3, "click"], [3, "innerHTML"], [1, "points"], ["name", "ecoLeavesHsc"], [1, "valid", 3, "innerHTML"]],
    template: function ComparisonModalPage_Template(rf, ctx) {
      if (rf & 1) {
        const _r1 = _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵgetCurrentView"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵelementStart"](0, "ion-content", 1)(1, "ion-grid")(2, "ion-row")(3, "ion-col", 2);
        _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵtemplate"](4, ComparisonModalPage_div_4_Template, 29, 37, "div", 3)(5, ComparisonModalPage_ng_template_5_Template, 29, 37, "ng-template", null, 0, _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵtemplateRefExtractor"]);
        _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵelementEnd"]()()()();
        _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵelementStart"](7, "ion-footer", 4)(8, "ion-button", 5);
        _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵlistener"]("click", function ComparisonModalPage_Template_ion_button_click_8_listener() {
          _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵrestoreView"](_r1);
          return _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵresetView"](ctx.close());
        });
        _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵtext"](9);
        _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵpipe"](10, "translate");
        _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵelementEnd"]()();
      }
      if (rf & 2) {
        const personal_r3 = _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵreference"](6);
        _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵadvance"](4);
        _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵproperty"]("ngIf", ctx.type === "team")("ngIfElse", personal_r3);
        _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵadvance"](5);
        _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵtextInterpolate"](_angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵpipeBind1"](10, 3, "modal.ok"));
      }
    },
    dependencies: [_angular_common__WEBPACK_IMPORTED_MODULE_4__.NgIf, _ionic_angular__WEBPACK_IMPORTED_MODULE_3__.IonButton, _ionic_angular__WEBPACK_IMPORTED_MODULE_3__.IonCol, _ionic_angular__WEBPACK_IMPORTED_MODULE_3__.IonContent, _ionic_angular__WEBPACK_IMPORTED_MODULE_3__.IonFooter, _ionic_angular__WEBPACK_IMPORTED_MODULE_3__.IonGrid, _ionic_angular__WEBPACK_IMPORTED_MODULE_3__.IonRow, _ui_icon_icon_component__WEBPACK_IMPORTED_MODULE_5__.IconComponent, _ngx_translate_core__WEBPACK_IMPORTED_MODULE_6__.TranslatePipe, _pipes_localDate_pipe__WEBPACK_IMPORTED_MODULE_7__.LocalDatePipe, _pipes_localNumber_pipe__WEBPACK_IMPORTED_MODULE_8__.LocalNumberPipe, _pipes_SafeHtml_pipe__WEBPACK_IMPORTED_MODULE_9__.SafeHtmlPipe],
    styles: [".limit-title[_ngcontent-%COMP%] {\n  font-weight: bold;\n  margin: 8px;\n}\n\n.valid[_ngcontent-%COMP%] {\n  font-size: 12px;\n}\n\n.limit-sub[_ngcontent-%COMP%] {\n  font-weight: bold;\n  margin: 8px 0px 0px 0px;\n}\n\n.limit-text[_ngcontent-%COMP%] {\n  margin: 8px;\n}\n\nion-footer[_ngcontent-%COMP%] {\n  background: var(--ion-color-playgo);\n}\n\n.modal-progression[_ngcontent-%COMP%] {\n  text-align: left;\n}\n\n.points[_ngcontent-%COMP%] {\n  text-align: left;\n  display: flex;\n  align-items: center;\n  border-bottom: 1px solid white;\n  border-style: none none dashed none;\n  margin: 16px 9px;\n}\n.points[_ngcontent-%COMP%]   div[_ngcontent-%COMP%] {\n  display: flex;\n  justify-content: flex-end;\n  flex-grow: 1;\n  align-items: center;\n}\n.points[_ngcontent-%COMP%]   div[_ngcontent-%COMP%]   app-icon[_ngcontent-%COMP%] {\n  margin: 2px;\n}\n/*# sourceMappingURL=data:application/json;charset=utf-8;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbIndlYnBhY2s6Ly8uL3NyYy9hcHAvY29yZS9zaGFyZWQvY2FtcGFpZ25zL2hvbWUtd2lkZ2V0LXR5cGVzL2hvbWUtY2FtcGFpZ24tc2Nob29sL2hvbWUtc2Nob29sLXByb2dyZXNzaW9uL2NvbXBhcmlzb24tbW9kYWwvY29tcGFyaXNvbi5tb2RhbC5zY3NzIl0sIm5hbWVzIjpbXSwibWFwcGluZ3MiOiJBQUFBO0VBQ0UsaUJBQUE7RUFDQSxXQUFBO0FBQ0Y7O0FBQ0E7RUFDRSxlQUFBO0FBRUY7O0FBQUE7RUFDRSxpQkFBQTtFQUNBLHVCQUFBO0FBR0Y7O0FBREE7RUFDRSxXQUFBO0FBSUY7O0FBRkE7RUFDRSxtQ0FBQTtBQUtGOztBQUhBO0VBQ0UsZ0JBQUE7QUFNRjs7QUFKQTtFQUNFLGdCQUFBO0VBQ0EsYUFBQTtFQUNBLG1CQUFBO0VBQ0EsOEJBQUE7RUFDQSxtQ0FBQTtFQUNBLGdCQUFBO0FBT0Y7QUFORTtFQUNFLGFBQUE7RUFDQSx5QkFBQTtFQUNBLFlBQUE7RUFDQSxtQkFBQTtBQVFKO0FBUEk7RUFDRSxXQUFBO0FBU04iLCJzb3VyY2VzQ29udGVudCI6WyIubGltaXQtdGl0bGUge1xuICBmb250LXdlaWdodDogYm9sZDtcbiAgbWFyZ2luOiA4cHg7XG59XG4udmFsaWQge1xuICBmb250LXNpemU6IDEycHg7XG59XG4ubGltaXQtc3ViIHtcbiAgZm9udC13ZWlnaHQ6IGJvbGQ7XG4gIG1hcmdpbjogOHB4IDBweCAwcHggMHB4O1xufVxuLmxpbWl0LXRleHQge1xuICBtYXJnaW46IDhweDtcbn1cbmlvbi1mb290ZXIge1xuICBiYWNrZ3JvdW5kOiB2YXIoLS1pb24tY29sb3ItcGxheWdvKTtcbn1cbi5tb2RhbC1wcm9ncmVzc2lvbiB7XG4gIHRleHQtYWxpZ246IGxlZnQ7XG59XG4ucG9pbnRzIHtcbiAgdGV4dC1hbGlnbjogbGVmdDtcbiAgZGlzcGxheTogZmxleDtcbiAgYWxpZ24taXRlbXM6IGNlbnRlcjtcbiAgYm9yZGVyLWJvdHRvbTogMXB4IHNvbGlkIHdoaXRlO1xuICBib3JkZXItc3R5bGU6IG5vbmUgbm9uZSBkYXNoZWQgbm9uZTtcbiAgbWFyZ2luOiAxNnB4IDlweDtcbiAgZGl2IHtcbiAgICBkaXNwbGF5OiBmbGV4O1xuICAgIGp1c3RpZnktY29udGVudDogZmxleC1lbmQ7XG4gICAgZmxleC1ncm93OiAxO1xuICAgIGFsaWduLWl0ZW1zOiBjZW50ZXI7XG4gICAgYXBwLWljb24ge1xuICAgICAgbWFyZ2luOiAycHg7XG4gICAgfVxuICB9XG59XG4iXSwic291cmNlUm9vdCI6IiJ9 */"]
  }));
}
_staticBlock();

/***/ }),

/***/ 1284:
/*!***************************************************************************************************!*\
  !*** ./src/app/core/shared/campaigns/main-campaign-stat/record-status/record-status.component.ts ***!
  \***************************************************************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   RecordStatusComponent: () => (/* binding */ RecordStatusComponent)
/* harmony export */ });
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! @angular/core */ 12481);
/* harmony import */ var _angular_common__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @angular/common */ 93683);
/* harmony import */ var _ionic_angular__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @ionic/angular */ 21507);
/* harmony import */ var _ngx_translate_core__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @ngx-translate/core */ 48503);
/* harmony import */ var _pipes_localNumber_pipe__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! ../../../pipes/localNumber.pipe */ 16024);
var _staticBlock;





const _c0 = a0 => ({
  score: a0
});
const _c1 = a0 => ({
  record: a0
});
function RecordStatusComponent_div_0_Template(rf, ctx) {
  if (rf & 1) {
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](0, "div", 1)(1, "ion-grid")(2, "ion-row", 2)(3, "ion-col", 3)(4, "span", 4);
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵtext"](5);
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵpipe"](6, "localNumber");
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵpipe"](7, "translate");
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]()();
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](8, "ion-col", 5)(9, "span", 6);
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵtext"](10);
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵpipe"](11, "localNumber");
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵpipe"](12, "translate");
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]()()();
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](13, "ion-row")(14, "ion-col", 7);
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelement"](15, "ion-progress-bar", 8);
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]()()()();
  }
  if (rf & 2) {
    const ctx_r0 = _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵnextContext"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵadvance"](5);
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵtextInterpolate"](_angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵpipeBind2"](7, 6, "campaigns.homewidgets.stat.status", _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵpureFunction1"](14, _c0, _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵpipeBind1"](6, 4, ctx_r0.status.value))));
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵadvance"](5);
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵtextInterpolate1"]("", _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵpipeBind2"](12, 11, "campaigns.homewidgets.stat.record", _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵpureFunction1"](16, _c1, _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵpipeBind1"](11, 9, ctx_r0.record.value))), " ");
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵadvance"](5);
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵproperty"]("color", ctx_r0.type)("value", (ctx_r0.status == null ? null : ctx_r0.status.value) / ctx_r0.record.value);
  }
}
class RecordStatusComponent {
  constructor() {
    this.status = undefined;
    this.record = undefined;
  }
  ngOnInit() {}
  static #_ = _staticBlock = () => (this.ɵfac = function RecordStatusComponent_Factory(__ngFactoryType__) {
    return new (__ngFactoryType__ || RecordStatusComponent)();
  }, this.ɵcmp = /*@__PURE__*/_angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵdefineComponent"]({
    type: RecordStatusComponent,
    selectors: [["app-record-status"]],
    inputs: {
      status: "status",
      record: "record",
      type: "type"
    },
    standalone: false,
    decls: 1,
    vars: 1,
    consts: [["class", "ion-text-left", 4, "ngIf"], [1, "ion-text-left"], [1, "min-padding"], ["size", "6"], [1, "status"], ["size", "6", 1, "ion-text-end"], [1, "record"], [1, "progress-bar"], [1, "level-bar", 3, "color", "value"]],
    template: function RecordStatusComponent_Template(rf, ctx) {
      if (rf & 1) {
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵtemplate"](0, RecordStatusComponent_div_0_Template, 16, 18, "div", 0);
      }
      if (rf & 2) {
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵproperty"]("ngIf", ctx.status && ctx.record);
      }
    },
    dependencies: [_angular_common__WEBPACK_IMPORTED_MODULE_1__.NgIf, _ionic_angular__WEBPACK_IMPORTED_MODULE_2__.IonCol, _ionic_angular__WEBPACK_IMPORTED_MODULE_2__.IonGrid, _ionic_angular__WEBPACK_IMPORTED_MODULE_2__.IonProgressBar, _ionic_angular__WEBPACK_IMPORTED_MODULE_2__.IonRow, _ngx_translate_core__WEBPACK_IMPORTED_MODULE_3__.TranslatePipe, _pipes_localNumber_pipe__WEBPACK_IMPORTED_MODULE_4__.LocalNumberPipe],
    styles: ["ion-grid[_ngcontent-%COMP%]   .progress-bar[_ngcontent-%COMP%]   .level-bar[_ngcontent-%COMP%] {\n  height: 16px;\n}\nion-grid[_ngcontent-%COMP%]   .status[_ngcontent-%COMP%] {\n  color: var(--dark-grey);\n  font-size: 12px;\n  font-weight: bold;\n}\nion-grid[_ngcontent-%COMP%]   .record[_ngcontent-%COMP%] {\n  color: var(--dark-grey);\n  font-size: 12px;\n}\n\n.min-padding[_ngcontent-%COMP%] {\n  padding: 4px;\n}\n/*# sourceMappingURL=data:application/json;charset=utf-8;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbIndlYnBhY2s6Ly8uL3NyYy9hcHAvY29yZS9zaGFyZWQvY2FtcGFpZ25zL21haW4tY2FtcGFpZ24tc3RhdC9yZWNvcmQtc3RhdHVzL3JlY29yZC1zdGF0dXMuY29tcG9uZW50LnNjc3MiXSwibmFtZXMiOltdLCJtYXBwaW5ncyI6IkFBRUk7RUFDRSxZQUFBO0FBRE47QUFJRTtFQUNFLHVCQUFBO0VBQ0EsZUFBQTtFQUNBLGlCQUFBO0FBRko7QUFJRTtFQUNFLHVCQUFBO0VBQ0EsZUFBQTtBQUZKOztBQUtBO0VBQ0UsWUFBQTtBQUZGIiwic291cmNlc0NvbnRlbnQiOlsiaW9uLWdyaWQge1xuICAucHJvZ3Jlc3MtYmFyIHtcbiAgICAubGV2ZWwtYmFyIHtcbiAgICAgIGhlaWdodDogMTZweDtcbiAgICB9XG4gIH1cbiAgLnN0YXR1cyB7XG4gICAgY29sb3I6IHZhcigtLWRhcmstZ3JleSk7XG4gICAgZm9udC1zaXplOiAxMnB4O1xuICAgIGZvbnQtd2VpZ2h0OiBib2xkO1xuICB9XG4gIC5yZWNvcmQge1xuICAgIGNvbG9yOiB2YXIoLS1kYXJrLWdyZXkpO1xuICAgIGZvbnQtc2l6ZTogMTJweDtcbiAgfVxufVxuLm1pbi1wYWRkaW5nIHtcbiAgcGFkZGluZzogNHB4O1xufVxuIl0sInNvdXJjZVJvb3QiOiIifQ== */"]
  }));
}
_staticBlock();

/***/ }),

/***/ 2661:
/*!*******************************************************!*\
  !*** ./src/app/core/shared/services/offline.guard.ts ***!
  \*******************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   OfflineGuard: () => (/* binding */ OfflineGuard)
/* harmony export */ });
/* harmony import */ var _utils__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ../utils */ 7497);
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @angular/core */ 34205);
/* harmony import */ var _angular_router__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @angular/router */ 85422);
var _staticBlock;



class OfflineGuard {
  constructor(router) {
    this.router = router;
  }
  canActivateChild(childRoute, state) {
    return this.navigateToOfflinePageIfNeeded(childRoute);
  }
  canActivate(route, state) {
    return this.navigateToOfflinePageIfNeeded(route);
  }
  navigateToOfflinePageIfNeeded(route) {
    if (!route.component) {
      return true;
    }
    if (route.data.isOfflinePage === true) {
      return true;
    }
    if ((0,_utils__WEBPACK_IMPORTED_MODULE_0__.isOffline)()) {
      return this.router.parseUrl('/pages/tabs/offline');
    }
    return true;
  }
  static #_ = _staticBlock = () => (this.ɵfac = function OfflineGuard_Factory(__ngFactoryType__) {
    return new (__ngFactoryType__ || OfflineGuard)(_angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵinject"](_angular_router__WEBPACK_IMPORTED_MODULE_2__.Router));
  }, this.ɵprov = /*@__PURE__*/_angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵdefineInjectable"]({
    token: OfflineGuard,
    factory: OfflineGuard.ɵfac,
    providedIn: 'root'
  }));
}
_staticBlock();

/***/ }),

/***/ 4127:
/*!***************************************************!*\
  !*** ./src/app/core/constants/error.constants.ts ***!
  \***************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   ERRORS: () => (/* binding */ ERRORS)
/* harmony export */ });
const ERRORS = [{
  value: 401,
  msg: 'user not found',
  errorString: 'errors.userNotFound'
}, {
  value: 400,
  msg: 'nickname already exists',
  errorString: 'errors.nickNameExist'
}];

/***/ }),

/***/ 4813:
/*!****************************************************************************************!*\
  !*** ./src/app/core/shared/campaigns/app-company-label/company-modal/company.modal.ts ***!
  \****************************************************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   CompanyModalPage: () => (/* binding */ CompanyModalPage)
/* harmony export */ });
/* harmony import */ var _Users_smartcommunitylab_Desktop_newWork_playAndGo_playGo_node_modules_babel_runtime_helpers_esm_asyncToGenerator_js__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./node_modules/@babel/runtime/helpers/esm/asyncToGenerator.js */ 89204);
/* harmony import */ var _capacitor_browser__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @capacitor/browser */ 26515);
/* harmony import */ var src_app_pages_home_campaign_details_companies_company_detail_page_company_map_company_map_modal__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! src/app/pages/home/campaign-details/companies/company-detail-page/company-map/company-map.modal */ 83613);
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @angular/core */ 34205);
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! @angular/core */ 12481);
/* harmony import */ var _ionic_angular__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! @ionic/angular */ 21507);
/* harmony import */ var _angular_common__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! @angular/common */ 93683);
/* harmony import */ var _ngx_translate_core__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(/*! @ngx-translate/core */ 48503);

var _staticBlock;






function CompanyModalPage_ion_content_9_img_6_Template(rf, ctx) {
  if (rf & 1) {
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵelement"](0, "img", 17);
  }
  if (rf & 2) {
    const ctx_r0 = _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵnextContext"](2);
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵproperty"]("src", ctx_r0.imagePath, _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵsanitizeUrl"]);
  }
}
function CompanyModalPage_ion_content_9_ng_template_7_Template(rf, ctx) {
  if (rf & 1) {
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵelement"](0, "ion-icon", 18);
  }
}
function CompanyModalPage_ion_content_9_div_23_Template(rf, ctx) {
  if (rf & 1) {
    const _r2 = _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵgetCurrentView"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵelementStart"](0, "div", 19)(1, "ion-button", 20);
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵlistener"]("click", function CompanyModalPage_ion_content_9_div_23_Template_ion_button_click_1_listener() {
      _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵrestoreView"](_r2);
      const ctx_r0 = _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵnextContext"](2);
      return _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵresetView"](ctx_r0.openWebsite(ctx_r0.userCompany == null ? null : ctx_r0.userCompany.company == null ? null : ctx_r0.userCompany.company.web));
    });
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵelement"](2, "ion-icon", 21);
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵtext"](3);
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵpipe"](4, "translate");
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵelementEnd"]()();
  }
  if (rf & 2) {
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵadvance"](3);
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵtextInterpolate"](_angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵpipeBind1"](4, 1, "campaigns.detail.companiesPage.website"));
  }
}
function CompanyModalPage_ion_content_9_div_25_Template(rf, ctx) {
  if (rf & 1) {
    const _r3 = _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵgetCurrentView"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵelementStart"](0, "div", 19)(1, "ion-button", 20);
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵlistener"]("click", function CompanyModalPage_ion_content_9_div_25_Template_ion_button_click_1_listener() {
      _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵrestoreView"](_r3);
      const ctx_r0 = _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵnextContext"](2);
      return _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵresetView"](ctx_r0.openMail(ctx_r0.userCompany == null ? null : ctx_r0.userCompany.company == null ? null : ctx_r0.userCompany.company.contactEmail));
    });
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵelement"](2, "ion-icon", 22);
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵtext"](3);
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵpipe"](4, "translate");
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵelementEnd"]()();
  }
  if (rf & 2) {
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵadvance"](3);
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵtextInterpolate"](_angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵpipeBind1"](4, 1, "campaigns.detail.companiesPage.email"));
  }
}
function CompanyModalPage_ion_content_9_div_27_Template(rf, ctx) {
  if (rf & 1) {
    const _r4 = _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵgetCurrentView"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵelementStart"](0, "div", 19)(1, "ion-button", 20);
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵlistener"]("click", function CompanyModalPage_ion_content_9_div_27_Template_ion_button_click_1_listener() {
      _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵrestoreView"](_r4);
      const ctx_r0 = _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵnextContext"](2);
      return _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵresetView"](ctx_r0.openPhone(ctx_r0.userCompany == null ? null : ctx_r0.userCompany.company == null ? null : ctx_r0.userCompany.company.contactPhone));
    });
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵelement"](2, "ion-icon", 23);
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵtext"](3);
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵpipe"](4, "translate");
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵelementEnd"]()();
  }
  if (rf & 2) {
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵadvance"](3);
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵtextInterpolate"](_angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵpipeBind1"](4, 1, "campaigns.detail.companiesPage.phone"));
  }
}
function CompanyModalPage_ion_content_9_div_33_Template(rf, ctx) {
  if (rf & 1) {
    const _r5 = _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵgetCurrentView"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵelementStart"](0, "div", 24)(1, "div", 25);
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵlistener"]("click", function CompanyModalPage_ion_content_9_div_33_Template_div_click_1_listener() {
      _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵrestoreView"](_r5);
      const ctx_r0 = _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵnextContext"](2);
      return _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵresetView"](ctx_r0.openMail(ctx_r0.userCompany == null ? null : ctx_r0.userCompany.company == null ? null : ctx_r0.userCompany.company.contactEmail));
    });
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵelementStart"](2, "span")(3, "b");
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵtext"](4);
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵelementEnd"]()();
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵelementStart"](5, "span")(6, "b");
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵtext"](7);
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵelementEnd"]()()();
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵelementStart"](8, "div")(9, "span", 26);
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵtext"](10);
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵelementEnd"]()();
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵelementStart"](11, "div", 25);
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵlistener"]("click", function CompanyModalPage_ion_content_9_div_33_Template_div_click_11_listener() {
      _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵrestoreView"](_r5);
      const ctx_r0 = _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵnextContext"](2);
      return _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵresetView"](ctx_r0.openPhone(ctx_r0.userCompany == null ? null : ctx_r0.userCompany.company == null ? null : ctx_r0.userCompany.company.contactPhone));
    });
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵelementStart"](12, "span", 26);
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵtext"](13);
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵelementEnd"]()()();
  }
  if (rf & 2) {
    const mm_r6 = ctx.$implicit;
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵadvance"](4);
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵtextInterpolate"](mm_r6.name);
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵadvance"](3);
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵtextInterpolate"](mm_r6.surname);
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵadvance"](3);
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵtextInterpolate"](mm_r6.username);
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵadvance"](3);
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵtextInterpolate"](mm_r6.phone);
  }
}
function CompanyModalPage_ion_content_9_ion_row_39_Template(rf, ctx) {
  if (rf & 1) {
    const _r7 = _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵgetCurrentView"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵelementStart"](0, "ion-row")(1, "ion-col", 27)(2, "div", 28);
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵtext"](3);
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵelementEnd"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵelementStart"](4, "div", 29);
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵtext"](5);
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵelementEnd"]()();
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵelementStart"](6, "ion-col", 30)(7, "ion-button", 31);
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵlistener"]("click", function CompanyModalPage_ion_content_9_ion_row_39_Template_ion_button_click_7_listener() {
      const location_r8 = _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵrestoreView"](_r7).$implicit;
      const ctx_r0 = _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵnextContext"](2);
      return _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵresetView"](ctx_r0.openMap(location_r8, ctx_r0.userCompany == null ? null : ctx_r0.userCompany.company == null ? null : ctx_r0.userCompany.company.locations, location_r8));
    });
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵelement"](8, "ion-icon", 32);
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵelementEnd"]()()();
  }
  if (rf & 2) {
    const location_r8 = ctx.$implicit;
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵadvance"](3);
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵtextInterpolate"](location_r8.id);
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵadvance"](2);
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵtextInterpolate4"]("", location_r8.address, " ", location_r8.streetNumber, " ", location_r8.zip, " ", location_r8.city, " ");
  }
}
function CompanyModalPage_ion_content_9_Template(rf, ctx) {
  if (rf & 1) {
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵelementStart"](0, "ion-content", 6)(1, "div")(2, "ion-grid", 6)(3, "ion-row")(4, "ion-col", 7)(5, "ion-thumbnail");
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵtemplate"](6, CompanyModalPage_ion_content_9_img_6_Template, 1, 1, "img", 8)(7, CompanyModalPage_ion_content_9_ng_template_7_Template, 1, 0, "ng-template", null, 0, _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵtemplateRefExtractor"]);
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵelementEnd"]()();
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵelementStart"](9, "ion-col", 9)(10, "div", 10);
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵtext"](11);
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵelementEnd"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵelementStart"](12, "div")(13, "span");
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵtext"](14);
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵelementEnd"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵelementStart"](15, "span");
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵtext"](16);
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵelementEnd"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵelementStart"](17, "span");
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵtext"](18);
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵelementEnd"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵelementStart"](19, "span");
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵtext"](20);
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵelementEnd"]()()()();
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵelementStart"](21, "ion-row", 11)(22, "ion-col", 12);
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵtemplate"](23, CompanyModalPage_ion_content_9_div_23_Template, 5, 3, "div", 13);
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵelementEnd"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵelementStart"](24, "ion-col", 12);
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵtemplate"](25, CompanyModalPage_ion_content_9_div_25_Template, 5, 3, "div", 13);
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵelementEnd"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵelementStart"](26, "ion-col", 12);
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵtemplate"](27, CompanyModalPage_ion_content_9_div_27_Template, 5, 3, "div", 13);
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵelementEnd"]()();
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵelementStart"](28, "ion-row")(29, "ion-col")(30, "div", 14);
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵtext"](31);
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵpipe"](32, "translate");
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵelementEnd"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵtemplate"](33, CompanyModalPage_ion_content_9_div_33_Template, 14, 4, "div", 15);
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵelementEnd"]()();
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵelementStart"](34, "ion-row")(35, "ion-col")(36, "div", 14);
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵtext"](37);
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵpipe"](38, "translate");
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵelementEnd"]()()();
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵtemplate"](39, CompanyModalPage_ion_content_9_ion_row_39_Template, 9, 5, "ion-row", 16);
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵelementEnd"]()()();
  }
  if (rf & 2) {
    const userCompanyIcon_r9 = _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵreference"](8);
    const ctx_r0 = _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵnextContext"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵadvance"](6);
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵproperty"]("ngIf", ctx_r0.imagePath)("ngIfElse", userCompanyIcon_r9);
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵadvance"](5);
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵtextInterpolate1"](" ", ctx_r0.userCompany == null ? null : ctx_r0.userCompany.company == null ? null : ctx_r0.userCompany.company.name, " ");
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵadvance"](3);
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵtextInterpolate1"]("", ctx_r0.userCompany == null ? null : ctx_r0.userCompany.company == null ? null : ctx_r0.userCompany.company.address, " ");
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵadvance"](2);
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵtextInterpolate1"]("", ctx_r0.userCompany == null ? null : ctx_r0.userCompany.company == null ? null : ctx_r0.userCompany.company.streetNumber, " ");
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵadvance"](2);
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵtextInterpolate1"]("", ctx_r0.userCompany == null ? null : ctx_r0.userCompany.company == null ? null : ctx_r0.userCompany.company.zip, " ");
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵadvance"](2);
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵtextInterpolate"](ctx_r0.userCompany == null ? null : ctx_r0.userCompany.company == null ? null : ctx_r0.userCompany.company.city);
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵadvance"](3);
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵproperty"]("ngIf", ctx_r0.userCompany == null ? null : ctx_r0.userCompany.company == null ? null : ctx_r0.userCompany.company.web);
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵadvance"](2);
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵproperty"]("ngIf", ctx_r0.userCompany == null ? null : ctx_r0.userCompany.company == null ? null : ctx_r0.userCompany.company.contactEmail);
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵadvance"](2);
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵproperty"]("ngIf", ctx_r0.userCompany == null ? null : ctx_r0.userCompany.company == null ? null : ctx_r0.userCompany.company.contactPhone);
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵadvance"](4);
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵtextInterpolate"](_angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵpipeBind1"](32, 14, "campaigns.detail.mm"));
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵadvance"](2);
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵproperty"]("ngForOf", ctx_r0.userCompany == null ? null : ctx_r0.userCompany.mobilityManagers);
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵadvance"](4);
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵtextInterpolate1"](" ", _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵpipeBind1"](38, 16, "campaigns.detail.companiesPage.location"), " ");
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵadvance"](2);
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵproperty"]("ngForOf", ctx_r0.userCompany == null ? null : ctx_r0.userCompany.company == null ? null : ctx_r0.userCompany.company.locations);
  }
}
class CompanyModalPage {
  constructor(modalController) {
    this.modalController = modalController;
  }
  ngOnInit() {
    this.imagePath = this.userCompany?.company?.logo;
  }
  close() {
    this.modalController.dismiss(false);
  }
  openWebsite(website) {
    _capacitor_browser__WEBPACK_IMPORTED_MODULE_1__.Browser.open({
      url: website,
      windowName: '_system',
      presentationStyle: 'popover'
    });
  }
  openMail(mail) {
    window.open('mailto:' + mail);
  }
  openPhone(phone) {
    window.open('tel:' + phone);
  }
  openMap(center, allLocations, selectedLocation) {
    var _this = this;
    return (0,_Users_smartcommunitylab_Desktop_newWork_playAndGo_playGo_node_modules_babel_runtime_helpers_esm_asyncToGenerator_js__WEBPACK_IMPORTED_MODULE_0__["default"])(function* () {
      const modal = yield _this.modalController.create({
        component: src_app_pages_home_campaign_details_companies_company_detail_page_company_map_company_map_modal__WEBPACK_IMPORTED_MODULE_2__.CompanyMapModalPage,
        cssClass: 'challenge-info',
        canDismiss: true,
        componentProps: {
          center,
          allLocations,
          selectedLocation
        }
      });
      yield modal.present();
      yield modal.onWillDismiss();
    })();
  }
  static #_ = _staticBlock = () => (this.ɵfac = function CompanyModalPage_Factory(__ngFactoryType__) {
    return new (__ngFactoryType__ || CompanyModalPage)(_angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵdirectiveInject"](_ionic_angular__WEBPACK_IMPORTED_MODULE_5__.ModalController));
  }, this.ɵcmp = /*@__PURE__*/_angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵdefineComponent"]({
    type: CompanyModalPage,
    selectors: [["app-company-modal"]],
    standalone: false,
    decls: 10,
    vars: 4,
    consts: [["userCompanyIcon", ""], ["color", "playgo"], ["slot", "start"], ["text", "", 3, "click"], ["name", "arrow-back-outline"], ["class", "ion-padding", 4, "ngIf"], [1, "ion-padding"], ["size", "4", 1, "image-center"], ["alt", "Logo", 3, "src", 4, "ngIf", "ngIfElse"], ["size", "8", 1, "company-desc", "ion-padding"], [1, "desc"], [1, "ion-no-padding", "ion-no-margin"], ["size", "4", 1, "ion-no-padding", "ion-no-margin"], ["class", "website", 4, "ngIf"], [1, "section"], ["class", "subsection", 4, "ngFor", "ngForOf"], [4, "ngFor", "ngForOf"], ["alt", "Logo", 3, "src"], ["name", "briefcase-outline", "size", "large"], [1, "website"], ["expand", "block", "color", "playgo", 3, "click"], ["slot", "start", "name", "globe"], ["slot", "start", "name", "mail"], ["slot", "start", "name", "call"], [1, "subsection"], [3, "click"], [1, "link"], ["size", "10"], [1, "id"], [1, "address"], ["size", "2"], ["color", "playgo", 3, "click"], ["name", "map-outline"]],
    template: function CompanyModalPage_Template(rf, ctx) {
      if (rf & 1) {
        _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵelementStart"](0, "ion-header")(1, "ion-toolbar", 1)(2, "ion-buttons", 2)(3, "ion-button", 3);
        _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵlistener"]("click", function CompanyModalPage_Template_ion_button_click_3_listener() {
          return ctx.close();
        });
        _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵelement"](4, "ion-icon", 4);
        _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵelementEnd"]()();
        _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵelementStart"](5, "ion-title")(6, "div");
        _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵtext"](7);
        _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵpipe"](8, "translate");
        _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵelementEnd"]()()()();
        _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵtemplate"](9, CompanyModalPage_ion_content_9_Template, 40, 18, "ion-content", 5);
      }
      if (rf & 2) {
        _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵadvance"](7);
        _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵtextInterpolate1"](" ", _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵpipeBind1"](8, 2, "campaigns.detail.youCompany"), " ");
        _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵadvance"](2);
        _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵproperty"]("ngIf", ctx.userCompany);
      }
    },
    dependencies: [_angular_common__WEBPACK_IMPORTED_MODULE_6__.NgForOf, _angular_common__WEBPACK_IMPORTED_MODULE_6__.NgIf, _ionic_angular__WEBPACK_IMPORTED_MODULE_5__.IonButton, _ionic_angular__WEBPACK_IMPORTED_MODULE_5__.IonButtons, _ionic_angular__WEBPACK_IMPORTED_MODULE_5__.IonCol, _ionic_angular__WEBPACK_IMPORTED_MODULE_5__.IonContent, _ionic_angular__WEBPACK_IMPORTED_MODULE_5__.IonGrid, _ionic_angular__WEBPACK_IMPORTED_MODULE_5__.IonHeader, _ionic_angular__WEBPACK_IMPORTED_MODULE_5__.IonIcon, _ionic_angular__WEBPACK_IMPORTED_MODULE_5__.IonRow, _ionic_angular__WEBPACK_IMPORTED_MODULE_5__.IonThumbnail, _ionic_angular__WEBPACK_IMPORTED_MODULE_5__.IonTitle, _ionic_angular__WEBPACK_IMPORTED_MODULE_5__.IonToolbar, _ngx_translate_core__WEBPACK_IMPORTED_MODULE_7__.TranslatePipe],
    styles: ["ion-content[_ngcontent-%COMP%]   span[_ngcontent-%COMP%] {\n  margin: 0px 2px;\n}\nion-content[_ngcontent-%COMP%]   .image-center[_ngcontent-%COMP%] {\n  display: flex;\n  align-items: center;\n  justify-content: center;\n}\nion-content[_ngcontent-%COMP%]   .company-name[_ngcontent-%COMP%] {\n  font-style: normal;\n  font-weight: 600;\n  font-size: 18px;\n  line-height: 21px;\n  text-align: center;\n}\nion-content[_ngcontent-%COMP%]   .close[_ngcontent-%COMP%] {\n  position: absolute;\n  top: 8px;\n  right: 8px;\n  font-size: 25px;\n  display: flex;\n  flex-direction: column;\n  justify-content: space-between;\n}\nion-content[_ngcontent-%COMP%]   .section[_ngcontent-%COMP%] {\n  font-weight: bold;\n  margin: 24px 0px 8px 0px;\n  border-bottom: solid 1px grey;\n  font-size: larger;\n}\nion-content[_ngcontent-%COMP%]   .subsection[_ngcontent-%COMP%] {\n  margin: 8px 0px 24px 0px;\n}\nion-content[_ngcontent-%COMP%]   .link[_ngcontent-%COMP%] {\n  cursor: pointer;\n  color: var(--ion-color-playgo);\n  text-decoration: underline;\n}\nion-content[_ngcontent-%COMP%]   .id[_ngcontent-%COMP%] {\n  font-weight: bold;\n}\n/*# sourceMappingURL=data:application/json;charset=utf-8;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbIndlYnBhY2s6Ly8uL3NyYy9hcHAvY29yZS9zaGFyZWQvY2FtcGFpZ25zL2FwcC1jb21wYW55LWxhYmVsL2NvbXBhbnktbW9kYWwvY29tcGFueS5tb2RhbC5zY3NzIl0sIm5hbWVzIjpbXSwibWFwcGluZ3MiOiJBQUNFO0VBQ0UsZUFBQTtBQUFKO0FBRUU7RUFDRSxhQUFBO0VBQ0EsbUJBQUE7RUFDQSx1QkFBQTtBQUFKO0FBRUU7RUFDRSxrQkFBQTtFQUNBLGdCQUFBO0VBQ0EsZUFBQTtFQUNBLGlCQUFBO0VBQ0Esa0JBQUE7QUFBSjtBQUVFO0VBQ0Usa0JBQUE7RUFDQSxRQUFBO0VBQ0EsVUFBQTtFQUNBLGVBQUE7RUFDQSxhQUFBO0VBQ0Esc0JBQUE7RUFDQSw4QkFBQTtBQUFKO0FBRUU7RUFDRSxpQkFBQTtFQUNBLHdCQUFBO0VBQ0EsNkJBQUE7RUFDQSxpQkFBQTtBQUFKO0FBRUU7RUFDRSx3QkFBQTtBQUFKO0FBRUU7RUFDRSxlQUFBO0VBQ0EsOEJBQUE7RUFDQSwwQkFBQTtBQUFKO0FBRUU7RUFDRSxpQkFBQTtBQUFKIiwic291cmNlc0NvbnRlbnQiOlsiaW9uLWNvbnRlbnQge1xuICBzcGFuIHtcbiAgICBtYXJnaW46IDBweCAycHg7XG4gIH1cbiAgLmltYWdlLWNlbnRlciB7XG4gICAgZGlzcGxheTogZmxleDtcbiAgICBhbGlnbi1pdGVtczogY2VudGVyO1xuICAgIGp1c3RpZnktY29udGVudDogY2VudGVyO1xuICB9XG4gIC5jb21wYW55LW5hbWUge1xuICAgIGZvbnQtc3R5bGU6IG5vcm1hbDtcbiAgICBmb250LXdlaWdodDogNjAwO1xuICAgIGZvbnQtc2l6ZTogMThweDtcbiAgICBsaW5lLWhlaWdodDogMjFweDtcbiAgICB0ZXh0LWFsaWduOiBjZW50ZXI7XG4gIH1cbiAgLmNsb3NlIHtcbiAgICBwb3NpdGlvbjogYWJzb2x1dGU7XG4gICAgdG9wOiA4cHg7XG4gICAgcmlnaHQ6IDhweDtcbiAgICBmb250LXNpemU6IDI1cHg7XG4gICAgZGlzcGxheTogZmxleDtcbiAgICBmbGV4LWRpcmVjdGlvbjogY29sdW1uO1xuICAgIGp1c3RpZnktY29udGVudDogc3BhY2UtYmV0d2VlbjtcbiAgfVxuICAuc2VjdGlvbiB7XG4gICAgZm9udC13ZWlnaHQ6IGJvbGQ7XG4gICAgbWFyZ2luOiAyNHB4IDBweCA4cHggMHB4O1xuICAgIGJvcmRlci1ib3R0b206IHNvbGlkIDFweCBncmV5O1xuICAgIGZvbnQtc2l6ZTogbGFyZ2VyO1xuICB9XG4gIC5zdWJzZWN0aW9uIHtcbiAgICBtYXJnaW46IDhweCAwcHggMjRweCAwcHg7XG4gIH1cbiAgLmxpbmsge1xuICAgIGN1cnNvcjogcG9pbnRlcjtcbiAgICBjb2xvcjogdmFyKC0taW9uLWNvbG9yLXBsYXlnbyk7XG4gICAgdGV4dC1kZWNvcmF0aW9uOiB1bmRlcmxpbmU7XG4gIH1cbiAgLmlkIHtcbiAgICBmb250LXdlaWdodDogYm9sZDtcbiAgfVxufVxuIl0sInNvdXJjZVJvb3QiOiIifQ== */"]
  }));
}
_staticBlock();

/***/ }),

/***/ 4927:
/*!*******************************************************************************************************************************************!*\
  !*** ./src/app/core/shared/campaigns/home-widget-types/home-campaign-school/home-school-progression/home-school-progression.component.ts ***!
  \*******************************************************************************************************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   HomeSchoolProgressionComponent: () => (/* binding */ HomeSchoolProgressionComponent)
/* harmony export */ });
/* harmony import */ var _Users_smartcommunitylab_Desktop_newWork_playAndGo_playGo_node_modules_babel_runtime_helpers_esm_asyncToGenerator_js__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./node_modules/@babel/runtime/helpers/esm/asyncToGenerator.js */ 89204);
/* harmony import */ var _comparison_modal_comparison_modal__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ./comparison-modal/comparison.modal */ 1146);
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @angular/core */ 34205);
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @angular/core */ 12481);
/* harmony import */ var _ionic_angular__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! @ionic/angular */ 21507);
/* harmony import */ var _angular_common__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! @angular/common */ 93683);
/* harmony import */ var _ngx_translate_core__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! @ngx-translate/core */ 48503);

var _staticBlock;





function HomeSchoolProgressionComponent_div_0_p_4_Template(rf, ctx) {
  if (rf & 1) {
    _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵelementStart"](0, "p");
    _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵtext"](1);
    _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵpipe"](2, "translate");
    _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵelementEnd"]();
  }
  if (rf & 2) {
    _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵadvance"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵtextInterpolate"](_angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵpipeBind1"](2, 1, "campaigns.detail.teamProgression"));
  }
}
function HomeSchoolProgressionComponent_div_0_ng_template_5_Template(rf, ctx) {
  if (rf & 1) {
    _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵelementStart"](0, "p");
    _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵtext"](1);
    _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵpipe"](2, "translate");
    _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵelementEnd"]();
  }
  if (rf & 2) {
    _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵadvance"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵtextInterpolate"](_angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵpipeBind1"](2, 1, "campaigns.detail.playerProgression"));
  }
}
function HomeSchoolProgressionComponent_div_0_ion_row_9_Template(rf, ctx) {
  if (rf & 1) {
    _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵelementStart"](0, "ion-row")(1, "ion-col", 8);
    _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵelement"](2, "ion-progress-bar", 9);
    _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵelementEnd"]()();
  }
  if (rf & 2) {
    const ctx_r1 = _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵnextContext"](2);
    _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵadvance"](2);
    _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵproperty"]("value", ctx_r1.getPercentage(ctx_r1.stat));
  }
}
function HomeSchoolProgressionComponent_div_0_ng_template_10_Template(rf, ctx) {
  if (rf & 1) {
    _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵelementStart"](0, "ion-row")(1, "ion-col", 8);
    _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵelement"](2, "ion-progress-bar", 9);
    _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵelementEnd"]()();
  }
  if (rf & 2) {
    _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵadvance"](2);
    _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵproperty"]("value", 0);
  }
}
function HomeSchoolProgressionComponent_div_0_Template(rf, ctx) {
  if (rf & 1) {
    const _r1 = _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵgetCurrentView"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵelementStart"](0, "div", 3)(1, "ion-grid")(2, "ion-row", 4)(3, "ion-col");
    _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵtemplate"](4, HomeSchoolProgressionComponent_div_0_p_4_Template, 3, 3, "p", 5)(5, HomeSchoolProgressionComponent_div_0_ng_template_5_Template, 3, 3, "ng-template", null, 0, _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵtemplateRefExtractor"]);
    _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵelementEnd"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵelementStart"](7, "ion-col", 6)(8, "ion-icon", 7);
    _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵlistener"]("click", function HomeSchoolProgressionComponent_div_0_Template_ion_icon_click_8_listener($event) {
      _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵrestoreView"](_r1);
      const ctx_r1 = _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵnextContext"]();
      return _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵresetView"](ctx_r1.openLimit($event));
    });
    _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵelementEnd"]()()();
    _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵtemplate"](9, HomeSchoolProgressionComponent_div_0_ion_row_9_Template, 3, 1, "ion-row", 5)(10, HomeSchoolProgressionComponent_div_0_ng_template_10_Template, 3, 1, "ng-template", null, 1, _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵtemplateRefExtractor"]);
    _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵelementEnd"]()();
  }
  if (rf & 2) {
    const player_r3 = _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵreference"](6);
    const zeroProgress_r4 = _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵreference"](11);
    const ctx_r1 = _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵnextContext"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵadvance"](4);
    _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵproperty"]("ngIf", ctx_r1.type === "team")("ngIfElse", player_r3);
    _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵadvance"](5);
    _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵproperty"]("ngIf", ctx_r1.stat == null ? null : ctx_r1.stat.value)("ngIfElse", zeroProgress_r4);
  }
}
class HomeSchoolProgressionComponent {
  constructor(modalController) {
    this.modalController = modalController;
  }
  ngOnInit() {}
  ngOnDestroy() {}
  getPercentage(arg0) {
    return arg0.value - arg0.min > 0 ? (arg0.value - arg0.min) / (arg0.max - arg0.min) : arg0.max === arg0.min && arg0.min === arg0.value && arg0.value === 0 || arg0.value === arg0.min && arg0.value !== arg0.max ? 0 : 100;
  }
  openLimit(event) {
    var _this = this;
    return (0,_Users_smartcommunitylab_Desktop_newWork_playAndGo_playGo_node_modules_babel_runtime_helpers_esm_asyncToGenerator_js__WEBPACK_IMPORTED_MODULE_0__["default"])(function* () {
      event.stopPropagation();
      const modal = yield _this.modalController.create({
        component: _comparison_modal_comparison_modal__WEBPACK_IMPORTED_MODULE_1__.ComparisonModalPage,
        cssClass: 'challenge-info',
        canDismiss: true,
        componentProps: {
          stat: _this.stat,
          type: _this.type
        }
      });
      yield modal.present();
      yield modal.onWillDismiss();
    })();
  }
  static #_ = _staticBlock = () => (this.ɵfac = function HomeSchoolProgressionComponent_Factory(__ngFactoryType__) {
    return new (__ngFactoryType__ || HomeSchoolProgressionComponent)(_angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵdirectiveInject"](_ionic_angular__WEBPACK_IMPORTED_MODULE_4__.ModalController));
  }, this.ɵcmp = /*@__PURE__*/_angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵdefineComponent"]({
    type: HomeSchoolProgressionComponent,
    selectors: [["app-home-school-progression"]],
    inputs: {
      stat: "stat",
      type: "type"
    },
    standalone: false,
    decls: 1,
    vars: 1,
    consts: [["player", ""], ["zeroProgress", ""], ["class", "ion-text-left", 4, "ngIf"], [1, "ion-text-left"], [1, "limit-text"], [4, "ngIf", "ngIfElse"], ["size", "1"], ["name", "information-circle-outline", 1, "info-box", 3, "click"], [1, "progress-bar"], ["color", "school", 1, "level-bar", 3, "value"]],
    template: function HomeSchoolProgressionComponent_Template(rf, ctx) {
      if (rf & 1) {
        _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵtemplate"](0, HomeSchoolProgressionComponent_div_0_Template, 12, 4, "div", 2);
      }
      if (rf & 2) {
        _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵproperty"]("ngIf", ctx.stat);
      }
    },
    dependencies: [_angular_common__WEBPACK_IMPORTED_MODULE_5__.NgIf, _ionic_angular__WEBPACK_IMPORTED_MODULE_4__.IonCol, _ionic_angular__WEBPACK_IMPORTED_MODULE_4__.IonGrid, _ionic_angular__WEBPACK_IMPORTED_MODULE_4__.IonIcon, _ionic_angular__WEBPACK_IMPORTED_MODULE_4__.IonProgressBar, _ionic_angular__WEBPACK_IMPORTED_MODULE_4__.IonRow, _ngx_translate_core__WEBPACK_IMPORTED_MODULE_6__.TranslatePipe],
    styles: [".level-bar[_ngcontent-%COMP%] {\n  height: 16px;\n  --background: none;\n}\n\n.limit-text[_ngcontent-%COMP%] {\n  font-size: 14px;\n}\n\n.info-box[_ngcontent-%COMP%] {\n  font-size: 19px;\n  display: inline-block;\n  vertical-align: middle;\n  vertical-align: center;\n  color: var(--ion-color-school);\n}\n\np[_ngcontent-%COMP%] {\n  font-style: italic;\n  font-weight: 300;\n  font-size: 13px;\n  line-height: 15px;\n  display: flex;\n  justify-content: normal;\n  align-items: center;\n}\np[_ngcontent-%COMP%]   app-icon[_ngcontent-%COMP%] {\n  margin: 2px;\n}\n/*# sourceMappingURL=data:application/json;charset=utf-8;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbIndlYnBhY2s6Ly8uL3NyYy9hcHAvY29yZS9zaGFyZWQvY2FtcGFpZ25zL2hvbWUtd2lkZ2V0LXR5cGVzL2hvbWUtY2FtcGFpZ24tc2Nob29sL2hvbWUtc2Nob29sLXByb2dyZXNzaW9uL2hvbWUtc2Nob29sLXByb2dyZXNzaW9uLmNvbXBvbmVudC5zY3NzIl0sIm5hbWVzIjpbXSwibWFwcGluZ3MiOiJBQUFBO0VBQ0UsWUFBQTtFQUNBLGtCQUFBO0FBQ0Y7O0FBQ0E7RUFDRSxlQUFBO0FBRUY7O0FBQUE7RUFDRSxlQUFBO0VBQ0EscUJBQUE7RUFDQSxzQkFBQTtFQUNBLHNCQUFBO0VBQ0EsOEJBQUE7QUFHRjs7QUFEQTtFQUNFLGtCQUFBO0VBQ0EsZ0JBQUE7RUFDQSxlQUFBO0VBQ0EsaUJBQUE7RUFDQSxhQUFBO0VBQ0EsdUJBQUE7RUFDQSxtQkFBQTtBQUlGO0FBSEU7RUFDRSxXQUFBO0FBS0oiLCJzb3VyY2VzQ29udGVudCI6WyIubGV2ZWwtYmFyIHtcbiAgaGVpZ2h0OiAxNnB4O1xuICAtLWJhY2tncm91bmQ6IG5vbmU7XG59XG4ubGltaXQtdGV4dCB7XG4gIGZvbnQtc2l6ZTogMTRweDtcbn1cbi5pbmZvLWJveCB7XG4gIGZvbnQtc2l6ZTogMTlweDtcbiAgZGlzcGxheTogaW5saW5lLWJsb2NrO1xuICB2ZXJ0aWNhbC1hbGlnbjogbWlkZGxlO1xuICB2ZXJ0aWNhbC1hbGlnbjogY2VudGVyO1xuICBjb2xvcjogdmFyKC0taW9uLWNvbG9yLXNjaG9vbCk7XG59XG5wIHtcbiAgZm9udC1zdHlsZTogaXRhbGljO1xuICBmb250LXdlaWdodDogMzAwO1xuICBmb250LXNpemU6IDEzcHg7XG4gIGxpbmUtaGVpZ2h0OiAxNXB4O1xuICBkaXNwbGF5OiBmbGV4O1xuICBqdXN0aWZ5LWNvbnRlbnQ6IG5vcm1hbDtcbiAgYWxpZ24taXRlbXM6IGNlbnRlcjtcbiAgYXBwLWljb24ge1xuICAgIG1hcmdpbjogMnB4O1xuICB9XG59XG4iXSwic291cmNlUm9vdCI6IiJ9 */"]
  }));
}
_staticBlock();

/***/ }),

/***/ 6972:
/*!**************************************************************************************!*\
  !*** ./src/app/core/shared/globalization/ordinal-number/ordinal-number.component.ts ***!
  \**************************************************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   OrdinalNumberComponent: () => (/* binding */ OrdinalNumberComponent)
/* harmony export */ });
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! @angular/core */ 12481);
/* harmony import */ var _services_user_service__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ../../services/user.service */ 89815);
/* harmony import */ var _angular_common__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @angular/common */ 93683);
/* harmony import */ var _ngx_translate_core__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @ngx-translate/core */ 48503);
var _staticBlock;




const _c0 = a0 => ({
  ordinal: a0
});
function OrdinalNumberComponent_ng_container_0_Template(rf, ctx) {
  if (rf & 1) {
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementContainerStart"](0);
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵtext"](1);
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵpipe"](2, "translate");
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementContainerEnd"]();
  }
  if (rf & 2) {
    const ctx_r0 = _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵnextContext"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵadvance"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵtextInterpolate1"](" ", _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵpipeBind2"](2, 1, "number.ordinal." + ctx_r0.ordinalPluralRules.select(ctx_r0.value), _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵpureFunction1"](4, _c0, ctx_r0.value)), " ");
  }
}
class OrdinalNumberComponent {
  constructor(userService) {
    this.userService = userService;
    this.ordinalPluralRules = new Intl.PluralRules(this.userService.getLocale(), {
      type: 'ordinal'
    });
  }
  ngOnInit() {}
  static #_ = _staticBlock = () => (this.ɵfac = function OrdinalNumberComponent_Factory(__ngFactoryType__) {
    return new (__ngFactoryType__ || OrdinalNumberComponent)(_angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵdirectiveInject"](_services_user_service__WEBPACK_IMPORTED_MODULE_1__.UserService));
  }, this.ɵcmp = /*@__PURE__*/_angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵdefineComponent"]({
    type: OrdinalNumberComponent,
    selectors: [["app-ordinal-number"]],
    inputs: {
      value: "value"
    },
    standalone: false,
    decls: 1,
    vars: 1,
    consts: [[4, "ngIf"]],
    template: function OrdinalNumberComponent_Template(rf, ctx) {
      if (rf & 1) {
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵtemplate"](0, OrdinalNumberComponent_ng_container_0_Template, 3, 6, "ng-container", 0);
      }
      if (rf & 2) {
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵproperty"]("ngIf", ctx.value !== undefined);
      }
    },
    dependencies: [_angular_common__WEBPACK_IMPORTED_MODULE_2__.NgIf, _ngx_translate_core__WEBPACK_IMPORTED_MODULE_3__.TranslatePipe],
    encapsulation: 2
  }));
}
_staticBlock();

/***/ }),

/***/ 7497:
/*!**************************************!*\
  !*** ./src/app/core/shared/utils.ts ***!
  \**************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   cartesian: () => (/* binding */ cartesian),
/* harmony export */   convertBlobToBase64: () => (/* binding */ convertBlobToBase64),
/* harmony export */   formatDurationToHoursAndMinutes: () => (/* binding */ formatDurationToHoursAndMinutes),
/* harmony export */   getAdjacentPairs: () => (/* binding */ getAdjacentPairs),
/* harmony export */   getDebugStack: () => (/* binding */ getDebugStack),
/* harmony export */   groupByConsecutiveValues: () => (/* binding */ groupByConsecutiveValues),
/* harmony export */   isConstant: () => (/* binding */ isConstant),
/* harmony export */   isInstanceOf: () => (/* binding */ isInstanceOf),
/* harmony export */   isNotConstant: () => (/* binding */ isNotConstant),
/* harmony export */   isNotNil: () => (/* binding */ isNotNil),
/* harmony export */   isOffline: () => (/* binding */ isOffline),
/* harmony export */   isOfflineError: () => (/* binding */ isOfflineError),
/* harmony export */   readAsBase64: () => (/* binding */ readAsBase64),
/* harmony export */   safeStringify: () => (/* binding */ safeStringify),
/* harmony export */   time: () => (/* binding */ time),
/* harmony export */   trackByProperty: () => (/* binding */ trackByProperty),
/* harmony export */   waitMs: () => (/* binding */ waitMs)
/* harmony export */ });
/* harmony import */ var _Users_smartcommunitylab_Desktop_newWork_playAndGo_playGo_node_modules_babel_runtime_helpers_esm_asyncToGenerator_js__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./node_modules/@babel/runtime/helpers/esm/asyncToGenerator.js */ 89204);
/* harmony import */ var lodash_es__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! lodash-es */ 70785);
/* harmony import */ var lodash_es__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! lodash-es */ 84046);
/* harmony import */ var lodash_es__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! lodash-es */ 80524);
/* harmony import */ var lodash_es__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! lodash-es */ 982);
/* harmony import */ var lodash_es__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! lodash-es */ 18665);
/* harmony import */ var luxon__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! luxon */ 45967);
/* harmony import */ var src_environments_environment__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(/*! src/environments/environment */ 45312);




const isNotConstant = constant => arg => arg !== constant;
const isConstant = constant => arg => arg === constant;
const isNotNil = arg => arg !== null && arg !== undefined;
const isInstanceOf = type => arg => arg instanceof type;
function groupByConsecutiveValues(array, needle) {
  return array.reduce((accumulator, currentValue) => {
    const lastGroup = (0,lodash_es__WEBPACK_IMPORTED_MODULE_3__["default"])(accumulator);
    const currentGroupValue = currentValue[needle];
    if (lastGroup && currentGroupValue === lastGroup.group) {
      lastGroup.values.push(currentValue);
    } else {
      accumulator.push({
        group: currentGroupValue,
        values: [currentValue]
      });
    }
    return accumulator;
  }, []);
}
function isOffline() {
  return navigator.onLine === false ||
  // debug offline from console
  src_environments_environment__WEBPACK_IMPORTED_MODULE_7__.environment.production === false && window.debugOffline === true;
}
function isOfflineError(error) {
  return error?.status === 0 && isOffline() ||
  // debug offline from network
  src_environments_environment__WEBPACK_IMPORTED_MODULE_7__.environment.production === false && error?.status === 418 && error?.error === 'offline';
}
function getDebugStack() {
  return new Error().stack || 'stack not available';
}
function readAsBase64(_x) {
  return _readAsBase.apply(this, arguments);
}
function _readAsBase() {
  _readAsBase = (0,_Users_smartcommunitylab_Desktop_newWork_playAndGo_playGo_node_modules_babel_runtime_helpers_esm_asyncToGenerator_js__WEBPACK_IMPORTED_MODULE_0__["default"])(function* (photo) {
    // Fetch the photo, read as a blob, then convert to base64 format
    // eslint-disable-next-line @typescript-eslint/no-non-null-assertion
    const response = yield fetch(photo.webPath);
    const blob = yield response.blob();
    return blob;
    //return await convertBlobToBase64(blob) as string;
  });
  return _readAsBase.apply(this, arguments);
}
function convertBlobToBase64(blob) {
  return new Promise((resolve, reject) => {
    const reader = new FileReader();
    reader.onerror = reject;
    reader.onload = () => {
      resolve(reader.result);
    };
    reader.readAsDataURL(blob);
  });
}
/**
 * [1,2,3,4] -> [[1,2], [2,3], [3,4]]
 */
const getAdjacentPairs = a => (0,lodash_es__WEBPACK_IMPORTED_MODULE_5__["default"])((0,lodash_es__WEBPACK_IMPORTED_MODULE_2__["default"])(a), (0,lodash_es__WEBPACK_IMPORTED_MODULE_4__["default"])(a));
/** Create all combinations of input arrays
 * cartesian(['a', 'b'], [1, 2]) => [['a', 1], ['a', 2], ['b', 1], ['b', 2]]
 */
const cartesian = (...arr) => arr.reduce((a, b) => (0,lodash_es__WEBPACK_IMPORTED_MODULE_1__["default"])(a, c => b.map(d => [...c, d])), [[]]);
function time(_x2) {
  return _time.apply(this, arguments);
}
function _time() {
  _time = (0,_Users_smartcommunitylab_Desktop_newWork_playAndGo_playGo_node_modules_babel_runtime_helpers_esm_asyncToGenerator_js__WEBPACK_IMPORTED_MODULE_0__["default"])(function* (ms) {
    yield new Promise(resolve => {
      setTimeout(resolve, ms);
    });
  });
  return _time.apply(this, arguments);
}
function formatDurationToHoursAndMinutes(millis) {
  const duration = luxon__WEBPACK_IMPORTED_MODULE_6__.Duration.fromMillis(Math.abs(millis)).shiftTo('hours', 'minutes');
  const hours = duration.hours;
  const minutes = Math.round(duration.minutes);
  if (hours > 0) {
    return `${hours} h ${minutes} min`;
  } else {
    return `${minutes} min`;
  }
}
function trackByProperty(property) {
  return (index, item) => item[property];
}
const waitMs = ms => new Promise(resolve => setTimeout(resolve, ms));
window.safeStringify = safeStringify;
// Prints json like structure, but with [cycle] instead of repeating the same object
function safeStringify(obj) {
  const cache = new Set();
  return JSON.stringify(obj, (key, value) => {
    if (typeof value === 'object' && value !== null) {
      if (cache.has(value)) {
        return '[cycle]';
      }
      cache.add(value);
    }
    return value;
  }, 2);
}

/***/ }),

/***/ 7594:
/*!***********************************************************!*\
  !*** ./src/app/core/shared/plugin-mocks/AppPluginMock.ts ***!
  \***********************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   AppPluginMock: () => (/* binding */ AppPluginMock)
/* harmony export */ });
/* harmony import */ var _Users_smartcommunitylab_Desktop_newWork_playAndGo_playGo_node_modules_babel_runtime_helpers_esm_asyncToGenerator_js__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./node_modules/@babel/runtime/helpers/esm/asyncToGenerator.js */ 89204);
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! tslib */ 24398);
/* harmony import */ var _mock_utils__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! ./mock-utils */ 79880);



const mockMethod = (0,_mock_utils__WEBPACK_IMPORTED_MODULE_2__.getMockMethodAnnotation)({
  doLog: false,
  logPrefix: 'AppPluginMock'
});
class AppPluginMock {
  constructor() {
    throw new Error('static mock');
  }
  static getInfo() {
    return (0,_Users_smartcommunitylab_Desktop_newWork_playAndGo_playGo_node_modules_babel_runtime_helpers_esm_asyncToGenerator_js__WEBPACK_IMPORTED_MODULE_0__["default"])(function* () {
      return {
        version: 'dev'
      };
    })();
  }
}
(0,tslib__WEBPACK_IMPORTED_MODULE_1__.__decorate)([mockMethod({
  async: true
})], AppPluginMock, "getInfo", null);

/***/ }),

/***/ 8780:
/*!***********************************************************!*\
  !*** ./src/app/core/shared/services/refresher.service.ts ***!
  \***********************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   RefresherService: () => (/* binding */ RefresherService)
/* harmony export */ });
/* harmony import */ var rxjs__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! rxjs */ 10819);
/* harmony import */ var rxjs__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! rxjs */ 59452);
/* harmony import */ var rxjs__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! rxjs */ 52575);
/* harmony import */ var rxjs__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! rxjs */ 91817);
/* harmony import */ var rxjs__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! rxjs */ 51567);
/* harmony import */ var rxjs__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! rxjs */ 70271);
/* harmony import */ var rxjs__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! rxjs */ 32112);
/* harmony import */ var rxjs__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(/*! rxjs */ 36647);
/* harmony import */ var rxjs__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(/*! rxjs */ 98764);
/* harmony import */ var rxjs__WEBPACK_IMPORTED_MODULE_9__ = __webpack_require__(/*! rxjs */ 49973);
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_10__ = __webpack_require__(/*! @angular/core */ 34205);
var _staticBlock;


/**
 * This service is used to refresh the content of any page.
 *
 * In fact we have one global refresher. If some page will trigger refresher
 * all other pages / services which subscribe to `refreshed$` will be notified.
 *
 * This is usually little more data being refreshed that user wants, but not too much
 * During life of app usually only one page is "alive", rest of pages will have their
 * onDestroy called, which will unsubscribe observables and so also `refreshed$`.
 * So this is not a problem.
 *
 * (Ok there could be more then one page alive, due to ionic magic,
 * which could keep one page per tab to be alive, and only hide/show them
 * using css. But still no problem - at least these pages will have up to date
 * date when they will be shown again.)
 *
 * One challenging thing was how to hide refresher animation. As we have only one
 * global refreshing, page that initiated it, does not know when it is finished.
 * (it could be deep in some service)
 *
 * So we are doing similar thing as in spinnerService, and counting how many api calls
 * are ongoing. When there is no more api calls, we hide refresher.
 */
class RefresherService {
  constructor() {
    this.refreshSubject = new rxjs__WEBPACK_IMPORTED_MODULE_0__.Subject();
    this.refreshed$ = this.refreshSubject.asObservable();
    this.httpCallSubject = new rxjs__WEBPACK_IMPORTED_MODULE_0__.Subject();
    this.isHttpCallInProgress$ = this.httpCallSubject.pipe((0,rxjs__WEBPACK_IMPORTED_MODULE_6__.scan)((acc, curr) => acc + curr, 0), (0,rxjs__WEBPACK_IMPORTED_MODULE_5__.map)(count => count > 0), (0,rxjs__WEBPACK_IMPORTED_MODULE_3__.distinctUntilChanged)(), (0,rxjs__WEBPACK_IMPORTED_MODULE_8__.tap)(() => console.log('isHttpCallInProgress')),
    // if call is ended and another one is opened in the same time, we don't want to emit
    // we assume that is also second call is caused by same refresher...
    (0,rxjs__WEBPACK_IMPORTED_MODULE_2__.debounceTime)(100));
    // hide refresher when there is no more http calls, but max 3 seconds.
    this.shouldCompleteRefresh$ = this.refreshed$.pipe((0,rxjs__WEBPACK_IMPORTED_MODULE_7__.switchMap)(() => this.isHttpCallInProgress$.pipe((0,rxjs__WEBPACK_IMPORTED_MODULE_4__.filter)(isInProgress => !isInProgress), (0,rxjs__WEBPACK_IMPORTED_MODULE_5__.map)(() => null), (0,rxjs__WEBPACK_IMPORTED_MODULE_8__.tap)(() => console.log('should complete refresh')), (0,rxjs__WEBPACK_IMPORTED_MODULE_9__.timeout)({
      first: 3000,
      with: () => (0,rxjs__WEBPACK_IMPORTED_MODULE_1__.of)(null)
    }))));
    this.completeFunction = () => {};
    this.shouldCompleteRefresh$.subscribe(() => {
      this.completeFunction();
    });
  }
  onRefresh(event) {
    this.refreshSubject.next();
    if (event && event.detail) {
      this.completeFunction = event.detail.complete;
    }
  }
  httpCallStarted() {
    this.httpCallSubject.next(1);
  }
  httpCallEnded() {
    this.httpCallSubject.next(-1);
  }
  static #_ = _staticBlock = () => (this.ɵfac = function RefresherService_Factory(__ngFactoryType__) {
    return new (__ngFactoryType__ || RefresherService)();
  }, this.ɵprov = /*@__PURE__*/_angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵdefineInjectable"]({
    token: RefresherService,
    factory: RefresherService.ɵfac,
    providedIn: 'root'
  }));
}
_staticBlock();

/***/ }),

/***/ 9891:
/*!***************************************************************!*\
  !*** ./src/app/core/shared/services/local-storage.service.ts ***!
  \***************************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   LocalStorageService: () => (/* binding */ LocalStorageService)
/* harmony export */ });
/* harmony import */ var _Users_smartcommunitylab_Desktop_newWork_playAndGo_playGo_node_modules_babel_runtime_helpers_esm_asyncToGenerator_js__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./node_modules/@babel/runtime/helpers/esm/asyncToGenerator.js */ 89204);
/* harmony import */ var localforage_cordovasqlitedriver__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! localforage-cordovasqlitedriver */ 28376);
/* harmony import */ var localforage_cordovasqlitedriver__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(localforage_cordovasqlitedriver__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @angular/core */ 34205);
/* harmony import */ var _ionic_storage_angular__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @ionic/storage-angular */ 60850);

var _staticBlock;



class LocalStorageService {
  constructor(storageFactory) {
    this.storageFactory = storageFactory;
    this.storageInstancePromise = this.getStorageImplementation();
    // TODO:clear local storage automatically, after new app version (or code push version)
    // for consistency.
  }
  getStorageImplementation() {
    var _this = this;
    return (0,_Users_smartcommunitylab_Desktop_newWork_playAndGo_playGo_node_modules_babel_runtime_helpers_esm_asyncToGenerator_js__WEBPACK_IMPORTED_MODULE_0__["default"])(function* () {
      yield _this.storageFactory.defineDriver(localforage_cordovasqlitedriver__WEBPACK_IMPORTED_MODULE_1__);
      const storageInstance = yield _this.storageFactory.create();
      return storageInstance;
    })();
  }
  getStorageOf(localStorageKey) {
    return new LocalStorage(localStorageKey, this.storageInstancePromise);
  }
  clearAll() {
    var _this2 = this;
    return (0,_Users_smartcommunitylab_Desktop_newWork_playAndGo_playGo_node_modules_babel_runtime_helpers_esm_asyncToGenerator_js__WEBPACK_IMPORTED_MODULE_0__["default"])(function* () {
      const storage = yield _this2.storageInstancePromise;
      storage.clear();
    })();
  }
  static #_ = _staticBlock = () => (this.ɵfac = function LocalStorageService_Factory(__ngFactoryType__) {
    return new (__ngFactoryType__ || LocalStorageService)(_angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵinject"](_ionic_storage_angular__WEBPACK_IMPORTED_MODULE_3__.Storage));
  }, this.ɵprov = /*@__PURE__*/_angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵdefineInjectable"]({
    token: LocalStorageService,
    factory: LocalStorageService.ɵfac,
    providedIn: 'root'
  }));
}
_staticBlock();
class LocalStorage {
  constructor(storageKey, storageInstancePromise) {
    this.storageInstancePromise = storageInstancePromise;
    this.storageKey = 'playgo-storage-' + storageKey;
    this.storageMetaKey = 'playgo-storage-meta-' + storageKey;
  }
  set(data) {
    var _this3 = this;
    return (0,_Users_smartcommunitylab_Desktop_newWork_playAndGo_playGo_node_modules_babel_runtime_helpers_esm_asyncToGenerator_js__WEBPACK_IMPORTED_MODULE_0__["default"])(function* () {
      // hmm we could maybe use some sort of compression here
      // https://pieroxy.net/blog/pages/lz-string/index.html
      const storage = yield _this3.storageInstancePromise;
      yield storage.set(_this3.storageKey, JSON.stringify(data || null));
      const metaInformation = {
        lastUpdated: new Date().getTime()
      };
      yield storage.set(_this3.storageMetaKey, JSON.stringify(metaInformation));
    })();
  }
  get() {
    var _this4 = this;
    return (0,_Users_smartcommunitylab_Desktop_newWork_playAndGo_playGo_node_modules_babel_runtime_helpers_esm_asyncToGenerator_js__WEBPACK_IMPORTED_MODULE_0__["default"])(function* () {
      return yield _this4.getFromStorage(_this4.storageKey);
    })();
  }
  getMeta() {
    var _this5 = this;
    return (0,_Users_smartcommunitylab_Desktop_newWork_playAndGo_playGo_node_modules_babel_runtime_helpers_esm_asyncToGenerator_js__WEBPACK_IMPORTED_MODULE_0__["default"])(function* () {
      const meta = yield _this5.getFromStorage(_this5.storageMetaKey);
      const defaultMeta = {
        lastUpdated: 0
      };
      return meta ?? defaultMeta;
    })();
  }
  getFromStorage(key) {
    var _this6 = this;
    return (0,_Users_smartcommunitylab_Desktop_newWork_playAndGo_playGo_node_modules_babel_runtime_helpers_esm_asyncToGenerator_js__WEBPACK_IMPORTED_MODULE_0__["default"])(function* () {
      const storage = yield _this6.storageInstancePromise;
      const stringVal = yield storage.get(key);
      return JSON.parse(stringVal);
    })();
  }
  clear() {
    var _this7 = this;
    return (0,_Users_smartcommunitylab_Desktop_newWork_playAndGo_playGo_node_modules_babel_runtime_helpers_esm_asyncToGenerator_js__WEBPACK_IMPORTED_MODULE_0__["default"])(function* () {
      const storage = yield _this7.storageInstancePromise;
      yield storage.remove(_this7.storageKey);
      yield storage.remove(_this7.storageMetaKey);
    })();
  }
}

/***/ }),

/***/ 11454:
/*!**************************************************************************************************!*\
  !*** ./src/app/core/shared/campaigns/challenge-users-status/challenge-users-status.component.ts ***!
  \**************************************************************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   ChallengeUsersStatusComponent: () => (/* binding */ ChallengeUsersStatusComponent)
/* harmony export */ });
/* harmony import */ var rxjs__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! rxjs */ 70271);
/* harmony import */ var rxjs__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! rxjs */ 86301);
/* harmony import */ var rxjs__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! rxjs */ 36647);
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @angular/core */ 12481);
/* harmony import */ var src_app_core_shared_services_user_service__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! src/app/core/shared/services/user.service */ 89815);
/* harmony import */ var src_app_core_shared_services_error_service__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! src/app/core/shared/services/error.service */ 46078);
/* harmony import */ var _services_team_service__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! ../../services/team.service */ 62625);
/* harmony import */ var _angular_common__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(/*! @angular/common */ 93683);
/* harmony import */ var _ionic_angular__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(/*! @ionic/angular */ 21507);
var _staticBlock;







const _c0 = a0 => [a0];
function ChallengeUsersStatusComponent_div_0_ion_col_3_ng_container_1_ion_avatar_1_Template(rf, ctx) {
  if (rf & 1) {
    _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵelementStart"](0, "ion-avatar", 13);
    _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵelement"](1, "img", 14);
    _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵpipe"](2, "async");
    _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵelementEnd"]();
  }
  if (rf & 2) {
    let tmp_7_0;
    const ctx_r0 = _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵnextContext"](4);
    _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵadvance"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵproperty"]("src", (tmp_7_0 = _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵpipeBind1"](2, 1, ctx_r0.teamAvatar$)) == null ? null : tmp_7_0.avatarUrl, _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵsanitizeUrl"]);
  }
}
function ChallengeUsersStatusComponent_div_0_ion_col_3_ng_container_1_Template(rf, ctx) {
  if (rf & 1) {
    _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵelementContainerStart"](0);
    _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵtemplate"](1, ChallengeUsersStatusComponent_div_0_ion_col_3_ng_container_1_ion_avatar_1_Template, 3, 3, "ion-avatar", 12);
    _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵpipe"](2, "async");
    _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵelementContainerEnd"]();
  }
  if (rf & 2) {
    _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵnextContext"]();
    const alternativeAvatar_r2 = _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵreference"](5);
    const ctx_r0 = _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵnextContext"](2);
    _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵadvance"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵproperty"]("ngIf", _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵpipeBind1"](2, 2, ctx_r0.teamAvatar$))("ngIfElse", alternativeAvatar_r2);
  }
}
function ChallengeUsersStatusComponent_div_0_ion_col_3_ng_template_2_ion_avatar_0_Template(rf, ctx) {
  if (rf & 1) {
    _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵelementStart"](0, "ion-avatar");
    _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵelement"](1, "img", 14);
    _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵpipe"](2, "async");
    _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵelementEnd"]();
  }
  if (rf & 2) {
    const ctx_r0 = _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵnextContext"](4);
    _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵadvance"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵproperty"]("src", _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵpipeBind1"](2, 1, ctx_r0.playerAvatarUrl$), _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵsanitizeUrl"]);
  }
}
function ChallengeUsersStatusComponent_div_0_ion_col_3_ng_template_2_Template(rf, ctx) {
  if (rf & 1) {
    _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵtemplate"](0, ChallengeUsersStatusComponent_div_0_ion_col_3_ng_template_2_ion_avatar_0_Template, 3, 3, "ion-avatar", 8);
    _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵpipe"](1, "async");
  }
  if (rf & 2) {
    _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵnextContext"]();
    const alternativeAvatar_r2 = _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵreference"](5);
    const ctx_r0 = _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵnextContext"](2);
    _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵproperty"]("ngIf", _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵpipeBind1"](1, 2, ctx_r0.playerAvatarUrl$))("ngIfElse", alternativeAvatar_r2);
  }
}
function ChallengeUsersStatusComponent_div_0_ion_col_3_ng_template_4_Template(rf, ctx) {
  if (rf & 1) {
    _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵelementStart"](0, "ion-avatar");
    _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵelement"](1, "ion-icon", 15);
    _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵelementEnd"]();
  }
}
function ChallengeUsersStatusComponent_div_0_ion_col_3_Template(rf, ctx) {
  if (rf & 1) {
    _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵelementStart"](0, "ion-col", 11);
    _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵtemplate"](1, ChallengeUsersStatusComponent_div_0_ion_col_3_ng_container_1_Template, 3, 4, "ng-container", 8)(2, ChallengeUsersStatusComponent_div_0_ion_col_3_ng_template_2_Template, 2, 4, "ng-template", null, 0, _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵtemplateRefExtractor"])(4, ChallengeUsersStatusComponent_div_0_ion_col_3_ng_template_4_Template, 2, 0, "ng-template", null, 1, _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵtemplateRefExtractor"]);
    _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵelementEnd"]();
  }
  if (rf & 2) {
    const singlePlayer_r3 = _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵreference"](3);
    const ctx_r0 = _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵnextContext"](2);
    _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵadvance"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵproperty"]("ngIf", ctx_r0.kind === "team")("ngIfElse", singlePlayer_r3);
  }
}
function ChallengeUsersStatusComponent_div_0_ion_col_7_Template(rf, ctx) {
  if (rf & 1) {
    _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵelementStart"](0, "ion-col", 16);
    _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵelement"](1, "div", 17);
    _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵelementEnd"]();
  }
  if (rf & 2) {
    const ctx_r0 = _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵnextContext"](2);
    _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵproperty"]("ngClass", ctx_r0.isHome() ? "ion-margin-start" : "");
    _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵadvance"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵproperty"]("ngClass", _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵpureFunction1"](2, _c0, ctx_r0.isWinning(ctx_r0.status, ctx_r0.otherUser == null ? null : ctx_r0.otherUser.status) ? "arrow-up" : "arrow-down"));
  }
}
function ChallengeUsersStatusComponent_div_0_ng_container_9_Template(rf, ctx) {
  if (rf & 1) {
    _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵelementContainerStart"](0);
    _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵelementStart"](1, "span", 18);
    _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵtext"](2);
    _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵpipe"](3, "async");
    _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵelementEnd"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵelementContainerEnd"]();
  }
  if (rf & 2) {
    let tmp_3_0;
    const ctx_r0 = _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵnextContext"](2);
    _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵadvance"](2);
    _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵtextInterpolate"]((tmp_3_0 = _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵpipeBind1"](3, 1, ctx_r0.myTeam$)) == null ? null : tmp_3_0.customData == null ? null : tmp_3_0.customData.name);
  }
}
function ChallengeUsersStatusComponent_div_0_ng_template_10_Template(rf, ctx) {
  if (rf & 1) {
    _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵelementStart"](0, "span", 18);
    _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵtext"](1);
    _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵpipe"](2, "async");
    _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵelementEnd"]();
  }
  if (rf & 2) {
    let tmp_3_0;
    const ctx_r0 = _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵnextContext"](2);
    _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵadvance"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵtextInterpolate"]((tmp_3_0 = _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵpipeBind1"](2, 1, ctx_r0.profile$)) == null ? null : tmp_3_0.nickname);
  }
}
function ChallengeUsersStatusComponent_div_0_ion_row_12_Template(rf, ctx) {
  if (rf & 1) {
    _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵelementStart"](0, "ion-row", 5)(1, "ion-col")(2, "span", 19);
    _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵtext"](3);
    _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵelementEnd"]()()();
  }
  if (rf & 2) {
    const ctx_r0 = _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵnextContext"](2);
    _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵadvance"](3);
    _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵtextInterpolate1"]("", ctx_r0.status, "%");
  }
}
function ChallengeUsersStatusComponent_div_0_ion_row_13_Template(rf, ctx) {
  if (rf & 1) {
    _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵelementStart"](0, "ion-row")(1, "ion-col")(2, "span", 19);
    _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵtext"](3);
    _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵelementEnd"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵtext"](4, " Km");
    _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵelementEnd"]()();
  }
  if (rf & 2) {
    const ctx_r0 = _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵnextContext"](2);
    _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵadvance"](3);
    _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵtextInterpolate"](ctx_r0.rowStatus);
  }
}
function ChallengeUsersStatusComponent_div_0_ion_grid_15_ng_container_3_Template(rf, ctx) {
  if (rf & 1) {
    _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵelementContainerStart"](0);
    _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵelementStart"](1, "span", 18);
    _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵtext"](2);
    _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵpipe"](3, "async");
    _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵelementEnd"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵelementContainerEnd"]();
  }
  if (rf & 2) {
    let tmp_5_0;
    const ctx_r0 = _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵnextContext"](3);
    _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵadvance"](2);
    _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵtextInterpolate"]((tmp_5_0 = _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵpipeBind1"](3, 1, ctx_r0.otherTeam$)) == null ? null : tmp_5_0.customData == null ? null : tmp_5_0.customData.name);
  }
}
function ChallengeUsersStatusComponent_div_0_ion_grid_15_ng_template_4_Template(rf, ctx) {
  if (rf & 1) {
    _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵelementStart"](0, "span", 18);
    _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵtext"](1);
    _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵelementEnd"]();
  }
  if (rf & 2) {
    const ctx_r0 = _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵnextContext"](3);
    _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵadvance"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵtextInterpolate"](ctx_r0.otherUser == null ? null : ctx_r0.otherUser.nickname);
  }
}
function ChallengeUsersStatusComponent_div_0_ion_grid_15_ion_col_6_Template(rf, ctx) {
  if (rf & 1) {
    _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵelementStart"](0, "ion-col", 16);
    _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵelement"](1, "div", 17);
    _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵelementEnd"]();
  }
  if (rf & 2) {
    const ctx_r0 = _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵnextContext"](3);
    _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵproperty"]("ngClass", ctx_r0.isHome() ? "ion-margin-end" : "");
    _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵadvance"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵproperty"]("ngClass", _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵpureFunction1"](2, _c0, ctx_r0.isWinning(ctx_r0.otherUser == null ? null : ctx_r0.otherUser.status, ctx_r0.status) ? "arrow-up" : "arrow-down"));
  }
}
function ChallengeUsersStatusComponent_div_0_ion_grid_15_ion_row_7_Template(rf, ctx) {
  if (rf & 1) {
    _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵelementStart"](0, "ion-row", 20)(1, "ion-col")(2, "span", 24);
    _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵtext"](3);
    _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵelementEnd"]()()();
  }
  if (rf & 2) {
    const ctx_r0 = _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵnextContext"](3);
    _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵadvance"](3);
    _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵtextInterpolate1"]("", ctx_r0.otherUser.status, "%");
  }
}
function ChallengeUsersStatusComponent_div_0_ion_grid_15_ion_row_8_Template(rf, ctx) {
  if (rf & 1) {
    _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵelementStart"](0, "ion-row", 21)(1, "ion-col")(2, "span", 24);
    _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵtext"](3);
    _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵelementEnd"]()()();
  }
  if (rf & 2) {
    const ctx_r0 = _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵnextContext"](3);
    _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵadvance"](3);
    _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵtextInterpolate1"]("", ctx_r0.otherUser.row_status, " Km");
  }
}
function ChallengeUsersStatusComponent_div_0_ion_grid_15_Template(rf, ctx) {
  if (rf & 1) {
    _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵelementStart"](0, "ion-grid", 3)(1, "ion-row", 20)(2, "ion-col", 21);
    _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵtemplate"](3, ChallengeUsersStatusComponent_div_0_ion_grid_15_ng_container_3_Template, 4, 3, "ng-container", 8)(4, ChallengeUsersStatusComponent_div_0_ion_grid_15_ng_template_4_Template, 2, 1, "ng-template", null, 0, _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵtemplateRefExtractor"]);
    _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵelementEnd"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵtemplate"](6, ChallengeUsersStatusComponent_div_0_ion_grid_15_ion_col_6_Template, 2, 4, "ion-col", 6);
    _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵelementEnd"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵtemplate"](7, ChallengeUsersStatusComponent_div_0_ion_grid_15_ion_row_7_Template, 4, 1, "ion-row", 22)(8, ChallengeUsersStatusComponent_div_0_ion_grid_15_ion_row_8_Template, 4, 1, "ion-row", 23);
    _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵelementEnd"]();
  }
  if (rf & 2) {
    const singlePlayer_r4 = _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵreference"](5);
    const ctx_r0 = _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵnextContext"](2);
    _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵadvance"](3);
    _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵproperty"]("ngIf", ctx_r0.kind === "team")("ngIfElse", singlePlayer_r4);
    _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵadvance"](3);
    _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵproperty"]("ngIf", ctx_r0.isCompetitive() && !ctx_r0.isFuture());
    _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵadvance"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵproperty"]("ngIf", !ctx_r0.isHome() && !ctx_r0.isGroupCompetitivePerformance() && !ctx_r0.isFuture());
    _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵadvance"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵproperty"]("ngIf", !ctx_r0.isHome() && ctx_r0.unitHasKm && !ctx_r0.isFuture());
  }
}
function ChallengeUsersStatusComponent_div_0_ion_col_16_ng_container_1_ion_avatar_1_Template(rf, ctx) {
  if (rf & 1) {
    _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵelementStart"](0, "ion-avatar", 13);
    _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵelement"](1, "img", 14);
    _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵpipe"](2, "async");
    _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵelementEnd"]();
  }
  if (rf & 2) {
    let tmp_7_0;
    const ctx_r0 = _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵnextContext"](4);
    _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵadvance"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵproperty"]("src", (tmp_7_0 = _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵpipeBind1"](2, 1, ctx_r0.otherTeamAvatar$)) == null ? null : tmp_7_0.avatarUrl, _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵsanitizeUrl"]);
  }
}
function ChallengeUsersStatusComponent_div_0_ion_col_16_ng_container_1_Template(rf, ctx) {
  if (rf & 1) {
    _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵelementContainerStart"](0);
    _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵtemplate"](1, ChallengeUsersStatusComponent_div_0_ion_col_16_ng_container_1_ion_avatar_1_Template, 3, 3, "ion-avatar", 12);
    _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵpipe"](2, "async");
    _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵelementContainerEnd"]();
  }
  if (rf & 2) {
    _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵnextContext"]();
    const alternativeAvatar_r5 = _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵreference"](5);
    const ctx_r0 = _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵnextContext"](2);
    _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵadvance"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵproperty"]("ngIf", _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵpipeBind1"](2, 2, ctx_r0.otherTeamAvatar$))("ngIfElse", alternativeAvatar_r5);
  }
}
function ChallengeUsersStatusComponent_div_0_ion_col_16_ng_template_2_ion_avatar_0_Template(rf, ctx) {
  if (rf & 1) {
    _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵelementStart"](0, "ion-avatar");
    _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵelement"](1, "img", 14);
    _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵelementEnd"]();
  }
  if (rf & 2) {
    const ctx_r0 = _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵnextContext"](4);
    _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵadvance"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵproperty"]("src", ctx_r0.otherUser == null ? null : ctx_r0.otherUser.avatar == null ? null : ctx_r0.otherUser.avatar.url, _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵsanitizeUrl"]);
  }
}
function ChallengeUsersStatusComponent_div_0_ion_col_16_ng_template_2_Template(rf, ctx) {
  if (rf & 1) {
    _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵtemplate"](0, ChallengeUsersStatusComponent_div_0_ion_col_16_ng_template_2_ion_avatar_0_Template, 2, 1, "ion-avatar", 8);
  }
  if (rf & 2) {
    _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵnextContext"]();
    const alternativeAvatar_r5 = _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵreference"](5);
    const ctx_r0 = _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵnextContext"](2);
    _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵproperty"]("ngIf", ctx_r0.otherUser == null ? null : ctx_r0.otherUser.avatar == null ? null : ctx_r0.otherUser.avatar.url)("ngIfElse", alternativeAvatar_r5);
  }
}
function ChallengeUsersStatusComponent_div_0_ion_col_16_ng_template_4_Template(rf, ctx) {
  if (rf & 1) {
    _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵelementStart"](0, "ion-avatar");
    _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵelement"](1, "ion-icon", 15);
    _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵelementEnd"]();
  }
}
function ChallengeUsersStatusComponent_div_0_ion_col_16_Template(rf, ctx) {
  if (rf & 1) {
    _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵelementStart"](0, "ion-col", 11);
    _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵtemplate"](1, ChallengeUsersStatusComponent_div_0_ion_col_16_ng_container_1_Template, 3, 4, "ng-container", 8)(2, ChallengeUsersStatusComponent_div_0_ion_col_16_ng_template_2_Template, 1, 2, "ng-template", null, 0, _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵtemplateRefExtractor"])(4, ChallengeUsersStatusComponent_div_0_ion_col_16_ng_template_4_Template, 2, 0, "ng-template", null, 1, _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵtemplateRefExtractor"]);
    _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵelementEnd"]();
  }
  if (rf & 2) {
    const singlePlayer_r6 = _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵreference"](3);
    const ctx_r0 = _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵnextContext"](2);
    _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵadvance"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵproperty"]("ngIf", ctx_r0.kind === "team")("ngIfElse", singlePlayer_r6);
  }
}
function ChallengeUsersStatusComponent_div_0_Template(rf, ctx) {
  if (rf & 1) {
    _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵelementStart"](0, "div")(1, "ion-grid", 3)(2, "ion-row", 3);
    _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵtemplate"](3, ChallengeUsersStatusComponent_div_0_ion_col_3_Template, 6, 2, "ion-col", 4);
    _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵelementStart"](4, "ion-col")(5, "ion-grid", 3)(6, "ion-row", 5);
    _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵtemplate"](7, ChallengeUsersStatusComponent_div_0_ion_col_7_Template, 2, 4, "ion-col", 6);
    _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵelementStart"](8, "ion-col", 7);
    _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵtemplate"](9, ChallengeUsersStatusComponent_div_0_ng_container_9_Template, 4, 3, "ng-container", 8)(10, ChallengeUsersStatusComponent_div_0_ng_template_10_Template, 3, 3, "ng-template", null, 0, _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵtemplateRefExtractor"]);
    _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵelementEnd"]()();
    _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵtemplate"](12, ChallengeUsersStatusComponent_div_0_ion_row_12_Template, 4, 1, "ion-row", 9)(13, ChallengeUsersStatusComponent_div_0_ion_row_13_Template, 5, 1, "ion-row", 2);
    _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵelementEnd"]()();
    _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵelementStart"](14, "ion-col");
    _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵtemplate"](15, ChallengeUsersStatusComponent_div_0_ion_grid_15_Template, 9, 5, "ion-grid", 10);
    _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵelementEnd"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵtemplate"](16, ChallengeUsersStatusComponent_div_0_ion_col_16_Template, 6, 2, "ion-col", 4);
    _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵelementEnd"]()()();
  }
  if (rf & 2) {
    const singlePlayer_r7 = _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵreference"](11);
    const ctx_r0 = _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵnextContext"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵadvance"](3);
    _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵproperty"]("ngIf", !ctx_r0.isHome());
    _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵadvance"](4);
    _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵproperty"]("ngIf", ctx_r0.isCompetitive() && !ctx_r0.isFuture());
    _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵadvance"](2);
    _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵproperty"]("ngIf", ctx_r0.kind === "team")("ngIfElse", singlePlayer_r7);
    _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵadvance"](3);
    _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵproperty"]("ngIf", ctx_r0.status !== null && !ctx_r0.isHome() && !ctx_r0.isGroupCompetitivePerformance() && !ctx_r0.isFuture());
    _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵadvance"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵproperty"]("ngIf", ctx_r0.rowStatus !== null && !ctx_r0.isHome() && ctx_r0.unitHasKm && !ctx_r0.isFuture());
    _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵadvance"](2);
    _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵproperty"]("ngIf", ctx_r0.otherUser);
    _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵadvance"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵproperty"]("ngIf", ctx_r0.otherUser && !ctx_r0.isHome());
  }
}
class ChallengeUsersStatusComponent {
  // opponentAvatarUrl$: Observable<IUser['avatar']>;
  constructor(userService, errorService, teamService) {
    this.userService = userService;
    this.errorService = errorService;
    this.teamService = teamService;
    this.playerAvatarUrl$ = this.userService.userProfile$.pipe((0,rxjs__WEBPACK_IMPORTED_MODULE_0__.map)(userProfile => userProfile.avatar.avatarSmallUrl));
    this.profile$ = this.userService.userProfile$;
  }
  ngOnInit() {
    this.myTeam$ = this.teamService.getMyTeam(this.campaignContainer?.campaign?.campaignId, this.campaignContainer?.subscription?.campaignData?.teamId);
    this.teamAvatar$ = this.myTeam$.pipe((0,rxjs__WEBPACK_IMPORTED_MODULE_2__.switchMap)(myTeam => this.teamService.getTeamAvatar(myTeam.id).pipe(this.errorService.getErrorHandler())), (0,rxjs__WEBPACK_IMPORTED_MODULE_1__.shareReplay)(1));
    if (this.otherUser) {
      this.otherTeam$ = this.teamService.getPublicTeam(this.campaignContainer?.campaign?.campaignId, this.otherUser.playerId);
      this.otherTeamAvatar$ = this.otherTeam$.pipe((0,rxjs__WEBPACK_IMPORTED_MODULE_2__.switchMap)(otherTeam => this.teamService.getTeamAvatar(otherTeam.id).pipe(this.errorService.getErrorHandler())), (0,rxjs__WEBPACK_IMPORTED_MODULE_1__.shareReplay)(1));
    }
  }
  ngOnDestroy() {}
  isWinning(me, other) {
    if (me > other) {
      return true;
    }
    return false;
  }
  isFuture() {
    return this.type === 'future';
  }
  isCompetitive() {
    if (this.challengeType === 'groupCompetitiveTime' || this.challengeType === 'groupCompetitivePerformance') {
      return true;
    }
    return false;
  }
  isHome() {
    return this.position === 'home';
  }
  isGroupCompetitivePerformance() {
    return this.challengeType === 'groupCompetitivePerformance';
  }
  static #_ = _staticBlock = () => (this.ɵfac = function ChallengeUsersStatusComponent_Factory(__ngFactoryType__) {
    return new (__ngFactoryType__ || ChallengeUsersStatusComponent)(_angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵdirectiveInject"](src_app_core_shared_services_user_service__WEBPACK_IMPORTED_MODULE_4__.UserService), _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵdirectiveInject"](src_app_core_shared_services_error_service__WEBPACK_IMPORTED_MODULE_5__.ErrorService), _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵdirectiveInject"](_services_team_service__WEBPACK_IMPORTED_MODULE_6__.TeamService));
  }, this.ɵcmp = /*@__PURE__*/_angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵdefineComponent"]({
    type: ChallengeUsersStatusComponent,
    selectors: [["app-challenge-users-status"]],
    inputs: {
      status: "status",
      rowStatus: "rowStatus",
      type: "type",
      otherUser: "otherUser",
      position: "position",
      challengeType: "challengeType",
      unitHasKm: "unitHasKm",
      kind: "kind",
      campaignContainer: "campaignContainer"
    },
    standalone: false,
    decls: 1,
    vars: 1,
    consts: [["singlePlayer", ""], ["alternativeAvatar", ""], [4, "ngIf"], [1, "ion-no-padding"], ["size", "2", 4, "ngIf"], [1, "ion-align-items-center"], ["size", "1", 3, "ngClass", 4, "ngIf"], [1, "ion-text-start"], [4, "ngIf", "ngIfElse"], ["class", "ion-align-items-center", 4, "ngIf"], ["class", "ion-no-padding", 4, "ngIf"], ["size", "2"], ["class", "team", 4, "ngIf", "ngIfElse"], [1, "team"], [3, "src"], ["name", "person-circle-outline"], ["size", "1", 3, "ngClass"], [3, "ngClass"], [1, "ion-margin-start", "nickname-style"], [1, "ion-margin-start", "value-style"], [1, "ion-text-end", "ion-align-items-center"], [1, "ion-text-end"], ["class", "ion-text-end ion-align-items-center", 4, "ngIf"], ["class", "ion-text-end", 4, "ngIf"], [1, "ion-margin-end", "value-style"]],
    template: function ChallengeUsersStatusComponent_Template(rf, ctx) {
      if (rf & 1) {
        _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵtemplate"](0, ChallengeUsersStatusComponent_div_0_Template, 17, 8, "div", 2);
      }
      if (rf & 2) {
        _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵproperty"]("ngIf", !ctx.isFuture() || ctx.otherUser);
      }
    },
    dependencies: [_angular_common__WEBPACK_IMPORTED_MODULE_7__.NgClass, _angular_common__WEBPACK_IMPORTED_MODULE_7__.NgIf, _ionic_angular__WEBPACK_IMPORTED_MODULE_8__.IonAvatar, _ionic_angular__WEBPACK_IMPORTED_MODULE_8__.IonCol, _ionic_angular__WEBPACK_IMPORTED_MODULE_8__.IonGrid, _ionic_angular__WEBPACK_IMPORTED_MODULE_8__.IonIcon, _ionic_angular__WEBPACK_IMPORTED_MODULE_8__.IonRow, _angular_common__WEBPACK_IMPORTED_MODULE_7__.AsyncPipe],
    styles: [".team[_ngcontent-%COMP%] {\n  width: 42px;\n  height: 42px;\n}\n\n.nickname[_ngcontent-%COMP%] {\n  margin-top: 32px;\n}\n\nion-avatar[_ngcontent-%COMP%] {\n  width: 10vw;\n  height: 10vw;\n  margin: auto;\n  padding: 4px;\n}\nion-avatar[_ngcontent-%COMP%]   img[_ngcontent-%COMP%] {\n  object-fit: cover;\n  border-radius: 50% !important;\n  border: lightgray solid 1px;\n}\n\nion-icon[_ngcontent-%COMP%] {\n  width: 30px;\n  height: 30px;\n}\n\n.arrow-up[_ngcontent-%COMP%] {\n  width: 0;\n  height: 0;\n  border-left: 5px solid transparent;\n  border-right: 5px solid transparent;\n  border-bottom: 5px solid green;\n}\n\n.arrow-down[_ngcontent-%COMP%] {\n  width: 0;\n  height: 0;\n  border-left: 5px solid transparent;\n  border-right: 5px solid transparent;\n  border-top: 5px solid #f00;\n}\n\n.nickname-style[_ngcontent-%COMP%] {\n  font-style: normal;\n  font-weight: 700;\n  font-size: 14px;\n  white-space: nowrap;\n  overflow: hidden;\n  text-overflow: ellipsis;\n  -o-text-overflow: ellipsis;\n}\n\n.value-style[_ngcontent-%COMP%] {\n  font-style: normal;\n  font-weight: 300;\n  font-size: 15px;\n}\n/*# sourceMappingURL=data:application/json;charset=utf-8;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbIndlYnBhY2s6Ly8uL3NyYy9hcHAvY29yZS9zaGFyZWQvY2FtcGFpZ25zL2NoYWxsZW5nZS11c2Vycy1zdGF0dXMvY2hhbGxlbmdlLXVzZXJzLXN0YXR1cy5jb21wb25lbnQuc2NzcyJdLCJuYW1lcyI6W10sIm1hcHBpbmdzIjoiQUFBQTtFQUNFLFdBQUE7RUFDQSxZQUFBO0FBQ0Y7O0FBQ0E7RUFDRSxnQkFBQTtBQUVGOztBQUNBO0VBQ0UsV0FBQTtFQUNBLFlBQUE7RUFDQSxZQUFBO0VBTUEsWUFBQTtBQUhGO0FBRkU7RUFDRSxpQkFBQTtFQUNBLDZCQUFBO0VBQ0EsMkJBQUE7QUFJSjs7QUFBQTtFQUNFLFdBQUE7RUFDQSxZQUFBO0FBR0Y7O0FBREE7RUFDRSxRQUFBO0VBQ0EsU0FBQTtFQUNBLGtDQUFBO0VBQ0EsbUNBQUE7RUFFQSw4QkFBQTtBQUdGOztBQURBO0VBQ0UsUUFBQTtFQUNBLFNBQUE7RUFDQSxrQ0FBQTtFQUNBLG1DQUFBO0VBQ0EsMEJBQUE7QUFJRjs7QUFGQTtFQUNFLGtCQUFBO0VBQ0EsZ0JBQUE7RUFDQSxlQUFBO0VBQ0EsbUJBQUE7RUFDQSxnQkFBQTtFQUNBLHVCQUFBO0VBQ0EsMEJBQUE7QUFLRjs7QUFIQTtFQUNFLGtCQUFBO0VBQ0EsZ0JBQUE7RUFDQSxlQUFBO0FBTUYiLCJzb3VyY2VzQ29udGVudCI6WyIudGVhbSB7XG4gIHdpZHRoOiA0MnB4O1xuICBoZWlnaHQ6IDQycHg7XG59XG4ubmlja25hbWUge1xuICBtYXJnaW4tdG9wOiAzMnB4O1xufVxuXG5pb24tYXZhdGFyIHtcbiAgd2lkdGg6IDEwdnc7XG4gIGhlaWdodDogMTB2dztcbiAgbWFyZ2luOiBhdXRvO1xuICBpbWcge1xuICAgIG9iamVjdC1maXQ6IGNvdmVyO1xuICAgIGJvcmRlci1yYWRpdXM6IDUwJSAhaW1wb3J0YW50O1xuICAgIGJvcmRlcjogbGlnaHRncmF5IHNvbGlkIDFweDtcbiAgfVxuICBwYWRkaW5nOiA0cHg7XG59XG5pb24taWNvbiB7XG4gIHdpZHRoOiAzMHB4O1xuICBoZWlnaHQ6IDMwcHg7XG59XG4uYXJyb3ctdXAge1xuICB3aWR0aDogMDtcbiAgaGVpZ2h0OiAwO1xuICBib3JkZXItbGVmdDogNXB4IHNvbGlkIHRyYW5zcGFyZW50O1xuICBib3JkZXItcmlnaHQ6IDVweCBzb2xpZCB0cmFuc3BhcmVudDtcblxuICBib3JkZXItYm90dG9tOiA1cHggc29saWQgZ3JlZW47XG59XG4uYXJyb3ctZG93biB7XG4gIHdpZHRoOiAwO1xuICBoZWlnaHQ6IDA7XG4gIGJvcmRlci1sZWZ0OiA1cHggc29saWQgdHJhbnNwYXJlbnQ7XG4gIGJvcmRlci1yaWdodDogNXB4IHNvbGlkIHRyYW5zcGFyZW50O1xuICBib3JkZXItdG9wOiA1cHggc29saWQgI2YwMDtcbn1cbi5uaWNrbmFtZS1zdHlsZSB7XG4gIGZvbnQtc3R5bGU6IG5vcm1hbDtcbiAgZm9udC13ZWlnaHQ6IDcwMDtcbiAgZm9udC1zaXplOiAxNHB4O1xuICB3aGl0ZS1zcGFjZTogbm93cmFwO1xuICBvdmVyZmxvdzogaGlkZGVuO1xuICB0ZXh0LW92ZXJmbG93OiBlbGxpcHNpcztcbiAgLW8tdGV4dC1vdmVyZmxvdzogZWxsaXBzaXM7XG59XG4udmFsdWUtc3R5bGUge1xuICBmb250LXN0eWxlOiBub3JtYWw7XG4gIGZvbnQtd2VpZ2h0OiAzMDA7XG4gIGZvbnQtc2l6ZTogMTVweDtcbn1cbiJdLCJzb3VyY2VSb290IjoiIn0= */"]
  }));
}
_staticBlock();

/***/ }),

/***/ 11630:
/*!***********************************************************!*\
  !*** ./src/app/core/shared/services/territory.service.ts ***!
  \***********************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   TerritoryService: () => (/* binding */ TerritoryService)
/* harmony export */ });
/* harmony import */ var lodash_es__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! lodash-es */ 92434);
/* harmony import */ var rxjs__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! rxjs */ 19240);
/* harmony import */ var rxjs_operators__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! rxjs/operators */ 91817);
/* harmony import */ var rxjs_operators__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! rxjs/operators */ 86301);
/* harmony import */ var rxjs_operators__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! rxjs/operators */ 63037);
/* harmony import */ var rxjs_operators__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! rxjs/operators */ 36647);
/* harmony import */ var rxjs_operators__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! rxjs/operators */ 98764);
/* harmony import */ var _rxjs_utils__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(/*! ../rxjs.utils */ 86040);
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(/*! @angular/core */ 34205);
/* harmony import */ var _api_generated_controllers_territoryController_service__WEBPACK_IMPORTED_MODULE_9__ = __webpack_require__(/*! ../../api/generated/controllers/territoryController.service */ 70200);
/* harmony import */ var _local_storage_service__WEBPACK_IMPORTED_MODULE_10__ = __webpack_require__(/*! ./local-storage.service */ 9891);
/* harmony import */ var _error_service__WEBPACK_IMPORTED_MODULE_11__ = __webpack_require__(/*! ./error.service */ 46078);
var _staticBlock;









class TerritoryService {
  constructor(territoryControllerService, localStorageService, errorService) {
    this.territoryControllerService = territoryControllerService;
    this.localStorageService = localStorageService;
    this.errorService = errorService;
    this.territoriesStorage = this.localStorageService.getStorageOf('territories');
    this.territoryStorage = this.localStorageService.getStorageOf('territory');
    this.trigger$ = (0,rxjs__WEBPACK_IMPORTED_MODULE_1__.interval)(600000);
    this.territories$ = this.trigger$.pipe((0,rxjs_operators__WEBPACK_IMPORTED_MODULE_4__.startWith)(0), (0,rxjs_operators__WEBPACK_IMPORTED_MODULE_5__.switchMap)(triggerId => {
      const isFirstCall = triggerId === 0;
      return this.territoryControllerService.getTerritoriesUsingGET().pipe((0,_rxjs_utils__WEBPACK_IMPORTED_MODULE_7__.ifOfflineUseStored)(this.territoriesStorage), this.errorService.getErrorHandler(isFirstCall ? 'blocking' : 'silent'));
    }), (0,rxjs_operators__WEBPACK_IMPORTED_MODULE_2__.distinctUntilChanged)(lodash_es__WEBPACK_IMPORTED_MODULE_0__["default"]), (0,rxjs_operators__WEBPACK_IMPORTED_MODULE_6__.tap)(territory => this.territoriesStorage.set(territory)), (0,rxjs_operators__WEBPACK_IMPORTED_MODULE_3__.shareReplay)(1));
  }
  /**
   * Gets the territory by id. Works also offline.
   *
   * @throws http error
   */
  getTerritory(territoryId) {
    return this.territoryControllerService.getTerritoryUsingGET(territoryId).pipe((0,_rxjs_utils__WEBPACK_IMPORTED_MODULE_7__.ifOfflineUseStored)(this.territoryStorage, storedTerritory => storedTerritory.territoryId === territoryId), (0,rxjs_operators__WEBPACK_IMPORTED_MODULE_6__.tap)(territory => this.territoryStorage.set(territory)));
  }
  static #_ = _staticBlock = () => (this.ɵfac = function TerritoryService_Factory(__ngFactoryType__) {
    return new (__ngFactoryType__ || TerritoryService)(_angular_core__WEBPACK_IMPORTED_MODULE_8__["ɵɵinject"](_api_generated_controllers_territoryController_service__WEBPACK_IMPORTED_MODULE_9__.TerritoryControllerService), _angular_core__WEBPACK_IMPORTED_MODULE_8__["ɵɵinject"](_local_storage_service__WEBPACK_IMPORTED_MODULE_10__.LocalStorageService), _angular_core__WEBPACK_IMPORTED_MODULE_8__["ɵɵinject"](_error_service__WEBPACK_IMPORTED_MODULE_11__.ErrorService));
  }, this.ɵprov = /*@__PURE__*/_angular_core__WEBPACK_IMPORTED_MODULE_8__["ɵɵdefineInjectable"]({
    token: TerritoryService,
    factory: TerritoryService.ɵfac,
    providedIn: 'root'
  }));
}
_staticBlock();

/***/ }),

/***/ 12498:
/*!******************************************************************************************************************!*\
  !*** ./src/app/core/shared/detail-notification/detail-notification-badge/detail-notification-badge.component.ts ***!
  \******************************************************************************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   DetailNotificationBadgeComponent: () => (/* binding */ DetailNotificationBadgeComponent)
/* harmony export */ });
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! @angular/core */ 12481);
/* harmony import */ var _ionic_angular__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @ionic/angular */ 21507);
/* harmony import */ var _ui_icon_icon_component__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! ../../ui/icon/icon.component */ 59621);
/* harmony import */ var _angular_common__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @angular/common */ 93683);
/* harmony import */ var _ngx_translate_core__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! @ngx-translate/core */ 48503);
var _staticBlock;





class DetailNotificationBadgeComponent {
  constructor() {}
  ngOnInit() {}
  static #_ = _staticBlock = () => (this.ɵfac = function DetailNotificationBadgeComponent_Factory(__ngFactoryType__) {
    return new (__ngFactoryType__ || DetailNotificationBadgeComponent)();
  }, this.ɵcmp = /*@__PURE__*/_angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵdefineComponent"]({
    type: DetailNotificationBadgeComponent,
    selectors: [["app-detail-notification-badge"]],
    inputs: {
      notification: "notification"
    },
    standalone: false,
    decls: 14,
    vars: 6,
    consts: [[1, "ion-text-center"], ["name", "badges", 1, "icon-size-superbig"], [1, "ion-padding"]],
    template: function DetailNotificationBadgeComponent_Template(rf, ctx) {
      if (rf & 1) {
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](0, "ion-grid")(1, "ion-row")(2, "ion-col", 0);
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelement"](3, "app-icon", 1);
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]()();
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](4, "ion-row")(5, "ion-col", 0)(6, "p")(7, "b");
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵtext"](8);
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵpipe"](9, "translate");
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵpipe"](10, "uppercase");
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]()()()();
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](11, "ion-row")(12, "p", 2);
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵtext"](13);
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]()()();
      }
      if (rf & 2) {
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵadvance"](8);
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵtextInterpolate"](_angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵpipeBind1"](10, 4, _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵpipeBind1"](9, 2, "modal.newbadge")));
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵadvance"](5);
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵtextInterpolate1"](" ", ctx.notification.description, " ");
      }
    },
    dependencies: [_ionic_angular__WEBPACK_IMPORTED_MODULE_1__.IonCol, _ionic_angular__WEBPACK_IMPORTED_MODULE_1__.IonGrid, _ionic_angular__WEBPACK_IMPORTED_MODULE_1__.IonRow, _ui_icon_icon_component__WEBPACK_IMPORTED_MODULE_2__.IconComponent, _angular_common__WEBPACK_IMPORTED_MODULE_3__.UpperCasePipe, _ngx_translate_core__WEBPACK_IMPORTED_MODULE_4__.TranslatePipe],
    styles: ["/*# sourceMappingURL=data:application/json;charset=utf-8;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbXSwibmFtZXMiOltdLCJtYXBwaW5ncyI6IiIsInNvdXJjZVJvb3QiOiIifQ== */"]
  }));
}
_staticBlock();

/***/ }),

/***/ 12795:
/*!******************************************!*\
  !*** ./src/app/core/auth/auth.module.ts ***!
  \******************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   AuthModule: () => (/* binding */ AuthModule)
/* harmony export */ });
/* harmony import */ var _ionic_angular__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! @ionic/angular */ 4059);
/* harmony import */ var _openid_appauth_built_storage__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @openid/appauth/built/storage */ 88030);
/* harmony import */ var _openid_appauth_built_storage__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(_openid_appauth_built_storage__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var _openid_appauth_built_xhr__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @openid/appauth/built/xhr */ 58709);
/* harmony import */ var _openid_appauth_built_xhr__WEBPACK_IMPORTED_MODULE_2___default = /*#__PURE__*/__webpack_require__.n(_openid_appauth_built_xhr__WEBPACK_IMPORTED_MODULE_2__);
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @angular/core */ 12481);
/* harmony import */ var _angular_common__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! @angular/common */ 93683);
/* harmony import */ var ionic_appauth__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! ionic-appauth */ 94713);
/* harmony import */ var ionic_appauth_lib_capacitor__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! ionic-appauth/lib/capacitor */ 60910);
/* harmony import */ var _ng_http_service__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(/*! ./ng-http.service */ 33976);
/* harmony import */ var _factories__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(/*! ./factories */ 98486);
/* harmony import */ var _angular_common_http__WEBPACK_IMPORTED_MODULE_9__ = __webpack_require__(/*! @angular/common/http */ 63855);
/* harmony import */ var _auth_interceptor__WEBPACK_IMPORTED_MODULE_10__ = __webpack_require__(/*! ./auth.interceptor */ 35056);
/* harmony import */ var _shared_services_spinner_service__WEBPACK_IMPORTED_MODULE_11__ = __webpack_require__(/*! ../shared/services/spinner.service */ 74821);
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_12__ = __webpack_require__(/*! @angular/core */ 34205);
var _staticBlock;













class AuthModule {
  static #_ = _staticBlock = () => (this.ɵfac = function AuthModule_Factory(__ngFactoryType__) {
    return new (__ngFactoryType__ || AuthModule)();
  }, this.ɵmod = /*@__PURE__*/_angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵdefineNgModule"]({
    type: AuthModule
  }), this.ɵinj = /*@__PURE__*/_angular_core__WEBPACK_IMPORTED_MODULE_12__["ɵɵdefineInjector"]({
    providers: [{
      provide: _angular_common_http__WEBPACK_IMPORTED_MODULE_9__.HTTP_INTERCEPTORS,
      useClass: _auth_interceptor__WEBPACK_IMPORTED_MODULE_10__.AuthInterceptor,
      multi: true
    }, {
      provide: _openid_appauth_built_storage__WEBPACK_IMPORTED_MODULE_1__.StorageBackend,
      useClass: ionic_appauth_lib_capacitor__WEBPACK_IMPORTED_MODULE_6__.CapacitorSecureStorage
    }, {
      provide: _openid_appauth_built_xhr__WEBPACK_IMPORTED_MODULE_2__.Requestor,
      useClass: _ng_http_service__WEBPACK_IMPORTED_MODULE_7__.NgHttpService
    }, {
      provide: ionic_appauth__WEBPACK_IMPORTED_MODULE_5__.Browser,
      useClass: ionic_appauth_lib_capacitor__WEBPACK_IMPORTED_MODULE_6__.CapacitorBrowser
    }, {
      provide: 'IonicAppAuthService',
      useFactory: _factories__WEBPACK_IMPORTED_MODULE_8__.authFactory,
      deps: [_ionic_angular__WEBPACK_IMPORTED_MODULE_0__.Platform, _angular_core__WEBPACK_IMPORTED_MODULE_3__.NgZone, _openid_appauth_built_xhr__WEBPACK_IMPORTED_MODULE_2__.Requestor, ionic_appauth__WEBPACK_IMPORTED_MODULE_5__.Browser, _openid_appauth_built_storage__WEBPACK_IMPORTED_MODULE_1__.StorageBackend, _shared_services_spinner_service__WEBPACK_IMPORTED_MODULE_11__.SpinnerService]
    }],
    imports: [_angular_common__WEBPACK_IMPORTED_MODULE_4__.CommonModule, _angular_common_http__WEBPACK_IMPORTED_MODULE_9__.HttpClientModule]
  }));
}
_staticBlock();
(function () {
  (typeof ngJitMode === "undefined" || ngJitMode) && _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵsetNgModuleScope"](AuthModule, {
    imports: [_angular_common__WEBPACK_IMPORTED_MODULE_4__.CommonModule, _angular_common_http__WEBPACK_IMPORTED_MODULE_9__.HttpClientModule]
  });
})();

/***/ }),

/***/ 13875:
/*!*************************************************************!*\
  !*** ./src/app/core/shared/pipes/abstractObservablePipe.ts ***!
  \*************************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   AbstractObservablePipe: () => (/* binding */ AbstractObservablePipe)
/* harmony export */ });
/* harmony import */ var rxjs__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! rxjs */ 10819);
/* harmony import */ var rxjs__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! rxjs */ 59400);
/* harmony import */ var rxjs__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! rxjs */ 61318);
/* harmony import */ var rxjs__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! rxjs */ 91817);
/* harmony import */ var rxjs__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! rxjs */ 36647);
/* harmony import */ var rxjs__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! rxjs */ 33900);
/* harmony import */ var lodash_es__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! lodash-es */ 92434);


/**
 * Abstract class used to help creating efficient "push" pipes.
 *
 * Basically we would like to have a pipe that behaves like onPush component.
 * Being evaluated every time the input changes, but with ability to explicitly trigger a new value based
 * on observable.
 *
 * Sadly this is no possible right now, so this is a workaround. When using this class, you need to:
 * - implement `transformToObservable` method.
 * - use `super.doTransform` in `transform` method.
 * - use `super.destroy` in `ngOnDestroy` method.
 * - annotate your pipe with `@Pipe({ pure: false })`
 *
 */
class AbstractObservablePipe {
  constructor(ref) {
    this.pipeIsDestroyed$ = new rxjs__WEBPACK_IMPORTED_MODULE_0__.Subject();
    this.requestsToTransformSubject = new rxjs__WEBPACK_IMPORTED_MODULE_0__.Subject();
    this.formattedValue$ = this.requestsToTransformSubject.pipe((0,rxjs__WEBPACK_IMPORTED_MODULE_3__.distinctUntilChanged)(lodash_es__WEBPACK_IMPORTED_MODULE_6__["default"]), (0,rxjs__WEBPACK_IMPORTED_MODULE_4__.switchMap)(request => this.transformToObservable(request).pipe((0,rxjs__WEBPACK_IMPORTED_MODULE_2__.catchError)(e => {
      console.error(e);
      return rxjs__WEBPACK_IMPORTED_MODULE_1__.EMPTY;
    }))), (0,rxjs__WEBPACK_IMPORTED_MODULE_5__.takeUntil)(this.pipeIsDestroyed$));
    this.formattedValue = null;
    this.formattedValue$.subscribe(formattedValue => {
      this.formattedValue = formattedValue;
      // We actually do not have any means to output asynchronously value from the pipe,
      // so we force the change detection, and pipe will be re-evaluated. At this point we have
      // this.formattedValue set, and we will output it in the pipe. To avoid infinite loop, we use
      // distinctUntilChanged operator.
      ref.markForCheck();
    });
  }
  doTransform(input) {
    this.requestsToTransformSubject.next(input);
    return this.formattedValue;
  }
  destroy() {
    this.pipeIsDestroyed$.next();
    this.pipeIsDestroyed$.complete();
  }
}

/***/ }),

/***/ 14055:
/*!******************************************************************************************************************!*\
  !*** ./src/app/core/shared/campaigns/home-widget-types/home-campaign-company/home-campaign-company.component.ts ***!
  \******************************************************************************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   HomeCampaignCompanyComponent: () => (/* binding */ HomeCampaignCompanyComponent)
/* harmony export */ });
/* harmony import */ var luxon__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! luxon */ 45967);
/* harmony import */ var _time_utils__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ../../../time.utils */ 27780);
/* harmony import */ var _utils__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! ../../../utils */ 7497);
/* harmony import */ var _campaignUtils__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! ../../campaignUtils */ 83239);
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! @angular/core */ 12481);
/* harmony import */ var _services_user_service__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! ../../../services/user.service */ 89815);
/* harmony import */ var _services_report_service__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! ../../../services/report.service */ 40610);
/* harmony import */ var _services_error_service__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(/*! ../../../services/error.service */ 46078);
/* harmony import */ var _angular_common__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(/*! @angular/common */ 93683);
/* harmony import */ var _ionic_angular__WEBPACK_IMPORTED_MODULE_9__ = __webpack_require__(/*! @ionic/angular */ 21507);
/* harmony import */ var _main_campaign_stat_main_campaign_stat_component__WEBPACK_IMPORTED_MODULE_10__ = __webpack_require__(/*! ../../main-campaign-stat/main-campaign-stat.component */ 79238);
/* harmony import */ var _notification_badge_notification_badge_component__WEBPACK_IMPORTED_MODULE_11__ = __webpack_require__(/*! ../notification-badge/notification-badge.component */ 25211);
/* harmony import */ var _app_company_label_app_company_label_component__WEBPACK_IMPORTED_MODULE_12__ = __webpack_require__(/*! ../../app-company-label/app-company-label.component */ 63138);
/* harmony import */ var _ngx_translate_core__WEBPACK_IMPORTED_MODULE_13__ = __webpack_require__(/*! @ngx-translate/core */ 48503);
/* harmony import */ var _pipes_languageMap_pipe__WEBPACK_IMPORTED_MODULE_14__ = __webpack_require__(/*! ../../../pipes/languageMap.pipe */ 69618);
var _staticBlock;















const _c0 = a0 => ({
  "home-card-widget": a0
});
function HomeCampaignCompanyComponent_app_notification_badge_0_Template(rf, ctx) {
  if (rf & 1) {
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵelement"](0, "app-notification-badge", 9);
  }
  if (rf & 2) {
    const ctx_r0 = _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵnextContext"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵproperty"]("type", "campaign")("campaignContainer", ctx_r0.campaignContainer);
  }
}
function HomeCampaignCompanyComponent_div_5_Template(rf, ctx) {
  if (rf & 1) {
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵelementStart"](0, "div", 10)(1, "span");
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵtext"](2);
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵpipe"](3, "languageMap");
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵelementEnd"]()();
  }
  if (rf & 2) {
    const ctx_r0 = _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵnextContext"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵadvance"](2);
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵtextInterpolate1"](" ", _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵpipeBind1"](3, 1, ctx_r0.campaignContainer.campaign.name));
  }
}
function HomeCampaignCompanyComponent_ng_template_6_Template(rf, ctx) {
  if (rf & 1) {
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵelementStart"](0, "div")(1, "span");
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵtext"](2);
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵpipe"](3, "translate");
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵelementEnd"]()();
  }
  if (rf & 2) {
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵadvance"](2);
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵtextInterpolate1"](" ", _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵpipeBind1"](3, 1, "campaigns.detail.generalStat"));
  }
}
function HomeCampaignCompanyComponent_app_company_label_10_Template(rf, ctx) {
  if (rf & 1) {
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵelement"](0, "app-company-label", 11);
  }
  if (rf & 2) {
    const ctx_r0 = _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵnextContext"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵproperty"]("campaignContainer", ctx_r0.campaignContainer);
  }
}
class HomeCampaignCompanyComponent {
  constructor(userService, reportService, errorService) {
    this.userService = userService;
    this.reportService = reportService;
    this.errorService = errorService;
    this.header = false;
    this.confMetric = {
      scoreDailyLimit: {
        metric: 'virtualScore',
        period: [(0,_time_utils__WEBPACK_IMPORTED_MODULE_1__.toServerDateOnly)(luxon__WEBPACK_IMPORTED_MODULE_0__.DateTime.utc().startOf('day')), (0,_time_utils__WEBPACK_IMPORTED_MODULE_1__.toServerDateOnly)(luxon__WEBPACK_IMPORTED_MODULE_0__.DateTime.utc())]
      },
      scoreWeeklyLimit: {
        metric: 'virtualScore',
        period: [(0,_time_utils__WEBPACK_IMPORTED_MODULE_1__.toServerDateOnly)(luxon__WEBPACK_IMPORTED_MODULE_0__.DateTime.utc().startOf('week')), (0,_time_utils__WEBPACK_IMPORTED_MODULE_1__.toServerDateOnly)(luxon__WEBPACK_IMPORTED_MODULE_0__.DateTime.utc())]
      },
      scoreMonthlyLimit: {
        metric: 'virtualScore',
        period: [(0,_time_utils__WEBPACK_IMPORTED_MODULE_1__.toServerDateOnly)(luxon__WEBPACK_IMPORTED_MODULE_0__.DateTime.utc().startOf('month')), (0,_time_utils__WEBPACK_IMPORTED_MODULE_1__.toServerDateOnly)(luxon__WEBPACK_IMPORTED_MODULE_0__.DateTime.utc())]
      },
      trackDailyLimit: {
        metric: 'virtualTrack',
        period: [(0,_time_utils__WEBPACK_IMPORTED_MODULE_1__.toServerDateOnly)(luxon__WEBPACK_IMPORTED_MODULE_0__.DateTime.utc().startOf('day')), (0,_time_utils__WEBPACK_IMPORTED_MODULE_1__.toServerDateOnly)(luxon__WEBPACK_IMPORTED_MODULE_0__.DateTime.utc())]
      },
      trackWeeklyLimit: {
        metric: 'virtualTrack',
        period: [(0,_time_utils__WEBPACK_IMPORTED_MODULE_1__.toServerDateOnly)(luxon__WEBPACK_IMPORTED_MODULE_0__.DateTime.utc().startOf('week')), (0,_time_utils__WEBPACK_IMPORTED_MODULE_1__.toServerDateOnly)(luxon__WEBPACK_IMPORTED_MODULE_0__.DateTime.utc())]
      },
      trackMonthlyLimit: {
        metric: 'virtualTrack',
        period: [(0,_time_utils__WEBPACK_IMPORTED_MODULE_1__.toServerDateOnly)(luxon__WEBPACK_IMPORTED_MODULE_0__.DateTime.utc().startOf('month')), (0,_time_utils__WEBPACK_IMPORTED_MODULE_1__.toServerDateOnly)(luxon__WEBPACK_IMPORTED_MODULE_0__.DateTime.utc())]
      }
    };
  }
  ngOnInit() {
    this.virtualScoreLabel = this.campaignContainer?.campaign?.specificData?.virtualScore ? this.campaignContainer?.campaign?.specificData?.virtualScore?.label : '';
    this.imagePath = (0,_campaignUtils__WEBPACK_IMPORTED_MODULE_3__.getCampaignImage)(this.campaignContainer);
    this.subStat = this.userService.userProfile$.subscribe(profile => {
      this.profile = profile;
      if (this.campaignContainer) {
        this.getServiceFunction(this.campaignContainer, this.profile.playerId, this.campaignContainer.campaign.specificData.virtualScore.firstLimitBar).then(stats => {
          this.reportDayStat = stats;
          if (!this.campaignContainer?.campaign?.specificData?.virtualScore) {
            this.reportDayStat.value = this.reportDayStat.value / 1000;
          }
        }).catch(error => {
          if ((0,_utils__WEBPACK_IMPORTED_MODULE_2__.isOfflineError)(error)) {
            this.reportDayStat = null;
          } else {
            this.reportDayStat = null;
            this.errorService.handleError(error);
          }
        });
        if (this.campaignContainer.campaign.specificData.periods) {
          this.getLastPayment();
        }
        if (this.campaignContainer) {
          this.getServiceFunction(this.campaignContainer, this.profile.playerId, this.campaignContainer.campaign.specificData.virtualScore.secondLimitBar).then(stats => {
            this.reportMonthStat = stats;
            console.log(this.reportMonthStat?.value);
            if (!this.campaignContainer?.campaign?.specificData?.virtualScore) {
              this.reportMonthStat.value = this.reportMonthStat.value / 1000;
            }
            console.log(this.reportMonthStat?.value);
          }).catch(error => {
            if ((0,_utils__WEBPACK_IMPORTED_MODULE_2__.isOfflineError)(error)) {
              this.reportMonthStat = null;
            } else {
              this.reportMonthStat = null;
              this.errorService.handleError(error);
            }
          });
          this.reportService.getBikeStats(this.campaignContainer.campaign.campaignId, this.profile.playerId, null, null, this.virtualScoreLabel).then(stats => {
            console.log('stats', stats);
            this.reportTotalStat = stats;
            //if (!this.campaignContainer?.campaign?.specificData?.virtualScore) {
            //  console.log('divido', this.reportTotalStat.value, '/1000');
            //  this.reportTotalStat.value = this.reportTotalStat.value / 1000;
            //console.log('this.reportTotalStat.value', this.reportTotalStat.value);
            // }
          }).catch(error => {
            if ((0,_utils__WEBPACK_IMPORTED_MODULE_2__.isOfflineError)(error)) {
              this.reportTotalStat = null;
            } else {
              this.reportTotalStat = null;
              this.errorService.handleError(error);
            }
          });
        }
      }
    });
  }
  getServiceFunction(campaign, playerId, barName) {
    if (!barName) {
      return Promise.resolve(null);
    }
    return this.reportService.getBarStat(campaign.campaign.campaignId, playerId, this.getPeriod(barName)[0], this.getPeriod(barName)[1], this.getMetric(barName));
  }
  //first bar firstLimitBar
  getLimitMonthMax() {
    return this.campaignContainer?.campaign?.specificData?.virtualScore?.secondLimitBar ? this.campaignContainer?.campaign?.specificData?.virtualScore[this.campaignContainer?.campaign?.specificData?.virtualScore?.secondLimitBar] : null;
  }
  //secondBar secondLimitBar
  getLimitDayMax() {
    return this.campaignContainer?.campaign?.specificData?.virtualScore?.firstLimitBar ? this.campaignContainer?.campaign?.specificData?.virtualScore[this.campaignContainer?.campaign?.specificData?.virtualScore?.firstLimitBar] : null;
  }
  getUnit() {
    return this.campaignContainer?.campaign?.specificData?.virtualScore?.label ? this.campaignContainer?.campaign?.specificData?.virtualScore?.label : this.campaignContainer?.campaign?.specificData?.virtualScore ? this.virtualScoreLabel : 'Km';
  }
  getLastPayment() {
    const index = this.campaignContainer.campaign.specificData.periods.length - 1;
    if (index !== -1) {
      this.lastPaymentDate = this.campaignContainer.campaign.specificData.periods[index].start;
      this.lastPaymentDateTo = this.campaignContainer.campaign.specificData.periods[index].end;
      this.reportService.getTransportStatsByMeans(this.campaignContainer.campaign.campaignId, this.profile.playerId, this.campaignContainer?.campaign?.specificData?.virtualScore ? 'virtualScore' : 'km', this.campaignContainer?.campaign?.specificData?.virtualScore ? '' : '', this.campaignContainer?.campaign?.specificData?.virtualScore ? '' : 'bike', (0,_time_utils__WEBPACK_IMPORTED_MODULE_1__.toServerDateOnly)(luxon__WEBPACK_IMPORTED_MODULE_0__.DateTime.fromMillis(Number(this.lastPaymentDate)).toUTC()), (0,_time_utils__WEBPACK_IMPORTED_MODULE_1__.toServerDateOnly)(luxon__WEBPACK_IMPORTED_MODULE_0__.DateTime.fromMillis(Number(this.lastPaymentDateTo)).toUTC())).toPromise().then(stats => {
        this.lastPaymentStat = stats[0] ? stats[0] : {
          mean: null,
          period: null,
          value: 0
        };
      }).catch(error => {
        if ((0,_utils__WEBPACK_IMPORTED_MODULE_2__.isOfflineError)(error)) {
          this.reportDayStat = null;
        } else {
          this.reportDayStat = null;
          this.errorService.handleError(error);
        }
      });
    }
  }
  goToChallenge(event) {
    if (event && event.stopPropagation) {
      console.log('goToChallenge - stopPropagation');
      event.stopPropagation();
    }
    console.log('goToChallenge');
  }
  ngOnDestroy() {
    this.subStat.unsubscribe();
  }
  getMetric(barName) {
    return this.confMetric[barName]?.metric;
  }
  getPeriod(barName) {
    return this.confMetric[barName]?.period;
  }
  static #_ = _staticBlock = () => (this.ɵfac = function HomeCampaignCompanyComponent_Factory(__ngFactoryType__) {
    return new (__ngFactoryType__ || HomeCampaignCompanyComponent)(_angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵdirectiveInject"](_services_user_service__WEBPACK_IMPORTED_MODULE_5__.UserService), _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵdirectiveInject"](_services_report_service__WEBPACK_IMPORTED_MODULE_6__.ReportService), _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵdirectiveInject"](_services_error_service__WEBPACK_IMPORTED_MODULE_7__.ErrorService));
  }, this.ɵcmp = /*@__PURE__*/_angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵdefineComponent"]({
    type: HomeCampaignCompanyComponent,
    selectors: [["app-home-campaign-company"]],
    inputs: {
      campaignContainer: "campaignContainer",
      header: "header"
    },
    standalone: false,
    decls: 11,
    vars: 19,
    consts: [["detailHeader", ""], [3, "type", "campaignContainer", 4, "ngIf"], [3, "ngClass"], ["color", "company"], ["alt", "Avatar", 3, "src"], ["lines", "none", "color", "company", 4, "ngIf", "ngIfElse"], [1, "company-content", "ion-no-padding"], [3, "campaignContainer", "lastPaymentStat", "lastPaymentDate", "lastPaymentDateTo", "showRanking", "reportTotalStat", "limitMonthMax", "limitMonthValue", "limitDayMax", "limitDayValue", "unit"], [3, "campaignContainer", 4, "ngIf"], [3, "type", "campaignContainer"], ["lines", "none", "color", "company"], [3, "campaignContainer"]],
    template: function HomeCampaignCompanyComponent_Template(rf, ctx) {
      if (rf & 1) {
        _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵtemplate"](0, HomeCampaignCompanyComponent_app_notification_badge_0_Template, 1, 2, "app-notification-badge", 1);
        _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵelementStart"](1, "ion-card", 2)(2, "ion-card-header", 3)(3, "ion-avatar");
        _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵelement"](4, "img", 4);
        _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵtemplate"](5, HomeCampaignCompanyComponent_div_5_Template, 4, 3, "div", 5)(6, HomeCampaignCompanyComponent_ng_template_6_Template, 4, 3, "ng-template", null, 0, _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵtemplateRefExtractor"]);
        _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵelementStart"](8, "ion-card-content", 6);
        _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵelement"](9, "app-main-campaign-stat", 7);
        _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵtemplate"](10, HomeCampaignCompanyComponent_app_company_label_10_Template, 1, 1, "app-company-label", 8);
        _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵelementEnd"]()();
      }
      if (rf & 2) {
        const detailHeader_r2 = _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵreference"](7);
        _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵproperty"]("ngIf", ctx.header);
        _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵadvance"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵproperty"]("ngClass", _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵpureFunction1"](17, _c0, ctx.header));
        _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵadvance"](3);
        _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵproperty"]("src", ctx.imagePath, _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵsanitizeUrl"]);
        _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵadvance"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵproperty"]("ngIf", ctx.header)("ngIfElse", detailHeader_r2);
        _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵadvance"](4);
        _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵproperty"]("campaignContainer", ctx.campaignContainer)("lastPaymentStat", ctx.lastPaymentStat)("lastPaymentDate", ctx.lastPaymentDate)("lastPaymentDateTo", ctx.lastPaymentDateTo)("showRanking", false)("reportTotalStat", ctx.reportTotalStat)("limitMonthMax", ctx.getLimitMonthMax())("limitMonthValue", ctx.reportMonthStat)("limitDayMax", ctx.getLimitDayMax())("limitDayValue", ctx.reportDayStat)("unit", ctx.getUnit());
        _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵadvance"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵproperty"]("ngIf", !(ctx.campaignContainer == null ? null : ctx.campaignContainer.campaign == null ? null : ctx.campaignContainer.campaign.specificData.hideCompanyDesc));
      }
    },
    dependencies: [_angular_common__WEBPACK_IMPORTED_MODULE_8__.NgClass, _angular_common__WEBPACK_IMPORTED_MODULE_8__.NgIf, _ionic_angular__WEBPACK_IMPORTED_MODULE_9__.IonAvatar, _ionic_angular__WEBPACK_IMPORTED_MODULE_9__.IonCard, _ionic_angular__WEBPACK_IMPORTED_MODULE_9__.IonCardContent, _ionic_angular__WEBPACK_IMPORTED_MODULE_9__.IonCardHeader, _main_campaign_stat_main_campaign_stat_component__WEBPACK_IMPORTED_MODULE_10__.MainCampaignStatComponent, _notification_badge_notification_badge_component__WEBPACK_IMPORTED_MODULE_11__.NotificationBadgeComponent, _app_company_label_app_company_label_component__WEBPACK_IMPORTED_MODULE_12__.CompanyLabelComponent, _ngx_translate_core__WEBPACK_IMPORTED_MODULE_13__.TranslatePipe, _pipes_languageMap_pipe__WEBPACK_IMPORTED_MODULE_14__.LanguageMapPipe],
    styles: [".company-content[_ngcontent-%COMP%] {\n  color: black;\n}\n\nion-card[_ngcontent-%COMP%] {\n  overflow: visible;\n  padding-bottom: 8px;\n}\nion-card[_ngcontent-%COMP%]   #challenge[_ngcontent-%COMP%] {\n  overflow: visible;\n}\nion-card[_ngcontent-%COMP%]   ion-card-header[_ngcontent-%COMP%] {\n  border-radius: 10px 10px 0px 0px;\n  text-align: left;\n  font-size: 18px;\n  font-weight: 500;\n  padding: 12px;\n  margin-bottom: 24px;\n}\nion-card[_ngcontent-%COMP%]   ion-card-header[_ngcontent-%COMP%]   ion-avatar[_ngcontent-%COMP%] {\n  --border-radius: 50%;\n  border: solid 5px var(--ion-color-company);\n  background-color: var(--ion-color-company);\n  position: absolute;\n  z-index: 2;\n  text-align: center;\n  right: 12px;\n  bottom: -29px;\n  width: 64px;\n  height: 64px;\n}\n/*# sourceMappingURL=data:application/json;charset=utf-8;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbIndlYnBhY2s6Ly8uL3NyYy9hcHAvY29yZS9zaGFyZWQvY2FtcGFpZ25zL2hvbWUtd2lkZ2V0LXR5cGVzL2hvbWUtY2FtcGFpZ24tY29tcGFueS9ob21lLWNhbXBhaWduLWNvbXBhbnkuY29tcG9uZW50LnNjc3MiXSwibmFtZXMiOltdLCJtYXBwaW5ncyI6IkFBQUE7RUFDRSxZQUFBO0FBQ0Y7O0FBRUE7RUFDRSxpQkFBQTtFQUNBLG1CQUFBO0FBQ0Y7QUFBRTtFQUNFLGlCQUFBO0FBRUo7QUFBRTtFQUNFLGdDQUFBO0VBQ0EsZ0JBQUE7RUFDQSxlQUFBO0VBQ0EsZ0JBQUE7RUFDQSxhQUFBO0VBQ0EsbUJBQUE7QUFFSjtBQUFJO0VBQ0Usb0JBQUE7RUFDQSwwQ0FBQTtFQUNBLDBDQUFBO0VBQ0Esa0JBQUE7RUFDQSxVQUFBO0VBQ0Esa0JBQUE7RUFDQSxXQUFBO0VBQ0EsYUFBQTtFQUNBLFdBQUE7RUFDQSxZQUFBO0FBRU4iLCJzb3VyY2VzQ29udGVudCI6WyIuY29tcGFueS1jb250ZW50IHtcbiAgY29sb3I6IGJsYWNrO1xufVxuXG5pb24tY2FyZCB7XG4gIG92ZXJmbG93OiB2aXNpYmxlO1xuICBwYWRkaW5nLWJvdHRvbTogOHB4O1xuICAjY2hhbGxlbmdlIHtcbiAgICBvdmVyZmxvdzogdmlzaWJsZTtcbiAgfVxuICBpb24tY2FyZC1oZWFkZXIge1xuICAgIGJvcmRlci1yYWRpdXM6IDEwcHggMTBweCAwcHggMHB4O1xuICAgIHRleHQtYWxpZ246IGxlZnQ7XG4gICAgZm9udC1zaXplOiAxOHB4O1xuICAgIGZvbnQtd2VpZ2h0OiA1MDA7XG4gICAgcGFkZGluZzogMTJweDtcbiAgICBtYXJnaW4tYm90dG9tOiAyNHB4O1xuXG4gICAgaW9uLWF2YXRhciB7XG4gICAgICAtLWJvcmRlci1yYWRpdXM6IDUwJTtcbiAgICAgIGJvcmRlcjogc29saWQgNXB4IHZhcigtLWlvbi1jb2xvci1jb21wYW55KTtcbiAgICAgIGJhY2tncm91bmQtY29sb3I6IHZhcigtLWlvbi1jb2xvci1jb21wYW55KTtcbiAgICAgIHBvc2l0aW9uOiBhYnNvbHV0ZTtcbiAgICAgIHotaW5kZXg6IDI7XG4gICAgICB0ZXh0LWFsaWduOiBjZW50ZXI7XG4gICAgICByaWdodDogMTJweDtcbiAgICAgIGJvdHRvbTogLTI5cHg7XG4gICAgICB3aWR0aDogNjRweDtcbiAgICAgIGhlaWdodDogNjRweDtcbiAgICB9XG4gIH1cbn1cbiJdLCJzb3VyY2VSb290IjoiIn0= */"]
  }));
}
_staticBlock();

/***/ }),

/***/ 14691:
/*!*********************************************************!*\
  !*** ./src/app/core/shared/campaigns/campaign.utils.ts ***!
  \*********************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   getImgChallenge: () => (/* binding */ getImgChallenge),
/* harmony export */   getPeriods: () => (/* binding */ getPeriods),
/* harmony export */   getTypeStringChallenge: () => (/* binding */ getTypeStringChallenge)
/* harmony export */ });
function getImgChallenge(challengeType) {
  if (['groupCooperative', 'groupCompetitiveTime', 'groupCompetitivePerformance'].indexOf(challengeType) > -1) {
    return challengeType;
  }
  if ('survey' === challengeType) {
    return 'listCircle';
  }
  return 'default';
}
function getTypeStringChallenge(challengeType) {
  if (['groupCooperative', 'groupCompetitiveTime', 'groupCompetitivePerformance', 'survey'].indexOf(challengeType) > -1) {
    return 'challenges.challenge_model.name.' + challengeType;
  }
  return 'challenges.challenge_model.name.default';
}
function getPeriods(referenceDate) {
  return [{
    labelKey: 'campaigns.stats.filter.period.week',
    label: 'dd - MMM',
    group: 'day',
    format: 'dd-MM',
    chartFormat: 'EEE',
    add: 'week',
    switchTo: null,
    from: referenceDate.startOf('week'),
    to: referenceDate.endOf('week')
  }, {
    labelKey: 'campaigns.stats.filter.period.month',
    label: 'MMMM',
    group: 'week',
    format: 'dd-MM-yyyy',
    chartFormat: 'dd',
    add: 'month',
    switchTo: 'day',
    from: referenceDate.startOf('month'),
    to: referenceDate.endOf('month')
  }, {
    labelKey: 'campaigns.stats.filter.period.year',
    label: 'yyyy',
    group: 'month',
    format: 'MM-yyyy',
    chartFormat: 'MMM',
    add: 'year',
    switchTo: 'week',
    from: referenceDate.startOf('year'),
    to: referenceDate.endOf('year')
  }];
}

/***/ }),

/***/ 16024:
/*!*******************************************************!*\
  !*** ./src/app/core/shared/pipes/localNumber.pipe.ts ***!
  \*******************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   LocalNumberPipe: () => (/* binding */ LocalNumberPipe)
/* harmony export */ });
/* harmony import */ var _angular_common__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! @angular/common */ 93683);
/* harmony import */ var _abstractObservablePipe__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ./abstractObservablePipe */ 13875);
/* harmony import */ var rxjs__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! rxjs */ 70271);
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @angular/core */ 12481);
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! @angular/core */ 37580);
/* harmony import */ var _services_user_service__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! ../services/user.service */ 89815);
/* harmony import */ var _services_error_service__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! ../services/error.service */ 46078);
var _staticBlock;






class LocalNumberPipe extends _abstractObservablePipe__WEBPACK_IMPORTED_MODULE_1__.AbstractObservablePipe {
  constructor(userService, errorService, ref) {
    super(ref);
    this.userService = userService;
    this.errorService = errorService;
    this.ref = ref;
  }
  transform(value, format) {
    return this.doTransform({
      value,
      format
    });
  }
  transformToObservable(input) {
    return this.userService.userLocale$.pipe((0,rxjs__WEBPACK_IMPORTED_MODULE_2__.map)(locale => {
      try {
        return this.format(input.value, input.format, locale);
      } catch (e) {
        this.errorService.handleError(e, 'silent');
        return '';
      }
    }));
  }
  format(value, format, locale) {
    if (value == null) {
      return '';
    }
    if (!format) {
      format = '.2-2';
    }
    return (0,_angular_common__WEBPACK_IMPORTED_MODULE_0__.formatNumber)(value, locale, format);
  }
  static #_ = _staticBlock = () => (this.ɵfac = function LocalNumberPipe_Factory(__ngFactoryType__) {
    return new (__ngFactoryType__ || LocalNumberPipe)(_angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵdirectiveInject"](_services_user_service__WEBPACK_IMPORTED_MODULE_5__.UserService, 16), _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵdirectiveInject"](_services_error_service__WEBPACK_IMPORTED_MODULE_6__.ErrorService, 16), _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵdirectiveInject"](_angular_core__WEBPACK_IMPORTED_MODULE_4__.ChangeDetectorRef, 16));
  }, this.ɵpipe = /*@__PURE__*/_angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵdefinePipe"]({
    name: "localNumber",
    type: LocalNumberPipe,
    pure: false,
    standalone: false
  }));
}
_staticBlock();

/***/ }),

/***/ 16095:
/*!*****************************************************************************!*\
  !*** ./src/app/core/shared/services/notifications/notifications.service.ts ***!
  \*****************************************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   MAX_NOTIFICATIONS: () => (/* binding */ MAX_NOTIFICATIONS),
/* harmony export */   NOTIFICATION_TYPE_ACTIONS: () => (/* binding */ NOTIFICATION_TYPE_ACTIONS),
/* harmony export */   NotificationService: () => (/* binding */ NotificationService),
/* harmony export */   NotificationType: () => (/* binding */ NotificationType)
/* harmony export */ });
/* harmony import */ var _Users_smartcommunitylab_Desktop_newWork_playAndGo_playGo_node_modules_babel_runtime_helpers_esm_asyncToGenerator_js__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./node_modules/@babel/runtime/helpers/esm/asyncToGenerator.js */ 89204);
/* harmony import */ var rxjs__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! rxjs */ 10819);
/* harmony import */ var rxjs__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! rxjs */ 63617);
/* harmony import */ var rxjs__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! rxjs */ 79439);
/* harmony import */ var rxjs__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! rxjs */ 52575);
/* harmony import */ var rxjs__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! rxjs */ 70271);
/* harmony import */ var rxjs__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! rxjs */ 86301);
/* harmony import */ var rxjs__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(/*! rxjs */ 36647);
/* harmony import */ var rxjs__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(/*! rxjs */ 98764);
/* harmony import */ var rxjs__WEBPACK_IMPORTED_MODULE_9__ = __webpack_require__(/*! rxjs */ 12136);
/* harmony import */ var luxon__WEBPACK_IMPORTED_MODULE_10__ = __webpack_require__(/*! luxon */ 45967);
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_11__ = __webpack_require__(/*! @angular/core */ 34205);
/* harmony import */ var _local_storage_service__WEBPACK_IMPORTED_MODULE_12__ = __webpack_require__(/*! ../local-storage.service */ 9891);
/* harmony import */ var _error_service__WEBPACK_IMPORTED_MODULE_13__ = __webpack_require__(/*! ../error.service */ 46078);
/* harmony import */ var src_app_core_auth_auth_service__WEBPACK_IMPORTED_MODULE_14__ = __webpack_require__(/*! src/app/core/auth/auth.service */ 35524);
/* harmony import */ var src_app_core_api_generated_controllers_communicationAccountController_service__WEBPACK_IMPORTED_MODULE_15__ = __webpack_require__(/*! src/app/core/api/generated/controllers/communicationAccountController.service */ 48153);
/* harmony import */ var _pushNotification_service__WEBPACK_IMPORTED_MODULE_16__ = __webpack_require__(/*! ./pushNotification.service */ 47562);
/* harmony import */ var _refresher_service__WEBPACK_IMPORTED_MODULE_17__ = __webpack_require__(/*! ../refresher.service */ 8780);

var _staticBlock;









class NotificationService {
  constructor(localStorageService, errorService, authService, communicationAccountController, pushNotificationService, refresherService) {
    var _this = this;
    this.localStorageService = localStorageService;
    this.errorService = errorService;
    this.authService = authService;
    this.communicationAccountController = communicationAccountController;
    this.pushNotificationService = pushNotificationService;
    this.refresherService = refresherService;
    this.since = null;
    this.marked = false;
    this.notificationStorage = this.localStorageService.getStorageOf('notifications');
    this.appResumed$ = rxjs__WEBPACK_IMPORTED_MODULE_3__.NEVER;
    this.networkStatusChanged$ = rxjs__WEBPACK_IMPORTED_MODULE_3__.NEVER;
    this.notificationRead$ = new rxjs__WEBPACK_IMPORTED_MODULE_1__.Subject();
    this.pushNotification$ = this.pushNotificationService.notifications$;
    this.trigger$ = (0,rxjs__WEBPACK_IMPORTED_MODULE_2__.merge)(
    // this.afterSyncTimer$,
    this.authService.isReadyForApi$, this.appResumed$, this.networkStatusChanged$, this.pushNotification$, this.refresherService.refreshed$, this.notificationRead$).pipe((0,rxjs__WEBPACK_IMPORTED_MODULE_9__.throttleTime)(500));
    this.allNotifications$ = this.trigger$.pipe(
    // warning!! side effects!!!
    (0,rxjs__WEBPACK_IMPORTED_MODULE_7__.switchMap)(/*#__PURE__*/(0,_Users_smartcommunitylab_Desktop_newWork_playAndGo_playGo_node_modules_babel_runtime_helpers_esm_asyncToGenerator_js__WEBPACK_IMPORTED_MODULE_0__["default"])(function* () {
      if (_this.since === null) {
        const notifications = yield _this.notificationStorage?.get();
        if (notifications && notifications.length > 0) {
          console.log('DateTime.local().minus({ hour: 1 }).valueOf();' + luxon__WEBPACK_IMPORTED_MODULE_10__.DateTime.local().minus({
            hour: 1
          }).valueOf());
          _this.since = notifications[0]?.timestamp - 60 * 60 * 1000;
          console.log('since' + _this.since);
        } else {
          _this.since = 0;
          console.log('first time notifications');
        }
      }
      return _this.since;
    })), (0,rxjs__WEBPACK_IMPORTED_MODULE_7__.switchMap)(since => this.communicationAccountController.getPlayerNotificationsUsingGET({
      since,
      limit: 100
    }).pipe(this.errorService.getErrorHandler('silent'))), (0,rxjs__WEBPACK_IMPORTED_MODULE_7__.switchMap)(/*#__PURE__*/function () {
      var _ref2 = (0,_Users_smartcommunitylab_Desktop_newWork_playAndGo_playGo_node_modules_babel_runtime_helpers_esm_asyncToGenerator_js__WEBPACK_IMPORTED_MODULE_0__["default"])(function* (serverNotifications) {
        return [...((yield _this.notificationStorage.get()) || []), ...serverNotifications];
      });
      return function (_x) {
        return _ref2.apply(this, arguments);
      };
    }()), (0,rxjs__WEBPACK_IMPORTED_MODULE_5__.map)(allNotifications => allNotifications.filter((value, index, self) => index === self.findIndex(t => t.id === value.id))), (0,rxjs__WEBPACK_IMPORTED_MODULE_8__.tap)(/*#__PURE__*/function () {
      var _ref3 = (0,_Users_smartcommunitylab_Desktop_newWork_playAndGo_playGo_node_modules_babel_runtime_helpers_esm_asyncToGenerator_js__WEBPACK_IMPORTED_MODULE_0__["default"])(function* (allNotificationsWithoutDuplicates) {
        yield _this.notificationStorage.set(allNotificationsWithoutDuplicates.slice(0, MAX_NOTIFICATIONS));
        if (_this.since === 0) {
          _this.markAllNOtificationsAsRead();
        }
      });
      return function (_x2) {
        return _ref3.apply(this, arguments);
      };
    }()), (0,rxjs__WEBPACK_IMPORTED_MODULE_4__.debounceTime)(2000), (0,rxjs__WEBPACK_IMPORTED_MODULE_6__.shareReplay)(1));
    this.unreadNotifications$ = this.allNotifications$.pipe((0,rxjs__WEBPACK_IMPORTED_MODULE_5__.map)(notifications => notifications.filter(not => not.readed === false)), (0,rxjs__WEBPACK_IMPORTED_MODULE_6__.shareReplay)(1));
    this.readNotifications$ = this.allNotifications$.pipe((0,rxjs__WEBPACK_IMPORTED_MODULE_5__.map)(notifications => notifications.filter(not => not.readed === true)), (0,rxjs__WEBPACK_IMPORTED_MODULE_6__.shareReplay)(1));
    this.unreadAnnouncementNotifications$ = this.allNotifications$.pipe((0,rxjs__WEBPACK_IMPORTED_MODULE_5__.map)(notifications => notifications.filter(not => not.readed === false)), (0,rxjs__WEBPACK_IMPORTED_MODULE_5__.map)(notifications => notifications.filter(notification => !!notification.content && notification.content.type === NotificationType.announcement)),
    // tapLog('unreadAnnouncements'),
    (0,rxjs__WEBPACK_IMPORTED_MODULE_6__.shareReplay)(1));
    this.readedAnnouncementNotifications$ = this.allNotifications$.pipe((0,rxjs__WEBPACK_IMPORTED_MODULE_5__.map)(notifications => notifications.filter(not => not.readed === true)), (0,rxjs__WEBPACK_IMPORTED_MODULE_5__.map)(notifications => notifications.filter(notification => !!notification.content && notification.content.type === NotificationType.announcement)), (0,rxjs__WEBPACK_IMPORTED_MODULE_6__.shareReplay)(1));
    this.authService.isReadyForApi$.subscribe(() => {
      this.allNotifications$.subscribe(notifications => {
        if (notifications === null) {
          this.notificationStorage.set([]);
        }
      });
    });
  }
  initPush() {
    this.pushNotificationService.initPush();
  }
  getCampaignNotifications(campaignId) {
    return this.allNotifications$.pipe((0,rxjs__WEBPACK_IMPORTED_MODULE_5__.map)(notifications => notifications.filter(notification => notification.campaignId === campaignId && !!notification.content && NOTIFICATION_TYPE_ACTIONS.campaignWidgetBadge.types.includes(notification?.content?.type))));
  }
  getUnreadCampaignChallengeNotifications(campaignId) {
    return this.unreadNotifications$.pipe((0,rxjs__WEBPACK_IMPORTED_MODULE_5__.map)(notifications => notifications.filter(notification => notification.campaignId === campaignId && !!notification.content && NOTIFICATION_TYPE_ACTIONS.campaignWidgetChallengeBadge.types.includes(notification?.content?.type))));
  }
  getUnreadChallengeNotifications() {
    return this.unreadNotifications$.pipe((0,rxjs__WEBPACK_IMPORTED_MODULE_5__.map)(notifications => notifications.filter(notification => !!notification.content && NOTIFICATION_TYPE_ACTIONS.challengeTabBadge.types.includes(notification?.content?.type))));
  }
  getUnreadCampaignNotifications(campaignId) {
    return this.unreadNotifications$.pipe((0,rxjs__WEBPACK_IMPORTED_MODULE_5__.map)(notifications => notifications.filter(notification => notification.campaignId === campaignId && !!notification.content && NOTIFICATION_TYPE_ACTIONS.campaignWidgetBadge.types.includes(notification?.content?.type))));
  }
  getAnnouncementNotifications() {
    return this.allNotifications$.pipe((0,rxjs__WEBPACK_IMPORTED_MODULE_5__.map)(notifications => notifications.filter(notification => !!notification.content && NOTIFICATION_TYPE_ACTIONS.notificationBadge.types.includes(notification?.content?.type))));
  }
  markAllNOtificationsAsRead() {
    var _this2 = this;
    return (0,_Users_smartcommunitylab_Desktop_newWork_playAndGo_playGo_node_modules_babel_runtime_helpers_esm_asyncToGenerator_js__WEBPACK_IMPORTED_MODULE_0__["default"])(function* () {
      console.log('markAllNOtificationsAsRead');
      const storedNotifications = yield _this2.notificationStorage.get();
      storedNotifications?.forEach(notification => {
        _this2.markSingleNotificationAsRead(storedNotifications, notification);
      });
      _this2.notificationStorage.set(storedNotifications);
      //notify the new list of notifications
      if (!_this2.marked) {
        _this2.marked = true;
        _this2.notificationRead$.next();
      }
    })();
  }
  markAnnouncementAsRead() {
    var _this3 = this;
    return (0,_Users_smartcommunitylab_Desktop_newWork_playAndGo_playGo_node_modules_babel_runtime_helpers_esm_asyncToGenerator_js__WEBPACK_IMPORTED_MODULE_0__["default"])(function* () {
      console.log('markAnnouncementAsRead');
      const storedNotifications = yield _this3.notificationStorage.get();
      storedNotifications?.forEach(notification => {
        if (!!notification.content && notification.content.type === NotificationType.announcement) {
          _this3.markSingleNotificationAsRead(storedNotifications, notification);
        }
      });
      _this3.notificationStorage.set(storedNotifications);
      //notify the new list of notifications
      _this3.notificationRead$.next();
    })();
  }
  markCommonChallengeNotificationAsRead() {
    var _this4 = this;
    return (0,_Users_smartcommunitylab_Desktop_newWork_playAndGo_playGo_node_modules_babel_runtime_helpers_esm_asyncToGenerator_js__WEBPACK_IMPORTED_MODULE_0__["default"])(function* () {
      console.log('markCommonChallengeNotificationAsRead');
      const storedNotifications = yield _this4.notificationStorage.get();
      storedNotifications.forEach(notification => {
        if (!!notification.content && NOTIFICATION_TYPE_ACTIONS.challengeTabBadge.types.indexOf(notification.content.type) > -1) {
          _this4.markSingleNotificationAsRead(storedNotifications, notification);
        }
      });
      _this4.notificationStorage.set(storedNotifications);
      //notify the new list of notifications
      _this4.notificationRead$.next();
    })();
  }
  markListOfNotificationAsRead(notifications) {
    var _this5 = this;
    return (0,_Users_smartcommunitylab_Desktop_newWork_playAndGo_playGo_node_modules_babel_runtime_helpers_esm_asyncToGenerator_js__WEBPACK_IMPORTED_MODULE_0__["default"])(function* () {
      console.log('markListOfNotificationAsRead');
      const storedNotifications = yield _this5.notificationStorage.get();
      notifications.forEach(notification => {
        _this5.markSingleNotificationAsRead(storedNotifications, notification);
      });
      _this5.notificationStorage.set(storedNotifications);
      //notify the new list of notifications
      _this5.notificationRead$.next();
    })();
  }
  markSingleNotificationAsRead(storedNotifications, notification) {
    for (const not of storedNotifications) {
      if (not.id === notification.id) {
        not.readed = true;
        break;
      }
    }
  }
  static #_ = _staticBlock = () => (this.ɵfac = function NotificationService_Factory(__ngFactoryType__) {
    return new (__ngFactoryType__ || NotificationService)(_angular_core__WEBPACK_IMPORTED_MODULE_11__["ɵɵinject"](_local_storage_service__WEBPACK_IMPORTED_MODULE_12__.LocalStorageService), _angular_core__WEBPACK_IMPORTED_MODULE_11__["ɵɵinject"](_error_service__WEBPACK_IMPORTED_MODULE_13__.ErrorService), _angular_core__WEBPACK_IMPORTED_MODULE_11__["ɵɵinject"](src_app_core_auth_auth_service__WEBPACK_IMPORTED_MODULE_14__.AuthService), _angular_core__WEBPACK_IMPORTED_MODULE_11__["ɵɵinject"](src_app_core_api_generated_controllers_communicationAccountController_service__WEBPACK_IMPORTED_MODULE_15__.CommunicationAccountControllerService), _angular_core__WEBPACK_IMPORTED_MODULE_11__["ɵɵinject"](_pushNotification_service__WEBPACK_IMPORTED_MODULE_16__.PushNotificationService), _angular_core__WEBPACK_IMPORTED_MODULE_11__["ɵɵinject"](_refresher_service__WEBPACK_IMPORTED_MODULE_17__.RefresherService));
  }, this.ɵprov = /*@__PURE__*/_angular_core__WEBPACK_IMPORTED_MODULE_11__["ɵɵdefineInjectable"]({
    token: NotificationService,
    factory: NotificationService.ɵfac,
    providedIn: 'root'
  }));
}
_staticBlock();
const MAX_NOTIFICATIONS = 500;
var NotificationType;
(function (NotificationType) {
  NotificationType["level"] = "level";
  NotificationType["badge"] = "badge";
  NotificationType["programChallenge"] = "program_challenge";
  NotificationType["newInvite"] = "new_invite";
  NotificationType["replyAccepted"] = "reply_accepted";
  NotificationType["replyDenied"] = "reply_denied";
  NotificationType["challengeCancel"] = "challenge_cancel";
  NotificationType["challengeAssigned"] = "challenge_assigned";
  NotificationType["challengeComplete"] = "challenge_complete";
  NotificationType["challengeFailed"] = "challenge_failed";
  NotificationType["announcement"] = "announcement";
  NotificationType["bonus"] = "bonus";
})(NotificationType || (NotificationType = {}));
const NOTIFICATION_TYPE_ACTIONS = {
  campaignWidgetBadge: {
    types: [NotificationType.level, NotificationType.badge]
  },
  challengeTabBadge: {
    types: [NotificationType.programChallenge, NotificationType.newInvite, NotificationType.replyAccepted, NotificationType.replyDenied, NotificationType.challengeCancel, NotificationType.challengeAssigned, NotificationType.challengeComplete, NotificationType.challengeFailed]
  },
  campaignWidgetChallengeBadge: {
    types: [NotificationType.programChallenge, NotificationType.newInvite, NotificationType.replyAccepted, NotificationType.replyDenied, NotificationType.challengeCancel, NotificationType.challengeAssigned, NotificationType.challengeComplete, NotificationType.challengeFailed]
  },
  notificationBadge: {
    types: [NotificationType.announcement]
  }
};

/***/ }),

/***/ 16561:
/*!***********************************************************!*\
  !*** ./src/app/core/shared/services/challenge.service.ts ***!
  \***********************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   ChallengeService: () => (/* binding */ ChallengeService)
/* harmony export */ });
/* harmony import */ var _Users_smartcommunitylab_Desktop_newWork_playAndGo_playGo_node_modules_babel_runtime_helpers_esm_asyncToGenerator_js__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./node_modules/@babel/runtime/helpers/esm/asyncToGenerator.js */ 89204);
/* harmony import */ var lodash_es__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! lodash-es */ 50300);
/* harmony import */ var rxjs__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! rxjs */ 56042);
/* harmony import */ var rxjs__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! rxjs */ 56196);
/* harmony import */ var rxjs__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! rxjs */ 19999);
/* harmony import */ var rxjs__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! rxjs */ 61873);
/* harmony import */ var rxjs__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! rxjs */ 63617);
/* harmony import */ var rxjs__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(/*! rxjs */ 59452);
/* harmony import */ var rxjs__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(/*! rxjs */ 61318);
/* harmony import */ var rxjs__WEBPACK_IMPORTED_MODULE_9__ = __webpack_require__(/*! rxjs */ 70271);
/* harmony import */ var rxjs__WEBPACK_IMPORTED_MODULE_10__ = __webpack_require__(/*! rxjs */ 86301);
/* harmony import */ var rxjs__WEBPACK_IMPORTED_MODULE_11__ = __webpack_require__(/*! rxjs */ 36647);
/* harmony import */ var rxjs__WEBPACK_IMPORTED_MODULE_12__ = __webpack_require__(/*! rxjs */ 15842);
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_13__ = __webpack_require__(/*! @angular/core */ 34205);
/* harmony import */ var _campaign_service__WEBPACK_IMPORTED_MODULE_14__ = __webpack_require__(/*! ./campaign.service */ 76658);
/* harmony import */ var _api_generated_controllers_challengeController_service__WEBPACK_IMPORTED_MODULE_15__ = __webpack_require__(/*! ../../api/generated/controllers/challengeController.service */ 79811);
/* harmony import */ var _error_service__WEBPACK_IMPORTED_MODULE_16__ = __webpack_require__(/*! ./error.service */ 46078);
/* harmony import */ var _refresher_service__WEBPACK_IMPORTED_MODULE_17__ = __webpack_require__(/*! ./refresher.service */ 8780);
/* harmony import */ var _notifications_pushNotification_service__WEBPACK_IMPORTED_MODULE_18__ = __webpack_require__(/*! ./notifications/pushNotification.service */ 47562);
/* harmony import */ var _user_service__WEBPACK_IMPORTED_MODULE_19__ = __webpack_require__(/*! ./user.service */ 89815);

var _staticBlock;









class ChallengeService {
  constructor(campaignService, challengeControllerService, errorService, refresherService, pushNotificationService, userService) {
    this.campaignService = campaignService;
    this.challengeControllerService = challengeControllerService;
    this.errorService = errorService;
    this.refresherService = refresherService;
    this.pushNotificationService = pushNotificationService;
    this.userService = userService;
    this.campaignsWithChallenges$ = this.campaignService.myCampaigns$.pipe((0,rxjs__WEBPACK_IMPORTED_MODULE_9__.map)(campaigns =>
    // TODO: ask if the condition is correct
    campaigns.filter(campaign => campaign.campaign.type === 'city' || campaign.campaign.type === 'school')), (0,rxjs__WEBPACK_IMPORTED_MODULE_10__.shareReplay)(1));
    this.challengesChangedSubject = new rxjs__WEBPACK_IMPORTED_MODULE_2__.ReplaySubject(1);
    this.challengesCouldBeChanged$ = (0,rxjs__WEBPACK_IMPORTED_MODULE_6__.merge)(this.campaignsWithChallenges$, this.challengesChangedSubject, this.refresherService.refreshed$, this.pushNotificationService.notifications$).pipe((0,rxjs__WEBPACK_IMPORTED_MODULE_12__.withLatestFrom)(this.campaignsWithChallenges$), (0,rxjs__WEBPACK_IMPORTED_MODULE_9__.map)(([trigger, campaigns]) => campaigns));
    this.canInvite$ = this.campaignsWithChallenges$.pipe((0,rxjs__WEBPACK_IMPORTED_MODULE_11__.switchMap)(campaigns => (0,rxjs__WEBPACK_IMPORTED_MODULE_5__.forkJoin)(campaigns.map(campaign => this.challengeControllerService.getChallengesUsingGET({
      campaignId: campaign.campaign.campaignId
    }).pipe(this.errorService.getErrorHandler('silent'), (0,rxjs__WEBPACK_IMPORTED_MODULE_9__.map)(response => this.processResponseForCanInvite(response, campaign))))).pipe((0,rxjs__WEBPACK_IMPORTED_MODULE_9__.map)(challengesPerCampaign => (0,lodash_es__WEBPACK_IMPORTED_MODULE_1__["default"])(challengesPerCampaign))))).pipe((0,rxjs__WEBPACK_IMPORTED_MODULE_10__.shareReplay)(1));
    this.allChallengesTeam$ = this.challengesCouldBeChanged$.pipe((0,rxjs__WEBPACK_IMPORTED_MODULE_11__.switchMap)(campaigns => (0,rxjs__WEBPACK_IMPORTED_MODULE_5__.forkJoin)(campaigns.map(campaign => {
      if (campaign?.campaign && campaign.subscription?.campaignData?.teamId) {
        return this.challengeControllerService.getChallengesByTeamUsingGET({
          campaignId: campaign.campaign.campaignId,
          teamId: campaign.subscription?.campaignData?.teamId
        }).pipe((0,rxjs__WEBPACK_IMPORTED_MODULE_8__.catchError)(error => {
          this.errorService.handleError(error, 'silent');
          return (0,rxjs__WEBPACK_IMPORTED_MODULE_7__.of)(null);
        }), (0,rxjs__WEBPACK_IMPORTED_MODULE_9__.map)(response => this.processResponseForOneCampaign(response, campaign, "team")));
      } else {
        return (0,rxjs__WEBPACK_IMPORTED_MODULE_7__.of)(null);
      }
    })).pipe((0,rxjs__WEBPACK_IMPORTED_MODULE_9__.map)(challengesPerCampaign => (0,lodash_es__WEBPACK_IMPORTED_MODULE_1__["default"])(challengesPerCampaign))))).pipe((0,rxjs__WEBPACK_IMPORTED_MODULE_10__.shareReplay)(1));
    this.allChallenges$ = this.challengesCouldBeChanged$.pipe((0,rxjs__WEBPACK_IMPORTED_MODULE_11__.switchMap)(campaigns => (0,rxjs__WEBPACK_IMPORTED_MODULE_5__.forkJoin)(campaigns.map(campaign => {
      if (campaign?.campaign) {
        return this.challengeControllerService.getChallengesUsingGET({
          campaignId: campaign.campaign.campaignId
        }).pipe((0,rxjs__WEBPACK_IMPORTED_MODULE_8__.catchError)(error => {
          this.errorService.handleError(error, 'silent');
          return (0,rxjs__WEBPACK_IMPORTED_MODULE_7__.of)(null);
        }), (0,rxjs__WEBPACK_IMPORTED_MODULE_9__.map)(response => this.processResponseForOneCampaign(response, campaign, "single")));
      } else {
        return (0,rxjs__WEBPACK_IMPORTED_MODULE_7__.of)(null);
      }
    })).pipe((0,rxjs__WEBPACK_IMPORTED_MODULE_9__.map)(challengesPerCampaign => (0,lodash_es__WEBPACK_IMPORTED_MODULE_1__["default"])(challengesPerCampaign))))).pipe((0,rxjs__WEBPACK_IMPORTED_MODULE_10__.shareReplay)(1));
    // public allChallenges$: Observable<Challenge[]> = this.campaignsWithChallenges$
    //   .pipe(
    //     switchMap((campaigns) =>
    //       forkJoin(
    //         campaigns.map((campaign) =>
    //           this.challengeControllerService
    //             .getChallengesUsingGET({
    //               campaignId: campaign.campaign.campaignId,
    //             })
    //             .pipe(
    //               this.errorService.getErrorHandler(),
    //               map((response) =>
    //                 this.processResponseForOneCampaign(response, campaign)
    //               )
    //             )
    //         )
    //       ).pipe(map((challengesPerCampaign) => flatten(challengesPerCampaign)))
    //     )
    //   )
    //   .pipe(shareReplay(1));
    //team challenges
    this.activeChallengesTeam$ = this.allChallengesTeam$.pipe((0,rxjs__WEBPACK_IMPORTED_MODULE_9__.map)(challenges => challenges.filter(challenge => challenge?.challengeType === 'ACTIVE')), (0,rxjs__WEBPACK_IMPORTED_MODULE_10__.shareReplay)(1));
    this.pastChallengesTeam$ = this.allChallengesTeam$.pipe((0,rxjs__WEBPACK_IMPORTED_MODULE_9__.map)(challenges => challenges.filter(challenge => challenge?.challengeType === 'OLD')), (0,rxjs__WEBPACK_IMPORTED_MODULE_10__.shareReplay)(1));
    this.proposedChallengesTeam$ = this.allChallengesTeam$.pipe((0,rxjs__WEBPACK_IMPORTED_MODULE_9__.map)(challenges => challenges.filter(challenge => challenge?.challengeType === 'PROPOSED')), (0,rxjs__WEBPACK_IMPORTED_MODULE_10__.shareReplay)(1));
    this.onlyFutureChallengesTeam$ = this.allChallengesTeam$.pipe((0,rxjs__WEBPACK_IMPORTED_MODULE_9__.map)(challenges => challenges.filter(challenge => challenge?.challengeType === 'FUTURE')), (0,rxjs__WEBPACK_IMPORTED_MODULE_10__.shareReplay)(1));
    this.futureChallengesTeam$ = this.allChallengesTeam$.pipe((0,rxjs__WEBPACK_IMPORTED_MODULE_9__.map)(challenges => challenges.filter(challenge => challenge?.challengeType === 'FUTURE' || challenge?.challengeType === 'PROPOSED'), (0,rxjs__WEBPACK_IMPORTED_MODULE_10__.shareReplay)(1)));
    // single challenges
    this.activeChallenges$ = this.allChallenges$.pipe((0,rxjs__WEBPACK_IMPORTED_MODULE_9__.map)(challenges => challenges.filter(challenge => challenge?.challengeType === 'ACTIVE')), (0,rxjs__WEBPACK_IMPORTED_MODULE_10__.shareReplay)(1));
    this.pastChallenges$ = this.allChallenges$.pipe((0,rxjs__WEBPACK_IMPORTED_MODULE_9__.map)(challenges => challenges.filter(challenge => challenge.challengeType === 'OLD')), (0,rxjs__WEBPACK_IMPORTED_MODULE_10__.shareReplay)(1));
    this.proposedChallenges$ = this.allChallenges$.pipe((0,rxjs__WEBPACK_IMPORTED_MODULE_9__.map)(challenges => challenges.filter(challenge => challenge.challengeType === 'PROPOSED')), (0,rxjs__WEBPACK_IMPORTED_MODULE_10__.shareReplay)(1));
    this.onlyFutureChallenges$ = this.allChallenges$.pipe((0,rxjs__WEBPACK_IMPORTED_MODULE_9__.map)(challenges => challenges.filter(challenge => challenge.challengeType === 'FUTURE')), (0,rxjs__WEBPACK_IMPORTED_MODULE_10__.shareReplay)(1));
    this.futureChallenges$ = this.allChallenges$.pipe((0,rxjs__WEBPACK_IMPORTED_MODULE_9__.map)(challenges => challenges.filter(challenge => challenge.challengeType === 'FUTURE' || challenge.challengeType === 'PROPOSED'), (0,rxjs__WEBPACK_IMPORTED_MODULE_10__.shareReplay)(1)));
  }
  processResponseForOneCampaign(response, campaign, kind) {
    if (response) {
      const challengesPerOneCampaign = Object.entries(response.challengeData).map(([challengeType, challenges]) => challenges.map(challenge => ({
        ...challenge,
        challengeType: challengeType,
        campaign: campaign.campaign,
        kind
      })));
      const challengesOfAllTypesPerOneCampaign = (0,lodash_es__WEBPACK_IMPORTED_MODULE_1__["default"])(challengesPerOneCampaign);
      return challengesOfAllTypesPerOneCampaign;
    } else {
      return [];
    }
  }
  processResponseForCanInvite(response, campaign) {
    return {
      canInvite: response.canInvite,
      campaign: campaign.campaign
    };
  }
  getChallengeStats(arg0) {
    return this.challengeControllerService.getChallengeStatsUsingGET(arg0);
  }
  canInviteByCampaign(campaignId) {
    return this.canInvite$.pipe((0,rxjs__WEBPACK_IMPORTED_MODULE_9__.map)(canInvites => canInvites.filter(canInvite => canInvite?.campaign?.campaignId === campaignId && canInvite?.canInvite === true).length > 0), (0,rxjs__WEBPACK_IMPORTED_MODULE_10__.shareReplay)(1));
  }
  getAllChallengesByCampaign(campaignId) {
    return this.allChallenges$.pipe((0,rxjs__WEBPACK_IMPORTED_MODULE_9__.map)(challenges => challenges.filter(challenge => challenge?.campaign?.campaignId === campaignId)), (0,rxjs__WEBPACK_IMPORTED_MODULE_10__.shareReplay)(1));
  }
  getBlacklistByCampaign(campaignId) {
    return this.challengeControllerService.getBlackListUsingGET(campaignId);
  }
  getActiveChallengesByCampaign(campaignId) {
    return this.activeChallenges$.pipe((0,rxjs__WEBPACK_IMPORTED_MODULE_9__.map)(challenges => challenges.filter(challenge => challenge?.campaign?.campaignId === campaignId)), (0,rxjs__WEBPACK_IMPORTED_MODULE_10__.shareReplay)(1));
  }
  getActiveChallengesTeamByCampaign(campaignId) {
    return this.activeChallengesTeam$.pipe((0,rxjs__WEBPACK_IMPORTED_MODULE_9__.map)(challenges => challenges.filter(challenge => challenge?.campaign?.campaignId === campaignId)), (0,rxjs__WEBPACK_IMPORTED_MODULE_10__.shareReplay)(1));
  }
  //get invitations from other user with proposer !== from my id
  getInvitesChallengesByCampaign(campaignId) {
    return (0,rxjs__WEBPACK_IMPORTED_MODULE_4__.combineLatest)([this.userService.userProfile$, this.proposedChallenges$]).pipe((0,rxjs__WEBPACK_IMPORTED_MODULE_11__.switchMap)(([profile, challenges]) => (0,rxjs__WEBPACK_IMPORTED_MODULE_7__.of)(challenges.filter(challenge => challenge?.campaign?.campaignId === campaignId).filter(challenge => challenge.proposerId !== null && challenge.proposerId !== profile.playerId))), (0,rxjs__WEBPACK_IMPORTED_MODULE_10__.shareReplay)(1));
  }
  configurableChallenges(campaignId) {
    return (0,rxjs__WEBPACK_IMPORTED_MODULE_4__.combineLatest)([this.userService.userProfile$, this.canInvite$, this.proposedChallenges$]).pipe((0,rxjs__WEBPACK_IMPORTED_MODULE_11__.switchMap)(([profile, caninvites, challenges]) =>
    //filter by campaign id challenges proposed and if I can invite number of proposed (no invites) so
    //  challenge.proposerId == something and sendinvites is true
    (0,rxjs__WEBPACK_IMPORTED_MODULE_7__.of)(challenges.filter(challenge => challenge?.campaign?.campaignId === campaignId).filter(challenge => challenge.proposerId === null))), (0,rxjs__WEBPACK_IMPORTED_MODULE_10__.shareReplay)(1));
  }
  // of(challenges.filter(
  //   (challenge) => challenge?.campaign?.campaignId === campaignId
  // ).filter((challenge) => challenge.proposerId !== profile.playerId)),
  getActiveUncompletedChallengesByCampaign(campaignId) {
    return this.activeChallenges$.pipe((0,rxjs__WEBPACK_IMPORTED_MODULE_9__.map)(challenges => challenges.filter(challenge => challenge?.campaign?.campaignId === campaignId && !challenge?.success)), (0,rxjs__WEBPACK_IMPORTED_MODULE_9__.map)(challenges => challenges.sort((a, b) => b.status - a.status)), (0,rxjs__WEBPACK_IMPORTED_MODULE_10__.shareReplay)(1));
  }
  getActiveUncompletedChallengesTeamByCampaign(campaignId) {
    return this.activeChallengesTeam$.pipe((0,rxjs__WEBPACK_IMPORTED_MODULE_9__.map)(challenges => challenges.filter(challenge => challenge?.campaign?.campaignId === campaignId && !challenge?.success)), (0,rxjs__WEBPACK_IMPORTED_MODULE_9__.map)(challenges => challenges.sort((a, b) => b.status - a.status)), (0,rxjs__WEBPACK_IMPORTED_MODULE_10__.shareReplay)(1));
  }
  getPastChallengesByCampaign(campaignId) {
    return this.pastChallenges$.pipe((0,rxjs__WEBPACK_IMPORTED_MODULE_9__.map)(challenges => challenges.filter(challenge => challenge?.campaign?.campaignId === campaignId)), (0,rxjs__WEBPACK_IMPORTED_MODULE_10__.shareReplay)(1));
  }
  getOnlyFutureChallengesByCampaign(campaignId) {
    return this.onlyFutureChallenges$.pipe((0,rxjs__WEBPACK_IMPORTED_MODULE_9__.map)(challenges => challenges.filter(challenge => challenge?.campaign?.campaignId === campaignId)), (0,rxjs__WEBPACK_IMPORTED_MODULE_10__.shareReplay)(1));
  }
  getFutureChallengesByCampaign(campaignId) {
    return this.futureChallenges$.pipe((0,rxjs__WEBPACK_IMPORTED_MODULE_9__.map)(challenges => challenges.filter(challenge => challenge?.campaign?.campaignId === campaignId)), (0,rxjs__WEBPACK_IMPORTED_MODULE_10__.shareReplay)(1));
  }
  removeBlacklist(campaignId, playerId) {
    return this.challengeControllerService.deleteFromBlackListUsingDELETE({
      campaignId,
      blockedPlayerId: playerId
    }).toPromise();
  }
  addBlacklist(campaignId, playerId) {
    return this.challengeControllerService.addToBlackListUsingPOST({
      campaignId,
      blockedPlayerId: playerId
    }).toPromise();
  }
  acceptSingleChallenge(campaign, challenge) {
    var _this = this;
    return (0,_Users_smartcommunitylab_Desktop_newWork_playAndGo_playGo_node_modules_babel_runtime_helpers_esm_asyncToGenerator_js__WEBPACK_IMPORTED_MODULE_0__["default"])(function* () {
      const response = yield (0,rxjs__WEBPACK_IMPORTED_MODULE_3__.firstValueFrom)(_this.challengeControllerService.chooseChallengeUsingPUT({
        challengeId: challenge.challId,
        campaignId: campaign.campaign.campaignId
      }));
      _this.challengesChangedSubject.next();
      return response;
    })();
  }
  acceptChallenge(campaign, challenge) {
    var _this2 = this;
    return (0,_Users_smartcommunitylab_Desktop_newWork_playAndGo_playGo_node_modules_babel_runtime_helpers_esm_asyncToGenerator_js__WEBPACK_IMPORTED_MODULE_0__["default"])(function* () {
      const response = yield (0,rxjs__WEBPACK_IMPORTED_MODULE_3__.firstValueFrom)(_this2.challengeControllerService.changeInvitationStatusUsingPOST({
        campaignId: campaign.campaign.campaignId,
        challengeId: challenge.challId,
        status: 'accept'
      }));
      _this2.challengesChangedSubject.next();
      return response;
    })();
  }
  rejectChallenge(campaign, challenge) {
    var _this3 = this;
    return (0,_Users_smartcommunitylab_Desktop_newWork_playAndGo_playGo_node_modules_babel_runtime_helpers_esm_asyncToGenerator_js__WEBPACK_IMPORTED_MODULE_0__["default"])(function* () {
      const res = yield _this3.challengeControllerService.changeInvitationStatusUsingPOST({
        campaignId: campaign.campaign.campaignId,
        challengeId: challenge.challId,
        status: 'refuse'
      }).toPromise();
      _this3.challengesChangedSubject.next(null);
      return res;
    })();
  }
  cancelChallenge(campaign, challenge) {
    var _this4 = this;
    return (0,_Users_smartcommunitylab_Desktop_newWork_playAndGo_playGo_node_modules_babel_runtime_helpers_esm_asyncToGenerator_js__WEBPACK_IMPORTED_MODULE_0__["default"])(function* () {
      const res = yield (0,rxjs__WEBPACK_IMPORTED_MODULE_3__.firstValueFrom)(_this4.challengeControllerService.changeInvitationStatusUsingPOST({
        campaignId: campaign.campaign.campaignId,
        challengeId: challenge.challId,
        status: 'cancel'
      }));
      _this4.challengesChangedSubject.next(null);
      return res;
    })();
  }
  sendInvitation(invitationParams) {
    var _this5 = this;
    return (0,_Users_smartcommunitylab_Desktop_newWork_playAndGo_playGo_node_modules_babel_runtime_helpers_esm_asyncToGenerator_js__WEBPACK_IMPORTED_MODULE_0__["default"])(function* () {
      const invitation = yield (0,rxjs__WEBPACK_IMPORTED_MODULE_3__.firstValueFrom)(_this5.challengeControllerService.sendInvitationUsingPOST(invitationParams));
      _this5.challengesChangedSubject.next();
      return invitation;
    })();
  }
  static #_ = _staticBlock = () => (this.ɵfac = function ChallengeService_Factory(__ngFactoryType__) {
    return new (__ngFactoryType__ || ChallengeService)(_angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵinject"](_campaign_service__WEBPACK_IMPORTED_MODULE_14__.CampaignService), _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵinject"](_api_generated_controllers_challengeController_service__WEBPACK_IMPORTED_MODULE_15__.ChallengeControllerService), _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵinject"](_error_service__WEBPACK_IMPORTED_MODULE_16__.ErrorService), _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵinject"](_refresher_service__WEBPACK_IMPORTED_MODULE_17__.RefresherService), _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵinject"](_notifications_pushNotification_service__WEBPACK_IMPORTED_MODULE_18__.PushNotificationService), _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵinject"](_user_service__WEBPACK_IMPORTED_MODULE_19__.UserService));
  }, this.ɵprov = /*@__PURE__*/_angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵdefineInjectable"]({
    token: ChallengeService,
    factory: ChallengeService.ɵfac,
    providedIn: 'root'
  }));
}
_staticBlock();

/***/ }),

/***/ 18128:
/*!**********************************************************************!*\
  !*** ./src/app/core/shared/notification-modal/notification.modal.ts ***!
  \**********************************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   NotificationModalPage: () => (/* binding */ NotificationModalPage)
/* harmony export */ });
/* harmony import */ var _capacitor_browser__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! @capacitor/browser */ 26515);
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @angular/core */ 12481);
/* harmony import */ var _ionic_angular__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @ionic/angular */ 21507);
/* harmony import */ var _ngx_translate_core__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @ngx-translate/core */ 48503);
var _staticBlock;




const _c0 = ["class", "modal"];
class NotificationModalPage {
  constructor(modalController, elementRef) {
    this.modalController = modalController;
    this.elementRef = elementRef;
    this.handleAnchorClick = event => {
      // Prevent opening anchors the default way
      event.preventDefault();
      const anchor = event.target;
      _capacitor_browser__WEBPACK_IMPORTED_MODULE_0__.Browser.open({
        url: anchor.href,
        windowName: '_system',
        presentationStyle: 'popover'
      });
    };
  }
  ngOnInit() {}
  ngAfterViewInit() {
    //change the behaviour of _blank arrived with editor, adding a new listener and opening a browser
    this.anchors = this.elementRef.nativeElement.querySelectorAll('a');
    this.anchors.forEach(anchor => {
      anchor.addEventListener('click', this.handleAnchorClick);
    });
  }
  close() {
    this.modalController.dismiss(false);
  }
  static #_ = _staticBlock = () => (this.ɵfac = function NotificationModalPage_Factory(__ngFactoryType__) {
    return new (__ngFactoryType__ || NotificationModalPage)(_angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵdirectiveInject"](_ionic_angular__WEBPACK_IMPORTED_MODULE_2__.ModalController), _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵdirectiveInject"](_angular_core__WEBPACK_IMPORTED_MODULE_1__.ElementRef));
  }, this.ɵcmp = /*@__PURE__*/_angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵdefineComponent"]({
    type: NotificationModalPage,
    selectors: [["app-notification", 8, "modal"]],
    standalone: false,
    attrs: _c0,
    decls: 17,
    vars: 5,
    consts: [["color", "playgo"], [1, "ion-text-center"], ["slot", "end"], [3, "click"], ["name", "close-circle-outline"], ["color", "light", "expand", "block", 3, "click"]],
    template: function NotificationModalPage_Template(rf, ctx) {
      if (rf & 1) {
        _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵelementStart"](0, "ion-header")(1, "ion-toolbar", 0)(2, "ion-title", 1);
        _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵtext"](3);
        _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵelementStart"](4, "ion-buttons", 2)(5, "ion-button", 3);
        _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵlistener"]("click", function NotificationModalPage_Template_ion_button_click_5_listener() {
          return ctx.close();
        });
        _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵelement"](6, "ion-icon", 4);
        _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵelementEnd"]()()()();
        _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵelementStart"](7, "ion-content", 0)(8, "ion-grid")(9, "ion-row")(10, "ion-col")(11, "p");
        _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵtext"](12);
        _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵelementEnd"]()()()()();
        _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵelementStart"](13, "ion-footer")(14, "ion-button", 5);
        _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵlistener"]("click", function NotificationModalPage_Template_ion_button_click_14_listener() {
          return ctx.close();
        });
        _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵtext"](15);
        _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵpipe"](16, "translate");
        _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵelementEnd"]()();
      }
      if (rf & 2) {
        _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵadvance"](3);
        _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵtextInterpolate1"](" ", ctx.notification.data.title, " ");
        _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵadvance"](9);
        _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵtextInterpolate"](ctx.notification.data.body);
        _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵadvance"](3);
        _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵtextInterpolate"](_angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵpipeBind1"](16, 3, "notifications.close"));
      }
    },
    dependencies: [_ionic_angular__WEBPACK_IMPORTED_MODULE_2__.IonButton, _ionic_angular__WEBPACK_IMPORTED_MODULE_2__.IonButtons, _ionic_angular__WEBPACK_IMPORTED_MODULE_2__.IonCol, _ionic_angular__WEBPACK_IMPORTED_MODULE_2__.IonContent, _ionic_angular__WEBPACK_IMPORTED_MODULE_2__.IonFooter, _ionic_angular__WEBPACK_IMPORTED_MODULE_2__.IonGrid, _ionic_angular__WEBPACK_IMPORTED_MODULE_2__.IonHeader, _ionic_angular__WEBPACK_IMPORTED_MODULE_2__.IonIcon, _ionic_angular__WEBPACK_IMPORTED_MODULE_2__.IonRow, _ionic_angular__WEBPACK_IMPORTED_MODULE_2__.IonTitle, _ionic_angular__WEBPACK_IMPORTED_MODULE_2__.IonToolbar, _ngx_translate_core__WEBPACK_IMPORTED_MODULE_3__.TranslatePipe],
    styles: [".external[_ngcontent-%COMP%]   .title[_ngcontent-%COMP%] {\n  text-align: center;\n  font-weight: bold;\n  padding: 8px;\n}\n.external[_ngcontent-%COMP%]   .internal[_ngcontent-%COMP%]   .body[_ngcontent-%COMP%] {\n  text-align: justify;\n  padding: 8px;\n}\n/*# sourceMappingURL=data:application/json;charset=utf-8;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbIndlYnBhY2s6Ly8uL3NyYy9hcHAvY29yZS9zaGFyZWQvbm90aWZpY2F0aW9uLW1vZGFsL25vdGlmaWNhdGlvbi5tb2RhbC5zY3NzIl0sIm5hbWVzIjpbXSwibWFwcGluZ3MiOiJBQUNFO0VBQ0Usa0JBQUE7RUFDQSxpQkFBQTtFQUNBLFlBQUE7QUFBSjtBQUdJO0VBQ0UsbUJBQUE7RUFDQSxZQUFBO0FBRE4iLCJzb3VyY2VzQ29udGVudCI6WyIuZXh0ZXJuYWwge1xuICAudGl0bGUge1xuICAgIHRleHQtYWxpZ246IGNlbnRlcjtcbiAgICBmb250LXdlaWdodDogYm9sZDtcbiAgICBwYWRkaW5nOiA4cHg7XG4gIH1cbiAgLmludGVybmFsIHtcbiAgICAuYm9keSB7XG4gICAgICB0ZXh0LWFsaWduOiBqdXN0aWZ5O1xuICAgICAgcGFkZGluZzogOHB4O1xuICAgIH1cbiAgfVxufVxuIl0sInNvdXJjZVJvb3QiOiIifQ== */"]
  }));
}
_staticBlock();

/***/ }),

/***/ 20092:
/*!**********************************!*\
  !*** ./src/app/app.component.ts ***!
  \**********************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   AppComponent: () => (/* binding */ AppComponent)
/* harmony export */ });
/* harmony import */ var _Users_smartcommunitylab_Desktop_newWork_playAndGo_playGo_node_modules_babel_runtime_helpers_esm_asyncToGenerator_js__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./node_modules/@babel/runtime/helpers/esm/asyncToGenerator.js */ 89204);
/* harmony import */ var _capacitor_splash_screen__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @capacitor/splash-screen */ 7661);
/* harmony import */ var _capacitor_core__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @capacitor/core */ 14070);
/* harmony import */ var _capacitor_browser__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @capacitor/browser */ 26515);
/* harmony import */ var _capacitor_screen_orientation__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! @capacitor/screen-orientation */ 41618);
/* harmony import */ var _capacitor_status_bar__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! @capacitor/status-bar */ 19153);
/* harmony import */ var _capacitor_app__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! @capacitor/app */ 59326);
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(/*! @angular/core */ 12481);
/* harmony import */ var _ngx_translate_core__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(/*! @ngx-translate/core */ 48503);
/* harmony import */ var _ionic_angular__WEBPACK_IMPORTED_MODULE_9__ = __webpack_require__(/*! @ionic/angular */ 4059);
/* harmony import */ var _ionic_angular__WEBPACK_IMPORTED_MODULE_10__ = __webpack_require__(/*! @ionic/angular */ 21507);
/* harmony import */ var _core_shared_tracking_background_tracking_service__WEBPACK_IMPORTED_MODULE_11__ = __webpack_require__(/*! ./core/shared/tracking/background-tracking.service */ 27215);
/* harmony import */ var _core_shared_services_app_status_service__WEBPACK_IMPORTED_MODULE_12__ = __webpack_require__(/*! ./core/shared/services/app-status.service */ 65800);
/* harmony import */ var _core_shared_ui_icon_icon_service__WEBPACK_IMPORTED_MODULE_13__ = __webpack_require__(/*! ./core/shared/ui/icon/icon.service */ 86313);
/* harmony import */ var _core_auth_auth_service__WEBPACK_IMPORTED_MODULE_14__ = __webpack_require__(/*! ./core/auth/auth.service */ 35524);
/* harmony import */ var _core_shared_services_badge_service__WEBPACK_IMPORTED_MODULE_15__ = __webpack_require__(/*! ./core/shared/services/badge.service */ 48687);
/* harmony import */ var _core_shared_services_auto_update_service__WEBPACK_IMPORTED_MODULE_16__ = __webpack_require__(/*! ./core/shared/services/auto-update.service */ 52755);
/* harmony import */ var _core_shared_services_error_service__WEBPACK_IMPORTED_MODULE_17__ = __webpack_require__(/*! ./core/shared/services/error.service */ 46078);
/* harmony import */ var _core_shared_layout_content_content_content_component__WEBPACK_IMPORTED_MODULE_18__ = __webpack_require__(/*! ./core/shared/layout/content/content-content.component */ 84661);

var _staticBlock;

















const _c0 = ["contentTemplateComponent"];
class AppComponent {
  constructor(translate, platform, backgroundTrackingService, appStatusService, iconService, authService, badgeService, autoUpdateService,
  // @Inject('CodePushPlugin')
  // private codePushPlugin: typeof CodePushPluginInternal,
  errorService) {
    this.translate = translate;
    this.platform = platform;
    this.backgroundTrackingService = backgroundTrackingService;
    this.appStatusService = appStatusService;
    this.iconService = iconService;
    this.authService = authService;
    this.badgeService = badgeService;
    this.autoUpdateService = autoUpdateService;
    this.errorService = errorService;
    this.initializeApp();
  }
  initializeApp() {
    var _this = this;
    return (0,_Users_smartcommunitylab_Desktop_newWork_playAndGo_playGo_node_modules_babel_runtime_helpers_esm_asyncToGenerator_js__WEBPACK_IMPORTED_MODULE_0__["default"])(function* () {
      try {
        _this.translate.setDefaultLang('it');
        try {
          yield _capacitor_screen_orientation__WEBPACK_IMPORTED_MODULE_4__.ScreenOrientation.lock({
            orientation: 'portrait'
          });
        } catch (e) {}
        _this.loadCustomIcons();
        _this.initLink();
        _this.badgeService.init();
        yield _this.platform.ready();
        yield _this.autoUpdateService.init();
        _capacitor_app__WEBPACK_IMPORTED_MODULE_6__.App.addListener('appUrlOpen', event => {
          console.log('App aperta con URL:', event.url);
        });
        const observer = new MutationObserver(() => {
          document.documentElement.classList.remove('dark');
        });
        observer.observe(document.documentElement, {
          attributes: true,
          attributeFilter: ['class']
        });
        _this.authService.init().catch(err => console.error('auth init error', err));
        // console.log('Starting codePushSync with 3s timeout');
        // await Promise.race([this.codePushSync(), waitMs(3000)]);
        // this.backgroundTrackingService.start().catch(err => console.error('tracking start error', err));
        // // await this.authService.init();
        yield _this.backgroundTrackingService.start();
      } catch (error) {
        console.error('initializeApp error:', error);
      } finally {
        _capacitor_status_bar__WEBPACK_IMPORTED_MODULE_5__.StatusBar.setOverlaysWebView({
          overlay: false
        });
        yield _capacitor_status_bar__WEBPACK_IMPORTED_MODULE_5__.StatusBar.setBackgroundColor({
          color: '#3880ff'
        });
        _capacitor_status_bar__WEBPACK_IMPORTED_MODULE_5__.StatusBar.setStyle({
          style: _capacitor_status_bar__WEBPACK_IMPORTED_MODULE_5__.Style.Light
        });
        yield _capacitor_splash_screen__WEBPACK_IMPORTED_MODULE_1__.SplashScreen.hide();
      }
    })();
  }
  initLink() {
    if (_capacitor_core__WEBPACK_IMPORTED_MODULE_2__.Capacitor.getPlatform() !== 'web') {
      document.onclick = event => {
        const element = event.target || event.srcElement;
        if (element.tagName === 'A' && element.target === '_blank' && element.href) {
          event.preventDefault();
          _capacitor_browser__WEBPACK_IMPORTED_MODULE_3__.Browser.open({
            url: element.href,
            windowName: '_system',
            presentationStyle: 'popover'
          });
          return true;
        }
      };
    }
  }
  // async codePushSync() {
  //   try {
  //     let syncStatus: SyncStatus | 'sync_disabled' = 'sync_disabled';
  //     console.log('Starting codePushSync');
  //     if (environment.useCodePush) {
  //       console.log('Starting codePushSync with 15s timeout');
  //       syncStatus = await Promise.race([
  //         this.codePushPlugin.sync({
  //           onSyncStatusChanged: (syncStatus) => {
  //             return syncStatus;
  //           },
  //           installMode: InstallMode.IMMEDIATE,
  //         }).then(
  //           (status) => {
  //             if (status) {
  //               return status;
  //             }
  //           },
  //           (error) => {
  //             if (error) {
  //               return SyncStatus.ERROR;
  //             }
  //           }),
  //         // there is some problem with error handling on the plugin side...
  //         // https://github.com/capacitor-community/http/issues/232
  //         waitMs(15_000).then(() => {
  //           throw new Error('codePushSync timeout');
  //         }),
  //       ]);
  //     }
  //     console.log('codePushSync syncStatus:', syncStatus);
  //     this.appStatusService.codePushSyncFinished(true);
  //   } catch (error) {
  //     this.errorService.handleError(error, 'silent');
  //     this.appStatusService.codePushSyncFinished(false);
  //   }
  // }
  loadCustomIcons() {
    const icons = {
      custom_carpooling: '../assets/icon/travel/carpooling.svg',
      bike: '../assets/icon/travel/bike.svg',
      bus: '../assets/icon/travel/bus.svg',
      car: '../assets/icon/travel/custom_carpooling.svg',
      train: '../assets/icon/travel/train.svg',
      walk: '../assets/icon/travel/walk.svg',
      boat: 'boat',
      cup: '../assets/icon/cup.svg',
      passenger: '../assets/icon/passenger.svg',
      driver: '../assets/icon/driver.svg',
      co2: '../assets/icon/co2.svg',
      km: '../assets/icon/km.svg',
      flower: '../assets/icon/flower.svg',
      shield: '../assets/icon/shield.svg',
      ecoLeavesCompany: '../assets/icon/company-leaf.svg',
      ecoLeavesCity: '../assets/icon/city-eco-leave.svg',
      ecoLeavesHsc: '../assets/icon/hsc-eco-leaves.svg',
      offline: '../assets/icon/offline.svg',
      badges: '../assets/icon/badges.svg',
      blockUserColor: '../assets/icon/blockUserColor.svg',
      blacklist: '../assets/icon/blacklist.svg',
      invitation: '../assets/icon/invitation.svg',
      invite: '../assets/icon/invite.svg',
      leaderboard: '../assets/icon/leaderboard.svg',
      homeFooter: '../assets/images/home/logo.svg',
      level_up: '../assets/icon/level-up.svg',
      stat: '../assets/icon/stat.svg',
      leave: '../assets/icon/leave.svg',
      checked: '../assets/icon/checked.svg',
      cupCog: '../assets/icon/cupCog.svg',
      groupCompetitivePerformance: '../assets/images/challenges/groupCompetitivePerformance.svg',
      groupCompetitiveTime: '../assets/images/challenges/groupCompetitiveTime.svg',
      groupCooperative: '../assets/images/challenges/groupCooperative.svg',
      default: '../assets/images/challenges/default.svg',
      listCircle: '../assets/images/challenges/list-circle-outline.svg'
    };
    this.iconService.registerSvgIcons(icons);
  }
  ngAfterContentInit() {}
  static #_ = _staticBlock = () => (this.ɵfac = function AppComponent_Factory(__ngFactoryType__) {
    return new (__ngFactoryType__ || AppComponent)(_angular_core__WEBPACK_IMPORTED_MODULE_7__["ɵɵdirectiveInject"](_ngx_translate_core__WEBPACK_IMPORTED_MODULE_8__.TranslateService), _angular_core__WEBPACK_IMPORTED_MODULE_7__["ɵɵdirectiveInject"](_ionic_angular__WEBPACK_IMPORTED_MODULE_9__.Platform), _angular_core__WEBPACK_IMPORTED_MODULE_7__["ɵɵdirectiveInject"](_core_shared_tracking_background_tracking_service__WEBPACK_IMPORTED_MODULE_11__.BackgroundTrackingService), _angular_core__WEBPACK_IMPORTED_MODULE_7__["ɵɵdirectiveInject"](_core_shared_services_app_status_service__WEBPACK_IMPORTED_MODULE_12__.AppStatusService), _angular_core__WEBPACK_IMPORTED_MODULE_7__["ɵɵdirectiveInject"](_core_shared_ui_icon_icon_service__WEBPACK_IMPORTED_MODULE_13__.IconService), _angular_core__WEBPACK_IMPORTED_MODULE_7__["ɵɵdirectiveInject"](_core_auth_auth_service__WEBPACK_IMPORTED_MODULE_14__.AuthService), _angular_core__WEBPACK_IMPORTED_MODULE_7__["ɵɵdirectiveInject"](_core_shared_services_badge_service__WEBPACK_IMPORTED_MODULE_15__.BadgeService), _angular_core__WEBPACK_IMPORTED_MODULE_7__["ɵɵdirectiveInject"](_core_shared_services_auto_update_service__WEBPACK_IMPORTED_MODULE_16__.AutoUpdateService), _angular_core__WEBPACK_IMPORTED_MODULE_7__["ɵɵdirectiveInject"](_core_shared_services_error_service__WEBPACK_IMPORTED_MODULE_17__.ErrorService));
  }, this.ɵcmp = /*@__PURE__*/_angular_core__WEBPACK_IMPORTED_MODULE_7__["ɵɵdefineComponent"]({
    type: AppComponent,
    selectors: [["app-root"]],
    viewQuery: function AppComponent_Query(rf, ctx) {
      if (rf & 1) {
        _angular_core__WEBPACK_IMPORTED_MODULE_7__["ɵɵviewQuery"](_c0, 7);
      }
      if (rf & 2) {
        let _t;
        _angular_core__WEBPACK_IMPORTED_MODULE_7__["ɵɵqueryRefresh"](_t = _angular_core__WEBPACK_IMPORTED_MODULE_7__["ɵɵloadQuery"]()) && (ctx.contentTemplateComponent = _t.first);
      }
    },
    standalone: false,
    decls: 5,
    vars: 0,
    consts: [["contentTemplateComponent", ""], [2, "display", "none"]],
    template: function AppComponent_Template(rf, ctx) {
      if (rf & 1) {
        _angular_core__WEBPACK_IMPORTED_MODULE_7__["ɵɵelementStart"](0, "ion-app");
        _angular_core__WEBPACK_IMPORTED_MODULE_7__["ɵɵelement"](1, "ion-router-outlet");
        _angular_core__WEBPACK_IMPORTED_MODULE_7__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_7__["ɵɵelementStart"](2, "div", 1);
        _angular_core__WEBPACK_IMPORTED_MODULE_7__["ɵɵelement"](3, "app-content-content", null, 0);
        _angular_core__WEBPACK_IMPORTED_MODULE_7__["ɵɵelementEnd"]();
      }
    },
    dependencies: [_ionic_angular__WEBPACK_IMPORTED_MODULE_10__.IonApp, _ionic_angular__WEBPACK_IMPORTED_MODULE_10__.IonRouterOutlet, _core_shared_layout_content_content_content_component__WEBPACK_IMPORTED_MODULE_18__.ContentContentComponent],
    styles: ["/*# sourceMappingURL=data:application/json;charset=utf-8;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbXSwibmFtZXMiOltdLCJtYXBwaW5ncyI6IiIsInNvdXJjZVJvb3QiOiIifQ== */"]
  }));
}
_staticBlock();

/***/ }),

/***/ 23126:
/*!****************************************************!*\
  !*** ./src/app/core/shared/tracking/trip.model.ts ***!
  \****************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   ACCESS_DENIED: () => (/* binding */ ACCESS_DENIED),
/* harmony export */   LOW_ACCURACY: () => (/* binding */ LOW_ACCURACY),
/* harmony export */   MAX_MS_TRACKING: () => (/* binding */ MAX_MS_TRACKING),
/* harmony export */   NO_TRIP_STARTED: () => (/* binding */ NO_TRIP_STARTED),
/* harmony export */   POWER_SAVE_MODE: () => (/* binding */ POWER_SAVE_MODE),
/* harmony export */   TRIP_END: () => (/* binding */ TRIP_END),
/* harmony export */   Trip: () => (/* binding */ Trip),
/* harmony export */   TripPart: () => (/* binding */ TripPart),
/* harmony export */   UNABLE_TO_GET_POSITION: () => (/* binding */ UNABLE_TO_GET_POSITION),
/* harmony export */   getTransportTypeColor: () => (/* binding */ getTransportTypeColor),
/* harmony export */   getTransportTypeIcon: () => (/* binding */ getTransportTypeIcon),
/* harmony export */   getTransportTypeLabel: () => (/* binding */ getTransportTypeLabel),
/* harmony export */   isTransportType: () => (/* binding */ isTransportType),
/* harmony export */   transportTypeColors: () => (/* binding */ transportTypeColors),
/* harmony export */   transportTypeIcons: () => (/* binding */ transportTypeIcons),
/* harmony export */   transportTypeLabels: () => (/* binding */ transportTypeLabels),
/* harmony export */   transportTypes: () => (/* binding */ transportTypes)
/* harmony export */ });
/* harmony import */ var _services_error_service__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ../services/error.service */ 46078);

/** Whole multimodal trip */
class Trip {
  constructor(data) {
    Object.assign(this, data || {});
  }
  static fromFirstPart(firstPart) {
    return new Trip({
      multimodalId: firstPart.multimodalId
    });
  }
}
/** Single part in (potentially) multimodal trip */
class TripPart {
  constructor(data) {
    Object.assign(this, data || {});
  }
  static fromTransportType(transportType) {
    const start = new Date().getTime();
    const idTrip = `${transportType}_${start}`;
    return new TripPart({
      start,
      transportType,
      idTrip,
      sharedTravelId: null,
      multimodalId: null,
      isInitial: false
    });
  }
}
const TRIP_END = 'TRIP_END';
const NO_TRIP_STARTED = 'NO_TRIP_STARTED';
const LOW_ACCURACY = new _services_error_service__WEBPACK_IMPORTED_MODULE_0__.UserError({
  id: 'LOW_ACCURACY',
  message: 'tracking.errors.LOW_ACCURACY'
});
const ACCESS_DENIED = new _services_error_service__WEBPACK_IMPORTED_MODULE_0__.UserError({
  id: 'ACCESS_DENIED',
  message: 'tracking.errors.ACCESS_DENIED'
});
const POWER_SAVE_MODE = new _services_error_service__WEBPACK_IMPORTED_MODULE_0__.UserError({
  id: 'POWER_SAVE_MODE',
  message: 'tracking.errors.POWER_SAVE_MODE'
});
// probably location services are disabled by user.
const UNABLE_TO_GET_POSITION = new _services_error_service__WEBPACK_IMPORTED_MODULE_0__.UserError({
  id: 'UNABLE_TO_GET_POSITION',
  message: 'tracking.errors.UNABLE_TO_GET_POSITION'
});
const transportTypes = ['walk', 'bike', 'bus', 'train', 'car', 'boat'];
const transportTypeColors = {
  bike: 'red',
  bus: 'green',
  car: 'yellow',
  train: 'blue',
  walk: 'brown',
  boat: 'blue',
  unknown: 'black'
};
const transportTypeIcons = {
  bike: 'bike',
  bus: 'bus',
  car: 'custom_carpooling',
  train: 'train',
  walk: 'walk',
  boat: 'boat',
  unknown: 'help'
};
const transportTypeLabels = {
  bike: 'trip_detail.mean.bike',
  bus: 'trip_detail.mean.bus',
  car: 'trip_detail.mean.car',
  train: 'trip_detail.mean.train',
  walk: 'trip_detail.mean.walk',
  boat: 'trip_detail.mean.boat',
  unknown: 'trip_detail.mean.unknown'
};
function isTransportType(transportType) {
  return transportTypes.includes(transportType) || transportType === 'unknown';
}
function getTransportTypeIcon(transportType) {
  if (!isTransportType(transportType)) {
    console.error(`Unknown transport type: ${transportType}`);
    return null;
  }
  return transportTypeIcons[transportType];
}
function getTransportTypeLabel(transportType) {
  if (!isTransportType(transportType)) {
    console.error(`Unknown transport type: ${transportType}`);
    return null;
  }
  return transportTypeLabels[transportType];
}
function getTransportTypeColor(transportType) {
  if (!isTransportType(transportType)) {
    console.error(`Unknown transport type: ${transportType}`);
    return null;
  }
  return transportTypeColors[transportType];
}
const MAX_MS_TRACKING = 8 * 60 * 60 * 1000;
// export const MAX_MS_TRACKING = 30 * 1000;

/***/ }),

/***/ 23797:
/*!************************************************************************************************************!*\
  !*** ./src/app/core/shared/campaigns/home-widget-types/home-campaign-city/home-campaign-city.component.ts ***!
  \************************************************************************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   HomeCampaignCityComponent: () => (/* binding */ HomeCampaignCityComponent)
/* harmony export */ });
/* harmony import */ var luxon__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! luxon */ 45967);
/* harmony import */ var _time_utils__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ../../../time.utils */ 27780);
/* harmony import */ var _utils__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! ../../../utils */ 7497);
/* harmony import */ var _campaignUtils__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! ../../campaignUtils */ 83239);
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! @angular/core */ 12481);
/* harmony import */ var src_app_core_shared_services_user_service__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! src/app/core/shared/services/user.service */ 89815);
/* harmony import */ var src_app_core_shared_services_report_service__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! src/app/core/shared/services/report.service */ 40610);
/* harmony import */ var _services_error_service__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(/*! ../../../services/error.service */ 46078);
/* harmony import */ var _services_challenge_service__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(/*! ../../../services/challenge.service */ 16561);
/* harmony import */ var _angular_common__WEBPACK_IMPORTED_MODULE_9__ = __webpack_require__(/*! @angular/common */ 93683);
/* harmony import */ var _ionic_angular__WEBPACK_IMPORTED_MODULE_10__ = __webpack_require__(/*! @ionic/angular */ 21507);
/* harmony import */ var _main_campaign_stat_main_campaign_stat_component__WEBPACK_IMPORTED_MODULE_11__ = __webpack_require__(/*! ../../main-campaign-stat/main-campaign-stat.component */ 79238);
/* harmony import */ var _notification_badge_notification_badge_component__WEBPACK_IMPORTED_MODULE_12__ = __webpack_require__(/*! ../notification-badge/notification-badge.component */ 25211);
/* harmony import */ var _app_widget_campaign_app_home_campaign_challenges_app_home_campaign_challenges_component__WEBPACK_IMPORTED_MODULE_13__ = __webpack_require__(/*! ../../app-widget-campaign/app-home-campaign-challenges/app-home-campaign-challenges.component */ 77234);
/* harmony import */ var _ngx_translate_core__WEBPACK_IMPORTED_MODULE_14__ = __webpack_require__(/*! @ngx-translate/core */ 48503);
/* harmony import */ var _pipes_languageMap_pipe__WEBPACK_IMPORTED_MODULE_15__ = __webpack_require__(/*! ../../../pipes/languageMap.pipe */ 69618);
var _staticBlock;
















const _c0 = a0 => ({
  "home-card-widget": a0
});
function HomeCampaignCityComponent_app_notification_badge_0_Template(rf, ctx) {
  if (rf & 1) {
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵelement"](0, "app-notification-badge", 9);
  }
  if (rf & 2) {
    const ctx_r0 = _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵnextContext"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵproperty"]("type", "campaign")("campaignContainer", ctx_r0.campaignContainer);
  }
}
function HomeCampaignCityComponent_div_5_Template(rf, ctx) {
  if (rf & 1) {
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵelementStart"](0, "div", 10)(1, "span");
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵtext"](2);
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵpipe"](3, "languageMap");
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵelementEnd"]()();
  }
  if (rf & 2) {
    const ctx_r0 = _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵnextContext"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵadvance"](2);
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵtextInterpolate1"](" ", _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵpipeBind1"](3, 1, ctx_r0.campaignContainer.campaign.name));
  }
}
function HomeCampaignCityComponent_ng_template_6_Template(rf, ctx) {
  if (rf & 1) {
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵelementStart"](0, "div")(1, "span");
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵtext"](2);
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵpipe"](3, "translate");
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵelementEnd"]()();
  }
  if (rf & 2) {
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵadvance"](2);
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵtextInterpolate1"](" ", _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵpipeBind1"](3, 1, "campaigns.detail.generalStat"));
  }
}
function HomeCampaignCityComponent_app_home_campaign_challenges_11_Template(rf, ctx) {
  if (rf & 1) {
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵelement"](0, "app-home-campaign-challenges", 11);
  }
  if (rf & 2) {
    const ctx_r0 = _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵnextContext"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵproperty"]("campaignContainer", ctx_r0.campaignContainer);
  }
}
class HomeCampaignCityComponent {
  constructor(userService, reportService, errorService, challengeService) {
    this.userService = userService;
    this.reportService = reportService;
    this.errorService = errorService;
    this.challengeService = challengeService;
    this.header = false;
    this.campaignStatus = null;
  }
  ngOnInit() {
    this.activeUncompleteChallenges$ = this.challengeService.getActiveUncompletedChallengesByCampaign(this.campaignContainer?.campaign?.campaignId);
    this.imagePath = (0,_campaignUtils__WEBPACK_IMPORTED_MODULE_3__.getCampaignImage)(this.campaignContainer);
    this.subStat = this.userService.userProfile$.subscribe(profile => {
      // this.subChallActive = this.activeUncompleteChallenges$.subscribe(
      //   (challenges) => {
      //     this.activeUncompleteChallenges = challenges;
      //   }
      // );
      this.gameStatus = this.reportService.getGameStatus(this.campaignContainer.campaign.campaignId).subscribe(campaignStatus => {
        this.campaignStatus = campaignStatus;
      }, error => {
        if ((0,_utils__WEBPACK_IMPORTED_MODULE_2__.isOfflineError)(error)) {
          this.campaignStatus = undefined;
        } else {
          this.campaignStatus = undefined;
          this.errorService.handleError(error);
        }
      });
      // First release: only global report, for the we can add global
      this.reportService.getGameStats(this.campaignContainer.campaign.campaignId, profile.playerId, (0,_time_utils__WEBPACK_IMPORTED_MODULE_1__.toServerDateOnly)(luxon__WEBPACK_IMPORTED_MODULE_0__.DateTime.utc().startOf('week')), (0,_time_utils__WEBPACK_IMPORTED_MODULE_1__.toServerDateOnly)(luxon__WEBPACK_IMPORTED_MODULE_0__.DateTime.utc())).subscribe(stats => {
        this.reportWeekStat = stats;
      }, error => {
        if ((0,_utils__WEBPACK_IMPORTED_MODULE_2__.isOfflineError)(error)) {
          this.reportWeekStat = null;
        } else {
          this.reportWeekStat = null;
          this.errorService.handleError(error);
        }
      });
      this.reportService.getGameStats(this.campaignContainer.campaign.campaignId, profile.playerId).subscribe(stats => {
        this.reportTotalStat = stats;
      }, error => {
        if ((0,_utils__WEBPACK_IMPORTED_MODULE_2__.isOfflineError)(error)) {
          this.reportTotalStat = null;
        } else {
          this.reportTotalStat = null;
          this.errorService.handleError(error);
        }
      });
    });
  }
  ngOnDestroy() {
    this.subStat.unsubscribe();
    this.gameStatus.unsubscribe();
  }
  static #_ = _staticBlock = () => (this.ɵfac = function HomeCampaignCityComponent_Factory(__ngFactoryType__) {
    return new (__ngFactoryType__ || HomeCampaignCityComponent)(_angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵdirectiveInject"](src_app_core_shared_services_user_service__WEBPACK_IMPORTED_MODULE_5__.UserService), _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵdirectiveInject"](src_app_core_shared_services_report_service__WEBPACK_IMPORTED_MODULE_6__.ReportService), _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵdirectiveInject"](_services_error_service__WEBPACK_IMPORTED_MODULE_7__.ErrorService), _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵdirectiveInject"](_services_challenge_service__WEBPACK_IMPORTED_MODULE_8__.ChallengeService));
  }, this.ɵcmp = /*@__PURE__*/_angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵdefineComponent"]({
    type: HomeCampaignCityComponent,
    selectors: [["app-home-campaign-city"]],
    inputs: {
      campaignContainer: "campaignContainer",
      header: "header"
    },
    standalone: false,
    decls: 12,
    vars: 16,
    consts: [["detailHeader", ""], [3, "type", "campaignContainer", 4, "ngIf"], [3, "ngClass"], ["color", "city"], ["alt", "Avatar", 3, "src"], ["lines", "none", "color", "city", 4, "ngIf", "ngIfElse"], [1, "city-content", "ion-no-padding"], [3, "campaignContainer", "status", "showGameStatus", "reportWeekStat", "reportTotalStat", "unit"], [3, "campaignContainer", 4, "ngIf"], [3, "type", "campaignContainer"], ["lines", "none", "color", "city"], [3, "campaignContainer"]],
    template: function HomeCampaignCityComponent_Template(rf, ctx) {
      if (rf & 1) {
        _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵtemplate"](0, HomeCampaignCityComponent_app_notification_badge_0_Template, 1, 2, "app-notification-badge", 1);
        _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵelementStart"](1, "ion-card", 2)(2, "ion-card-header", 3)(3, "ion-avatar");
        _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵelement"](4, "img", 4);
        _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵtemplate"](5, HomeCampaignCityComponent_div_5_Template, 4, 3, "div", 5)(6, HomeCampaignCityComponent_ng_template_6_Template, 4, 3, "ng-template", null, 0, _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵtemplateRefExtractor"]);
        _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵelementStart"](8, "ion-card-content", 6);
        _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵelement"](9, "app-main-campaign-stat", 7);
        _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵpipe"](10, "async");
        _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵtemplate"](11, HomeCampaignCityComponent_app_home_campaign_challenges_11_Template, 1, 1, "app-home-campaign-challenges", 8);
        _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵelementEnd"]()();
      }
      if (rf & 2) {
        let tmp_8_0;
        const detailHeader_r2 = _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵreference"](7);
        _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵproperty"]("ngIf", ctx.header);
        _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵadvance"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵproperty"]("ngClass", _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵpureFunction1"](14, _c0, ctx.header));
        _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵadvance"](3);
        _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵproperty"]("src", ctx.imagePath, _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵsanitizeUrl"]);
        _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵadvance"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵproperty"]("ngIf", ctx.header)("ngIfElse", detailHeader_r2);
        _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵadvance"](4);
        _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵproperty"]("campaignContainer", ctx.campaignContainer)("status", ctx.campaignStatus)("showGameStatus", ((tmp_8_0 = _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵpipeBind1"](10, 12, ctx.activeUncompleteChallenges$)) == null ? null : tmp_8_0.length) === 0 || !ctx.header ? true : false)("reportWeekStat", ctx.reportWeekStat)("reportTotalStat", ctx.reportTotalStat)("unit", "eL");
        _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵadvance"](2);
        _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵproperty"]("ngIf", ctx.header);
      }
    },
    dependencies: [_angular_common__WEBPACK_IMPORTED_MODULE_9__.NgClass, _angular_common__WEBPACK_IMPORTED_MODULE_9__.NgIf, _ionic_angular__WEBPACK_IMPORTED_MODULE_10__.IonAvatar, _ionic_angular__WEBPACK_IMPORTED_MODULE_10__.IonCard, _ionic_angular__WEBPACK_IMPORTED_MODULE_10__.IonCardContent, _ionic_angular__WEBPACK_IMPORTED_MODULE_10__.IonCardHeader, _main_campaign_stat_main_campaign_stat_component__WEBPACK_IMPORTED_MODULE_11__.MainCampaignStatComponent, _notification_badge_notification_badge_component__WEBPACK_IMPORTED_MODULE_12__.NotificationBadgeComponent, _app_widget_campaign_app_home_campaign_challenges_app_home_campaign_challenges_component__WEBPACK_IMPORTED_MODULE_13__.HomeCampaignChallengeComponent, _angular_common__WEBPACK_IMPORTED_MODULE_9__.AsyncPipe, _ngx_translate_core__WEBPACK_IMPORTED_MODULE_14__.TranslatePipe, _pipes_languageMap_pipe__WEBPACK_IMPORTED_MODULE_15__.LanguageMapPipe],
    styles: [".city-content[_ngcontent-%COMP%] {\n  color: black;\n}\n\nion-card[_ngcontent-%COMP%] {\n  overflow: visible;\n}\nion-card[_ngcontent-%COMP%]   ion-card-header[_ngcontent-%COMP%] {\n  border-radius: 10px 10px 0px 0px;\n  text-align: left;\n  font-size: 18px;\n  font-weight: 500;\n  padding: 12px;\n  margin-bottom: 24px;\n}\nion-card[_ngcontent-%COMP%]   ion-card-header[_ngcontent-%COMP%]   ion-avatar[_ngcontent-%COMP%] {\n  --border-radius: 50%;\n  border: solid 5px var(--ion-color-city);\n  background-color: var(--ion-color-city);\n  position: absolute;\n  z-index: 2;\n  text-align: center;\n  right: 12px;\n  bottom: -29px;\n  width: 64px;\n  height: 64px;\n}\nion-card[_ngcontent-%COMP%]   ion-card-content[_ngcontent-%COMP%] {\n  padding: 0px 0px 0px 0px;\n}\n/*# sourceMappingURL=data:application/json;charset=utf-8;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbIndlYnBhY2s6Ly8uL3NyYy9hcHAvY29yZS9zaGFyZWQvY2FtcGFpZ25zL2hvbWUtd2lkZ2V0LXR5cGVzL2hvbWUtY2FtcGFpZ24tY2l0eS9ob21lLWNhbXBhaWduLWNpdHkuY29tcG9uZW50LnNjc3MiXSwibmFtZXMiOltdLCJtYXBwaW5ncyI6IkFBQUE7RUFDRSxZQUFBO0FBQ0Y7O0FBQ0E7RUFDRSxpQkFBQTtBQUVGO0FBREU7RUFDRSxnQ0FBQTtFQUNBLGdCQUFBO0VBQ0EsZUFBQTtFQUNBLGdCQUFBO0VBQ0EsYUFBQTtFQUNBLG1CQUFBO0FBR0o7QUFGSTtFQUNFLG9CQUFBO0VBQ0EsdUNBQUE7RUFDQSx1Q0FBQTtFQUNBLGtCQUFBO0VBQ0EsVUFBQTtFQUNBLGtCQUFBO0VBQ0EsV0FBQTtFQUNBLGFBQUE7RUFDQSxXQUFBO0VBQ0EsWUFBQTtBQUlOO0FBREU7RUFDRSx3QkFBQTtBQUdKIiwic291cmNlc0NvbnRlbnQiOlsiLmNpdHktY29udGVudCB7XG4gIGNvbG9yOiBibGFjaztcbn1cbmlvbi1jYXJkIHtcbiAgb3ZlcmZsb3c6IHZpc2libGU7XG4gIGlvbi1jYXJkLWhlYWRlciB7XG4gICAgYm9yZGVyLXJhZGl1czogMTBweCAxMHB4IDBweCAwcHg7XG4gICAgdGV4dC1hbGlnbjogbGVmdDtcbiAgICBmb250LXNpemU6IDE4cHg7XG4gICAgZm9udC13ZWlnaHQ6IDUwMDtcbiAgICBwYWRkaW5nOiAxMnB4O1xuICAgIG1hcmdpbi1ib3R0b206IDI0cHg7XG4gICAgaW9uLWF2YXRhciB7XG4gICAgICAtLWJvcmRlci1yYWRpdXM6IDUwJTtcbiAgICAgIGJvcmRlcjogc29saWQgNXB4IHZhcigtLWlvbi1jb2xvci1jaXR5KTtcbiAgICAgIGJhY2tncm91bmQtY29sb3I6IHZhcigtLWlvbi1jb2xvci1jaXR5KTtcbiAgICAgIHBvc2l0aW9uOiBhYnNvbHV0ZTtcbiAgICAgIHotaW5kZXg6IDI7XG4gICAgICB0ZXh0LWFsaWduOiBjZW50ZXI7XG4gICAgICByaWdodDogMTJweDtcbiAgICAgIGJvdHRvbTogLTI5cHg7XG4gICAgICB3aWR0aDogNjRweDtcbiAgICAgIGhlaWdodDogNjRweDtcbiAgICB9XG4gIH1cbiAgaW9uLWNhcmQtY29udGVudCB7XG4gICAgcGFkZGluZzogMHB4IDBweCAwcHggMHB4O1xuICB9XG59XG4iXSwic291cmNlUm9vdCI6IiJ9 */"]
  }));
}
_staticBlock();

/***/ }),

/***/ 25211:
/*!************************************************************************************************************!*\
  !*** ./src/app/core/shared/campaigns/home-widget-types/notification-badge/notification-badge.component.ts ***!
  \************************************************************************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   NotificationBadgeComponent: () => (/* binding */ NotificationBadgeComponent)
/* harmony export */ });
/* harmony import */ var rxjs__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! rxjs */ 59400);
/* harmony import */ var rxjs__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! rxjs */ 98764);
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @angular/core */ 12481);
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @angular/core */ 37580);
/* harmony import */ var _services_notifications_notifications_service__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! ../../../services/notifications/notifications.service */ 16095);
/* harmony import */ var _angular_common__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! @angular/common */ 93683);
/* harmony import */ var _ionic_angular__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! @ionic/angular */ 21507);
var _staticBlock;





function NotificationBadgeComponent_ion_badge_1_Template(rf, ctx) {
  if (rf & 1) {
    _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵelementStart"](0, "ion-badge", 2);
    _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵelement"](1, "ion-icon", 3);
    _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵelementEnd"]();
  }
}
class NotificationBadgeComponent {
  constructor(notificationService, cdRef) {
    this.notificationService = notificationService;
    this.cdRef = cdRef;
    this.numberOfNotification = 0;
  }
  ngOnInit() {
    this.unreadNotification$ = this.getNotifObservable(this.type).pipe((0,rxjs__WEBPACK_IMPORTED_MODULE_1__.tap)(notifications => {
      // console.log('unread campaign notification', notifications);
      this.numberOfNotification = notifications.length;
      // this.cdRef.detectChanges();
    }));
    this.subUnread = this.unreadNotification$.subscribe();
  }
  getNotifObservable(type) {
    switch (type) {
      case 'campaign':
        return this.notificationService.getUnreadCampaignNotifications(this.campaignContainer.campaign.campaignId);
      case 'challenge':
        return this.notificationService.getUnreadCampaignChallengeNotifications(this.campaignContainer.campaign.campaignId);
      default:
        return rxjs__WEBPACK_IMPORTED_MODULE_0__.EMPTY;
    }
  }
  ngOnDestroy() {
    this.subUnread.unsubscribe();
  }
  static #_ = _staticBlock = () => (this.ɵfac = function NotificationBadgeComponent_Factory(__ngFactoryType__) {
    return new (__ngFactoryType__ || NotificationBadgeComponent)(_angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵdirectiveInject"](_services_notifications_notifications_service__WEBPACK_IMPORTED_MODULE_4__.NotificationService), _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵdirectiveInject"](_angular_core__WEBPACK_IMPORTED_MODULE_3__.ChangeDetectorRef));
  }, this.ɵcmp = /*@__PURE__*/_angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵdefineComponent"]({
    type: NotificationBadgeComponent,
    selectors: [["app-notification-badge"]],
    inputs: {
      campaignContainer: "campaignContainer",
      type: "type"
    },
    standalone: false,
    decls: 2,
    vars: 1,
    consts: [[1, "notif"], ["color", "danger", 4, "ngIf"], ["color", "danger"], ["name", "alert-outline"]],
    template: function NotificationBadgeComponent_Template(rf, ctx) {
      if (rf & 1) {
        _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵelementStart"](0, "div", 0);
        _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵtemplate"](1, NotificationBadgeComponent_ion_badge_1_Template, 2, 0, "ion-badge", 1);
        _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵelementEnd"]();
      }
      if (rf & 2) {
        _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵadvance"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵproperty"]("ngIf", ctx.numberOfNotification > 0);
      }
    },
    dependencies: [_angular_common__WEBPACK_IMPORTED_MODULE_5__.NgIf, _ionic_angular__WEBPACK_IMPORTED_MODULE_6__.IonBadge, _ionic_angular__WEBPACK_IMPORTED_MODULE_6__.IonIcon],
    styles: [".school-content[_ngcontent-%COMP%] {\n  color: black;\n}\n\n.notif[_ngcontent-%COMP%] {\n  position: relative;\n}\n.notif[_ngcontent-%COMP%]   ion-badge[_ngcontent-%COMP%] {\n  position: absolute;\n  z-index: 99;\n  right: 10px;\n  top: -6px;\n}\n/*# sourceMappingURL=data:application/json;charset=utf-8;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbIndlYnBhY2s6Ly8uL3NyYy9hcHAvY29yZS9zaGFyZWQvY2FtcGFpZ25zL2hvbWUtd2lkZ2V0LXR5cGVzL25vdGlmaWNhdGlvbi1iYWRnZS9ub3RpZmljYXRpb24tYmFkZ2UuY29tcG9uZW50LnNjc3MiXSwibmFtZXMiOltdLCJtYXBwaW5ncyI6IkFBQUE7RUFFRSxZQUFBO0FBQUY7O0FBRUE7RUFDRSxrQkFBQTtBQUNGO0FBQUU7RUFDRSxrQkFBQTtFQUNBLFdBQUE7RUFDQSxXQUFBO0VBQ0EsU0FBQTtBQUVKIiwic291cmNlc0NvbnRlbnQiOlsiLnNjaG9vbC1jb250ZW50IHtcbiAgLy8gICBiYWNrZ3JvdW5kLWNvbG9yOiB2YXIoLS1pb24tY29sb3Itc2Nob29sLXRpbnQpO1xuICBjb2xvcjogYmxhY2s7XG59XG4ubm90aWYge1xuICBwb3NpdGlvbjogcmVsYXRpdmU7XG4gIGlvbi1iYWRnZSB7XG4gICAgcG9zaXRpb246IGFic29sdXRlO1xuICAgIHotaW5kZXg6IDk5O1xuICAgIHJpZ2h0OiAxMHB4O1xuICAgIHRvcDogLTZweDtcbiAgfVxufVxuIl0sInNvdXJjZVJvb3QiOiIifQ== */"]
  }));
}
_staticBlock();

/***/ }),

/***/ 25449:
/*!***************************************************************************************!*\
  !*** ./src/app/core/shared/profile-components/profile-component/profile.component.ts ***!
  \***************************************************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   ProfileComponent: () => (/* binding */ ProfileComponent)
/* harmony export */ });
/* harmony import */ var _Users_smartcommunitylab_Desktop_newWork_playAndGo_playGo_node_modules_babel_runtime_helpers_esm_asyncToGenerator_js__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./node_modules/@babel/runtime/helpers/esm/asyncToGenerator.js */ 89204);
/* harmony import */ var _capacitor_camera__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @capacitor/camera */ 54982);
/* harmony import */ var _utils__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! ../../utils */ 7497);
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @angular/core */ 34205);
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! @angular/core */ 12481);
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! @angular/core */ 37580);
/* harmony import */ var src_app_core_shared_services_user_service__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! src/app/core/shared/services/user.service */ 89815);
/* harmony import */ var _services_campaign_service__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(/*! ../../services/campaign.service */ 76658);
/* harmony import */ var _ionic_angular__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(/*! @ionic/angular */ 4059);
/* harmony import */ var _ionic_angular__WEBPACK_IMPORTED_MODULE_9__ = __webpack_require__(/*! @ionic/angular */ 21507);
/* harmony import */ var _services_error_service__WEBPACK_IMPORTED_MODULE_10__ = __webpack_require__(/*! ../../services/error.service */ 46078);
/* harmony import */ var _angular_common__WEBPACK_IMPORTED_MODULE_11__ = __webpack_require__(/*! @angular/common */ 93683);
/* harmony import */ var _ngx_translate_core__WEBPACK_IMPORTED_MODULE_12__ = __webpack_require__(/*! @ngx-translate/core */ 48503);
/* harmony import */ var _pipes_localDate_pipe__WEBPACK_IMPORTED_MODULE_13__ = __webpack_require__(/*! ../../pipes/localDate.pipe */ 86451);
/* harmony import */ var _pipes_languageMap_pipe__WEBPACK_IMPORTED_MODULE_14__ = __webpack_require__(/*! ../../pipes/languageMap.pipe */ 69618);

var _staticBlock;











function ProfileComponent_div_0_div_1_Template(rf, ctx) {
  if (rf & 1) {
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵelement"](0, "div");
  }
}
function ProfileComponent_div_0_ng_template_2_Template(rf, ctx) {
  if (rf & 1) {
    const _r1 = _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵgetCurrentView"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵelementStart"](0, "div", 4);
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵlistener"]("click", function ProfileComponent_div_0_ng_template_2_Template_div_click_0_listener() {
      _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵrestoreView"](_r1);
      const ctx_r1 = _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵnextContext"](2);
      return _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵresetView"](ctx_r1.goToProfile());
    });
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵelementStart"](1, "ion-item", 5)(2, "ion-avatar", 6);
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵelement"](3, "img", 7);
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵpipe"](4, "translate");
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵelementEnd"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵelementStart"](5, "ion-label")(6, "div", 8)(7, "span", 9);
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵtext"](8);
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵelementEnd"]()()()()();
  }
  if (rf & 2) {
    const ctx_r1 = _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵnextContext"](2);
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵadvance"](3);
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵproperty"]("title", _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵinterpolate"](_angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵpipeBind1"](4, 4, "registration.avatar.title")))("src", ctx_r1.profile.avatar.avatarUrl, _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵsanitizeUrl"]);
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵadvance"](5);
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵtextInterpolate"](ctx_r1.profile.nickname);
  }
}
function ProfileComponent_div_0_ng_template_4_ion_label_6_Template(rf, ctx) {
  if (rf & 1) {
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵelementStart"](0, "ion-label", 5)(1, "div", 15)(2, "b");
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵtext"](3);
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵelementEnd"]()();
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵelementStart"](4, "div", 16);
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵtext"](5);
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵpipe"](6, "translate");
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵelementStart"](7, "b");
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵtext"](8);
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵelementEnd"]()()();
  }
  if (rf & 2) {
    const ctx_r1 = _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵnextContext"](3);
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵadvance"](3);
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵtextInterpolate"](ctx_r1.profile.nickname);
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵadvance"](2);
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵtextInterpolate1"](" ", _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵpipeBind1"](6, 3, "profile.mail"));
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵadvance"](3);
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵtextInterpolate"](ctx_r1.profile.mail);
  }
}
function ProfileComponent_div_0_ng_template_4_ion_item_7_Template(rf, ctx) {
  if (rf & 1) {
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵelementStart"](0, "ion-item", 5)(1, "ion-label")(2, "div");
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵtext"](3);
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵpipe"](4, "translate");
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵelementStart"](5, "b");
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵtext"](6);
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵpipe"](7, "localDate");
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵelementEnd"]()()()();
  }
  if (rf & 2) {
    const ctx_r1 = _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵnextContext"](3);
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵadvance"](3);
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵtextInterpolate1"](" ", _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵpipeBind1"](4, 2, "profile.activeFrom"));
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵadvance"](3);
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵtextInterpolate"](_angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵpipeBind2"](7, 4, ctx_r1.activeFrom, "shortDate"));
  }
}
function ProfileComponent_div_0_ng_template_4_ion_item_8_Template(rf, ctx) {
  if (rf & 1) {
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵelementStart"](0, "ion-item", 5)(1, "ion-label")(2, "div");
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵtext"](3);
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵpipe"](4, "translate");
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵelementStart"](5, "b");
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵtext"](6);
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵpipe"](7, "languageMap");
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵelementEnd"]()()()();
  }
  if (rf & 2) {
    const ctx_r1 = _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵnextContext"](3);
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵadvance"](3);
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵtextInterpolate1"](" ", _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵpipeBind1"](4, 2, "profile.territory"));
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵadvance"](3);
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵtextInterpolate"](_angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵpipeBind1"](7, 4, ctx_r1.territory.name));
  }
}
function ProfileComponent_div_0_ng_template_4_Template(rf, ctx) {
  if (rf & 1) {
    const _r3 = _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵgetCurrentView"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵelementStart"](0, "ion-item", 10)(1, "div", 11)(2, "ion-avatar", 12);
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵelement"](3, "img", 7);
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵpipe"](4, "translate");
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵelementEnd"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵelementStart"](5, "ion-icon", 13);
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵlistener"]("click", function ProfileComponent_div_0_ng_template_4_Template_ion_icon_click_5_listener() {
      _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵrestoreView"](_r3);
      const ctx_r1 = _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵnextContext"](2);
      return _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵresetView"](ctx_r1.changeAvatar());
    });
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵelementEnd"]()();
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵtemplate"](6, ProfileComponent_div_0_ng_template_4_ion_label_6_Template, 9, 5, "ion-label", 14);
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵelementEnd"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵtemplate"](7, ProfileComponent_div_0_ng_template_4_ion_item_7_Template, 8, 7, "ion-item", 14)(8, ProfileComponent_div_0_ng_template_4_ion_item_8_Template, 8, 6, "ion-item", 14);
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵelementStart"](9, "ion-item", 5)(10, "ion-label")(11, "div");
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵtext"](12);
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵpipe"](13, "translate");
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵelementStart"](14, "b");
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵtext"](15);
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵelementEnd"]()()()();
  }
  if (rf & 2) {
    const ctx_r1 = _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵnextContext"](2);
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵadvance"](3);
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵproperty"]("title", _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵinterpolate"](_angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵpipeBind1"](4, 8, "registration.avatar.title")))("src", ctx_r1.profile.avatar.avatarUrl, _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵsanitizeUrl"]);
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵadvance"](3);
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵproperty"]("ngIf", ctx_r1.profile == null ? null : ctx_r1.profile.mail);
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵadvance"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵproperty"]("ngIf", ctx_r1.activeFrom);
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵadvance"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵproperty"]("ngIf", ctx_r1.territory == null ? null : ctx_r1.territory.name);
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵadvance"](4);
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵtextInterpolate1"](" ", _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵpipeBind1"](13, 10, "profile.status.myCampaigns"));
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵadvance"](3);
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵtextInterpolate"](ctx_r1.numMyCampaigns);
  }
}
function ProfileComponent_div_0_Template(rf, ctx) {
  if (rf & 1) {
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵelementStart"](0, "div");
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵtemplate"](1, ProfileComponent_div_0_div_1_Template, 1, 0, "div", 3)(2, ProfileComponent_div_0_ng_template_2_Template, 9, 6, "ng-template", null, 0, _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵtemplateRefExtractor"])(4, ProfileComponent_div_0_ng_template_4_Template, 16, 12, "ng-template", null, 1, _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵtemplateRefExtractor"]);
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵelementEnd"]();
  }
  if (rf & 2) {
    const homeProfile_r4 = _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵreference"](3);
    const editingProfile_r5 = _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵreference"](5);
    const ctx_r1 = _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵnextContext"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵadvance"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵproperty"]("ngIf", !ctx_r1.editable)("ngIfThen", homeProfile_r4)("ngIfElse", editingProfile_r5);
  }
}
class ProfileComponent {
  constructor(userService, campaignService, navCtrl, errorService, cdr) {
    this.userService = userService;
    this.campaignService = campaignService;
    this.navCtrl = navCtrl;
    this.errorService = errorService;
    this.cdr = cdr;
    this.editable = false;
  }
  ngOnInit() {
    this.subProf = this.userService.userProfile$.subscribe(profile => {
      this.profile = profile;
    });
    this.subTerritory = this.userService.userProfileTerritory$.subscribe(territory => {
      this.territory = territory;
    });
    this.subCamp = this.campaignService.myCampaigns$.subscribe(myCampaigns => {
      this.numMyCampaigns = myCampaigns?.length;
      this.activeFrom = myCampaigns?.find(camp => camp.campaign?.type === 'personal')?.subscription?.registrationDate;
    });
  }
  ngOnDestroy() {
    this.subProf.unsubscribe();
    this.subCamp.unsubscribe();
  }
  changeAvatar() {
    var _this = this;
    return (0,_Users_smartcommunitylab_Desktop_newWork_playAndGo_playGo_node_modules_babel_runtime_helpers_esm_asyncToGenerator_js__WEBPACK_IMPORTED_MODULE_0__["default"])(function* () {
      _this.image = yield _capacitor_camera__WEBPACK_IMPORTED_MODULE_1__.Camera.getPhoto({
        quality: 90,
        allowEditing: false,
        resultType: _capacitor_camera__WEBPACK_IMPORTED_MODULE_1__.CameraResultType.Uri
      });
      yield _this.userService.uploadAvatar(_this.profile, yield (0,_utils__WEBPACK_IMPORTED_MODULE_2__.readAsBase64)(_this.image));
    })();
  }
  goToProfile() {
    this.navCtrl.navigateForward('/pages/tabs/home/profile');
  }
  static #_ = _staticBlock = () => (this.ɵfac = function ProfileComponent_Factory(__ngFactoryType__) {
    return new (__ngFactoryType__ || ProfileComponent)(_angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵdirectiveInject"](src_app_core_shared_services_user_service__WEBPACK_IMPORTED_MODULE_6__.UserService), _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵdirectiveInject"](_services_campaign_service__WEBPACK_IMPORTED_MODULE_7__.CampaignService), _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵdirectiveInject"](_ionic_angular__WEBPACK_IMPORTED_MODULE_8__.NavController), _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵdirectiveInject"](_services_error_service__WEBPACK_IMPORTED_MODULE_10__.ErrorService), _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵdirectiveInject"](_angular_core__WEBPACK_IMPORTED_MODULE_5__.ChangeDetectorRef));
  }, this.ɵcmp = /*@__PURE__*/_angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵdefineComponent"]({
    type: ProfileComponent,
    selectors: [["app-profile-component"]],
    inputs: {
      editable: "editable"
    },
    standalone: false,
    decls: 1,
    vars: 1,
    consts: [["homeProfile", ""], ["editingProfile", ""], [4, "ngIf"], [4, "ngIf", "ngIfThen", "ngIfElse"], [3, "click"], ["lines", "none"], ["slot", "start", 1, "avatar"], [3, "src", "title"], [1, "ion-text-center"], [1, "nickname"], ["lines", "none", 1, "ion-margin-bottom"], [1, "avatar-container"], [1, "avatar"], ["name", "camera-outline", 1, "avatar-cange", 3, "click"], ["lines", "none", 4, "ngIf"], [1, "ion-text-start", "nickname-show", "ion-margin"], [1, "mail", "ion-margin"]],
    template: function ProfileComponent_Template(rf, ctx) {
      if (rf & 1) {
        _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵtemplate"](0, ProfileComponent_div_0_Template, 6, 3, "div", 2);
      }
      if (rf & 2) {
        _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵproperty"]("ngIf", ctx.profile);
      }
    },
    dependencies: [_angular_common__WEBPACK_IMPORTED_MODULE_11__.NgIf, _ionic_angular__WEBPACK_IMPORTED_MODULE_9__.IonAvatar, _ionic_angular__WEBPACK_IMPORTED_MODULE_9__.IonIcon, _ionic_angular__WEBPACK_IMPORTED_MODULE_9__.IonItem, _ionic_angular__WEBPACK_IMPORTED_MODULE_9__.IonLabel, _ngx_translate_core__WEBPACK_IMPORTED_MODULE_12__.TranslatePipe, _pipes_localDate_pipe__WEBPACK_IMPORTED_MODULE_13__.LocalDatePipe, _pipes_languageMap_pipe__WEBPACK_IMPORTED_MODULE_14__.LanguageMapPipe],
    styles: [".avatar[_ngcontent-%COMP%] {\n  background-color: white;\n  margin: auto;\n  height: 61px;\n  width: 61px;\n}\n.nickname-show[_ngcontent-%COMP%] {\n  font-weight: 600;\n  font-size: 20px;\n  line-height: 23px;\n}\n.mail[_ngcontent-%COMP%] {\n  text-overflow: ellipsis;\n  white-space: nowrap;\n  overflow: hidden;\n}\n\n.avatar-container[_ngcontent-%COMP%] {\n  margin: 33px;\n  position: relative;\n}\n.avatar-cange[_ngcontent-%COMP%] {\n  background-color: var(--ion-color-playgo);\n  color: white;\n  border-radius: 16px;\n  padding: 8px;\n  position: absolute;\n  bottom: -10%;\n  left: 80%;\n}\n.nickname[_ngcontent-%COMP%] {\n  font-size: 18px;\n  font-weight: bold;\n}\n.home-cog[_ngcontent-%COMP%] {\n  position: absolute;\n  bottom: 2px;\n  right: 2px;\n  font-size: 40px;\n  z-index: 99;\n}\n\n/*# sourceMappingURL=data:application/json;charset=utf-8;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbIndlYnBhY2s6Ly8uL3NyYy9hcHAvY29yZS9zaGFyZWQvcHJvZmlsZS1jb21wb25lbnRzL3Byb2ZpbGUtY29tcG9uZW50L3Byb2ZpbGUuY29tcG9uZW50LmNzcyJdLCJuYW1lcyI6W10sIm1hcHBpbmdzIjoiQUFBQTtFQUNFLHVCQUF1QjtFQUN2QixZQUFZO0VBQ1osWUFBWTtFQUNaLFdBQVc7QUFDYjtBQUNBO0VBQ0UsZ0JBQWdCO0VBQ2hCLGVBQWU7RUFDZixpQkFBaUI7QUFDbkI7QUFDQTtFQUNFLHVCQUF1QjtFQUN2QixtQkFBbUI7RUFDbkIsZ0JBQWdCO0FBQ2xCOztBQUVBO0VBQ0UsWUFBWTtFQUNaLGtCQUFrQjtBQUNwQjtBQUNBO0VBQ0UseUNBQXlDO0VBQ3pDLFlBQVk7RUFDWixtQkFBbUI7RUFDbkIsWUFBWTtFQUNaLGtCQUFrQjtFQUNsQixZQUFZO0VBQ1osU0FBUztBQUNYO0FBQ0E7RUFDRSxlQUFlO0VBQ2YsaUJBQWlCO0FBQ25CO0FBQ0E7RUFDRSxrQkFBa0I7RUFDbEIsV0FBVztFQUNYLFVBQVU7RUFDVixlQUFlO0VBQ2YsV0FBVztBQUNiIiwic291cmNlc0NvbnRlbnQiOlsiLmF2YXRhciB7XG4gIGJhY2tncm91bmQtY29sb3I6IHdoaXRlO1xuICBtYXJnaW46IGF1dG87XG4gIGhlaWdodDogNjFweDtcbiAgd2lkdGg6IDYxcHg7XG59XG4ubmlja25hbWUtc2hvdyB7XG4gIGZvbnQtd2VpZ2h0OiA2MDA7XG4gIGZvbnQtc2l6ZTogMjBweDtcbiAgbGluZS1oZWlnaHQ6IDIzcHg7XG59XG4ubWFpbCB7XG4gIHRleHQtb3ZlcmZsb3c6IGVsbGlwc2lzO1xuICB3aGl0ZS1zcGFjZTogbm93cmFwO1xuICBvdmVyZmxvdzogaGlkZGVuO1xufVxuXG4uYXZhdGFyLWNvbnRhaW5lciB7XG4gIG1hcmdpbjogMzNweDtcbiAgcG9zaXRpb246IHJlbGF0aXZlO1xufVxuLmF2YXRhci1jYW5nZSB7XG4gIGJhY2tncm91bmQtY29sb3I6IHZhcigtLWlvbi1jb2xvci1wbGF5Z28pO1xuICBjb2xvcjogd2hpdGU7XG4gIGJvcmRlci1yYWRpdXM6IDE2cHg7XG4gIHBhZGRpbmc6IDhweDtcbiAgcG9zaXRpb246IGFic29sdXRlO1xuICBib3R0b206IC0xMCU7XG4gIGxlZnQ6IDgwJTtcbn1cbi5uaWNrbmFtZSB7XG4gIGZvbnQtc2l6ZTogMThweDtcbiAgZm9udC13ZWlnaHQ6IGJvbGQ7XG59XG4uaG9tZS1jb2cge1xuICBwb3NpdGlvbjogYWJzb2x1dGU7XG4gIGJvdHRvbTogMnB4O1xuICByaWdodDogMnB4O1xuICBmb250LXNpemU6IDQwcHg7XG4gIHotaW5kZXg6IDk5O1xufVxuIl0sInNvdXJjZVJvb3QiOiIifQ== */"]
  }));
}
_staticBlock();

/***/ }),

/***/ 26311:
/*!***********************************************************************************************************************************!*\
  !*** ./src/app/core/shared/campaigns/home-widget-types/home-campaign-school/home-school-profile/home-school-profile.component.ts ***!
  \***********************************************************************************************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   HomeSchoolProfiloComponent: () => (/* binding */ HomeSchoolProfiloComponent)
/* harmony export */ });
/* harmony import */ var rxjs__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! rxjs */ 86301);
/* harmony import */ var rxjs__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! rxjs */ 36647);
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @angular/core */ 34205);
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @angular/core */ 12481);
/* harmony import */ var src_app_core_shared_services_team_service__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! src/app/core/shared/services/team.service */ 62625);
/* harmony import */ var src_app_core_shared_services_error_service__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! src/app/core/shared/services/error.service */ 46078);
/* harmony import */ var _ionic_angular__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! @ionic/angular */ 4059);
/* harmony import */ var _ionic_angular__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(/*! @ionic/angular */ 21507);
/* harmony import */ var _angular_common__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(/*! @angular/common */ 93683);
var _staticBlock;






function HomeSchoolProfiloComponent_div_0_ion_row_9_ion_col_1_Template(rf, ctx) {
  if (rf & 1) {
    const _r1 = _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵgetCurrentView"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵelementStart"](0, "ion-col", 7);
    _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵlistener"]("click", function HomeSchoolProfiloComponent_div_0_ion_row_9_ion_col_1_Template_ion_col_click_0_listener($event) {
      _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵrestoreView"](_r1);
      const ctx_r1 = _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵnextContext"](3);
      return _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵresetView"](ctx_r1.gotToProfile($event));
    });
    _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵelementStart"](1, "span", 8);
    _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵtext"](2);
    _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵpipe"](3, "async");
    _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵelementEnd"]()();
  }
  if (rf & 2) {
    let tmp_3_0;
    const ctx_r1 = _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵnextContext"](3);
    _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵadvance"](2);
    _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵtextInterpolate"]((tmp_3_0 = _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵpipeBind1"](3, 1, ctx_r1.myTeam$)) == null ? null : tmp_3_0.customData == null ? null : tmp_3_0.customData.name);
  }
}
function HomeSchoolProfiloComponent_div_0_ion_row_9_Template(rf, ctx) {
  if (rf & 1) {
    _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵelementStart"](0, "ion-row");
    _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵtemplate"](1, HomeSchoolProfiloComponent_div_0_ion_row_9_ion_col_1_Template, 4, 3, "ion-col", 6);
    _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵpipe"](2, "async");
    _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵelementEnd"]();
  }
  if (rf & 2) {
    let tmp_2_0;
    const ctx_r1 = _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵnextContext"](2);
    _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵadvance"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵproperty"]("ngIf", (tmp_2_0 = _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵpipeBind1"](2, 1, ctx_r1.myTeam$)) == null ? null : tmp_2_0.customData == null ? null : tmp_2_0.customData.name);
  }
}
function HomeSchoolProfiloComponent_div_0_ion_row_11_Template(rf, ctx) {
  if (rf & 1) {
    _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵelementStart"](0, "ion-row")(1, "ion-col", 9)(2, "span", 10);
    _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵtext"](3);
    _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵpipe"](4, "async");
    _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵelementEnd"]()()();
  }
  if (rf & 2) {
    let tmp_2_0;
    const ctx_r1 = _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵnextContext"](2);
    _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵadvance"](3);
    _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵtextInterpolate1"]("", (tmp_2_0 = _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵpipeBind1"](4, 1, ctx_r1.myTeam$)) == null ? null : tmp_2_0.customData == null ? null : tmp_2_0.customData.desc, " ");
  }
}
function HomeSchoolProfiloComponent_div_0_Template(rf, ctx) {
  if (rf & 1) {
    _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵelementStart"](0, "div")(1, "ion-grid")(2, "ion-row")(3, "ion-col", 1)(4, "div", 2)(5, "ion-avatar", 3);
    _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵelement"](6, "img", 4);
    _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵpipe"](7, "async");
    _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵelementEnd"]()()();
    _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵelementStart"](8, "ion-col", 5);
    _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵtemplate"](9, HomeSchoolProfiloComponent_div_0_ion_row_9_Template, 3, 3, "ion-row", 0);
    _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵpipe"](10, "async");
    _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵtemplate"](11, HomeSchoolProfiloComponent_div_0_ion_row_11_Template, 5, 3, "ion-row", 0);
    _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵpipe"](12, "async");
    _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵelementEnd"]()()()();
  }
  if (rf & 2) {
    let tmp_1_0;
    let tmp_2_0;
    let tmp_3_0;
    const ctx_r1 = _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵnextContext"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵadvance"](6);
    _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵproperty"]("src", (tmp_1_0 = _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵpipeBind1"](7, 3, ctx_r1.teamAvatar$)) == null ? null : tmp_1_0.avatarUrl, _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵsanitizeUrl"]);
    _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵadvance"](3);
    _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵproperty"]("ngIf", (tmp_2_0 = _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵpipeBind1"](10, 5, ctx_r1.myTeam$)) == null ? null : tmp_2_0.customData == null ? null : tmp_2_0.customData.name);
    _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵadvance"](2);
    _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵproperty"]("ngIf", (tmp_3_0 = _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵpipeBind1"](12, 7, ctx_r1.myTeam$)) == null ? null : tmp_3_0.customData == null ? null : tmp_3_0.customData.desc);
  }
}
class HomeSchoolProfiloComponent {
  constructor(teamService, errorService, navController) {
    this.teamService = teamService;
    this.errorService = errorService;
    this.navController = navController;
  }
  ngOnInit() {
    this.myTeam$ = this.teamService.getMyTeam(this.campaignContainer?.campaign?.campaignId, this.campaignContainer?.subscription?.campaignData?.teamId);
    this.teamAvatar$ = this.myTeam$.pipe((0,rxjs__WEBPACK_IMPORTED_MODULE_1__.switchMap)(myTeam => this.teamService.getTeamAvatar(myTeam.id).pipe(this.errorService.getErrorHandler())), (0,rxjs__WEBPACK_IMPORTED_MODULE_0__.shareReplay)(1));
  }
  goToChallenge(event) {}
  gotToProfile(event) {
    if (event && event.stopPropagation) {
      event.stopPropagation();
    }
    this.navController.navigateForward('/pages/team-profile/' + this.campaignContainer?.campaign?.campaignId + '/' + this.campaignContainer?.subscription?.campaignData?.teamId + '/my');
  }
  ngOnDestroy() {}
  static #_ = _staticBlock = () => (this.ɵfac = function HomeSchoolProfiloComponent_Factory(__ngFactoryType__) {
    return new (__ngFactoryType__ || HomeSchoolProfiloComponent)(_angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵdirectiveInject"](src_app_core_shared_services_team_service__WEBPACK_IMPORTED_MODULE_4__.TeamService), _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵdirectiveInject"](src_app_core_shared_services_error_service__WEBPACK_IMPORTED_MODULE_5__.ErrorService), _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵdirectiveInject"](_ionic_angular__WEBPACK_IMPORTED_MODULE_6__.NavController));
  }, this.ɵcmp = /*@__PURE__*/_angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵdefineComponent"]({
    type: HomeSchoolProfiloComponent,
    selectors: [["app-home-school-profile"]],
    inputs: {
      campaignContainer: "campaignContainer",
      player: "player"
    },
    standalone: false,
    decls: 1,
    vars: 1,
    consts: [[4, "ngIf"], ["size", "auto", 1, "avatar-col"], [1, "user-intro"], [1, "team"], [3, "src"], ["size", "8"], ["class", "ion-text-start name-school", 3, "click", 4, "ngIf"], [1, "ion-text-start", "name-school", 3, "click"], [1, "name"], [1, "ion-text-start", "desc-school"], [1, "institute"]],
    template: function HomeSchoolProfiloComponent_Template(rf, ctx) {
      if (rf & 1) {
        _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵtemplate"](0, HomeSchoolProfiloComponent_div_0_Template, 13, 9, "div", 0);
      }
      if (rf & 2) {
        _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵproperty"]("ngIf", ctx.myTeam$);
      }
    },
    dependencies: [_angular_common__WEBPACK_IMPORTED_MODULE_8__.NgIf, _ionic_angular__WEBPACK_IMPORTED_MODULE_7__.IonAvatar, _ionic_angular__WEBPACK_IMPORTED_MODULE_7__.IonCol, _ionic_angular__WEBPACK_IMPORTED_MODULE_7__.IonGrid, _ionic_angular__WEBPACK_IMPORTED_MODULE_7__.IonRow, _angular_common__WEBPACK_IMPORTED_MODULE_8__.AsyncPipe],
    styles: [".institute[_ngcontent-%COMP%] {\n  font-size: 13px;\n  font-style: italic;\n  font-weight: 300;\n  line-height: 15px;\n  letter-spacing: 0px;\n  text-align: left;\n  text-overflow: ellipsis;\n  overflow: hidden;\n  white-space: nowrap;\n}\n\n.name[_ngcontent-%COMP%] {\n  font-size: 18px;\n  font-weight: 600;\n  line-height: 21px;\n  letter-spacing: 0px;\n  text-align: left;\n}\n\n.avatar-col[_ngcontent-%COMP%] {\n  display: flex;\n  justify-content: space-evenly;\n  flex-direction: column;\n}\n\n.name-school[_ngcontent-%COMP%] {\n  display: flex;\n  justify-content: space-evenly;\n  flex-direction: column;\n  font-weight: 700;\n  color: var(--ion-color-playgo);\n  margin-top: 8px;\n  font-style: italic;\n  text-decoration: underline;\n}\n\n.desc-school[_ngcontent-%COMP%] {\n  display: flex;\n  justify-content: space-evenly;\n  flex-direction: column;\n}\n/*# sourceMappingURL=data:application/json;charset=utf-8;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbIndlYnBhY2s6Ly8uL3NyYy9hcHAvY29yZS9zaGFyZWQvY2FtcGFpZ25zL2hvbWUtd2lkZ2V0LXR5cGVzL2hvbWUtY2FtcGFpZ24tc2Nob29sL2hvbWUtc2Nob29sLXByb2ZpbGUvaG9tZS1zY2hvb2wtcHJvZmlsZS5jb21wb25lbnQuc2NzcyJdLCJuYW1lcyI6W10sIm1hcHBpbmdzIjoiQUFBQTtFQUNFLGVBQUE7RUFDQSxrQkFBQTtFQUNBLGdCQUFBO0VBQ0EsaUJBQUE7RUFDQSxtQkFBQTtFQUNBLGdCQUFBO0VBQ0EsdUJBQUE7RUFDQSxnQkFBQTtFQUNBLG1CQUFBO0FBQ0Y7O0FBQ0E7RUFDRSxlQUFBO0VBQ0EsZ0JBQUE7RUFDQSxpQkFBQTtFQUNBLG1CQUFBO0VBQ0EsZ0JBQUE7QUFFRjs7QUFBQTtFQUNFLGFBQUE7RUFDQSw2QkFBQTtFQUNBLHNCQUFBO0FBR0Y7O0FBREE7RUFDRSxhQUFBO0VBQ0EsNkJBQUE7RUFDQSxzQkFBQTtFQUNBLGdCQUFBO0VBQ0EsOEJBQUE7RUFDQSxlQUFBO0VBQ0Esa0JBQUE7RUFDQSwwQkFBQTtBQUlGOztBQUZBO0VBQ0UsYUFBQTtFQUNBLDZCQUFBO0VBQ0Esc0JBQUE7QUFLRiIsInNvdXJjZXNDb250ZW50IjpbIi5pbnN0aXR1dGUge1xuICBmb250LXNpemU6IDEzcHg7XG4gIGZvbnQtc3R5bGU6IGl0YWxpYztcbiAgZm9udC13ZWlnaHQ6IDMwMDtcbiAgbGluZS1oZWlnaHQ6IDE1cHg7XG4gIGxldHRlci1zcGFjaW5nOiAwcHg7XG4gIHRleHQtYWxpZ246IGxlZnQ7XG4gIHRleHQtb3ZlcmZsb3c6IGVsbGlwc2lzO1xuICBvdmVyZmxvdzogaGlkZGVuO1xuICB3aGl0ZS1zcGFjZTogbm93cmFwO1xufVxuLm5hbWUge1xuICBmb250LXNpemU6IDE4cHg7XG4gIGZvbnQtd2VpZ2h0OiA2MDA7XG4gIGxpbmUtaGVpZ2h0OiAyMXB4O1xuICBsZXR0ZXItc3BhY2luZzogMHB4O1xuICB0ZXh0LWFsaWduOiBsZWZ0O1xufVxuLmF2YXRhci1jb2wge1xuICBkaXNwbGF5OiBmbGV4O1xuICBqdXN0aWZ5LWNvbnRlbnQ6IHNwYWNlLWV2ZW5seTtcbiAgZmxleC1kaXJlY3Rpb246IGNvbHVtbjtcbn1cbi5uYW1lLXNjaG9vbCB7XG4gIGRpc3BsYXk6IGZsZXg7XG4gIGp1c3RpZnktY29udGVudDogc3BhY2UtZXZlbmx5O1xuICBmbGV4LWRpcmVjdGlvbjogY29sdW1uO1xuICBmb250LXdlaWdodDogNzAwO1xuICBjb2xvcjogdmFyKC0taW9uLWNvbG9yLXBsYXlnbyk7XG4gIG1hcmdpbi10b3A6IDhweDtcbiAgZm9udC1zdHlsZTogaXRhbGljO1xuICB0ZXh0LWRlY29yYXRpb246IHVuZGVybGluZTtcbn1cbi5kZXNjLXNjaG9vbCB7XG4gIGRpc3BsYXk6IGZsZXg7XG4gIGp1c3RpZnktY29udGVudDogc3BhY2UtZXZlbmx5O1xuICBmbGV4LWRpcmVjdGlvbjogY29sdW1uO1xufVxuIl0sInNvdXJjZVJvb3QiOiIifQ== */"]
  }));
}
_staticBlock();

/***/ }),

/***/ 26856:
/*!**********************************************************************************************!*\
  !*** ./src/app/core/shared/campaigns/challenge-bar-status/challenge-bar-status.component.ts ***!
  \**********************************************************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   ChallengeBarStatusComponent: () => (/* binding */ ChallengeBarStatusComponent)
/* harmony export */ });
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! @angular/core */ 12481);
/* harmony import */ var _angular_common__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @angular/common */ 93683);
var _staticBlock;


function ChallengeBarStatusComponent_div_2_Template(rf, ctx) {
  if (rf & 1) {
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelement"](0, "div", 4);
  }
}
function ChallengeBarStatusComponent_div_3_Template(rf, ctx) {
  if (rf & 1) {
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelement"](0, "div", 5);
  }
  if (rf & 2) {
    const ctx_r0 = _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵnextContext"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵstyleProp"]("width", ctx_r0.getWidth(ctx_r0.otherStatus));
  }
}
class ChallengeBarStatusComponent {
  // @Input() position?: string;
  constructor() {}
  ngOnInit() {
    // console.log(this.status);
    console.log(this.challengeType);
  }
  getWidth(status) {
    if (this.challengeType === 'groupCompetitiveTime') {
      return `calc(${status / 2}% - 8px)`;
    }
    return `calc(${status}% - 8px)`;
  }
  getColor(type) {
    if (type === 'school') {
      return 'var(--ion-color-school)';
    }
    if (type === 'city') {
      return 'var(--ion-color-city)';
    }
    return 'var(--ion-color-personal)';
  }
  getBackgroundColor(type) {
    if (type === 'school') {
      return 'var(--ion-color-school)';
    }
    if (type === 'city') {
      return 'var(--ion-color-city)';
    }
    return 'var(--ion-color-personal)';
  }
  static #_ = _staticBlock = () => (this.ɵfac = function ChallengeBarStatusComponent_Factory(__ngFactoryType__) {
    return new (__ngFactoryType__ || ChallengeBarStatusComponent)();
  }, this.ɵcmp = /*@__PURE__*/_angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵdefineComponent"]({
    type: ChallengeBarStatusComponent,
    selectors: [["app-challenge-bar-status"]],
    inputs: {
      status: "status",
      rowStatus: "rowStatus",
      otherStatus: "otherStatus",
      type: "type",
      campaignType: "campaignType",
      challengeType: "challengeType"
    },
    standalone: false,
    decls: 4,
    vars: 8,
    consts: [[1, "progress"], [1, "progress-bar"], ["class", "separator", 4, "ngIf"], ["class", "progress-bar-opposite", 3, "width", 4, "ngIf"], [1, "separator"], [1, "progress-bar-opposite"]],
    template: function ChallengeBarStatusComponent_Template(rf, ctx) {
      if (rf & 1) {
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](0, "div", 0);
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelement"](1, "div", 1);
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵtemplate"](2, ChallengeBarStatusComponent_div_2_Template, 1, 0, "div", 2)(3, ChallengeBarStatusComponent_div_3_Template, 1, 2, "div", 3);
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();
      }
      if (rf & 2) {
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵadvance"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵstyleProp"]("width", ctx.getWidth(ctx.status))("color", ctx.getColor(ctx.campaignType))("background-color", ctx.getBackgroundColor(ctx.campaignType));
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵadvance"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵproperty"]("ngIf", ctx.challengeType === "groupCompetitiveTime");
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵadvance"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵproperty"]("ngIf", ctx.otherStatus !== null);
      }
    },
    dependencies: [_angular_common__WEBPACK_IMPORTED_MODULE_1__.NgIf],
    styles: [".progress[_ngcontent-%COMP%] {\n  padding: 2px;\n  margin: 4px;\n  border: 1px solid lightgray;\n  height: 22px;\n  position: relative;\n}\n.progress[_ngcontent-%COMP%]   .separator[_ngcontent-%COMP%] {\n  height: inherit;\n  width: 3px;\n  background-color: lightgray;\n  position: absolute;\n  left: 50%;\n  top: 0px;\n}\n.progress[_ngcontent-%COMP%]   .progress-bar[_ngcontent-%COMP%] {\n  height: 100%;\n  background-color: #fdd835;\n  float: left;\n}\n.progress[_ngcontent-%COMP%]   .progress-bar-opposite[_ngcontent-%COMP%] {\n  height: 100%;\n  float: right;\n  background-color: #f29900;\n  padding: 2px;\n  border: solid 1px var(--ion-color-sad-gray);\n  border-radius: 4px;\n}\n\n@keyframes _ngcontent-%COMP%_fill-bar {\n  from {\n    width: 0%;\n  }\n  to {\n    width: 100%;\n  }\n}\n/*# sourceMappingURL=data:application/json;charset=utf-8;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbIndlYnBhY2s6Ly8uL3NyYy9hcHAvY29yZS9zaGFyZWQvY2FtcGFpZ25zL2NoYWxsZW5nZS1iYXItc3RhdHVzL2NoYWxsZW5nZS1iYXItc3RhdHVzLmNvbXBvbmVudC5zY3NzIl0sIm5hbWVzIjpbXSwibWFwcGluZ3MiOiJBQUFBO0VBRUUsWUFBQTtFQUdBLFdBQUE7RUFDQSwyQkFBQTtFQUNBLFlBQUE7RUFDQSxrQkFBQTtBQUZGO0FBTUU7RUFDRSxlQUFBO0VBQ0EsVUFBQTtFQUNBLDJCQUFBO0VBQ0Esa0JBQUE7RUFDQSxTQUFBO0VBQ0EsUUFBQTtBQUpKO0FBTUU7RUFDRSxZQUFBO0VBQ0EseUJBQUE7RUFDQSxXQUFBO0FBSko7QUFRRTtFQUVFLFlBQUE7RUFDQSxZQUFBO0VBQ0EseUJBQUE7RUFDQSxZQUFBO0VBQ0EsMkNBQUE7RUFDQSxrQkFBQTtBQVBKOztBQVdBO0VBQ0U7SUFDRSxTQUFBO0VBUkY7RUFVQTtJQUNFLFdBQUE7RUFSRjtBQUNGIiwic291cmNlc0NvbnRlbnQiOlsiLnByb2dyZXNzIHtcbiAgLy8gICBtYXJnaW46IDUwcHggYXV0bztcbiAgcGFkZGluZzogMnB4O1xuICAvLyB3aWR0aDogMTAwJTtcbiAgLy8gICBtYXgtd2lkdGg6IDUwMHB4O1xuICBtYXJnaW46IDRweDtcbiAgYm9yZGVyOiAxcHggc29saWQgbGlnaHRncmF5O1xuICBoZWlnaHQ6IDIycHg7XG4gIHBvc2l0aW9uOiByZWxhdGl2ZTtcbiAgLy8gICBkaXNwbGF5OiBmbGV4O1xuICAvLyAgIC5wbGF5ZXItcHJvZ3Jlc3MtY29udGFpbmVyIHtcbiAgLy8gICAgIGhlaWdodDogMTAwJTtcbiAgLnNlcGFyYXRvciB7XG4gICAgaGVpZ2h0OiBpbmhlcml0O1xuICAgIHdpZHRoOiAzcHg7XG4gICAgYmFja2dyb3VuZC1jb2xvcjogbGlnaHRncmF5O1xuICAgIHBvc2l0aW9uOiBhYnNvbHV0ZTtcbiAgICBsZWZ0OiA1MCU7XG4gICAgdG9wOiAwcHg7XG4gIH1cbiAgLnByb2dyZXNzLWJhciB7XG4gICAgaGVpZ2h0OiAxMDAlO1xuICAgIGJhY2tncm91bmQtY29sb3I6ICNmZGQ4MzU7XG4gICAgZmxvYXQ6IGxlZnQ7XG4gIH1cbiAgLy8gICAub3Bwb3NpdGUtcGxheWVyLXByb2dyZXNzLWNvbnRhaW5lciB7XG4gIC8vICAgICBoZWlnaHQ6IDEwMCU7XG4gIC5wcm9ncmVzcy1iYXItb3Bwb3NpdGUge1xuICAgIC8vICAgcm90YXRlOiAxODBkZWc7XG4gICAgaGVpZ2h0OiAxMDAlO1xuICAgIGZsb2F0OiByaWdodDtcbiAgICBiYWNrZ3JvdW5kLWNvbG9yOiAjZjI5OTAwO1xuICAgIHBhZGRpbmc6IDJweDtcbiAgICBib3JkZXI6IHNvbGlkIDFweCB2YXIoLS1pb24tY29sb3Itc2FkLWdyYXkpO1xuICAgIGJvcmRlci1yYWRpdXM6IDRweDtcbiAgfVxufVxuLy8gfVxuQGtleWZyYW1lcyBmaWxsLWJhciB7XG4gIGZyb20ge1xuICAgIHdpZHRoOiAwJTtcbiAgfVxuICB0byB7XG4gICAgd2lkdGg6IDEwMCU7XG4gIH1cbn1cbiJdLCJzb3VyY2VSb290IjoiIn0= */"]
  }));
}
_staticBlock();

/***/ }),

/***/ 27215:
/*!*********************************************************************!*\
  !*** ./src/app/core/shared/tracking/background-tracking.service.ts ***!
  \*********************************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   BackgroundTrackingService: () => (/* binding */ BackgroundTrackingService),
/* harmony export */   TripLocation: () => (/* binding */ TripLocation)
/* harmony export */ });
/* harmony import */ var _Users_smartcommunitylab_Desktop_newWork_playAndGo_playGo_node_modules_babel_runtime_helpers_esm_asyncToGenerator_js__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./node_modules/@babel/runtime/helpers/esm/asyncToGenerator.js */ 89204);
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @angular/core */ 12481);
/* harmony import */ var _transistorsoft_capacitor_background_geolocation__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @transistorsoft/capacitor-background-geolocation */ 5914);
/* harmony import */ var lodash_es__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! lodash-es */ 93362);
/* harmony import */ var lodash_es__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! lodash-es */ 92434);
/* harmony import */ var lodash_es__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! lodash-es */ 80524);
/* harmony import */ var rxjs__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! rxjs */ 56042);
/* harmony import */ var rxjs__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(/*! rxjs */ 56196);
/* harmony import */ var rxjs__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(/*! rxjs */ 19999);
/* harmony import */ var rxjs__WEBPACK_IMPORTED_MODULE_9__ = __webpack_require__(/*! rxjs */ 44665);
/* harmony import */ var rxjs__WEBPACK_IMPORTED_MODULE_10__ = __webpack_require__(/*! rxjs */ 63617);
/* harmony import */ var rxjs__WEBPACK_IMPORTED_MODULE_11__ = __webpack_require__(/*! rxjs */ 14876);
/* harmony import */ var rxjs_operators__WEBPACK_IMPORTED_MODULE_12__ = __webpack_require__(/*! rxjs/operators */ 91817);
/* harmony import */ var rxjs_operators__WEBPACK_IMPORTED_MODULE_13__ = __webpack_require__(/*! rxjs/operators */ 89475);
/* harmony import */ var rxjs_operators__WEBPACK_IMPORTED_MODULE_14__ = __webpack_require__(/*! rxjs/operators */ 2435);
/* harmony import */ var rxjs_operators__WEBPACK_IMPORTED_MODULE_15__ = __webpack_require__(/*! rxjs/operators */ 70271);
/* harmony import */ var rxjs_operators__WEBPACK_IMPORTED_MODULE_16__ = __webpack_require__(/*! rxjs/operators */ 86301);
/* harmony import */ var rxjs_operators__WEBPACK_IMPORTED_MODULE_17__ = __webpack_require__(/*! rxjs/operators */ 63037);
/* harmony import */ var rxjs_operators__WEBPACK_IMPORTED_MODULE_18__ = __webpack_require__(/*! rxjs/operators */ 36647);
/* harmony import */ var rxjs_operators__WEBPACK_IMPORTED_MODULE_19__ = __webpack_require__(/*! rxjs/operators */ 33900);
/* harmony import */ var rxjs_operators__WEBPACK_IMPORTED_MODULE_20__ = __webpack_require__(/*! rxjs/operators */ 98764);
/* harmony import */ var _trip_model__WEBPACK_IMPORTED_MODULE_21__ = __webpack_require__(/*! ./trip.model */ 23126);
/* harmony import */ var _rxjs_utils__WEBPACK_IMPORTED_MODULE_22__ = __webpack_require__(/*! ../rxjs.utils */ 86040);
/* harmony import */ var src_environments_environment__WEBPACK_IMPORTED_MODULE_23__ = __webpack_require__(/*! src/environments/environment */ 45312);
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_24__ = __webpack_require__(/*! @angular/core */ 34205);
/* harmony import */ var src_app_core_shared_services_alert_service__WEBPACK_IMPORTED_MODULE_25__ = __webpack_require__(/*! src/app/core/shared/services/alert.service */ 67406);
/* harmony import */ var _auth_auth_service__WEBPACK_IMPORTED_MODULE_26__ = __webpack_require__(/*! ../../auth/auth.service */ 35524);
/* harmony import */ var _api_generated_controllers_playerController_service__WEBPACK_IMPORTED_MODULE_27__ = __webpack_require__(/*! ../../api/generated/controllers/playerController.service */ 63971);
/* harmony import */ var _services_app_status_service__WEBPACK_IMPORTED_MODULE_28__ = __webpack_require__(/*! ../services/app-status.service */ 65800);
/* harmony import */ var _ngx_translate_core__WEBPACK_IMPORTED_MODULE_29__ = __webpack_require__(/*! @ngx-translate/core */ 48503);

var _staticBlock;














/**
 * Low level service, that controls starting / stopping of tracking.
 * Calls BackgroundGeolocation Plugin under the hood.
 */
class BackgroundTrackingService {
  constructor(
  // we are not using BackgroundGeolocation directly, but use dependency injection
  // so we can use mock in web (develop) version.
  backgroundGeolocationPlugin, alertService, authService, playerControllerService, appStatusService, zone, translateService) {
    this.backgroundGeolocationPlugin = backgroundGeolocationPlugin;
    this.alertService = alertService;
    this.authService = authService;
    this.playerControllerService = playerControllerService;
    this.appStatusService = appStatusService;
    this.zone = zone;
    this.translateService = translateService;
    this.isReady = new Promise((resolve, reject) => {
      this.markAsReady = resolve;
    });
    this.appConfig = {
      tracking: {
        maximalAccuracy: 30
      }
    };
    this.pluginLocation$ = this.getPluginObservable(this.backgroundGeolocationPlugin.onLocation).pipe((0,rxjs_operators__WEBPACK_IMPORTED_MODULE_20__.tap)(_angular_core__WEBPACK_IMPORTED_MODULE_1__.NgZone.assertInAngularZone), (0,rxjs_operators__WEBPACK_IMPORTED_MODULE_16__.shareReplay)(1));
    this.accuracy$ = this.pluginLocation$.pipe((0,rxjs_operators__WEBPACK_IMPORTED_MODULE_15__.map)(loc => loc.coords.accuracy), (0,rxjs_operators__WEBPACK_IMPORTED_MODULE_16__.shareReplay)(1));
    this.lowAccuracy$ = this.accuracy$.pipe((0,rxjs_operators__WEBPACK_IMPORTED_MODULE_15__.map)(accuracy => accuracy > this.appConfig.tracking.maximalAccuracy), (0,rxjs_operators__WEBPACK_IMPORTED_MODULE_12__.distinctUntilChanged)(), (0,rxjs_operators__WEBPACK_IMPORTED_MODULE_16__.shareReplay)(1));
    this.currentLocation$ = this.pluginLocation$.pipe((0,rxjs_operators__WEBPACK_IMPORTED_MODULE_15__.map)(TripLocation.fromLocation), (0,rxjs_operators__WEBPACK_IMPORTED_MODULE_16__.shareReplay)(1));
    this.isPowerSaveMode$ = (0,rxjs__WEBPACK_IMPORTED_MODULE_9__.concat)(this.isReady.then(() => this.backgroundGeolocationPlugin.isPowerSaveMode()), this.getPluginObservable(this.backgroundGeolocationPlugin.onPowerSaveChange)).pipe((0,rxjs_operators__WEBPACK_IMPORTED_MODULE_17__.startWith)(false), (0,rxjs_operators__WEBPACK_IMPORTED_MODULE_12__.distinctUntilChanged)(), (0,rxjs_operators__WEBPACK_IMPORTED_MODULE_20__.tap)(_angular_core__WEBPACK_IMPORTED_MODULE_1__.NgZone.assertInAngularZone), (0,rxjs_operators__WEBPACK_IMPORTED_MODULE_16__.shareReplay)(1));
    /** appAndDeviceInfo is send to server on each .sync */
    this.appAndDeviceInfo$ = (0,rxjs__WEBPACK_IMPORTED_MODULE_8__.combineLatest)([this.appStatusService.appInfo$, this.appStatusService.deviceInfo$
    // this.appStatusService.codePushLabel$.pipe(startWith('unknown')),
    ]).pipe(
    // map(([appInfo, deviceInfo, codePushLabel]) => ({
    //   isVirtual: deviceInfo.isVirtual,
    //   platform: deviceInfo.platform,
    //   version: appInfo.version,
    //   codePushLabel,
    //   osVersion: deviceInfo.osVersion,
    //   model: deviceInfo.model,
    // })),
    (0,rxjs_operators__WEBPACK_IMPORTED_MODULE_15__.map)(([appInfo, deviceInfo]) => ({
      isVirtual: deviceInfo.isVirtual,
      platform: deviceInfo.platform,
      version: appInfo.version,
      // codePushLabel,
      osVersion: deviceInfo.osVersion,
      model: deviceInfo.model
    })), (0,rxjs_operators__WEBPACK_IMPORTED_MODULE_16__.shareReplay)(1));
    this.possibleLocationsChangeSubject = new rxjs__WEBPACK_IMPORTED_MODULE_6__.ReplaySubject();
    this.currentExtrasSubject = new rxjs__WEBPACK_IMPORTED_MODULE_6__.ReplaySubject();
    /** Locations that are only in plugin's database */
    this.notSynchronizedLocations$ = (0,rxjs__WEBPACK_IMPORTED_MODULE_10__.merge)(this.currentLocation$, this.possibleLocationsChangeSubject.pipe(/*debounceTime(100)*/)).pipe((0,rxjs_operators__WEBPACK_IMPORTED_MODULE_17__.startWith)('initial getLocation request'), (0,rxjs_operators__WEBPACK_IMPORTED_MODULE_18__.switchMap)(() => this.backgroundGeolocationPlugin.getLocations()), (0,rxjs_operators__WEBPACK_IMPORTED_MODULE_15__.map)(rawLocations => rawLocations.map(TripLocation.fromLocation)), (0,rxjs_operators__WEBPACK_IMPORTED_MODULE_12__.distinctUntilChanged)(lodash_es__WEBPACK_IMPORTED_MODULE_4__["default"]), (0,rxjs_operators__WEBPACK_IMPORTED_MODULE_16__.shareReplay)(1));
    this.currentTripLocations$ = (0,rxjs__WEBPACK_IMPORTED_MODULE_8__.combineLatest)([this.notSynchronizedLocations$, this.currentExtrasSubject]).pipe((0,rxjs_operators__WEBPACK_IMPORTED_MODULE_15__.map)(([notSynchronizedLocations, currentExtras]) => (0,lodash_es__WEBPACK_IMPORTED_MODULE_3__["default"])(notSynchronizedLocations, {
      multimodalId: currentExtras.multimodalId
    })), (0,rxjs_operators__WEBPACK_IMPORTED_MODULE_16__.shareReplay)(1));
    /**
     * Watch all onLocation events, but also take last location from database.
     * First value will be used in map for "current" location marker.
     */
    this.lastLocation$ = (0,rxjs__WEBPACK_IMPORTED_MODULE_9__.concat)(this.notSynchronizedLocations$.pipe((0,rxjs_operators__WEBPACK_IMPORTED_MODULE_14__.first)(), (0,rxjs_operators__WEBPACK_IMPORTED_MODULE_15__.map)(x => (0,lodash_es__WEBPACK_IMPORTED_MODULE_5__["default"])(x)), (0,rxjs_operators__WEBPACK_IMPORTED_MODULE_19__.takeUntil)(this.currentLocation$)), this.currentLocation$).pipe((0,rxjs_operators__WEBPACK_IMPORTED_MODULE_12__.distinctUntilChanged)(lodash_es__WEBPACK_IMPORTED_MODULE_4__["default"]), (0,rxjs_operators__WEBPACK_IMPORTED_MODULE_16__.shareReplay)(1));
    this.synchronizedLocationsSubject = new rxjs__WEBPACK_IMPORTED_MODULE_6__.ReplaySubject(1);
    this.synchronizedLocations$ = this.synchronizedLocationsSubject.asObservable();
    /**
     * Manually get locations without starting the tracking. Observable is cold
     * and not replayed, so each subscription will trigger new execution.
     * Used in map for "current" location marker.
     * */
    this.coldForegroundLocation$ = (0,rxjs__WEBPACK_IMPORTED_MODULE_11__.timer)(0, 10000).pipe((0,rxjs_operators__WEBPACK_IMPORTED_MODULE_18__.switchMap)(() => this.backgroundGeolocationPlugin.getCurrentPosition({
      timeout: 1000,
      persist: false
    })));
    // start observing plugin events
    this.pluginLocation$.subscribe();
    this.isPowerSaveMode$.subscribe();
  }
  askForPermissions() {
    var _this = this;
    return (0,_Users_smartcommunitylab_Desktop_newWork_playAndGo_playGo_node_modules_babel_runtime_helpers_esm_asyncToGenerator_js__WEBPACK_IMPORTED_MODULE_0__["default"])(function* () {
      yield _this.isReady;
      // Manually request permission with configured locationAuthorizationRequest.
      let status;
      const now = performance.now();
      try {
        // AUTHORIZATION_STATUS_NOT_DETERMINED | iOS only
        // AUTHORIZATION_STATUS_RESTRICTED     | iOS only
        // AUTHORIZATION_STATUS_DENIED         | iOS & Android
        // AUTHORIZATION_STATUS_ALWAYS         | iOS & Android
        // AUTHORIZATION_STATUS_WHEN_IN_USE    | iOS only
        status = yield _this.backgroundGeolocationPlugin.requestPermission();
        // console.log('status requestPermission: ' + status);
      } catch (errorStatus) {
        status = errorStatus;
      }
      const executionTime = performance.now() - now;
      // console.log('executionTime: ' + executionTime);
      if (status === _this.backgroundGeolocationPlugin.AUTHORIZATION_STATUS_ALWAYS) {
        return 'ACCEPTED';
      }
      if (status === _this.backgroundGeolocationPlugin.AUTHORIZATION_STATUS_WHEN_IN_USE) {
        return 'ACCEPTED_WHEN_IN_USE';
      }
      // After user deny permission two times, then no new popups will be presented,
      // and permission will be denied silently. If we want to show some information
      // in this case, we have heuristics measuring how long it takes to get permission.
      // If it takes more than 1 second, then we can assume that user denied permission.
      // Otherwise, we can assume that permission was denied silently. Silent denial
      // takes around 400ms
      if (executionTime < 1000) {
        return 'DENIED_SILENTLY';
      }
      return 'DENIED';
    })();
  }
  start() {
    var _this2 = this;
    return (0,_Users_smartcommunitylab_Desktop_newWork_playAndGo_playGo_node_modules_babel_runtime_helpers_esm_asyncToGenerator_js__WEBPACK_IMPORTED_MODULE_0__["default"])(function* () {
      try {
        const titlePermission = yield (0,rxjs__WEBPACK_IMPORTED_MODULE_7__.firstValueFrom)(_this2.translateService.get('permission.title'));
        const messagePermission = yield (0,rxjs__WEBPACK_IMPORTED_MODULE_7__.firstValueFrom)(_this2.translateService.get('permission.message'));
        const positiveActionPermission = yield (0,rxjs__WEBPACK_IMPORTED_MODULE_7__.firstValueFrom)(_this2.translateService.get('permission.positiveAction'));
        const cancelActionPermission = yield (0,rxjs__WEBPACK_IMPORTED_MODULE_7__.firstValueFrom)(_this2.translateService.get('permission.cancelAction'));
        const appAndDeviceInfo = yield (0,rxjs__WEBPACK_IMPORTED_MODULE_7__.firstValueFrom)(_this2.appAndDeviceInfo$);
        const config = {
          url: src_environments_environment__WEBPACK_IMPORTED_MODULE_23__.environment.serverUrl.api + src_environments_environment__WEBPACK_IMPORTED_MODULE_23__.environment.serverUrl.apiPath + '/track/player/geolocations',
          distanceFilter: 10,
          stopAfterElapsedMinutes: 8 * 60,
          stopOnTerminate: false,
          startOnBoot: false,
          autoSync: false,
          batchSync: true,
          authorization: null,
          disableLocationAuthorizationAlert: true,
          notification: {
            smallIcon: 'drawable/ic_push'
          },
          backgroundPermissionRationale: {
            title: titlePermission,
            message: messagePermission,
            positiveAction: positiveActionPermission,
            negativeAction: cancelActionPermission
          },
          params: {
            device: appAndDeviceInfo
          }
        };
        // console.log('starting BackgroundGeolocation', config);
        const state = yield _this2.backgroundGeolocationPlugin.ready(config);
        console.log('BackgroundGeolocation ready', state, config);
      } catch (e) {
        console.error('BackgroundGeolocation', e);
      }
      // after this all plugin methods could be called. We can use `await this.isReady`
      _this2.markAsReady(true);
    })();
  }
  syncInitialLocations() {
    var _this3 = this;
    return (0,_Users_smartcommunitylab_Desktop_newWork_playAndGo_playGo_node_modules_babel_runtime_helpers_esm_asyncToGenerator_js__WEBPACK_IMPORTED_MODULE_0__["default"])(function* () {
      yield _this3.isReady;
      yield _this3.sync();
      yield _this3.backgroundGeolocationPlugin.stop();
      _this3.possibleLocationsChangeSubject.next();
    })();
  }
  startTracking(tripPart, doChecks) {
    var _this4 = this;
    return (0,_Users_smartcommunitylab_Desktop_newWork_playAndGo_playGo_node_modules_babel_runtime_helpers_esm_asyncToGenerator_js__WEBPACK_IMPORTED_MODULE_0__["default"])(function* () {
      console.log('backgroundTracking  service');
      const location = yield _this4.setExtrasAndForceLocation(tripPart);
      const accuracy = location.coords.accuracy;
      // we are not doing checks in case of change of the mean
      if (doChecks) {
        if (accuracy > _this4.appConfig.tracking.maximalAccuracy) {
          const userAcceptsLowAccuracy = yield _this4.showLowAccuracyWarning();
          if (!userAcceptsLowAccuracy) {
            throw _trip_model__WEBPACK_IMPORTED_MODULE_21__.LOW_ACCURACY;
          }
        }
        const isPowerSaveMode = yield _this4.backgroundGeolocationPlugin.isPowerSaveMode();
        if (isPowerSaveMode) {
          throw _trip_model__WEBPACK_IMPORTED_MODULE_21__.POWER_SAVE_MODE;
        }
      }
      yield _this4.backgroundGeolocationPlugin.start().then(state => {
        _this4.backgroundGeolocationPlugin.changePace(true);
      });
      _this4.possibleLocationsChangeSubject.next();
    })();
  }
  showLowAccuracyWarning() {
    var _this5 = this;
    return (0,_Users_smartcommunitylab_Desktop_newWork_playAndGo_playGo_node_modules_babel_runtime_helpers_esm_asyncToGenerator_js__WEBPACK_IMPORTED_MODULE_0__["default"])(function* () {
      return yield _this5.alertService.confirmAlert('modal.alert_title', 'tracking.continue_low_accuracy_prompt');
    })();
  }
  /** For example after logout / delete account.. */
  clearPluginData() {
    var _this6 = this;
    return (0,_Users_smartcommunitylab_Desktop_newWork_playAndGo_playGo_node_modules_babel_runtime_helpers_esm_asyncToGenerator_js__WEBPACK_IMPORTED_MODULE_0__["default"])(function* () {
      yield _this6.isReady;
      yield _this6.backgroundGeolocationPlugin.setConfig({});
      _this6.currentExtrasSubject.next({});
      yield _this6.backgroundGeolocationPlugin.stop();
      _this6.backgroundGeolocationPlugin.destroyLocations();
    })();
  }
  stopTracking() {
    var _this7 = this;
    return (0,_Users_smartcommunitylab_Desktop_newWork_playAndGo_playGo_node_modules_babel_runtime_helpers_esm_asyncToGenerator_js__WEBPACK_IMPORTED_MODULE_0__["default"])(function* () {
      // we are forcing to measure user's location at the moment of stopping tracking
      // this could be important in case of company campaigns, where trip ends have to be
      // precisely at the workplace.
      yield _this7.setExtrasAndForceLocation(null);
      yield _this7.backgroundGeolocationPlugin.stop();
      yield _this7.sync();
      _this7.possibleLocationsChangeSubject.next();
    })();
  }
  /**
   * We are running sync after ending each trip and also after each app start.
   *
   * We are using batchSync, so we are sending all locations, from potentially all trips
   * in one request. Locations are sorted to individual trips by server.
   *
   * Note that location can stay in plugin database for some time, if sync fails.
   */
  sync() {
    var _this8 = this;
    return (0,_Users_smartcommunitylab_Desktop_newWork_playAndGo_playGo_node_modules_babel_runtime_helpers_esm_asyncToGenerator_js__WEBPACK_IMPORTED_MODULE_0__["default"])(function* () {
      try {
        try {
          yield _this8.trySync();
        } catch (maybe401Error) {
          console.log('Sync failed, trying to get new token');
          // maybe sync failed because the token is expired. Let's try to call some
          // api to refresh the token and try again.
          yield _this8.playerControllerService.getProfileUsingGET().toPromise();
          yield _this8.trySync();
        }
      } catch (e) {
        console.warn('Sync failed, we will try to sync next time', e);
      }
      _this8.possibleLocationsChangeSubject.next();
    })();
  }
  trySync() {
    var _this9 = this;
    return (0,_Users_smartcommunitylab_Desktop_newWork_playAndGo_playGo_node_modules_babel_runtime_helpers_esm_asyncToGenerator_js__WEBPACK_IMPORTED_MODULE_0__["default"])(function* () {
      const token = yield _this9.authService.getToken();
      // console.log('sync using token', token);
      yield _this9.backgroundGeolocationPlugin.setConfig({
        authorization: {
          strategy: 'jwt',
          accessToken: token.accessToken
        }
      });
      const locationSentToServer = yield _this9.backgroundGeolocationPlugin.getLocations();
      // .sync call will fail, if the network is not available
      // I dont know why is seems that it is not possible to get list of locations
      // that was really sent...
      yield _this9.backgroundGeolocationPlugin.sync();
      _this9.synchronizedLocationsSubject.next(locationSentToServer.map(TripLocation.fromLocation));
      _this9.possibleLocationsChangeSubject.next();
    })();
  }
  setExtrasAndForceLocation(tripPart) {
    var _this0 = this;
    return (0,_Users_smartcommunitylab_Desktop_newWork_playAndGo_playGo_node_modules_babel_runtime_helpers_esm_asyncToGenerator_js__WEBPACK_IMPORTED_MODULE_0__["default"])(function* () {
      yield _this0.isReady;
      const extras = _this0.getExtras(tripPart);
      yield _this0.backgroundGeolocationPlugin.setConfig({
        extras
      });
      _this0.currentExtrasSubject.next(extras);
      let currentLocation;
      try {
        currentLocation = yield _this0.backgroundGeolocationPlugin.getCurrentPosition({
          // TODO: this does not work... I an to sure why but I was not able to set custom
          // extras in getCurrentPosition call
          extras: {
            ...extras,
            forced: true
          }
        });
      } catch (e) {
        console.error(e);
        throw _trip_model__WEBPACK_IMPORTED_MODULE_21__.UNABLE_TO_GET_POSITION;
      }
      _this0.possibleLocationsChangeSubject.next();
      return currentLocation;
    })();
  }
  getExtras(tripPart) {
    return {
      idTrip: tripPart?.idTrip,
      multimodalId: tripPart?.multimodalId,
      start: tripPart?.start,
      transportType: tripPart?.transportType,
      sharedTravelId: tripPart?.sharedTravelId
    };
  }
  /**
   * Helper method that uses plugin's "add handler" method, and creates observable.
   *
   * Observable runs in angular zone, so it is safe to use it in templates.
   */
  getPluginObservable(createPluginSubscriptionFn) {
    const subject = new rxjs__WEBPACK_IMPORTED_MODULE_6__.ReplaySubject();
    const pluginSubscription = createPluginSubscriptionFn(event => {
      subject.next(event);
    });
    return subject.pipe((0,_rxjs_utils__WEBPACK_IMPORTED_MODULE_22__.runInZone)(this.zone), (0,rxjs_operators__WEBPACK_IMPORTED_MODULE_13__.finalize)(() => {
      pluginSubscription.remove();
    }));
  }
  static #_ = _staticBlock = () => (this.ɵfac = function BackgroundTrackingService_Factory(__ngFactoryType__) {
    return new (__ngFactoryType__ || BackgroundTrackingService)(_angular_core__WEBPACK_IMPORTED_MODULE_24__["ɵɵinject"]('BackgroundGeolocationPlugin'), _angular_core__WEBPACK_IMPORTED_MODULE_24__["ɵɵinject"](src_app_core_shared_services_alert_service__WEBPACK_IMPORTED_MODULE_25__.AlertService), _angular_core__WEBPACK_IMPORTED_MODULE_24__["ɵɵinject"](_auth_auth_service__WEBPACK_IMPORTED_MODULE_26__.AuthService), _angular_core__WEBPACK_IMPORTED_MODULE_24__["ɵɵinject"](_api_generated_controllers_playerController_service__WEBPACK_IMPORTED_MODULE_27__.PlayerControllerService), _angular_core__WEBPACK_IMPORTED_MODULE_24__["ɵɵinject"](_services_app_status_service__WEBPACK_IMPORTED_MODULE_28__.AppStatusService), _angular_core__WEBPACK_IMPORTED_MODULE_24__["ɵɵinject"](_angular_core__WEBPACK_IMPORTED_MODULE_1__.NgZone), _angular_core__WEBPACK_IMPORTED_MODULE_24__["ɵɵinject"](_ngx_translate_core__WEBPACK_IMPORTED_MODULE_29__.TranslateService));
  }, this.ɵprov = /*@__PURE__*/_angular_core__WEBPACK_IMPORTED_MODULE_24__["ɵɵdefineInjectable"]({
    token: BackgroundTrackingService,
    factory: BackgroundTrackingService.ɵfac,
    providedIn: 'root'
  }));
}
_staticBlock();
class TripLocation {
  constructor(data) {
    Object.assign(this, data || {});
  }
  static fromLocation(location) {
    const extras = location.extras || {};
    return new TripLocation({
      date: new Date(location.timestamp).getTime(),
      latitude: location.coords.latitude,
      longitude: location.coords.longitude,
      multimodalId: extras.multimodalId,
      idTrip: extras.idTrip,
      transportType: extras.transportType
    });
  }
}

/***/ }),

/***/ 27242:
/*!*****************************************************!*\
  !*** ./src/app/core/auth/factories/auth.factory.ts ***!
  \*****************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   authFactory: () => (/* binding */ authFactory)
/* harmony export */ });
/* harmony import */ var ionic_appauth__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ionic-appauth */ 94713);
/* harmony import */ var _capacitor_app__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @capacitor/app */ 59326);
/* harmony import */ var src_environments_environment__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! src/environments/environment */ 45312);



const authFactory = (platform, ngZone, requestor, browser, storage, spinnerService) => {
  browser.browserCloseListener(closeBrowserEvent => {
    spinnerService.hide('login');
  });
  const authService = new ionic_appauth__WEBPACK_IMPORTED_MODULE_0__.AuthService(browser, storage, requestor);
  authService.authConfig = src_environments_environment__WEBPACK_IMPORTED_MODULE_2__.environment.authConfig;
  if (!platform.is('cordova')) {
    authService.authConfig.redirect_url = window.location.origin + '/auth/callback';
    authService.authConfig.end_session_redirect_url = window.location.origin + '/auth/endsession';
  }
  if (platform.is('capacitor')) {
    console.log('capacitor');
    _capacitor_app__WEBPACK_IMPORTED_MODULE_1__.App.addListener('appUrlOpen', data => {
      if (data.url !== undefined) {
        ngZone.run(() => {
          if (data.url.indexOf(authService.authConfig.redirect_url) === 0) {
            authService.authorizationCallback(data.url);
          } else {
            authService.endSessionCallback();
          }
        });
      }
    });
  }
  return authService;
};

/***/ }),

/***/ 27473:
/*!*********************************!*\
  !*** ./src/assets/i18n/en.json ***!
  \*********************************/
/***/ ((module) => {

"use strict";
module.exports = /*#__PURE__*/JSON.parse('{"---comment-cSpell-locales":"cSpell:locale en","helloWorld":"Hello world","homeTtle":"Play&Go","profileTitle":"Profile","campaignsTitle":"Campaigns","tripsTitle":"Trips","challengeTitle":"Challenges","tripDetailTitle":"Trip Details","notifications_title":"Notifications","discovercampaignbutton":"Discover other campaigns","leaderboard.title":"Leaderboard","green leaves":"ecoLeaves","bike aficionado":"Bike Trip Badge","sustainable life":"Zero Impact Badge","public transport aficionado":"Public Transport Badge","park and ride pioneer":"Park And Ride Badge","bike sharing pioneer":"Bike Sharing Badge","recommendations":"User Recommendation Badge","leaderboard top 3":"Leaderboard Top 3 Badge","travels":" journeys","appFooter":{"by":"By Fondazione Bruno Kessler","version":"Versione {{version}}","credits":"Credits","faq":"FAQ","help":"Help","privacy":"Privacy"},"appCredits":{"by":"A research project by:","dslab":"DSLab","modis":"MoDiS","pmg":"PMG","fbk":"Fondazione Bruno Kessler","version":"Versione {{version}}","credits":"Credits","faq":"FAQ","help":"Help","privacy":"Privacy"},"firstTime":{"title":"Use your location","message":"Play&go collects location data to enable the tracking, validation and rewarding of sustainable trips even when the app is closed or not in use.","close":"Deny","accept":"Accept"},"permission":{"title":"Allow {applicationName} to access to this device\'s location in the background?","message":"In order to track your activity in the background, please enable {backgroundPermissionOptionLabel} location permission","positiveAction":"Change to {backgroundPermissionOptionLabel}","cancelAction":"Cancel"},"permission_denied":{"title":"Not able to start tracking","message":"You have denied the permission to access this device\'s location. This permission is needed to create tracks of your sustainable trips which are later used to assign you score based on your campaigns. You can enable the permission in the phone\'s settings."},"permission_when_in_use":{"title":"Warning","message":"If you don\'t allow to share location in the background, there is risk that your tracks will be incomplete. Please consider changing permission to \\"Allow always\\"."},"badges":{"empty":"You have not earned any badges for this campaign. Play to find them."},"login":{"login_page_title":"Login","labelSignin":"Signing in...","labelSignout":"Signing out...","loginCardHeader":"Login","loginButton":"Login","welcome":"Welcome","loginGoogleButton":"Login with Google","loginFacebookButton":"Login with Facebook","loginAppleButton":"Login with Apple","loginInternalButton":"Login with Username","title":"Welcome in Play&Go","subtitle":"Sustainable mobility app"},"notifications":{"empty":"You have no notifications","close":"Close"},"registration":{"title":"New user","newUser":"New User. Fill the form with your information","avatar":{"title":"Avatar"},"name":"Name","lastname":"Surname","mail":"Email","nickname":"Nickname","lang":{"language":"Language","select":"Select the language","it":"Italian","en":"English"},"territories":{"territory":"Territory","select":"Select the territory"},"infoTerritory":"Your territory will influence your campaigns. Please select your territory","form":{"nameRequired":"The name is required.","nameMinLength":"Name must be at least 2 characters long.","lastNameRequired":"The surname is required.","lastNameMinLength":"Last name must be at least 2 characters long.","mailRequired":"The address is required.","mailPattern":"The email address is not valid.","nicknameRequired":"The nickname is required.","nicknameMinLength":"Nickname must be at least 2 characters long.","languageRequired":"The language is required.","territoryRequired":"The territory is required.","privacyRequired":"Privacy is required.","nicknamePattern":"Use only alphanumeric characters"},"territoryPopup":{"header":"Territory","message":"The choice of the territory determines the validation of the journeys and the availability of the mobility campaigns. Once selected, it will no longer be possible to modify."},"privacyPopup":{"header":"Privacy","title":"Privacy","message":"<div class=\\"entry-content\\"><p style=\\"font: 18.7px ;\\"><b>PLAY&amp;GO </b></p><p class=\\"c2\\"><span class=\\"c0\\">Information regarding the processing of personal data</span></p><p class=\\"c2 c4\\"><span class=\\"c0\\"></span></p><p class=\\"c2\\"><span class=\\"c1\\">Pursuant to Article 13 of the EU Regulation No. 2016/679 (GDPR), and in general in compliance with the principle of transparency set out in that Regulation, below we provide information regarding the processing of personal data within the Play&amp;Go application (hereinafter &quot;App&quot;).</span></p><p class=\\"c2\\"><span class=\\"c1\\">The App allows tracking of integrated, multimodal mobility trips &nbsp;(e.g., bus, train, bicycle, walking, carpooling, and combinations these).</span></p><p class=\\"c2 c4\\"><span class=\\"c1\\"></span></p><p class=\\"c2\\"><span class=\\"c3\\">It is worth pointing out that the App can also be used in the context of sustainable mobility campaigns to award </span><span class=\\"c3 c10\\">points </span><span class=\\"c3\\">and prizes based on the trips correctly </span><span class=\\"c3\\">tracked </span><span class=\\"c1\\">by participants. In order to allow such campaigns to be carried out, it is necessary to collect and process information related to the tracking of trips made via the App.</span></p><p class=\\"c2\\"><span class=\\"c1\\">This information is therefore to be considered supplementary to that which will be made available upon joining the various sustainable mobility campaigns proposed over time through the Play&amp;Go App.</span></p><p class=\\"c2 c4\\"><span class=\\"c1\\"></span></p><p class=\\"c2\\"><span class=\\"c0\\">1. PURPOSE OF PROCESSING</span></p><p class=\\"c2\\"><span class=\\"c1\\">The processing of personal data takes place within the App and will have the following purposes:</span></p><ol class=\\"c6 lst-kix_v1j04fyyyjqt-0 start\\" start=\\"1\\"><li class=\\"c5 li-bullet-0\\"><span class=\\"c1\\">register users and allow them to use the App;</span></li><li class=\\"c5 li-bullet-0\\"><span class=\\"c1\\">ensure the proper functioning of the App;</span></li><li class=\\"c5 li-bullet-0\\"><span class=\\"c1\\">enable the performance, documentation, and improvement of the App&#39;s activities;</span></li><li class=\\"c5 li-bullet-0\\"><span class=\\"c1\\">track and validate trips through the App;</span></li><li class=\\"c5 li-bullet-0\\"><span class=\\"c1\\">provide for scientific, historical, and statistical research purposes.</span></li></ol><p class=\\"c2 c4\\"><span class=\\"c0\\"></span></p><p class=\\"c2\\"><span class=\\"c0\\">2. OBLIGATION TO PROVIDE DATA</span></p><p class=\\"c2\\"><span class=\\"c1\\">The legal basis for processing is the explicit consent upon first use of the App.</span></p><p class=\\"c2\\"><span class=\\"c1\\">All purposes of processing are related to the use of the App. Although there is no obligation to provide the data, failure to do so will make it impossible to proceed with access to the App and therefore to use it. With reference to geolocation, it should be noted that failure to consent to tracking could compromise the validation of your trips.</span></p><p class=\\"c2 c4\\"><span class=\\"c1\\"></span></p><p class=\\"c2\\"><span class=\\"c7\\">3. TYPE OF DATA PROCESSED</span></p><p class=\\"c2\\"><span class=\\"c1\\">The following categories of data may be processed for the purposes of managing the App: </span></p><ol class=\\"c6 lst-kix_4xl5nuom5aqd-0 start\\" start=\\"1\\"><li class=\\"c8 li-bullet-0\\"><span class=\\"c1\\">personal data and contact details;</span></li><li class=\\"c8 li-bullet-0\\"><span class=\\"c1\\">geolocalization data (data on the user&#39;s position detected in real time, based on the GPS present on the mobile device on which the App is installed, while tracking a trip); </span></li><li class=\\"c8 li-bullet-0\\"><span class=\\"c1\\">behavior data (mode of travel, number of kilometers covered).</span></li></ol><p class=\\"c2\\"><span class=\\"c1\\">The user&#39;s public profile data (Google, Facebook, Apple, Smart Community) may be used to personalize the App.</span></p><p class=\\"c2\\"><span class=\\"c1\\">The user&#39;s e-mail address is also used as a means to uniquely identify the user within the Smart Community systems.</span></p><p class=\\"c2 c4\\"><span class=\\"c0\\"></span></p><p class=\\"c2\\"><span class=\\"c7\\">4. METHODS OF DATA PROCESSING</span></p><p class=\\"c2\\"><span class=\\"c1\\">The processing will be carried out:</span></p><ul class=\\"c6 lst-kix_9abvnggic5rt-0 start\\"><li class=\\"c8 li-bullet-0\\"><span class=\\"c1\\">through the App and the use of manual and automated systems;</span></li><li class=\\"c8 li-bullet-0\\"><span class=\\"c1\\">by individuals authorized and trained to perform such tasks, in accordance with the law; </span></li><li class=\\"c8 li-bullet-0\\"><span class=\\"c1\\">with the use of appropriate measures to ensure the confidentiality of data and prevent access to them by unauthorized third parties;</span></li><li class=\\"c8 li-bullet-0\\"><span class=\\"c1\\">in contexts that do not undermine the personal dignity and decorum of the data subject, ensuring due care to guarantee confidentiality in their use.</span></li></ul><p class=\\"c2\\"><span class=\\"c3\\">You can consult all the technical and organizational measures adopted by FBK to ensure proportionality and necessity of the processing and prevent illegitimate access, unwanted modification, disappearance and explicit breaches of personal data at the following link </span><span class=\\"c3 c13 c17\\"><a class=\\"c15\\" href=\\"https://www.google.com/url?q=http://bit.ly/MisureFBK&amp;sa=D&amp;source=editors&amp;ust=1749139687909478&amp;usg=AOvVaw3I2ueLstevB1z71YTAikxC\\">bit.ly/MisureFBK</a></span><span class=\\"c1\\">.</span></p><p class=\\"c2\\"><span class=\\"c1\\">No automated decision-making process is involved, nor any profiling activity.</span></p><p class=\\"c2 c4\\"><span class=\\"c0\\"></span></p><p class=\\"c2\\"><span class=\\"c0\\">5. DURATION OF TREATMENT</span></p><p class=\\"c2\\"><span class=\\"c1\\">The data will be retained until the user requests its deletion and, in any case, for a period not exceeding that necessary for the fulfillment the obligations or tasks referred to in point 1, and in any case for pursuing the specific purposes indicated therein. The deletion of the data will occur gradually, based on the exhaustion of the individual purposes for which they were collected.</span></p><p class=\\"c2\\"><span class=\\"c1\\">In some cases, the data may also be retained after the account is closed, such as in backups or in the Disaster Recovery system, or in aggregated and anonymized form, for scientific research purposes.</span></p><p class=\\"c2 c4\\"><span class=\\"c0\\"></span></p><p class=\\"c2\\"><span class=\\"c7\\">6. COMMUNICATION OF DATA</span></p><p class=\\"c2\\"><span class=\\"c1\\">The data collected and processed may be communicated exclusively for the above mentioned purposes and in aggregate form, to Public Administrations (for example as promoters of sustainable mobility initiatives).</span></p><p class=\\"c2\\"><span class=\\"c1\\">Personal data are not subject to dissemination.</span></p><p class=\\"c2\\"><span class=\\"c1\\">For the exclusive purposes of scientific dissemination of statistical and/or scientific results (e.g., through publication of scientific articles, participation in conferences, etc.), data may be disseminated in anonymous and aggregate form and always in a manner that does not make the Data Subject identifiable.</span></p><p class=\\"c2 c4\\"><span class=\\"c0\\"></span></p><p class=\\"c2\\"><span class=\\"c7\\">7. PLACE OF DATA PROCESSING</span></p><p class=\\"c2\\"><span class=\\"c1\\">The processing personal data takes place on the territory of the European Union, or with the help of IT tools involving processing in countries for which the European Commission has taken a decision on the adequacy of the protection of personal data or, failing that, through the signing of Standard Contractual Clauses (SCC) for data protection adopted by the European Commission with the supplier.</span></p><p class=\\"c2 c4\\"><span class=\\"c1\\"></span></p><p class=\\"c2\\"><span class=\\"c0\\">8. RIGHTS OF THE DATA SUBJECT</span></p><p class=\\"c11 c10 c12\\"><span class=\\"c1\\">The Data Subject has the right to ask the Data Controller at any time to exercise the rights set out in Articles 15 et seq. of the GDPR and, in particular, to:</span></p><ul class=\\"c6 lst-kix_rh590fh4292s-0 start\\"><li class=\\"c8 li-bullet-0\\"><span class=\\"c1\\">request confirmation of the existence or non-existence of their personal data and request access to them;</span></li><li class=\\"c8 li-bullet-0\\"><span class=\\"c1\\">obtain information about the purposes of the processing, the categories of personal data, the recipients or categories of recipients to whom the personal data have been or will be communicated and, when possible, the storage period;</span></li><li class=\\"c8 li-bullet-0\\"><span class=\\"c1\\">obtain rectification and deletion of data;</span></li><li class=\\"c8 li-bullet-0\\"><span class=\\"c1\\">obtain restriction of processing; </span></li><li class=\\"c8 li-bullet-0\\"><span class=\\"c1\\">object to the processing at any time.</span></li></ul><p class=\\"c2\\"><span class=\\"c1\\">He or she also has the right to revoke his consent at any time without affecting the lawfulness of processing based on consent given before revocation. </span></p><p class=\\"c2\\"><span class=\\"c7\\">To exercise the above rights, please write to: </span><span class=\\"c7 c10 c13\\"><a class=\\"c15\\" href=\\"mailto:privacy@fbk.eu\\">privacy@fbk.eu</a></span><span class=\\"c7 c10\\">.</span><span class=\\"c7\\">&nbsp;</span></p><p class=\\"c2\\"><span class=\\"c1\\">This is without prejudice to the right to send a complaint to the Garante per la protezione dei dati personali.</span></p><p class=\\"c2 c4\\"><span class=\\"c0\\"></span></p><p class=\\"c2\\"><span class=\\"c0\\">9. DATA CONTROLLER</span></p><p class=\\"c2\\"><span class=\\"c3\\">The data controller for the processing of personal data is the Bruno Kessler Foundation, based in Trento, Italy</span><span class=\\"c1\\">, via Santa Croce, 77 &ndash; +39.0461.314.621-227 &ndash; segr.presidenza@fbk.eu</span></p><p class=\\"c2 c4\\"><span class=\\"c0\\"></span></p><p class=\\"c2\\"><span class=\\"c0\\">10. CONTACT DETAILS OF THE DATA PROTECTION OFFICER </span></p><p class=\\"c2\\"><span class=\\"c3\\">The Data Controller has designated a Data Protection Officer (DPO) pursuant to Article 37 of the GDPR, who can be contacted through the following channels</span><span class=\\"c1\\">: +39.0461.314.370 &ndash; privacy@fbk.eu.</span></p><p class=\\"c2 c4\\"><span class=\\"c0\\"></span></p><p class=\\"c2\\"><span class=\\"c0\\">11. AMENDMENTS TO THIS POLICY</span></p><p class=\\"c11\\"><span class=\\"c3\\">The Data Controller reserves the right to make, if necessary, appropriate changes to this Privacy Policy - currently updated to</span><span class=\\"c7\\">&nbsp;May 16, 2025</span><span class=\\"c1\\">&nbsp;- giving the widest possible visibility to the Data Subjects.</span></p><p class=\\"c2 c4\\"><span class=\\"c0\\"></span></p><p class=\\"c4 c9\\"><span class=\\"c14\\"></span></p></div>"},"privacyLink":"Privacy Policy","privacy":"I agree with the privacy policy","sumbmitButton":"Register","confirm":{"header":"Confirm registration","message":"<h1>{{territory}}</h1><br><strong>{{nickname}}</strong>, are you sure you want to register to app Play&Go for the selected territory?"}},"modal":{"cancel":"Cancel","ok":"OK","alert_title":"Alert","levelup":"Level Up!","newbadge":"New badge!"},"tracking":{"low_accuracy":"Low accuracy!","choose_means":"Choose means of tracking","continue_low_accuracy_prompt":"Low accuracy detected! Do you want to continue?","show_current_location":"Show me where I am","too_short":"The journey is too short and will not be added.","info":{"title":"Means e tracking","subtitle":"Each icon could correspond to several different vehicles. Here is a legend to better orient you:","car":"Shared car, Transport reserved for the disabled with authorized drivers or vehicles","bike":"Electric/muscle bike, Running, Electric/muscle scooter, Skateboard, Segway, Roller skates","walk":"Walking","train":"Rail transport","bus":"Urban and suburban line bus","boat":"Boat","unknown":"by any other means"},"car":{"choose_role":"Which mode are you?","driver":"Driver","passenger":"Passenger","manual_code":"Trip code:","manual_code_input_label":"Input code manually:","manual_code_input_example":"Ex: 12345","manual_code_input_confirm":"OK","or":"or scan the QR code","scan":"Scan","showCode":"<h3><b>Your journeu has started.</b></h3><br>Now add a passenger.<br>Show QR Code or share code.","confirm":"Start to drive","errors":{"NO_ROLE_CHOSEN":"You have to choose to be passenger or driver!","NO_CONFIRMED":"You have to confirm the QR Code","NO_PASSENGER_CARPOOLING_ID":"You have to insert the driver code","INCORRECT_QR_CODE":"Wrong QR CODE"}},"stop_header":"Journey completed!","stop_body":"Tracking was successful. The trip data will be sent to our servers for validation.","errors":{"ACCESS_DENIED":"Access to background position denied!","LOW_ACCURACY":"Low location accuracy detected!","POWER_SAVE_MODE":"Power save mode is active! This will result in not accurate tracking!","UNABLE_TO_GET_POSITION":"Unable to get current location! Make sure that location services are enabled and try again."}},"profile":{"mail":"Email: ","activeFrom":"Activated since: ","territory":"Territory: ","blacklistedUser":"Blacklist user","Faq":"FAQ","Help":"Help","Privacy":"Privacy","logout":"Logout","logoutpopup":{"title":"Warning","message":"The unsaved data will be lost. Are you sure you want to exit?","cancel":"Annulla","ok":"OK"},"about":"About","deleteAccount":"Delete account","changeButton":"Change","delete":{"title":"Delete account","message":"This action will delete all your data and your progress in the Play&Go app","message2":"This is a irreversible action: you cannot get any data back if you will delete the account","message3":"Are you sure to delete definetly your account?","close":"Cancel","accept":"Delete"},"change":{"modalTitle":"Change Profile","closeButton":"Save","saveButton":"Close","lang":{"language":"Language","select":"Select the language","it":"Italian","en":"English"}},"status":{"totalKm":"{{totalKM}} done","travels":"{{totalTravels}} valid travels","activityDays":"{{activityDays}} days of gaming","activeCampaigns":"{{activeCampaigns}} active campaigns","myCampaigns":"Active campaigns:"}},"report":{"stats":{"title":"Statistics","title_team":"Team statistics"}},"trips":{"filter_all_campaigns":"All the campaigns","filter_all_the_time":"All the periods","empty":"No journeys stored"},"trip_detail":{"title":"Trip Details","start":"Start","end":"End","distance":"Distance","gl_for":"for","valid_for_campaigns":{"plural_form":{"one":"Valid for {{count}} campaign","other":"Valid for {{count}} campaigns"}},"no_score":"No score associated with this journey.","no_track":"No track associated with this journey.","mean":{"car":"Car","bike":"Bike","walk":"Walk","train":"Train","bus":"Bus","boat":"Boat","unknown":"Unknown Mean"},"status":{"valid":"Valid","invalid":"Invalid","pending":"Pending","not_synchronized":"Not synchronized","not_finished":"Ongoing","validation":"Validating"},"historic_values_offline":"To load historic trips, you have to be online."},"errors":{"error_header":"Error","not_recoverable":"Application encountered unrecoverable error, and will be restarted! \\n Your trip progress will be saved.","offline":"This functionality is available only online.","userNotFound":"User Not Found!","nickNameExist":"This nickname already exists!","defaultErr":"Server operation failed!"},"offline":{"title":"Offline","header":"You can continue to track your trips, but some pages may not work!","page":{"body_1":"No connection available!","body_2":"This page cannot work without an internet connection","body_3":"You can still track your trips and play; the data will be sent when the connection is restored.","return_home":"Return to homepage"}},"campaigns":{"title":"Campaigns","join":"Join","novaliddate":"The campaign\'s period is not valid","removed":"The campaign is over","notStarted":"The campaign is not active","cantSubscribe":"The campaign is running.<br> Your nickname does not belong to any team. To participate, contact the teacher in charge","notStartedHSC":"The campaign is not yet active. To partecipate contact your teacher.","noDesc":"No description provided","myCampaigns":"My campaigns","allCampaigns":"All campaigns","registered":"Registered","unregistered":"Unregistered","public":{"last":"TODO: Durata:"},"campaignmodal":{"listTitle":"Partecipating companies","title":"Company Details","close":"X"},"joinmodal":{"search":"Search","raccomandation":"Who invited you?","nickname":"Insert thenickname","teamselection":"Select your team","teams":"Teams","noItems":"No companies found","modalTitle":"Subscribe to {{campaignTitle}}","close":"X","closeString":"Close","pinRequired":"The univoque code is required","companyselection":"Select the company","companyPIN":"Insert your PIN","privacyLink":"Read the privacy","privacy":"Accept the privacy","privacyRequired":"Privacy is needed","rulesLink":"Read the rules","rules":"Accept the rules","rulesRequired":"Rules is needed","companyRequired":"The selection is needed","error":{"ERROR_TEAM":"Subscription error. Check the selected team"},"privacyPopup":{"header":"Privacy"},"rulesPopup":{"header":"Rules"},"codeInfo":{"header":"Player code","message":"Unique code issued to the player"},"join":"Join","confirm":"Confirm subscription"},"unsub":{"title":"Unsubscribe","text":"Are you sure to unsubscribe?","close":"Close","confirm":"Confirm"},"detail":{"not_subscribed":"Not subscribed","unregistered":"Unregistered","nMembersActive":"Members active:","nMembersInvited":"Invited:","nMembersMax":"Max team:","playerProgression":"How are you going","teamProgression":"How is your team doing","teamDetailRanking":"General Ranking:","teamAvg":"{{value}} Km/mese per utente","points":"Weekly points: ","noPoints":"Weekly points: 0","members":"{{members}} members","member":"{{members}} member","modalTeam":"<div class=\\"ion-text-start\\"><i>This component shows the performance of your team compared to the most active and least active <b>team this week</b> .<br/><br/>The score of the less active team is shown on the left.<br/><br/> The score of the more active team is shown on the right. <br/>The bar represents your position with respect to the two scores. <br /><br/><b>Values from {{dateFrom}} to {{dateTo }}</b>:<br /><br/></i></div>","modalBestTeam":"Best team score: ","modalActualTeam":"Your team score: ","modalMinTeam":"Worst team score: ","modalPersonal":"<div class=\\"ion-text-start\\"><i>This component shows your performance compared to the most active and least active player <b> this week</b>.< br/><br/> On the left, the score of the less active player is represented. <br/><br/>On the right, the score of the more active player. <br/>The bar represents your position with respect to the two scores. <br/> <br/><b>Values from {{dateFrom}} to {{dateTo }}</b>:<br /><br/><i></div>","modalBestPersonal":"Max score: ","modalActualPersonal":"Your score:","modalMinPersonal":"Min score:","modalTeamValid":"Only teams that have made at least one valid journey are taken into consideration.","modalPersonalValid":"Only players that have made at least one valid journey are taken into consideration.","myCompany":"Company:","youCompany":"Your company","otherCompany":"Other companies","companies":"Partecipating companies","companySubscribe":"Insert your identification code","not_found":"Campaign not found","blacklist":"Blacklist","badges":"Badges","stats":"Statistics","statsTeam":"Team statistics","generalStat":"General informazion","signal":"Help and support","unsubscribe":"Leave the campaign","prizes":"Prizes","prize":{"title":"Prizes","desc":"The first prize will be awarded by right to the first player in the weekly eco-leaves ranking while the other prizes will be drawn at random among the top 50 classified players. Check the rules to find out which players can compete for the weekly prizes, such as cases of equality and other details on assignment methods and times are managed.","periodic":"Periodic","final":"Final","prizefinal":"Final prizes","prizeactual":"Current prizes","finalWeekTitle":"Final prizes\' notes","actualWeekTitle":"Periodic prizes\' notes","finalRewardTitle":"Prize\'s information","periodicWeekTitle":"Regulation","sponsorBy":"Sponsor by:","website":"website","noFinal":"No prizes available","noActual":"No prizes available","expand":"Show past prizes","expanded":"Past prizes"},"from":"From ","to":"to","info":"Prizes information","current":"On going","dateFrom":"From: ","dateTo":"To: ","challenges":"Challenges","journeys":"Journeys","leaderboard":"Leaderboard","faq":"FAQ","sponsor":"Organizers and collaborators","description":"Description","details":"Campaign details","limits_title":"Limits","limits_text":"The regulation provides for the following limits: <ul><li>maximum 20 km per day;</li><li> maximum 250 km per month;</li><ul> Once the limit is exceeded, the trips are not validated for the campaign and the reward is not recognized.","contacts":"Contatti: ","name":"Nome: ","address":"Indirizzo: ","phone":"Telefono: ","mail":"Email: ","mm":"Mobility Manager","locations":"Valid locations:","location":"location {{index}}:","personalStatWeek":"Your contribution this week: {{value}}","companiesPage":{"website":"Website","email":"Email","phone":"Phone","address":"Address: ","location":"Locations"}},"homewidgets":{"personal":{"active":"Active from: {{startDate}}","totalco2":"Total CO₂: {{totalCO2}}","weeklyco2":"Weekly CO₂: {{weeklyCO2}}","weeklyRanking":"Weekly ranking: {{weeklyRanking}}"},"stat":{"weekposition":"Week:","totalposition":"Total:","weekvalue":"<b>{{value}} weekly value</b>","monthvalue":"<b>{{value}} monthly value</b>","totalvalue":"<b>{{value}} total value</b>","lastpaymentkm":"<b>{{value}} {{unit}}</b> from {{date}} to {{dateTo}}","levelName":"<b>Level : {{levelName}}</b>","maxscore":"You have reached the max score","score":" ","emptystatus":"If you want to see your level and points start to play!","status":"{{score}} Kg CO₂ saved","record":"{{record}} weekly record","today":"Today: ","thisWeek":"Week: ","lastmonth":"{{lastmonth}}: ","max":" max","km":" Km"}},"stats":{"filter":{"unit":{"km":{"label":"Km","unit":"km"},"co2":{"label":"CO2","unit":"co2"}},"means":{"car":{"label":"Car","unit":"car"},"bike":{"label":"Bike","unit":"bike"},"walk":{"label":"Walk","unit":"walk"},"boat":{"label":"Boat","unit":"boat"},"bus":{"label":"Bus","unit":"bus"},"train":{"label":"Train","unit":"train"}},"GL":"ecoLeaves","period":{"week":"Week","month":"Month","year":"Year"},"mean_type":"Mean","unit_type":"Unit"}},"leaderboard":{"empty":"No journeys tracked in this period","filter":{"leaderboard_type":"Value","period":"Period"},"period":{"today":"Today","this_week":"This Week","last_week":"Last Week","this_month":"This Month","all_time":"All Time"},"leaderboard_type":{"co2":"Total CO₂","km":"Total km","GL":"ecoLeaves","virtualScore":"","virtualTrack":""},"select":{"co2":"CO₂","km":"km","tracks":"tracks","duration":"duration","virtualScore":"","virtualTrack":""},"unit":{"co2":"CO₂ Kg","km":"km","tracks":"# of tracks","duration":"hours","virtualScore":"","virtualTrack":"# of journeys"},"unitChart":{"co2":"Kg","km":"Km","tracks":"","duration":"h","virtualScore":"","virtualTrack":""},"leaderboard_type_unit":{"co2":"{{value}} kg CO₂","GL":"{{value}}","km":"{{value}} km","duration":"{{value}} h","tracks":"{{value}}","virtualScore":"{{value}}","virtualTrack":"{{value}}"},"all_means":"All means","gl":"Score","virtualScore":"Virtual Score"},"score_label":{"flower":"ecoLeaves","shield":"ecoLeaves"}},"blacklist":{"blacklist":"Blacklisted users","intro1":"Here you can find the list of the users you blocked","intro2":"The users you blocked can not send you invites for the challenges in this campaign and you can not challenge them.","empty":"No blocked user for this campaign"},"teamprofile":{"title":"Team profile"},"userprofile":{"period_challenge":"Last month\'s challenges {{periodFrom}} - {{periodTo}}","title":"User Profile","last_month":"Last month activity","personal_stat_bike":" by bike","personal_stat_walk":" walking","personal_stat_bus":" by bus","personal_stat_train":" by train","personal_stat_car":" by carpooling","personal_stat_boat":" by boat","empty":"There are not statistics to show","last_week_position":" this week","general_position":" general ranking","total_points":" total points","won":"won {{won}}","add_blacklist":"Block invites","remove_blacklist":"Unlock invites","user_joined":"The user participates in this campaign","blacklist_user":"Attenzione: hai bloccato gli inviti per le sfide di questo utente. Non puoi inviare nè ricevere sfide da questo utente. "},"challenges":{"singleActivated":"Challenge activated!","singleDesc":"You activated a single challenge from {{from}} to {{to}}","active":"Active : {{active}}","configure":"Configurable: {{configurable}}","invitations":"Invitations: {{invites}}","challenges":"Challenges","allchallenges":"All the challenges","checkallchallenges":"Check all challenges","detail":{"title":"Challenge details","close":"Close"},"sent":"Invitation sent to {{nickame}}","received":"Invitation received from {{nickame}}","activate":"Accept","reject":"Reject","cancel":"Cancel","ongoing":"Ongoing","singleproposal":"Single challenge","proposed":"Next week challenges","choose_single":"Choose one of the following challenge","choose_or_configure":"Configure a group challenge","empty":"You don\'t have future challenges","past":"Past","present":"Present","future":"Future","fromto":"From {{ from }} to {{ to }}","points":"{{ point }} points","challenge_container":"Challenges {{ type }} of campaign","info":{"title":"Single challenge","body":"Each week you can choose only ONE single challenge and ONE couple challenge. <br> Once you have chosen a challenge, the other alternatives for that type disappear. <br> So when you activate a single challenge, the other possible single challenges proposed by the system disappear. <br> <br> Similarly, when you activate a couple challenge, the alternatives disappear. <br> <br>  Each week the proposed challenges are renewed: depending on your level, you can receive up to a maximum of 3 single challenge proposals.","close":"Close"},"infogroup":{"title":"Group challenges","body":"Each week you can choose only ONE couple challenge. <br> Once you have chosen a challenge, the other alternatives for that type disappear. <br> So when you activate a couple challenge, the other possible couple challenges proposed by the system disappear. <br> <br> Accepting an invitation is equivalent to choosing a couple challenge. <br> <br> When someone accepts an invitation you sent, the couple challenge for the week is automatically chosen. All other alternate challenges disappear. <br> <br> Each week the proposed challenges are renewed: depending on your level, you can receive up to a maximum of 3 invitations and you can send up to a maximum of 2 invitations.","close":"Chiudi"},"challenge_detail":{"challenge_future_start":"This challenge will start : {{startDate}}","survey":"Survey","title":"Configure a challenge","won":"You won!","prize":"You won {{prize}}","lost":"You lost!"},"stats":{"empty":"If you want to see your challenges\' statistics start to play!","filter":{"campaign":"Campaign","no_campaigns":"No game present"},"totalChallenges":"{{totalChallenges}} challenges","totalWon":"{{totalWon}} won","singleChallengeWin":{"single":"won","plural":"won"},"singleChallengeLost":{"single":"lost","plural":"lost"}},"create":{"configure":"Configure challenge","button_create":"Configure a new challenge","title":"Configure a challenge","choose_type":"Choose challenge type","choose_metric":"Choose metric","choose_partner":"Choose opponent","activate":"Activate challenge","invite":"INVITE","preview":{"model":"Type:","mean":"Selected mean:","challengeable":"Player to challenge:","you":"You"},"sent_title":"You have sent a challenge to {{nickname}}","sent_body":"The invitation will be visible to {{nickname}}. You will get a notification if {{nickname}} accept or reject the challenge. If he will not reply before the time limit the challenge will be rejected automatically. ","close":"Close"},"challenge_model":{"title":"Which kind of challenge you want create?","name":{"groupCompetitivePerformance":"Competitive performance","groupCompetitiveTime":"Competitive time","groupCooperative":"Cooperative","survey":"Survey","default":"Single Challenge","default-team":"Team challenge","teams":"Teams challenge"},"description":{"groupCompetitivePerformance":"Do more than your opponent in a week","groupCompetitiveTime":"Reach the target before your opponent!","groupCooperative":"Reach shared target with another player."},"disabled_until_level":"Challenge type disabled until level {{level}}!"},"challenge_mean":{"title":"How do you want to face the challenge?","label":{"Bike_Km":"Km on bike","Walk_Km":"Km on foot","Boat_Km":"Km on boat","Bus_Km":"Km on bus","Car_Km":"Km in car","Train_Km":"Km on train"},"pointconcept":{"Bike_Km":"Km on bike","Walk_Km":"Km on foot","green leaves":"ecoLeaves"}}},"wizard":{"next":"Next","back":"Back"},"outof":"{{current}} out of {{total}}","Language":"Language","join":"Discover","home":"Play&Go","home_title":"Home","profile_title":"Profile","campaigns_title":"Available campaigns","playNow":"Play now","noMessages":"No messages available","noCampaigns":"No campaigns available","noOtherCampaigns":"No other campaigns available.","messages":"Messages","generalStatistics":"General Statistics","noStatistics":"No statistics available","activities":"My activities","noActivities":"No activities available","greenLeaves":"Green Leaves","forNextLevel":"for next level","challenge":"Challenge","totals":"totals","thisWeek":"this week","classificationList":"Classification position","activeSince":"Active since","to":"to","madeToday":"Made today","maximumKmPerToday":"maximum for today","total":"total","tier":"Tier","adhesionCode":"Adhesion code","generalTier":"General tier","weeklyTier":"Weekly tier","number":{"ordinal":{"one":"{{ordinal}}st","two":"{{ordinal}}nd","few":"{{ordinal}}rd","other":"{{ordinal}}th","many":"{{ordinal}}th"}},"date":{"from_to":"from {{from}} to {{to}}"}}');

/***/ }),

/***/ 27780:
/*!*******************************************!*\
  !*** ./src/app/core/shared/time.utils.ts ***!
  \*******************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   fromServerDate: () => (/* binding */ fromServerDate),
/* harmony export */   getServerTimeZone: () => (/* binding */ getServerTimeZone),
/* harmony export */   toServerDateOnly: () => (/* binding */ toServerDateOnly),
/* harmony export */   toServerDateTime: () => (/* binding */ toServerDateTime)
/* harmony export */ });
/* harmony import */ var lodash_es__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! lodash-es */ 1261);
/* harmony import */ var luxon__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! luxon */ 45967);
/**
 * All time based operation should be done with this utils.
 * If needed, we can create a service for it. (For example if timezone is not fixed)
 */


/**
 * Some information about time should be interpreted as "territory" or
 * "central" time, and not using client timezone. For example dates.
 *
 * For that occasions we need to use this timezone.
 */
function getServerTimeZone() {
  return 'Europe/Rome';
}
/**
 * Used for sending time instant to server. It is always UTC.
 *
 * Even if this function is quite trivial, using this function enables us to
 * change how time is sent to server for whole app.
 *
 * @param dateTime
 * @returns UTC dateTime milliseconds.
 */
function toServerDateTime(dateTime) {
  if ((0,lodash_es__WEBPACK_IMPORTED_MODULE_0__["default"])(dateTime)) {
    return null;
  }
  if (!dateTime.isValid) {
    console.error('Invalid dateTime', dateTime, dateTime.invalidReason, dateTime.invalidExplanation);
    throw new Error('Invalid dateTime');
  }
  return dateTime.toMillis();
}
/**
 *
 * Converts DateTime to string, but only date part.
 * It uses server timezone! (see getServerTimeZone)
 * Should be used as little as possible. Mainly for sending time information that are
 * not instances in time, but more information about "human" constructions.
 *
 * @param dateTime
 * @returns yyyy-MM-dd string in server timezone.
 */
function toServerDateOnly(dateTime) {
  if ((0,lodash_es__WEBPACK_IMPORTED_MODULE_0__["default"])(dateTime)) {
    return '';
  }
  if (!dateTime.isValid) {
    console.error('Invalid dateTime', dateTime, dateTime.invalidReason, dateTime.invalidExplanation);
    throw new Error('Invalid dateTime');
  }
  return dateTime.setZone(getServerTimeZone()).toFormat('yyyy-MM-dd');
}
/**
 * Converts server milliseconds to DateTime. Keeps null as null.
 * Only problem is that generated models has Date fields, but in runtime, they are
 * numbers.
 */
function fromServerDate(dateTime) {
  if (!dateTime) {
    return null;
  }
  return luxon__WEBPACK_IMPORTED_MODULE_1__.DateTime.fromJSDate(new Date(dateTime));
}

/***/ }),

/***/ 28137:
/*!****************************************************************************!*\
  !*** ./src/app/core/shared/globalization/i18n/check-dictio-compiletime.ts ***!
  \****************************************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.r(__webpack_exports__);
const errorHereMeansThatKeyIsMissingInItalianDictionary = null;
const errorHereMeansThatKeyIsMissingInEnglishDictionary = null;
// to suppress "unused variable" error
((...a) => {})(errorHereMeansThatKeyIsMissingInItalianDictionary, errorHereMeansThatKeyIsMissingInEnglishDictionary);


/***/ }),

/***/ 29639:
/*!********************************************************************************************************************!*\
  !*** ./src/app/core/shared/campaigns/home-widget-types/home-campaign-personal/home-campaign-personal.component.ts ***!
  \********************************************************************************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   HomeCampaignPersonalComponent: () => (/* binding */ HomeCampaignPersonalComponent)
/* harmony export */ });
/* harmony import */ var luxon__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! luxon */ 45967);
/* harmony import */ var _time_utils__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ../../../time.utils */ 27780);
/* harmony import */ var _utils__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! ../../../utils */ 7497);
/* harmony import */ var _campaignUtils__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! ../../campaignUtils */ 83239);
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! @angular/core */ 12481);
/* harmony import */ var src_app_core_shared_services_user_service__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! src/app/core/shared/services/user.service */ 89815);
/* harmony import */ var src_app_core_shared_services_report_service__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! src/app/core/shared/services/report.service */ 40610);
/* harmony import */ var _services_error_service__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(/*! ../../../services/error.service */ 46078);
/* harmony import */ var _angular_common__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(/*! @angular/common */ 93683);
/* harmony import */ var _ionic_angular__WEBPACK_IMPORTED_MODULE_9__ = __webpack_require__(/*! @ionic/angular */ 21507);
/* harmony import */ var _main_campaign_stat_main_campaign_stat_component__WEBPACK_IMPORTED_MODULE_10__ = __webpack_require__(/*! ../../main-campaign-stat/main-campaign-stat.component */ 79238);
/* harmony import */ var _notification_badge_notification_badge_component__WEBPACK_IMPORTED_MODULE_11__ = __webpack_require__(/*! ../notification-badge/notification-badge.component */ 25211);
/* harmony import */ var _ngx_translate_core__WEBPACK_IMPORTED_MODULE_12__ = __webpack_require__(/*! @ngx-translate/core */ 48503);
/* harmony import */ var _pipes_languageMap_pipe__WEBPACK_IMPORTED_MODULE_13__ = __webpack_require__(/*! ../../../pipes/languageMap.pipe */ 69618);
var _staticBlock;














const _c0 = a0 => ({
  "home-card-widget": a0
});
function HomeCampaignPersonalComponent_div_5_Template(rf, ctx) {
  if (rf & 1) {
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵelementStart"](0, "div", 8)(1, "span");
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵtext"](2);
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵpipe"](3, "languageMap");
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵelementEnd"]()();
  }
  if (rf & 2) {
    const ctx_r0 = _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵnextContext"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵadvance"](2);
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵtextInterpolate1"](" ", _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵpipeBind1"](3, 1, ctx_r0.campaignContainer.campaign.name));
  }
}
function HomeCampaignPersonalComponent_ng_template_6_Template(rf, ctx) {
  if (rf & 1) {
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵelementStart"](0, "div")(1, "span");
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵtext"](2);
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵpipe"](3, "translate");
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵelementEnd"]()();
  }
  if (rf & 2) {
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵadvance"](2);
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵtextInterpolate1"](" ", _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵpipeBind1"](3, 1, "campaigns.detail.generalStat"));
  }
}
class HomeCampaignPersonalComponent {
  constructor(userService, reportService, errorService) {
    this.userService = userService;
    this.reportService = reportService;
    this.errorService = errorService;
    this.header = false;
  }
  ngOnInit() {
    this.imagePath = (0,_campaignUtils__WEBPACK_IMPORTED_MODULE_3__.getCampaignImage)(this.campaignContainer);
    this.subStat = this.userService.userProfile$.subscribe(profile => {
      this.profile = profile;
      this.reportService.getCo2Stats(this.campaignContainer.campaign.campaignId, this.profile.playerId, (0,_time_utils__WEBPACK_IMPORTED_MODULE_1__.toServerDateOnly)(luxon__WEBPACK_IMPORTED_MODULE_0__.DateTime.utc().minus({
        week: 1
      })), (0,_time_utils__WEBPACK_IMPORTED_MODULE_1__.toServerDateOnly)(luxon__WEBPACK_IMPORTED_MODULE_0__.DateTime.utc())).then(stats => {
        this.reportWeekStat = stats;
      }).catch(error => {
        if ((0,_utils__WEBPACK_IMPORTED_MODULE_2__.isOfflineError)(error)) {
          this.reportWeekStat = null;
        } else {
          this.reportWeekStat = null;
          this.errorService.handleError(error);
        }
      });
      this.reportService.getCo2WeekRecord(this.campaignContainer.campaign.campaignId, this.profile.playerId).then(record => {
        this.record = record[0];
      }).catch(error => {
        if ((0,_utils__WEBPACK_IMPORTED_MODULE_2__.isOfflineError)(error)) {
          this.record = null;
        } else {
          this.record = null;
          this.errorService.handleError(error);
        }
      });
      this.reportService.getCo2Stats(this.campaignContainer.campaign.campaignId, this.profile.playerId).then(stats => {
        this.reportTotalStat = stats;
      }).catch(error => {
        if ((0,_utils__WEBPACK_IMPORTED_MODULE_2__.isOfflineError)(error)) {
          this.reportTotalStat = null;
        } else {
          this.reportTotalStat = null;
          this.errorService.handleError(error);
        }
      });
    });
  }
  ngOnDestroy() {
    this.subStat.unsubscribe();
  }
  static #_ = _staticBlock = () => (this.ɵfac = function HomeCampaignPersonalComponent_Factory(__ngFactoryType__) {
    return new (__ngFactoryType__ || HomeCampaignPersonalComponent)(_angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵdirectiveInject"](src_app_core_shared_services_user_service__WEBPACK_IMPORTED_MODULE_5__.UserService), _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵdirectiveInject"](src_app_core_shared_services_report_service__WEBPACK_IMPORTED_MODULE_6__.ReportService), _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵdirectiveInject"](_services_error_service__WEBPACK_IMPORTED_MODULE_7__.ErrorService));
  }, this.ɵcmp = /*@__PURE__*/_angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵdefineComponent"]({
    type: HomeCampaignPersonalComponent,
    selectors: [["app-home-campaign-personal"]],
    inputs: {
      campaignContainer: "campaignContainer",
      header: "header"
    },
    standalone: false,
    decls: 10,
    vars: 12,
    consts: [["detailHeader", ""], [3, "campaignContainer"], [3, "ngClass"], ["color", "personal"], ["alt", "Avatar", 3, "src"], ["lines", "none", "color", "personal", 4, "ngIf", "ngIfElse"], [1, "personal-content", "ion-no-padding"], [3, "campaignContainer", "reportWeekStat", "record", "reportTotalStat", "unit"], ["lines", "none", "color", "personal"]],
    template: function HomeCampaignPersonalComponent_Template(rf, ctx) {
      if (rf & 1) {
        _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵelement"](0, "app-notification-badge", 1);
        _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵelementStart"](1, "ion-card", 2)(2, "ion-card-header", 3)(3, "ion-avatar");
        _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵelement"](4, "img", 4);
        _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵtemplate"](5, HomeCampaignPersonalComponent_div_5_Template, 4, 3, "div", 5)(6, HomeCampaignPersonalComponent_ng_template_6_Template, 4, 3, "ng-template", null, 0, _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵtemplateRefExtractor"]);
        _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵelementStart"](8, "ion-card-content", 6);
        _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵelement"](9, "app-main-campaign-stat", 7);
        _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵelementEnd"]()();
      }
      if (rf & 2) {
        const detailHeader_r2 = _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵreference"](7);
        _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵproperty"]("campaignContainer", ctx.campaignContainer);
        _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵadvance"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵproperty"]("ngClass", _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵpureFunction1"](10, _c0, ctx.header));
        _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵadvance"](3);
        _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵproperty"]("src", ctx.imagePath, _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵsanitizeUrl"]);
        _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵadvance"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵproperty"]("ngIf", ctx.header)("ngIfElse", detailHeader_r2);
        _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵadvance"](4);
        _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵproperty"]("campaignContainer", ctx.campaignContainer)("reportWeekStat", ctx.reportWeekStat)("record", ctx.record)("reportTotalStat", ctx.reportTotalStat)("unit", "Kg");
      }
    },
    dependencies: [_angular_common__WEBPACK_IMPORTED_MODULE_8__.NgClass, _angular_common__WEBPACK_IMPORTED_MODULE_8__.NgIf, _ionic_angular__WEBPACK_IMPORTED_MODULE_9__.IonAvatar, _ionic_angular__WEBPACK_IMPORTED_MODULE_9__.IonCard, _ionic_angular__WEBPACK_IMPORTED_MODULE_9__.IonCardContent, _ionic_angular__WEBPACK_IMPORTED_MODULE_9__.IonCardHeader, _main_campaign_stat_main_campaign_stat_component__WEBPACK_IMPORTED_MODULE_10__.MainCampaignStatComponent, _notification_badge_notification_badge_component__WEBPACK_IMPORTED_MODULE_11__.NotificationBadgeComponent, _ngx_translate_core__WEBPACK_IMPORTED_MODULE_12__.TranslatePipe, _pipes_languageMap_pipe__WEBPACK_IMPORTED_MODULE_13__.LanguageMapPipe],
    styles: ["ion-card-header[_ngcontent-%COMP%] {\n  text-align: left;\n  border-radius: 10px 10px 0px 0px;\n  font-size: 18px;\n  font-weight: 500;\n  padding: 12px;\n  margin-bottom: 24px;\n}\nion-card-header[_ngcontent-%COMP%]   ion-avatar[_ngcontent-%COMP%] {\n  --border-radius: 50%;\n  border: solid 5px var(--ion-color-personal);\n  background-color: var(--ion-color-personal);\n  position: absolute;\n  z-index: 2;\n  text-align: center;\n  right: 12px;\n  bottom: -29px;\n  width: 64px;\n  height: 64px;\n}\n/*# sourceMappingURL=data:application/json;charset=utf-8;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbIndlYnBhY2s6Ly8uL3NyYy9hcHAvY29yZS9zaGFyZWQvY2FtcGFpZ25zL2hvbWUtd2lkZ2V0LXR5cGVzL2hvbWUtY2FtcGFpZ24tcGVyc29uYWwvaG9tZS1jYW1wYWlnbi1wZXJzb25hbC5jb21wb25lbnQuc2NzcyJdLCJuYW1lcyI6W10sIm1hcHBpbmdzIjoiQUFJQTtFQUNFLGdCQUFBO0VBQ0EsZ0NBQUE7RUFDQSxlQUFBO0VBQ0EsZ0JBQUE7RUFDQSxhQUFBO0VBQ0EsbUJBQUE7QUFIRjtBQUtFO0VBQ0Usb0JBQUE7RUFDQSwyQ0FBQTtFQUNBLDJDQUFBO0VBQ0Esa0JBQUE7RUFDQSxVQUFBO0VBQ0Esa0JBQUE7RUFDQSxXQUFBO0VBQ0EsYUFBQTtFQUNBLFdBQUE7RUFDQSxZQUFBO0FBSEoiLCJzb3VyY2VzQ29udGVudCI6WyIucGVyc29uYWwtY29udGVudCB7XG4gIC8vICAgYmFja2dyb3VuZC1jb2xvcjogdmFyKC0taW9uLWNvbG9yLXBlcnNvbmFsLXNoYWRlKTtcbiAgLy8gICBjb2xvcjogd2hpdGU7XG59XG5pb24tY2FyZC1oZWFkZXIge1xuICB0ZXh0LWFsaWduOiBsZWZ0O1xuICBib3JkZXItcmFkaXVzOiAxMHB4IDEwcHggMHB4IDBweDtcbiAgZm9udC1zaXplOiAxOHB4O1xuICBmb250LXdlaWdodDogNTAwO1xuICBwYWRkaW5nOiAxMnB4O1xuICBtYXJnaW4tYm90dG9tOiAyNHB4O1xuXG4gIGlvbi1hdmF0YXIge1xuICAgIC0tYm9yZGVyLXJhZGl1czogNTAlO1xuICAgIGJvcmRlcjogc29saWQgNXB4IHZhcigtLWlvbi1jb2xvci1wZXJzb25hbCk7XG4gICAgYmFja2dyb3VuZC1jb2xvcjogdmFyKC0taW9uLWNvbG9yLXBlcnNvbmFsKTtcbiAgICBwb3NpdGlvbjogYWJzb2x1dGU7XG4gICAgei1pbmRleDogMjtcbiAgICB0ZXh0LWFsaWduOiBjZW50ZXI7XG4gICAgcmlnaHQ6IDEycHg7XG4gICAgYm90dG9tOiAtMjlweDtcbiAgICB3aWR0aDogNjRweDtcbiAgICBoZWlnaHQ6IDY0cHg7XG4gIH1cbn1cbiJdLCJzb3VyY2VSb290IjoiIn0= */"]
  }));
}
_staticBlock();

/***/ }),

/***/ 30052:
/*!****************************************************!*\
  !*** ./src/app/core/shared/pipes/SafeHtml.pipe.ts ***!
  \****************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   SafeHtmlPipe: () => (/* binding */ SafeHtmlPipe)
/* harmony export */ });
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! @angular/core */ 12481);
/* harmony import */ var _angular_platform_browser__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @angular/platform-browser */ 80436);
var _staticBlock;


class SafeHtmlPipe {
  constructor(sanitized) {
    this.sanitized = sanitized;
  }
  transform(value) {
    return this.sanitized.bypassSecurityTrustHtml(value);
  }
  static #_ = _staticBlock = () => (this.ɵfac = function SafeHtmlPipe_Factory(__ngFactoryType__) {
    return new (__ngFactoryType__ || SafeHtmlPipe)(_angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵdirectiveInject"](_angular_platform_browser__WEBPACK_IMPORTED_MODULE_1__.DomSanitizer, 16));
  }, this.ɵpipe = /*@__PURE__*/_angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵdefinePipe"]({
    name: "safeHtml",
    type: SafeHtmlPipe,
    pure: true,
    standalone: false
  }));
}
_staticBlock();

/***/ }),

/***/ 30116:
/*!***********************************************************************!*\
  !*** ./src/app/core/shared/plugin-mocks/BackgroundGeolocationMock.ts ***!
  \***********************************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   BackgroundGeolocationMock: () => (/* binding */ BackgroundGeolocationMock)
/* harmony export */ });
/* harmony import */ var _Users_smartcommunitylab_Desktop_newWork_playAndGo_playGo_node_modules_babel_runtime_helpers_esm_asyncToGenerator_js__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./node_modules/@babel/runtime/helpers/esm/asyncToGenerator.js */ 89204);
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! tslib */ 24398);
/* harmony import */ var _transistorsoft_capacitor_background_geolocation__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @transistorsoft/capacitor-background-geolocation */ 5914);
/* harmony import */ var lodash_es__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! lodash-es */ 80524);
/* harmony import */ var lodash_es__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! lodash-es */ 31046);
/* harmony import */ var lodash_es__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! lodash-es */ 53183);
/* harmony import */ var _utils__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! ../utils */ 7497);
/* harmony import */ var _mock_utils__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(/*! ./mock-utils */ 79880);

var _staticBlock;

/* eslint-disable @typescript-eslint/naming-convention */
/* eslint-disable @typescript-eslint/member-ordering */
/* eslint-disable prefer-arrow/prefer-arrow-functions */




const mockMethod = (0,_mock_utils__WEBPACK_IMPORTED_MODULE_7__.getMockMethodAnnotation)({
  doLog: false,
  logPrefix: 'BackgroundGeolocationMock'
});
class BackgroundGeolocationMock {
  constructor() {
    throw new Error('static mock');
  }
  static findOrCreateTransistorAuthorizationToken() {
    return 'TOKEN_MOCK';
  }
  static ready(config) {
    return (0,_Users_smartcommunitylab_Desktop_newWork_playAndGo_playGo_node_modules_babel_runtime_helpers_esm_asyncToGenerator_js__WEBPACK_IMPORTED_MODULE_0__["default"])(function* () {
      return {
        enabled: true
      };
    })();
  }
  static setConfig(config) {
    return (0,_Users_smartcommunitylab_Desktop_newWork_playAndGo_playGo_node_modules_babel_runtime_helpers_esm_asyncToGenerator_js__WEBPACK_IMPORTED_MODULE_0__["default"])(function* () {
      BackgroundGeolocationMock.config = config;
    })();
  }
  static requestPermission() {
    return (0,_Users_smartcommunitylab_Desktop_newWork_playAndGo_playGo_node_modules_babel_runtime_helpers_esm_asyncToGenerator_js__WEBPACK_IMPORTED_MODULE_0__["default"])(function* () {
      if (BackgroundGeolocationMock.lastPermissionStatus === true) {
        return BackgroundGeolocationMock.AUTHORIZATION_STATUS_ALWAYS;
      }
      if (BackgroundGeolocationMock.permissionDeniedCount >= 2) {
        return BackgroundGeolocationMock.AUTHORIZATION_STATUS_DENIED;
      }
      yield (0,_utils__WEBPACK_IMPORTED_MODULE_6__.waitMs)(200);
      const confirmRes = confirm('Allow location tracking? \n (mocked)');
      BackgroundGeolocationMock.lastPermissionStatus = confirmRes;
      if (confirmRes === false) {
        BackgroundGeolocationMock.permissionDeniedCount++;
      }
      return confirmRes ? BackgroundGeolocationMock.AUTHORIZATION_STATUS_ALWAYS : BackgroundGeolocationMock.AUTHORIZATION_STATUS_DENIED;
    })();
  }
  static getCurrentPosition(request) {
    return (0,_Users_smartcommunitylab_Desktop_newWork_playAndGo_playGo_node_modules_babel_runtime_helpers_esm_asyncToGenerator_js__WEBPACK_IMPORTED_MODULE_0__["default"])(function* () {
      const location = BackgroundGeolocationMock.getRandomLocation(request.extras);
      if (request?.persist !== false) {
        BackgroundGeolocationMock.locations.push(location);
      }
      return location;
    })();
  }
  static start() {
    return (0,_Users_smartcommunitylab_Desktop_newWork_playAndGo_playGo_node_modules_babel_runtime_helpers_esm_asyncToGenerator_js__WEBPACK_IMPORTED_MODULE_0__["default"])(function* () {
      BackgroundGeolocationMock.isTracking = true;
    })();
  }
  static changePace(force) {
    return (0,_Users_smartcommunitylab_Desktop_newWork_playAndGo_playGo_node_modules_babel_runtime_helpers_esm_asyncToGenerator_js__WEBPACK_IMPORTED_MODULE_0__["default"])(function* () {
      BackgroundGeolocationMock.isTracking = true;
    })();
  }
  static stop() {
    return (0,_Users_smartcommunitylab_Desktop_newWork_playAndGo_playGo_node_modules_babel_runtime_helpers_esm_asyncToGenerator_js__WEBPACK_IMPORTED_MODULE_0__["default"])(function* () {
      BackgroundGeolocationMock.isTracking = false;
    })();
  }
  static destroyLocations() {
    return (0,_Users_smartcommunitylab_Desktop_newWork_playAndGo_playGo_node_modules_babel_runtime_helpers_esm_asyncToGenerator_js__WEBPACK_IMPORTED_MODULE_0__["default"])(function* () {
      BackgroundGeolocationMock.isTracking = false;
    })();
  }
  static sync() {
    return (0,_Users_smartcommunitylab_Desktop_newWork_playAndGo_playGo_node_modules_babel_runtime_helpers_esm_asyncToGenerator_js__WEBPACK_IMPORTED_MODULE_0__["default"])(function* () {
      const locations = BackgroundGeolocationMock.locations;
      BackgroundGeolocationMock.locations = [];
      return locations;
    })();
  }
  static getLocations() {
    return (0,_Users_smartcommunitylab_Desktop_newWork_playAndGo_playGo_node_modules_babel_runtime_helpers_esm_asyncToGenerator_js__WEBPACK_IMPORTED_MODULE_0__["default"])(function* () {
      return [...BackgroundGeolocationMock.locations];
    })();
  }
  static onLocation(handler) {
    BackgroundGeolocationMock.handlers.add(handler);
    return {
      remove: () => {
        BackgroundGeolocationMock.handlers.delete(handler);
        console.log('BackgroundGeolocationMock: onLocation subscription removed!');
      }
    };
  }
  static onPowerSaveChange(handler) {
    return {
      remove: () => {}
    };
  }
  static isPowerSaveMode() {
    return (0,_Users_smartcommunitylab_Desktop_newWork_playAndGo_playGo_node_modules_babel_runtime_helpers_esm_asyncToGenerator_js__WEBPACK_IMPORTED_MODULE_0__["default"])(function* () {
      return false;
    })();
  }
  static getRandomLocation(extras = {}) {
    const lastCoords = (0,lodash_es__WEBPACK_IMPORTED_MODULE_3__["default"])(BackgroundGeolocationMock.locations)?.coords || {
      latitude: 46.06787,
      longitude: 11.12108
    };
    const newCoords = (0,lodash_es__WEBPACK_IMPORTED_MODULE_4__["default"])(lastCoords, coord => coord + (0,lodash_es__WEBPACK_IMPORTED_MODULE_5__["default"])(-0.001, 0.001));
    return {
      coords: {
        ...newCoords,
        accuracy: 10 + Math.random() * 20
      },
      timestamp: new Date().toISOString(),
      extras: {
        ...BackgroundGeolocationMock.config.extras,
        ...extras
      }
    };
  }
  static initMockTracking() {
    setInterval(() => {
      if (BackgroundGeolocationMock.isTracking) {
        const location = BackgroundGeolocationMock.getRandomLocation();
        BackgroundGeolocationMock.locations.push(location);
        BackgroundGeolocationMock.handlers.forEach(handler => handler(location));
      }
    }, 5000);
  }
  static #_ = _staticBlock = () => (this.locations = [], this.config = {
    extras: {}
  }, this.isTracking = false, this.handlers = new Set(), this.lastPermissionStatus = null, this.permissionDeniedCount = 0, this.AUTHORIZATION_STATUS_ALWAYS = _transistorsoft_capacitor_background_geolocation__WEBPACK_IMPORTED_MODULE_2__["default"].AUTHORIZATION_STATUS_ALWAYS, this.AUTHORIZATION_STATUS_DENIED = _transistorsoft_capacitor_background_geolocation__WEBPACK_IMPORTED_MODULE_2__["default"].AUTHORIZATION_STATUS_DENIED, BackgroundGeolocationMock.initMockTracking());
}
_staticBlock();
(0,tslib__WEBPACK_IMPORTED_MODULE_1__.__decorate)([mockMethod()], BackgroundGeolocationMock, "findOrCreateTransistorAuthorizationToken", null);
(0,tslib__WEBPACK_IMPORTED_MODULE_1__.__decorate)([mockMethod({
  async: true
})], BackgroundGeolocationMock, "ready", null);
(0,tslib__WEBPACK_IMPORTED_MODULE_1__.__decorate)([mockMethod({
  async: true
})], BackgroundGeolocationMock, "setConfig", null);
(0,tslib__WEBPACK_IMPORTED_MODULE_1__.__decorate)([mockMethod({
  async: true,
  wait: 1
})], BackgroundGeolocationMock, "requestPermission", null);
(0,tslib__WEBPACK_IMPORTED_MODULE_1__.__decorate)([mockMethod({
  async: true,
  wait: 1000
})], BackgroundGeolocationMock, "getCurrentPosition", null);
(0,tslib__WEBPACK_IMPORTED_MODULE_1__.__decorate)([mockMethod({
  async: true
})], BackgroundGeolocationMock, "start", null);
(0,tslib__WEBPACK_IMPORTED_MODULE_1__.__decorate)([mockMethod({
  async: true
})], BackgroundGeolocationMock, "changePace", null);
(0,tslib__WEBPACK_IMPORTED_MODULE_1__.__decorate)([mockMethod({
  async: true
})], BackgroundGeolocationMock, "stop", null);
(0,tslib__WEBPACK_IMPORTED_MODULE_1__.__decorate)([mockMethod({
  async: true
})], BackgroundGeolocationMock, "destroyLocations", null);
(0,tslib__WEBPACK_IMPORTED_MODULE_1__.__decorate)([mockMethod({
  async: true
})], BackgroundGeolocationMock, "sync", null);
(0,tslib__WEBPACK_IMPORTED_MODULE_1__.__decorate)([mockMethod({
  async: true
})], BackgroundGeolocationMock, "getLocations", null);
(0,tslib__WEBPACK_IMPORTED_MODULE_1__.__decorate)([mockMethod()], BackgroundGeolocationMock, "onLocation", null);
(0,tslib__WEBPACK_IMPORTED_MODULE_1__.__decorate)([mockMethod()], BackgroundGeolocationMock, "onPowerSaveChange", null);
(0,tslib__WEBPACK_IMPORTED_MODULE_1__.__decorate)([mockMethod({
  async: true
})], BackgroundGeolocationMock, "isPowerSaveMode", null);

/***/ }),

/***/ 32076:
/*!****************************************************************************!*\
  !*** ./src/app/core/api/generated/controllers/reportController.service.ts ***!
  \****************************************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   ReportControllerService: () => (/* binding */ ReportControllerService)
/* harmony export */ });
/* harmony import */ var src_environments_environment__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! src/environments/environment */ 45312);
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @angular/core */ 34205);
/* harmony import */ var _angular_common_http__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @angular/common/http */ 63855);
var _staticBlock;
/**
 * Play&Go Project
 * No description provided (generated by Swagger Codegen https://github.com/swagger-api/swagger-codegen)
 *
 * OpenAPI spec version: 2.0
 * Contact: info@smartcommunitylab.it
 *
 * NOTE: This class is auto generated by the swagger code generator program.
 * https://github.com/swagger-api/swagger-codegen.git
 * Do not edit the class manually.
 */



class ReportControllerService {
  constructor(http) {
    this.http = http;
  }
  /**
   * geGroupCampaingPlacingByTransportMode
   *
   * @param campaignId campaignId
   * @param groupId groupId
   * @param metric metric
   * @param mean mean
   * @param dateFrom yyyy-MM-dd
   * @param dateTo yyyy-MM-dd
   */
  geGroupCampaingPlacingByTransportModeUsingGET(args) {
    const {
      campaignId,
      groupId,
      metric,
      mean,
      dateFrom,
      dateTo
    } = args;
    return this.http.request('get', src_environments_environment__WEBPACK_IMPORTED_MODULE_0__.environment.serverUrl.api + `/playandgo/api/report/campaign/placing/group/transport`, {
      params: removeNullOrUndefined({
        campaignId,
        groupId,
        metric,
        mean,
        dateFrom,
        dateTo
      })
    });
  }
  /**
   * getCampaingPlacingByGame
   *
   * @param campaignId campaignId
   * @param page Results page you want to retrieve (0..N)
   * @param size Number of records per page
   * @param sort Sorting option: field,[asc,desc]
   * @param dateFrom yyyy-MM-dd
   * @param dateTo yyyy-MM-dd
   * @param groupByGroupId groupByGroupId
   */
  getCampaingPlacingByGameUsingGET(args) {
    const {
      campaignId,
      page,
      size,
      sort,
      dateFrom,
      dateTo,
      groupByGroupId
    } = args;
    return this.http.request('get', src_environments_environment__WEBPACK_IMPORTED_MODULE_0__.environment.serverUrl.api + `/playandgo/api/report/campaign/placing/game`, {
      params: removeNullOrUndefined({
        campaignId,
        page,
        size,
        sort,
        dateFrom,
        dateTo,
        groupByGroupId
      })
    });
  }
  /**
   * getCampaingPlacingByTransportStats
   *
   * @param campaignId campaignId
   * @param page Results page you want to retrieve (0..N)
   * @param size Number of records per page
   * @param metric metric
   * @param sort Sorting option: field,[asc,desc]
   * @param mean mean
   * @param dateFrom yyyy-MM-dd
   * @param dateTo yyyy-MM-dd
   * @param groupByGroupId groupByGroupId
   */
  getCampaingPlacingByTransportStatsUsingGET(args) {
    const {
      campaignId,
      page,
      size,
      metric,
      sort,
      mean,
      dateFrom,
      dateTo,
      groupByGroupId,
      filterByGroupId
    } = args;
    return this.http.request('get', src_environments_environment__WEBPACK_IMPORTED_MODULE_0__.environment.serverUrl.api + `/playandgo/api/report/campaign/placing/transport`, {
      params: removeNullOrUndefined({
        campaignId,
        page,
        size,
        sort,
        metric,
        mean,
        dateFrom,
        dateTo,
        groupByGroupId,
        filterByGroupId
      })
    });
  }
  /**
   * getGroupCampaingPlacingByGame
   *
   * @param campaignId campaignId
   * @param groupId groupId
   * @param dateFrom yyyy-MM-dd
   * @param dateTo yyyy-MM-dd
   */
  getGroupCampaingPlacingByGameUsingGET(args) {
    const {
      campaignId,
      groupId,
      dateFrom,
      dateTo
    } = args;
    return this.http.request('get', src_environments_environment__WEBPACK_IMPORTED_MODULE_0__.environment.serverUrl.api + `/playandgo/api/report/campaign/placing/group/game`, {
      params: removeNullOrUndefined({
        campaignId,
        groupId,
        dateFrom,
        dateTo
      })
    });
  }
  /**
   * getGroupGameStats
   *
   * @param campaignId campaignId
   * @param groupId groupId
   * @param groupMode groupMode
   * @param dateFrom yyyy-MM-dd
   * @param dateTo yyyy-MM-dd
   */
  getGroupGameStatsUsingGET(args) {
    const {
      campaignId,
      groupId,
      groupMode,
      dateFrom,
      dateTo
    } = args;
    return this.http.request('get', src_environments_environment__WEBPACK_IMPORTED_MODULE_0__.environment.serverUrl.api + `/playandgo/api/report/group/game/stats`, {
      params: removeNullOrUndefined({
        campaignId,
        groupId,
        groupMode,
        dateFrom,
        dateTo
      })
    });
  }
  /**
   * getGroupTransportStatsGroupByMean
   *
   * @param campaignId campaignId
   * @param groupId groupId
   * @param metric metric
   * @param dateFrom yyyy-MM-dd
   * @param dateTo yyyy-MM-dd
   */
  getGroupTransportStatsGroupByMeanUsingGET(args) {
    const {
      campaignId,
      groupId,
      metric,
      dateFrom,
      dateTo
    } = args;
    return this.http.request('get', src_environments_environment__WEBPACK_IMPORTED_MODULE_0__.environment.serverUrl.api + `/playandgo/api/report/group/transport/stats/mean`, {
      params: removeNullOrUndefined({
        campaignId,
        groupId,
        metric,
        dateFrom,
        dateTo
      })
    });
  }
  /**
   * getGroupTransportStats
   *
   * @param campaignId campaignId
   * @param groupId groupId
   * @param metric metric
   * @param groupMode groupMode
   * @param mean mean
   * @param dateFrom yyyy-MM-dd
   * @param dateTo yyyy-MM-dd
   */
  getGroupTransportStatsUsingGET(args) {
    const {
      campaignId,
      groupId,
      metric,
      groupMode,
      mean,
      dateFrom,
      dateTo
    } = args;
    return this.http.request('get', src_environments_environment__WEBPACK_IMPORTED_MODULE_0__.environment.serverUrl.api + `/playandgo/api/report/group/transport/stats`, {
      params: removeNullOrUndefined({
        campaignId,
        groupId,
        metric,
        groupMode,
        mean,
        dateFrom,
        dateTo
      })
    });
  }
  /**
   * getPlayerCampaingPlacingByGame
   *
   * @param campaignId campaignId
   * @param playerId playerId
   * @param dateFrom yyyy-MM-dd
   * @param dateTo yyyy-MM-dd
   */
  getPlayerCampaingPlacingByGameUsingGET(args) {
    const {
      campaignId,
      playerId,
      dateFrom,
      dateTo
    } = args;
    return this.http.request('get', src_environments_environment__WEBPACK_IMPORTED_MODULE_0__.environment.serverUrl.api + `/playandgo/api/report/campaign/placing/player/game`, {
      params: removeNullOrUndefined({
        campaignId,
        playerId,
        dateFrom,
        dateTo
      })
    });
  }
  /**
   * getPlayerCampaingPlacingByTransportMode
   *
   * @param campaignId campaignId
   * @param playerId playerId
   * @param metric metric
   * @param mean mean
   * @param dateFrom yyyy-MM-dd
   * @param dateTo yyyy-MM-dd
   */
  getPlayerCampaingPlacingByTransportModeUsingGET(args) {
    const {
      campaignId,
      playerId,
      metric,
      mean,
      dateFrom,
      dateTo,
      filterByGroupId
    } = args;
    return this.http.request('get', src_environments_environment__WEBPACK_IMPORTED_MODULE_0__.environment.serverUrl.api + `/playandgo/api/report/campaign/placing/player/transport`, {
      params: removeNullOrUndefined({
        campaignId,
        playerId,
        metric,
        mean,
        dateFrom,
        dateTo,
        filterByGroupId
      })
    });
  }
  /**
   * getPlayerGameStats
   *
   * @param campaignId campaignId
   * @param playerId playerId
   * @param groupMode groupMode
   * @param dateFrom yyyy-MM-dd
   * @param dateTo yyyy-MM-dd
   */
  getPlayerGameStatsUsingGET1(args) {
    const {
      campaignId,
      playerId,
      groupMode,
      dateFrom,
      dateTo
    } = args;
    return this.http.request('get', src_environments_environment__WEBPACK_IMPORTED_MODULE_0__.environment.serverUrl.api + `/playandgo/api/report/player/game/stats`, {
      params: removeNullOrUndefined({
        campaignId,
        playerId,
        groupMode,
        dateFrom,
        dateTo
      })
    });
  }
  /**
   * getPlayerTransportRecord
   *
   * @param campaignId campaignId
   * @param playerId playerId
   * @param metric metric
   * @param groupMode groupMode
   * @param mean mean
   */
  getPlayerTransportRecordUsingGET(args) {
    const {
      campaignId,
      playerId,
      metric,
      groupMode,
      mean
    } = args;
    return this.http.request('get', src_environments_environment__WEBPACK_IMPORTED_MODULE_0__.environment.serverUrl.api + `/playandgo/api/report/player/transport/record`, {
      params: removeNullOrUndefined({
        campaignId,
        playerId,
        metric,
        groupMode,
        mean
      })
    });
  }
  /**
   * getPlayerTransportStatsGroupByMean
   *
   * @param campaignId campaignId
   * @param playerId playerId
   * @param metric metric
   * @param dateFrom yyyy-MM-dd
   * @param dateTo yyyy-MM-dd
   */
  getPlayerTransportStatsGroupByMeanUsingGET(args) {
    const {
      campaignId,
      playerId,
      metric,
      dateFrom,
      dateTo
    } = args;
    return this.http.request('get', src_environments_environment__WEBPACK_IMPORTED_MODULE_0__.environment.serverUrl.api + `/playandgo/api/report/player/transport/stats/mean`, {
      params: removeNullOrUndefined({
        campaignId,
        playerId,
        metric,
        dateFrom,
        dateTo
      })
    });
  }
  /**
   * getPlayerTransportStats
   *
   * @param campaignId campaignId
   * @param playerId playerId
   * @param metric metric
   * @param groupMode groupMode
   * @param mean mean
   * @param dateFrom yyyy-MM-dd
   * @param dateTo yyyy-MM-dd
   */
  getPlayerTransportStatsUsingGET(args) {
    const {
      campaignId,
      playerId,
      metric,
      groupMode,
      mean,
      dateFrom,
      dateTo
    } = args;
    return this.http.request('get', src_environments_environment__WEBPACK_IMPORTED_MODULE_0__.environment.serverUrl.api + `/playandgo/api/report/player/transport/stats`, {
      params: removeNullOrUndefined({
        campaignId,
        playerId,
        metric,
        groupMode,
        mean,
        dateFrom,
        dateTo
      })
    });
  }
  static #_ = _staticBlock = () => (this.ɵfac = function ReportControllerService_Factory(__ngFactoryType__) {
    return new (__ngFactoryType__ || ReportControllerService)(_angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵinject"](_angular_common_http__WEBPACK_IMPORTED_MODULE_2__.HttpClient));
  }, this.ɵprov = /*@__PURE__*/_angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵdefineInjectable"]({
    token: ReportControllerService,
    factory: ReportControllerService.ɵfac,
    providedIn: 'root'
  }));
}
_staticBlock();
function removeNullOrUndefined(obj) {
  const newObj = {};
  Object.keys(obj).forEach(key => {
    if (obj[key] != null) {
      newObj[key] = obj[key];
    }
  });
  return newObj;
}

/***/ }),

/***/ 33976:
/*!**********************************************!*\
  !*** ./src/app/core/auth/ng-http.service.ts ***!
  \**********************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   NgHttpService: () => (/* binding */ NgHttpService)
/* harmony export */ });
/* harmony import */ var _Users_smartcommunitylab_Desktop_newWork_playAndGo_playGo_node_modules_babel_runtime_helpers_esm_asyncToGenerator_js__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./node_modules/@babel/runtime/helpers/esm/asyncToGenerator.js */ 89204);
/* harmony import */ var _angular_common_http__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @angular/common/http */ 63855);
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @angular/core */ 34205);

var _staticBlock;



class NgHttpService {
  constructor(http) {
    this.http = http;
  }
  xhr(settings) {
    var _this = this;
    return (0,_Users_smartcommunitylab_Desktop_newWork_playAndGo_playGo_node_modules_babel_runtime_helpers_esm_asyncToGenerator_js__WEBPACK_IMPORTED_MODULE_0__["default"])(function* () {
      if (!settings.method) {
        settings.method = 'GET';
      }
      switch (settings.method) {
        case 'GET':
          return _this.http.get(settings.url, {
            headers: _this.getHeaders(settings.headers)
          }).toPromise();
        case 'POST':
          return _this.http.post(settings.url, settings.data, {
            headers: _this.getHeaders(settings.headers)
          }).toPromise();
        case 'PUT':
          return _this.http.put(settings.url, settings.data, {
            headers: _this.getHeaders(settings.headers)
          }).toPromise();
        case 'DELETE':
          return _this.http.delete(settings.url, {
            headers: _this.getHeaders(settings.headers)
          }).toPromise();
      }
    })();
  }
  getHeaders(headers) {
    let httpHeaders = new _angular_common_http__WEBPACK_IMPORTED_MODULE_1__.HttpHeaders();
    if (headers !== undefined) {
      Object.keys(headers).forEach(key => {
        httpHeaders = httpHeaders.append(key, headers[key]);
      });
    }
    return httpHeaders;
  }
  static #_ = _staticBlock = () => (this.ɵfac = function NgHttpService_Factory(__ngFactoryType__) {
    return new (__ngFactoryType__ || NgHttpService)(_angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵinject"](_angular_common_http__WEBPACK_IMPORTED_MODULE_1__.HttpClient));
  }, this.ɵprov = /*@__PURE__*/_angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵdefineInjectable"]({
    token: NgHttpService,
    factory: NgHttpService.ɵfac,
    providedIn: 'root'
  }));
}
_staticBlock();

/***/ }),

/***/ 34127:
/*!****************************************************************************************************************!*\
  !*** ./src/app/core/shared/campaigns/home-widget-types/home-campaign-school/home-campaign-school.component.ts ***!
  \****************************************************************************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   HomeCampaignSchoolComponent: () => (/* binding */ HomeCampaignSchoolComponent)
/* harmony export */ });
/* harmony import */ var luxon__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! luxon */ 45967);
/* harmony import */ var _time_utils__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ../../../time.utils */ 27780);
/* harmony import */ var _utils__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! ../../../utils */ 7497);
/* harmony import */ var _campaignUtils__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! ../../campaignUtils */ 83239);
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! @angular/core */ 12481);
/* harmony import */ var _services_user_service__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! ../../../services/user.service */ 89815);
/* harmony import */ var _services_report_service__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! ../../../services/report.service */ 40610);
/* harmony import */ var _services_error_service__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(/*! ../../../services/error.service */ 46078);
/* harmony import */ var _services_team_service__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(/*! ../../../services/team.service */ 62625);
/* harmony import */ var _services_challenge_service__WEBPACK_IMPORTED_MODULE_9__ = __webpack_require__(/*! ../../../services/challenge.service */ 16561);
/* harmony import */ var _angular_common__WEBPACK_IMPORTED_MODULE_10__ = __webpack_require__(/*! @angular/common */ 93683);
/* harmony import */ var _ionic_angular__WEBPACK_IMPORTED_MODULE_11__ = __webpack_require__(/*! @ionic/angular */ 21507);
/* harmony import */ var _main_campaign_stat_main_campaign_stat_component__WEBPACK_IMPORTED_MODULE_12__ = __webpack_require__(/*! ../../main-campaign-stat/main-campaign-stat.component */ 79238);
/* harmony import */ var _home_school_profile_home_school_profile_component__WEBPACK_IMPORTED_MODULE_13__ = __webpack_require__(/*! ./home-school-profile/home-school-profile.component */ 26311);
/* harmony import */ var _home_school_progression_home_school_progression_component__WEBPACK_IMPORTED_MODULE_14__ = __webpack_require__(/*! ./home-school-progression/home-school-progression.component */ 4927);
/* harmony import */ var _notification_badge_notification_badge_component__WEBPACK_IMPORTED_MODULE_15__ = __webpack_require__(/*! ../notification-badge/notification-badge.component */ 25211);
/* harmony import */ var _app_widget_campaign_app_home_campaign_challenges_app_home_campaign_challenges_component__WEBPACK_IMPORTED_MODULE_16__ = __webpack_require__(/*! ../../app-widget-campaign/app-home-campaign-challenges/app-home-campaign-challenges.component */ 77234);
/* harmony import */ var _ngx_translate_core__WEBPACK_IMPORTED_MODULE_17__ = __webpack_require__(/*! @ngx-translate/core */ 48503);
/* harmony import */ var _pipes_languageMap_pipe__WEBPACK_IMPORTED_MODULE_18__ = __webpack_require__(/*! ../../../pipes/languageMap.pipe */ 69618);
var _staticBlock;



















const _c0 = a0 => ({
  "home-card-widget": a0
});
function HomeCampaignSchoolComponent_app_notification_badge_0_Template(rf, ctx) {
  if (rf & 1) {
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵelement"](0, "app-notification-badge", 11);
  }
  if (rf & 2) {
    const ctx_r0 = _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵnextContext"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵproperty"]("type", "campaign")("campaignContainer", ctx_r0.campaignContainer);
  }
}
function HomeCampaignSchoolComponent_div_5_Template(rf, ctx) {
  if (rf & 1) {
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵelementStart"](0, "div", 12)(1, "span");
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵtext"](2);
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵpipe"](3, "languageMap");
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵelementEnd"]()();
  }
  if (rf & 2) {
    const ctx_r0 = _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵnextContext"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵadvance"](2);
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵtextInterpolate1"](" ", _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵpipeBind1"](3, 1, ctx_r0.campaignContainer.campaign.name));
  }
}
function HomeCampaignSchoolComponent_ng_template_6_Template(rf, ctx) {
  if (rf & 1) {
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵelementStart"](0, "div")(1, "span");
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵtext"](2);
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵpipe"](3, "translate");
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵelementEnd"]()();
  }
  if (rf & 2) {
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵadvance"](2);
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵtextInterpolate1"](" ", _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵpipeBind1"](3, 1, "campaigns.detail.generalStat"));
  }
}
function HomeCampaignSchoolComponent_ng_container_11_app_home_school_progression_1_Template(rf, ctx) {
  if (rf & 1) {
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵelement"](0, "app-home-school-progression", 15);
  }
  if (rf & 2) {
    const ctx_r0 = _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵnextContext"](2);
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵproperty"]("stat", ctx_r0.progressionTeam)("type", "team");
  }
}
function HomeCampaignSchoolComponent_ng_container_11_app_home_school_progression_4_Template(rf, ctx) {
  if (rf & 1) {
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵelement"](0, "app-home-school-progression", 15);
  }
  if (rf & 2) {
    const ctx_r0 = _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵnextContext"](2);
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵproperty"]("stat", ctx_r0.progressionPlayer)("type", "personal");
  }
}
function HomeCampaignSchoolComponent_ng_container_11_app_home_campaign_challenges_7_Template(rf, ctx) {
  if (rf & 1) {
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵelement"](0, "app-home-campaign-challenges", 16);
  }
  if (rf & 2) {
    const ctx_r0 = _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵnextContext"](2);
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵproperty"]("team", true)("campaignContainer", ctx_r0.campaignContainer);
  }
}
function HomeCampaignSchoolComponent_ng_container_11_Template(rf, ctx) {
  if (rf & 1) {
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵelementContainerStart"](0);
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵtemplate"](1, HomeCampaignSchoolComponent_ng_container_11_app_home_school_progression_1_Template, 1, 2, "app-home-school-progression", 13);
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵpipe"](2, "async");
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵpipe"](3, "async");
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵtemplate"](4, HomeCampaignSchoolComponent_ng_container_11_app_home_school_progression_4_Template, 1, 2, "app-home-school-progression", 13);
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵpipe"](5, "async");
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵpipe"](6, "async");
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵtemplate"](7, HomeCampaignSchoolComponent_ng_container_11_app_home_campaign_challenges_7_Template, 1, 2, "app-home-campaign-challenges", 14);
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵpipe"](8, "async");
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵpipe"](9, "async");
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵelementContainerEnd"]();
  }
  if (rf & 2) {
    let tmp_3_0;
    let tmp_4_0;
    let tmp_5_0;
    const ctx_r0 = _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵnextContext"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵadvance"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵproperty"]("ngIf", ((tmp_3_0 = _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵpipeBind1"](2, 3, ctx_r0.activeUncompleteChallenges$)) == null ? null : tmp_3_0.length) === 0 && ((tmp_3_0 = _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵpipeBind1"](3, 5, ctx_r0.activeUncompleteChallengesTeam$)) == null ? null : tmp_3_0.length) === 0);
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵadvance"](3);
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵproperty"]("ngIf", ((tmp_4_0 = _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵpipeBind1"](5, 7, ctx_r0.activeUncompleteChallenges$)) == null ? null : tmp_4_0.length) === 0 && ((tmp_4_0 = _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵpipeBind1"](6, 9, ctx_r0.activeUncompleteChallengesTeam$)) == null ? null : tmp_4_0.length) === 0);
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵadvance"](3);
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵproperty"]("ngIf", ((tmp_5_0 = _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵpipeBind1"](8, 11, ctx_r0.activeUncompleteChallenges$)) == null ? null : tmp_5_0.length) !== 0 || ((tmp_5_0 = _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵpipeBind1"](9, 13, ctx_r0.activeUncompleteChallengesTeam$)) == null ? null : tmp_5_0.length) !== 0);
  }
}
function HomeCampaignSchoolComponent_ng_template_12_Template(rf, ctx) {
  if (rf & 1) {
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵelement"](0, "app-home-school-progression", 15)(1, "app-home-school-progression", 15);
  }
  if (rf & 2) {
    const ctx_r0 = _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵnextContext"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵproperty"]("stat", ctx_r0.progressionTeam)("type", "team");
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵadvance"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵproperty"]("stat", ctx_r0.progressionPlayer)("type", "personal");
  }
}
class HomeCampaignSchoolComponent {
  constructor(userService, reportService, errorService, teamService, challengeService) {
    this.userService = userService;
    this.reportService = reportService;
    this.errorService = errorService;
    this.teamService = teamService;
    this.challengeService = challengeService;
    this.header = false;
    this.referenceDate = luxon__WEBPACK_IMPORTED_MODULE_0__.DateTime.local();
  }
  ngOnInit() {
    this.activeUncompleteChallenges$ = this.challengeService.getActiveUncompletedChallengesByCampaign(this.campaignContainer?.campaign?.campaignId);
    this.activeUncompleteChallengesTeam$ = this.challengeService.getActiveUncompletedChallengesTeamByCampaign(this.campaignContainer?.campaign?.campaignId);
    this.imagePath = (0,_campaignUtils__WEBPACK_IMPORTED_MODULE_3__.getCampaignImage)(this.campaignContainer);
    this.subStat = this.userService.userProfile$.subscribe(profile => {
      // this.status = status;
      this.reportService.getGameStatus(this.campaignContainer.campaign.campaignId).subscribe(campaignStatus => {
        this.campaignStatus = campaignStatus;
      }, error => {
        if ((0,_utils__WEBPACK_IMPORTED_MODULE_2__.isOfflineError)(error)) {
          this.campaignStatus = null;
        } else {
          this.campaignStatus = null;
          this.errorService.handleError(error);
        }
      });
      this.subTeamPlacingWeek = this.teamService.getTeamPlacing(this.campaignContainer.campaign.campaignId, this.campaignContainer?.subscription?.campaignData?.teamId, (0,_time_utils__WEBPACK_IMPORTED_MODULE_1__.toServerDateOnly)(this.referenceDate.startOf('week')), (0,_time_utils__WEBPACK_IMPORTED_MODULE_1__.toServerDateOnly)(this.referenceDate.endOf('week'))).subscribe(stats => {
        this.reportWeekStat = stats;
      }, error => {
        if ((0,_utils__WEBPACK_IMPORTED_MODULE_2__.isOfflineError)(error)) {
          this.reportWeekStat = null;
        } else {
          this.reportWeekStat = null;
          this.errorService.handleError(error);
        }
      });
      this.subTeamPlacingTotal = this.teamService.getTeamPlacing(this.campaignContainer.campaign.campaignId, this.campaignContainer?.subscription?.campaignData?.teamId).subscribe(stats => {
        this.reportTotalStat = stats;
      }, error => {
        if ((0,_utils__WEBPACK_IMPORTED_MODULE_2__.isOfflineError)(error)) {
          this.reportTotalStat = null;
        } else {
          this.reportTotalStat = null;
          this.errorService.handleError(error);
        }
      });
      this.subTeamProgressionTeam = this.teamService.getProgressionTeam(this.campaignContainer.campaign.campaignId, this.campaignContainer?.subscription?.campaignData?.teamId, (0,_time_utils__WEBPACK_IMPORTED_MODULE_1__.toServerDateOnly)(this.referenceDate.startOf('week')), (0,_time_utils__WEBPACK_IMPORTED_MODULE_1__.toServerDateOnly)(this.referenceDate.endOf('week'))).subscribe(stats => {
        this.progressionTeam = stats;
      }, error => {
        if ((0,_utils__WEBPACK_IMPORTED_MODULE_2__.isOfflineError)(error)) {
          this.progressionTeam = null;
        } else {
          this.progressionTeam = null;
          this.errorService.handleError(error);
        }
      });
      this.subTeamProgressionPlayer = this.teamService.getProgressionPlayer(this.campaignContainer.campaign.campaignId, profile.playerId, (0,_time_utils__WEBPACK_IMPORTED_MODULE_1__.toServerDateOnly)(this.referenceDate.startOf('week')), (0,_time_utils__WEBPACK_IMPORTED_MODULE_1__.toServerDateOnly)(this.referenceDate.endOf('week'))).subscribe(stats => {
        this.progressionPlayer = stats;
      }, error => {
        if ((0,_utils__WEBPACK_IMPORTED_MODULE_2__.isOfflineError)(error)) {
          this.progressionPlayer = null;
        } else {
          this.progressionPlayer = null;
          this.errorService.handleError(error);
        }
      });
    });
  }
  goToChallenge(event) {
    if (event && event.stopPropagation) {
      console.log('goToChallenge - stopPropagation');
      event.stopPropagation();
    }
    console.log('goToChallenge');
  }
  ngOnDestroy() {
    this.subStat.unsubscribe();
    this.subTeamPlacingWeek.unsubscribe();
    this.subTeamPlacingTotal.unsubscribe();
    this.subTeamProgressionTeam.unsubscribe();
    this.subTeamProgressionPlayer.unsubscribe();
  }
  static #_ = _staticBlock = () => (this.ɵfac = function HomeCampaignSchoolComponent_Factory(__ngFactoryType__) {
    return new (__ngFactoryType__ || HomeCampaignSchoolComponent)(_angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵdirectiveInject"](_services_user_service__WEBPACK_IMPORTED_MODULE_5__.UserService), _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵdirectiveInject"](_services_report_service__WEBPACK_IMPORTED_MODULE_6__.ReportService), _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵdirectiveInject"](_services_error_service__WEBPACK_IMPORTED_MODULE_7__.ErrorService), _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵdirectiveInject"](_services_team_service__WEBPACK_IMPORTED_MODULE_8__.TeamService), _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵdirectiveInject"](_services_challenge_service__WEBPACK_IMPORTED_MODULE_9__.ChallengeService));
  }, this.ɵcmp = /*@__PURE__*/_angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵdefineComponent"]({
    type: HomeCampaignSchoolComponent,
    selectors: [["app-home-campaign-school"]],
    inputs: {
      campaignContainer: "campaignContainer",
      header: "header"
    },
    standalone: false,
    decls: 14,
    vars: 15,
    consts: [["detailHeader", ""], ["noHome", ""], [3, "type", "campaignContainer", 4, "ngIf"], [3, "ngClass"], ["color", "school"], ["alt", "Avatar", 3, "src"], ["lines", "none", "color", "school", 4, "ngIf", "ngIfElse"], [1, "school-content", "ion-no-padding"], [3, "campaignContainer"], [3, "campaignContainer", "status", "reportWeekStat", "reportTotalStat", "unit"], [4, "ngIf", "ngIfElse"], [3, "type", "campaignContainer"], ["lines", "none", "color", "school"], [3, "stat", "type", 4, "ngIf"], [3, "team", "campaignContainer", 4, "ngIf"], [3, "stat", "type"], [3, "team", "campaignContainer"]],
    template: function HomeCampaignSchoolComponent_Template(rf, ctx) {
      if (rf & 1) {
        _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵtemplate"](0, HomeCampaignSchoolComponent_app_notification_badge_0_Template, 1, 2, "app-notification-badge", 2);
        _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵelementStart"](1, "ion-card", 3)(2, "ion-card-header", 4)(3, "ion-avatar");
        _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵelement"](4, "img", 5);
        _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵtemplate"](5, HomeCampaignSchoolComponent_div_5_Template, 4, 3, "div", 6)(6, HomeCampaignSchoolComponent_ng_template_6_Template, 4, 3, "ng-template", null, 0, _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵtemplateRefExtractor"]);
        _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵelementStart"](8, "ion-card-content", 7);
        _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵelement"](9, "app-home-school-profile", 8)(10, "app-main-campaign-stat", 9);
        _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵtemplate"](11, HomeCampaignSchoolComponent_ng_container_11_Template, 10, 15, "ng-container", 10)(12, HomeCampaignSchoolComponent_ng_template_12_Template, 2, 4, "ng-template", null, 1, _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵtemplateRefExtractor"]);
        _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵelementEnd"]()();
      }
      if (rf & 2) {
        const detailHeader_r2 = _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵreference"](7);
        const noHome_r3 = _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵreference"](13);
        _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵproperty"]("ngIf", ctx.header);
        _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵadvance"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵproperty"]("ngClass", _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵpureFunction1"](13, _c0, ctx.header));
        _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵadvance"](3);
        _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵproperty"]("src", ctx.imagePath, _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵsanitizeUrl"]);
        _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵadvance"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵproperty"]("ngIf", ctx.header)("ngIfElse", detailHeader_r2);
        _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵadvance"](4);
        _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵproperty"]("campaignContainer", ctx.campaignContainer);
        _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵadvance"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵproperty"]("campaignContainer", ctx.campaignContainer)("status", ctx.campaignStatus)("reportWeekStat", ctx.reportWeekStat)("reportTotalStat", ctx.reportTotalStat)("unit", "eL");
        _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵadvance"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵproperty"]("ngIf", ctx.header)("ngIfElse", noHome_r3);
      }
    },
    dependencies: [_angular_common__WEBPACK_IMPORTED_MODULE_10__.NgClass, _angular_common__WEBPACK_IMPORTED_MODULE_10__.NgIf, _ionic_angular__WEBPACK_IMPORTED_MODULE_11__.IonAvatar, _ionic_angular__WEBPACK_IMPORTED_MODULE_11__.IonCard, _ionic_angular__WEBPACK_IMPORTED_MODULE_11__.IonCardContent, _ionic_angular__WEBPACK_IMPORTED_MODULE_11__.IonCardHeader, _main_campaign_stat_main_campaign_stat_component__WEBPACK_IMPORTED_MODULE_12__.MainCampaignStatComponent, _home_school_profile_home_school_profile_component__WEBPACK_IMPORTED_MODULE_13__.HomeSchoolProfiloComponent, _home_school_progression_home_school_progression_component__WEBPACK_IMPORTED_MODULE_14__.HomeSchoolProgressionComponent, _notification_badge_notification_badge_component__WEBPACK_IMPORTED_MODULE_15__.NotificationBadgeComponent, _app_widget_campaign_app_home_campaign_challenges_app_home_campaign_challenges_component__WEBPACK_IMPORTED_MODULE_16__.HomeCampaignChallengeComponent, _angular_common__WEBPACK_IMPORTED_MODULE_10__.AsyncPipe, _ngx_translate_core__WEBPACK_IMPORTED_MODULE_17__.TranslatePipe, _pipes_languageMap_pipe__WEBPACK_IMPORTED_MODULE_18__.LanguageMapPipe],
    styles: [".school-content[_ngcontent-%COMP%] {\n  color: black;\n}\n\nion-card[_ngcontent-%COMP%] {\n  overflow: visible;\n}\nion-card[_ngcontent-%COMP%]   #challenge[_ngcontent-%COMP%] {\n  overflow: visible;\n}\nion-card[_ngcontent-%COMP%]   ion-card-header[_ngcontent-%COMP%] {\n  text-align: left;\n  border-radius: 10px 10px 0px 0px;\n  font-size: 18px;\n  font-weight: 500;\n  padding: 12px;\n}\nion-card[_ngcontent-%COMP%]   ion-card-header[_ngcontent-%COMP%]   ion-avatar[_ngcontent-%COMP%] {\n  --border-radius: 50%;\n  border: solid 5px var(--ion-color-school);\n  background-color: var(--ion-color-school);\n  position: absolute;\n  z-index: 2;\n  text-align: center;\n  right: 12px;\n  bottom: -29px;\n  width: 64px;\n  height: 64px;\n}\n/*# sourceMappingURL=data:application/json;charset=utf-8;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbIndlYnBhY2s6Ly8uL3NyYy9hcHAvY29yZS9zaGFyZWQvY2FtcGFpZ25zL2hvbWUtd2lkZ2V0LXR5cGVzL2hvbWUtY2FtcGFpZ24tc2Nob29sL2hvbWUtY2FtcGFpZ24tc2Nob29sLmNvbXBvbmVudC5zY3NzIl0sIm5hbWVzIjpbXSwibWFwcGluZ3MiOiJBQUFBO0VBRUUsWUFBQTtBQUFGOztBQUVBO0VBQ0UsaUJBQUE7QUFDRjtBQUFFO0VBQ0UsaUJBQUE7QUFFSjtBQUFFO0VBQ0UsZ0JBQUE7RUFDQSxnQ0FBQTtFQUNBLGVBQUE7RUFDQSxnQkFBQTtFQUNBLGFBQUE7QUFFSjtBQURJO0VBQ0Usb0JBQUE7RUFDQSx5Q0FBQTtFQUNBLHlDQUFBO0VBQ0Esa0JBQUE7RUFDQSxVQUFBO0VBQ0Esa0JBQUE7RUFDQSxXQUFBO0VBQ0EsYUFBQTtFQUNBLFdBQUE7RUFDQSxZQUFBO0FBR04iLCJzb3VyY2VzQ29udGVudCI6WyIuc2Nob29sLWNvbnRlbnQge1xuICAvLyAgIGJhY2tncm91bmQtY29sb3I6IHZhcigtLWlvbi1jb2xvci1zY2hvb2wtdGludCk7XG4gIGNvbG9yOiBibGFjaztcbn1cbmlvbi1jYXJkIHtcbiAgb3ZlcmZsb3c6IHZpc2libGU7XG4gICNjaGFsbGVuZ2Uge1xuICAgIG92ZXJmbG93OiB2aXNpYmxlO1xuICB9XG4gIGlvbi1jYXJkLWhlYWRlciB7XG4gICAgdGV4dC1hbGlnbjogbGVmdDtcbiAgICBib3JkZXItcmFkaXVzOiAxMHB4IDEwcHggMHB4IDBweDtcbiAgICBmb250LXNpemU6IDE4cHg7XG4gICAgZm9udC13ZWlnaHQ6IDUwMDtcbiAgICBwYWRkaW5nOiAxMnB4O1xuICAgIGlvbi1hdmF0YXIge1xuICAgICAgLS1ib3JkZXItcmFkaXVzOiA1MCU7XG4gICAgICBib3JkZXI6IHNvbGlkIDVweCB2YXIoLS1pb24tY29sb3Itc2Nob29sKTtcbiAgICAgIGJhY2tncm91bmQtY29sb3I6IHZhcigtLWlvbi1jb2xvci1zY2hvb2wpO1xuICAgICAgcG9zaXRpb246IGFic29sdXRlO1xuICAgICAgei1pbmRleDogMjtcbiAgICAgIHRleHQtYWxpZ246IGNlbnRlcjtcbiAgICAgIHJpZ2h0OiAxMnB4O1xuICAgICAgYm90dG9tOiAtMjlweDtcbiAgICAgIHdpZHRoOiA2NHB4O1xuICAgICAgaGVpZ2h0OiA2NHB4O1xuICAgIH1cbiAgfVxufVxuIl0sInNvdXJjZVJvb3QiOiIifQ== */"]
  }));
}
_staticBlock();

/***/ }),

/***/ 35056:
/*!***********************************************!*\
  !*** ./src/app/core/auth/auth.interceptor.ts ***!
  \***********************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   AuthInterceptor: () => (/* binding */ AuthInterceptor)
/* harmony export */ });
/* harmony import */ var _angular_common_http__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! @angular/common/http */ 63855);
/* harmony import */ var rxjs__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! rxjs */ 95429);
/* harmony import */ var rxjs__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! rxjs */ 77919);
/* harmony import */ var rxjs_operators__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! rxjs/operators */ 61318);
/* harmony import */ var rxjs_operators__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! rxjs/operators */ 51903);
/* harmony import */ var rxjs_operators__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! rxjs/operators */ 89475);
/* harmony import */ var rxjs_operators__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! rxjs/operators */ 64334);
/* harmony import */ var rxjs_operators__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(/*! rxjs/operators */ 98764);
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(/*! @angular/core */ 34205);
/* harmony import */ var _auth_service__WEBPACK_IMPORTED_MODULE_9__ = __webpack_require__(/*! ./auth.service */ 35524);
/* harmony import */ var _shared_services_spinner_service__WEBPACK_IMPORTED_MODULE_10__ = __webpack_require__(/*! ../shared/services/spinner.service */ 74821);
/* harmony import */ var _shared_services_refresher_service__WEBPACK_IMPORTED_MODULE_11__ = __webpack_require__(/*! ../shared/services/refresher.service */ 8780);
var _staticBlock;







class AuthInterceptor {
  constructor(authService, spinnerService, refresherService) {
    this.authService = authService;
    this.spinnerService = spinnerService;
    this.refresherService = refresherService;
    this.sharedToken$ = this.authService.validToken$;
    this.urlsToNotUse = [];
  }
  // eslint-disable-next-line @typescript-eslint/ban-types
  intercept(request, next) {
    if (!this.isValidRequestForInterceptor(request.url)) {
      return next.handle(request);
    }
    return this.handle(request, next);
  }
  handle(request, next) {
    const spinnerTopic = request.url + Math.random();
    return this.sharedToken$.pipe((0,rxjs_operators__WEBPACK_IMPORTED_MODULE_6__.take)(1),
    // timeout({ first: 5000 }),
    (0,rxjs_operators__WEBPACK_IMPORTED_MODULE_7__.tap)(() => this.spinnerService.show(spinnerTopic)), (0,rxjs_operators__WEBPACK_IMPORTED_MODULE_7__.tap)(() => this.refresherService.httpCallStarted()), (0,rxjs_operators__WEBPACK_IMPORTED_MODULE_4__.concatMap)(token => {
      const requestWithToken = request.clone({
        // eslint-disable-next-line @typescript-eslint/naming-convention
        setHeaders: {
          // eslint-disable-next-line @typescript-eslint/naming-convention
          Authorization: `${token.tokenType === 'bearer' ? 'Bearer' : token.tokenType} ${token.accessToken}`,
          // eslint-disable-next-line @typescript-eslint/naming-convention
          Accept: '*/*'
        }
      });
      return next.handle(requestWithToken).pipe((0,rxjs_operators__WEBPACK_IMPORTED_MODULE_3__.catchError)(error => {
        if (error instanceof _angular_common_http__WEBPACK_IMPORTED_MODULE_0__.HttpErrorResponse && error.status === 401) {
          return this.handle401Error(requestWithToken, next);
        }
        return (0,rxjs__WEBPACK_IMPORTED_MODULE_2__.throwError)(() => error);
      }));
    }), (0,rxjs_operators__WEBPACK_IMPORTED_MODULE_5__.finalize)(() => {
      this.spinnerService.hide(spinnerTopic);
      this.refresherService.httpCallEnded();
    }));
  }
  handle401Error(request, next) {
    return (0,rxjs__WEBPACK_IMPORTED_MODULE_1__.from)(this.authService.forceRefreshToken()).pipe((0,rxjs_operators__WEBPACK_IMPORTED_MODULE_4__.concatMap)(() => this.sharedToken$.pipe((0,rxjs_operators__WEBPACK_IMPORTED_MODULE_6__.take)(1))), (0,rxjs_operators__WEBPACK_IMPORTED_MODULE_4__.concatMap)(newToken => next.handle(this.changeToken(newToken.accessToken, request))), (0,rxjs_operators__WEBPACK_IMPORTED_MODULE_3__.catchError)(err => {
      this.authService.postLogoutCleanup();
      return (0,rxjs__WEBPACK_IMPORTED_MODULE_2__.throwError)(() => err);
    }));
  }
  changeToken(accessToken, request) {
    return request.clone({
      headers: request.headers.set('Authorization', `Bearer ${accessToken}`)
    });
  }
  isValidRequestForInterceptor(requestUrl) {
    if (requestUrl.indexOf('/userinfo') > 0) {
      return true;
    }
    if (requestUrl.indexOf('api/profile/campaign/') > 0) {
      return true;
    }
    if (requestUrl.indexOf('/playandgo-hsc/api') > 0) {
      return true;
    }
    const positionIndicator = 'playandgo/api/';
    const position = requestUrl.indexOf(positionIndicator);
    if (position > 0) {
      const destination = requestUrl.substr(position + positionIndicator.length);
      for (const address of this.urlsToNotUse) {
        if (new RegExp(address).test(destination)) {
          return false;
        }
      }
      return true;
    }
    return false;
  }
  static #_ = _staticBlock = () => (this.ɵfac = function AuthInterceptor_Factory(__ngFactoryType__) {
    return new (__ngFactoryType__ || AuthInterceptor)(_angular_core__WEBPACK_IMPORTED_MODULE_8__["ɵɵinject"](_auth_service__WEBPACK_IMPORTED_MODULE_9__.AuthService), _angular_core__WEBPACK_IMPORTED_MODULE_8__["ɵɵinject"](_shared_services_spinner_service__WEBPACK_IMPORTED_MODULE_10__.SpinnerService), _angular_core__WEBPACK_IMPORTED_MODULE_8__["ɵɵinject"](_shared_services_refresher_service__WEBPACK_IMPORTED_MODULE_11__.RefresherService));
  }, this.ɵprov = /*@__PURE__*/_angular_core__WEBPACK_IMPORTED_MODULE_8__["ɵɵdefineInjectable"]({
    token: AuthInterceptor,
    factory: AuthInterceptor.ɵfac
  }));
}
_staticBlock();

/***/ }),

/***/ 35524:
/*!*******************************************!*\
  !*** ./src/app/core/auth/auth.service.ts ***!
  \*******************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   AuthService: () => (/* binding */ AuthService)
/* harmony export */ });
/* harmony import */ var _Users_smartcommunitylab_Desktop_newWork_playAndGo_playGo_node_modules_babel_runtime_helpers_esm_asyncToGenerator_js__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./node_modules/@babel/runtime/helpers/esm/asyncToGenerator.js */ 89204);
/* harmony import */ var ionic_appauth__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ionic-appauth */ 94713);
/* harmony import */ var rxjs__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! rxjs */ 5342);
/* harmony import */ var rxjs__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! rxjs */ 51567);
/* harmony import */ var rxjs__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! rxjs */ 2435);
/* harmony import */ var rxjs__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! rxjs */ 70271);
/* harmony import */ var rxjs__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! rxjs */ 86301);
/* harmony import */ var rxjs__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(/*! rxjs */ 36647);
/* harmony import */ var rxjs__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(/*! rxjs */ 64334);
/* harmony import */ var src_environments_environment__WEBPACK_IMPORTED_MODULE_9__ = __webpack_require__(/*! src/environments/environment */ 45312);
/* harmony import */ var _shared_tracking_background_tracking_service__WEBPACK_IMPORTED_MODULE_10__ = __webpack_require__(/*! ../shared/tracking/background-tracking.service */ 27215);
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_11__ = __webpack_require__(/*! @angular/core */ 34205);
/* harmony import */ var _shared_services_alert_service__WEBPACK_IMPORTED_MODULE_12__ = __webpack_require__(/*! ../shared/services/alert.service */ 67406);
/* harmony import */ var _angular_router__WEBPACK_IMPORTED_MODULE_13__ = __webpack_require__(/*! @angular/router */ 85422);
/* harmony import */ var _ionic_angular__WEBPACK_IMPORTED_MODULE_14__ = __webpack_require__(/*! @ionic/angular */ 4059);
/* harmony import */ var _shared_services_local_storage_service__WEBPACK_IMPORTED_MODULE_15__ = __webpack_require__(/*! ../shared/services/local-storage.service */ 9891);
/* harmony import */ var _api_generated_controllers_playerController_service__WEBPACK_IMPORTED_MODULE_16__ = __webpack_require__(/*! ../api/generated/controllers/playerController.service */ 63971);
/* harmony import */ var _shared_services_spinner_service__WEBPACK_IMPORTED_MODULE_17__ = __webpack_require__(/*! ../shared/services/spinner.service */ 74821);

var _staticBlock;












/**
 * Wrapper around ionic-appauth service.
 */
class AuthService {
  constructor(ionicAppAuthService, alertService, router, navController, localStorageService, playerControllerService, injector, spinnerService) {
    this.ionicAppAuthService = ionicAppAuthService;
    this.alertService = alertService;
    this.router = router;
    this.navController = navController;
    this.localStorageService = localStorageService;
    this.playerControllerService = playerControllerService;
    this.injector = injector;
    this.spinnerService = spinnerService;
    this.isInitComplete$ = this.ionicAppAuthService.initComplete$.pipe((0,rxjs__WEBPACK_IMPORTED_MODULE_3__.filter)(Boolean), (0,rxjs__WEBPACK_IMPORTED_MODULE_5__.map)(() => undefined), (0,rxjs__WEBPACK_IMPORTED_MODULE_8__.take)(1), (0,rxjs__WEBPACK_IMPORTED_MODULE_6__.shareReplay)(1));
    this.isAuthenticated$ = this.isInitComplete$.pipe((0,rxjs__WEBPACK_IMPORTED_MODULE_7__.switchMap)(() => this.ionicAppAuthService.isAuthenticated$), (0,rxjs__WEBPACK_IMPORTED_MODULE_6__.shareReplay)(1));
    this.validToken$ = this.ionicAppAuthService.token$.pipe((0,rxjs__WEBPACK_IMPORTED_MODULE_3__.filter)(Boolean), (0,rxjs__WEBPACK_IMPORTED_MODULE_6__.shareReplay)(1));
    this.isReadyForApi$ = this.validToken$.pipe((0,rxjs__WEBPACK_IMPORTED_MODULE_5__.map)(() => undefined), (0,rxjs__WEBPACK_IMPORTED_MODULE_4__.first)(), (0,rxjs__WEBPACK_IMPORTED_MODULE_6__.shareReplay)(1));
    this.refreshTokenCallPromise = null;
  }
  init() {
    var _this = this;
    return (0,_Users_smartcommunitylab_Desktop_newWork_playAndGo_playGo_node_modules_babel_runtime_helpers_esm_asyncToGenerator_js__WEBPACK_IMPORTED_MODULE_0__["default"])(function* () {
      yield _this.ionicAppAuthService.init();
      _this.ionicAppAuthService.events$.subscribe(action => {
        const actionType = action.action;
        if (actionType === ionic_appauth__WEBPACK_IMPORTED_MODULE_1__.AuthActions.SignInSuccess) {
          _this.onSignInSuccess(action);
        }
        if (actionType === ionic_appauth__WEBPACK_IMPORTED_MODULE_1__.AuthActions.SignOutSuccess) {
          _this.postLogoutCleanup();
        }
        if (actionType === ionic_appauth__WEBPACK_IMPORTED_MODULE_1__.AuthActions.SignOutFailed) {
          console.error('sign out failed', action);
          // there is nothing else to do...
          _this.postLogoutCleanup();
        }
        if (actionType === ionic_appauth__WEBPACK_IMPORTED_MODULE_1__.AuthActions.SignInFailed || actionType === ionic_appauth__WEBPACK_IMPORTED_MODULE_1__.AuthActions.SignInSuccess) {
          console.log('AuthActions hide spinner', actionType);
          _this.spinnerService.hide('login');
        }
        if (actionType === ionic_appauth__WEBPACK_IMPORTED_MODULE_1__.AuthActions.SignInFailed || actionType === ionic_appauth__WEBPACK_IMPORTED_MODULE_1__.AuthActions.RefreshFailed) {
          console.error('auth error', action);
          _this.logoutAfterAuthFailed();
        }
        if (actionType === ionic_appauth__WEBPACK_IMPORTED_MODULE_1__.AuthActions.RefreshSuccess || actionType === ionic_appauth__WEBPACK_IMPORTED_MODULE_1__.AuthActions.RefreshFailed) {
          _this.refreshTokenCallPromise = null;
        }
      });
    })();
  }
  /**
   * Waits for the first token available, but later it will return latest token immediately
   *
   * This api is just promise version of authService.validToken$
   * */
  getToken() {
    var _this2 = this;
    return (0,_Users_smartcommunitylab_Desktop_newWork_playAndGo_playGo_node_modules_babel_runtime_helpers_esm_asyncToGenerator_js__WEBPACK_IMPORTED_MODULE_0__["default"])(function* () {
      return yield (0,rxjs__WEBPACK_IMPORTED_MODULE_2__.lastValueFrom)(_this2.validToken$.pipe((0,rxjs__WEBPACK_IMPORTED_MODULE_8__.take)(1)));
    })();
  }
  login(provider) {
    var _this3 = this;
    return (0,_Users_smartcommunitylab_Desktop_newWork_playAndGo_playGo_node_modules_babel_runtime_helpers_esm_asyncToGenerator_js__WEBPACK_IMPORTED_MODULE_0__["default"])(function* () {
      // redirect is handled from global event subscription
      yield _this3.ionicAppAuthService.signIn(provider ? _this3.getExtraIdp(provider) : undefined);
    })();
  }
  getExtraIdp(provider) {
    if (src_environments_environment__WEBPACK_IMPORTED_MODULE_9__.environment.idp_hint[provider]) {
      // eslint-disable-next-line @typescript-eslint/naming-convention
      return {
        idp_hint: src_environments_environment__WEBPACK_IMPORTED_MODULE_9__.environment.idp_hint[provider]
      };
    }
    return undefined;
  }
  logout() {
    var _this4 = this;
    return (0,_Users_smartcommunitylab_Desktop_newWork_playAndGo_playGo_node_modules_babel_runtime_helpers_esm_asyncToGenerator_js__WEBPACK_IMPORTED_MODULE_0__["default"])(function* () {
      // redirect is handled from global event subscription
      try {
        // in the future, we may not need to perform signOut, just delete the token. (from secure storage)
        yield _this4.ionicAppAuthService.signOut();
      } finally {
        setTimeout(() => _this4.postLogoutCleanup(), 300);
      }
    })();
  }
  logoutAfterAuthFailed() {
    var _this5 = this;
    return (0,_Users_smartcommunitylab_Desktop_newWork_playAndGo_playGo_node_modules_babel_runtime_helpers_esm_asyncToGenerator_js__WEBPACK_IMPORTED_MODULE_0__["default"])(function* () {
      //todo alert('You are not longer logged in, please log in again.');
      try {
        yield _this5.ionicAppAuthService.signOut();
      } finally {
        // redirect should be handled from global event subscription,
        // but if not, we do it manually
        setTimeout(() => _this5.postLogoutCleanup(), 300);
      }
    })();
  }
  postLogoutCleanup() {
    var _this6 = this;
    return (0,_Users_smartcommunitylab_Desktop_newWork_playAndGo_playGo_node_modules_babel_runtime_helpers_esm_asyncToGenerator_js__WEBPACK_IMPORTED_MODULE_0__["default"])(function* () {
      // clear out storage
      yield _this6.localStorageService.clearAll();
      // clear stored data of plugins
      const backgroundTrackingService = _this6.injector.get(_shared_tracking_background_tracking_service__WEBPACK_IMPORTED_MODULE_10__.BackgroundTrackingService);
      if (backgroundTrackingService) {
        yield backgroundTrackingService.clearPluginData();
      }
      // clear local state stored in variables of all services. By doing
      // hard page reload.
      location.replace('login');
    })();
  }
  /**
   * Uses one time refresh token, to get a new token from aac.
   *
   * Function guarantees that the token will be asked only once, even if there are multiple calls.
   */
  forceRefreshToken() {
    if (!this.refreshTokenCallPromise) {
      this.refreshTokenCallPromise = this.ionicAppAuthService.refreshToken();
    }
    return this.refreshTokenCallPromise;
  }
  /** called from EndSessionPage */
  endSessionCallback() {
    this.ionicAppAuthService.endSessionCallback();
    this.navController.navigateRoot('login');
  }
  /** called from AuthCallbackPage */
  authorizationCallback() {
    return this.ionicAppAuthService.authorizationCallback(window.location.origin + this.router.url);
  }
  onSignInSuccess(action) {
    var _this7 = this;
    return (0,_Users_smartcommunitylab_Desktop_newWork_playAndGo_playGo_node_modules_babel_runtime_helpers_esm_asyncToGenerator_js__WEBPACK_IMPORTED_MODULE_0__["default"])(function* () {
      const userIsRegistered = yield _this7.isUserRegistered();
      if (userIsRegistered === true) {
        _this7.alertService.showToast({
          messageTranslateKey: 'login.welcome'
        });
        _this7.navController.navigateRoot('/pages/tabs/home');
      } else if (userIsRegistered === false) {
        _this7.navController.navigateRoot('/pages/registration');
      } else {
        // api call failed... but token should be there
        console.error('failed to check if user is registered after log in!', action);
        _this7.navController.navigateRoot('login');
      }
    })();
  }
  /**
   * TODO: this could be included in the token response.
   *
   * We cannot use user service, because of the circular dependency.
   * */
  isUserRegistered() {
    var _this8 = this;
    return (0,_Users_smartcommunitylab_Desktop_newWork_playAndGo_playGo_node_modules_babel_runtime_helpers_esm_asyncToGenerator_js__WEBPACK_IMPORTED_MODULE_0__["default"])(function* () {
      try {
        const user = yield _this8.playerControllerService.getProfileUsingGET().toPromise();
        if (user) {
          //user registered
          return true;
        } else {
          //user not registered
          return false;
        }
      } catch (e) {
        // toto check local storage
        console.warn(e);
        return null;
      }
    })();
  }
  static #_ = _staticBlock = () => (this.ɵfac = function AuthService_Factory(__ngFactoryType__) {
    return new (__ngFactoryType__ || AuthService)(_angular_core__WEBPACK_IMPORTED_MODULE_11__["ɵɵinject"]('IonicAppAuthService'), _angular_core__WEBPACK_IMPORTED_MODULE_11__["ɵɵinject"](_shared_services_alert_service__WEBPACK_IMPORTED_MODULE_12__.AlertService), _angular_core__WEBPACK_IMPORTED_MODULE_11__["ɵɵinject"](_angular_router__WEBPACK_IMPORTED_MODULE_13__.Router), _angular_core__WEBPACK_IMPORTED_MODULE_11__["ɵɵinject"](_ionic_angular__WEBPACK_IMPORTED_MODULE_14__.NavController), _angular_core__WEBPACK_IMPORTED_MODULE_11__["ɵɵinject"](_shared_services_local_storage_service__WEBPACK_IMPORTED_MODULE_15__.LocalStorageService), _angular_core__WEBPACK_IMPORTED_MODULE_11__["ɵɵinject"](_api_generated_controllers_playerController_service__WEBPACK_IMPORTED_MODULE_16__.PlayerControllerService), _angular_core__WEBPACK_IMPORTED_MODULE_11__["ɵɵinject"](_angular_core__WEBPACK_IMPORTED_MODULE_11__.Injector), _angular_core__WEBPACK_IMPORTED_MODULE_11__["ɵɵinject"](_shared_services_spinner_service__WEBPACK_IMPORTED_MODULE_17__.SpinnerService));
  }, this.ɵprov = /*@__PURE__*/_angular_core__WEBPACK_IMPORTED_MODULE_11__["ɵɵdefineInjectable"]({
    token: AuthService,
    factory: AuthService.ɵfac,
    providedIn: 'root'
  }));
}
_staticBlock();

/***/ }),

/***/ 35808:
/*!*********************************************************************************************************************************************!*\
  !*** ./src/app/core/shared/campaigns/app-widget-campaign/app-home-campaign-challenges/app-challenge-state/app-challenge-state.component.ts ***!
  \*********************************************************************************************************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   ChallengeStateComponent: () => (/* binding */ ChallengeStateComponent)
/* harmony export */ });
/* harmony import */ var rxjs__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! rxjs */ 70271);
/* harmony import */ var rxjs__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! rxjs */ 98764);
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @angular/core */ 34205);
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @angular/core */ 12481);
/* harmony import */ var _ionic_angular__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! @ionic/angular */ 4059);
/* harmony import */ var _ionic_angular__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! @ionic/angular */ 21507);
/* harmony import */ var _angular_common__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! @angular/common */ 93683);
/* harmony import */ var _ui_icon_icon_component__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(/*! ../../../../ui/icon/icon.component */ 59621);
/* harmony import */ var _ngx_translate_core__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(/*! @ngx-translate/core */ 48503);
var _staticBlock;






const _c0 = a0 => ({
  backgroundColor: a0
});
const _c1 = (a0, a1) => ({
  borderColor: a0,
  backgroundColor: a1
});
const _c2 = a0 => ({
  active: a0
});
const _c3 = a0 => ({
  configurable: a0
});
const _c4 = a0 => ({
  invites: a0
});
function ChallengeStateComponent_div_1_Template(rf, ctx) {
  if (rf & 1) {
    const _r1 = _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵgetCurrentView"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵelementStart"](0, "div", 2);
    _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵlistener"]("click", function ChallengeStateComponent_div_1_Template_div_click_0_listener($event) {
      _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵrestoreView"](_r1);
      const ctx_r1 = _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵnextContext"]();
      return _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵresetView"](ctx_r1.goToActiveChallenge($event));
    });
    _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵelementStart"](1, "ion-avatar", 3);
    _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵelement"](2, "app-icon", 4);
    _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵelementEnd"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵelementStart"](3, "div", 5);
    _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵtext"](4);
    _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵpipe"](5, "async");
    _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵpipe"](6, "async");
    _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵpipe"](7, "translate");
    _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵelementEnd"]()();
  }
  if (rf & 2) {
    let tmp_2_0;
    const ctx_r1 = _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵnextContext"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵadvance"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵproperty"]("ngStyle", _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵpureFunction2"](9, _c1, " var(--ion-color-" + (ctx_r1.campaignContainer == null ? null : ctx_r1.campaignContainer.campaign == null ? null : ctx_r1.campaignContainer.campaign.type) + ")", " var(--ion-color-" + (ctx_r1.campaignContainer == null ? null : ctx_r1.campaignContainer.campaign == null ? null : ctx_r1.campaignContainer.campaign.type) + "-light)"));
    _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵadvance"](3);
    _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵtextInterpolate"](_angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵpipeBind2"](7, 6, "challenges.active", _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵpureFunction1"](12, _c2, ((tmp_2_0 = _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵpipeBind1"](5, 2, ctx_r1.activeUncompleteChallenges$)) == null ? null : tmp_2_0.length) + ((tmp_2_0 = _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵpipeBind1"](6, 4, ctx_r1.activeUncompleteChallengesTeam$)) == null ? null : tmp_2_0.length))));
  }
}
function ChallengeStateComponent_div_4_Template(rf, ctx) {
  if (rf & 1) {
    const _r3 = _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵgetCurrentView"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵelementStart"](0, "div", 2);
    _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵlistener"]("click", function ChallengeStateComponent_div_4_Template_div_click_0_listener($event) {
      _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵrestoreView"](_r3);
      const ctx_r1 = _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵnextContext"]();
      return _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵresetView"](ctx_r1.goToConfigureChallenge($event));
    });
    _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵelementStart"](1, "ion-avatar", 3);
    _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵelement"](2, "app-icon", 6);
    _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵelementEnd"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵelementStart"](3, "div", 5);
    _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵtext"](4);
    _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵpipe"](5, "async");
    _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵpipe"](6, "async");
    _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵpipe"](7, "async");
    _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵpipe"](8, "translate");
    _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵelementEnd"]()();
  }
  if (rf & 2) {
    let tmp_2_0;
    const ctx_r1 = _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵnextContext"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵadvance"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵproperty"]("ngStyle", _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵpureFunction2"](11, _c1, " var(--ion-color-" + (ctx_r1.campaignContainer == null ? null : ctx_r1.campaignContainer.campaign == null ? null : ctx_r1.campaignContainer.campaign.type) + ")", " var(--ion-color-" + (ctx_r1.campaignContainer == null ? null : ctx_r1.campaignContainer.campaign == null ? null : ctx_r1.campaignContainer.campaign.type) + "-light)"));
    _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵadvance"](3);
    _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵtextInterpolate"](_angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵpipeBind2"](8, 8, "challenges.configure", _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵpureFunction1"](14, _c3, (((tmp_2_0 = _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵpipeBind1"](5, 2, ctx_r1.configureChallenges$)) == null ? null : tmp_2_0.length) > 0 ? 1 : 0) + (_angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵpipeBind1"](6, 4, ctx_r1.canInvite$) && _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵpipeBind1"](7, 6, ctx_r1.coupled$) === false ? 1 : 0))));
  }
}
function ChallengeStateComponent_div_8_Template(rf, ctx) {
  if (rf & 1) {
    const _r4 = _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵgetCurrentView"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵelementStart"](0, "div", 2);
    _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵlistener"]("click", function ChallengeStateComponent_div_8_Template_div_click_0_listener($event) {
      _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵrestoreView"](_r4);
      const ctx_r1 = _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵnextContext"]();
      return _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵresetView"](ctx_r1.goToInvitationsChallenge($event));
    });
    _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵelementStart"](1, "ion-avatar", 3);
    _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵelement"](2, "app-icon", 7);
    _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵelementEnd"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵelementStart"](3, "div", 5);
    _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵtext"](4);
    _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵpipe"](5, "async");
    _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵpipe"](6, "translate");
    _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵelementEnd"]()();
  }
  if (rf & 2) {
    let tmp_2_0;
    const ctx_r1 = _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵnextContext"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵadvance"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵproperty"]("ngStyle", _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵpureFunction2"](7, _c1, " var(--ion-color-" + (ctx_r1.campaignContainer == null ? null : ctx_r1.campaignContainer.campaign == null ? null : ctx_r1.campaignContainer.campaign.type) + ")", " var(--ion-color-" + (ctx_r1.campaignContainer == null ? null : ctx_r1.campaignContainer.campaign == null ? null : ctx_r1.campaignContainer.campaign.type) + "-light)"));
    _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵadvance"](3);
    _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵtextInterpolate"](_angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵpipeBind2"](6, 4, "challenges.invitations", _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵpureFunction1"](10, _c4, (tmp_2_0 = _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵpipeBind1"](5, 2, ctx_r1.invitesChallenges$)) == null ? null : tmp_2_0.length)));
  }
}
class ChallengeStateComponent {
  constructor(navController) {
    this.navController = navController;
  }
  ngOnInit() {
    this.coupled$ = this.onlyFutureChallenges$.pipe((0,rxjs__WEBPACK_IMPORTED_MODULE_1__.tap)(challenges => console.log(challenges)), (0,rxjs__WEBPACK_IMPORTED_MODULE_0__.map)(challenges => challenges.some(x => {
      if (x.type === 'groupCooperative' || x.type === 'groupCompetitiveTime' || x.type === 'groupCompetitivePerformance') {
        return true;
      }
      return false;
    })), (0,rxjs__WEBPACK_IMPORTED_MODULE_1__.tap)(challenges => console.log(challenges)));
  }
  goToActiveChallenge(event) {
    const navigationExtras = {
      queryParams: {
        selectedSegment: 'activeChallenges'
      }
    };
    if (event && event.stopPropagation) {
      event.stopPropagation();
    }
    this.navController.navigateRoot('/pages/tabs/challenges', navigationExtras);
  }
  goToConfigureChallenge(event) {
    const navigationExtras = {
      queryParams: {
        selectedSegment: 'futureChallenges'
      }
    };
    if (event && event.stopPropagation) {
      event.stopPropagation();
    }
    this.navController.navigateRoot('/pages/tabs/challenges', navigationExtras);
  }
  goToInvitationsChallenge(event) {
    const navigationExtras = {
      queryParams: {
        selectedSegment: 'futureChallenges'
      }
    };
    if (event && event.stopPropagation) {
      event.stopPropagation();
    }
    this.navController.navigateRoot('/pages/tabs/challenges', navigationExtras);
  }
  static #_ = _staticBlock = () => (this.ɵfac = function ChallengeStateComponent_Factory(__ngFactoryType__) {
    return new (__ngFactoryType__ || ChallengeStateComponent)(_angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵdirectiveInject"](_ionic_angular__WEBPACK_IMPORTED_MODULE_4__.NavController));
  }, this.ɵcmp = /*@__PURE__*/_angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵdefineComponent"]({
    type: ChallengeStateComponent,
    selectors: [["app-challenge-state"]],
    inputs: {
      campaignContainer: "campaignContainer",
      activeUncompleteChallenges$: "activeUncompleteChallenges$",
      activeUncompleteChallengesTeam$: "activeUncompleteChallengesTeam$",
      configureChallenges$: "configureChallenges$",
      invitesChallenges$: "invitesChallenges$",
      canInvite$: "canInvite$",
      onlyFutureChallenges$: "onlyFutureChallenges$"
    },
    standalone: false,
    decls: 10,
    vars: 18,
    consts: [[1, "challenges-state", 3, "ngStyle"], [3, "click", 4, "ngIf"], [3, "click"], [3, "ngStyle"], ["name", "groupCompetitivePerformance", 1, "type-notif", "icon-size-normal"], [1, "challenge-text"], ["name", "cupCog", 1, "type-notif", "icon-size-normal"], ["name", "invitation", 1, "type-notif", "icon-size-normal"]],
    template: function ChallengeStateComponent_Template(rf, ctx) {
      if (rf & 1) {
        _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵelementStart"](0, "div", 0);
        _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵtemplate"](1, ChallengeStateComponent_div_1_Template, 8, 14, "div", 1);
        _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵpipe"](2, "async");
        _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵpipe"](3, "async");
        _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵtemplate"](4, ChallengeStateComponent_div_4_Template, 9, 16, "div", 1);
        _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵpipe"](5, "async");
        _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵpipe"](6, "async");
        _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵpipe"](7, "async");
        _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵtemplate"](8, ChallengeStateComponent_div_8_Template, 7, 12, "div", 1);
        _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵpipe"](9, "async");
        _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵelementEnd"]();
      }
      if (rf & 2) {
        let tmp_1_0;
        let tmp_2_0;
        let tmp_3_0;
        _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵproperty"]("ngStyle", _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵpureFunction1"](16, _c0, " var(--ion-color-" + (ctx.campaignContainer == null ? null : ctx.campaignContainer.campaign == null ? null : ctx.campaignContainer.campaign.type) + "-light)"));
        _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵadvance"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵproperty"]("ngIf", ((tmp_1_0 = _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵpipeBind1"](2, 4, ctx.activeUncompleteChallenges$)) == null ? null : tmp_1_0.length) !== 0 || ((tmp_1_0 = _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵpipeBind1"](3, 6, ctx.activeUncompleteChallengesTeam$)) == null ? null : tmp_1_0.length) !== 0);
        _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵadvance"](3);
        _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵproperty"]("ngIf", ((tmp_2_0 = _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵpipeBind1"](5, 8, ctx.configureChallenges$)) == null ? null : tmp_2_0.length) !== 0 || _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵpipeBind1"](6, 10, ctx.canInvite$) && _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵpipeBind1"](7, 12, ctx.coupled$) === false);
        _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵadvance"](4);
        _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵproperty"]("ngIf", ((tmp_3_0 = _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵpipeBind1"](9, 14, ctx.invitesChallenges$)) == null ? null : tmp_3_0.length) !== 0);
      }
    },
    dependencies: [_angular_common__WEBPACK_IMPORTED_MODULE_6__.NgIf, _angular_common__WEBPACK_IMPORTED_MODULE_6__.NgStyle, _ionic_angular__WEBPACK_IMPORTED_MODULE_5__.IonAvatar, _ui_icon_icon_component__WEBPACK_IMPORTED_MODULE_7__.IconComponent, _angular_common__WEBPACK_IMPORTED_MODULE_6__.AsyncPipe, _ngx_translate_core__WEBPACK_IMPORTED_MODULE_8__.TranslatePipe],
    styles: [".challenges-state[_ngcontent-%COMP%] {\n  display: flex;\n  flex-direction: row;\n  justify-content: space-around;\n  padding: 8px;\n}\n.challenges-state[_ngcontent-%COMP%]   .challenge-text[_ngcontent-%COMP%] {\n  font-style: italic;\n  font-weight: 300;\n  font-size: 10px;\n}\n.challenges-state[_ngcontent-%COMP%]   ion-avatar[_ngcontent-%COMP%] {\n  position: relative;\n  width: 40px;\n  height: 40px;\n  margin: auto;\n  border: solid 4px var(--ion-color-city);\n  background-color: rgba(253, 216, 53, 0.5);\n}\n.challenges-state[_ngcontent-%COMP%]   ion-avatar[_ngcontent-%COMP%]   .type-notif[_ngcontent-%COMP%] {\n  display: flex;\n  justify-content: space-around;\n  flex-direction: row;\n  padding-bottom: 4px;\n}\n.challenges-state[_ngcontent-%COMP%]   ion-avatar[_ngcontent-%COMP%]   ion-badge[_ngcontent-%COMP%] {\n  position: absolute;\n  right: -8px;\n  top: -8px;\n  border-radius: 100%;\n}\n/*# sourceMappingURL=data:application/json;charset=utf-8;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbIndlYnBhY2s6Ly8uL3NyYy9hcHAvY29yZS9zaGFyZWQvY2FtcGFpZ25zL2FwcC13aWRnZXQtY2FtcGFpZ24vYXBwLWhvbWUtY2FtcGFpZ24tY2hhbGxlbmdlcy9hcHAtY2hhbGxlbmdlLXN0YXRlL2FwcC1jaGFsbGVuZ2Utc3RhdGUuY29tcG9uZW50LnNjc3MiXSwibmFtZXMiOltdLCJtYXBwaW5ncyI6IkFBQUE7RUFFRSxhQUFBO0VBQ0EsbUJBQUE7RUFDQSw2QkFBQTtFQUNBLFlBQUE7QUFBRjtBQUNFO0VBQ0Usa0JBQUE7RUFDQSxnQkFBQTtFQUNBLGVBQUE7QUFDSjtBQUNFO0VBQ0Usa0JBQUE7RUFDQSxXQUFBO0VBQ0EsWUFBQTtFQUNBLFlBQUE7RUFJQSx1Q0FBQTtFQUNBLHlDQUFBO0FBRko7QUFHSTtFQUNFLGFBQUE7RUFDQSw2QkFBQTtFQUNBLG1CQUFBO0VBQ0EsbUJBQUE7QUFETjtBQUdJO0VBQ0Usa0JBQUE7RUFDQSxXQUFBO0VBQ0EsU0FBQTtFQUNBLG1CQUFBO0FBRE4iLCJzb3VyY2VzQ29udGVudCI6WyIuY2hhbGxlbmdlcy1zdGF0ZSB7XG4gIC8vIGJhY2tncm91bmQ6ICNmZGZkYWE7XG4gIGRpc3BsYXk6IGZsZXg7XG4gIGZsZXgtZGlyZWN0aW9uOiByb3c7XG4gIGp1c3RpZnktY29udGVudDogc3BhY2UtYXJvdW5kO1xuICBwYWRkaW5nOiA4cHg7XG4gIC5jaGFsbGVuZ2UtdGV4dCB7XG4gICAgZm9udC1zdHlsZTogaXRhbGljO1xuICAgIGZvbnQtd2VpZ2h0OiAzMDA7XG4gICAgZm9udC1zaXplOiAxMHB4O1xuICB9XG4gIGlvbi1hdmF0YXIge1xuICAgIHBvc2l0aW9uOiByZWxhdGl2ZTtcbiAgICB3aWR0aDogNDBweDtcbiAgICBoZWlnaHQ6IDQwcHg7XG4gICAgbWFyZ2luOiBhdXRvO1xuICAgIC8vZGlzcGxheTogZmxleDtcbiAgICAvL2ZsZXgtZGlyZWN0aW9uOiBjb2x1bW47XG4gICAgLy9qdXN0aWZ5LWNvbnRlbnQ6IHNwYWNlLWFyb3VuZDtcbiAgICBib3JkZXI6IHNvbGlkIDRweCB2YXIoLS1pb24tY29sb3ItY2l0eSk7XG4gICAgYmFja2dyb3VuZC1jb2xvcjogcmdiYSgyNTMsIDIxNiwgNTMsIDAuNSk7XG4gICAgLnR5cGUtbm90aWYge1xuICAgICAgZGlzcGxheTogZmxleDtcbiAgICAgIGp1c3RpZnktY29udGVudDogc3BhY2UtYXJvdW5kO1xuICAgICAgZmxleC1kaXJlY3Rpb246IHJvdztcbiAgICAgIHBhZGRpbmctYm90dG9tOiA0cHg7XG4gICAgfVxuICAgIGlvbi1iYWRnZSB7XG4gICAgICBwb3NpdGlvbjogYWJzb2x1dGU7XG4gICAgICByaWdodDogLThweDtcbiAgICAgIHRvcDogLThweDtcbiAgICAgIGJvcmRlci1yYWRpdXM6IDEwMCU7XG4gICAgfVxuICB9XG59XG4iXSwic291cmNlUm9vdCI6IiJ9 */"]
  }));
}
_staticBlock();

/***/ }),

/***/ 36092:
/*!**********************************************************************************************************!*\
  !*** ./src/app/core/shared/campaigns/app-widget-campaign/active-challenge/active-challenge.component.ts ***!
  \**********************************************************************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   ActiveChallengeComponent: () => (/* binding */ ActiveChallengeComponent)
/* harmony export */ });
/* harmony import */ var _campaign_utils__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ../../campaign.utils */ 14691);
/* harmony import */ var _capacitor_browser__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @capacitor/browser */ 26515);
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @angular/core */ 12481);
/* harmony import */ var _ionic_angular__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @ionic/angular */ 4059);
/* harmony import */ var _ionic_angular__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! @ionic/angular */ 21507);
/* harmony import */ var _services_team_service__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! ../../../services/team.service */ 62625);
/* harmony import */ var _services_error_service__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! ../../../services/error.service */ 46078);
/* harmony import */ var _angular_common__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(/*! @angular/common */ 93683);
/* harmony import */ var _ui_icon_icon_component__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(/*! ../../../ui/icon/icon.component */ 59621);
/* harmony import */ var _challenge_users_status_challenge_users_status_component__WEBPACK_IMPORTED_MODULE_9__ = __webpack_require__(/*! ../../challenge-users-status/challenge-users-status.component */ 11454);
/* harmony import */ var _challenge_bar_status_challenge_bar_status_component__WEBPACK_IMPORTED_MODULE_10__ = __webpack_require__(/*! ../../challenge-bar-status/challenge-bar-status.component */ 26856);
/* harmony import */ var _ngx_translate_core__WEBPACK_IMPORTED_MODULE_11__ = __webpack_require__(/*! @ngx-translate/core */ 48503);
/* harmony import */ var _pipes_languageMap_pipe__WEBPACK_IMPORTED_MODULE_12__ = __webpack_require__(/*! ../../../pipes/languageMap.pipe */ 69618);
var _staticBlock;












const _c0 = a0 => ({
  border: a0
});
const _c1 = a0 => ({
  backgroundColor: a0
});
function ActiveChallengeComponent_app_challenge_users_status_11_Template(rf, ctx) {
  if (rf & 1) {
    _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵelement"](0, "app-challenge-users-status", 13);
  }
  if (rf & 2) {
    const ctx_r0 = _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵnextContext"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵproperty"]("position", "home")("status", ctx_r0.challenge.status)("rowStatus", ctx_r0.challenge.row_status)("type", "type")("challengeType", ctx_r0.challenge.type)("kind", ctx_r0.challenge.kind)("campaignContainer", ctx_r0.campaign)("otherUser", ctx_r0.challenge.otherAttendeeData);
  }
}
function ActiveChallengeComponent_app_challenge_bar_status_12_Template(rf, ctx) {
  if (rf & 1) {
    _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵelement"](0, "app-challenge-bar-status", 14);
  }
  if (rf & 2) {
    const ctx_r0 = _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵnextContext"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵproperty"]("status", ctx_r0.challenge.status)("rowStatus", ctx_r0.challenge.row_status)("otherStatus", ctx_r0.challenge.otherAttendeeData == null ? null : ctx_r0.challenge.otherAttendeeData.status)("challengeType", ctx_r0.challenge.type)("type", ctx_r0.type)("campaignType", ctx_r0.campaign.campaign.type);
  }
}
class ActiveChallengeComponent {
  constructor(elementRef, navController, teamService, errorService) {
    this.elementRef = elementRef;
    this.navController = navController;
    this.teamService = teamService;
    this.errorService = errorService;
    this.team = false;
    this.imgChallenge = _campaign_utils__WEBPACK_IMPORTED_MODULE_0__.getImgChallenge;
    this.type = 'active';
    this.handleAnchorClick = event => {
      // Prevent opening anchors the default way
      event.preventDefault();
      const anchor = event.target;
      _capacitor_browser__WEBPACK_IMPORTED_MODULE_1__.Browser.open({
        url: anchor.href,
        windowName: '_system',
        presentationStyle: 'popover'
      });
    };
  }
  ngAfterViewInit() {
    //change the behaviour of _blank arrived with editor, adding a new listener and opening a browser
    this.anchors = this.elementRef.nativeElement.querySelectorAll('a');
    this.anchors.forEach(anchor => {
      anchor.addEventListener('click', this.handleAnchorClick);
    });
  }
  ngOnInit() {
    if (this.team && this.challenge?.otherAttendeeData) {
      try {
        this.otherTeam$ = this.teamService.getPublicTeam(this.campaign?.campaign?.campaignId, this.challenge?.otherAttendeeData.playerId);
      } catch (error) {
        this.errorService.handleError(error, 'silent');
      }
    }
    ;
  }
  goToChallenge(event) {
    if (event && event.stopPropagation) {
      event.stopPropagation();
    }
    this.navController.navigateRoot('/pages/tabs/challenges');
  }
  challDesc(desc, name) {
    //sub id with name
    const search = this.challenge?.otherAttendeeData?.playerId;
    const searchRegExp = new RegExp(search, 'g');
    const replaceWith = name;
    if (this.team && name && desc) return desc.replace(searchRegExp, replaceWith);
    return desc;
  }
  static #_ = _staticBlock = () => (this.ɵfac = function ActiveChallengeComponent_Factory(__ngFactoryType__) {
    return new (__ngFactoryType__ || ActiveChallengeComponent)(_angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵdirectiveInject"](_angular_core__WEBPACK_IMPORTED_MODULE_2__.ElementRef), _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵdirectiveInject"](_ionic_angular__WEBPACK_IMPORTED_MODULE_3__.NavController), _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵdirectiveInject"](_services_team_service__WEBPACK_IMPORTED_MODULE_5__.TeamService), _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵdirectiveInject"](_services_error_service__WEBPACK_IMPORTED_MODULE_6__.ErrorService));
  }, this.ɵcmp = /*@__PURE__*/_angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵdefineComponent"]({
    type: ActiveChallengeComponent,
    selectors: [["app-active-challenge"]],
    inputs: {
      challenge: "challenge",
      campaign: "campaign",
      team: "team"
    },
    standalone: false,
    decls: 22,
    vars: 26,
    consts: [[1, "ion-no-padding", 3, "ngStyle"], [1, "ion-no-padding"], ["size", "2", 1, "ion-no-padding"], [1, "challenge-icon", "icon-size-big", 3, "name"], [1, "short-desc", 3, "innerHTML"], [3, "position", "status", "rowStatus", "type", "challengeType", "kind", "campaignContainer", "otherUser", 4, "ngIf"], [3, "status", "rowStatus", "otherStatus", "challengeType", "type", "campaignType", 4, "ngIf"], [1, "container-challenges"], [1, "ion-text-end", "all-challenges", 3, "click", "ngStyle"], ["name", "arrow-forward-outline"], [1, "third-line", "line", 3, "ngStyle"], [1, "second-line", "line", 3, "ngStyle"], [1, "first-line", "line", 3, "ngStyle"], [3, "position", "status", "rowStatus", "type", "challengeType", "kind", "campaignContainer", "otherUser"], [3, "status", "rowStatus", "otherStatus", "challengeType", "type", "campaignType"]],
    template: function ActiveChallengeComponent_Template(rf, ctx) {
      if (rf & 1) {
        _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵelementStart"](0, "ion-card", 0)(1, "ion-card-header", 1)(2, "ion-grid", 1)(3, "ion-row", 1)(4, "ion-col", 2);
        _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵelement"](5, "app-icon", 3);
        _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵelementStart"](6, "ion-col");
        _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵelement"](7, "p", 4);
        _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵpipe"](8, "languageMap");
        _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵpipe"](9, "async");
        _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵelementEnd"]()()()();
        _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵelementStart"](10, "ion-card-content", 1);
        _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵtemplate"](11, ActiveChallengeComponent_app_challenge_users_status_11_Template, 1, 8, "app-challenge-users-status", 5)(12, ActiveChallengeComponent_app_challenge_bar_status_12_Template, 1, 6, "app-challenge-bar-status", 6);
        _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵelementStart"](13, "div", 7)(14, "div", 8);
        _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵlistener"]("click", function ActiveChallengeComponent_Template_div_click_14_listener($event) {
          return ctx.goToChallenge($event);
        });
        _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵelementStart"](15, "span");
        _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵtext"](16);
        _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵpipe"](17, "translate");
        _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵelement"](18, "ion-icon", 9);
        _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵelement"](19, "div", 10)(20, "div", 11)(21, "div", 12);
        _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵelementEnd"]()()();
      }
      if (rf & 2) {
        let tmp_2_0;
        _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵproperty"]("ngStyle", _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵpureFunction1"](16, _c0, "4px solid var(--ion-color-" + (ctx.campaign == null ? null : ctx.campaign.campaign == null ? null : ctx.campaign.campaign.type) + ")"));
        _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵadvance"](5);
        _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵproperty"]("name", ctx.imgChallenge(ctx.challenge.type));
        _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵadvance"](2);
        _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵproperty"]("innerHTML", ctx.challDesc(_angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵpipeBind1"](8, 10, ctx.challenge == null ? null : ctx.challenge.challDesc), (tmp_2_0 = _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵpipeBind1"](9, 12, ctx.otherTeam$)) == null ? null : tmp_2_0.customData == null ? null : tmp_2_0.customData.name), _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵsanitizeHtml"]);
        _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵadvance"](4);
        _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵproperty"]("ngIf", ctx.challenge.type !== "survey");
        _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵadvance"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵproperty"]("ngIf", ctx.challenge.type !== "survey");
        _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵadvance"](2);
        _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵproperty"]("ngStyle", _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵpureFunction1"](18, _c1, " var(--ion-color-" + (ctx.campaign == null ? null : ctx.campaign.campaign == null ? null : ctx.campaign.campaign.type) + ")"));
        _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵadvance"](2);
        _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵtextInterpolate"](_angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵpipeBind1"](17, 14, "challenges.checkallchallenges"));
        _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵadvance"](3);
        _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵproperty"]("ngStyle", _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵpureFunction1"](20, _c1, " var(--ion-color-" + (ctx.campaign == null ? null : ctx.campaign.campaign == null ? null : ctx.campaign.campaign.type) + ")"));
        _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵadvance"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵproperty"]("ngStyle", _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵpureFunction1"](22, _c1, " var(--ion-color-" + (ctx.campaign == null ? null : ctx.campaign.campaign == null ? null : ctx.campaign.campaign.type) + ")"));
        _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵadvance"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵproperty"]("ngStyle", _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵpureFunction1"](24, _c1, " var(--ion-color-" + (ctx.campaign == null ? null : ctx.campaign.campaign == null ? null : ctx.campaign.campaign.type) + ")"));
      }
    },
    dependencies: [_angular_common__WEBPACK_IMPORTED_MODULE_7__.NgIf, _angular_common__WEBPACK_IMPORTED_MODULE_7__.NgStyle, _ionic_angular__WEBPACK_IMPORTED_MODULE_4__.IonCard, _ionic_angular__WEBPACK_IMPORTED_MODULE_4__.IonCardContent, _ionic_angular__WEBPACK_IMPORTED_MODULE_4__.IonCardHeader, _ionic_angular__WEBPACK_IMPORTED_MODULE_4__.IonCol, _ionic_angular__WEBPACK_IMPORTED_MODULE_4__.IonGrid, _ionic_angular__WEBPACK_IMPORTED_MODULE_4__.IonIcon, _ionic_angular__WEBPACK_IMPORTED_MODULE_4__.IonRow, _ui_icon_icon_component__WEBPACK_IMPORTED_MODULE_8__.IconComponent, _challenge_users_status_challenge_users_status_component__WEBPACK_IMPORTED_MODULE_9__.ChallengeUsersStatusComponent, _challenge_bar_status_challenge_bar_status_component__WEBPACK_IMPORTED_MODULE_10__.ChallengeBarStatusComponent, _angular_common__WEBPACK_IMPORTED_MODULE_7__.AsyncPipe, _ngx_translate_core__WEBPACK_IMPORTED_MODULE_11__.TranslatePipe, _pipes_languageMap_pipe__WEBPACK_IMPORTED_MODULE_12__.LanguageMapPipe],
    styles: ["ion-card[_ngcontent-%COMP%] {\n  box-shadow: none !important;\n  border-radius: 8px;\n}\nion-card[_ngcontent-%COMP%]   ion-row[_ngcontent-%COMP%] {\n  align-items: center !important;\n}\nion-card[_ngcontent-%COMP%]   .header[_ngcontent-%COMP%] {\n  text-align: end;\n  padding: 2px;\n  font-style: italic;\n}\nion-card[_ngcontent-%COMP%]   .short-desc[_ngcontent-%COMP%] {\n  overflow: hidden;\n  text-overflow: ellipsis;\n  display: -webkit-box;\n  -webkit-line-clamp: 2;\n  -webkit-box-orient: vertical;\n  margin: 2px;\n}\nion-card[_ngcontent-%COMP%]   ion-icon[_ngcontent-%COMP%] {\n  display: inline-block;\n  vertical-align: middle;\n}\nion-card[_ngcontent-%COMP%]   .container-challenges[_ngcontent-%COMP%] {\n  margin-top: 2px;\n  display: flex;\n  flex-direction: row-reverse;\n}\nion-card[_ngcontent-%COMP%]   .container-challenges[_ngcontent-%COMP%]   .line[_ngcontent-%COMP%] {\n  display: inline-block;\n}\nion-card[_ngcontent-%COMP%]   .container-challenges[_ngcontent-%COMP%]   .first-line[_ngcontent-%COMP%] {\n  height: 22px;\n  width: 2px;\n  margin-left: 6px;\n}\nion-card[_ngcontent-%COMP%]   .container-challenges[_ngcontent-%COMP%]   .second-line[_ngcontent-%COMP%] {\n  height: 22px;\n  width: 4px;\n  margin-left: 6px;\n}\nion-card[_ngcontent-%COMP%]   .container-challenges[_ngcontent-%COMP%]   .third-line[_ngcontent-%COMP%] {\n  height: 22px;\n  width: 8px;\n  margin-left: 6px;\n}\nion-card[_ngcontent-%COMP%]   .container-challenges[_ngcontent-%COMP%]   .all-challenges[_ngcontent-%COMP%] {\n  width: fit-content;\n  padding: 2px 4px;\n  height: 22px;\n  margin-left: 6px;\n}\nion-card[_ngcontent-%COMP%]   .container-challenges[_ngcontent-%COMP%]   .all-challenges[_ngcontent-%COMP%]   span[_ngcontent-%COMP%] {\n  font-style: italic;\n}\n/*# sourceMappingURL=data:application/json;charset=utf-8;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbIndlYnBhY2s6Ly8uL3NyYy9hcHAvY29yZS9zaGFyZWQvY2FtcGFpZ25zL2FwcC13aWRnZXQtY2FtcGFpZ24vYWN0aXZlLWNoYWxsZW5nZS9hY3RpdmUtY2hhbGxlbmdlLmNvbXBvbmVudC5zY3NzIl0sIm5hbWVzIjpbXSwibWFwcGluZ3MiOiJBQUFBO0VBSUUsMkJBQUE7RUFDQSxrQkFBQTtBQUZGO0FBRkU7RUFDRSw4QkFBQTtBQUlKO0FBQUU7RUFDRSxlQUFBO0VBQ0EsWUFBQTtFQUNBLGtCQUFBO0FBRUo7QUFBRTtFQUNFLGdCQUFBO0VBQ0EsdUJBQUE7RUFDQSxvQkFBQTtFQUNBLHFCQUFBO0VBQ0EsNEJBQUE7RUFDQSxXQUFBO0FBRUo7QUFBRTtFQUNFLHFCQUFBO0VBQ0Esc0JBQUE7QUFFSjtBQUFFO0VBQ0UsZUFBQTtFQUNBLGFBQUE7RUFDQSwyQkFBQTtBQUVKO0FBQUk7RUFDRSxxQkFBQTtBQUVOO0FBQUk7RUFDRSxZQUFBO0VBQ0EsVUFBQTtFQUNBLGdCQUFBO0FBRU47QUFBSTtFQUNFLFlBQUE7RUFDQSxVQUFBO0VBQ0EsZ0JBQUE7QUFFTjtBQUFJO0VBQ0UsWUFBQTtFQUNBLFVBQUE7RUFDQSxnQkFBQTtBQUVOO0FBQUk7RUFDRSxrQkFBQTtFQUNBLGdCQUFBO0VBQ0EsWUFBQTtFQUNBLGdCQUFBO0FBRU47QUFETTtFQUNFLGtCQUFBO0FBR1IiLCJzb3VyY2VzQ29udGVudCI6WyJpb24tY2FyZCB7XG4gIGlvbi1yb3cge1xuICAgIGFsaWduLWl0ZW1zOiBjZW50ZXIgIWltcG9ydGFudDtcbiAgfVxuICBib3gtc2hhZG93OiBub25lICFpbXBvcnRhbnQ7XG4gIGJvcmRlci1yYWRpdXM6IDhweDtcbiAgLmhlYWRlciB7XG4gICAgdGV4dC1hbGlnbjogZW5kO1xuICAgIHBhZGRpbmc6IDJweDtcbiAgICBmb250LXN0eWxlOiBpdGFsaWM7XG4gIH1cbiAgLnNob3J0LWRlc2Mge1xuICAgIG92ZXJmbG93OiBoaWRkZW47XG4gICAgdGV4dC1vdmVyZmxvdzogZWxsaXBzaXM7XG4gICAgZGlzcGxheTogLXdlYmtpdC1ib3g7XG4gICAgLXdlYmtpdC1saW5lLWNsYW1wOiAyO1xuICAgIC13ZWJraXQtYm94LW9yaWVudDogdmVydGljYWw7XG4gICAgbWFyZ2luOiAycHg7XG4gIH1cbiAgaW9uLWljb24ge1xuICAgIGRpc3BsYXk6IGlubGluZS1ibG9jaztcbiAgICB2ZXJ0aWNhbC1hbGlnbjogbWlkZGxlO1xuICB9XG4gIC5jb250YWluZXItY2hhbGxlbmdlcyB7XG4gICAgbWFyZ2luLXRvcDogMnB4O1xuICAgIGRpc3BsYXk6IGZsZXg7XG4gICAgZmxleC1kaXJlY3Rpb246IHJvdy1yZXZlcnNlO1xuXG4gICAgLmxpbmUge1xuICAgICAgZGlzcGxheTogaW5saW5lLWJsb2NrO1xuICAgIH1cbiAgICAuZmlyc3QtbGluZSB7XG4gICAgICBoZWlnaHQ6IDIycHg7XG4gICAgICB3aWR0aDogMnB4O1xuICAgICAgbWFyZ2luLWxlZnQ6IDZweDtcbiAgICB9XG4gICAgLnNlY29uZC1saW5lIHtcbiAgICAgIGhlaWdodDogMjJweDtcbiAgICAgIHdpZHRoOiA0cHg7XG4gICAgICBtYXJnaW4tbGVmdDogNnB4O1xuICAgIH1cbiAgICAudGhpcmQtbGluZSB7XG4gICAgICBoZWlnaHQ6IDIycHg7XG4gICAgICB3aWR0aDogOHB4O1xuICAgICAgbWFyZ2luLWxlZnQ6IDZweDtcbiAgICB9XG4gICAgLmFsbC1jaGFsbGVuZ2VzIHtcbiAgICAgIHdpZHRoOiBmaXQtY29udGVudDtcbiAgICAgIHBhZGRpbmc6IDJweCA0cHg7XG4gICAgICBoZWlnaHQ6IDIycHg7XG4gICAgICBtYXJnaW4tbGVmdDogNnB4O1xuICAgICAgc3BhbiB7XG4gICAgICAgIGZvbnQtc3R5bGU6IGl0YWxpYztcbiAgICAgIH1cbiAgICB9XG4gIH1cbn1cbiJdLCJzb3VyY2VSb290IjoiIn0= */"]
  }));
}
_staticBlock();

/***/ }),

/***/ 37026:
/*!****************************************************************************!*\
  !*** ./src/app/pages/home/profile/privacy-modal/privacyModal.component.ts ***!
  \****************************************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   PrivacyModalPage: () => (/* binding */ PrivacyModalPage)
/* harmony export */ });
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! @angular/core */ 12481);
/* harmony import */ var _ionic_angular__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @ionic/angular */ 21507);
/* harmony import */ var _core_shared_layout_content_content_directive__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! ../../../../core/shared/layout/content/content.directive */ 75855);
/* harmony import */ var _ngx_translate_core__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @ngx-translate/core */ 48503);
var _staticBlock;




class PrivacyModalPage {
  constructor(modalController) {
    this.modalController = modalController;
  }
  ngOnInit() {}
  close() {
    this.modalController.dismiss();
  }
  static #_ = _staticBlock = () => (this.ɵfac = function PrivacyModalPage_Factory(__ngFactoryType__) {
    return new (__ngFactoryType__ || PrivacyModalPage)(_angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵdirectiveInject"](_ionic_angular__WEBPACK_IMPORTED_MODULE_1__.ModalController));
  }, this.ɵcmp = /*@__PURE__*/_angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵdefineComponent"]({
    type: PrivacyModalPage,
    selectors: [["app-privacy-modal"]],
    standalone: false,
    decls: 9,
    vars: 3,
    consts: [["color", "playgo"], ["slot", "end"], [3, "click"], ["appContent", "", "color", "playgo"]],
    template: function PrivacyModalPage_Template(rf, ctx) {
      if (rf & 1) {
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](0, "ion-header")(1, "ion-toolbar", 0)(2, "ion-title");
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵtext"](3);
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵpipe"](4, "translate");
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](5, "ion-buttons", 1)(6, "ion-button", 2);
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵlistener"]("click", function PrivacyModalPage_Template_ion_button_click_6_listener() {
          return ctx.close();
        });
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵtext"](7, "Close");
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]()()()();
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelement"](8, "ion-content", 3);
      }
      if (rf & 2) {
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵadvance"](3);
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵtextInterpolate"](_angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵpipeBind1"](4, 1, "profile.privacy.modalTitle"));
      }
    },
    dependencies: [_ionic_angular__WEBPACK_IMPORTED_MODULE_1__.IonButton, _ionic_angular__WEBPACK_IMPORTED_MODULE_1__.IonButtons, _ionic_angular__WEBPACK_IMPORTED_MODULE_1__.IonContent, _ionic_angular__WEBPACK_IMPORTED_MODULE_1__.IonHeader, _ionic_angular__WEBPACK_IMPORTED_MODULE_1__.IonTitle, _ionic_angular__WEBPACK_IMPORTED_MODULE_1__.IonToolbar, _core_shared_layout_content_content_directive__WEBPACK_IMPORTED_MODULE_2__.ContentDirective, _ngx_translate_core__WEBPACK_IMPORTED_MODULE_3__.TranslatePipe],
    styles: ["/*# sourceMappingURL=data:application/json;charset=utf-8;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbXSwibmFtZXMiOltdLCJtYXBwaW5ncyI6IiIsInNvdXJjZVJvb3QiOiIifQ== */"]
  }));
}
_staticBlock();

/***/ }),

/***/ 37572:
/*!******************************************************************************!*\
  !*** ./src/app/core/shared/detail-notification/detail-notification.modal.ts ***!
  \******************************************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   DetailNotificationModalPage: () => (/* binding */ DetailNotificationModalPage)
/* harmony export */ });
/* harmony import */ var _services_notifications_notifications_service__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ../services/notifications/notifications.service */ 16095);
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @angular/core */ 12481);
/* harmony import */ var _ionic_angular__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @ionic/angular */ 21507);
/* harmony import */ var _angular_common__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @angular/common */ 93683);
/* harmony import */ var _detail_notification_level_detail_notification_level_component__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! ./detail-notification-level/detail-notification-level.component */ 37814);
/* harmony import */ var _detail_notification_badge_detail_notification_badge_component__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! ./detail-notification-badge/detail-notification-badge.component */ 12498);
/* harmony import */ var _ngx_translate_core__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! @ngx-translate/core */ 48503);
var _staticBlock;







function DetailNotificationModalPage_div_2_Template(rf, ctx) {
  if (rf & 1) {
    _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵelementStart"](0, "div");
    _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵelement"](1, "app-detail-notification-level", 5);
    _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵelementEnd"]();
  }
  if (rf & 2) {
    const ctx_r0 = _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵnextContext"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵadvance"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵproperty"]("notification", ctx_r0.notification);
  }
}
function DetailNotificationModalPage_div_3_Template(rf, ctx) {
  if (rf & 1) {
    _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵelementStart"](0, "div");
    _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵelement"](1, "app-detail-notification-badge", 5);
    _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵelementEnd"]();
  }
  if (rf & 2) {
    const ctx_r0 = _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵnextContext"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵadvance"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵproperty"]("notification", ctx_r0.notification);
  }
}
function DetailNotificationModalPage_div_4_Template(rf, ctx) {
  if (rf & 1) {
    _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵelement"](0, "div", 6);
  }
  if (rf & 2) {
    const ctx_r0 = _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵnextContext"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵproperty"]("innerHTML", ctx_r0.notification == null ? null : ctx_r0.notification.description, _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵsanitizeHtml"]);
  }
}
class DetailNotificationModalPage {
  constructor(modalController) {
    this.modalController = modalController;
    this.notificationType = _services_notifications_notifications_service__WEBPACK_IMPORTED_MODULE_0__.NotificationType;
  }
  ngOnInit() {}
  close() {
    this.modalController.dismiss(false);
  }
  static #_ = _staticBlock = () => (this.ɵfac = function DetailNotificationModalPage_Factory(__ngFactoryType__) {
    return new (__ngFactoryType__ || DetailNotificationModalPage)(_angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵdirectiveInject"](_ionic_angular__WEBPACK_IMPORTED_MODULE_2__.ModalController));
  }, this.ɵcmp = /*@__PURE__*/_angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵdefineComponent"]({
    type: DetailNotificationModalPage,
    selectors: [["app-detail-notification-modal"]],
    standalone: false,
    decls: 9,
    vars: 8,
    consts: [[3, "color"], [3, "ngSwitch"], [4, "ngSwitchCase"], [3, "innerHTML", 4, "ngSwitchDefault"], ["expand", "block", 3, "click", "color"], [3, "notification"], [3, "innerHTML"]],
    template: function DetailNotificationModalPage_Template(rf, ctx) {
      if (rf & 1) {
        _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵelementStart"](0, "ion-content", 0)(1, "div", 1);
        _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵtemplate"](2, DetailNotificationModalPage_div_2_Template, 2, 1, "div", 2)(3, DetailNotificationModalPage_div_3_Template, 2, 1, "div", 2)(4, DetailNotificationModalPage_div_4_Template, 1, 1, "div", 3);
        _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵelementStart"](5, "div")(6, "ion-button", 4);
        _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵlistener"]("click", function DetailNotificationModalPage_Template_ion_button_click_6_listener() {
          return ctx.close();
        });
        _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵtext"](7);
        _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵpipe"](8, "translate");
        _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵelementEnd"]()()();
      }
      if (rf & 2) {
        _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵproperty"]("color", ctx.campaign == null ? null : ctx.campaign.campaign == null ? null : ctx.campaign.campaign.type);
        _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵadvance"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵproperty"]("ngSwitch", ctx.notification == null ? null : ctx.notification.content == null ? null : ctx.notification.content.type);
        _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵadvance"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵproperty"]("ngSwitchCase", ctx.notificationType.level);
        _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵadvance"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵproperty"]("ngSwitchCase", ctx.notificationType.badge);
        _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵadvance"](3);
        _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵproperty"]("color", (ctx.campaign == null ? null : ctx.campaign.campaign == null ? null : ctx.campaign.campaign.type) + "-light");
        _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵadvance"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵtextInterpolate"](_angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵpipeBind1"](8, 6, "modal.ok"));
      }
    },
    dependencies: [_angular_common__WEBPACK_IMPORTED_MODULE_3__.NgSwitch, _angular_common__WEBPACK_IMPORTED_MODULE_3__.NgSwitchCase, _angular_common__WEBPACK_IMPORTED_MODULE_3__.NgSwitchDefault, _ionic_angular__WEBPACK_IMPORTED_MODULE_2__.IonButton, _ionic_angular__WEBPACK_IMPORTED_MODULE_2__.IonContent, _detail_notification_level_detail_notification_level_component__WEBPACK_IMPORTED_MODULE_4__.DetailNotificationLevelComponent, _detail_notification_badge_detail_notification_badge_component__WEBPACK_IMPORTED_MODULE_5__.DetailNotificationBadgeComponent, _ngx_translate_core__WEBPACK_IMPORTED_MODULE_6__.TranslatePipe],
    styles: ["ion-button[_ngcontent-%COMP%] {\n  position: absolute;\n  width: 100%;\n  bottom: 8px;\n}\n/*# sourceMappingURL=data:application/json;charset=utf-8;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbIndlYnBhY2s6Ly8uL3NyYy9hcHAvY29yZS9zaGFyZWQvZGV0YWlsLW5vdGlmaWNhdGlvbi9kZXRhaWwtbm90aWZpY2F0aW9uLm1vZGFsLnNjc3MiXSwibmFtZXMiOltdLCJtYXBwaW5ncyI6IkFBQUE7RUFDRSxrQkFBQTtFQUNBLFdBQUE7RUFDQSxXQUFBO0FBQ0YiLCJzb3VyY2VzQ29udGVudCI6WyJpb24tYnV0dG9uIHtcbiAgcG9zaXRpb246IGFic29sdXRlO1xuICB3aWR0aDogMTAwJTtcbiAgYm90dG9tOiA4cHg7XG59XG4iXSwic291cmNlUm9vdCI6IiJ9 */"]
  }));
}
_staticBlock();

/***/ }),

/***/ 37814:
/*!******************************************************************************************************************!*\
  !*** ./src/app/core/shared/detail-notification/detail-notification-level/detail-notification-level.component.ts ***!
  \******************************************************************************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   DetailNotificationLevelComponent: () => (/* binding */ DetailNotificationLevelComponent)
/* harmony export */ });
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! @angular/core */ 12481);
/* harmony import */ var _ionic_angular__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @ionic/angular */ 21507);
/* harmony import */ var _ui_icon_icon_component__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! ../../ui/icon/icon.component */ 59621);
/* harmony import */ var _angular_common__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @angular/common */ 93683);
/* harmony import */ var _ngx_translate_core__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! @ngx-translate/core */ 48503);
var _staticBlock;





class DetailNotificationLevelComponent {
  constructor() {}
  ngOnInit() {}
  static #_ = _staticBlock = () => (this.ɵfac = function DetailNotificationLevelComponent_Factory(__ngFactoryType__) {
    return new (__ngFactoryType__ || DetailNotificationLevelComponent)();
  }, this.ɵcmp = /*@__PURE__*/_angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵdefineComponent"]({
    type: DetailNotificationLevelComponent,
    selectors: [["app-detail-notification-level"]],
    inputs: {
      notification: "notification"
    },
    standalone: false,
    decls: 14,
    vars: 6,
    consts: [[1, "ion-text-center"], ["name", "level_up", 1, "icon-size-superbig"], [1, "ion-padding"]],
    template: function DetailNotificationLevelComponent_Template(rf, ctx) {
      if (rf & 1) {
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](0, "ion-grid")(1, "ion-row")(2, "ion-col", 0);
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelement"](3, "app-icon", 1);
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]()();
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](4, "ion-row")(5, "ion-col", 0)(6, "p")(7, "b");
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵtext"](8);
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵpipe"](9, "translate");
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵpipe"](10, "uppercase");
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]()()()();
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](11, "ion-row")(12, "p", 2);
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵtext"](13);
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]()()();
      }
      if (rf & 2) {
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵadvance"](8);
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵtextInterpolate"](_angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵpipeBind1"](10, 4, _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵpipeBind1"](9, 2, "modal.levelup")));
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵadvance"](5);
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵtextInterpolate1"](" ", ctx.notification.description, " ");
      }
    },
    dependencies: [_ionic_angular__WEBPACK_IMPORTED_MODULE_1__.IonCol, _ionic_angular__WEBPACK_IMPORTED_MODULE_1__.IonGrid, _ionic_angular__WEBPACK_IMPORTED_MODULE_1__.IonRow, _ui_icon_icon_component__WEBPACK_IMPORTED_MODULE_2__.IconComponent, _angular_common__WEBPACK_IMPORTED_MODULE_3__.UpperCasePipe, _ngx_translate_core__WEBPACK_IMPORTED_MODULE_4__.TranslatePipe],
    styles: ["/*# sourceMappingURL=data:application/json;charset=utf-8;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbXSwibmFtZXMiOltdLCJtYXBwaW5ncyI6IiIsInNvdXJjZVJvb3QiOiIifQ== */"]
  }));
}
_staticBlock();

/***/ }),

/***/ 38325:
/*!***********************************************************************!*\
  !*** ./src/app/core/shared/layout/header/header-content.component.ts ***!
  \***********************************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   HeaderContentComponent: () => (/* binding */ HeaderContentComponent)
/* harmony export */ });
/* harmony import */ var _Users_smartcommunitylab_Desktop_newWork_playAndGo_playGo_node_modules_babel_runtime_helpers_esm_asyncToGenerator_js__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./node_modules/@babel/runtime/helpers/esm/asyncToGenerator.js */ 89204);
/* harmony import */ var _ionic_angular__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @ionic/angular */ 21507);
/* harmony import */ var rxjs__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! rxjs */ 56196);
/* harmony import */ var rxjs__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! rxjs */ 98764);
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! @angular/core */ 34205);
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! @angular/core */ 12481);
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! @angular/core */ 37580);
/* harmony import */ var _ionic_angular__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(/*! @ionic/angular */ 4059);
/* harmony import */ var _services_app_status_service__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(/*! ../../services/app-status.service */ 65800);
/* harmony import */ var _angular_router__WEBPACK_IMPORTED_MODULE_9__ = __webpack_require__(/*! @angular/router */ 85422);
/* harmony import */ var _services_notifications_notifications_service__WEBPACK_IMPORTED_MODULE_10__ = __webpack_require__(/*! ../../services/notifications/notifications.service */ 16095);
/* harmony import */ var _services_page_settings_service__WEBPACK_IMPORTED_MODULE_11__ = __webpack_require__(/*! ../../services/page-settings.service */ 40147);
/* harmony import */ var _angular_common__WEBPACK_IMPORTED_MODULE_12__ = __webpack_require__(/*! @angular/common */ 93683);
/* harmony import */ var _ui_icon_icon_component__WEBPACK_IMPORTED_MODULE_13__ = __webpack_require__(/*! ../../ui/icon/icon.component */ 59621);
/* harmony import */ var _ngx_translate_core__WEBPACK_IMPORTED_MODULE_14__ = __webpack_require__(/*! @ngx-translate/core */ 48503);

var _staticBlock;











function HeaderContentComponent_ng_container_0_ion_buttons_2_Template(rf, ctx) {
  if (rf & 1) {
    _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵelementStart"](0, "ion-buttons", 5);
    _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵelement"](1, "ion-back-button", 6);
    _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵelementEnd"]();
  }
  if (rf & 2) {
    const settings_r1 = _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵnextContext"]().ngIf;
    _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵadvance"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵproperty"]("defaultHref", settings_r1.defaultHref);
  }
}
function HeaderContentComponent_ng_container_0_div_4_Template(rf, ctx) {
  if (rf & 1) {
    _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵelementStart"](0, "div");
    _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵtext"](1);
    _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵpipe"](2, "translate");
    _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵelementEnd"]();
  }
  if (rf & 2) {
    const settings_r1 = _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵnextContext"]().ngIf;
    _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵadvance"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵtextInterpolate"](_angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵpipeBind1"](2, 1, settings_r1.title));
  }
}
function HeaderContentComponent_ng_container_0_ion_buttons_5_ion_badge_3_Template(rf, ctx) {
  if (rf & 1) {
    _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵelementStart"](0, "ion-badge", 11);
    _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵtext"](1);
    _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵelementEnd"]();
  }
  if (rf & 2) {
    const ctx_r2 = _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵnextContext"](3);
    _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵadvance"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵtextInterpolate"](ctx_r2.numberOfNotification);
  }
}
function HeaderContentComponent_ng_container_0_ion_buttons_5_Template(rf, ctx) {
  if (rf & 1) {
    const _r2 = _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵgetCurrentView"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵelementStart"](0, "ion-buttons", 7)(1, "ion-button", 8);
    _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵlistener"]("click", function HeaderContentComponent_ng_container_0_ion_buttons_5_Template_ion_button_click_1_listener() {
      _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵrestoreView"](_r2);
      const ctx_r2 = _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵnextContext"](2);
      return _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵresetView"](ctx_r2.navigateToNotification());
    });
    _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵelement"](2, "ion-icon", 9);
    _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵtemplate"](3, HeaderContentComponent_ng_container_0_ion_buttons_5_ion_badge_3_Template, 2, 1, "ion-badge", 10);
    _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵelementEnd"]()();
  }
  if (rf & 2) {
    const ctx_r2 = _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵnextContext"](2);
    _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵadvance"](3);
    _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵproperty"]("ngIf", ctx_r2.numberOfNotification > 0);
  }
}
function HeaderContentComponent_ng_container_0_ion_toolbar_6_Template(rf, ctx) {
  if (rf & 1) {
    _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵelementStart"](0, "ion-toolbar", 12)(1, "ion-grid")(2, "ion-row", 13)(3, "ion-col", 14);
    _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵelement"](4, "app-icon", 15);
    _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵelementEnd"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵelementStart"](5, "ion-col", 16)(6, "b");
    _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵtext"](7);
    _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵpipe"](8, "translate");
    _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵelementEnd"]()();
    _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵelementStart"](9, "ion-col", 17);
    _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵtext"](10);
    _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵpipe"](11, "translate");
    _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵelementEnd"]()()()();
  }
  if (rf & 2) {
    _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵadvance"](7);
    _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵtextInterpolate"](_angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵpipeBind1"](8, 2, "offline.title"));
    _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵadvance"](3);
    _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵtextInterpolate1"](" ", _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵpipeBind1"](11, 4, "offline.header"), " ");
  }
}
function HeaderContentComponent_ng_container_0_Template(rf, ctx) {
  if (rf & 1) {
    _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵelementContainerStart"](0);
    _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵelementStart"](1, "ion-toolbar", 1);
    _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵtemplate"](2, HeaderContentComponent_ng_container_0_ion_buttons_2_Template, 2, 1, "ion-buttons", 2);
    _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵelementStart"](3, "ion-title");
    _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵtemplate"](4, HeaderContentComponent_ng_container_0_div_4_Template, 3, 3, "div", 0);
    _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵelementEnd"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵtemplate"](5, HeaderContentComponent_ng_container_0_ion_buttons_5_Template, 4, 1, "ion-buttons", 3);
    _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵelementEnd"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵtemplate"](6, HeaderContentComponent_ng_container_0_ion_toolbar_6_Template, 12, 6, "ion-toolbar", 4);
    _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵpipe"](7, "async");
    _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵelementContainerEnd"]();
  }
  if (rf & 2) {
    const settings_r1 = ctx.ngIf;
    const ctx_r2 = _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵnextContext"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵadvance"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵproperty"]("color", settings_r1.color);
    _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵadvance"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵproperty"]("ngIf", settings_r1.backButton);
    _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵadvance"](2);
    _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵproperty"]("ngIf", settings_r1.title);
    _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵadvance"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵproperty"]("ngIf", settings_r1.showNotifications);
    _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵadvance"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵproperty"]("ngIf", _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵpipeBind1"](7, 5, ctx_r2.isOnline$) === false);
  }
}
class HeaderContentComponent {
  constructor(navCtrl, appStatusService, router, cdRef, notificationService, pageSettingsService) {
    this.navCtrl = navCtrl;
    this.appStatusService = appStatusService;
    this.router = router;
    this.cdRef = cdRef;
    this.notificationService = notificationService;
    this.pageSettingsService = pageSettingsService;
    this.isOnline$ = this.appStatusService.isOnline$;
    this.numberOfNotification = 0;
    this.unreadNotification$ = this.notificationService.unreadAnnouncementNotifications$.pipe((0,rxjs__WEBPACK_IMPORTED_MODULE_3__.tap)(notifications => {
      this.numberOfNotification = notifications.length;
      this.cdRef.detectChanges();
    }));
  }
  ngOnDestroy() {
    this.subunread.unsubscribe();
  }
  ngOnInit() {
    var _this = this;
    return (0,_Users_smartcommunitylab_Desktop_newWork_playAndGo_playGo_node_modules_babel_runtime_helpers_esm_asyncToGenerator_js__WEBPACK_IMPORTED_MODULE_0__["default"])(function* () {
      _this.subunread = _this.unreadNotification$.subscribe();
    })();
  }
  navigateToNotification() {
    this.router.navigateByUrl('/pages/notifications');
  }
  getCurrentSettings() {
    var _this2 = this;
    return (0,_Users_smartcommunitylab_Desktop_newWork_playAndGo_playGo_node_modules_babel_runtime_helpers_esm_asyncToGenerator_js__WEBPACK_IMPORTED_MODULE_0__["default"])(function* () {
      return yield (0,rxjs__WEBPACK_IMPORTED_MODULE_2__.firstValueFrom)(_this2.pageSettingsService.pageSettings$);
    })();
  }
  static #_ = _staticBlock = () => (this.ɵfac = function HeaderContentComponent_Factory(__ngFactoryType__) {
    return new (__ngFactoryType__ || HeaderContentComponent)(_angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵdirectiveInject"](_ionic_angular__WEBPACK_IMPORTED_MODULE_7__.NavController), _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵdirectiveInject"](_services_app_status_service__WEBPACK_IMPORTED_MODULE_8__.AppStatusService), _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵdirectiveInject"](_angular_router__WEBPACK_IMPORTED_MODULE_9__.Router), _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵdirectiveInject"](_angular_core__WEBPACK_IMPORTED_MODULE_6__.ChangeDetectorRef), _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵdirectiveInject"](_services_notifications_notifications_service__WEBPACK_IMPORTED_MODULE_10__.NotificationService), _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵdirectiveInject"](_services_page_settings_service__WEBPACK_IMPORTED_MODULE_11__.PageSettingsService));
  }, this.ɵcmp = /*@__PURE__*/_angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵdefineComponent"]({
    type: HeaderContentComponent,
    selectors: [["app-header-content"]],
    viewQuery: function HeaderContentComponent_Query(rf, ctx) {
      if (rf & 1) {
        _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵviewQuery"](_ionic_angular__WEBPACK_IMPORTED_MODULE_1__.IonTitle, 5);
        _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵviewQuery"](_ionic_angular__WEBPACK_IMPORTED_MODULE_1__.IonToolbar, 5);
        _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵviewQuery"](_ionic_angular__WEBPACK_IMPORTED_MODULE_1__.IonButtons, 5);
      }
      if (rf & 2) {
        let _t;
        _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵqueryRefresh"](_t = _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵloadQuery"]()) && (ctx.ionTitle = _t.first);
        _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵqueryRefresh"](_t = _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵloadQuery"]()) && (ctx.ionToolbar = _t.first);
        _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵqueryRefresh"](_t = _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵloadQuery"]()) && (ctx.ionButtons = _t);
      }
    },
    standalone: false,
    decls: 2,
    vars: 3,
    consts: [[4, "ngIf"], [3, "color"], ["slot", "start", 4, "ngIf"], ["slot", "secondary", 4, "ngIf"], ["color", "warning", 4, "ngIf"], ["slot", "start"], ["text", "", 3, "defaultHref"], ["slot", "secondary"], ["id", "notificationButton", 3, "click"], ["name", "notifications"], ["id", "notifications-badge", "color", "danger", 4, "ngIf"], ["id", "notifications-badge", "color", "danger"], ["color", "warning"], [1, "ion-align-items-center"], ["size", "2"], ["name", "offline", 2, "font-size", "200%"], ["size", "3", 1, "ion-text-uppercase"], ["size", "7"]],
    template: function HeaderContentComponent_Template(rf, ctx) {
      if (rf & 1) {
        _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵtemplate"](0, HeaderContentComponent_ng_container_0_Template, 8, 7, "ng-container", 0);
        _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵpipe"](1, "async");
      }
      if (rf & 2) {
        _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵproperty"]("ngIf", _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵpipeBind1"](1, 1, ctx.pageSettingsService.pageSettings$));
      }
    },
    dependencies: [_angular_common__WEBPACK_IMPORTED_MODULE_12__.NgIf, _ionic_angular__WEBPACK_IMPORTED_MODULE_1__.IonBadge, _ionic_angular__WEBPACK_IMPORTED_MODULE_1__.IonButton, _ionic_angular__WEBPACK_IMPORTED_MODULE_1__.IonButtons, _ionic_angular__WEBPACK_IMPORTED_MODULE_1__.IonCol, _ionic_angular__WEBPACK_IMPORTED_MODULE_1__.IonGrid, _ionic_angular__WEBPACK_IMPORTED_MODULE_1__.IonIcon, _ionic_angular__WEBPACK_IMPORTED_MODULE_1__.IonRow, _ionic_angular__WEBPACK_IMPORTED_MODULE_1__.IonTitle, _ionic_angular__WEBPACK_IMPORTED_MODULE_1__.IonToolbar, _ionic_angular__WEBPACK_IMPORTED_MODULE_1__.IonBackButton, _ui_icon_icon_component__WEBPACK_IMPORTED_MODULE_13__.IconComponent, _angular_common__WEBPACK_IMPORTED_MODULE_12__.AsyncPipe, _ngx_translate_core__WEBPACK_IMPORTED_MODULE_14__.TranslatePipe],
    styles: ["ion-badge[_ngcontent-%COMP%] {\n  position: absolute;\n  top: -1px;\n  right: -1px;\n  border-radius: 100%;\n  min-width: 20px;\n  min-height: 20px;\n}\n\n#notificationButton[_ngcontent-%COMP%] {\n  position: relative;\n  width: 42px;\n  top: 1px;\n  right: 1px;\n  overflow: visible !important;\n  font-size: 20px;\n}\n/*# sourceMappingURL=data:application/json;charset=utf-8;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbIndlYnBhY2s6Ly8uL3NyYy9hcHAvY29yZS9zaGFyZWQvbGF5b3V0L2hlYWRlci9oZWFkZXItY29udGVudC5jb21wb25lbnQuc2NzcyJdLCJuYW1lcyI6W10sIm1hcHBpbmdzIjoiQUFBQTtFQUNFLGtCQUFBO0VBQ0EsU0FBQTtFQUNBLFdBQUE7RUFDQSxtQkFBQTtFQUNBLGVBQUE7RUFDQSxnQkFBQTtBQUNGOztBQUVBO0VBQ0Usa0JBQUE7RUFDQSxXQUFBO0VBQ0EsUUFBQTtFQUNBLFVBQUE7RUFDQSw0QkFBQTtFQUNBLGVBQUE7QUFDRiIsInNvdXJjZXNDb250ZW50IjpbImlvbi1iYWRnZSB7XG4gIHBvc2l0aW9uOiBhYnNvbHV0ZTtcbiAgdG9wOiAtMXB4O1xuICByaWdodDogLTFweDtcbiAgYm9yZGVyLXJhZGl1czogMTAwJTtcbiAgbWluLXdpZHRoOiAyMHB4O1xuICBtaW4taGVpZ2h0OiAyMHB4O1xufVxuXG4jbm90aWZpY2F0aW9uQnV0dG9uIHtcbiAgcG9zaXRpb246IHJlbGF0aXZlO1xuICB3aWR0aDogNDJweDtcbiAgdG9wOiAxcHg7XG4gIHJpZ2h0OiAxcHg7XG4gIG92ZXJmbG93OiB2aXNpYmxlICFpbXBvcnRhbnQ7XG4gIGZvbnQtc2l6ZTogMjBweDtcbn1cbiJdLCJzb3VyY2VSb290IjoiIn0= */"],
    changeDetection: 0
  }));
}
_staticBlock();

/***/ }),

/***/ 40147:
/*!***************************************************************!*\
  !*** ./src/app/core/shared/services/page-settings.service.ts ***!
  \***************************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   PageSettingsService: () => (/* binding */ PageSettingsService)
/* harmony export */ });
/* harmony import */ var _angular_router__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! @angular/router */ 85422);
/* harmony import */ var rxjs__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! rxjs */ 10819);
/* harmony import */ var rxjs__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! rxjs */ 44665);
/* harmony import */ var rxjs__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! rxjs */ 63617);
/* harmony import */ var rxjs__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! rxjs */ 59452);
/* harmony import */ var rxjs__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! rxjs */ 91817);
/* harmony import */ var rxjs__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! rxjs */ 81292);
/* harmony import */ var rxjs__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(/*! rxjs */ 51567);
/* harmony import */ var rxjs__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(/*! rxjs */ 70271);
/* harmony import */ var rxjs__WEBPACK_IMPORTED_MODULE_9__ = __webpack_require__(/*! rxjs */ 32112);
/* harmony import */ var rxjs__WEBPACK_IMPORTED_MODULE_10__ = __webpack_require__(/*! rxjs */ 86301);
/* harmony import */ var rxjs__WEBPACK_IMPORTED_MODULE_11__ = __webpack_require__(/*! rxjs */ 36647);
/* harmony import */ var lodash_es__WEBPACK_IMPORTED_MODULE_12__ = __webpack_require__(/*! lodash-es */ 92434);
/* harmony import */ var _utils__WEBPACK_IMPORTED_MODULE_13__ = __webpack_require__(/*! ../utils */ 7497);
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_14__ = __webpack_require__(/*! @angular/core */ 34205);
/* harmony import */ var _angular_platform_browser__WEBPACK_IMPORTED_MODULE_15__ = __webpack_require__(/*! @angular/platform-browser */ 80436);
/* harmony import */ var _ngx_translate_core__WEBPACK_IMPORTED_MODULE_16__ = __webpack_require__(/*! @ngx-translate/core */ 48503);
var _staticBlock;








/**
 * Page settings
 *
 * Service to manage page settings.
 * Manages common behavior which is shared between all pages.
 * Mainly behavior of the header (but not only).
 *
 * In order to change behavior of the ion-header we use `appHeader` directive.
 * See `header.directive.ts`.
 *
 * For changes in ion-content component we use `appContent` directive, for example
 * used to create global refresher. See `content.directive.ts`.
 *
 * Settings are defined in the router configuration. Data should by added to 'data' property of
 * route containing final component property (not loadChildren).
 * It is possible also to override them in the component using `pageSettingsService.set()`.
 *
 * Merged settings are available as an observable `pageSettings$`.
 *
 * There could be some problems with ionic, because ionic sometimes do not do real
 * router navigation but instead just show/hide page by css. Unfortunately, I was
 * not able to detect such changes. There are methods ionViewWillEnter and ionViewWillLeave
 * but they are on the level of the component, not the router / global events.
 */
class PageSettingsService {
  constructor(router, activatedRoute, titleService, translateService) {
    this.router = router;
    this.activatedRoute = activatedRoute;
    this.titleService = titleService;
    this.translateService = translateService;
    this.defaultPageSettings = {
      title: '',
      backButton: true,
      color: 'playgo',
      defaultHref: '/',
      isOfflinePage: false,
      customHeader: false,
      showNotifications: false,
      showPlayButton: true,
      refresher: false
    };
    this.routerPageSettings$ = (0,rxjs__WEBPACK_IMPORTED_MODULE_3__.merge)(this.router.events.pipe((0,rxjs__WEBPACK_IMPORTED_MODULE_7__.filter)((0,_utils__WEBPACK_IMPORTED_MODULE_13__.isInstanceOf)(_angular_router__WEBPACK_IMPORTED_MODULE_0__.RoutesRecognized)), (0,rxjs__WEBPACK_IMPORTED_MODULE_8__.map)(event => ({
      id: event.id,
      settings: getRouterDataFromActivatedRouteSnapshot(event.state.root)
    }))), this.router.events.pipe((0,rxjs__WEBPACK_IMPORTED_MODULE_7__.filter)((0,_utils__WEBPACK_IMPORTED_MODULE_13__.isInstanceOf)(_angular_router__WEBPACK_IMPORTED_MODULE_0__.NavigationEnd)), (0,rxjs__WEBPACK_IMPORTED_MODULE_8__.map)(event => ({
      id: event.id,
      settings: getRouterDataFromActivatedRoute(this.activatedRoute)
    })))).pipe((0,rxjs__WEBPACK_IMPORTED_MODULE_6__.distinctUntilKeyChanged)('id'), (0,rxjs__WEBPACK_IMPORTED_MODULE_8__.map)(({
      settings
    }) => settings));
    this.manualPageSettingsSubject = new rxjs__WEBPACK_IMPORTED_MODULE_1__.Subject();
    this.pageSettings$ = this.routerPageSettings$.pipe(
    // for every page we start from scratch
    (0,rxjs__WEBPACK_IMPORTED_MODULE_11__.switchMap)(routerPageSettings => (0,rxjs__WEBPACK_IMPORTED_MODULE_2__.concat)((0,rxjs__WEBPACK_IMPORTED_MODULE_4__.of)({}), this.manualPageSettingsSubject).pipe(
    // apply all manual overrides for the current page
    (0,rxjs__WEBPACK_IMPORTED_MODULE_9__.scan)((settings, manualPageSettings) => ({
      ...settings,
      ...manualPageSettings
    }), routerPageSettings),
    // set defaults
    (0,rxjs__WEBPACK_IMPORTED_MODULE_8__.map)(settings => ({
      ...this.defaultPageSettings,
      ...settings
    })), (0,rxjs__WEBPACK_IMPORTED_MODULE_5__.distinctUntilChanged)(lodash_es__WEBPACK_IMPORTED_MODULE_12__["default"]))), (0,rxjs__WEBPACK_IMPORTED_MODULE_10__.shareReplay)());
    this.translatedTitle$ = this.pageSettings$.pipe((0,rxjs__WEBPACK_IMPORTED_MODULE_8__.map)(settings => settings.title || 'home'), (0,rxjs__WEBPACK_IMPORTED_MODULE_11__.switchMap)(title => this.translateService.stream(title)));
    this.translatedTitle$.subscribe(title => {
      this.titleService.setTitle(title);
    });
  }
  set(pageSettings) {
    this.manualPageSettingsSubject.next(pageSettings);
  }
  static #_ = _staticBlock = () => (this.ɵfac = function PageSettingsService_Factory(__ngFactoryType__) {
    return new (__ngFactoryType__ || PageSettingsService)(_angular_core__WEBPACK_IMPORTED_MODULE_14__["ɵɵinject"](_angular_router__WEBPACK_IMPORTED_MODULE_0__.Router), _angular_core__WEBPACK_IMPORTED_MODULE_14__["ɵɵinject"](_angular_router__WEBPACK_IMPORTED_MODULE_0__.ActivatedRoute), _angular_core__WEBPACK_IMPORTED_MODULE_14__["ɵɵinject"](_angular_platform_browser__WEBPACK_IMPORTED_MODULE_15__.Title), _angular_core__WEBPACK_IMPORTED_MODULE_14__["ɵɵinject"](_ngx_translate_core__WEBPACK_IMPORTED_MODULE_16__.TranslateService));
  }, this.ɵprov = /*@__PURE__*/_angular_core__WEBPACK_IMPORTED_MODULE_14__["ɵɵdefineInjectable"]({
    token: PageSettingsService,
    factory: PageSettingsService.ɵfac,
    providedIn: 'root'
  }));
}
_staticBlock();
function getRouterDataFromActivatedRouteSnapshot(activatedRouteSnapshot) {
  let child = activatedRouteSnapshot.firstChild;
  while (child) {
    if (child.firstChild) {
      child = child.firstChild;
    } else if (child.data) {
      return child.data;
    } else {
      return {};
    }
  }
  return {};
}
function getRouterDataFromActivatedRoute(activatedRoute) {
  let child = activatedRoute.firstChild;
  while (child) {
    if (child.firstChild) {
      child = child.firstChild;
    } else if (child.snapshot.data) {
      return child.snapshot.data;
    } else {
      return {};
    }
  }
  return {};
}

/***/ }),

/***/ 40459:
/*!************************************************************************************!*\
  !*** ./src/app/core/api/generated-hsc/controllers/playerTeamController.service.ts ***!
  \************************************************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   PlayerTeamControllerService: () => (/* binding */ PlayerTeamControllerService)
/* harmony export */ });
/* harmony import */ var src_environments_environment__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! src/environments/environment */ 45312);
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @angular/core */ 34205);
/* harmony import */ var _angular_common_http__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @angular/common/http */ 63855);
var _staticBlock;
/**
 * Play&Go HSC Project
 * No description provided (generated by Swagger Codegen https://github.com/swagger-api/swagger-codegen)
 *
 * OpenAPI spec version: 2.0
 * Contact: info@smartcommunitylab.it
 *
 * NOTE: This class is auto generated by the swagger code generator program.
 * https://github.com/swagger-api/swagger-codegen.git
 * Do not edit the class manually.
 */



class PlayerTeamControllerService {
  constructor(http) {
    this.http = http;
  }
  /**
   * candidates
   *
   * @param initiativeId initiativeId
   * @param page Results page you want to retrieve (0..N)
   * @param size Number of records per page
   * @param sort Sorting option: field,[asc,desc]
   * @param txt txt
   */
  candidatesUsingGET(args) {
    const {
      initiativeId,
      page,
      size,
      sort,
      txt
    } = args;
    return this.http.request('get', src_environments_environment__WEBPACK_IMPORTED_MODULE_0__.environment.serverUrl.hscApi + `/playandgo-hsc/api/initiatives/${encodeURIComponent(String(initiativeId))}/team/candidates`, {
      params: removeNullOrUndefined({
        page,
        size,
        sort,
        txt
      })
    });
  }
  /**
   * checkSubscribeTeamMember
   *
   * @param initiativeId initiativeId
   * @param nickname nickname
   */
  checkSubscribeTeamMemberUsingGET(args) {
    const {
      initiativeId,
      nickname
    } = args;
    return this.http.request('get', src_environments_environment__WEBPACK_IMPORTED_MODULE_0__.environment.serverUrl.hscApi + `/playandgo-hsc/api/initiatives/${encodeURIComponent(String(initiativeId))}/player/subscribe/check`, {
      params: removeNullOrUndefined({
        nickname
      })
    });
  }
  /**
   * deleteTeam
   *
   * @param initiativeId initiativeId
   * @param teamId teamId
   */
  deleteTeamUsingDELETE(args) {
    const {
      initiativeId,
      teamId
    } = args;
    return this.http.request('delete', src_environments_environment__WEBPACK_IMPORTED_MODULE_0__.environment.serverUrl.hscApi + `/playandgo-hsc/api/initiatives/${encodeURIComponent(String(initiativeId))}/team/${encodeURIComponent(String(teamId))}`, {});
  }
  /**
   * getInitative
   *
   * @param initiativeId initiativeId
   */
  getInitativeUsingGET(initiativeId) {
    return this.http.request('get', src_environments_environment__WEBPACK_IMPORTED_MODULE_0__.environment.serverUrl.hscApi + `/playandgo-hsc/api/initiatives/${encodeURIComponent(String(initiativeId))}/model`, {});
  }
  /**
   * getMyTeamInfo
   *
   * @param initiativeId initiativeId
   * @param teamId teamId
   */
  getMyTeamInfoUsingGET(args) {
    const {
      initiativeId,
      teamId
    } = args;
    return this.http.request('get', src_environments_environment__WEBPACK_IMPORTED_MODULE_0__.environment.serverUrl.hscApi + `/playandgo-hsc/api/initiatives/${encodeURIComponent(String(initiativeId))}/team/${encodeURIComponent(String(teamId))}/my`, {});
  }
  /**
   * getMyTeamsAsManager
   *
   * @param initiativeId initiativeId
   */
  getMyTeamsAsManagerUsingGET(initiativeId) {
    return this.http.request('get', src_environments_environment__WEBPACK_IMPORTED_MODULE_0__.environment.serverUrl.hscApi + `/playandgo-hsc/api/initiatives/${encodeURIComponent(String(initiativeId))}/teams`, {});
  }
  /**
   * getPlayerTeamByOwner
   *
   */
  getPlayerTeamByOwnerUsingGET() {
    return this.http.request('get', src_environments_environment__WEBPACK_IMPORTED_MODULE_0__.environment.serverUrl.hscApi + `/playandgo-hsc/api/initiatives/team/owner`, {});
  }
  /**
   * getPlayerTeamInfo
   *
   * @param initiativeId initiativeId
   * @param teamId teamId
   */
  getPlayerTeamInfoUsingGET(args) {
    const {
      initiativeId,
      teamId
    } = args;
    return this.http.request('get', src_environments_environment__WEBPACK_IMPORTED_MODULE_0__.environment.serverUrl.hscApi + `/playandgo-hsc/api/initiatives/${encodeURIComponent(String(initiativeId))}/team/${encodeURIComponent(String(teamId))}/info`, {});
  }
  /**
   * getPublicTeamInfo
   *
   * @param initiativeId initiativeId
   * @param teamId teamId
   */
  getPublicTeamInfoUsingGET(args) {
    const {
      initiativeId,
      teamId
    } = args;
    return this.http.request('get', src_environments_environment__WEBPACK_IMPORTED_MODULE_0__.environment.serverUrl.hscApi + `/playandgo-hsc/api/initiatives/${encodeURIComponent(String(initiativeId))}/team/${encodeURIComponent(String(teamId))}/public`, {});
  }
  /**
   * getPublicTeamsInfo
   *
   * @param initiativeId initiativeId
   */
  getPublicTeamsInfoUsingGET(initiativeId) {
    return this.http.request('get', src_environments_environment__WEBPACK_IMPORTED_MODULE_0__.environment.serverUrl.hscApi + `/playandgo-hsc/api/initiatives/${encodeURIComponent(String(initiativeId))}/teams/public`, {});
  }
  /**
   * getTeamAvatar
   *
   * @param teamId teamId
   */
  getTeamAvatarUsingGET(teamId) {
    return this.http.request('get', src_environments_environment__WEBPACK_IMPORTED_MODULE_0__.environment.serverUrl.hscApi + `/playandgo-hsc/api/team/${encodeURIComponent(String(teamId))}/avatar`, {});
  }
  /**
   * getTeamLeaderInitiatives
   *
   */
  getTeamLeaderInitiativesUsingGET() {
    return this.http.request('get', src_environments_environment__WEBPACK_IMPORTED_MODULE_0__.environment.serverUrl.hscApi + `/playandgo-hsc/api/initiatives/teamleader`, {});
  }
  /**
   * initatives
   *
   */
  initativesUsingGET() {
    return this.http.request('get', src_environments_environment__WEBPACK_IMPORTED_MODULE_0__.environment.serverUrl.hscApi + `/playandgo-hsc/api/initiatives`, {});
  }
  /**
   * isAdmin
   *
   * @param initiativeId initiativeId
   */
  isAdminUsingGET(initiativeId) {
    return this.http.request('get', src_environments_environment__WEBPACK_IMPORTED_MODULE_0__.environment.serverUrl.hscApi + `/playandgo-hsc/api/initiatives/${encodeURIComponent(String(initiativeId))}/admin`, {});
  }
  /**
   * removePlayerFromTeam
   *
   * @param initiativeId initiativeId
   * @param teamId teamId
   * @param playerId playerId
   */
  removePlayerFromTeamUsingDELETE(args) {
    const {
      initiativeId,
      teamId,
      playerId
    } = args;
    return this.http.request('delete', src_environments_environment__WEBPACK_IMPORTED_MODULE_0__.environment.serverUrl.hscApi + `/playandgo-hsc/api/initiatives/team/player`, {
      params: removeNullOrUndefined({
        initiativeId,
        teamId,
        playerId
      })
    });
  }
  /**
   * saveInitiative
   *
   * @param initiativeId initiativeId
   * @param body
   */
  saveInitiativeUsingPUT(args) {
    const {
      initiativeId,
      body
    } = args;
    return this.http.request('put', src_environments_environment__WEBPACK_IMPORTED_MODULE_0__.environment.serverUrl.hscApi + `/playandgo-hsc/api/initiatives/${encodeURIComponent(String(initiativeId))}`, {
      body
    });
  }
  /**
   * saveTeam
   *
   * @param initiativeId initiativeId
   * @param body
   */
  saveTeamUsingPOST(args) {
    const {
      initiativeId,
      body
    } = args;
    return this.http.request('post', src_environments_environment__WEBPACK_IMPORTED_MODULE_0__.environment.serverUrl.hscApi + `/playandgo-hsc/api/initiatives/${encodeURIComponent(String(initiativeId))}/team`, {
      body
    });
  }
  /**
   * setCreate
   *
   * @param initiativeId initiativeId
   * @param value value
   */
  setCreateUsingPUT(args) {
    const {
      initiativeId,
      value
    } = args;
    return this.http.request('put', src_environments_environment__WEBPACK_IMPORTED_MODULE_0__.environment.serverUrl.hscApi + `/playandgo-hsc/api/initiatives/${encodeURIComponent(String(initiativeId))}/create/${encodeURIComponent(String(value))}`, {});
  }
  /**
   * setEdit
   *
   * @param initiativeId initiativeId
   * @param value value
   */
  setEditUsingPUT(args) {
    const {
      initiativeId,
      value
    } = args;
    return this.http.request('put', src_environments_environment__WEBPACK_IMPORTED_MODULE_0__.environment.serverUrl.hscApi + `/playandgo-hsc/api/initiatives/${encodeURIComponent(String(initiativeId))}/edit/${encodeURIComponent(String(value))}`, {});
  }
  /**
   * subscribeTeamMember
   *
   * @param initiativeId initiativeId
   * @param nickname nickname
   * @param teamId teamId
   */
  subscribeTeamMemberUsingPOST1(args) {
    const {
      initiativeId,
      nickname,
      teamId
    } = args;
    return this.http.request('post', src_environments_environment__WEBPACK_IMPORTED_MODULE_0__.environment.serverUrl.hscApi + `/playandgo-hsc/api/initiatives/${encodeURIComponent(String(initiativeId))}/player/subscribe`, {
      params: removeNullOrUndefined({
        nickname,
        teamId
      })
    });
  }
  /**
   * syncInitatives
   *
   */
  syncInitativesUsingPUT() {
    return this.http.request('put', src_environments_environment__WEBPACK_IMPORTED_MODULE_0__.environment.serverUrl.hscApi + `/playandgo-hsc/api/initiatives`, {});
  }
  /**
   * uploadTeamAvatar
   *
   * @param teamId teamId
   * @param body
   */
  uploadTeamAvatarUsingPOST(args) {
    const {
      teamId,
      body
    } = args;
    return this.http.request('post', src_environments_environment__WEBPACK_IMPORTED_MODULE_0__.environment.serverUrl.hscApi + `/playandgo-hsc/api/team/${encodeURIComponent(String(teamId))}/avatar`, {
      body
    });
  }
  static #_ = _staticBlock = () => (this.ɵfac = function PlayerTeamControllerService_Factory(__ngFactoryType__) {
    return new (__ngFactoryType__ || PlayerTeamControllerService)(_angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵinject"](_angular_common_http__WEBPACK_IMPORTED_MODULE_2__.HttpClient));
  }, this.ɵprov = /*@__PURE__*/_angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵdefineInjectable"]({
    token: PlayerTeamControllerService,
    factory: PlayerTeamControllerService.ɵfac,
    providedIn: 'root'
  }));
}
_staticBlock();
function removeNullOrUndefined(obj) {
  const newObj = {};
  Object.keys(obj).forEach(key => {
    if (obj[key] != null) {
      newObj[key] = obj[key];
    }
  });
  return newObj;
}

/***/ }),

/***/ 40508:
/*!**************************************************************************************!*\
  !*** ./src/app/core/shared/campaigns/my-campaign-card/my-campaign-card.component.ts ***!
  \**************************************************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   MyCampaignCardComponent: () => (/* binding */ MyCampaignCardComponent)
/* harmony export */ });
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! @angular/core */ 12481);
/* harmony import */ var _angular_router__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @angular/router */ 85422);
/* harmony import */ var _services_user_service__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! ../../services/user.service */ 89815);
/* harmony import */ var _ionic_angular__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @ionic/angular */ 21507);
/* harmony import */ var _main_campaign_stat_main_campaign_stat_component__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! ../main-campaign-stat/main-campaign-stat.component */ 79238);
/* harmony import */ var _ngx_translate_core__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! @ngx-translate/core */ 48503);
/* harmony import */ var _pipes_localDate_pipe__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! ../../pipes/localDate.pipe */ 86451);
/* harmony import */ var _pipes_languageMap_pipe__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(/*! ../../pipes/languageMap.pipe */ 69618);
var _staticBlock;








class MyCampaignCardComponent {
  constructor(router, userService) {
    this.router = router;
    this.userService = userService;
  }
  ngOnInit() {
    this.imagePath = this.containerCampaign.campaign.logo.url ? this.containerCampaign.campaign.logo.url : 'data:image/jpg;base64,' + this.containerCampaign.campaign.logo.image;
    this.bannerPath = this.containerCampaign?.campaign?.banner?.url ? this.containerCampaign?.campaign?.banner?.url : 'data:image/jpg;base64,' + this.containerCampaign?.campaign?.banner?.image;
  }
  detailCampaign() {
    this.router.navigateByUrl('/pages/tabs/home/details/' + this.containerCampaign.campaign.campaignId);
  }
  joinCamp() {
    console.log('joinCampaign');
  }
  challenges() {
    console.log('challenges');
  }
  static #_ = _staticBlock = () => (this.ɵfac = function MyCampaignCardComponent_Factory(__ngFactoryType__) {
    return new (__ngFactoryType__ || MyCampaignCardComponent)(_angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵdirectiveInject"](_angular_router__WEBPACK_IMPORTED_MODULE_1__.Router), _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵdirectiveInject"](_services_user_service__WEBPACK_IMPORTED_MODULE_2__.UserService));
  }, this.ɵcmp = /*@__PURE__*/_angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵdefineComponent"]({
    type: MyCampaignCardComponent,
    selectors: [["app-my-campaign-card"]],
    inputs: {
      containerCampaign: "containerCampaign"
    },
    standalone: false,
    decls: 22,
    vars: 15,
    consts: [[1, "ion-card", 3, "click"], [1, "header"], ["alt", "banner", 1, "banner", 3, "src"], ["lines", "none", 1, "header-title", 3, "color"], ["slot", "end", 2, "margin", "2px"], ["alt", "image", 3, "src"]],
    template: function MyCampaignCardComponent_Template(rf, ctx) {
      if (rf & 1) {
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](0, "div")(1, "ion-card", 0);
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵlistener"]("click", function MyCampaignCardComponent_Template_ion_card_click_1_listener() {
          return ctx.detailCampaign();
        });
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](2, "div", 1);
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelement"](3, "img", 2);
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](4, "ion-item", 3)(5, "ion-avatar", 4);
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelement"](6, "img", 5);
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](7, "ion-label")(8, "h3");
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵtext"](9);
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵpipe"](10, "languageMap");
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](11, "h4");
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵtext"](12);
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵpipe"](13, "translate");
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](14, "h4");
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵtext"](15);
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵpipe"](16, "localDate");
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵpipe"](17, "localDate");
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]()()()();
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](18, "ion-card-content")(19, "div");
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵtext"](20, " TODO ");
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelement"](21, "app-main-campaign-stat");
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]()()()();
      }
      if (rf & 2) {
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵadvance"](3);
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵproperty"]("src", ctx.bannerPath, _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵsanitizeUrl"]);
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵadvance"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵproperty"]("color", ctx.containerCampaign.campaign.type);
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵadvance"](2);
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵproperty"]("src", ctx.imagePath, _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵsanitizeUrl"]);
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵadvance"](3);
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵtextInterpolate"](_angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵpipeBind1"](10, 7, ctx.containerCampaign.campaign.name));
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵadvance"](3);
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵtextInterpolate"](_angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵpipeBind1"](13, 9, "campaigns.blabla"));
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵadvance"](3);
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵtextInterpolate2"](" ", _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵpipeBind1"](16, 11, ctx.containerCampaign.campaign.dateFrom), " - ", _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵpipeBind1"](17, 13, ctx.containerCampaign.campaign.dateTo), " ");
      }
    },
    dependencies: [_ionic_angular__WEBPACK_IMPORTED_MODULE_3__.IonAvatar, _ionic_angular__WEBPACK_IMPORTED_MODULE_3__.IonCard, _ionic_angular__WEBPACK_IMPORTED_MODULE_3__.IonCardContent, _ionic_angular__WEBPACK_IMPORTED_MODULE_3__.IonItem, _ionic_angular__WEBPACK_IMPORTED_MODULE_3__.IonLabel, _main_campaign_stat_main_campaign_stat_component__WEBPACK_IMPORTED_MODULE_4__.MainCampaignStatComponent, _ngx_translate_core__WEBPACK_IMPORTED_MODULE_5__.TranslatePipe, _pipes_localDate_pipe__WEBPACK_IMPORTED_MODULE_6__.LocalDatePipe, _pipes_languageMap_pipe__WEBPACK_IMPORTED_MODULE_7__.LanguageMapPipe],
    styles: [".progress-bar[_ngcontent-%COMP%] {\n  height: 24px;\n  width: var(--varwidth, 0%);\n  color: black;\n  background-color: rgb(8, 166, 240);\n  text-align: center;\n  border-top-left-radius: 10px;\n  border-bottom-left-radius: 10px;\n}\n\n.progress-bar-contourn[_ngcontent-%COMP%] {\n  border: 1px solid black;\n  border-color: black;\n  margin-left: 18px;\n  margin-right: 18px;\n  background-color: lightgrey;\n  border-radius: 10px;\n}\n\n.border-class[_ngcontent-%COMP%] {\n  border: 1px solid rgb(63, 63, 63);\n  margin-left: 18px;\n  margin-right: 18px;\n  margin-top: 10px;\n  margin-bottom: 10px;\n}\n\n.border-class-fancy[_ngcontent-%COMP%] {\n  border: 1px solid rgb(255, 255, 255);\n  margin-left: 18px;\n  margin-right: 18px;\n  margin-top: 10px;\n  margin-bottom: 10px;\n  border-radius: 4px;\n}\n\n.ion-card[_ngcontent-%COMP%] {\n  color: white;\n  background-color: rgba(0, 0, 0, 0.3);\n  border: 2px solid white;\n}\n\n.header[_ngcontent-%COMP%] {\n  position: relative;\n  opacity: 0.9;\n}\n.header[_ngcontent-%COMP%]   .banner[_ngcontent-%COMP%] {\n  max-height: 200px;\n  width: 100%;\n  object-fit: cover;\n  object-position: center;\n}\n.header[_ngcontent-%COMP%]   .header-title[_ngcontent-%COMP%] {\n  position: absolute;\n  top: 0px;\n  background: transparent;\n  width: 100%;\n  opacity: 0.85;\n}\n/*# sourceMappingURL=data:application/json;charset=utf-8;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbIndlYnBhY2s6Ly8uL3NyYy9hcHAvY29yZS9zaGFyZWQvY2FtcGFpZ25zL215LWNhbXBhaWduLWNhcmQvbXktY2FtcGFpZ24tY2FyZC5jb21wb25lbnQuc2NzcyJdLCJuYW1lcyI6W10sIm1hcHBpbmdzIjoiQUFBQTtFQUNFLFlBQUE7RUFDQSwwQkFBQTtFQUNBLFlBQUE7RUFDQSxrQ0FBQTtFQUNBLGtCQUFBO0VBQ0EsNEJBQUE7RUFDQSwrQkFBQTtBQUNGOztBQUVBO0VBQ0UsdUJBQUE7RUFDQSxtQkFBQTtFQUNBLGlCQUFBO0VBQ0Esa0JBQUE7RUFDQSwyQkFBQTtFQUNBLG1CQUFBO0FBQ0Y7O0FBRUE7RUFDRSxpQ0FBQTtFQUNBLGlCQUFBO0VBQ0Esa0JBQUE7RUFDQSxnQkFBQTtFQUNBLG1CQUFBO0FBQ0Y7O0FBRUE7RUFDRSxvQ0FBQTtFQUNBLGlCQUFBO0VBQ0Esa0JBQUE7RUFDQSxnQkFBQTtFQUNBLG1CQUFBO0VBQ0Esa0JBQUE7QUFDRjs7QUFFQTtFQUNFLFlBQUE7RUFDQSxvQ0FBQTtFQUNBLHVCQUFBO0FBQ0Y7O0FBQ0E7RUFDRSxrQkFBQTtFQUNBLFlBQUE7QUFFRjtBQURFO0VBQ0UsaUJBQUE7RUFDQSxXQUFBO0VBQ0EsaUJBQUE7RUFDQSx1QkFBQTtBQUdKO0FBREU7RUFDRSxrQkFBQTtFQUNBLFFBQUE7RUFDQSx1QkFBQTtFQUNBLFdBQUE7RUFDQSxhQUFBO0FBR0oiLCJzb3VyY2VzQ29udGVudCI6WyIucHJvZ3Jlc3MtYmFyIHtcbiAgaGVpZ2h0OiAyNHB4O1xuICB3aWR0aDogdmFyKC0tdmFyd2lkdGgsIDAlKTtcbiAgY29sb3I6IGJsYWNrO1xuICBiYWNrZ3JvdW5kLWNvbG9yOiByZ2IoOCwgMTY2LCAyNDApO1xuICB0ZXh0LWFsaWduOiBjZW50ZXI7XG4gIGJvcmRlci10b3AtbGVmdC1yYWRpdXM6IDEwcHg7XG4gIGJvcmRlci1ib3R0b20tbGVmdC1yYWRpdXM6IDEwcHg7XG59XG5cbi5wcm9ncmVzcy1iYXItY29udG91cm4ge1xuICBib3JkZXI6IDFweCBzb2xpZCBibGFjaztcbiAgYm9yZGVyLWNvbG9yOiBibGFjaztcbiAgbWFyZ2luLWxlZnQ6IDE4cHg7XG4gIG1hcmdpbi1yaWdodDogMThweDtcbiAgYmFja2dyb3VuZC1jb2xvcjogbGlnaHRncmV5O1xuICBib3JkZXItcmFkaXVzOiAxMHB4O1xufVxuXG4uYm9yZGVyLWNsYXNzIHtcbiAgYm9yZGVyOiAxcHggc29saWQgcmdiKDYzLCA2MywgNjMpO1xuICBtYXJnaW4tbGVmdDogMThweDtcbiAgbWFyZ2luLXJpZ2h0OiAxOHB4O1xuICBtYXJnaW4tdG9wOiAxMHB4O1xuICBtYXJnaW4tYm90dG9tOiAxMHB4O1xufVxuXG4uYm9yZGVyLWNsYXNzLWZhbmN5IHtcbiAgYm9yZGVyOiAxcHggc29saWQgcmdiKDI1NSwgMjU1LCAyNTUpO1xuICBtYXJnaW4tbGVmdDogMThweDtcbiAgbWFyZ2luLXJpZ2h0OiAxOHB4O1xuICBtYXJnaW4tdG9wOiAxMHB4O1xuICBtYXJnaW4tYm90dG9tOiAxMHB4O1xuICBib3JkZXItcmFkaXVzOiA0cHg7XG59XG5cbi5pb24tY2FyZCB7XG4gIGNvbG9yOiB3aGl0ZTtcbiAgYmFja2dyb3VuZC1jb2xvcjogcmdiYSgwLCAwLCAwLCAwLjMpO1xuICBib3JkZXI6IDJweCBzb2xpZCB3aGl0ZTtcbn1cbi5oZWFkZXIge1xuICBwb3NpdGlvbjogcmVsYXRpdmU7XG4gIG9wYWNpdHk6IDAuOTtcbiAgLmJhbm5lciB7XG4gICAgbWF4LWhlaWdodDogMjAwcHg7XG4gICAgd2lkdGg6IDEwMCU7XG4gICAgb2JqZWN0LWZpdDogY292ZXI7XG4gICAgb2JqZWN0LXBvc2l0aW9uOiBjZW50ZXI7XG4gIH1cbiAgLmhlYWRlci10aXRsZSB7XG4gICAgcG9zaXRpb246IGFic29sdXRlO1xuICAgIHRvcDogMHB4O1xuICAgIGJhY2tncm91bmQ6IHRyYW5zcGFyZW50O1xuICAgIHdpZHRoOiAxMDAlO1xuICAgIG9wYWNpdHk6IDAuODU7XG4gIH1cbn1cbiJdLCJzb3VyY2VSb290IjoiIn0= */"]
  }));
}
_staticBlock();

/***/ }),

/***/ 40610:
/*!********************************************************!*\
  !*** ./src/app/core/shared/services/report.service.ts ***!
  \********************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   ReportService: () => (/* binding */ ReportService)
/* harmony export */ });
/* harmony import */ var rxjs__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! rxjs */ 70271);
/* harmony import */ var rxjs__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! rxjs */ 86301);
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @angular/core */ 34205);
/* harmony import */ var _api_generated_controllers_reportController_service__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! ../../api/generated/controllers/reportController.service */ 32076);
/* harmony import */ var _api_generated_controllers_gameController_service__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! ../../api/generated/controllers/gameController.service */ 60436);
var _staticBlock;




class ReportService {
  constructor(reportControllerService, gameController) {
    this.reportControllerService = reportControllerService;
    this.gameController = gameController;
  }
  getCo2Stats(campaignId, playerId, dateFrom, dateTo) {
    return this.reportControllerService.getPlayerCampaingPlacingByTransportModeUsingGET({
      campaignId,
      playerId,
      metric: 'co2',
      mean: null,
      dateFrom,
      dateTo
    }).toPromise();
  }
  getCo2WeekRecord(campaignId, playerId) {
    return this.reportControllerService.getPlayerTransportRecordUsingGET({
      campaignId,
      playerId,
      metric: 'co2',
      mean: null,
      groupMode: 'week'
    }).toPromise();
  }
  getGameStatus(campaignId) {
    return this.gameController.getCampaignGameStatusUsingGET(campaignId).pipe((0,rxjs__WEBPACK_IMPORTED_MODULE_1__.shareReplay)(1));
  }
  getCurrentLevel(campaignId) {
    return this.gameController.getCampaignGameStatusUsingGET(campaignId).pipe((0,rxjs__WEBPACK_IMPORTED_MODULE_0__.map)(status => status?.levels?.length || 0), (0,rxjs__WEBPACK_IMPORTED_MODULE_1__.shareReplay)());
  }
  getGameStats(campaignId, playerId, dateFrom, dateTo) {
    return this.reportControllerService.getPlayerCampaingPlacingByGameUsingGET({
      campaignId,
      playerId,
      dateFrom,
      dateTo
    });
  }
  getBarStat(campaignId, playerId, dateFrom, dateTo, virtualScoreLabel) {
    return this.reportControllerService.getPlayerTransportStatsUsingGET({
      campaignId,
      playerId,
      metric: virtualScoreLabel,
      mean: null,
      dateFrom,
      dateTo
    }).pipe((0,rxjs__WEBPACK_IMPORTED_MODULE_0__.map)(stats => {
      return {
        value: stats[0] ? stats[0]?.value : 0
      };
    })).toPromise();
  }
  getBikeStats(campaignId, playerId, dateFrom, dateTo, virtualScoreLabel) {
    return this.reportControllerService.getPlayerTransportStatsUsingGET({
      campaignId,
      playerId,
      metric: virtualScoreLabel ? 'virtualScore' : 'km',
      mean: virtualScoreLabel ? null : 'bike',
      dateFrom,
      dateTo
    }).pipe((0,rxjs__WEBPACK_IMPORTED_MODULE_0__.map)(stats => {
      return {
        value: stats[0] ? stats[0]?.value : 0
      };
      // removed by dead control flow
{}
    })).toPromise();
  }
  getTransportStatsByMeans(campaignId, playerId, metric, groupMode, mean, dateFrom, dateTo) {
    return this.reportControllerService.getPlayerTransportStatsUsingGET({
      campaignId,
      playerId,
      metric,
      groupMode,
      mean,
      dateFrom,
      dateTo
    });
  }
  static #_ = _staticBlock = () => (this.ɵfac = function ReportService_Factory(__ngFactoryType__) {
    return new (__ngFactoryType__ || ReportService)(_angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵinject"](_api_generated_controllers_reportController_service__WEBPACK_IMPORTED_MODULE_3__.ReportControllerService), _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵinject"](_api_generated_controllers_gameController_service__WEBPACK_IMPORTED_MODULE_4__.GameControllerService));
  }, this.ɵprov = /*@__PURE__*/_angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵdefineInjectable"]({
    token: ReportService,
    factory: ReportService.ɵfac,
    providedIn: 'root'
  }));
}
_staticBlock();

/***/ }),

/***/ 42996:
/*!**************************************************************!*\
  !*** ./src/app/core/shared/services/global-error-handler.ts ***!
  \**************************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   GlobalErrorHandler: () => (/* binding */ GlobalErrorHandler)
/* harmony export */ });
/* harmony import */ var _angular_common_http__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! @angular/common/http */ 63855);
/* harmony import */ var src_environments_environment__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! src/environments/environment */ 45312);
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @angular/core */ 34205);
/* harmony import */ var _error_service__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! ./error.service */ 46078);
var _staticBlock;




class GlobalErrorHandler {
  constructor(errorService) {
    this.errorService = errorService;
  }
  /**
   * We should never get here!
   *
   * There are two possibilities of what could went wrong:
   * 1. There is a javascript bug in the code, which needs to be fixed.
   * 2. There is a server error, which was not properly handled (by ErrorService).
   */
  handleError(error) {
    const originalError = findOriginalError(error);
    // we can only guess what is correct here. We don't have any context. So let's be conservative.
    if (originalError instanceof _angular_common_http__WEBPACK_IMPORTED_MODULE_0__.HttpErrorResponse) {
      if (!src_environments_environment__WEBPACK_IMPORTED_MODULE_1__.environment.production) {
        console.error('UNHANDLED HTTP ERROR!!\n' + 'You should never get here!!\n' + 'Catch server errors in service or in the component using ErrorService\n\n', error, '\n\nOriginal error:\n', originalError);
      }
      // it is hard to decide, if we want it to be silent or not.
      this.errorService.handleError(error, 'normal');
    } else {
      if (!src_environments_environment__WEBPACK_IMPORTED_MODULE_1__.environment.production) {
        console.error('UNHANDLED ERROR!! (probably a javascript bug)\n\n', error, '\n\nOriginal error:\n', originalError);
      }
      this.errorService.handleError(error, 'silent');
    }
  }
  static #_ = _staticBlock = () => (this.ɵfac = function GlobalErrorHandler_Factory(__ngFactoryType__) {
    return new (__ngFactoryType__ || GlobalErrorHandler)(_angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵinject"](_error_service__WEBPACK_IMPORTED_MODULE_3__.ErrorService));
  }, this.ɵprov = /*@__PURE__*/_angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵdefineInjectable"]({
    token: GlobalErrorHandler,
    factory: GlobalErrorHandler.ɵfac
  }));
}
/** from angular source code.. */
_staticBlock();
function findOriginalError(error) {
  let e = error;
  if (error?.rejection) {
    e = error.rejection;
  }
  while (getOriginalError(e)) {
    e = getOriginalError(e);
  }
  return e;
}
/** from angular source code.. */
function getOriginalError(error) {
  return error?.ngOriginalError;
}

/***/ }),

/***/ 45312:
/*!*****************************************!*\
  !*** ./src/environments/environment.ts ***!
  \*****************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   environment: () => (/* binding */ environment)
/* harmony export */ });
/* harmony import */ var src_app_core_shared_globalization_i18n_check_dictio_compiletime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! src/app/core/shared/globalization/i18n/check-dictio-compiletime */ 28137);
/* harmony import */ var _create_environment__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ./create-environment */ 76285);
/* eslint-disable @typescript-eslint/naming-convention */
/**
 * stage environment. To be used with stage productFlavors on Android and iOS
 * see android\app\build.gradle
 * Main differences is separate url schema and acc
 */
// ---------- Check if translation are same for it, en ----------------- //


const environment = (0,_create_environment__WEBPACK_IMPORTED_MODULE_1__.createEnvironment)({
  name: 'stage',
  aacConfig: 'stage',
  apiServer: 'dev',
  releaseToStore: true
});

/***/ }),

/***/ 46078:
/*!*******************************************************!*\
  !*** ./src/app/core/shared/services/error.service.ts ***!
  \*******************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   ErrorService: () => (/* binding */ ErrorService),
/* harmony export */   UserError: () => (/* binding */ UserError)
/* harmony export */ });
/* harmony import */ var rxjs__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! rxjs */ 59400);
/* harmony import */ var rxjs__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! rxjs */ 61318);
/* harmony import */ var _constants_error_constants__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! ../../constants/error.constants */ 4127);
/* harmony import */ var _utils__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! ../utils */ 7497);
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! @angular/core */ 34205);
/* harmony import */ var _alert_service__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! ./alert.service */ 67406);
/* harmony import */ var _ngx_translate_core__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! @ngx-translate/core */ 48503);
var _staticBlock;






class ErrorService {
  constructor(alertService, translateService) {
    this.alertService = alertService;
    this.translateService = translateService;
    this.definedErrors = _constants_error_constants__WEBPACK_IMPORTED_MODULE_2__.ERRORS;
  }
  getErrorHandler(context = 'normal') {
    //capture the stack trace, rxjs stacks are not helpful
    const originalStack = (0,_utils__WEBPACK_IMPORTED_MODULE_3__.getDebugStack)();
    return source => source.pipe((0,rxjs__WEBPACK_IMPORTED_MODULE_1__.catchError)(error => {
      this.handleErrorInternal(error, context, originalStack);
      // return observable used for downstream subscription
      return rxjs__WEBPACK_IMPORTED_MODULE_0__.EMPTY;
    }));
  }
  /**
   *
   * Universal error handler. Display toast/popup/logs based on severity and actual error.
   *
   * @param error error
   * @param context @see {@link ErrorContextSeverity}
   */
  handleError(error, context = 'normal') {
    this.handleErrorInternal(error, context);
  }
  handleErrorInternal(error, contextSeverity = 'normal', stack) {
    // first let's check if error is "expected"
    const knownApplicationError = this.definedErrors.find(definedError => definedError.msg === error?.error?.ex);
    // if we want to handle offline error differently, than it should be done before
    // handleError was called.
    const isOffline = (0,_utils__WEBPACK_IMPORTED_MODULE_3__.isOfflineError)(error);
    const isUserError = error instanceof UserError;
    const isExpectedError = knownApplicationError || isOffline || isUserError;
    let messageTranslateKey = 'errors.defaultErr';
    if (isExpectedError) {
      if (knownApplicationError) {
        messageTranslateKey = knownApplicationError.errorString;
      }
      if (isOffline) {
        messageTranslateKey = 'errors.offline';
      }
      if (isUserError) {
        messageTranslateKey = error.message;
      }
    }
    // if we want to, we can change severity based on error itself.
    const realSeverity = contextSeverity;
    if (realSeverity === 'silent') {
      console.warn('Error handled silently\n', error, stack);
    }
    if (realSeverity === 'normal') {
      console.error('Error handled by toast\n', error, stack);
      this.alertService.showToast({
        messageTranslateKey
      });
    }
    if (realSeverity === 'important') {
      console.error('Error handled by popup\n', error, stack);
      this.alertService.confirmAlert('errors.error_header', messageTranslateKey);
    }
    if (realSeverity === 'blocking') {
      console.error('ERROR HANDLED BY FULL PAGE RELOAD!\n', error, stack);
      this.alertService.confirmAlert('errors.error_header', 'errors.not_recoverable').then(shouldReload => {
        if (shouldReload) {
          window.location.reload();
        }
      });
    }
  }
  static #_ = _staticBlock = () => (this.ɵfac = function ErrorService_Factory(__ngFactoryType__) {
    return new (__ngFactoryType__ || ErrorService)(_angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵinject"](_alert_service__WEBPACK_IMPORTED_MODULE_5__.AlertService), _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵinject"](_ngx_translate_core__WEBPACK_IMPORTED_MODULE_6__.TranslateService));
  }, this.ɵprov = /*@__PURE__*/_angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵdefineInjectable"]({
    token: ErrorService,
    factory: ErrorService.ɵfac,
    providedIn: 'root'
  }));
}
// ideas for another severities:
// 'page_blocking' - this page is broken, redirect home. For example failed load trip detail.
_staticBlock();
class UserError {
  constructor(args) {
    Object.assign(this, args);
  }
}

/***/ }),

/***/ 47550:
/*!**********************************************************************************************!*\
  !*** ./src/app/core/shared/campaigns/public-campaign-card/public-campaign-card.component.ts ***!
  \**********************************************************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   PublicCampaignCardComponent: () => (/* binding */ PublicCampaignCardComponent)
/* harmony export */ });
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! @angular/core */ 34205);
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @angular/core */ 12481);
/* harmony import */ var _angular_router__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @angular/router */ 85422);
/* harmony import */ var _services_user_service__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! ../../services/user.service */ 89815);
/* harmony import */ var _angular_common__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! @angular/common */ 93683);
/* harmony import */ var _ionic_angular__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! @ionic/angular */ 21507);
/* harmony import */ var _ngx_translate_core__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! @ngx-translate/core */ 48503);
/* harmony import */ var _pipes_localDate_pipe__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(/*! ../../pipes/localDate.pipe */ 86451);
/* harmony import */ var _pipes_languageMap_pipe__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(/*! ../../pipes/languageMap.pipe */ 69618);
var _staticBlock;








function PublicCampaignCardComponent_ng_container_18_Template(rf, ctx) {
  if (rf & 1) {
    _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵelementContainerStart"](0);
    _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵelement"](1, "ion-card-content", 12);
    _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵpipe"](2, "languageMap");
    _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵelementContainerEnd"]();
  }
  if (rf & 2) {
    const ctx_r1 = _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵnextContext"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵadvance"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵproperty"]("innerHTML", _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵpipeBind1"](2, 1, ctx_r1.campaign.description), _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵsanitizeHtml"]);
  }
}
function PublicCampaignCardComponent_ng_template_20_Template(rf, ctx) {}
class PublicCampaignCardComponent {
  constructor(router, userService) {
    this.router = router;
    this.userService = userService;
  }
  ngOnInit() {
    this.imagePath = this.campaign.logo.url ? this.campaign.logo.url : 'data:image/jpg;base64,' + this.campaign.logo.image;
    this.bannerPath = this.campaign.banner.url ? this.campaign.banner.url : 'data:image/jpg;base64,' + this.campaign.banner.image;
  }
  joinCamp() {
    this.router.navigateByUrl('/pages/tabs/campaigns/join/' + this.campaign.campaignId);
  }
  static #_ = _staticBlock = () => (this.ɵfac = function PublicCampaignCardComponent_Factory(__ngFactoryType__) {
    return new (__ngFactoryType__ || PublicCampaignCardComponent)(_angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵdirectiveInject"](_angular_router__WEBPACK_IMPORTED_MODULE_2__.Router), _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵdirectiveInject"](_services_user_service__WEBPACK_IMPORTED_MODULE_3__.UserService));
  }, this.ɵcmp = /*@__PURE__*/_angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵdefineComponent"]({
    type: PublicCampaignCardComponent,
    selectors: [["app-public-campaign-card"]],
    inputs: {
      campaign: "campaign"
    },
    standalone: false,
    decls: 26,
    vars: 28,
    consts: [["noDesc", ""], [1, "ion-card", 3, "ngClass"], [1, "ion-no-padding"], [1, "header", 3, "ngClass"], ["alt", "banner", 1, "banner", 3, "src"], ["slot", "end", 2, "margin", "2px", 3, "ngClass"], ["alt", "image", 3, "src"], [1, "ion-align-items-center"], ["size", "12"], [4, "ngIf", "ngIfElse"], ["size", "12", 1, "ion-text-center"], [2, "margin-left", "18px", "margin-bottom", "6px", 3, "click", "color"], [1, "card-ellipsis", 3, "innerHTML"]],
    template: function PublicCampaignCardComponent_Template(rf, ctx) {
      if (rf & 1) {
        const _r1 = _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵgetCurrentView"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵelementStart"](0, "div")(1, "ion-card", 1)(2, "ion-card-header", 2)(3, "div", 3);
        _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵelement"](4, "img", 4);
        _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵelementStart"](5, "ion-avatar", 5);
        _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵelement"](6, "img", 6);
        _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵelementStart"](7, "ion-label")(8, "h3");
        _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵtext"](9);
        _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵpipe"](10, "languageMap");
        _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵelementStart"](11, "h4");
        _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵtext"](12);
        _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵpipe"](13, "localDate");
        _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵpipe"](14, "localDate");
        _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵelementEnd"]()()()();
        _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵelementStart"](15, "ion-grid")(16, "ion-row", 7)(17, "ion-col", 8);
        _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵtemplate"](18, PublicCampaignCardComponent_ng_container_18_Template, 3, 3, "ng-container", 9);
        _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵpipe"](19, "languageMap");
        _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵtemplate"](20, PublicCampaignCardComponent_ng_template_20_Template, 0, 0, "ng-template", null, 0, _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵtemplateRefExtractor"]);
        _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵelementStart"](22, "ion-col", 10)(23, "ion-button", 11);
        _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵlistener"]("click", function PublicCampaignCardComponent_Template_ion_button_click_23_listener() {
          _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵrestoreView"](_r1);
          return _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵresetView"](ctx.joinCamp());
        });
        _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵtext"](24);
        _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵpipe"](25, "translate");
        _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵelementEnd"]()()()()()();
      }
      if (rf & 2) {
        const noDesc_r3 = _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵreference"](21);
        _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵadvance"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵproperty"]("ngClass", ctx.campaign.type);
        _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵadvance"](2);
        _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵproperty"]("ngClass", ctx.campaign.type + "-effect");
        _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵadvance"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵproperty"]("src", ctx.bannerPath, _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵsanitizeUrl"]);
        _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵadvance"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵproperty"]("ngClass", ctx.campaign.type);
        _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵadvance"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵproperty"]("src", ctx.imagePath, _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵsanitizeUrl"]);
        _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵadvance"](2);
        _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵstyleProp"]("color", "var(--ion-color-" + ctx.campaign.type + "-contrast")("font-weight", "bold");
        _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵadvance"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵtextInterpolate"](_angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵpipeBind1"](10, 18, ctx.campaign.name));
        _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵadvance"](2);
        _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵstyleProp"]("color", "var(--ion-color-" + ctx.campaign.type + "-contrast");
        _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵadvance"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵtextInterpolate2"](" ", _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵpipeBind1"](13, 20, ctx.campaign.dateFrom), " - ", _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵpipeBind1"](14, 22, ctx.campaign.dateTo), " ");
        _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵadvance"](6);
        _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵproperty"]("ngIf", _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵpipeBind1"](19, 24, ctx.campaign.description))("ngIfElse", noDesc_r3);
        _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵadvance"](5);
        _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵproperty"]("color", ctx.campaign.type);
        _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵadvance"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵtextInterpolate1"]("", _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵpipeBind1"](25, 26, "join"), " ");
      }
    },
    dependencies: [_angular_common__WEBPACK_IMPORTED_MODULE_4__.NgClass, _angular_common__WEBPACK_IMPORTED_MODULE_4__.NgIf, _ionic_angular__WEBPACK_IMPORTED_MODULE_5__.IonAvatar, _ionic_angular__WEBPACK_IMPORTED_MODULE_5__.IonButton, _ionic_angular__WEBPACK_IMPORTED_MODULE_5__.IonCard, _ionic_angular__WEBPACK_IMPORTED_MODULE_5__.IonCardContent, _ionic_angular__WEBPACK_IMPORTED_MODULE_5__.IonCardHeader, _ionic_angular__WEBPACK_IMPORTED_MODULE_5__.IonCol, _ionic_angular__WEBPACK_IMPORTED_MODULE_5__.IonGrid, _ionic_angular__WEBPACK_IMPORTED_MODULE_5__.IonLabel, _ionic_angular__WEBPACK_IMPORTED_MODULE_5__.IonRow, _ngx_translate_core__WEBPACK_IMPORTED_MODULE_6__.TranslatePipe, _pipes_localDate_pipe__WEBPACK_IMPORTED_MODULE_7__.LocalDatePipe, _pipes_languageMap_pipe__WEBPACK_IMPORTED_MODULE_8__.LanguageMapPipe],
    styles: [".progress-bar[_ngcontent-%COMP%] {\n  height: 24px;\n  width: var(--varwidth, 0%);\n  color: black;\n  background-color: rgb(8, 166, 240);\n  text-align: center;\n  border-top-left-radius: 10px;\n  border-bottom-left-radius: 10px;\n}\n\n.progress-bar-contourn[_ngcontent-%COMP%] {\n  border: 1px solid black;\n  border-color: black;\n  margin-left: 18px;\n  margin-right: 18px;\n  background-color: lightgrey;\n  border-radius: 10px;\n}\n\nion-card-header[_ngcontent-%COMP%]   ion-label[_ngcontent-%COMP%] {\n  font-weight: bold;\n}\n\n.border-class[_ngcontent-%COMP%] {\n  border: 1px solid rgb(63, 63, 63);\n  margin-left: 18px;\n  margin-right: 18px;\n  margin-top: 10px;\n  margin-bottom: 10px;\n}\n\n.border-class-fancy[_ngcontent-%COMP%] {\n  border: 1px solid rgb(255, 255, 255);\n  margin-left: 18px;\n  margin-right: 18px;\n  margin-top: 10px;\n  margin-bottom: 10px;\n  border-radius: 4px;\n}\n\n.ion-card[_ngcontent-%COMP%] {\n  color: black;\n  background-color: white;\n}\n.ion-card[_ngcontent-%COMP%]   .header[_ngcontent-%COMP%]   ion-label[_ngcontent-%COMP%] {\n  position: absolute;\n  bottom: 0px;\n  right: 0px;\n  bottom: 20px;\n  z-index: 2;\n  text-align: center;\n  bottom: 20px;\n  width: 100%;\n}\n.ion-card[_ngcontent-%COMP%]   .header[_ngcontent-%COMP%]   ion-avatar[_ngcontent-%COMP%] {\n  --border-radius: 50%;\n  background-color: white;\n  position: absolute;\n  z-index: 2;\n  text-align: center;\n  right: 20px;\n  bottom: -20px;\n}\n.ion-card[_ngcontent-%COMP%]   ion-grid[_ngcontent-%COMP%] {\n  margin-top: 15px;\n}\n\n.company[_ngcontent-%COMP%] {\n  border: 3px solid var(--ion-color-company);\n}\n\n.school[_ngcontent-%COMP%] {\n  border: 3px solid var(--ion-color-school);\n}\n\n.city[_ngcontent-%COMP%] {\n  border: 3px solid var(--ion-color-city);\n}\n\n.header[_ngcontent-%COMP%] {\n  position: relative;\n}\n.header[_ngcontent-%COMP%]   .banner[_ngcontent-%COMP%] {\n  max-height: 200px;\n  width: 100%;\n  object-fit: cover;\n  object-position: center;\n}\n.header[_ngcontent-%COMP%]   .header-title[_ngcontent-%COMP%] {\n  position: absolute;\n  top: 0px;\n  background-color: rgba(0, 0, 0, 0.5);\n  width: 100%;\n  color: white;\n  padding: 8px;\n}\n\n.company-effect[_ngcontent-%COMP%]:before {\n  content: \"\";\n  position: absolute;\n  top: 0;\n  left: 0;\n  right: 0;\n  bottom: 0;\n  background: linear-gradient(to bottom, rgba(0, 0, 0, 0) 30%, var(--ion-color-company) 75%);\n  z-index: 1;\n}\n\n.school-effect[_ngcontent-%COMP%]:before {\n  content: \"\";\n  position: absolute;\n  top: 0;\n  left: 0;\n  right: 0;\n  bottom: 0;\n  background: linear-gradient(to bottom, rgba(0, 0, 0, 0) 30%, var(--ion-color-school) 75%);\n  z-index: 1;\n}\n\n.city-effect[_ngcontent-%COMP%]:before {\n  content: \"\";\n  position: absolute;\n  top: 0;\n  left: 0;\n  right: 0;\n  bottom: 0;\n  background: linear-gradient(to bottom, rgba(0, 0, 0, 0) 30%, var(--ion-color-city) 75%);\n  z-index: 1;\n}\n/*# sourceMappingURL=data:application/json;charset=utf-8;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbIndlYnBhY2s6Ly8uL3NyYy9hcHAvY29yZS9zaGFyZWQvY2FtcGFpZ25zL3B1YmxpYy1jYW1wYWlnbi1jYXJkL3B1YmxpYy1jYW1wYWlnbi1jYXJkLmNvbXBvbmVudC5zY3NzIl0sIm5hbWVzIjpbXSwibWFwcGluZ3MiOiJBQUFBO0VBQ0UsWUFBQTtFQUNBLDBCQUFBO0VBQ0EsWUFBQTtFQUNBLGtDQUFBO0VBQ0Esa0JBQUE7RUFDQSw0QkFBQTtFQUNBLCtCQUFBO0FBQ0Y7O0FBRUE7RUFDRSx1QkFBQTtFQUNBLG1CQUFBO0VBQ0EsaUJBQUE7RUFDQSxrQkFBQTtFQUNBLDJCQUFBO0VBQ0EsbUJBQUE7QUFDRjs7QUFDQTtFQUNFLGlCQUFBO0FBRUY7O0FBQUE7RUFDRSxpQ0FBQTtFQUNBLGlCQUFBO0VBQ0Esa0JBQUE7RUFDQSxnQkFBQTtFQUNBLG1CQUFBO0FBR0Y7O0FBQUE7RUFDRSxvQ0FBQTtFQUNBLGlCQUFBO0VBQ0Esa0JBQUE7RUFDQSxnQkFBQTtFQUNBLG1CQUFBO0VBQ0Esa0JBQUE7QUFHRjs7QUFBQTtFQUNFLFlBQUE7RUFDQSx1QkFBQTtBQUdGO0FBQUk7RUFDRSxrQkFBQTtFQUNBLFdBQUE7RUFDQSxVQUFBO0VBQ0EsWUFBQTtFQUNBLFVBQUE7RUFDQSxrQkFBQTtFQUNBLFlBQUE7RUFDQSxXQUFBO0FBRU47QUFBSTtFQUNFLG9CQUFBO0VBRUEsdUJBQUE7RUFDQSxrQkFBQTtFQUNBLFVBQUE7RUFDQSxrQkFBQTtFQUNBLFdBQUE7RUFDQSxhQUFBO0FBQ047QUFFRTtFQUNFLGdCQUFBO0FBQUo7O0FBR0E7RUFDRSwwQ0FBQTtBQUFGOztBQUVBO0VBQ0UseUNBQUE7QUFDRjs7QUFDQTtFQUNFLHVDQUFBO0FBRUY7O0FBQUE7RUFDRSxrQkFBQTtBQUdGO0FBREU7RUFDRSxpQkFBQTtFQUNBLFdBQUE7RUFDQSxpQkFBQTtFQUNBLHVCQUFBO0FBR0o7QUFERTtFQUNFLGtCQUFBO0VBQ0EsUUFBQTtFQUNBLG9DQUFBO0VBQ0EsV0FBQTtFQUNBLFlBQUE7RUFDQSxZQUFBO0FBR0o7O0FBQUE7RUFDRSxXQUFBO0VBQ0Esa0JBQUE7RUFDQSxNQUFBO0VBQ0EsT0FBQTtFQUNBLFFBQUE7RUFDQSxTQUFBO0VBQ0EsMEZBQUE7RUFLQSxVQUFBO0FBREY7O0FBR0E7RUFDRSxXQUFBO0VBQ0Esa0JBQUE7RUFDQSxNQUFBO0VBQ0EsT0FBQTtFQUNBLFFBQUE7RUFDQSxTQUFBO0VBQ0EseUZBQUE7RUFLQSxVQUFBO0FBSkY7O0FBTUE7RUFDRSxXQUFBO0VBQ0Esa0JBQUE7RUFDQSxNQUFBO0VBQ0EsT0FBQTtFQUNBLFFBQUE7RUFDQSxTQUFBO0VBQ0EsdUZBQUE7RUFLQSxVQUFBO0FBUEYiLCJzb3VyY2VzQ29udGVudCI6WyIucHJvZ3Jlc3MtYmFyIHtcbiAgaGVpZ2h0OiAyNHB4O1xuICB3aWR0aDogdmFyKC0tdmFyd2lkdGgsIDAlKTtcbiAgY29sb3I6IGJsYWNrO1xuICBiYWNrZ3JvdW5kLWNvbG9yOiByZ2IoOCwgMTY2LCAyNDApO1xuICB0ZXh0LWFsaWduOiBjZW50ZXI7XG4gIGJvcmRlci10b3AtbGVmdC1yYWRpdXM6IDEwcHg7XG4gIGJvcmRlci1ib3R0b20tbGVmdC1yYWRpdXM6IDEwcHg7XG59XG5cbi5wcm9ncmVzcy1iYXItY29udG91cm4ge1xuICBib3JkZXI6IDFweCBzb2xpZCBibGFjaztcbiAgYm9yZGVyLWNvbG9yOiBibGFjaztcbiAgbWFyZ2luLWxlZnQ6IDE4cHg7XG4gIG1hcmdpbi1yaWdodDogMThweDtcbiAgYmFja2dyb3VuZC1jb2xvcjogbGlnaHRncmV5O1xuICBib3JkZXItcmFkaXVzOiAxMHB4O1xufVxuaW9uLWNhcmQtaGVhZGVyIGlvbi1sYWJlbCB7XG4gIGZvbnQtd2VpZ2h0OiBib2xkO1xufVxuLmJvcmRlci1jbGFzcyB7XG4gIGJvcmRlcjogMXB4IHNvbGlkIHJnYig2MywgNjMsIDYzKTtcbiAgbWFyZ2luLWxlZnQ6IDE4cHg7XG4gIG1hcmdpbi1yaWdodDogMThweDtcbiAgbWFyZ2luLXRvcDogMTBweDtcbiAgbWFyZ2luLWJvdHRvbTogMTBweDtcbn1cblxuLmJvcmRlci1jbGFzcy1mYW5jeSB7XG4gIGJvcmRlcjogMXB4IHNvbGlkIHJnYigyNTUsIDI1NSwgMjU1KTtcbiAgbWFyZ2luLWxlZnQ6IDE4cHg7XG4gIG1hcmdpbi1yaWdodDogMThweDtcbiAgbWFyZ2luLXRvcDogMTBweDtcbiAgbWFyZ2luLWJvdHRvbTogMTBweDtcbiAgYm9yZGVyLXJhZGl1czogNHB4O1xufVxuXG4uaW9uLWNhcmQge1xuICBjb2xvcjogYmxhY2s7XG4gIGJhY2tncm91bmQtY29sb3I6IHdoaXRlO1xuXG4gIC5oZWFkZXIge1xuICAgIGlvbi1sYWJlbCB7XG4gICAgICBwb3NpdGlvbjogYWJzb2x1dGU7XG4gICAgICBib3R0b206IDBweDtcbiAgICAgIHJpZ2h0OiAwcHg7XG4gICAgICBib3R0b206IDIwcHg7XG4gICAgICB6LWluZGV4OiAyO1xuICAgICAgdGV4dC1hbGlnbjogY2VudGVyO1xuICAgICAgYm90dG9tOiAyMHB4O1xuICAgICAgd2lkdGg6IDEwMCU7XG4gICAgfVxuICAgIGlvbi1hdmF0YXIge1xuICAgICAgLS1ib3JkZXItcmFkaXVzOiA1MCU7XG4gICAgICAvLyBib3JkZXI6IHNvbGlkIDNweCByZ2JhKDAsIDAsIDAsIDApO1xuICAgICAgYmFja2dyb3VuZC1jb2xvcjogd2hpdGU7XG4gICAgICBwb3NpdGlvbjogYWJzb2x1dGU7XG4gICAgICB6LWluZGV4OiAyO1xuICAgICAgdGV4dC1hbGlnbjogY2VudGVyO1xuICAgICAgcmlnaHQ6IDIwcHg7XG4gICAgICBib3R0b206IC0yMHB4O1xuICAgIH1cbiAgfVxuICBpb24tZ3JpZCB7XG4gICAgbWFyZ2luLXRvcDogMTVweDtcbiAgfVxufVxuLmNvbXBhbnkge1xuICBib3JkZXI6IDNweCBzb2xpZCB2YXIoLS1pb24tY29sb3ItY29tcGFueSk7XG59XG4uc2Nob29sIHtcbiAgYm9yZGVyOiAzcHggc29saWQgdmFyKC0taW9uLWNvbG9yLXNjaG9vbCk7XG59XG4uY2l0eSB7XG4gIGJvcmRlcjogM3B4IHNvbGlkIHZhcigtLWlvbi1jb2xvci1jaXR5KTtcbn1cbi5oZWFkZXIge1xuICBwb3NpdGlvbjogcmVsYXRpdmU7XG5cbiAgLmJhbm5lciB7XG4gICAgbWF4LWhlaWdodDogMjAwcHg7XG4gICAgd2lkdGg6IDEwMCU7XG4gICAgb2JqZWN0LWZpdDogY292ZXI7XG4gICAgb2JqZWN0LXBvc2l0aW9uOiBjZW50ZXI7XG4gIH1cbiAgLmhlYWRlci10aXRsZSB7XG4gICAgcG9zaXRpb246IGFic29sdXRlO1xuICAgIHRvcDogMHB4O1xuICAgIGJhY2tncm91bmQtY29sb3I6IHJnYmEoMCwgMCwgMCwgMC41KTtcbiAgICB3aWR0aDogMTAwJTtcbiAgICBjb2xvcjogd2hpdGU7XG4gICAgcGFkZGluZzogOHB4O1xuICB9XG59XG4uY29tcGFueS1lZmZlY3Q6YmVmb3JlIHtcbiAgY29udGVudDogXCJcIjtcbiAgcG9zaXRpb246IGFic29sdXRlO1xuICB0b3A6IDA7XG4gIGxlZnQ6IDA7XG4gIHJpZ2h0OiAwO1xuICBib3R0b206IDA7XG4gIGJhY2tncm91bmQ6IGxpbmVhci1ncmFkaWVudChcbiAgICB0byBib3R0b20sXG4gICAgcmdiYSgwLCAwLCAwLCAwKSAzMCUsXG4gICAgdmFyKC0taW9uLWNvbG9yLWNvbXBhbnkpIDc1JVxuICApO1xuICB6LWluZGV4OiAxO1xufVxuLnNjaG9vbC1lZmZlY3Q6YmVmb3JlIHtcbiAgY29udGVudDogXCJcIjtcbiAgcG9zaXRpb246IGFic29sdXRlO1xuICB0b3A6IDA7XG4gIGxlZnQ6IDA7XG4gIHJpZ2h0OiAwO1xuICBib3R0b206IDA7XG4gIGJhY2tncm91bmQ6IGxpbmVhci1ncmFkaWVudChcbiAgICB0byBib3R0b20sXG4gICAgcmdiYSgwLCAwLCAwLCAwKSAzMCUsXG4gICAgdmFyKC0taW9uLWNvbG9yLXNjaG9vbCkgNzUlXG4gICk7XG4gIHotaW5kZXg6IDE7XG59XG4uY2l0eS1lZmZlY3Q6YmVmb3JlIHtcbiAgY29udGVudDogXCJcIjtcbiAgcG9zaXRpb246IGFic29sdXRlO1xuICB0b3A6IDA7XG4gIGxlZnQ6IDA7XG4gIHJpZ2h0OiAwO1xuICBib3R0b206IDA7XG4gIGJhY2tncm91bmQ6IGxpbmVhci1ncmFkaWVudChcbiAgICB0byBib3R0b20sXG4gICAgcmdiYSgwLCAwLCAwLCAwKSAzMCUsXG4gICAgdmFyKC0taW9uLWNvbG9yLWNpdHkpIDc1JVxuICApO1xuICB6LWluZGV4OiAxO1xufVxuLy8gLmhlYWRlcjpiZWZvcmUge1xuLy8gICBjb250ZW50OiBcIlwiO1xuLy8gICBwb3NpdGlvbjogYWJzb2x1dGU7XG4vLyAgIHRvcDogMDtcbi8vICAgbGVmdDogMDtcbi8vICAgcmlnaHQ6IDA7XG4vLyAgIGJvdHRvbTogMDtcbi8vICAgYmFja2dyb3VuZDogbGluZWFyLWdyYWRpZW50KFxuLy8gICAgIHRvIGJvdHRvbSxcbi8vICAgICByZ2JhKDAsIDAsIDAsIDApIDAlLFxuLy8gICAgIHJnYmEoMCwgMCwgMCwgMSkgMTAwJVxuLy8gICApO1xuLy8gICB6LWluZGV4OiAxO1xuLy8gfVxuIl0sInNvdXJjZVJvb3QiOiIifQ== */"]
  }));
}
_staticBlock();

/***/ }),

/***/ 47562:
/*!********************************************************************************!*\
  !*** ./src/app/core/shared/services/notifications/pushNotification.service.ts ***!
  \********************************************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   PushNotificationService: () => (/* binding */ PushNotificationService)
/* harmony export */ });
/* harmony import */ var _Users_smartcommunitylab_Desktop_newWork_playAndGo_playGo_node_modules_babel_runtime_helpers_esm_asyncToGenerator_js__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./node_modules/@babel/runtime/helpers/esm/asyncToGenerator.js */ 89204);
/* harmony import */ var _capacitor_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @capacitor/core */ 14070);
/* harmony import */ var _capacitor_push_notifications__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @capacitor/push-notifications */ 92132);
/* harmony import */ var _capacitor_community_fcm__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @capacitor-community/fcm */ 89077);
/* harmony import */ var _rxjs_utils__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! ../../rxjs.utils */ 86040);
/* harmony import */ var rxjs__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! rxjs */ 56042);
/* harmony import */ var rxjs__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! rxjs */ 19999);
/* harmony import */ var rxjs__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(/*! rxjs */ 95429);
/* harmony import */ var rxjs__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(/*! rxjs */ 63617);
/* harmony import */ var rxjs__WEBPACK_IMPORTED_MODULE_9__ = __webpack_require__(/*! rxjs */ 61318);
/* harmony import */ var rxjs__WEBPACK_IMPORTED_MODULE_10__ = __webpack_require__(/*! rxjs */ 2435);
/* harmony import */ var rxjs__WEBPACK_IMPORTED_MODULE_11__ = __webpack_require__(/*! rxjs */ 13255);
/* harmony import */ var rxjs__WEBPACK_IMPORTED_MODULE_12__ = __webpack_require__(/*! rxjs */ 36647);
/* harmony import */ var rxjs__WEBPACK_IMPORTED_MODULE_13__ = __webpack_require__(/*! rxjs */ 43143);
/* harmony import */ var _notification_modal_notification_modal__WEBPACK_IMPORTED_MODULE_14__ = __webpack_require__(/*! ../../notification-modal/notification.modal */ 18128);
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_15__ = __webpack_require__(/*! @angular/core */ 34205);
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_16__ = __webpack_require__(/*! @angular/core */ 12481);
/* harmony import */ var _campaign_service__WEBPACK_IMPORTED_MODULE_17__ = __webpack_require__(/*! ../campaign.service */ 76658);
/* harmony import */ var _api_generated_controllers_communicationAccountController_service__WEBPACK_IMPORTED_MODULE_18__ = __webpack_require__(/*! ../../../api/generated/controllers/communicationAccountController.service */ 48153);
/* harmony import */ var _user_service__WEBPACK_IMPORTED_MODULE_19__ = __webpack_require__(/*! ../user.service */ 89815);
/* harmony import */ var _ionic_angular__WEBPACK_IMPORTED_MODULE_20__ = __webpack_require__(/*! @ionic/angular */ 21507);
/* harmony import */ var _error_service__WEBPACK_IMPORTED_MODULE_21__ = __webpack_require__(/*! ../error.service */ 46078);
/* harmony import */ var _refresher_service__WEBPACK_IMPORTED_MODULE_22__ = __webpack_require__(/*! ../refresher.service */ 8780);

var _staticBlock;













class PushNotificationService {
  constructor(zone, campaignService, communicationAccountControllerService, userService, modalController, errorService, refresherService) {
    this.zone = zone;
    this.campaignService = campaignService;
    this.communicationAccountControllerService = communicationAccountControllerService;
    this.userService = userService;
    this.modalController = modalController;
    this.errorService = errorService;
    this.refresherService = refresherService;
    this.notifications = [];
    this.notificationsSubject = new rxjs__WEBPACK_IMPORTED_MODULE_5__.ReplaySubject(1);
    this.notifications$ = this.notificationsSubject.asObservable();
  }
  initPush() {
    if (_capacitor_core__WEBPACK_IMPORTED_MODULE_1__.Capacitor.getPlatform() !== 'web') {
      this.registerPush();
      this.campaignService.subscribeCampaignAction$.subscribe(topicName => {
        this.userService.userProfileTerritory$.pipe((0,rxjs__WEBPACK_IMPORTED_MODULE_10__.first)(), (0,_rxjs_utils__WEBPACK_IMPORTED_MODULE_4__.tapLog)('userProfileTerritory$')).subscribe(profile => {
          _capacitor_community_fcm__WEBPACK_IMPORTED_MODULE_3__.FCM.subscribeTo({
            topic: `${profile.territoryId}-${topicName}`
          });
        });
      });
      this.campaignService.unsubscribeCampaignAction$.subscribe(topicName => {
        this.userService.userProfileTerritory$.pipe((0,rxjs__WEBPACK_IMPORTED_MODULE_10__.first)(), (0,_rxjs_utils__WEBPACK_IMPORTED_MODULE_4__.tapLog)('userProfileTerritory$')).subscribe(profile => {
          _capacitor_community_fcm__WEBPACK_IMPORTED_MODULE_3__.FCM.unsubscribeFrom({
            topic: `${profile.territoryId}-${topicName}`
          });
        });
      });
    }
  }
  registerPush() {
    var _this = this;
    return (0,_Users_smartcommunitylab_Desktop_newWork_playAndGo_playGo_node_modules_babel_runtime_helpers_esm_asyncToGenerator_js__WEBPACK_IMPORTED_MODULE_0__["default"])(function* () {
      let permStatus = yield _capacitor_push_notifications__WEBPACK_IMPORTED_MODULE_2__.PushNotifications.checkPermissions();
      if (permStatus.receive === 'prompt') {
        permStatus = yield _capacitor_push_notifications__WEBPACK_IMPORTED_MODULE_2__.PushNotifications.requestPermissions();
      }
      if (permStatus.receive !== 'granted') {
        throw new Error('User denied permissions!');
      }
      yield _capacitor_push_notifications__WEBPACK_IMPORTED_MODULE_2__.PushNotifications.register();
      // On success, we should be able to receive notifications
      _capacitor_push_notifications__WEBPACK_IMPORTED_MODULE_2__.PushNotifications.addListener('registration', token => {
        _this.zone.run(() => {
          _capacitor_community_fcm__WEBPACK_IMPORTED_MODULE_3__.FCM.getToken().then(fcmtoken => {
            if (_capacitor_core__WEBPACK_IMPORTED_MODULE_1__.Capacitor.getPlatform() === 'ios') {
              console.log('fcmtoken', fcmtoken);
              _this.registerToServer(fcmtoken.token);
            } else {
              _this.registerToServer(token.value);
            }
            // subscribe to territory and all campaign I have
            _this.registerToTopics();
          });
        });
      });
      // Some issue with our setup and push will not work
      _capacitor_push_notifications__WEBPACK_IMPORTED_MODULE_2__.PushNotifications.addListener('registrationError', error => {
        _this.zone.run(() => {
          console.log('Error on registration: ' + JSON.stringify(error));
        });
      });
      // Show us the notification payload if the app is open on our device
      _capacitor_push_notifications__WEBPACK_IMPORTED_MODULE_2__.PushNotifications.addListener('pushNotificationReceived', notification => {
        _this.zone.run(() => {
          _this.notificationsSubject.next();
          console.log('Push received: ' + JSON.stringify(notification));
          _this.notifications.push(notification);
          _this.showLastNotification(notification);
          _this.refresherService.onRefresh(null);
        });
      });
      // Method called when tapping on a notification
      _capacitor_push_notifications__WEBPACK_IMPORTED_MODULE_2__.PushNotifications.addListener('pushNotificationActionPerformed', notification => {
        _this.zone.run(() => {
          _this.notifications.push(notification.notification);
          if (notification?.notification?.data?.title && notification?.notification?.data?.description) {
            _this.showLastNotification(notification.notification);
          }
        });
      });
    })();
  }
  showLastNotification(notification) {
    var _this2 = this;
    return (0,_Users_smartcommunitylab_Desktop_newWork_playAndGo_playGo_node_modules_babel_runtime_helpers_esm_asyncToGenerator_js__WEBPACK_IMPORTED_MODULE_0__["default"])(function* () {
      //show last notification if received
      if (!_this2.modal) {
        _this2.modal = yield _this2.modalController.create({
          component: _notification_modal_notification_modal__WEBPACK_IMPORTED_MODULE_14__.NotificationModalPage,
          cssClass: 'modal-challenge',
          componentProps: {
            notification
          }
        });
        yield _this2.modal.present();
        const {
          data
        } = yield _this2.modal.onWillDismiss();
        _this2.modal = null;
      }
    })();
  }
  registerToServer(token) {
    var _this3 = this;
    return (0,_Users_smartcommunitylab_Desktop_newWork_playAndGo_playGo_node_modules_babel_runtime_helpers_esm_asyncToGenerator_js__WEBPACK_IMPORTED_MODULE_0__["default"])(function* () {
      console.log('registerToServer', token);
      try {
        yield _this3.communicationAccountControllerService.registerUserToPushUsingPOST({
          platform: _capacitor_core__WEBPACK_IMPORTED_MODULE_1__.Capacitor.getPlatform(),
          registrationId: token
        }).toPromise();
      } catch (e) {
        _this3.errorService.handleError(e, 'silent');
      }
    })();
  }
  registerToTopics() {
    console.log('registerToTopics');
    this.sub = (0,rxjs__WEBPACK_IMPORTED_MODULE_6__.combineLatest)([this.campaignService.myCampaigns$, this.userService.userProfileTerritory$]).pipe((0,rxjs__WEBPACK_IMPORTED_MODULE_10__.first)(), (0,rxjs__WEBPACK_IMPORTED_MODULE_12__.switchMap)(([campaigns, profile]) => (0,rxjs__WEBPACK_IMPORTED_MODULE_8__.merge)((0,rxjs__WEBPACK_IMPORTED_MODULE_7__.from)(campaigns).pipe((0,_rxjs_utils__WEBPACK_IMPORTED_MODULE_4__.tapLog)('campaigns'), (0,rxjs__WEBPACK_IMPORTED_MODULE_11__.mergeMap)(val => {
      console.log(val);
      return _capacitor_community_fcm__WEBPACK_IMPORTED_MODULE_3__.FCM.subscribeTo({
        topic: `${profile.territoryId}-${val?.campaign?.campaignId}`
      });
    }), (0,rxjs__WEBPACK_IMPORTED_MODULE_13__.toArray)()), (0,rxjs__WEBPACK_IMPORTED_MODULE_7__.from)(_capacitor_community_fcm__WEBPACK_IMPORTED_MODULE_3__.FCM.subscribeTo({
      topic: profile?.territoryId
    })))), (0,rxjs__WEBPACK_IMPORTED_MODULE_9__.catchError)(err => {
      throw err;
    })).subscribe();
  }
  unregisterToTopics() {
    console.log('unregisterToTopics');
    if (_capacitor_core__WEBPACK_IMPORTED_MODULE_1__.Capacitor.getPlatform() !== 'web') {
      this.subUn = (0,rxjs__WEBPACK_IMPORTED_MODULE_6__.combineLatest)([this.campaignService.myCampaigns$, this.userService.userProfileTerritory$]).pipe((0,rxjs__WEBPACK_IMPORTED_MODULE_10__.first)(), (0,rxjs__WEBPACK_IMPORTED_MODULE_12__.switchMap)(([campaigns, profile]) => (0,rxjs__WEBPACK_IMPORTED_MODULE_8__.merge)((0,rxjs__WEBPACK_IMPORTED_MODULE_7__.from)(campaigns).pipe((0,_rxjs_utils__WEBPACK_IMPORTED_MODULE_4__.tapLog)('campaigns'), (0,rxjs__WEBPACK_IMPORTED_MODULE_11__.mergeMap)(val => {
        console.log(val);
        return _capacitor_community_fcm__WEBPACK_IMPORTED_MODULE_3__.FCM.unsubscribeFrom({
          topic: `${profile.territoryId}-${val?.campaign?.campaignId}`
        });
      }), (0,rxjs__WEBPACK_IMPORTED_MODULE_13__.toArray)()), (0,rxjs__WEBPACK_IMPORTED_MODULE_7__.from)(_capacitor_community_fcm__WEBPACK_IMPORTED_MODULE_3__.FCM.unsubscribeFrom({
        topic: profile?.territoryId
      })))), (0,rxjs__WEBPACK_IMPORTED_MODULE_9__.catchError)(err => {
        throw err;
      })).subscribe();
    }
  }
  static #_ = _staticBlock = () => (this.ɵfac = function PushNotificationService_Factory(__ngFactoryType__) {
    return new (__ngFactoryType__ || PushNotificationService)(_angular_core__WEBPACK_IMPORTED_MODULE_15__["ɵɵinject"](_angular_core__WEBPACK_IMPORTED_MODULE_16__.NgZone), _angular_core__WEBPACK_IMPORTED_MODULE_15__["ɵɵinject"](_campaign_service__WEBPACK_IMPORTED_MODULE_17__.CampaignService), _angular_core__WEBPACK_IMPORTED_MODULE_15__["ɵɵinject"](_api_generated_controllers_communicationAccountController_service__WEBPACK_IMPORTED_MODULE_18__.CommunicationAccountControllerService), _angular_core__WEBPACK_IMPORTED_MODULE_15__["ɵɵinject"](_user_service__WEBPACK_IMPORTED_MODULE_19__.UserService), _angular_core__WEBPACK_IMPORTED_MODULE_15__["ɵɵinject"](_ionic_angular__WEBPACK_IMPORTED_MODULE_20__.ModalController), _angular_core__WEBPACK_IMPORTED_MODULE_15__["ɵɵinject"](_error_service__WEBPACK_IMPORTED_MODULE_21__.ErrorService), _angular_core__WEBPACK_IMPORTED_MODULE_15__["ɵɵinject"](_refresher_service__WEBPACK_IMPORTED_MODULE_22__.RefresherService));
  }, this.ɵprov = /*@__PURE__*/_angular_core__WEBPACK_IMPORTED_MODULE_15__["ɵɵdefineInjectable"]({
    token: PushNotificationService,
    factory: PushNotificationService.ɵfac,
    providedIn: 'root'
  }));
}
_staticBlock();

/***/ }),

/***/ 48153:
/*!******************************************************************************************!*\
  !*** ./src/app/core/api/generated/controllers/communicationAccountController.service.ts ***!
  \******************************************************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   CommunicationAccountControllerService: () => (/* binding */ CommunicationAccountControllerService)
/* harmony export */ });
/* harmony import */ var src_environments_environment__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! src/environments/environment */ 45312);
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @angular/core */ 34205);
/* harmony import */ var _angular_common_http__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @angular/common/http */ 63855);
var _staticBlock;
/**
 * Play&Go Project
 * No description provided (generated by Swagger Codegen https://github.com/swagger-api/swagger-codegen)
 *
 * OpenAPI spec version: 2.0
 * Contact: info@smartcommunitylab.it
 *
 * NOTE: This class is auto generated by the swagger code generator program.
 * https://github.com/swagger-api/swagger-codegen.git
 * Do not edit the class manually.
 */



class CommunicationAccountControllerService {
  constructor(http) {
    this.http = http;
  }
  /**
   * getPlayerNotifications
   *
   * @param since since
   * @param skip skip
   * @param limit limit
   */
  getPlayerNotificationsUsingGET(args) {
    const {
      since,
      skip,
      limit
    } = args;
    return this.http.request('get', src_environments_environment__WEBPACK_IMPORTED_MODULE_0__.environment.serverUrl.api + `/playandgo/api/app/notifications`, {
      params: removeNullOrUndefined({
        since,
        skip,
        limit
      })
    });
  }
  /**
   * registerUserToPush
   *
   * @param body
   */
  registerUserToPushUsingPOST(body) {
    return this.http.request('post', src_environments_environment__WEBPACK_IMPORTED_MODULE_0__.environment.serverUrl.api + `/playandgo/api/app/register`, {
      body
    });
  }
  static #_ = _staticBlock = () => (this.ɵfac = function CommunicationAccountControllerService_Factory(__ngFactoryType__) {
    return new (__ngFactoryType__ || CommunicationAccountControllerService)(_angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵinject"](_angular_common_http__WEBPACK_IMPORTED_MODULE_2__.HttpClient));
  }, this.ɵprov = /*@__PURE__*/_angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵdefineInjectable"]({
    token: CommunicationAccountControllerService,
    factory: CommunicationAccountControllerService.ɵfac,
    providedIn: 'root'
  }));
}
_staticBlock();
function removeNullOrUndefined(obj) {
  const newObj = {};
  Object.keys(obj).forEach(key => {
    if (obj[key] != null) {
      newObj[key] = obj[key];
    }
  });
  return newObj;
}

/***/ }),

/***/ 48687:
/*!*******************************************************!*\
  !*** ./src/app/core/shared/services/badge.service.ts ***!
  \*******************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   BadgeService: () => (/* binding */ BadgeService)
/* harmony export */ });
/* harmony import */ var _Users_smartcommunitylab_Desktop_newWork_playAndGo_playGo_node_modules_babel_runtime_helpers_esm_asyncToGenerator_js__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./node_modules/@babel/runtime/helpers/esm/asyncToGenerator.js */ 89204);
/* harmony import */ var rxjs__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! rxjs */ 56196);
/* harmony import */ var rxjs__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! rxjs */ 86301);
/* harmony import */ var rxjs__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! rxjs */ 36647);
/* harmony import */ var rxjs__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! rxjs */ 98764);
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! @angular/core */ 34205);
/* harmony import */ var _local_storage_service__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! ./local-storage.service */ 9891);
/* harmony import */ var _auth_auth_service__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(/*! ../../auth/auth.service */ 35524);
/* harmony import */ var _api_generated_controllers_gameController_service__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(/*! ../../api/generated/controllers/gameController.service */ 60436);
/* harmony import */ var _error_service__WEBPACK_IMPORTED_MODULE_9__ = __webpack_require__(/*! ./error.service */ 46078);

var _staticBlock;






class BadgeService {
  constructor(localStorageService, authService, gameControllerService, errorService) {
    this.localStorageService = localStorageService;
    this.authService = authService;
    this.gameControllerService = gameControllerService;
    this.errorService = errorService;
    this.allBadgesStorage = this.localStorageService.getStorageOf('allBadges');
    this.allBadges$ = this.authService.isReadyForApi$.pipe((0,rxjs__WEBPACK_IMPORTED_MODULE_3__.switchMap)(() => this.allBadgesStorage.getMeta()), (0,rxjs__WEBPACK_IMPORTED_MODULE_3__.switchMap)(({
      lastUpdated
    }) => this.checkIfStoredBadgesAreUpToDate(lastUpdated) ? this.allBadgesStorage.get() : this.gameControllerService.getAllBadgesUsingGET().pipe((0,rxjs__WEBPACK_IMPORTED_MODULE_4__.tap)(badges => this.allBadgesStorage.set(badges)), this.errorService.getErrorHandler('silent'))), (0,rxjs__WEBPACK_IMPORTED_MODULE_2__.shareReplay)(1));
  }
  init() {
    // run api call as soon as possible
    this.allBadges$.subscribe();
  }
  // call api only once per week
  checkIfStoredBadgesAreUpToDate(lastUpdated) {
    const oneWeek = 1000 * 60 * 60 * 24 * 7;
    return lastUpdated + oneWeek > new Date().getTime();
  }
  getBadgeByKey(key) {
    var _this = this;
    return (0,_Users_smartcommunitylab_Desktop_newWork_playAndGo_playGo_node_modules_babel_runtime_helpers_esm_asyncToGenerator_js__WEBPACK_IMPORTED_MODULE_0__["default"])(function* () {
      const allBadges = yield (0,rxjs__WEBPACK_IMPORTED_MODULE_1__.firstValueFrom)(_this.allBadges$);
      return allBadges[key];
    })();
  }
  static #_ = _staticBlock = () => (this.ɵfac = function BadgeService_Factory(__ngFactoryType__) {
    return new (__ngFactoryType__ || BadgeService)(_angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵinject"](_local_storage_service__WEBPACK_IMPORTED_MODULE_6__.LocalStorageService), _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵinject"](_auth_auth_service__WEBPACK_IMPORTED_MODULE_7__.AuthService), _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵinject"](_api_generated_controllers_gameController_service__WEBPACK_IMPORTED_MODULE_8__.GameControllerService), _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵinject"](_error_service__WEBPACK_IMPORTED_MODULE_9__.ErrorService));
  }, this.ɵprov = /*@__PURE__*/_angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵdefineInjectable"]({
    token: BadgeService,
    factory: BadgeService.ɵfac,
    providedIn: 'root'
  }));
}
_staticBlock();

/***/ }),

/***/ 50635:
/*!*******************************!*\
  !*** ./src/app/app.module.ts ***!
  \*******************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   AppModule: () => (/* binding */ AppModule)
/* harmony export */ });
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! @angular/core */ 34205);
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @angular/core */ 37580);
/* harmony import */ var _angular_platform_browser__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @angular/platform-browser */ 62190);
/* harmony import */ var _angular_router__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @angular/router */ 85422);
/* harmony import */ var _ionic_angular__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! @ionic/angular */ 4059);
/* harmony import */ var _ionic_angular__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! @ionic/angular */ 21507);
/* harmony import */ var _app_component__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! ./app.component */ 20092);
/* harmony import */ var _app_routing_module__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(/*! ./app-routing.module */ 94114);
/* harmony import */ var _core_shared_shared_module__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(/*! ./core/shared/shared.module */ 62657);
/* harmony import */ var _ngx_translate_core__WEBPACK_IMPORTED_MODULE_9__ = __webpack_require__(/*! @ngx-translate/core */ 48503);
/* harmony import */ var _core_auth_auth_module__WEBPACK_IMPORTED_MODULE_10__ = __webpack_require__(/*! ./core/auth/auth.module */ 12795);
/* harmony import */ var _transistorsoft_capacitor_background_geolocation__WEBPACK_IMPORTED_MODULE_11__ = __webpack_require__(/*! @transistorsoft/capacitor-background-geolocation */ 5914);
/* harmony import */ var _core_shared_plugin_mocks_BackgroundGeolocationMock__WEBPACK_IMPORTED_MODULE_12__ = __webpack_require__(/*! ./core/shared/plugin-mocks/BackgroundGeolocationMock */ 30116);
/* harmony import */ var _capacitor_app__WEBPACK_IMPORTED_MODULE_13__ = __webpack_require__(/*! @capacitor/app */ 59326);
/* harmony import */ var _core_shared_plugin_mocks_AppPluginMock__WEBPACK_IMPORTED_MODULE_14__ = __webpack_require__(/*! ./core/shared/plugin-mocks/AppPluginMock */ 7594);
/* harmony import */ var _core_shared_services_global_error_handler__WEBPACK_IMPORTED_MODULE_15__ = __webpack_require__(/*! ./core/shared/services/global-error-handler */ 42996);
/* harmony import */ var _capacitor_device__WEBPACK_IMPORTED_MODULE_16__ = __webpack_require__(/*! @capacitor/device */ 67801);
/* harmony import */ var _core_shared_plugin_mocks_DevicePluginMock__WEBPACK_IMPORTED_MODULE_17__ = __webpack_require__(/*! ./core/shared/plugin-mocks/DevicePluginMock */ 76797);
/* harmony import */ var _angular_common_locales_it__WEBPACK_IMPORTED_MODULE_18__ = __webpack_require__(/*! @angular/common/locales/it */ 51147);
/* harmony import */ var _angular_common__WEBPACK_IMPORTED_MODULE_19__ = __webpack_require__(/*! @angular/common */ 60316);
/* harmony import */ var _ionic_storage_angular__WEBPACK_IMPORTED_MODULE_20__ = __webpack_require__(/*! @ionic/storage-angular */ 26817);
/* harmony import */ var localforage_cordovasqlitedriver__WEBPACK_IMPORTED_MODULE_21__ = __webpack_require__(/*! localforage-cordovasqlitedriver */ 28376);
/* harmony import */ var localforage_cordovasqlitedriver__WEBPACK_IMPORTED_MODULE_21___default = /*#__PURE__*/__webpack_require__.n(localforage_cordovasqlitedriver__WEBPACK_IMPORTED_MODULE_21__);
/* harmony import */ var _angular_platform_browser_animations__WEBPACK_IMPORTED_MODULE_22__ = __webpack_require__(/*! @angular/platform-browser/animations */ 43835);
/* harmony import */ var _ngx_translate_http_loader__WEBPACK_IMPORTED_MODULE_23__ = __webpack_require__(/*! @ngx-translate/http-loader */ 12279);
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_24__ = __webpack_require__(/*! @angular/core */ 12481);
var _staticBlock;
/* eslint-disable @typescript-eslint/naming-convention */













// import { codePush } from '@dwimcore/capacitor-codepush';
// import { codePush, CodePush  } from 'cap-codepush';













// this is somehow not exported from '@ionic/storage-angular'
const Drivers = {
  SecureStorage: 'ionicSecureStorage',
  IndexedDB: 'asyncStorage',
  LocalStorage: 'localStorageWrapper'
};
(0,_angular_common__WEBPACK_IMPORTED_MODULE_19__.registerLocaleData)(_angular_common_locales_it__WEBPACK_IMPORTED_MODULE_18__["default"]);
// export function createTranslateLoader(http: HttpClient) {
//   return new TranslateHttpLoader(http, './assets/i18n/', '.json');
// }
class AppModule {
  static #_ = _staticBlock = () => (this.ɵfac = function AppModule_Factory(__ngFactoryType__) {
    return new (__ngFactoryType__ || AppModule)();
  }, this.ɵmod = /*@__PURE__*/_angular_core__WEBPACK_IMPORTED_MODULE_24__["ɵɵdefineNgModule"]({
    type: AppModule,
    bootstrap: [_app_component__WEBPACK_IMPORTED_MODULE_6__.AppComponent]
  }), this.ɵinj = /*@__PURE__*/_angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵdefineInjector"]({
    providers: [{
      provide: _angular_router__WEBPACK_IMPORTED_MODULE_3__.RouteReuseStrategy,
      useClass: _ionic_angular__WEBPACK_IMPORTED_MODULE_4__.IonicRouteStrategy
    }, {
      provide: 'BackgroundGeolocationPlugin',
      useFactory: () =>
      // useMock() ? BackgroundGeolocationMock : BackgroundGeolocation,
      useMock() ? _core_shared_plugin_mocks_BackgroundGeolocationMock__WEBPACK_IMPORTED_MODULE_12__.BackgroundGeolocationMock : _transistorsoft_capacitor_background_geolocation__WEBPACK_IMPORTED_MODULE_11__["default"]
    }, {
      provide: 'AppPlugin',
      useFactory: () => useMock() ? _core_shared_plugin_mocks_AppPluginMock__WEBPACK_IMPORTED_MODULE_14__.AppPluginMock : _capacitor_app__WEBPACK_IMPORTED_MODULE_13__.App
    }, {
      provide: 'DevicePlugin',
      useFactory: () => useMock() ? _core_shared_plugin_mocks_DevicePluginMock__WEBPACK_IMPORTED_MODULE_17__.DevicePluginMock : _capacitor_device__WEBPACK_IMPORTED_MODULE_16__.Device
    },
    // {
    //   provide: 'CodePushPlugin',
    //   useFactory: () => (useMock() ? CodePushPluginMock : codePush),
    // },
    {
      provide: _angular_core__WEBPACK_IMPORTED_MODULE_0__.ErrorHandler,
      useClass: _core_shared_services_global_error_handler__WEBPACK_IMPORTED_MODULE_15__.GlobalErrorHandler
    }],
    imports: [_core_auth_auth_module__WEBPACK_IMPORTED_MODULE_10__.AuthModule, _angular_platform_browser__WEBPACK_IMPORTED_MODULE_2__.BrowserModule, _angular_platform_browser_animations__WEBPACK_IMPORTED_MODULE_22__.BrowserAnimationsModule, _core_shared_shared_module__WEBPACK_IMPORTED_MODULE_8__.PlayGoSharedModule, _ngx_translate_core__WEBPACK_IMPORTED_MODULE_9__.TranslateModule.forRoot({
      loader: (0,_ngx_translate_http_loader__WEBPACK_IMPORTED_MODULE_23__.provideTranslateHttpLoader)({
        prefix: "./assets/i18n/",
        suffix: ".json"
      })
    }), _ionic_angular__WEBPACK_IMPORTED_MODULE_5__.IonicModule.forRoot(), _ionic_storage_angular__WEBPACK_IMPORTED_MODULE_20__.IonicStorageModule.forRoot({
      driverOrder: [
      // eslint-disable-next-line no-underscore-dangle
      localforage_cordovasqlitedriver__WEBPACK_IMPORTED_MODULE_21__._driver, Drivers.IndexedDB, Drivers.LocalStorage]
    }), _app_routing_module__WEBPACK_IMPORTED_MODULE_7__.AppRoutingModule]
  }));
}
_staticBlock();
(function () {
  (typeof ngJitMode === "undefined" || ngJitMode) && _angular_core__WEBPACK_IMPORTED_MODULE_24__["ɵɵsetNgModuleScope"](AppModule, {
    declarations: [_app_component__WEBPACK_IMPORTED_MODULE_6__.AppComponent],
    imports: [_core_auth_auth_module__WEBPACK_IMPORTED_MODULE_10__.AuthModule, _angular_platform_browser__WEBPACK_IMPORTED_MODULE_2__.BrowserModule, _angular_platform_browser_animations__WEBPACK_IMPORTED_MODULE_22__.BrowserAnimationsModule, _core_shared_shared_module__WEBPACK_IMPORTED_MODULE_8__.PlayGoSharedModule, _ngx_translate_core__WEBPACK_IMPORTED_MODULE_9__.TranslateModule, _ionic_angular__WEBPACK_IMPORTED_MODULE_5__.IonicModule, _ionic_storage_angular__WEBPACK_IMPORTED_MODULE_20__.IonicStorageModule, _app_routing_module__WEBPACK_IMPORTED_MODULE_7__.AppRoutingModule]
  });
})();
const useMock = () => (0,_angular_core__WEBPACK_IMPORTED_MODULE_1__.isDevMode)() && getPlatformId(window) === 'web';
// copied from capacitor core source (it is not exported)
const getPlatformId = win => {
  if (win?.androidBridge) {
    return 'android';
  } else if (win?.webkit?.messageHandlers?.bridge) {
    return 'ios';
  } else {
    return 'web';
  }
};

/***/ }),

/***/ 52493:
/*!***********************************************************************************!*\
  !*** ./src/app/core/api/generated-hsc/controllers/teamStatsController.service.ts ***!
  \***********************************************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   TeamStatsControllerService: () => (/* binding */ TeamStatsControllerService)
/* harmony export */ });
/* harmony import */ var src_environments_environment__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! src/environments/environment */ 45312);
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @angular/core */ 34205);
/* harmony import */ var _angular_common_http__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @angular/common/http */ 63855);
var _staticBlock;
/**
 * Play&Go HSC Project
 * No description provided (generated by Swagger Codegen https://github.com/swagger-api/swagger-codegen)
 *
 * OpenAPI spec version: 2.0
 * Contact: info@smartcommunitylab.it
 *
 * NOTE: This class is auto generated by the swagger code generator program.
 * https://github.com/swagger-api/swagger-codegen.git
 * Do not edit the class manually.
 */



class TeamStatsControllerService {
  constructor(http) {
    this.http = http;
  }
  /**
   * geGroupCampaingPlacingByTransportMode
   *
   * @param campaignId campaignId
   * @param groupId groupId
   * @param metric metric
   * @param mean mean
   * @param dateFrom yyyy-MM-dd
   * @param dateTo yyyy-MM-dd
   */
  geGroupCampaingPlacingByTransportModeUsingGET(args) {
    const {
      campaignId,
      groupId,
      metric,
      mean,
      dateFrom,
      dateTo
    } = args;
    return this.http.request('get', src_environments_environment__WEBPACK_IMPORTED_MODULE_0__.environment.serverUrl.hscApi + `/playandgo-hsc/api/data/campaign/placing/group/transport`, {
      params: removeNullOrUndefined({
        campaignId,
        groupId,
        metric,
        mean,
        dateFrom,
        dateTo
      })
    });
  }
  /**
   * getCampaignPlacingByGameGroupComparison
   *
   * @param campaignId campaignId
   * @param groupId groupId
   * @param dateFrom yyyy-MM-dd
   * @param dateTo yyyy-MM-dd
   */
  getCampaignPlacingByGameGroupComparisonUsingGET(args) {
    const {
      campaignId,
      groupId,
      dateFrom,
      dateTo
    } = args;
    return this.http.request('get', src_environments_environment__WEBPACK_IMPORTED_MODULE_0__.environment.serverUrl.hscApi + `/playandgo-hsc/api/data/campaign/placing/group/game/comparison`, {
      params: removeNullOrUndefined({
        campaignId,
        groupId,
        dateFrom,
        dateTo
      })
    });
  }
  /**
   * getCampaignPlacingByGamePlayerComparison
   *
   * @param campaignId campaignId
   * @param playerId playerId
   * @param dateFrom yyyy-MM-dd
   * @param dateTo yyyy-MM-dd
   */
  getCampaignPlacingByGamePlayerComparisonUsingGET(args) {
    const {
      campaignId,
      playerId,
      dateFrom,
      dateTo
    } = args;
    return this.http.request('get', src_environments_environment__WEBPACK_IMPORTED_MODULE_0__.environment.serverUrl.hscApi + `/playandgo-hsc/api/data/campaign/placing/player/game/comparison`, {
      params: removeNullOrUndefined({
        campaignId,
        playerId,
        dateFrom,
        dateTo
      })
    });
  }
  /**
   * getCampaingPlacingByGame
   *
   * @param campaignId campaignId
   * @param page Results page you want to retrieve (0..N)
   * @param size Number of records per page
   * @param sort Sorting option: field,[asc,desc]
   * @param dateFrom yyyy-MM-dd
   * @param dateTo yyyy-MM-dd
   */
  getCampaingPlacingByGameUsingGET(args) {
    const {
      campaignId,
      page,
      size,
      sort,
      dateFrom,
      dateTo
    } = args;
    return this.http.request('get', src_environments_environment__WEBPACK_IMPORTED_MODULE_0__.environment.serverUrl.hscApi + `/playandgo-hsc/api/data/campaign/placing/game`, {
      params: removeNullOrUndefined({
        campaignId,
        page,
        size,
        sort,
        dateFrom,
        dateTo
      })
    });
  }
  /**
   * getCampaingPlacingByTransportStats
   *
   * @param campaignId campaignId
   * @param page Results page you want to retrieve (0..N)
   * @param size Number of records per page
   * @param metric metric
   * @param sort Sorting option: field,[asc,desc]
   * @param mean mean
   * @param dateFrom yyyy-MM-dd
   * @param dateTo yyyy-MM-dd
   */
  getCampaingPlacingByTransportStatsUsingGET(args) {
    const {
      campaignId,
      page,
      size,
      metric,
      sort,
      mean,
      dateFrom,
      dateTo
    } = args;
    return this.http.request('get', src_environments_environment__WEBPACK_IMPORTED_MODULE_0__.environment.serverUrl.hscApi + `/playandgo-hsc/api/data/campaign/placing/transport`, {
      params: removeNullOrUndefined({
        campaignId,
        page,
        size,
        sort,
        metric,
        mean,
        dateFrom,
        dateTo
      })
    });
  }
  /**
   * getGroupCampaingPlacingByGame
   *
   * @param campaignId campaignId
   * @param groupId groupId
   * @param dateFrom yyyy-MM-dd
   * @param dateTo yyyy-MM-dd
   */
  getGroupCampaingPlacingByGameUsingGET(args) {
    const {
      campaignId,
      groupId,
      dateFrom,
      dateTo
    } = args;
    return this.http.request('get', src_environments_environment__WEBPACK_IMPORTED_MODULE_0__.environment.serverUrl.hscApi + `/playandgo-hsc/api/data/campaign/placing/group/game`, {
      params: removeNullOrUndefined({
        campaignId,
        groupId,
        dateFrom,
        dateTo
      })
    });
  }
  /**
   * getGroupGameStats
   *
   * @param campaignId campaignId
   * @param groupId groupId
   * @param groupMode groupMode
   * @param dateFrom yyyy-MM-dd
   * @param dateTo yyyy-MM-dd
   */
  getGroupGameStatsUsingGET(args) {
    const {
      campaignId,
      groupId,
      groupMode,
      dateFrom,
      dateTo
    } = args;
    return this.http.request('get', src_environments_environment__WEBPACK_IMPORTED_MODULE_0__.environment.serverUrl.hscApi + `/playandgo-hsc/api/data/campaign/group/game/stats`, {
      params: removeNullOrUndefined({
        campaignId,
        groupId,
        groupMode,
        dateFrom,
        dateTo
      })
    });
  }
  /**
   * getGroupTransportStatsGroupByMean
   *
   * @param campaignId campaignId
   * @param groupId groupId
   * @param metric metric
   * @param avg avg
   * @param dateFrom yyyy-MM-dd
   * @param dateTo yyyy-MM-dd
   */
  getGroupTransportStatsGroupByMeanUsingGET(args) {
    const {
      campaignId,
      groupId,
      metric,
      avg,
      dateFrom,
      dateTo
    } = args;
    return this.http.request('get', src_environments_environment__WEBPACK_IMPORTED_MODULE_0__.environment.serverUrl.hscApi + `/playandgo-hsc/api/data/campaign/transport/group/stats/mean`, {
      params: removeNullOrUndefined({
        campaignId,
        groupId,
        metric,
        avg,
        dateFrom,
        dateTo
      })
    });
  }
  /**
   * getGroupTransportStats
   *
   * @param campaignId campaignId
   * @param groupId groupId
   * @param metric metric
   * @param groupMode groupMode
   * @param mean mean
   * @param dateFrom yyyy-MM-dd
   * @param dateTo yyyy-MM-dd
   */
  getGroupTransportStatsUsingGET(args) {
    const {
      campaignId,
      groupId,
      metric,
      groupMode,
      mean,
      dateFrom,
      dateTo
    } = args;
    return this.http.request('get', src_environments_environment__WEBPACK_IMPORTED_MODULE_0__.environment.serverUrl.hscApi + `/playandgo-hsc/api/data/campaign/transport/group/stats`, {
      params: removeNullOrUndefined({
        campaignId,
        groupId,
        metric,
        groupMode,
        mean,
        dateFrom,
        dateTo
      })
    });
  }
  static #_ = _staticBlock = () => (this.ɵfac = function TeamStatsControllerService_Factory(__ngFactoryType__) {
    return new (__ngFactoryType__ || TeamStatsControllerService)(_angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵinject"](_angular_common_http__WEBPACK_IMPORTED_MODULE_2__.HttpClient));
  }, this.ɵprov = /*@__PURE__*/_angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵdefineInjectable"]({
    token: TeamStatsControllerService,
    factory: TeamStatsControllerService.ɵfac,
    providedIn: 'root'
  }));
}
_staticBlock();
function removeNullOrUndefined(obj) {
  const newObj = {};
  Object.keys(obj).forEach(key => {
    if (obj[key] != null) {
      newObj[key] = obj[key];
    }
  });
  return newObj;
}

/***/ }),

/***/ 52755:
/*!*************************************************************!*\
  !*** ./src/app/core/shared/services/auto-update.service.ts ***!
  \*************************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   AutoUpdateService: () => (/* binding */ AutoUpdateService)
/* harmony export */ });
/* harmony import */ var _Users_smartcommunitylab_Desktop_newWork_playAndGo_playGo_node_modules_babel_runtime_helpers_esm_asyncToGenerator_js__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./node_modules/@babel/runtime/helpers/esm/asyncToGenerator.js */ 89204);
/* harmony import */ var _capgo_capacitor_updater__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @capgo/capacitor-updater */ 21597);
/* harmony import */ var _capacitor_app__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @capacitor/app */ 59326);
/* harmony import */ var _capacitor_core__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @capacitor/core */ 14070);
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! @angular/core */ 34205);

var _staticBlock;




class AutoUpdateService {
  constructor() {}
  init() {
    var _this = this;
    return (0,_Users_smartcommunitylab_Desktop_newWork_playAndGo_playGo_node_modules_babel_runtime_helpers_esm_asyncToGenerator_js__WEBPACK_IMPORTED_MODULE_0__["default"])(function* () {
      if (_capacitor_core__WEBPACK_IMPORTED_MODULE_3__.Capacitor.getPlatform() === 'web') {
        console.log('AutoUpdate: skipped on web platform');
        return;
      }
      try {
        yield _capgo_capacitor_updater__WEBPACK_IMPORTED_MODULE_1__.CapacitorUpdater.notifyAppReady();
        console.log('✅ Capgo: App notificata come pronta!');
        const current = yield _capgo_capacitor_updater__WEBPACK_IMPORTED_MODULE_1__.CapacitorUpdater.current();
        console.log('📦 Versione corrente:', current);
        yield _this.checkForUpdate();
      } catch (error) {
        console.error('❌ AutoUpdate init error:', error);
      }
    })();
  }
  checkForUpdate() {
    return (0,_Users_smartcommunitylab_Desktop_newWork_playAndGo_playGo_node_modules_babel_runtime_helpers_esm_asyncToGenerator_js__WEBPACK_IMPORTED_MODULE_0__["default"])(function* () {
      try {
        console.log('🔍 Controllo aggiornamenti...');
        const appInfo = yield _capacitor_app__WEBPACK_IMPORTED_MODULE_2__.App.getInfo();
        console.log('App version:', appInfo.version);
        const update = yield _capgo_capacitor_updater__WEBPACK_IMPORTED_MODULE_1__.CapacitorUpdater.download({
          url: 'http://10.30.46.226:8000/api/update',
          version: appInfo.version
        });
        console.log('📥 Update scaricato:', update);
        if (update.status === 'success') {
          yield _capgo_capacitor_updater__WEBPACK_IMPORTED_MODULE_1__.CapacitorUpdater.set({
            id: update.id
          });
          console.log('✅ Update impostato, riavvia app per applicarlo');
          // Opzionale: ricarica automaticamente
          // await CapacitorUpdater.reload();
        } else {
          console.log('ℹ️ Nessun aggiornamento disponibile');
        }
      } catch (error) {
        console.error('❌ Errore controllo update:', error);
      }
    })();
  }
  listBundles() {
    return (0,_Users_smartcommunitylab_Desktop_newWork_playAndGo_playGo_node_modules_babel_runtime_helpers_esm_asyncToGenerator_js__WEBPACK_IMPORTED_MODULE_0__["default"])(function* () {
      const bundles = yield _capgo_capacitor_updater__WEBPACK_IMPORTED_MODULE_1__.CapacitorUpdater.list();
      console.log('📦 Bundle installati:', bundles);
    })();
  }
  getCurrentBundle() {
    return (0,_Users_smartcommunitylab_Desktop_newWork_playAndGo_playGo_node_modules_babel_runtime_helpers_esm_asyncToGenerator_js__WEBPACK_IMPORTED_MODULE_0__["default"])(function* () {
      const current = yield _capgo_capacitor_updater__WEBPACK_IMPORTED_MODULE_1__.CapacitorUpdater.current();
      return {
        id: current.bundle.id,
        version: current.bundle.version,
        downloaded: current.bundle.downloaded,
        checksum: current.bundle.checksum,
        status: current.bundle.status
      };
    })();
  }
  deleteOldBundles() {
    return (0,_Users_smartcommunitylab_Desktop_newWork_playAndGo_playGo_node_modules_babel_runtime_helpers_esm_asyncToGenerator_js__WEBPACK_IMPORTED_MODULE_0__["default"])(function* () {
      const bundles = yield _capgo_capacitor_updater__WEBPACK_IMPORTED_MODULE_1__.CapacitorUpdater.list();
      const current = yield _capgo_capacitor_updater__WEBPACK_IMPORTED_MODULE_1__.CapacitorUpdater.current();
      for (const bundle of bundles.bundles) {
        if (bundle.id !== current.bundle.id && bundle.id !== 'builtin') {
          yield _capgo_capacitor_updater__WEBPACK_IMPORTED_MODULE_1__.CapacitorUpdater.delete({
            id: bundle.id
          });
          console.log(`🗑️ Bundle eliminato: ${bundle.id}`);
        }
      }
    })();
  }
  static #_ = _staticBlock = () => (this.ɵfac = function AutoUpdateService_Factory(__ngFactoryType__) {
    return new (__ngFactoryType__ || AutoUpdateService)();
  }, this.ɵprov = /*@__PURE__*/_angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵdefineInjectable"]({
    token: AutoUpdateService,
    factory: AutoUpdateService.ɵfac,
    providedIn: 'root'
  }));
}
_staticBlock();

/***/ }),

/***/ 54140:
/*!************************************************************************************************************************************************************!*\
  !*** ./node_modules/@stencil/core/internal/client/ lazy ^\.\/.*\.entry\.js.*$ include: \.entry\.js$ exclude: \.system\.entry\.js$ strict namespace object ***!
  \************************************************************************************************************************************************************/
/***/ ((module) => {

function webpackEmptyAsyncContext(req) {
	// Here Promise.resolve().then() is used instead of new Promise() to prevent
	// uncaught exception popping up in devtools
	return Promise.resolve().then(() => {
		var e = new Error("Cannot find module '" + req + "'");
		e.code = 'MODULE_NOT_FOUND';
		throw e;
	});
}
webpackEmptyAsyncContext.keys = () => ([]);
webpackEmptyAsyncContext.resolve = webpackEmptyAsyncContext;
webpackEmptyAsyncContext.id = 54140;
module.exports = webpackEmptyAsyncContext;

/***/ }),

/***/ 56195:
/*!*********************************************************************!*\
  !*** ./src/app/core/shared/directives/parallax-header.directive.ts ***!
  \*********************************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   ParallaxDirective: () => (/* binding */ ParallaxDirective)
/* harmony export */ });
/* harmony import */ var _Users_smartcommunitylab_Desktop_newWork_playAndGo_playGo_node_modules_babel_runtime_helpers_esm_asyncToGenerator_js__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./node_modules/@babel/runtime/helpers/esm/asyncToGenerator.js */ 89204);
/* harmony import */ var _ionic_angular__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @ionic/angular */ 21507);
/* harmony import */ var to_px__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! to-px */ 40551);
/* harmony import */ var to_px__WEBPACK_IMPORTED_MODULE_2___default = /*#__PURE__*/__webpack_require__.n(to_px__WEBPACK_IMPORTED_MODULE_2__);
/* harmony import */ var _utils__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! ../utils */ 7497);
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! @angular/core */ 12481);
/* harmony import */ var _layout_header_header_directive__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! ../layout/header/header.directive */ 85039);

var _staticBlock;





class ParallaxDirective {
  constructor(headerRef, renderer, headerDirective) {
    this.headerRef = headerRef;
    this.renderer = renderer;
    this.headerDirective = headerDirective;
    this.height = 300;
    this.bgPosition = 'top';
    this.originalToolbarHeight = 0;
    this.ticking = false;
  }
  ngAfterContentInit() {
    this.init();
  }
  init() {
    var _this = this;
    return (0,_Users_smartcommunitylab_Desktop_newWork_playAndGo_playGo_node_modules_babel_runtime_helpers_esm_asyncToGenerator_js__WEBPACK_IMPORTED_MODULE_0__["default"])(function* (numOfTry = 0) {
      try {
        if (yield _this.initElements()) {
          _this.setupContentPadding();
          _this.setupImageOverlay();
          _this.setupDate();
          _this.setupPointerEventsForButtons();
          _this.setupEvents();
          _this.updateProgress();
        }
      } catch (e) {
        if (numOfTry > 5) {
          console.error('parallax error', e);
        } else {
          yield (0,_utils__WEBPACK_IMPORTED_MODULE_3__.waitMs)(100);
          yield _this.init(numOfTry + 1);
        }
      }
    }).apply(this, arguments);
  }
  get header() {
    return this.headerRef.nativeElement;
  }
  getMaxHeightWithUnits() {
    return !isNaN(+this.height) || typeof this.height === 'number' ? this.height + 'px' : this.height;
  }
  getMaxHeightInPx() {
    return to_px__WEBPACK_IMPORTED_MODULE_2___default()(this.getMaxHeightWithUnits());
  }
  initElements() {
    var _this2 = this;
    return (0,_Users_smartcommunitylab_Desktop_newWork_playAndGo_playGo_node_modules_babel_runtime_helpers_esm_asyncToGenerator_js__WEBPACK_IMPORTED_MODULE_0__["default"])(function* () {
      if (_this2.headerDirective) {
        const headerContentComponent = _this2.headerDirective.headerContentComponent.instance;
        _this2.ionToolbar = headerContentComponent.ionToolbar;
        _this2.ionTitle = headerContentComponent.ionTitle;
        _this2.ionButtons = headerContentComponent.ionButtons;
      }
      if (!_this2.ionToolbar) {
        console.error('A <ion-toolbar> element is needed inside <ion-header> or using the [appHeader] directive');
        return false;
      }
      // Stili per il titolo
      if (_this2.ionTitle) {
        _this2.renderer.setStyle(_this2.ionTitle.el.firstChild, 'margin-top', `calc(env(safe-area-inset-top) + 75px)`);
        _this2.renderer.setStyle(_this2.ionTitle.el.firstChild, 'overflow', 'hidden');
        _this2.renderer.setStyle(_this2.ionTitle.el.firstChild, 'white-space', 'normal');
        _this2.renderer.setStyle(_this2.ionTitle.el.firstChild, 'text-overflow', 'ellipsis');
        _this2.renderer.setStyle(_this2.ionTitle.el.firstChild, 'display', '-webkit-box');
        _this2.renderer.setStyle(_this2.ionTitle.el.firstChild, '-webkit-line-clamp', '2');
        _this2.renderer.setStyle(_this2.ionTitle.el.firstChild, '-webkit-box-orient', 'vertical');
      }
      // Stili per i bottoni - Ionic 8
      if (_this2.ionButtons?.first?.el) {
        const backButton = _this2.ionButtons.first.el.querySelector('ion-back-button');
        const button = _this2.ionButtons.first.el.querySelector('ion-button');
        if (backButton) {
          // Per ion-back-button, prova diversi selettori per trovare il button interno
          const backButtonShadow = backButton.shadowRoot?.querySelector('button') || backButton.shadowRoot?.querySelector('.button-native') || backButton.shadowRoot?.querySelector('[part="native"]');
          if (backButtonShadow) {
            _this2.renderer.setStyle(backButtonShadow, 'background-color', 'rgba(var(--ion-color-contrast-reversed-rgb), 0.5)');
            _this2.renderer.setStyle(backButtonShadow, 'border-radius', '50%');
            _this2.renderer.setStyle(backButtonShadow, 'width', '36px');
            _this2.renderer.setStyle(backButtonShadow, 'height', '36px');
            _this2.renderer.setStyle(backButtonShadow, 'min-width', '36px');
            _this2.renderer.setStyle(backButtonShadow, 'min-height', '36px');
          } else {
            console.warn('Cannot find back button shadow element. Available elements:', backButton.shadowRoot ? Array.from(backButton.shadowRoot.children).map(el => el.tagName) : 'No shadowRoot');
          }
          _this2.renderer.setStyle(backButton, 'width', '36px');
          _this2.renderer.setStyle(backButton, 'height', '36px');
        } else if (button) {
          // Per ion-button normale
          const buttonShadow = button.shadowRoot?.querySelector('button') || button.shadowRoot?.querySelector('.button-native') || button.shadowRoot?.querySelector('[part="native"]');
          if (buttonShadow) {
            _this2.renderer.setStyle(buttonShadow, 'background-color', 'rgba(var(--ion-color-contrast-reversed-rgb), 0.5)');
            _this2.renderer.setStyle(buttonShadow, 'border-radius', '50%');
            _this2.renderer.setStyle(buttonShadow, 'width', '36px');
            _this2.renderer.setStyle(buttonShadow, 'height', '36px');
          }
        }
      }
      const parentElement = _this2.header.parentElement;
      _this2.ionContent = parentElement.querySelector('ion-content');
      if (!_this2.ionContent) {
        console.error('A <ion-content> element is needed');
        return false;
      }
      // IMPORTANTE: In Ionic 8, usa getScrollElement() invece di accedere al shadowRoot
      try {
        _this2.innerScroll = yield _this2.ionContent.getScrollElement();
      } catch (e) {
        console.error('Cannot get scroll element', e);
        return false;
      }
      if (!_this2.innerScroll) {
        console.error('innerScroll is null');
        return false;
      }
      _this2.originalToolbarHeight = _this2.ionToolbar.el.offsetHeight;
      // Accesso al shadow DOM della toolbar - Ionic 8
      const toolbarShadowRoot = _this2.ionToolbar.el.shadowRoot;
      if (!toolbarShadowRoot) {
        console.error('Cannot access toolbar shadow root');
        return false;
      }
      // In Ionic 8, prova questi selettori
      _this2.toolbarContainer = toolbarShadowRoot.querySelector('.toolbar-container');
      _this2.toolbarBackground = toolbarShadowRoot.querySelector('.toolbar-background');
      // Fallback: se non trova .toolbar-background, prova altri selettori
      if (!_this2.toolbarBackground) {
        // Prova con il div principale
        _this2.toolbarBackground = toolbarShadowRoot.querySelector('div');
        console.warn('Using fallback for toolbar background');
      }
      if (!_this2.toolbarContainer) {
        // Crea un container se non esiste
        _this2.toolbarContainer = _this2.renderer.createElement('div');
        _this2.renderer.addClass(_this2.toolbarContainer, 'toolbar-container-custom');
        const firstChild = toolbarShadowRoot.firstElementChild;
        if (firstChild) {
          _this2.renderer.insertBefore(toolbarShadowRoot, _this2.toolbarContainer, firstChild);
          _this2.renderer.appendChild(_this2.toolbarContainer, firstChild);
        }
        console.warn('Created custom toolbar container');
      }
      if (!_this2.toolbarBackground) {
        console.error('Cannot find toolbar background element');
        return false;
      }
      // Imposta il colore
      _this2.color = _this2.color || window.getComputedStyle(_this2.toolbarBackground).backgroundColor;
      // Imposta l'allineamento del container
      if (_this2.toolbarContainer) {
        _this2.renderer.setStyle(_this2.toolbarContainer, 'align-items', 'baseline');
      }
      return true;
    })();
  }
  setupPointerEventsForButtons() {
    this.renderer.setStyle(this.header, 'pointer-events', 'none');
    this.ionToolbar.el.querySelectorAll('ion-buttons').forEach(item => this.renderer.setStyle(item, 'pointer-events', 'all'));
  }
  setupContentPadding() {
    const coverHeightPx = this.getMaxHeightInPx();
    this.renderer.setStyle(this.header, 'position', 'absolute');
    // In Ionic 8, imposta il padding direttamente sul content
    this.renderer.setStyle(this.innerScroll, 'padding-top', `${coverHeightPx}px`);
  }
  setupDate() {
    if (!this.text) return;
    this.textDateOverlay = this.renderer.createElement('div');
    this.textDateOverlay.innerHTML = this.text;
    this.renderer.addClass(this.textDateOverlay, 'text-overlay');
    this.renderer.setStyle(this.textDateOverlay, 'background-color', 'transparent');
    this.renderer.setStyle(this.textDateOverlay, 'text-align', 'center');
    this.renderer.setStyle(this.textDateOverlay, 'width', '100%');
    this.renderer.setStyle(this.textDateOverlay, 'position', 'absolute');
    const safeTop = parseInt(getComputedStyle(document.documentElement).getPropertyValue('--ion-safe-area-top') || '0');
    this.renderer.setStyle(this.textDateOverlay, 'bottom', `calc(${safeTop}px + 16px)`);
    // this.renderer.setStyle(this.textDateOverlay, 'bottom', '20%');
    this.renderer.setStyle(this.textDateOverlay, 'pointer-events', 'none');
    this.toolbarBackground.appendChild(this.textDateOverlay);
  }
  setupImageOverlay() {
    this.imageOverlay = this.renderer.createElement('div');
    this.renderer.addClass(this.imageOverlay, 'image-overlay');
    this.renderer.setStyle(this.imageOverlay, 'background-color', this.color);
    this.renderer.setStyle(this.imageOverlay, 'background-image', `url(${this.imageUrl || ''})`);
    this.renderer.setStyle(this.imageOverlay, 'height', '100%');
    this.renderer.setStyle(this.imageOverlay, 'width', '100%');
    this.renderer.setStyle(this.imageOverlay, 'position', 'absolute');
    this.renderer.setStyle(this.imageOverlay, 'top', '0');
    this.renderer.setStyle(this.imageOverlay, 'left', '0');
    this.renderer.setStyle(this.imageOverlay, 'background-size', 'cover');
    this.renderer.setStyle(this.imageOverlay, 'background-position', this.bgPosition);
    this.renderer.setStyle(this.imageOverlay, 'box-shadow', 'inset 0px -170px 102px -57px rgba(var(--ion-color-base-rgb),1), 4px 5px 15px 5px rgb(0 0 0 / 0%)');
    this.renderer.setStyle(this.imageOverlay, 'pointer-events', 'none');
    this.toolbarBackground.appendChild(this.imageOverlay);
  }
  setupEvents() {
    this.innerScroll.addEventListener('scroll', _event => {
      if (!this.ticking) {
        window.requestAnimationFrame(() => {
          this.updateProgress();
          this.ticking = false;
        });
      }
      this.ticking = true;
    });
  }
  updateProgress() {
    const h = this.getMaxHeightInPx();
    const progress = this.calcProgress(this.innerScroll, h);
    this.progressLayerHeight(progress);
    this.progressLayerOpacity(progress);
    this.progressLayerBackground(progress);
  }
  progressLayerHeight(progress) {
    const h = Math.max(this.getMaxHeightInPx() * (1 - progress), this.originalToolbarHeight);
    if (this.toolbarContainer) {
      this.renderer.setStyle(this.toolbarContainer, 'height', `${h}px`);
    }
    this.renderer.setStyle(this.ionToolbar.el, 'height', `${h}px`);
    this.renderer.setStyle(this.imageOverlay, 'height', '100%');
  }
  progressLayerOpacity(progress) {
    const op = 1 - progress;
    this.renderer.setStyle(this.imageOverlay, 'opacity', op);
    if (this.textDateOverlay) {
      this.renderer.setStyle(this.textDateOverlay, 'opacity', op);
    }
    if (this.ionTitle?.el?.firstChild) {
      this.renderer.setStyle(this.ionTitle.el.firstChild, 'margin-top', `calc(env(safe-area-inset-top) + ${(1 - progress) * 75}px)`);
    }
  }
  progressLayerBackground(progress) {
    const op = Math.max(0, 0.5 - progress);
    if (this.ionButtons?.first?.el) {
      const backButton = this.ionButtons.first.el.querySelector('ion-back-button');
      const button = this.ionButtons.first.el.querySelector('ion-button');
      if (backButton) {
        const backButtonShadow = backButton.shadowRoot?.querySelector('button') || backButton.shadowRoot?.querySelector('.button-native') || backButton.shadowRoot?.querySelector('[part="native"]');
        if (backButtonShadow) {
          this.renderer.setStyle(backButtonShadow, 'background-color', `rgba(var(--ion-color-contrast-reversed-rgb), ${op})`);
        }
      } else if (button) {
        const buttonShadow = button.shadowRoot?.querySelector('button') || button.shadowRoot?.querySelector('.button-native') || button.shadowRoot?.querySelector('[part="native"]');
        if (buttonShadow) {
          this.renderer.setStyle(buttonShadow, 'background-color', `rgba(var(--ion-color-contrast-reversed-rgb), ${op})`);
        }
      }
    }
  }
  calcProgress(scrollingElement, maxHeight) {
    const scroll = +scrollingElement.scrollTop;
    const progress = Math.min(1, Math.max(0, scroll / maxHeight));
    return progress;
  }
  static #_ = _staticBlock = () => (this.ɵfac = function ParallaxDirective_Factory(__ngFactoryType__) {
    return new (__ngFactoryType__ || ParallaxDirective)(_angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵdirectiveInject"](_angular_core__WEBPACK_IMPORTED_MODULE_4__.ElementRef), _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵdirectiveInject"](_angular_core__WEBPACK_IMPORTED_MODULE_4__.Renderer2), _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵdirectiveInject"](_layout_header_header_directive__WEBPACK_IMPORTED_MODULE_5__.HeaderDirective, 8));
  }, this.ɵdir = /*@__PURE__*/_angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵdefineDirective"]({
    type: ParallaxDirective,
    selectors: [["ion-header", "parallax", ""]],
    contentQueries: function ParallaxDirective_ContentQueries(rf, ctx, dirIndex) {
      if (rf & 1) {
        _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵcontentQuery"](dirIndex, _ionic_angular__WEBPACK_IMPORTED_MODULE_1__.IonTitle, 5);
        _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵcontentQuery"](dirIndex, _ionic_angular__WEBPACK_IMPORTED_MODULE_1__.IonToolbar, 5);
        _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵcontentQuery"](dirIndex, _ionic_angular__WEBPACK_IMPORTED_MODULE_1__.IonButtons, 4);
      }
      if (rf & 2) {
        let _t;
        _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵqueryRefresh"](_t = _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵloadQuery"]()) && (ctx.ionTitle = _t.first);
        _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵqueryRefresh"](_t = _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵloadQuery"]()) && (ctx.ionToolbar = _t.first);
        _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵqueryRefresh"](_t = _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵloadQuery"]()) && (ctx.ionButtons = _t);
      }
    },
    inputs: {
      imageUrl: "imageUrl",
      text: "text",
      logo: "logo",
      color: "color",
      height: "height",
      bgPosition: "bgPosition"
    },
    standalone: false
  }));
}
_staticBlock();

/***/ }),

/***/ 58223:
/*!**************************************************************************************************!*\
  !*** ./src/app/core/shared/campaigns/main-campaign-stat/limit-status/limit-modal/limit.modal.ts ***!
  \**************************************************************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   LimitModalPage: () => (/* binding */ LimitModalPage)
/* harmony export */ });
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! @angular/core */ 12481);
/* harmony import */ var _ionic_angular__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @ionic/angular */ 21507);
/* harmony import */ var _ngx_translate_core__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @ngx-translate/core */ 48503);
/* harmony import */ var _pipes_languageMap_pipe__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! ../../../../pipes/languageMap.pipe */ 69618);
var _staticBlock;




class LimitModalPage {
  constructor(modalController) {
    this.modalController = modalController;
  }
  ngOnInit() {}
  close() {
    this.modalController.dismiss(false);
  }
  static #_ = _staticBlock = () => (this.ɵfac = function LimitModalPage_Factory(__ngFactoryType__) {
    return new (__ngFactoryType__ || LimitModalPage)(_angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵdirectiveInject"](_ionic_angular__WEBPACK_IMPORTED_MODULE_1__.ModalController));
  }, this.ɵcmp = /*@__PURE__*/_angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵdefineComponent"]({
    type: LimitModalPage,
    selectors: [["app-limit-modal"]],
    standalone: false,
    decls: 16,
    vars: 11,
    consts: [["color", "playgo"], [1, "ion-text-center"], [1, "limit-title"], [1, "limit-text", 3, "innerHtml"], ["color", "playgo", 1, "ion-text-center"], ["expand", "block", "color", "light", 3, "click"]],
    template: function LimitModalPage_Template(rf, ctx) {
      if (rf & 1) {
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](0, "ion-content", 0)(1, "ion-grid")(2, "ion-row")(3, "ion-col", 1)(4, "div", 2);
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵtext"](5);
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵpipe"](6, "translate");
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]()()();
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](7, "ion-row")(8, "ion-col");
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelement"](9, "div", 3);
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵpipe"](10, "languageMap");
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵpipe"](11, "translate");
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]()()()();
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](12, "ion-footer", 4)(13, "ion-button", 5);
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵlistener"]("click", function LimitModalPage_Template_ion_button_click_13_listener() {
          return ctx.close();
        });
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵtext"](14);
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵpipe"](15, "translate");
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]()();
      }
      if (rf & 2) {
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵadvance"](5);
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵtextInterpolate"](_angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵpipeBind1"](6, 3, "campaigns.detail.limits_title"));
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵadvance"](4);
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵproperty"]("innerHtml", (ctx.campaign == null ? null : ctx.campaign.specificData == null ? null : ctx.campaign.specificData.limitCompanyDesc) ? _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵpipeBind1"](10, 5, ctx.campaign.specificData.limitCompanyDesc) : _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵpipeBind1"](11, 7, "campaigns.detail.limits_text"), _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵsanitizeHtml"]);
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵadvance"](5);
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵtextInterpolate"](_angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵpipeBind1"](15, 9, "modal.ok"));
      }
    },
    dependencies: [_ionic_angular__WEBPACK_IMPORTED_MODULE_1__.IonButton, _ionic_angular__WEBPACK_IMPORTED_MODULE_1__.IonCol, _ionic_angular__WEBPACK_IMPORTED_MODULE_1__.IonContent, _ionic_angular__WEBPACK_IMPORTED_MODULE_1__.IonFooter, _ionic_angular__WEBPACK_IMPORTED_MODULE_1__.IonGrid, _ionic_angular__WEBPACK_IMPORTED_MODULE_1__.IonRow, _ngx_translate_core__WEBPACK_IMPORTED_MODULE_2__.TranslatePipe, _pipes_languageMap_pipe__WEBPACK_IMPORTED_MODULE_3__.LanguageMapPipe],
    styles: [".limit-title[_ngcontent-%COMP%] {\n  font-weight: bold;\n  margin: 8px;\n}\n\n.limit-sub[_ngcontent-%COMP%] {\n  font-weight: bold;\n  margin: 8px 0px 0px 0px;\n}\n\n.limit-text[_ngcontent-%COMP%] {\n  margin: 8px;\n}\n\nion-footer[_ngcontent-%COMP%] {\n  background: var(--ion-color-playgo);\n}\n/*# sourceMappingURL=data:application/json;charset=utf-8;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbIndlYnBhY2s6Ly8uL3NyYy9hcHAvY29yZS9zaGFyZWQvY2FtcGFpZ25zL21haW4tY2FtcGFpZ24tc3RhdC9saW1pdC1zdGF0dXMvbGltaXQtbW9kYWwvbGltaXQubW9kYWwuc2NzcyJdLCJuYW1lcyI6W10sIm1hcHBpbmdzIjoiQUFBQTtFQUNFLGlCQUFBO0VBQ0EsV0FBQTtBQUNGOztBQUNBO0VBQ0UsaUJBQUE7RUFDQSx1QkFBQTtBQUVGOztBQUFBO0VBQ0UsV0FBQTtBQUdGOztBQURBO0VBQ0UsbUNBQUE7QUFJRiIsInNvdXJjZXNDb250ZW50IjpbIi5saW1pdC10aXRsZSB7XG4gIGZvbnQtd2VpZ2h0OiBib2xkO1xuICBtYXJnaW46IDhweDtcbn1cbi5saW1pdC1zdWIge1xuICBmb250LXdlaWdodDogYm9sZDtcbiAgbWFyZ2luOiA4cHggMHB4IDBweCAwcHg7XG59XG4ubGltaXQtdGV4dCB7XG4gIG1hcmdpbjogOHB4O1xufVxuaW9uLWZvb3RlciB7XG4gIGJhY2tncm91bmQ6IHZhcigtLWlvbi1jb2xvci1wbGF5Z28pO1xufVxuIl0sInNvdXJjZVJvb3QiOiIifQ== */"]
  }));
}
_staticBlock();

/***/ }),

/***/ 58297:
/*!************************************************************************!*\
  !*** ./src/app/core/shared/globalization/i18n/check-dictio-runtime.ts ***!
  \************************************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
var _assets_i18n_it_json__WEBPACK_IMPORTED_MODULE_2___namespace_cache;
var _assets_i18n_en_json__WEBPACK_IMPORTED_MODULE_3___namespace_cache;
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   assertDictionariesAreEqualInRuntime: () => (/* binding */ assertDictionariesAreEqualInRuntime)
/* harmony export */ });
/* harmony import */ var lodash_es__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! lodash-es */ 92434);
/* harmony import */ var lodash_es__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! lodash-es */ 20317);
/* harmony import */ var _assets_i18n_it_json__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! ../../../../../assets/i18n/it.json */ 78355);
/* harmony import */ var _assets_i18n_en_json__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! ../../../../../assets/i18n/en.json */ 27473);



function assertDictionariesAreEqualInRuntime() {
  const itKeys = allKeys(getJsonModuleContent(/*#__PURE__*/ (_assets_i18n_it_json__WEBPACK_IMPORTED_MODULE_2___namespace_cache || (_assets_i18n_it_json__WEBPACK_IMPORTED_MODULE_2___namespace_cache = __webpack_require__.t(_assets_i18n_it_json__WEBPACK_IMPORTED_MODULE_2__, 2)))));
  const enKeys = allKeys(getJsonModuleContent(/*#__PURE__*/ (_assets_i18n_en_json__WEBPACK_IMPORTED_MODULE_3___namespace_cache || (_assets_i18n_en_json__WEBPACK_IMPORTED_MODULE_3___namespace_cache = __webpack_require__.t(_assets_i18n_en_json__WEBPACK_IMPORTED_MODULE_3__, 2)))));
  const areDictionariesEqual = (0,lodash_es__WEBPACK_IMPORTED_MODULE_0__["default"])(itKeys, enKeys);
  if (!areDictionariesEqual) {
    const missingKeysInIt = enKeys.filter(key => !itKeys.includes(key));
    const missingKeysInEn = itKeys.filter(key => !enKeys.includes(key));
    if (missingKeysInIt.length) {
      console.error('Dictionaries are not equal! Missing keys in italian dictionary', missingKeysInIt);
    }
    if (missingKeysInEn.length) {
      console.error('Dictionaries are not equal! Missing keys in english dictionary', missingKeysInEn);
    }
  }
}
const allKeys = (o, prefix = '', out = []) => {
  if ((0,lodash_es__WEBPACK_IMPORTED_MODULE_1__["default"])(o)) {
    Object.entries(o).forEach(([k, v]) => allKeys(v, prefix === '' ? k : `${prefix}.${k}`, out));
  } else {
    out.push(prefix);
  }
  return out;
};
function getJsonModuleContent(jsonModule) {
  // eslint-disable-next-line no-underscore-dangle
  if (jsonModule.__esModule) {
    return jsonModule.default;
  }
  return jsonModule;
}

/***/ }),

/***/ 59002:
/*!*************************************************************************************************!*\
  !*** ./src/app/core/shared/campaigns/main-campaign-stat/limit-status/limit-status.component.ts ***!
  \*************************************************************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   LimitStatusComponent: () => (/* binding */ LimitStatusComponent)
/* harmony export */ });
/* harmony import */ var _Users_smartcommunitylab_Desktop_newWork_playAndGo_playGo_node_modules_babel_runtime_helpers_esm_asyncToGenerator_js__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./node_modules/@babel/runtime/helpers/esm/asyncToGenerator.js */ 89204);
/* harmony import */ var _limit_modal_limit_modal__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ./limit-modal/limit.modal */ 58223);
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @angular/core */ 34205);
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @angular/core */ 12481);
/* harmony import */ var _ionic_angular__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! @ionic/angular */ 21507);
/* harmony import */ var _services_user_service__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! ../../../services/user.service */ 89815);
/* harmony import */ var _angular_common__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! @angular/common */ 93683);
/* harmony import */ var _ngx_translate_core__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(/*! @ngx-translate/core */ 48503);
/* harmony import */ var _pipes_localNumber_pipe__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(/*! ../../../pipes/localNumber.pipe */ 16024);

var _staticBlock;







function LimitStatusComponent_div_0_ion_col_15_Template(rf, ctx) {
  if (rf & 1) {
    const _r1 = _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵgetCurrentView"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵelementStart"](0, "ion-col", 9)(1, "ion-icon", 10);
    _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵlistener"]("click", function LimitStatusComponent_div_0_ion_col_15_Template_ion_icon_click_1_listener($event) {
      _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵrestoreView"](_r1);
      const ctx_r1 = _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵnextContext"](2);
      return _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵresetView"](ctx_r1.openLimit($event));
    });
    _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵelementEnd"]()();
  }
}
function LimitStatusComponent_div_0_ion_row_16_Template(rf, ctx) {
  if (rf & 1) {
    _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵelementStart"](0, "ion-row")(1, "ion-col", 11);
    _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵelement"](2, "ion-progress-bar", 12);
    _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵelementEnd"]()();
  }
  if (rf & 2) {
    const ctx_r1 = _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵnextContext"](2);
    _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵadvance"](2);
    _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵproperty"]("color", ctx_r1.type)("value", (ctx_r1.limitValue == null ? null : ctx_r1.limitValue.value) / ctx_r1.limitMax);
  }
}
function LimitStatusComponent_div_0_ng_template_17_Template(rf, ctx) {
  if (rf & 1) {
    _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵelementStart"](0, "ion-row")(1, "ion-col", 11);
    _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵelement"](2, "ion-progress-bar", 12);
    _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵelementEnd"]()();
  }
  if (rf & 2) {
    const ctx_r1 = _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵnextContext"](2);
    _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵadvance"](2);
    _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵproperty"]("color", ctx_r1.type)("value", 0);
  }
}
function LimitStatusComponent_div_0_Template(rf, ctx) {
  if (rf & 1) {
    _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵelementStart"](0, "div", 2)(1, "ion-grid")(2, "ion-row", 3)(3, "ion-col", 4)(4, "div", 5);
    _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵtext"](5);
    _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵelementStart"](6, "b");
    _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵtext"](7);
    _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵpipe"](8, "localNumber");
    _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵelementStart"](9, "span");
    _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵtext"](10);
    _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵelementEnd"]()()()();
    _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵelementStart"](11, "ion-col", 6)(12, "div", 5);
    _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵtext"](13);
    _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵpipe"](14, "translate");
    _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵelementEnd"]()();
    _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵtemplate"](15, LimitStatusComponent_div_0_ion_col_15_Template, 2, 0, "ion-col", 7);
    _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵelementEnd"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵtemplate"](16, LimitStatusComponent_div_0_ion_row_16_Template, 3, 2, "ion-row", 8)(17, LimitStatusComponent_div_0_ng_template_17_Template, 3, 2, "ng-template", null, 0, _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵtemplateRefExtractor"]);
    _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵelementEnd"]()();
  }
  if (rf & 2) {
    const zeroProgress_r3 = _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵreference"](18);
    const ctx_r1 = _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵnextContext"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵadvance"](5);
    _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵtextInterpolate1"]("", ctx_r1.header, " ");
    _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵadvance"](2);
    _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵtextInterpolate1"]("", _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵpipeBind2"](8, 8, ctx_r1.limitValue == null ? null : ctx_r1.limitValue.value, "0.0-1"), " ");
    _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵadvance"](3);
    _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵtextInterpolate"](ctx_r1.virtualScoreLabel);
    _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵadvance"](3);
    _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵtextInterpolate2"](" ", ctx_r1.limitMax, " ", _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵpipeBind1"](14, 11, "campaigns.homewidgets.stat.max"));
    _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵadvance"](2);
    _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵproperty"]("ngIf", ctx_r1.infoBox);
    _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵadvance"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵproperty"]("ngIf", ctx_r1.limitValue == null ? null : ctx_r1.limitValue.value)("ngIfElse", zeroProgress_r3);
  }
}
class LimitStatusComponent {
  constructor(modalController, userService) {
    this.modalController = modalController;
    this.userService = userService;
    this.campaign = undefined;
    this.limitMax = undefined;
    this.limitValue = undefined;
    this.infoBox = false;
  }
  ngOnInit() {
    // console.log('limitMax', this.limitMax, 'limitValue', this.limitValue);
  }
  openLimit(event) {
    var _this = this;
    return (0,_Users_smartcommunitylab_Desktop_newWork_playAndGo_playGo_node_modules_babel_runtime_helpers_esm_asyncToGenerator_js__WEBPACK_IMPORTED_MODULE_0__["default"])(function* () {
      event.stopPropagation();
      const language = _this.userService.getLanguage();
      const modal = yield _this.modalController.create({
        component: _limit_modal_limit_modal__WEBPACK_IMPORTED_MODULE_1__.LimitModalPage,
        componentProps: {
          campaign: _this.campaign,
          language
        },
        cssClass: 'challenge-info',
        canDismiss: true
      });
      yield modal.present();
      yield modal.onWillDismiss();
    })();
  }
  static #_ = _staticBlock = () => (this.ɵfac = function LimitStatusComponent_Factory(__ngFactoryType__) {
    return new (__ngFactoryType__ || LimitStatusComponent)(_angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵdirectiveInject"](_ionic_angular__WEBPACK_IMPORTED_MODULE_4__.ModalController), _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵdirectiveInject"](_services_user_service__WEBPACK_IMPORTED_MODULE_5__.UserService));
  }, this.ɵcmp = /*@__PURE__*/_angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵdefineComponent"]({
    type: LimitStatusComponent,
    selectors: [["app-limit-status"]],
    inputs: {
      campaign: "campaign",
      limitMax: "limitMax",
      limitValue: "limitValue",
      type: "type",
      header: "header",
      infoBox: "infoBox",
      virtualScoreLabel: "virtualScoreLabel"
    },
    standalone: false,
    decls: 1,
    vars: 1,
    consts: [["zeroProgress", ""], ["class", "ion-text-left", 4, "ngIf"], [1, "ion-text-left"], [1, "limit-text"], ["size", "8"], [1, "max-length"], ["size", "3", 1, "ion-text-end"], ["size", "1", 4, "ngIf"], [4, "ngIf", "ngIfElse"], ["size", "1"], ["name", "information-circle-outline", 1, "info-box", 3, "click"], [1, "progress-bar"], [1, "level-bar", 3, "color", "value"]],
    template: function LimitStatusComponent_Template(rf, ctx) {
      if (rf & 1) {
        _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵtemplate"](0, LimitStatusComponent_div_0_Template, 19, 13, "div", 1);
      }
      if (rf & 2) {
        _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵproperty"]("ngIf", ctx.limitMax);
      }
    },
    dependencies: [_angular_common__WEBPACK_IMPORTED_MODULE_6__.NgIf, _ionic_angular__WEBPACK_IMPORTED_MODULE_4__.IonCol, _ionic_angular__WEBPACK_IMPORTED_MODULE_4__.IonGrid, _ionic_angular__WEBPACK_IMPORTED_MODULE_4__.IonIcon, _ionic_angular__WEBPACK_IMPORTED_MODULE_4__.IonProgressBar, _ionic_angular__WEBPACK_IMPORTED_MODULE_4__.IonRow, _ngx_translate_core__WEBPACK_IMPORTED_MODULE_7__.TranslatePipe, _pipes_localNumber_pipe__WEBPACK_IMPORTED_MODULE_8__.LocalNumberPipe],
    styles: [".level-bar[_ngcontent-%COMP%] {\n  height: 16px;\n  --background: none;\n}\n\n.limit-text[_ngcontent-%COMP%] {\n  font-size: 14px;\n}\n\n.info-box[_ngcontent-%COMP%] {\n  font-size: 19px;\n  display: inline-block;\n  vertical-align: middle;\n  vertical-align: center;\n  color: var(--ion-color-company);\n}\n\n.max-length[_ngcontent-%COMP%] {\n  max-width: 200px;\n  overflow: hidden;\n  text-overflow: ellipsis;\n  white-space: nowrap;\n}\n/*# sourceMappingURL=data:application/json;charset=utf-8;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbIndlYnBhY2s6Ly8uL3NyYy9hcHAvY29yZS9zaGFyZWQvY2FtcGFpZ25zL21haW4tY2FtcGFpZ24tc3RhdC9saW1pdC1zdGF0dXMvbGltaXQtc3RhdHVzLmNvbXBvbmVudC5zY3NzIl0sIm5hbWVzIjpbXSwibWFwcGluZ3MiOiJBQUFBO0VBQ0UsWUFBQTtFQUNBLGtCQUFBO0FBQ0Y7O0FBQ0E7RUFDRSxlQUFBO0FBRUY7O0FBQUE7RUFDRSxlQUFBO0VBQ0EscUJBQUE7RUFDQSxzQkFBQTtFQUNBLHNCQUFBO0VBQ0EsK0JBQUE7QUFHRjs7QUFEQTtFQUNFLGdCQUFBO0VBQ0EsZ0JBQUE7RUFDQSx1QkFBQTtFQUNBLG1CQUFBO0FBSUYiLCJzb3VyY2VzQ29udGVudCI6WyIubGV2ZWwtYmFyIHtcbiAgaGVpZ2h0OiAxNnB4O1xuICAtLWJhY2tncm91bmQ6IG5vbmU7XG59XG4ubGltaXQtdGV4dCB7XG4gIGZvbnQtc2l6ZTogMTRweDtcbn1cbi5pbmZvLWJveCB7XG4gIGZvbnQtc2l6ZTogMTlweDtcbiAgZGlzcGxheTogaW5saW5lLWJsb2NrO1xuICB2ZXJ0aWNhbC1hbGlnbjogbWlkZGxlO1xuICB2ZXJ0aWNhbC1hbGlnbjogY2VudGVyO1xuICBjb2xvcjogdmFyKC0taW9uLWNvbG9yLWNvbXBhbnkpO1xufVxuLm1heC1sZW5ndGgge1xuICBtYXgtd2lkdGg6IDIwMHB4O1xuICBvdmVyZmxvdzogaGlkZGVuO1xuICB0ZXh0LW92ZXJmbG93OiBlbGxpcHNpcztcbiAgd2hpdGUtc3BhY2U6IG5vd3JhcDtcbn1cbiJdLCJzb3VyY2VSb290IjoiIn0= */"]
  }));
}
_staticBlock();

/***/ }),

/***/ 59621:
/*!*******************************************************!*\
  !*** ./src/app/core/shared/ui/icon/icon.component.ts ***!
  \*******************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   IconComponent: () => (/* binding */ IconComponent)
/* harmony export */ });
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! @angular/core */ 12481);
/* harmony import */ var _icon_service__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ./icon.service */ 86313);
/* harmony import */ var _angular_common__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @angular/common */ 93683);
/* harmony import */ var _ionic_angular__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @ionic/angular */ 21507);
var _staticBlock;




function IconComponent_ion_text_0_Template(rf, ctx) {
  if (rf & 1) {
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](0, "ion-text", 2)(1, "i", 3);
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵtext"](2);
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]()();
  }
  if (rf & 2) {
    const ctx_r0 = _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵnextContext"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵproperty"]("color", ctx_r0.color);
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵadvance"](2);
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵtextInterpolate"](ctx_r0.name);
  }
}
function IconComponent_ion_icon_1_Template(rf, ctx) {
  if (rf & 1) {
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelement"](0, "ion-icon", 4);
  }
  if (rf & 2) {
    const ctx_r0 = _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵnextContext"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵproperty"]("src", ctx_r0.src)("color", ctx_r0.color);
  }
}
class IconComponent {
  constructor(iconService) {
    this.iconService = iconService;
  }
  ngOnChanges() {
    this.isSvg = this.iconService.isIconSvg(this.name);
    if (this.isSvg) {
      this.src = this.iconService.getSvgSrc(this.name);
    } else {
      this.src = null;
    }
  }
  ngOnInit() {}
  static #_ = _staticBlock = () => (this.ɵfac = function IconComponent_Factory(__ngFactoryType__) {
    return new (__ngFactoryType__ || IconComponent)(_angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵdirectiveInject"](_icon_service__WEBPACK_IMPORTED_MODULE_1__.IconService));
  }, this.ɵcmp = /*@__PURE__*/_angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵdefineComponent"]({
    type: IconComponent,
    selectors: [["app-icon"]],
    inputs: {
      name: "name",
      color: "color"
    },
    standalone: false,
    features: [_angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵNgOnChangesFeature"]],
    decls: 2,
    vars: 2,
    consts: [[3, "color", 4, "ngIf"], ["class", "svg-icon", 3, "src", "color", 4, "ngIf"], [3, "color"], [1, "material-icons"], [1, "svg-icon", 3, "src", "color"]],
    template: function IconComponent_Template(rf, ctx) {
      if (rf & 1) {
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵtemplate"](0, IconComponent_ion_text_0_Template, 3, 2, "ion-text", 0)(1, IconComponent_ion_icon_1_Template, 1, 2, "ion-icon", 1);
      }
      if (rf & 2) {
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵproperty"]("ngIf", !ctx.isSvg);
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵadvance"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵproperty"]("ngIf", ctx.isSvg);
      }
    },
    dependencies: [_angular_common__WEBPACK_IMPORTED_MODULE_2__.NgIf, _ionic_angular__WEBPACK_IMPORTED_MODULE_3__.IonIcon, _ionic_angular__WEBPACK_IMPORTED_MODULE_3__.IonText],
    styles: [".material-icons[_ngcontent-%COMP%] {\n  font-size: inherit;\n}\n\n.svg-icon[_ngcontent-%COMP%] {\n  fill: currentcolor !important;\n  transform-origin: center center;\n  font-size: inherit;\n  margin-top: 0.2727272727em;\n  margin-bottom: 0.0909090909em;\n}\n\nion-text[_ngcontent-%COMP%] {\n  display: flex;\n  flex-direction: column;\n  align-items: center;\n}\n/*# sourceMappingURL=data:application/json;charset=utf-8;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbIndlYnBhY2s6Ly8uL3NyYy9hcHAvY29yZS9zaGFyZWQvdWkvaWNvbi9pY29uLmNvbXBvbmVudC5zY3NzIl0sIm5hbWVzIjpbXSwibWFwcGluZ3MiOiJBQUdBO0VBQ0Usa0JBQUE7QUFGRjs7QUFLQTtFQUNFLDZCQUFBO0VBQ0EsK0JBQUE7RUFDQSxrQkFBQTtFQUNBLDBCQUFBO0VBQ0EsNkJBQUE7QUFGRjs7QUFJQTtFQUNFLGFBQUE7RUFDQSxzQkFBQTtFQUNBLG1CQUFBO0FBREYiLCJzb3VyY2VzQ29udGVudCI6WyIvLyBpb24taWNvbiB7XG4vLyAgIHdpZHRoOiAxMDAlO1xuLy8gfVxuLm1hdGVyaWFsLWljb25zIHtcbiAgZm9udC1zaXplOiBpbmhlcml0O1xufVxuXG4uc3ZnLWljb24ge1xuICBmaWxsOiBjdXJyZW50Y29sb3IgIWltcG9ydGFudDtcbiAgdHJhbnNmb3JtLW9yaWdpbjogY2VudGVyIGNlbnRlcjtcbiAgZm9udC1zaXplOiBpbmhlcml0O1xuICBtYXJnaW4tdG9wOiBjYWxjKDZlbSAvIDIyKTtcbiAgbWFyZ2luLWJvdHRvbTogY2FsYygyZW0gLyAyMik7XG59XG5pb24tdGV4dCB7XG4gIGRpc3BsYXk6IGZsZXg7XG4gIGZsZXgtZGlyZWN0aW9uOiBjb2x1bW47XG4gIGFsaWduLWl0ZW1zOiBjZW50ZXI7XG59XG4iXSwic291cmNlUm9vdCI6IiJ9 */"]
  }));
}
_staticBlock();

/***/ }),

/***/ 60436:
/*!**************************************************************************!*\
  !*** ./src/app/core/api/generated/controllers/gameController.service.ts ***!
  \**************************************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   GameControllerService: () => (/* binding */ GameControllerService)
/* harmony export */ });
/* harmony import */ var src_environments_environment__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! src/environments/environment */ 45312);
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @angular/core */ 34205);
/* harmony import */ var _angular_common_http__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @angular/common/http */ 63855);
var _staticBlock;
/**
 * Play&Go Project
 * No description provided (generated by Swagger Codegen https://github.com/swagger-api/swagger-codegen)
 *
 * OpenAPI spec version: 2.0
 * Contact: info@smartcommunitylab.it
 *
 * NOTE: This class is auto generated by the swagger code generator program.
 * https://github.com/swagger-api/swagger-codegen.git
 * Do not edit the class manually.
 */



class GameControllerService {
  constructor(http) {
    this.http = http;
  }
  /**
   * getAllBadges
   *
   */
  getAllBadgesUsingGET() {
    return this.http.request('get', src_environments_environment__WEBPACK_IMPORTED_MODULE_0__.environment.serverUrl.api + `/playandgo/api/game/badge`, {});
  }
  /**
   * getCampaignGameStatus
   *
   * @param campaignId campaignId
   */
  getCampaignGameStatusUsingGET(campaignId) {
    return this.http.request('get', src_environments_environment__WEBPACK_IMPORTED_MODULE_0__.environment.serverUrl.api + `/playandgo/api/game/campaign`, {
      params: removeNullOrUndefined({
        campaignId
      })
    });
  }
  static #_ = _staticBlock = () => (this.ɵfac = function GameControllerService_Factory(__ngFactoryType__) {
    return new (__ngFactoryType__ || GameControllerService)(_angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵinject"](_angular_common_http__WEBPACK_IMPORTED_MODULE_2__.HttpClient));
  }, this.ɵprov = /*@__PURE__*/_angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵdefineInjectable"]({
    token: GameControllerService,
    factory: GameControllerService.ɵfac,
    providedIn: 'root'
  }));
}
_staticBlock();
function removeNullOrUndefined(obj) {
  const newObj = {};
  Object.keys(obj).forEach(key => {
    if (obj[key] != null) {
      newObj[key] = obj[key];
    }
  });
  return newObj;
}

/***/ }),

/***/ 62625:
/*!******************************************************!*\
  !*** ./src/app/core/shared/services/team.service.ts ***!
  \******************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   TeamService: () => (/* binding */ TeamService)
/* harmony export */ });
/* harmony import */ var _angular_common_http__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! @angular/common/http */ 63855);
/* harmony import */ var rxjs__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! rxjs */ 59452);
/* harmony import */ var rxjs__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! rxjs */ 61318);
/* harmony import */ var rxjs__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! rxjs */ 70271);
/* harmony import */ var rxjs__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! rxjs */ 86301);
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! @angular/core */ 34205);
/* harmony import */ var _api_generated_hsc_controllers_teamStatsController_service__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! ../../api/generated-hsc/controllers/teamStatsController.service */ 52493);
/* harmony import */ var _api_generated_hsc_controllers_playerTeamController_service__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(/*! ../../api/generated-hsc/controllers/playerTeamController.service */ 40459);
/* harmony import */ var _error_service__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(/*! ./error.service */ 46078);
var _staticBlock;






class TeamService {
  constructor(teamStatsControllerService, playerTeamController, errorService) {
    this.teamStatsControllerService = teamStatsControllerService;
    this.playerTeamController = playerTeamController;
    this.errorService = errorService;
    // public myTeam$: Observable<Campaign[]> = this.initialUserProfile$.pipe(
    //     switchMap(({ territoryId }) =>
    //       this.campaignControllerService.getCampaignsUsingGET({
    //         territoryId,
    //         onlyVisible: true,
    //       })
    //     ),
    //     shareReplay(1)
    //   );
    this.avatarDefaults = {
      avatarSmallUrl: 'assets/images/registration/people.svg',
      avatarUrl: 'assets/images/registration/people.svg'
    };
  }
  getTeamAvatar(teamId) {
    return this.playerTeamController.getTeamAvatarUsingGET(teamId).pipe((0,rxjs__WEBPACK_IMPORTED_MODULE_2__.catchError)(error => {
      if (error instanceof _angular_common_http__WEBPACK_IMPORTED_MODULE_0__.HttpErrorResponse && (error?.status === 404 || error?.status === 400 || error?.status === 500) && error?.error?.ex === 'avatar not found') {
        return (0,rxjs__WEBPACK_IMPORTED_MODULE_1__.of)(this.avatarDefaults);
      }
      // we do not want to block app completely.
      this.errorService.handleError(error, 'normal');
      return (0,rxjs__WEBPACK_IMPORTED_MODULE_1__.of)(this.avatarDefaults);
    }), (0,rxjs__WEBPACK_IMPORTED_MODULE_3__.map)(avatar => ({
      ...this.avatarDefaults,
      ...this.timestampAvatarUrls(avatar)
    })));
  }
  timestampAvatarUrls(avatar) {
    if (avatar) {
      return {
        ...avatar,
        avatarUrl: this.timestampUrl(avatar.avatarUrl),
        avatarSmallUrl: this.timestampUrl(avatar.avatarSmallUrl)
      };
    } else {
      return {
        ...this.avatarDefaults
      };
    }
  }
  timestampUrl(url) {
    if (!url || url.includes('?')) {
      return url;
    }
    return url + '?t=' + new Date().getTime();
  }
  getTeamsForSubscription(idInitiative) {
    return this.playerTeamController.getPublicTeamsInfoUsingGET(idInitiative);
  }
  getTeamAvg(campaignId, groupId, metric, avg, dateFrom, dateTo) {
    return this.teamStatsControllerService.getGroupTransportStatsGroupByMeanUsingGET({
      campaignId,
      groupId,
      metric,
      avg,
      dateFrom,
      dateTo
    });
  }
  getTeamPlacing(campaignId, groupId, dateFrom, dateTo) {
    return this.teamStatsControllerService.getGroupCampaingPlacingByGameUsingGET({
      campaignId,
      groupId,
      dateFrom,
      dateTo
    });
  }
  getGroupStat(campaignId, groupId, metric, groupMode, mean, dateFrom, dateTo) {
    return this.teamStatsControllerService.getGroupTransportStatsUsingGET({
      campaignId,
      groupId,
      metric,
      groupMode,
      mean,
      dateFrom,
      dateTo
    });
  }
  getGroupGameStats(campaignId, groupId, groupMode, dateFrom, dateTo) {
    return this.teamStatsControllerService.getGroupGameStatsUsingGET({
      campaignId,
      groupId,
      groupMode,
      dateFrom,
      dateTo
    });
  }
  getMyTeam(campaignId, groupId) {
    return this.playerTeamController.getMyTeamInfoUsingGET({
      initiativeId: campaignId,
      teamId: groupId
    }).pipe((0,rxjs__WEBPACK_IMPORTED_MODULE_4__.shareReplay)(1));
  }
  getPublicTeam(campaignId, groupId) {
    return this.playerTeamController.getPublicTeamInfoUsingGET({
      initiativeId: campaignId,
      teamId: groupId
    }).pipe((0,rxjs__WEBPACK_IMPORTED_MODULE_4__.shareReplay)(1));
  }
  getProgressionTeam(campaignId, groupId, dateFrom, dateTo) {
    return this.teamStatsControllerService.getCampaignPlacingByGameGroupComparisonUsingGET({
      campaignId,
      groupId,
      dateFrom,
      dateTo
    }).pipe((0,rxjs__WEBPACK_IMPORTED_MODULE_4__.shareReplay)(1));
  }
  getProgressionPlayer(campaignId, playerId, dateFrom, dateTo) {
    return this.teamStatsControllerService.getCampaignPlacingByGamePlayerComparisonUsingGET({
      campaignId,
      playerId,
      dateFrom,
      dateTo
    }).pipe((0,rxjs__WEBPACK_IMPORTED_MODULE_4__.shareReplay)(1));
  }
  static #_ = _staticBlock = () => (this.ɵfac = function TeamService_Factory(__ngFactoryType__) {
    return new (__ngFactoryType__ || TeamService)(_angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵinject"](_api_generated_hsc_controllers_teamStatsController_service__WEBPACK_IMPORTED_MODULE_6__.TeamStatsControllerService), _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵinject"](_api_generated_hsc_controllers_playerTeamController_service__WEBPACK_IMPORTED_MODULE_7__.PlayerTeamControllerService), _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵinject"](_error_service__WEBPACK_IMPORTED_MODULE_8__.ErrorService));
  }, this.ɵprov = /*@__PURE__*/_angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵdefineInjectable"]({
    token: TeamService,
    factory: TeamService.ɵfac,
    providedIn: 'root'
  }));
}
_staticBlock();

/***/ }),

/***/ 62657:
/*!**********************************************!*\
  !*** ./src/app/core/shared/shared.module.ts ***!
  \**********************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   PlayGoSharedModule: () => (/* binding */ PlayGoSharedModule)
/* harmony export */ });
/* harmony import */ var _campaigns_my_campaign_card_my_campaign_card_component__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./campaigns/my-campaign-card/my-campaign-card.component */ 40508);
/* harmony import */ var _campaigns_public_campaign_card_public_campaign_card_component__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ./campaigns/public-campaign-card/public-campaign-card.component */ 47550);
/* harmony import */ var _pipes_localDate_pipe__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! ./pipes/localDate.pipe */ 86451);
/* harmony import */ var _pipes_localNumber_pipe__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! ./pipes/localNumber.pipe */ 16024);
/* harmony import */ var _profile_components_profile_component_profile_component__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! ./profile-components/profile-component/profile.component */ 25449);
/* harmony import */ var _services_alert_service__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! ./services/alert.service */ 67406);
/* harmony import */ var _shared_libs_module__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! ./shared-libs.module */ 64412);
/* harmony import */ var _infinite_scroll_infinite_scroll_component__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(/*! ./infinite-scroll/infinite-scroll.component */ 666);
/* harmony import */ var _layout_header_header_content_component__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(/*! ./layout/header/header-content.component */ 38325);
/* harmony import */ var _globalization_ordinal_number_ordinal_number_component__WEBPACK_IMPORTED_MODULE_9__ = __webpack_require__(/*! ./globalization/ordinal-number/ordinal-number.component */ 6972);
/* harmony import */ var _campaigns_main_campaign_stat_main_campaign_stat_component__WEBPACK_IMPORTED_MODULE_10__ = __webpack_require__(/*! ./campaigns/main-campaign-stat/main-campaign-stat.component */ 79238);
/* harmony import */ var src_app_pages_home_profile_privacy_modal_privacyModal_component__WEBPACK_IMPORTED_MODULE_11__ = __webpack_require__(/*! src/app/pages/home/profile/privacy-modal/privacyModal.component */ 37026);
/* harmony import */ var _directives_parallax_header_directive__WEBPACK_IMPORTED_MODULE_12__ = __webpack_require__(/*! ./directives/parallax-header.directive */ 56195);
/* harmony import */ var _campaigns_home_widget_types_home_campaign_city_home_campaign_city_component__WEBPACK_IMPORTED_MODULE_13__ = __webpack_require__(/*! ./campaigns/home-widget-types/home-campaign-city/home-campaign-city.component */ 23797);
/* harmony import */ var _campaigns_home_widget_types_home_campaign_school_home_campaign_school_component__WEBPACK_IMPORTED_MODULE_14__ = __webpack_require__(/*! ./campaigns/home-widget-types/home-campaign-school/home-campaign-school.component */ 34127);
/* harmony import */ var _campaigns_home_widget_types_home_campaign_company_home_campaign_company_component__WEBPACK_IMPORTED_MODULE_15__ = __webpack_require__(/*! ./campaigns/home-widget-types/home-campaign-company/home-campaign-company.component */ 14055);
/* harmony import */ var _campaigns_home_widget_types_home_campaign_personal_home_campaign_personal_component__WEBPACK_IMPORTED_MODULE_16__ = __webpack_require__(/*! ./campaigns/home-widget-types/home-campaign-personal/home-campaign-personal.component */ 29639);
/* harmony import */ var _campaigns_app_widget_campaign_app_widget_campaign_component__WEBPACK_IMPORTED_MODULE_17__ = __webpack_require__(/*! ./campaigns/app-widget-campaign/app-widget-campaign.component */ 91502);
/* harmony import */ var _ui_icon_icon_component__WEBPACK_IMPORTED_MODULE_18__ = __webpack_require__(/*! ./ui/icon/icon.component */ 59621);
/* harmony import */ var _campaigns_main_campaign_stat_game_status_game_status_component__WEBPACK_IMPORTED_MODULE_19__ = __webpack_require__(/*! ./campaigns/main-campaign-stat/game-status/game-status.component */ 86208);
/* harmony import */ var _campaigns_main_campaign_stat_record_status_record_status_component__WEBPACK_IMPORTED_MODULE_20__ = __webpack_require__(/*! ./campaigns/main-campaign-stat/record-status/record-status.component */ 1284);
/* harmony import */ var _pipes_languageMap_pipe__WEBPACK_IMPORTED_MODULE_21__ = __webpack_require__(/*! ./pipes/languageMap.pipe */ 69618);
/* harmony import */ var _detail_notification_detail_notification_modal__WEBPACK_IMPORTED_MODULE_22__ = __webpack_require__(/*! ./detail-notification/detail-notification.modal */ 37572);
/* harmony import */ var _detail_notification_detail_notification_level_detail_notification_level_component__WEBPACK_IMPORTED_MODULE_23__ = __webpack_require__(/*! ./detail-notification/detail-notification-level/detail-notification-level.component */ 37814);
/* harmony import */ var _detail_notification_detail_notification_badge_detail_notification_badge_component__WEBPACK_IMPORTED_MODULE_24__ = __webpack_require__(/*! ./detail-notification/detail-notification-badge/detail-notification-badge.component */ 12498);
/* harmony import */ var _campaigns_home_widget_types_notification_badge_notification_badge_component__WEBPACK_IMPORTED_MODULE_25__ = __webpack_require__(/*! ./campaigns/home-widget-types/notification-badge/notification-badge.component */ 25211);
/* harmony import */ var _pipes_SafeHtml_pipe__WEBPACK_IMPORTED_MODULE_26__ = __webpack_require__(/*! ./pipes/SafeHtml.pipe */ 30052);
/* harmony import */ var _campaigns_app_widget_campaign_app_home_campaign_challenges_app_home_campaign_challenges_component__WEBPACK_IMPORTED_MODULE_27__ = __webpack_require__(/*! ./campaigns/app-widget-campaign/app-home-campaign-challenges/app-home-campaign-challenges.component */ 77234);
/* harmony import */ var _layout_header_header_directive__WEBPACK_IMPORTED_MODULE_28__ = __webpack_require__(/*! ./layout/header/header.directive */ 85039);
/* harmony import */ var _campaigns_app_widget_campaign_active_challenge_active_challenge_component__WEBPACK_IMPORTED_MODULE_29__ = __webpack_require__(/*! ./campaigns/app-widget-campaign/active-challenge/active-challenge.component */ 36092);
/* harmony import */ var _campaigns_challenge_users_status_challenge_users_status_component__WEBPACK_IMPORTED_MODULE_30__ = __webpack_require__(/*! ./campaigns/challenge-users-status/challenge-users-status.component */ 11454);
/* harmony import */ var _campaigns_challenge_bar_status_challenge_bar_status_component__WEBPACK_IMPORTED_MODULE_31__ = __webpack_require__(/*! ./campaigns/challenge-bar-status/challenge-bar-status.component */ 26856);
/* harmony import */ var _campaigns_main_campaign_stat_limit_status_limit_status_component__WEBPACK_IMPORTED_MODULE_32__ = __webpack_require__(/*! ./campaigns/main-campaign-stat/limit-status/limit-status.component */ 59002);
/* harmony import */ var _notification_modal_notification_modal__WEBPACK_IMPORTED_MODULE_33__ = __webpack_require__(/*! ./notification-modal/notification.modal */ 18128);
/* harmony import */ var _layout_content_content_content_component__WEBPACK_IMPORTED_MODULE_34__ = __webpack_require__(/*! ./layout/content/content-content.component */ 84661);
/* harmony import */ var _layout_content_content_directive__WEBPACK_IMPORTED_MODULE_35__ = __webpack_require__(/*! ./layout/content/content.directive */ 75855);
/* harmony import */ var _campaigns_app_company_label_app_company_label_component__WEBPACK_IMPORTED_MODULE_36__ = __webpack_require__(/*! ./campaigns/app-company-label/app-company-label.component */ 63138);
/* harmony import */ var _campaigns_main_campaign_stat_limit_status_limit_modal_limit_modal__WEBPACK_IMPORTED_MODULE_37__ = __webpack_require__(/*! ./campaigns/main-campaign-stat/limit-status/limit-modal/limit.modal */ 58223);
/* harmony import */ var _campaigns_app_company_label_company_modal_company_modal__WEBPACK_IMPORTED_MODULE_38__ = __webpack_require__(/*! ./campaigns/app-company-label/company-modal/company.modal */ 4813);
/* harmony import */ var _campaigns_home_widget_types_home_campaign_school_home_school_profile_home_school_profile_component__WEBPACK_IMPORTED_MODULE_39__ = __webpack_require__(/*! ./campaigns/home-widget-types/home-campaign-school/home-school-profile/home-school-profile.component */ 26311);
/* harmony import */ var _campaigns_home_widget_types_home_campaign_school_home_school_progression_home_school_progression_component__WEBPACK_IMPORTED_MODULE_40__ = __webpack_require__(/*! ./campaigns/home-widget-types/home-campaign-school/home-school-progression/home-school-progression.component */ 4927);
/* harmony import */ var _campaigns_home_widget_types_home_campaign_school_home_school_progression_comparison_modal_comparison_modal__WEBPACK_IMPORTED_MODULE_41__ = __webpack_require__(/*! ./campaigns/home-widget-types/home-campaign-school/home-school-progression/comparison-modal/comparison.modal */ 1146);
/* harmony import */ var _directives_enter_viewport_directive__WEBPACK_IMPORTED_MODULE_42__ = __webpack_require__(/*! ./directives/enter-viewport.directive */ 583);
/* harmony import */ var _campaigns_app_widget_campaign_app_home_campaign_challenges_app_challenge_state_app_challenge_state_component__WEBPACK_IMPORTED_MODULE_43__ = __webpack_require__(/*! ./campaigns/app-widget-campaign/app-home-campaign-challenges/app-challenge-state/app-challenge-state.component */ 35808);
/* harmony import */ var _pipes_filter_pipe__WEBPACK_IMPORTED_MODULE_44__ = __webpack_require__(/*! ./pipes/filter.pipe */ 82310);
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_45__ = __webpack_require__(/*! @angular/core */ 34205);
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_46__ = __webpack_require__(/*! @angular/core */ 12481);
var _staticBlock;














































class PlayGoSharedModule {
  static #_ = _staticBlock = () => (this.ɵfac = function PlayGoSharedModule_Factory(__ngFactoryType__) {
    return new (__ngFactoryType__ || PlayGoSharedModule)();
  }, this.ɵmod = /*@__PURE__*/_angular_core__WEBPACK_IMPORTED_MODULE_46__["ɵɵdefineNgModule"]({
    type: PlayGoSharedModule
  }), this.ɵinj = /*@__PURE__*/_angular_core__WEBPACK_IMPORTED_MODULE_45__["ɵɵdefineInjector"]({
    providers: [_services_alert_service__WEBPACK_IMPORTED_MODULE_5__.AlertService, _pipes_localDate_pipe__WEBPACK_IMPORTED_MODULE_2__.LocalDatePipe],
    imports: [_shared_libs_module__WEBPACK_IMPORTED_MODULE_6__.PlayGoSharedLibsModule, _shared_libs_module__WEBPACK_IMPORTED_MODULE_6__.PlayGoSharedLibsModule]
  }));
}
_staticBlock();
(function () {
  (typeof ngJitMode === "undefined" || ngJitMode) && _angular_core__WEBPACK_IMPORTED_MODULE_46__["ɵɵsetNgModuleScope"](PlayGoSharedModule, {
    declarations: [_campaigns_my_campaign_card_my_campaign_card_component__WEBPACK_IMPORTED_MODULE_0__.MyCampaignCardComponent, _campaigns_main_campaign_stat_main_campaign_stat_component__WEBPACK_IMPORTED_MODULE_10__.MainCampaignStatComponent, _campaigns_public_campaign_card_public_campaign_card_component__WEBPACK_IMPORTED_MODULE_1__.PublicCampaignCardComponent, _layout_header_header_content_component__WEBPACK_IMPORTED_MODULE_8__.HeaderContentComponent, _layout_header_header_directive__WEBPACK_IMPORTED_MODULE_28__.HeaderDirective, _layout_content_content_content_component__WEBPACK_IMPORTED_MODULE_34__.ContentContentComponent, _layout_content_content_directive__WEBPACK_IMPORTED_MODULE_35__.ContentDirective, _profile_components_profile_component_profile_component__WEBPACK_IMPORTED_MODULE_4__.ProfileComponent, src_app_pages_home_profile_privacy_modal_privacyModal_component__WEBPACK_IMPORTED_MODULE_11__.PrivacyModalPage, _detail_notification_detail_notification_modal__WEBPACK_IMPORTED_MODULE_22__.DetailNotificationModalPage, _pipes_localDate_pipe__WEBPACK_IMPORTED_MODULE_2__.LocalDatePipe, _pipes_localNumber_pipe__WEBPACK_IMPORTED_MODULE_3__.LocalNumberPipe, _pipes_filter_pipe__WEBPACK_IMPORTED_MODULE_44__.FilterPipe, _pipes_SafeHtml_pipe__WEBPACK_IMPORTED_MODULE_26__.SafeHtmlPipe, _pipes_languageMap_pipe__WEBPACK_IMPORTED_MODULE_21__.LanguageMapPipe, _infinite_scroll_infinite_scroll_component__WEBPACK_IMPORTED_MODULE_7__.InfiniteScrollComponent, _infinite_scroll_infinite_scroll_component__WEBPACK_IMPORTED_MODULE_7__.InfiniteScrollContentDirective, _directives_parallax_header_directive__WEBPACK_IMPORTED_MODULE_12__.ParallaxDirective, _directives_enter_viewport_directive__WEBPACK_IMPORTED_MODULE_42__.EnterTheViewportNotifierDirective, _globalization_ordinal_number_ordinal_number_component__WEBPACK_IMPORTED_MODULE_9__.OrdinalNumberComponent, _campaigns_home_widget_types_home_campaign_school_home_school_progression_comparison_modal_comparison_modal__WEBPACK_IMPORTED_MODULE_41__.ComparisonModalPage, _campaigns_home_widget_types_home_campaign_city_home_campaign_city_component__WEBPACK_IMPORTED_MODULE_13__.HomeCampaignCityComponent, _campaigns_home_widget_types_home_campaign_school_home_school_profile_home_school_profile_component__WEBPACK_IMPORTED_MODULE_39__.HomeSchoolProfiloComponent, _campaigns_home_widget_types_home_campaign_school_home_school_progression_home_school_progression_component__WEBPACK_IMPORTED_MODULE_40__.HomeSchoolProgressionComponent, _campaigns_home_widget_types_home_campaign_school_home_campaign_school_component__WEBPACK_IMPORTED_MODULE_14__.HomeCampaignSchoolComponent, _campaigns_home_widget_types_home_campaign_company_home_campaign_company_component__WEBPACK_IMPORTED_MODULE_15__.HomeCampaignCompanyComponent, _campaigns_home_widget_types_home_campaign_personal_home_campaign_personal_component__WEBPACK_IMPORTED_MODULE_16__.HomeCampaignPersonalComponent, _campaigns_home_widget_types_notification_badge_notification_badge_component__WEBPACK_IMPORTED_MODULE_25__.NotificationBadgeComponent, _campaigns_main_campaign_stat_record_status_record_status_component__WEBPACK_IMPORTED_MODULE_20__.RecordStatusComponent, _campaigns_main_campaign_stat_game_status_game_status_component__WEBPACK_IMPORTED_MODULE_19__.GameStatusComponent, _campaigns_app_widget_campaign_app_widget_campaign_component__WEBPACK_IMPORTED_MODULE_17__.WidgetComponent, _ui_icon_icon_component__WEBPACK_IMPORTED_MODULE_18__.IconComponent, _campaigns_app_widget_campaign_app_home_campaign_challenges_app_home_campaign_challenges_component__WEBPACK_IMPORTED_MODULE_27__.HomeCampaignChallengeComponent, _campaigns_app_widget_campaign_active_challenge_active_challenge_component__WEBPACK_IMPORTED_MODULE_29__.ActiveChallengeComponent, _campaigns_challenge_users_status_challenge_users_status_component__WEBPACK_IMPORTED_MODULE_30__.ChallengeUsersStatusComponent, _campaigns_challenge_bar_status_challenge_bar_status_component__WEBPACK_IMPORTED_MODULE_31__.ChallengeBarStatusComponent, _campaigns_app_widget_campaign_app_home_campaign_challenges_app_challenge_state_app_challenge_state_component__WEBPACK_IMPORTED_MODULE_43__.ChallengeStateComponent, _detail_notification_detail_notification_level_detail_notification_level_component__WEBPACK_IMPORTED_MODULE_23__.DetailNotificationLevelComponent, _detail_notification_detail_notification_badge_detail_notification_badge_component__WEBPACK_IMPORTED_MODULE_24__.DetailNotificationBadgeComponent, _campaigns_main_campaign_stat_limit_status_limit_status_component__WEBPACK_IMPORTED_MODULE_32__.LimitStatusComponent, _notification_modal_notification_modal__WEBPACK_IMPORTED_MODULE_33__.NotificationModalPage, _campaigns_app_company_label_app_company_label_component__WEBPACK_IMPORTED_MODULE_36__.CompanyLabelComponent, _campaigns_main_campaign_stat_limit_status_limit_modal_limit_modal__WEBPACK_IMPORTED_MODULE_37__.LimitModalPage, _campaigns_app_company_label_company_modal_company_modal__WEBPACK_IMPORTED_MODULE_38__.CompanyModalPage],
    imports: [_shared_libs_module__WEBPACK_IMPORTED_MODULE_6__.PlayGoSharedLibsModule],
    exports: [_shared_libs_module__WEBPACK_IMPORTED_MODULE_6__.PlayGoSharedLibsModule, _campaigns_my_campaign_card_my_campaign_card_component__WEBPACK_IMPORTED_MODULE_0__.MyCampaignCardComponent, _campaigns_main_campaign_stat_main_campaign_stat_component__WEBPACK_IMPORTED_MODULE_10__.MainCampaignStatComponent, _campaigns_public_campaign_card_public_campaign_card_component__WEBPACK_IMPORTED_MODULE_1__.PublicCampaignCardComponent, _profile_components_profile_component_profile_component__WEBPACK_IMPORTED_MODULE_4__.ProfileComponent, src_app_pages_home_profile_privacy_modal_privacyModal_component__WEBPACK_IMPORTED_MODULE_11__.PrivacyModalPage, _detail_notification_detail_notification_modal__WEBPACK_IMPORTED_MODULE_22__.DetailNotificationModalPage, _pipes_localDate_pipe__WEBPACK_IMPORTED_MODULE_2__.LocalDatePipe, _pipes_languageMap_pipe__WEBPACK_IMPORTED_MODULE_21__.LanguageMapPipe, _layout_header_header_content_component__WEBPACK_IMPORTED_MODULE_8__.HeaderContentComponent, _layout_header_header_directive__WEBPACK_IMPORTED_MODULE_28__.HeaderDirective, _layout_content_content_content_component__WEBPACK_IMPORTED_MODULE_34__.ContentContentComponent, _layout_content_content_directive__WEBPACK_IMPORTED_MODULE_35__.ContentDirective, _pipes_localNumber_pipe__WEBPACK_IMPORTED_MODULE_3__.LocalNumberPipe, _pipes_filter_pipe__WEBPACK_IMPORTED_MODULE_44__.FilterPipe, _pipes_SafeHtml_pipe__WEBPACK_IMPORTED_MODULE_26__.SafeHtmlPipe, _infinite_scroll_infinite_scroll_component__WEBPACK_IMPORTED_MODULE_7__.InfiniteScrollComponent, _infinite_scroll_infinite_scroll_component__WEBPACK_IMPORTED_MODULE_7__.InfiniteScrollContentDirective, _directives_parallax_header_directive__WEBPACK_IMPORTED_MODULE_12__.ParallaxDirective, _directives_enter_viewport_directive__WEBPACK_IMPORTED_MODULE_42__.EnterTheViewportNotifierDirective, _globalization_ordinal_number_ordinal_number_component__WEBPACK_IMPORTED_MODULE_9__.OrdinalNumberComponent, _campaigns_home_widget_types_home_campaign_school_home_school_progression_comparison_modal_comparison_modal__WEBPACK_IMPORTED_MODULE_41__.ComparisonModalPage, _campaigns_home_widget_types_home_campaign_city_home_campaign_city_component__WEBPACK_IMPORTED_MODULE_13__.HomeCampaignCityComponent, _campaigns_home_widget_types_home_campaign_school_home_school_profile_home_school_profile_component__WEBPACK_IMPORTED_MODULE_39__.HomeSchoolProfiloComponent, _campaigns_home_widget_types_home_campaign_school_home_school_progression_home_school_progression_component__WEBPACK_IMPORTED_MODULE_40__.HomeSchoolProgressionComponent, _campaigns_home_widget_types_home_campaign_school_home_campaign_school_component__WEBPACK_IMPORTED_MODULE_14__.HomeCampaignSchoolComponent, _campaigns_home_widget_types_home_campaign_company_home_campaign_company_component__WEBPACK_IMPORTED_MODULE_15__.HomeCampaignCompanyComponent, _campaigns_home_widget_types_home_campaign_personal_home_campaign_personal_component__WEBPACK_IMPORTED_MODULE_16__.HomeCampaignPersonalComponent, _campaigns_app_widget_campaign_app_home_campaign_challenges_app_challenge_state_app_challenge_state_component__WEBPACK_IMPORTED_MODULE_43__.ChallengeStateComponent, _campaigns_home_widget_types_notification_badge_notification_badge_component__WEBPACK_IMPORTED_MODULE_25__.NotificationBadgeComponent, _campaigns_main_campaign_stat_game_status_game_status_component__WEBPACK_IMPORTED_MODULE_19__.GameStatusComponent, _campaigns_main_campaign_stat_record_status_record_status_component__WEBPACK_IMPORTED_MODULE_20__.RecordStatusComponent, _campaigns_app_widget_campaign_app_widget_campaign_component__WEBPACK_IMPORTED_MODULE_17__.WidgetComponent, _ui_icon_icon_component__WEBPACK_IMPORTED_MODULE_18__.IconComponent, _campaigns_app_widget_campaign_app_home_campaign_challenges_app_home_campaign_challenges_component__WEBPACK_IMPORTED_MODULE_27__.HomeCampaignChallengeComponent, _campaigns_app_widget_campaign_active_challenge_active_challenge_component__WEBPACK_IMPORTED_MODULE_29__.ActiveChallengeComponent, _campaigns_challenge_users_status_challenge_users_status_component__WEBPACK_IMPORTED_MODULE_30__.ChallengeUsersStatusComponent, _campaigns_challenge_bar_status_challenge_bar_status_component__WEBPACK_IMPORTED_MODULE_31__.ChallengeBarStatusComponent, _detail_notification_detail_notification_level_detail_notification_level_component__WEBPACK_IMPORTED_MODULE_23__.DetailNotificationLevelComponent, _detail_notification_detail_notification_badge_detail_notification_badge_component__WEBPACK_IMPORTED_MODULE_24__.DetailNotificationBadgeComponent, _campaigns_main_campaign_stat_limit_status_limit_status_component__WEBPACK_IMPORTED_MODULE_32__.LimitStatusComponent, _notification_modal_notification_modal__WEBPACK_IMPORTED_MODULE_33__.NotificationModalPage, _campaigns_app_company_label_app_company_label_component__WEBPACK_IMPORTED_MODULE_36__.CompanyLabelComponent, _campaigns_main_campaign_stat_limit_status_limit_modal_limit_modal__WEBPACK_IMPORTED_MODULE_37__.LimitModalPage, _campaigns_app_company_label_company_modal_company_modal__WEBPACK_IMPORTED_MODULE_38__.CompanyModalPage]
  });
})();

/***/ }),

/***/ 63138:
/*!****************************************************************************************!*\
  !*** ./src/app/core/shared/campaigns/app-company-label/app-company-label.component.ts ***!
  \****************************************************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   CompanyLabelComponent: () => (/* binding */ CompanyLabelComponent)
/* harmony export */ });
/* harmony import */ var _Users_smartcommunitylab_Desktop_newWork_playAndGo_playGo_node_modules_babel_runtime_helpers_esm_asyncToGenerator_js__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./node_modules/@babel/runtime/helpers/esm/asyncToGenerator.js */ 89204);
/* harmony import */ var _company_modal_company_modal__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ./company-modal/company.modal */ 4813);
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @angular/core */ 34205);
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @angular/core */ 12481);
/* harmony import */ var _services_campaign_service__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! ../../services/campaign.service */ 76658);
/* harmony import */ var _ionic_angular__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! @ionic/angular */ 21507);
/* harmony import */ var _angular_common__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! @angular/common */ 93683);
/* harmony import */ var _ngx_translate_core__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(/*! @ngx-translate/core */ 48503);

var _staticBlock;






function CompanyLabelComponent_div_0_Template(rf, ctx) {
  if (rf & 1) {
    const _r1 = _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵgetCurrentView"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵelementStart"](0, "div")(1, "i");
    _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵtext"](2);
    _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵpipe"](3, "translate");
    _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵelementEnd"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵelementStart"](4, "span", 1);
    _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵlistener"]("click", function CompanyLabelComponent_div_0_Template_span_click_4_listener($event) {
      _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵrestoreView"](_r1);
      const ctx_r1 = _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵnextContext"]();
      return _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵresetView"](ctx_r1.openCompanyDetail($event));
    });
    _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵtext"](5);
    _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵelementEnd"]()();
  }
  if (rf & 2) {
    const ctx_r1 = _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵnextContext"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵadvance"](2);
    _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵtextInterpolate"](_angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵpipeBind1"](3, 2, "campaigns.detail.myCompany"));
    _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵadvance"](3);
    _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵtextInterpolate"](ctx_r1.userCompany.company.name);
  }
}
class CompanyLabelComponent {
  constructor(campaignService, modalController) {
    this.campaignService = campaignService;
    this.modalController = modalController;
  }
  ngOnInit() {
    this.initCompanies();
  }
  initCompanies() {
    var _this = this;
    return (0,_Users_smartcommunitylab_Desktop_newWork_playAndGo_playGo_node_modules_babel_runtime_helpers_esm_asyncToGenerator_js__WEBPACK_IMPORTED_MODULE_0__["default"])(function* () {
      try {
        _this.userCompany = yield _this.campaignService.getCompanyOfTheUser(_this.campaignContainer);
      } catch (error) {
        console.error(error);
      }
    })();
  }
  openCompanyDetail(event) {
    var _this2 = this;
    return (0,_Users_smartcommunitylab_Desktop_newWork_playAndGo_playGo_node_modules_babel_runtime_helpers_esm_asyncToGenerator_js__WEBPACK_IMPORTED_MODULE_0__["default"])(function* () {
      event.stopPropagation();
      const modal = yield _this2.modalController.create({
        component: _company_modal_company_modal__WEBPACK_IMPORTED_MODULE_1__.CompanyModalPage,
        componentProps: {
          userCompany: _this2.userCompany
        },
        canDismiss: true
      });
      yield modal.present();
      yield modal.onWillDismiss();
    })();
  }
  static #_ = _staticBlock = () => (this.ɵfac = function CompanyLabelComponent_Factory(__ngFactoryType__) {
    return new (__ngFactoryType__ || CompanyLabelComponent)(_angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵdirectiveInject"](_services_campaign_service__WEBPACK_IMPORTED_MODULE_4__.CampaignService), _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵdirectiveInject"](_ionic_angular__WEBPACK_IMPORTED_MODULE_5__.ModalController));
  }, this.ɵcmp = /*@__PURE__*/_angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵdefineComponent"]({
    type: CompanyLabelComponent,
    selectors: [["app-company-label"]],
    inputs: {
      campaignContainer: "campaignContainer"
    },
    standalone: false,
    decls: 1,
    vars: 1,
    consts: [[4, "ngIf"], [3, "click"]],
    template: function CompanyLabelComponent_Template(rf, ctx) {
      if (rf & 1) {
        _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵtemplate"](0, CompanyLabelComponent_div_0_Template, 6, 4, "div", 0);
      }
      if (rf & 2) {
        _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵproperty"]("ngIf", ctx.userCompany == null ? null : ctx.userCompany.company == null ? null : ctx.userCompany.company.name);
      }
    },
    dependencies: [_angular_common__WEBPACK_IMPORTED_MODULE_6__.NgIf, _ngx_translate_core__WEBPACK_IMPORTED_MODULE_7__.TranslatePipe],
    styles: ["div[_ngcontent-%COMP%] {\n  margin: 8px 16px 8px 16px;\n  text-align: right;\n}\ndiv[_ngcontent-%COMP%]   span[_ngcontent-%COMP%] {\n  font-weight: 700;\n  color: var(--ion-color-playgo);\n  margin: 8px;\n  font-style: italic;\n  text-decoration: underline;\n}\n/*# sourceMappingURL=data:application/json;charset=utf-8;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbIndlYnBhY2s6Ly8uL3NyYy9hcHAvY29yZS9zaGFyZWQvY2FtcGFpZ25zL2FwcC1jb21wYW55LWxhYmVsL2FwcC1jb21wYW55LWxhYmVsLmNvbXBvbmVudC5zY3NzIl0sIm5hbWVzIjpbXSwibWFwcGluZ3MiOiJBQUFBO0VBQ0UseUJBQUE7RUFDQSxpQkFBQTtBQUNGO0FBQUU7RUFDRSxnQkFBQTtFQUNBLDhCQUFBO0VBQ0EsV0FBQTtFQUNBLGtCQUFBO0VBQ0EsMEJBQUE7QUFFSiIsInNvdXJjZXNDb250ZW50IjpbImRpdiB7XG4gIG1hcmdpbjogOHB4IDE2cHggOHB4IDE2cHg7XG4gIHRleHQtYWxpZ246IHJpZ2h0O1xuICBzcGFuIHtcbiAgICBmb250LXdlaWdodDogNzAwO1xuICAgIGNvbG9yOiB2YXIoLS1pb24tY29sb3ItcGxheWdvKTtcbiAgICBtYXJnaW46IDhweDtcbiAgICBmb250LXN0eWxlOiBpdGFsaWM7XG4gICAgdGV4dC1kZWNvcmF0aW9uOiB1bmRlcmxpbmU7XG4gIH1cbn1cbiJdLCJzb3VyY2VSb290IjoiIn0= */"]
  }));
}
_staticBlock();

/***/ }),

/***/ 63352:
/*!*************************************************!*\
  !*** ./src/app/core/auth/auth-guard.service.ts ***!
  \*************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   AuthGuardService: () => (/* binding */ AuthGuardService)
/* harmony export */ });
/* harmony import */ var rxjs_operators__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! rxjs/operators */ 98764);
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @angular/core */ 34205);
/* harmony import */ var _auth_service__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! ./auth.service */ 35524);
/* harmony import */ var _shared_services_user_service__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! ../shared/services/user.service */ 89815);
/* harmony import */ var _ionic_angular__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! @ionic/angular */ 4059);
var _staticBlock;





class AuthGuardService {
  constructor(authService, userService, navCtrl) {
    this.authService = authService;
    this.userService = userService;
    this.navCtrl = navCtrl;
  }
  canActivate(route, state) {
    return this.authService.isAuthenticated$.pipe((0,rxjs_operators__WEBPACK_IMPORTED_MODULE_0__.tap)(isAuthenticated => {
      if (!isAuthenticated) {
        this.authService.postLogoutCleanup();
      }
      if (isAuthenticated) {
        this.userService.isUserRegistered().then(isRegistered => {
          if (isRegistered === false) {
            this.navCtrl.navigateRoot('/pages/registration');
          }
        });
      }
    }));
  }
  static #_ = _staticBlock = () => (this.ɵfac = function AuthGuardService_Factory(__ngFactoryType__) {
    return new (__ngFactoryType__ || AuthGuardService)(_angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵinject"](_auth_service__WEBPACK_IMPORTED_MODULE_2__.AuthService), _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵinject"](_shared_services_user_service__WEBPACK_IMPORTED_MODULE_3__.UserService), _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵinject"](_ionic_angular__WEBPACK_IMPORTED_MODULE_4__.NavController));
  }, this.ɵprov = /*@__PURE__*/_angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵdefineInjectable"]({
    token: AuthGuardService,
    factory: AuthGuardService.ɵfac,
    providedIn: 'root'
  }));
}
_staticBlock();

/***/ }),

/***/ 63971:
/*!****************************************************************************!*\
  !*** ./src/app/core/api/generated/controllers/playerController.service.ts ***!
  \****************************************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   PlayerControllerService: () => (/* binding */ PlayerControllerService)
/* harmony export */ });
/* harmony import */ var src_environments_environment__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! src/environments/environment */ 45312);
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @angular/core */ 34205);
/* harmony import */ var _angular_common_http__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @angular/common/http */ 63855);
var _staticBlock;
/**
 * Play&Go Project
 * No description provided (generated by Swagger Codegen https://github.com/swagger-api/swagger-codegen)
 *
 * OpenAPI spec version: 2.0
 * Contact: info@smartcommunitylab.it
 *
 * NOTE: This class is auto generated by the swagger code generator program.
 * https://github.com/swagger-api/swagger-codegen.git
 * Do not edit the class manually.
 */



class PlayerControllerService {
  constructor(http) {
    this.http = http;
  }
  /**
   * addPlayer
   *
   * @param body
   */
  addPlayerUsingPOST(body) {
    return this.http.request('post', src_environments_environment__WEBPACK_IMPORTED_MODULE_0__.environment.serverUrl.api + `/playandgo/api/player`, {
      body
    });
  }
  /**
   * checkNickname
   *
   * @param nickname nickname
   */
  checkNicknameUsingGET(nickname) {
    return this.http.request('get', src_environments_environment__WEBPACK_IMPORTED_MODULE_0__.environment.serverUrl.api + `/playandgo/api/player/nick`, {
      params: removeNullOrUndefined({
        nickname
      })
    });
  }
  /**
   * deletePlayer
   *
   * @param playerId playerId
   */
  deletePlayerUsingDELETE(playerId) {
    return this.http.request('delete', src_environments_environment__WEBPACK_IMPORTED_MODULE_0__.environment.serverUrl.api + `/playandgo/api/player/${encodeURIComponent(String(playerId))}`, {});
  }
  /**
   * getPlayerAvatar
   *
   * @param playerId playerId
   */
  getPlayerAvatarUsingGET(playerId) {
    return this.http.request('get', src_environments_environment__WEBPACK_IMPORTED_MODULE_0__.environment.serverUrl.api + `/playandgo/api/player/avatar`, {
      params: removeNullOrUndefined({
        playerId
      })
    });
  }
  /**
   * getPlayer
   *
   * @param playerId playerId
   */
  getPlayerUsingGET1(playerId) {
    return this.http.request('get', src_environments_environment__WEBPACK_IMPORTED_MODULE_0__.environment.serverUrl.api + `/playandgo/api/player/${encodeURIComponent(String(playerId))}`, {});
  }
  /**
   * getProfile
   *
   */
  getProfileUsingGET() {
    return this.http.request('get', src_environments_environment__WEBPACK_IMPORTED_MODULE_0__.environment.serverUrl.api + `/playandgo/api/player/profile`, {});
  }
  /**
   * registerPlayer
   *
   * @param body
   */
  registerPlayerUsingPOST(body) {
    return this.http.request('post', src_environments_environment__WEBPACK_IMPORTED_MODULE_0__.environment.serverUrl.api + `/playandgo/api/player/register`, {
      body
    });
  }
  /**
   * searchNickname
   *
   * @param nickname nickname
   */
  searchNicknameUsingGET(nickname) {
    return this.http.request('get', src_environments_environment__WEBPACK_IMPORTED_MODULE_0__.environment.serverUrl.api + `/playandgo/api/player/search`, {
      params: removeNullOrUndefined({
        nickname
      })
    });
  }
  /**
   * unregisterPlayer
   *
   */
  unregisterPlayerUsingPUT() {
    return this.http.request('put', src_environments_environment__WEBPACK_IMPORTED_MODULE_0__.environment.serverUrl.api + `/playandgo/api/player/unregister`, {});
  }
  /**
   * updateProfile
   *
   * @param body
   */
  updateProfileUsingPUT(body) {
    return this.http.request('put', src_environments_environment__WEBPACK_IMPORTED_MODULE_0__.environment.serverUrl.api + `/playandgo/api/player/profile`, {
      body
    });
  }
  /**
   * uploadPlayerAvatar
   *
   * @param body
   */
  uploadPlayerAvatarUsingPOST(body) {
    return this.http.request('post', src_environments_environment__WEBPACK_IMPORTED_MODULE_0__.environment.serverUrl.api + `/playandgo/api/player/avatar`, {
      body
    });
  }
  static #_ = _staticBlock = () => (this.ɵfac = function PlayerControllerService_Factory(__ngFactoryType__) {
    return new (__ngFactoryType__ || PlayerControllerService)(_angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵinject"](_angular_common_http__WEBPACK_IMPORTED_MODULE_2__.HttpClient));
  }, this.ɵprov = /*@__PURE__*/_angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵdefineInjectable"]({
    token: PlayerControllerService,
    factory: PlayerControllerService.ɵfac,
    providedIn: 'root'
  }));
}
_staticBlock();
function removeNullOrUndefined(obj) {
  const newObj = {};
  Object.keys(obj).forEach(key => {
    if (obj[key] != null) {
      newObj[key] = obj[key];
    }
  });
  return newObj;
}

/***/ }),

/***/ 64412:
/*!***************************************************!*\
  !*** ./src/app/core/shared/shared-libs.module.ts ***!
  \***************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   PlayGoSharedLibsModule: () => (/* binding */ PlayGoSharedLibsModule)
/* harmony export */ });
/* harmony import */ var _angular_common__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! @angular/common */ 93683);
/* harmony import */ var _angular_forms__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @angular/forms */ 34456);
/* harmony import */ var _ionic_angular__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @ionic/angular */ 21507);
/* harmony import */ var _ngx_translate_core__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @ngx-translate/core */ 48503);
/* harmony import */ var ionic_selectable__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! ionic-selectable */ 56885);
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! @angular/core */ 34205);
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! @angular/core */ 12481);
var _staticBlock;






class PlayGoSharedLibsModule {
  static #_ = _staticBlock = () => (this.ɵfac = function PlayGoSharedLibsModule_Factory(__ngFactoryType__) {
    return new (__ngFactoryType__ || PlayGoSharedLibsModule)();
  }, this.ɵmod = /*@__PURE__*/_angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵdefineNgModule"]({
    type: PlayGoSharedLibsModule
  }), this.ɵinj = /*@__PURE__*/_angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵdefineInjector"]({
    imports: [_angular_common__WEBPACK_IMPORTED_MODULE_0__.CommonModule, _angular_forms__WEBPACK_IMPORTED_MODULE_1__.FormsModule, _angular_forms__WEBPACK_IMPORTED_MODULE_1__.ReactiveFormsModule, _ionic_angular__WEBPACK_IMPORTED_MODULE_2__.IonicModule, _ngx_translate_core__WEBPACK_IMPORTED_MODULE_3__.TranslateModule,
    // 👇 importa standalone components con .import() (Angular 15+)
    ionic_selectable__WEBPACK_IMPORTED_MODULE_4__.IonicSelectableComponent, _angular_common__WEBPACK_IMPORTED_MODULE_0__.CommonModule, _angular_forms__WEBPACK_IMPORTED_MODULE_1__.FormsModule, _angular_forms__WEBPACK_IMPORTED_MODULE_1__.ReactiveFormsModule, _ionic_angular__WEBPACK_IMPORTED_MODULE_2__.IonicModule, _ngx_translate_core__WEBPACK_IMPORTED_MODULE_3__.TranslateModule]
  }));
}
_staticBlock();
(function () {
  (typeof ngJitMode === "undefined" || ngJitMode) && _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵsetNgModuleScope"](PlayGoSharedLibsModule, {
    imports: [_angular_common__WEBPACK_IMPORTED_MODULE_0__.CommonModule, _angular_forms__WEBPACK_IMPORTED_MODULE_1__.FormsModule, _angular_forms__WEBPACK_IMPORTED_MODULE_1__.ReactiveFormsModule, _ionic_angular__WEBPACK_IMPORTED_MODULE_2__.IonicModule, _ngx_translate_core__WEBPACK_IMPORTED_MODULE_3__.TranslateModule,
    // 👇 importa standalone components con .import() (Angular 15+)
    ionic_selectable__WEBPACK_IMPORTED_MODULE_4__.IonicSelectableComponent, ionic_selectable__WEBPACK_IMPORTED_MODULE_4__.IonicSelectableItemTemplateDirective, ionic_selectable__WEBPACK_IMPORTED_MODULE_4__.IonicSelectableValueTemplateDirective, ionic_selectable__WEBPACK_IMPORTED_MODULE_4__.IonicSelectableCloseButtonTemplateDirective, ionic_selectable__WEBPACK_IMPORTED_MODULE_4__.IonicSelectableTitleTemplateDirective],
    exports: [_angular_common__WEBPACK_IMPORTED_MODULE_0__.CommonModule, _angular_forms__WEBPACK_IMPORTED_MODULE_1__.FormsModule, _angular_forms__WEBPACK_IMPORTED_MODULE_1__.ReactiveFormsModule, _ionic_angular__WEBPACK_IMPORTED_MODULE_2__.IonicModule, _ngx_translate_core__WEBPACK_IMPORTED_MODULE_3__.TranslateModule, ionic_selectable__WEBPACK_IMPORTED_MODULE_4__.IonicSelectableComponent, ionic_selectable__WEBPACK_IMPORTED_MODULE_4__.IonicSelectableItemTemplateDirective, ionic_selectable__WEBPACK_IMPORTED_MODULE_4__.IonicSelectableValueTemplateDirective, ionic_selectable__WEBPACK_IMPORTED_MODULE_4__.IonicSelectableCloseButtonTemplateDirective, ionic_selectable__WEBPACK_IMPORTED_MODULE_4__.IonicSelectableTitleTemplateDirective]
  });
})();

/***/ }),

/***/ 64692:
/*!******************************************************************************!*\
  !*** ./src/app/core/api/generated/controllers/campaignController.service.ts ***!
  \******************************************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   CampaignControllerService: () => (/* binding */ CampaignControllerService)
/* harmony export */ });
/* harmony import */ var src_environments_environment__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! src/environments/environment */ 45312);
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @angular/core */ 34205);
/* harmony import */ var _angular_common_http__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @angular/common/http */ 63855);
var _staticBlock;
/**
 * Play&Go Project
 * No description provided (generated by Swagger Codegen https://github.com/swagger-api/swagger-codegen)
 *
 * OpenAPI spec version: 2.0
 * Contact: info@smartcommunitylab.it
 *
 * NOTE: This class is auto generated by the swagger code generator program.
 * https://github.com/swagger-api/swagger-codegen.git
 * Do not edit the class manually.
 */



class CampaignControllerService {
  constructor(http) {
    this.http = http;
  }
  /**
   * addCampaign
   *
   * @param body
   */
  addCampaignUsingPOST(body) {
    return this.http.request('post', src_environments_environment__WEBPACK_IMPORTED_MODULE_0__.environment.serverUrl.api + `/playandgo/api/campaign`, {
      body
    });
  }
  /**
   * addSurvey
   *
   * @param campaignId campaignId
   * @param body
   */
  addSurveyUsingPOST(args) {
    const {
      campaignId,
      body
    } = args;
    return this.http.request('post', src_environments_environment__WEBPACK_IMPORTED_MODULE_0__.environment.serverUrl.api + `/playandgo/api/campaign/${encodeURIComponent(String(campaignId))}/survey`, {
      body
    });
  }
  /**
   * deleteCampaign
   *
   * @param campaignId campaignId
   */
  deleteCampaignUsingDELETE(campaignId) {
    return this.http.request('delete', src_environments_environment__WEBPACK_IMPORTED_MODULE_0__.environment.serverUrl.api + `/playandgo/api/campaign/${encodeURIComponent(String(campaignId))}`, {});
  }
  /**
   * deleteSurvey
   *
   * @param campaignId campaignId
   * @param name name
   */
  deleteSurveyUsingDELETE(args) {
    const {
      campaignId,
      name
    } = args;
    return this.http.request('delete', src_environments_environment__WEBPACK_IMPORTED_MODULE_0__.environment.serverUrl.api + `/playandgo/api/campaign/${encodeURIComponent(String(campaignId))}/survey`, {
      params: removeNullOrUndefined({
        name
      })
    });
  }
  /**
   * deleteWebhook
   *
   * @param campaignId campaignId
   */
  deleteWebhookUsingDELETE(campaignId) {
    return this.http.request('delete', src_environments_environment__WEBPACK_IMPORTED_MODULE_0__.environment.serverUrl.api + `/playandgo/api/campaign/${encodeURIComponent(String(campaignId))}/webhook`, {});
  }
  /**
   * getCampaign
   *
   * @param campaignId campaignId
   */
  getCampaignUsingGET(campaignId) {
    return this.http.request('get', src_environments_environment__WEBPACK_IMPORTED_MODULE_0__.environment.serverUrl.api + `/playandgo/api/campaign/${encodeURIComponent(String(campaignId))}`, {});
  }
  /**
   * getCampaignsByPlayer
   *
   * @param playerId playerId
   */
  getCampaignsByPlayerUsingGET(playerId) {
    return this.http.request('get', src_environments_environment__WEBPACK_IMPORTED_MODULE_0__.environment.serverUrl.api + `/playandgo/api/campaign/player`, {
      params: removeNullOrUndefined({
        playerId
      })
    });
  }
  /**
   * getCampaigns
   *
   * @param territoryId territoryId
   * @param type type
   * @param currentlyActive currentlyActive
   * @param onlyVisible onlyVisible
   */
  getCampaignsUsingGET(args) {
    const {
      territoryId,
      type,
      currentlyActive,
      onlyVisible
    } = args;
    return this.http.request('get', src_environments_environment__WEBPACK_IMPORTED_MODULE_0__.environment.serverUrl.api + `/playandgo/api/campaign`, {
      params: removeNullOrUndefined({
        territoryId,
        type,
        currentlyActive,
        onlyVisible
      })
    });
  }
  /**
   * getMyCampaigns
   *
   * @param currentlyActive currentlyActive
   * @param onlyVisible onlyVisible
   */
  getMyCampaignsUsingGET(args) {
    const {
      currentlyActive,
      onlyVisible
    } = args;
    return this.http.request('get', src_environments_environment__WEBPACK_IMPORTED_MODULE_0__.environment.serverUrl.api + `/playandgo/api/campaign/my`, {
      params: removeNullOrUndefined({
        currentlyActive,
        onlyVisible
      })
    });
  }
  /**
   * getWebhook
   *
   * @param campaignId campaignId
   */
  getWebhookUsingGET(campaignId) {
    return this.http.request('get', src_environments_environment__WEBPACK_IMPORTED_MODULE_0__.environment.serverUrl.api + `/playandgo/api/campaign/${encodeURIComponent(String(campaignId))}/webhook`, {});
  }
  /**
   * setWebhook
   *
   * @param campaignId campaignId
   * @param body
   */
  setWebhookUsingPOST(args) {
    const {
      campaignId,
      body
    } = args;
    return this.http.request('post', src_environments_environment__WEBPACK_IMPORTED_MODULE_0__.environment.serverUrl.api + `/playandgo/api/campaign/${encodeURIComponent(String(campaignId))}/webhook`, {
      body
    });
  }
  /**
   * subscribeCampaign
   *
   * @param campaignId campaignId
   * @param body
   */
  subscribeCampaignUsingPOST(args) {
    const {
      campaignId,
      body
    } = args;
    return this.http.request('post', src_environments_environment__WEBPACK_IMPORTED_MODULE_0__.environment.serverUrl.api + `/playandgo/api/campaign/${encodeURIComponent(String(campaignId))}/subscribe`, {
      body
    });
  }
  /**
   * unsubscribeCampaign
   *
   * @param campaignId campaignId
   */
  unsubscribeCampaignUsingPUT(campaignId) {
    return this.http.request('put', src_environments_environment__WEBPACK_IMPORTED_MODULE_0__.environment.serverUrl.api + `/playandgo/api/campaign/${encodeURIComponent(String(campaignId))}/unsubscribe`, {});
  }
  /**
   * updateCampaign
   *
   * @param body
   */
  updateCampaignUsingPUT(body) {
    return this.http.request('put', src_environments_environment__WEBPACK_IMPORTED_MODULE_0__.environment.serverUrl.api + `/playandgo/api/campaign`, {
      body
    });
  }
  /**
   * uploadCampaignBanner
   *
   * @param campaignId campaignId
   * @param body
   */
  uploadCampaignBannerUsingPOST(args) {
    const {
      campaignId,
      body
    } = args;
    return this.http.request('post', src_environments_environment__WEBPACK_IMPORTED_MODULE_0__.environment.serverUrl.api + `/playandgo/api/campaign/${encodeURIComponent(String(campaignId))}/banner`, {
      body
    });
  }
  /**
   * uploadCampaignLogo
   *
   * @param campaignId campaignId
   * @param body
   */
  uploadCampaignLogoUsingPOST(args) {
    const {
      campaignId,
      body
    } = args;
    return this.http.request('post', src_environments_environment__WEBPACK_IMPORTED_MODULE_0__.environment.serverUrl.api + `/playandgo/api/campaign/${encodeURIComponent(String(campaignId))}/logo`, {
      body
    });
  }
  /**
   * uploadRewards
   *
   * @param campaignId campaignId
   * @param body
   */
  uploadRewardsUsingPOST(args) {
    const {
      campaignId,
      body
    } = args;
    return this.http.request('post', src_environments_environment__WEBPACK_IMPORTED_MODULE_0__.environment.serverUrl.api + `/playandgo/api/campaign/${encodeURIComponent(String(campaignId))}/reward`, {
      body
    });
  }
  /**
   * uploadWeekConfs
   *
   * @param campaignId campaignId
   * @param body
   */
  uploadWeekConfsUsingPOST(args) {
    const {
      campaignId,
      body
    } = args;
    return this.http.request('post', src_environments_environment__WEBPACK_IMPORTED_MODULE_0__.environment.serverUrl.api + `/playandgo/api/campaign/${encodeURIComponent(String(campaignId))}/weekconf`, {
      body
    });
  }
  static #_ = _staticBlock = () => (this.ɵfac = function CampaignControllerService_Factory(__ngFactoryType__) {
    return new (__ngFactoryType__ || CampaignControllerService)(_angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵinject"](_angular_common_http__WEBPACK_IMPORTED_MODULE_2__.HttpClient));
  }, this.ɵprov = /*@__PURE__*/_angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵdefineInjectable"]({
    token: CampaignControllerService,
    factory: CampaignControllerService.ɵfac,
    providedIn: 'root'
  }));
}
_staticBlock();
function removeNullOrUndefined(obj) {
  const newObj = {};
  Object.keys(obj).forEach(key => {
    if (obj[key] != null) {
      newObj[key] = obj[key];
    }
  });
  return newObj;
}

/***/ }),

/***/ 65800:
/*!************************************************************!*\
  !*** ./src/app/core/shared/services/app-status.service.ts ***!
  \************************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   AppStatusService: () => (/* binding */ AppStatusService)
/* harmony export */ });
/* harmony import */ var _capacitor_app__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! @capacitor/app */ 59326);
/* harmony import */ var rxjs__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! rxjs */ 56042);
/* harmony import */ var rxjs__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! rxjs */ 95429);
/* harmony import */ var rxjs__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! rxjs */ 18537);
/* harmony import */ var rxjs__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! rxjs */ 19240);
/* harmony import */ var rxjs__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! rxjs */ 63617);
/* harmony import */ var rxjs__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! rxjs */ 59452);
/* harmony import */ var rxjs__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(/*! rxjs */ 86301);
/* harmony import */ var rxjs_operators__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(/*! rxjs/operators */ 91817);
/* harmony import */ var rxjs_operators__WEBPACK_IMPORTED_MODULE_9__ = __webpack_require__(/*! rxjs/operators */ 70271);
/* harmony import */ var rxjs_operators__WEBPACK_IMPORTED_MODULE_10__ = __webpack_require__(/*! rxjs/operators */ 36647);
/* harmony import */ var rxjs_operators__WEBPACK_IMPORTED_MODULE_11__ = __webpack_require__(/*! rxjs/operators */ 98764);
/* harmony import */ var _rxjs_utils__WEBPACK_IMPORTED_MODULE_12__ = __webpack_require__(/*! ../rxjs.utils */ 86040);
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_13__ = __webpack_require__(/*! @angular/core */ 34205);
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_14__ = __webpack_require__(/*! @angular/core */ 12481);
/* harmony import */ var _error_service__WEBPACK_IMPORTED_MODULE_15__ = __webpack_require__(/*! ./error.service */ 46078);
var _staticBlock;

// import { codePush as CodePushPluginInternal } from '@dwimcore/capacitor-codepush';
// import { codePush } from 'cap-codepush';
// import type { CodePush } from 'cap-codepush';


// import { ILocalPackage } from '@dwimcore/capacitor-codepush/dist/esm/package';



// import { ILocalPackage } from 'cap-codepush/dist/esm/package';
class AppStatusService {
  // public codePushLabel$: Observable<string> = this.syncFinished$.pipe(
  //   switchMap((success) =>
  //     combineLatest([
  //       of(success),
  //       this.codePushPlugin.getCurrentPackage(),
  //       this.codePushPlugin.getPendingPackage(),
  //     ]).pipe(
  //       map((a) => a),
  //       catchError((error) => {
  //         this.errorService.handleError(error, 'silent');
  //         return of([false, { label: 'unknown' }, null] as [
  //           boolean,
  //           ILocalPackage,
  //           ILocalPackage
  //         ]);
  //       })
  //     )
  //   ),
  //   map(([successSync, currentPackage, pendingPackage]) => {
  //     let hotCodePushLabel = '';
  //     if (!environment.useCodePush) {
  //       hotCodePushLabel = '(code push disabled)';
  //     } else {
  //       const fallbackLabel = successSync ? '-' : 'unknown';
  //       hotCodePushLabel = currentPackage?.label || fallbackLabel;
  //     }
  //     const pendingPackageLabel = pendingPackage
  //       ? ` (pending: ${pendingPackage.label})`
  //       : '';
  //     return hotCodePushLabel + pendingPackageLabel;
  //   })
  // );
  constructor(appPlugin, devicePlugin, errorService, zone) {
    this.appPlugin = appPlugin;
    this.devicePlugin = devicePlugin;
    this.errorService = errorService;
    this.zone = zone;
    // private codePushPlugin = codePush; 
    this.isOnline$ = (0,rxjs__WEBPACK_IMPORTED_MODULE_5__.merge)((0,rxjs__WEBPACK_IMPORTED_MODULE_6__.of)(navigator?.onLine), (0,rxjs__WEBPACK_IMPORTED_MODULE_6__.of)(null).pipe((0,_rxjs_utils__WEBPACK_IMPORTED_MODULE_12__.runOutsideAngular)(this.zone), (0,rxjs_operators__WEBPACK_IMPORTED_MODULE_10__.switchMap)(() => (0,rxjs__WEBPACK_IMPORTED_MODULE_4__.interval)(1000)), (0,rxjs_operators__WEBPACK_IMPORTED_MODULE_9__.map)(() => navigator?.onLine)), (0,rxjs__WEBPACK_IMPORTED_MODULE_3__.fromEvent)(window, 'online').pipe((0,rxjs_operators__WEBPACK_IMPORTED_MODULE_9__.map)(() => true)), (0,rxjs__WEBPACK_IMPORTED_MODULE_3__.fromEvent)(window, 'offline').pipe((0,rxjs_operators__WEBPACK_IMPORTED_MODULE_9__.map)(() => false))).pipe((0,rxjs_operators__WEBPACK_IMPORTED_MODULE_8__.distinctUntilChanged)(), (0,_rxjs_utils__WEBPACK_IMPORTED_MODULE_12__.runInZone)(this.zone), (0,rxjs__WEBPACK_IMPORTED_MODULE_7__.shareReplay)(1));
    this.deviceInfo$ = (0,rxjs__WEBPACK_IMPORTED_MODULE_2__.from)(this.devicePlugin.getInfo()).pipe((0,rxjs__WEBPACK_IMPORTED_MODULE_7__.shareReplay)(1));
    this.appInfo$ = (0,rxjs__WEBPACK_IMPORTED_MODULE_2__.from)(this.appPlugin.getInfo()).pipe((0,rxjs_operators__WEBPACK_IMPORTED_MODULE_11__.tap)(info => console.log(info)), (0,rxjs__WEBPACK_IMPORTED_MODULE_7__.shareReplay)(1));
    this.version$ = this.appInfo$.pipe((0,rxjs_operators__WEBPACK_IMPORTED_MODULE_9__.map)(info => info.version));
    this.syncFinished$ = new rxjs__WEBPACK_IMPORTED_MODULE_1__.ReplaySubject(1);
  }
  codePushSyncFinished(success) {
    this.syncFinished$.next(success);
  }
  static #_ = _staticBlock = () => (this.ɵfac = function AppStatusService_Factory(__ngFactoryType__) {
    return new (__ngFactoryType__ || AppStatusService)(_angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵinject"]('AppPlugin'), _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵinject"]('DevicePlugin'), _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵinject"](_error_service__WEBPACK_IMPORTED_MODULE_15__.ErrorService), _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵinject"](_angular_core__WEBPACK_IMPORTED_MODULE_14__.NgZone));
  }, this.ɵprov = /*@__PURE__*/_angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵdefineInjectable"]({
    token: AppStatusService,
    factory: AppStatusService.ɵfac,
    providedIn: 'root'
  }));
}
_staticBlock();

/***/ }),

/***/ 67406:
/*!*******************************************************!*\
  !*** ./src/app/core/shared/services/alert.service.ts ***!
  \*******************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   AlertService: () => (/* binding */ AlertService),
/* harmony export */   normalizeTranslateKey: () => (/* binding */ normalizeTranslateKey)
/* harmony export */ });
/* harmony import */ var _Users_smartcommunitylab_Desktop_newWork_playAndGo_playGo_node_modules_babel_runtime_helpers_esm_asyncToGenerator_js__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./node_modules/@babel/runtime/helpers/esm/asyncToGenerator.js */ 89204);
/* harmony import */ var _capacitor_browser__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @capacitor/browser */ 26515);
/* harmony import */ var lodash_es__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! lodash-es */ 78745);
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @angular/core */ 34205);
/* harmony import */ var _ionic_angular__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! @ionic/angular */ 21507);
/* harmony import */ var _ngx_translate_core__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! @ngx-translate/core */ 48503);

var _staticBlock;





class AlertService {
  constructor(toastController, loadingController, alertController, translateService) {
    this.toastController = toastController;
    this.loadingController = loadingController;
    this.alertController = alertController;
    this.translateService = translateService;
    this.handleAnchorClick = event => {
      // Prevent opening anchors the default way
      event.preventDefault();
      const anchor = event.target;
      _capacitor_browser__WEBPACK_IMPORTED_MODULE_1__.Browser.open({
        url: anchor.href,
        windowName: '_system',
        presentationStyle: 'popover'
      });
    };
    // HACK: fix toast not presented when offline, due to lazy loading the toast controller.
    // Can be removed once #17450 is resolved: https://github.com/ionic-team/ionic/issues/17450
    this.toastController.create({
      animated: false
    }).then(t => {
      t.present();
      t.dismiss();
    });
  }
  showToast(args) {
    var _this = this;
    return (0,_Users_smartcommunitylab_Desktop_newWork_playAndGo_playGo_node_modules_babel_runtime_helpers_esm_asyncToGenerator_js__WEBPACK_IMPORTED_MODULE_0__["default"])(function* () {
      let message = '';
      if (args.messageTranslateKey) {
        message = yield _this.translate(args.messageTranslateKey);
      } else if (args.messageString) {
        message = args.messageString;
      }
      try {
        // this can fail if we are offline...
        _this.toast = yield _this.toastController.create({
          message,
          duration: 3000,
          position: 'bottom'
        });
        yield _this.toast.present();
      } catch (e) {
        //..but the fail is somehow so severe, that it will be not caught, here :(
        console.error('Showing toast failed', e);
      }
    })();
  }
  presentAlert(args) {
    var _this2 = this;
    return (0,_Users_smartcommunitylab_Desktop_newWork_playAndGo_playGo_node_modules_babel_runtime_helpers_esm_asyncToGenerator_js__WEBPACK_IMPORTED_MODULE_0__["default"])(function* () {
      const header = yield _this2.translate(args.headerTranslateKey);
      let message = '';
      if (args.messageTranslateKey) {
        message = yield _this2.translate(args.messageTranslateKey);
      } else if (args.messageString) {
        message = args.messageString;
      }
      const ok = yield _this2.translate('modal.ok');
      return new Promise(/*#__PURE__*/function () {
        var _ref = (0,_Users_smartcommunitylab_Desktop_newWork_playAndGo_playGo_node_modules_babel_runtime_helpers_esm_asyncToGenerator_js__WEBPACK_IMPORTED_MODULE_0__["default"])(function* (resolve) {
          const alert = yield _this2.alertController.create({
            cssClass: args.cssClass,
            header,
            message: '',
            buttons: [{
              text: ok,
              id: 'confirm-button',
              handler: () => {
                resolve();
              }
            }]
          });
          yield alert.present();
          const messageEl = alert.querySelector('.alert-message');
          if (messageEl) {
            messageEl.innerHTML = message;
          }
          const anchors = alert.querySelectorAll('a');
          anchors.forEach(anchor => {
            anchor.addEventListener('click', _this2.handleAnchorClick);
          });
        });
        return function (_x) {
          return _ref.apply(this, arguments);
        };
      }());
    })();
  }
  confirmAlert(headerTranslateKey, messageTranslateKey, cssClass) {
    var _this3 = this;
    return (0,_Users_smartcommunitylab_Desktop_newWork_playAndGo_playGo_node_modules_babel_runtime_helpers_esm_asyncToGenerator_js__WEBPACK_IMPORTED_MODULE_0__["default"])(function* () {
      const header = yield _this3.translate(headerTranslateKey);
      const message = yield _this3.translate(messageTranslateKey);
      const cancel = yield _this3.translate('modal.cancel');
      const ok = yield _this3.translate('modal.ok');
      return new Promise(/*#__PURE__*/function () {
        var _ref2 = (0,_Users_smartcommunitylab_Desktop_newWork_playAndGo_playGo_node_modules_babel_runtime_helpers_esm_asyncToGenerator_js__WEBPACK_IMPORTED_MODULE_0__["default"])(function* (resolve, reject) {
          const alert = yield _this3.alertController.create({
            cssClass: cssClass ? cssClass : 'app-alert',
            header,
            message,
            buttons: [{
              text: cancel,
              role: 'cancel',
              cssClass: 'secondary',
              id: 'cancel-button',
              handler: () => {
                resolve(false);
              }
            }, {
              text: ok,
              id: 'confirm-button',
              handler: () => {
                resolve(true);
              }
            }]
          });
          yield alert.present();
        });
        return function (_x2, _x3) {
          return _ref2.apply(this, arguments);
        };
      }());
    })();
  }
  showLoading(message) {
    var _this4 = this;
    return (0,_Users_smartcommunitylab_Desktop_newWork_playAndGo_playGo_node_modules_babel_runtime_helpers_esm_asyncToGenerator_js__WEBPACK_IMPORTED_MODULE_0__["default"])(function* () {
      _this4.loading = yield _this4.loadingController.create({
        message,
        duration: 3000
      });
      yield _this4.loading.present();
    })();
  }
  dismissLoading() {
    return (0,_Users_smartcommunitylab_Desktop_newWork_playAndGo_playGo_node_modules_babel_runtime_helpers_esm_asyncToGenerator_js__WEBPACK_IMPORTED_MODULE_0__["default"])(function* () {})();
  }
  translate(key) {
    var _this5 = this;
    return (0,_Users_smartcommunitylab_Desktop_newWork_playAndGo_playGo_node_modules_babel_runtime_helpers_esm_asyncToGenerator_js__WEBPACK_IMPORTED_MODULE_0__["default"])(function* () {
      if (!key) {
        return '';
      }
      const translated = yield _this5.translateService.get(...normalizeTranslateKey(key)).toPromise();
      return String(translated);
    })();
  }
  static #_ = _staticBlock = () => (this.ɵfac = function AlertService_Factory(__ngFactoryType__) {
    return new (__ngFactoryType__ || AlertService)(_angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵinject"](_ionic_angular__WEBPACK_IMPORTED_MODULE_4__.ToastController), _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵinject"](_ionic_angular__WEBPACK_IMPORTED_MODULE_4__.LoadingController), _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵinject"](_ionic_angular__WEBPACK_IMPORTED_MODULE_4__.AlertController), _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵinject"](_ngx_translate_core__WEBPACK_IMPORTED_MODULE_5__.TranslateService));
  }, this.ɵprov = /*@__PURE__*/_angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵdefineInjectable"]({
    token: AlertService,
    factory: AlertService.ɵfac,
    providedIn: 'root'
  }));
}
_staticBlock();
function normalizeTranslateKey(key) {
  return (0,lodash_es__WEBPACK_IMPORTED_MODULE_2__["default"])(key) ? [key, null] : [key.key, key.interpolateParams];
}

/***/ }),

/***/ 69618:
/*!*******************************************************!*\
  !*** ./src/app/core/shared/pipes/languageMap.pipe.ts ***!
  \*******************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   LanguageMapPipe: () => (/* binding */ LanguageMapPipe)
/* harmony export */ });
/* harmony import */ var _abstractObservablePipe__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./abstractObservablePipe */ 13875);
/* harmony import */ var rxjs__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! rxjs */ 70271);
/* harmony import */ var lodash_es__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! lodash-es */ 88502);
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @angular/core */ 12481);
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! @angular/core */ 37580);
/* harmony import */ var _services_user_service__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! ../services/user.service */ 89815);
/* harmony import */ var _services_error_service__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! ../services/error.service */ 46078);
var _staticBlock;






class LanguageMapPipe extends _abstractObservablePipe__WEBPACK_IMPORTED_MODULE_0__.AbstractObservablePipe {
  constructor(userService, errorService, ref) {
    super(ref);
    this.userService = userService;
    this.errorService = errorService;
    this.ref = ref;
  }
  ngOnDestroy() {
    super.destroy();
  }
  transform(value) {
    return this.doTransform(value);
  }
  transformToObservable(input) {
    return this.userService.userLanguage$.pipe((0,rxjs__WEBPACK_IMPORTED_MODULE_1__.map)(language => {
      try {
        return this.format(input, language);
      } catch (e) {
        this.errorService.handleError(e, 'silent');
        return null;
      }
    }));
  }
  format(value, language) {
    const languagesToTry = [language, 'en', 'it'];
    const applicableLanguage = languagesToTry.find(eachLanguage => (0,lodash_es__WEBPACK_IMPORTED_MODULE_2__["default"])(value, eachLanguage));
    return applicableLanguage ? value[applicableLanguage] : null;
  }
  static #_ = _staticBlock = () => (this.ɵfac = function LanguageMapPipe_Factory(__ngFactoryType__) {
    return new (__ngFactoryType__ || LanguageMapPipe)(_angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵdirectiveInject"](_services_user_service__WEBPACK_IMPORTED_MODULE_5__.UserService, 16), _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵdirectiveInject"](_services_error_service__WEBPACK_IMPORTED_MODULE_6__.ErrorService, 16), _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵdirectiveInject"](_angular_core__WEBPACK_IMPORTED_MODULE_4__.ChangeDetectorRef, 16));
  }, this.ɵpipe = /*@__PURE__*/_angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵdefinePipe"]({
    name: "languageMap",
    type: LanguageMapPipe,
    pure: false,
    standalone: false
  }));
}
_staticBlock();

/***/ }),

/***/ 70200:
/*!*******************************************************************************!*\
  !*** ./src/app/core/api/generated/controllers/territoryController.service.ts ***!
  \*******************************************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   TerritoryControllerService: () => (/* binding */ TerritoryControllerService)
/* harmony export */ });
/* harmony import */ var src_environments_environment__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! src/environments/environment */ 45312);
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @angular/core */ 34205);
/* harmony import */ var _angular_common_http__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @angular/common/http */ 63855);
var _staticBlock;
/**
 * Play&Go Project
 * No description provided (generated by Swagger Codegen https://github.com/swagger-api/swagger-codegen)
 *
 * OpenAPI spec version: 2.0
 * Contact: info@smartcommunitylab.it
 *
 * NOTE: This class is auto generated by the swagger code generator program.
 * https://github.com/swagger-api/swagger-codegen.git
 * Do not edit the class manually.
 */



class TerritoryControllerService {
  constructor(http) {
    this.http = http;
  }
  /**
   * deleteTerritory
   *
   * @param territoryId territoryId
   */
  deleteTerritoryUsingDELETE(territoryId) {
    return this.http.request('delete', src_environments_environment__WEBPACK_IMPORTED_MODULE_0__.environment.serverUrl.api + `/playandgo/api/territory/${encodeURIComponent(String(territoryId))}`, {});
  }
  /**
   * getTerritories
   *
   */
  getTerritoriesUsingGET() {
    return this.http.request('get', src_environments_environment__WEBPACK_IMPORTED_MODULE_0__.environment.serverUrl.api + `/playandgo/api/territory`, {});
  }
  /**
   * getTerritory
   *
   * @param territoryId territoryId
   */
  getTerritoryUsingGET(territoryId) {
    return this.http.request('get', src_environments_environment__WEBPACK_IMPORTED_MODULE_0__.environment.serverUrl.api + `/playandgo/api/territory/${encodeURIComponent(String(territoryId))}`, {});
  }
  /**
   * saveTerritory
   *
   * @param body
   */
  saveTerritoryUsingPOST(body) {
    return this.http.request('post', src_environments_environment__WEBPACK_IMPORTED_MODULE_0__.environment.serverUrl.api + `/playandgo/api/territory`, {
      body
    });
  }
  /**
   * updateTerritory
   *
   * @param body
   */
  updateTerritoryUsingPUT(body) {
    return this.http.request('put', src_environments_environment__WEBPACK_IMPORTED_MODULE_0__.environment.serverUrl.api + `/playandgo/api/territory`, {
      body
    });
  }
  static #_ = _staticBlock = () => (this.ɵfac = function TerritoryControllerService_Factory(__ngFactoryType__) {
    return new (__ngFactoryType__ || TerritoryControllerService)(_angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵinject"](_angular_common_http__WEBPACK_IMPORTED_MODULE_2__.HttpClient));
  }, this.ɵprov = /*@__PURE__*/_angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵdefineInjectable"]({
    token: TerritoryControllerService,
    factory: TerritoryControllerService.ɵfac,
    providedIn: 'root'
  }));
}
_staticBlock();
function removeNullOrUndefined(obj) {
  const newObj = {};
  Object.keys(obj).forEach(key => {
    if (obj[key] != null) {
      newObj[key] = obj[key];
    }
  });
  return newObj;
}

/***/ }),

/***/ 74821:
/*!*********************************************************!*\
  !*** ./src/app/core/shared/services/spinner.service.ts ***!
  \*********************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   SpinnerService: () => (/* binding */ SpinnerService)
/* harmony export */ });
/* harmony import */ var _Users_smartcommunitylab_Desktop_newWork_playAndGo_playGo_node_modules_babel_runtime_helpers_esm_asyncToGenerator_js__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./node_modules/@babel/runtime/helpers/esm/asyncToGenerator.js */ 89204);
/* harmony import */ var rxjs__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! rxjs */ 10819);
/* harmony import */ var rxjs_operators__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! rxjs/operators */ 32351);
/* harmony import */ var rxjs_operators__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! rxjs/operators */ 51903);
/* harmony import */ var rxjs_operators__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! rxjs/operators */ 91817);
/* harmony import */ var rxjs_operators__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! rxjs/operators */ 70271);
/* harmony import */ var rxjs_operators__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! rxjs/operators */ 32112);
/* harmony import */ var rxjs_operators__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(/*! rxjs/operators */ 63037);
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(/*! @angular/core */ 34205);
/* harmony import */ var _ionic_angular__WEBPACK_IMPORTED_MODULE_9__ = __webpack_require__(/*! @ionic/angular */ 21507);

var _staticBlock;




class SpinnerService {
  constructor(loadingController) {
    var _this = this;
    this.loadingController = loadingController;
    this.delay = 500;
    this.loadingRequestedSubject = new rxjs__WEBPACK_IMPORTED_MODULE_1__.Subject();
    this.notDebouncedLoading = this.loadingRequestedSubject.pipe((0,rxjs_operators__WEBPACK_IMPORTED_MODULE_6__.scan)((mapOfOngoingLoadings, newUpdate) => {
      mapOfOngoingLoadings.add(newUpdate.topic, newUpdate.changeCounter);
      return mapOfOngoingLoadings;
    }, new CounterMap()), (0,rxjs_operators__WEBPACK_IMPORTED_MODULE_5__.map)(mapOfOngoingLoadings => mapOfOngoingLoadings.isEmpty() === false), (0,rxjs_operators__WEBPACK_IMPORTED_MODULE_7__.startWith)(false), (0,rxjs_operators__WEBPACK_IMPORTED_MODULE_4__.distinctUntilChanged)());
    this.debouncedLoading$ = this.notDebouncedLoading.pipe((0,rxjs_operators__WEBPACK_IMPORTED_MODULE_2__.auditTime)(this.delay), (0,rxjs_operators__WEBPACK_IMPORTED_MODULE_4__.distinctUntilChanged)());
    this.debouncedLoading$.pipe((0,rxjs_operators__WEBPACK_IMPORTED_MODULE_3__.concatMap)(/*#__PURE__*/function () {
      var _ref = (0,_Users_smartcommunitylab_Desktop_newWork_playAndGo_playGo_node_modules_babel_runtime_helpers_esm_asyncToGenerator_js__WEBPACK_IMPORTED_MODULE_0__["default"])(function* (shouldBeShowing) {
        return shouldBeShowing ? yield _this.showLoader() : yield _this.hideLoader();
      });
      return function (_x) {
        return _ref.apply(this, arguments);
      };
    }())).subscribe();
  }
  hideLoader() {
    var _this2 = this;
    return (0,_Users_smartcommunitylab_Desktop_newWork_playAndGo_playGo_node_modules_babel_runtime_helpers_esm_asyncToGenerator_js__WEBPACK_IMPORTED_MODULE_0__["default"])(function* () {
      if (_this2.loader) {
        yield _this2.loader.dismiss();
        _this2.loader = null;
      }
    })();
  }
  showLoader() {
    var _this3 = this;
    return (0,_Users_smartcommunitylab_Desktop_newWork_playAndGo_playGo_node_modules_babel_runtime_helpers_esm_asyncToGenerator_js__WEBPACK_IMPORTED_MODULE_0__["default"])(function* () {
      console.log('show loader');
      _this3.loader = yield _this3.loadingController.create({});
      yield _this3.loader.present();
    })();
  }
  show(topic, timeout) {
    this.loadingRequestedSubject.next({
      topic,
      changeCounter: +1
    });
    // quick way how to ensure that no topic will be forgotten
    setTimeout(() => {
      this.loadingRequestedSubject.next({
        topic,
        changeCounter: Number.NEGATIVE_INFINITY
      });
    }, timeout || 10_000);
  }
  hide(topic) {
    this.loadingRequestedSubject.next({
      topic,
      changeCounter: -1
    });
  }
  static #_ = _staticBlock = () => (this.ɵfac = function SpinnerService_Factory(__ngFactoryType__) {
    return new (__ngFactoryType__ || SpinnerService)(_angular_core__WEBPACK_IMPORTED_MODULE_8__["ɵɵinject"](_ionic_angular__WEBPACK_IMPORTED_MODULE_9__.LoadingController));
  }, this.ɵprov = /*@__PURE__*/_angular_core__WEBPACK_IMPORTED_MODULE_8__["ɵɵdefineInjectable"]({
    token: SpinnerService,
    factory: SpinnerService.ɵfac,
    providedIn: 'root'
  }));
}
_staticBlock();
class CounterMap {
  constructor() {
    this.map = {};
  }
  add(key, value) {
    const previousValue = this.map[key] || 0;
    const newValue = previousValue + value;
    this.map[key] = newValue;
    if (newValue <= 0) {
      delete this.map[key];
    }
  }
  isEmpty() {
    return Object.keys(this.map).length === 0;
  }
}

/***/ }),

/***/ 75855:
/*!*****************************************************************!*\
  !*** ./src/app/core/shared/layout/content/content.directive.ts ***!
  \*****************************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   ContentDirective: () => (/* binding */ ContentDirective)
/* harmony export */ });
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! @angular/core */ 12481);
/* harmony import */ var src_app_app_component__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! src/app/app.component */ 20092);
var _staticBlock;


/**
 * Ionic does not support extending behavior of ion-content component globally.
 * To avoid adding the same code to every page, we use a directive to add it automatically.
 *
 * Main use case is to add a ion-refresher to the ion-content. Easy way to add
 * content dynamically in directive is to add whole component (as we did in appHeader).
 * Unfortunately in this case it was not possible because ior-refresher expects
 * to be a direct child of ion-content. So we need to add just "template".
 * This is possible but we need another component somewhere, which will export
 * template using ViewChild of "<ng-template #template>..". This is the reason why
 * we have ContentContentComponent, which is just a wrapper for template and
 * is always present in the DOM (appComponent).
 *
 *
 * Directive to add the content component to the DOM
 */
class ContentDirective {
  constructor(
  // We can ask dependency injection to give us this component
  appComponentReference,
  // this is reference to element on which appContent is. (again DI will get it)
  element, viewContainerRef) {
    this.appComponentReference = appComponentReference;
    this.element = element;
    this.viewContainerRef = viewContainerRef;
  }
  ngOnInit() {
    // get reference to contentTemplateComponent which is in appComponent template
    // using ViewChild in AppComponent
    const contentTemplateComponent = this.appComponentReference.contentTemplateComponent;
    // get reference to ng-template in ContentContentComponent (using ViewChild
    // in ContentContentComponent). This ng-template contains the content which we want to add.
    // this is just ng-template, so content is not rendered yet.
    const contentTemplate = contentTemplateComponent.template;
    // prepare context for the ng-template if needed (we don't need it here)
    const context = {};
    // instantiate the ng-template content.
    // (think about how ngFor works... in ngFor we will run next step for every item in the list)
    const templateView = this.viewContainerRef.createEmbeddedView(contentTemplate, context);
    // add content of template directly to the component which have appContent
    // directive (ion-content)
    const rootNodes = templateView.rootNodes || [];
    const host = this.element.nativeElement;
    const firstChild = host.firstChild;
    rootNodes.forEach(rootNode => {
      host.insertBefore(rootNode, firstChild);
    });
  }
  static #_ = _staticBlock = () => (this.ɵfac = function ContentDirective_Factory(__ngFactoryType__) {
    return new (__ngFactoryType__ || ContentDirective)(_angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵdirectiveInject"](src_app_app_component__WEBPACK_IMPORTED_MODULE_1__.AppComponent), _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵdirectiveInject"](_angular_core__WEBPACK_IMPORTED_MODULE_0__.ElementRef), _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵdirectiveInject"](_angular_core__WEBPACK_IMPORTED_MODULE_0__.ViewContainerRef));
  }, this.ɵdir = /*@__PURE__*/_angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵdefineDirective"]({
    type: ContentDirective,
    selectors: [["", "appContent", ""]],
    standalone: false
  }));
}
_staticBlock();

/***/ }),

/***/ 76285:
/*!************************************************!*\
  !*** ./src/environments/create-environment.ts ***!
  \************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   createEnvironment: () => (/* binding */ createEnvironment)
/* harmony export */ });
/* harmony import */ var src_app_core_shared_globalization_i18n_check_dictio_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! src/app/core/shared/globalization/i18n/check-dictio-runtime */ 58297);
/* eslint-disable @typescript-eslint/naming-convention */

/**
 * Our environment configuration is little complex, so we are using a factory to create it.
 *
 * Main problem is, that angular does not support "multi dimensional" environment files. In
 * the same matter that for example android does. For example, we would like to specify which
 * api server (dev/prod) to use independently from angular build optimizations (dev/prod). We would
 * like to have also build without minified code, with source maps, but with prod
 * api server - to test or debug it.
 *
 * This function is creating "joined" environment, based on different "dimensions" of configuration.
 * Each dimension is represented by one field of 'EnvironmentOptions' interface.
 * Description of dimensions in 'EnvironmentOptions' interface.
 *
 * @see EnvironmentOptions
 *
 * @param opts
 * @returns
 */
function createEnvironment(opts) {
  const environment = {
    name: opts.name,
    production: opts.releaseToStore,
    useCodePush: opts.releaseToStore,
    support: {
      privacy: 'https://playngo.it/privacy-policy-app/',
      privacyEng: 'https://playngo.it/privacy-policy-app-eng/',
      faq: 'https://playngo.it/faq-it-app-playgo/',
      faqEng: 'https://playngo.it/faq-eng-app-playgo/',
      email: 'playandgo@smartcommunitylab.it'
    },
    authConfig: getAuthConfig(opts.aacConfig),
    idp_hint: {
      facebook: 'rSDHs4bv',
      google: 'Nqoa1EDO',
      apple: 'owbERvU0'
    },
    serverUrl: getServerUrlConfig(opts.apiServer)
  };
  if (opts.releaseToStore === false) {
    (0,src_app_core_shared_globalization_i18n_check_dictio_runtime__WEBPACK_IMPORTED_MODULE_0__.assertDictionariesAreEqualInRuntime)();
  }
  return environment;
}
function getAuthConfig(aacConfig) {
  if (aacConfig === 'default') {
    return {
      server_host: `https://aac.platform.smartcommunitylab.it`,
      client_id: `c_5445634c-95d6-4c0e-a1ff-829b951b91b3`,
      redirect_url: `it.dslab.playgo://callback`,
      end_session_redirect_url: `it.dslab.playgo://endsession`,
      scopes: 'openid email profile offline_access',
      automaticSilentRenew: true,
      pkce: true
    };
  }
  if (aacConfig === 'stage') {
    return {
      server_host: `https://aac.platform.smartcommunitylab.it`,
      client_id: `c_5445634c-95d6-4c0e-a1ff-829b951b91b3`,
      redirect_url: `it.dslab.playgo.stage://callback`,
      end_session_redirect_url: `it.dslab.playgo.stage://endsession`,
      scopes: 'openid email profile offline_access',
      automaticSilentRenew: true,
      pkce: true
    };
  }
  throw Error('unknown aacConfig variant: ' + aacConfig);
}
function getServerUrlConfig(apiServer) {
  if (apiServer === 'dev') {
    return {
      api: 'https://backenddev.playngo.it:443',
      apiPath: '/playandgo/api',
      pgaziendePublicUrl: 'https://pgaziendaledev.platform.smartcommunitylab.it/api/public',
      pgaziendeUrl: 'https://pgaziendaledev.platform.smartcommunitylab.it/api',
      hscApi: 'https://hscdev.playngo.it'
    };
  }
  if (apiServer === 'prod') {
    return {
      api: 'https://backend.playngo.it:443',
      apiPath: '/playandgo/api',
      pgaziendePublicUrl: 'https://pgaziendale.platform.smartcommunitylab.it/api/public',
      pgaziendeUrl: 'https://pgaziendale.platform.smartcommunitylab.it/api',
      hscApi: 'https://hsc.playngo.it'
    };
  }
  throw Error('unknown apiServer variant: ' + apiServer);
}

/***/ }),

/***/ 76658:
/*!**********************************************************!*\
  !*** ./src/app/core/shared/services/campaign.service.ts ***!
  \**********************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   CampaignService: () => (/* binding */ CampaignService)
/* harmony export */ });
/* harmony import */ var _Users_smartcommunitylab_Desktop_newWork_playAndGo_playGo_node_modules_babel_runtime_helpers_esm_asyncToGenerator_js__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./node_modules/@babel/runtime/helpers/esm/asyncToGenerator.js */ 89204);
/* harmony import */ var lodash_es__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! lodash-es */ 92434);
/* harmony import */ var rxjs__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! rxjs */ 10819);
/* harmony import */ var rxjs__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! rxjs */ 56042);
/* harmony import */ var rxjs__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! rxjs */ 19999);
/* harmony import */ var rxjs__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! rxjs */ 63617);
/* harmony import */ var rxjs__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! rxjs */ 59452);
/* harmony import */ var rxjs_operators__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(/*! rxjs/operators */ 61318);
/* harmony import */ var rxjs_operators__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(/*! rxjs/operators */ 91817);
/* harmony import */ var rxjs_operators__WEBPACK_IMPORTED_MODULE_9__ = __webpack_require__(/*! rxjs/operators */ 51567);
/* harmony import */ var rxjs_operators__WEBPACK_IMPORTED_MODULE_10__ = __webpack_require__(/*! rxjs/operators */ 2435);
/* harmony import */ var rxjs_operators__WEBPACK_IMPORTED_MODULE_11__ = __webpack_require__(/*! rxjs/operators */ 70271);
/* harmony import */ var rxjs_operators__WEBPACK_IMPORTED_MODULE_12__ = __webpack_require__(/*! rxjs/operators */ 86301);
/* harmony import */ var rxjs_operators__WEBPACK_IMPORTED_MODULE_13__ = __webpack_require__(/*! rxjs/operators */ 63037);
/* harmony import */ var rxjs_operators__WEBPACK_IMPORTED_MODULE_14__ = __webpack_require__(/*! rxjs/operators */ 36647);
/* harmony import */ var rxjs_operators__WEBPACK_IMPORTED_MODULE_15__ = __webpack_require__(/*! rxjs/operators */ 98764);
/* harmony import */ var src_environments_environment__WEBPACK_IMPORTED_MODULE_16__ = __webpack_require__(/*! src/environments/environment */ 45312);
/* harmony import */ var _tracking_trip_model__WEBPACK_IMPORTED_MODULE_17__ = __webpack_require__(/*! ../tracking/trip.model */ 23126);
/* harmony import */ var _rxjs_utils__WEBPACK_IMPORTED_MODULE_18__ = __webpack_require__(/*! ../rxjs.utils */ 86040);
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_19__ = __webpack_require__(/*! @angular/core */ 34205);
/* harmony import */ var _user_service__WEBPACK_IMPORTED_MODULE_20__ = __webpack_require__(/*! ./user.service */ 89815);
/* harmony import */ var _api_generated_controllers_campaignController_service__WEBPACK_IMPORTED_MODULE_21__ = __webpack_require__(/*! ../../api/generated/controllers/campaignController.service */ 64692);
/* harmony import */ var _local_storage_service__WEBPACK_IMPORTED_MODULE_22__ = __webpack_require__(/*! ./local-storage.service */ 9891);
/* harmony import */ var _angular_common_http__WEBPACK_IMPORTED_MODULE_23__ = __webpack_require__(/*! @angular/common/http */ 63855);
/* harmony import */ var _error_service__WEBPACK_IMPORTED_MODULE_24__ = __webpack_require__(/*! ./error.service */ 46078);
/* harmony import */ var _refresher_service__WEBPACK_IMPORTED_MODULE_25__ = __webpack_require__(/*! ./refresher.service */ 8780);

var _staticBlock;













class CampaignService {
  constructor(userService, campaignControllerService, localStorageService, http, errorService, refresherService) {
    this.userService = userService;
    this.campaignControllerService = campaignControllerService;
    this.localStorageService = localStorageService;
    this.http = http;
    this.errorService = errorService;
    this.refresherService = refresherService;
    this.initialUserProfile$ = this.userService.userProfile$.pipe((0,rxjs_operators__WEBPACK_IMPORTED_MODULE_9__.filter)(profile => profile !== null), (0,rxjs_operators__WEBPACK_IMPORTED_MODULE_10__.first)());
    this.allCampaigns$ = this.initialUserProfile$.pipe((0,rxjs_operators__WEBPACK_IMPORTED_MODULE_14__.switchMap)(({
      territoryId
    }) => this.campaignControllerService.getCampaignsUsingGET({
      territoryId,
      onlyVisible: true
    })), (0,rxjs_operators__WEBPACK_IMPORTED_MODULE_12__.shareReplay)(1));
    this.playerCampaignUnSubscribed$ = new rxjs__WEBPACK_IMPORTED_MODULE_3__.ReplaySubject(1);
    this.playerCampaignSubscribed$ = new rxjs__WEBPACK_IMPORTED_MODULE_3__.ReplaySubject(1);
    this.campaignsCouldBeChanged$ = (0,rxjs__WEBPACK_IMPORTED_MODULE_5__.merge)(this.initialUserProfile$, this.playerCampaignSubscribed$, this.playerCampaignUnSubscribed$, this.refresherService.refreshed$).pipe((0,rxjs_operators__WEBPACK_IMPORTED_MODULE_13__.startWith)(null));
    this.myCampaignsStorage = this.localStorageService.getStorageOf('myCampaigns');
    this.myCampaigns$ = this.campaignsCouldBeChanged$.pipe((0,rxjs_operators__WEBPACK_IMPORTED_MODULE_14__.switchMap)(() => this.campaignControllerService.getMyCampaignsUsingGET({
      onlyVisible: true
    }).pipe((0,rxjs_operators__WEBPACK_IMPORTED_MODULE_15__.tap)(myCampaigns => console.log(myCampaigns)), (0,_rxjs_utils__WEBPACK_IMPORTED_MODULE_18__.ifOfflineUseStored)(this.myCampaignsStorage),
    // this is not recoverable, app is bricked...
    // for example new campaign subscription could be added successfully, but
    // server could not return the list of my campaigns, data integrity is broken,
    // but problem when new user, in that case error is 500
    (0,rxjs_operators__WEBPACK_IMPORTED_MODULE_15__.tap)(myCampaigns => console.log(myCampaigns)), (0,rxjs_operators__WEBPACK_IMPORTED_MODULE_7__.catchError)(error => {
      const isErrorExpected = true; // TODO:
      this.errorService.handleError(error, isErrorExpected ? 'silent' : 'blocking');
      return (0,rxjs__WEBPACK_IMPORTED_MODULE_6__.of)([]);
    }))), (0,rxjs_operators__WEBPACK_IMPORTED_MODULE_8__.distinctUntilChanged)(lodash_es__WEBPACK_IMPORTED_MODULE_1__["default"]), (0,rxjs_operators__WEBPACK_IMPORTED_MODULE_15__.tap)(myCampaigns => this.myCampaignsStorage.set(myCampaigns)), (0,rxjs_operators__WEBPACK_IMPORTED_MODULE_12__.shareReplay)(1));
    this.availableMeans$ = (0,rxjs__WEBPACK_IMPORTED_MODULE_4__.combineLatest)([this.userService.userProfileTerritory$, this.myCampaigns$]).pipe((0,rxjs_operators__WEBPACK_IMPORTED_MODULE_11__.map)(([userTerritory, myCampaigns]) => _tracking_trip_model__WEBPACK_IMPORTED_MODULE_17__.transportTypes.filter(eachTransportType => userTerritory?.territoryData?.means?.includes(eachTransportType)).filter(eachTransportType => myCampaigns.some(campaign => campaign.campaign.validationData.means.includes(eachTransportType)))), (0,rxjs_operators__WEBPACK_IMPORTED_MODULE_8__.distinctUntilChanged)(lodash_es__WEBPACK_IMPORTED_MODULE_1__["default"]), (0,rxjs_operators__WEBPACK_IMPORTED_MODULE_12__.shareReplay)(1));
    this.mapFunctionalities = {
      personal: {
        challenge: {
          present: false
        },
        prizes: {
          present: false
        },
        leaderboard: {
          present: true
        },
        blacklist: {
          present: false
        },
        stats: {
          present: true
        },
        statsTeam: {
          present: false
        },
        badges: {
          present: false
        },
        dates: {
          present: false
        },
        companies: {
          present: false
        },
        sponsor: {
          present: false
        }
      },
      school: {
        challenge: {
          present: false
        },
        prizes: {
          present: true
        },
        leaderboard: {
          present: true,
          api: src_environments_environment__WEBPACK_IMPORTED_MODULE_16__.environment.serverUrl.hscApi
        },
        blacklist: {
          present: false
        },
        stats: {
          present: false
        },
        statsTeam: {
          present: true
        },
        badges: {
          present: false
        },
        dates: {
          present: true
        },
        companies: {
          present: false
        },
        sponsor: {
          present: false
        }
      },
      company: {
        challenge: {
          present: false
        },
        prizes: {
          present: false
        },
        leaderboard: {
          present: false
        },
        blacklist: {
          present: false
        },
        stats: {
          present: true
        },
        statsTeam: {
          present: false
        },
        badges: {
          present: false
        },
        dates: {
          present: true
        },
        companies: {
          present: true
        },
        sponsor: {
          present: true
        }
      },
      city: {
        challenge: {
          present: true
        },
        prizes: {
          present: true
        },
        leaderboard: {
          present: true
        },
        blacklist: {
          present: true
        },
        stats: {
          present: true
        },
        statsTeam: {
          present: false
        },
        badges: {
          present: true
        },
        dates: {
          present: true
        },
        companies: {
          present: false
        },
        sponsor: {
          present: false
        }
      }
    };
    this.subscribeCampaignAction$ = new rxjs__WEBPACK_IMPORTED_MODULE_2__.Subject();
    this.unsubscribeCampaignAction$ = new rxjs__WEBPACK_IMPORTED_MODULE_2__.Subject();
  }
  subscribeToCampaign(id, body) {
    //update my campaign list
    return this.campaignControllerService.subscribeCampaignUsingPOST({
      campaignId: id,
      body
    }).pipe((0,rxjs_operators__WEBPACK_IMPORTED_MODULE_11__.map)(res => {
      this.subscribeCampaignAction$.next(id);
      this.playerCampaignSubscribed$.next(null);
      this.refresherService.onRefresh(null);
      return res;
    }));
  }
  unsubscribeCampaign(id) {
    //update my campaign list
    return this.campaignControllerService.unsubscribeCampaignUsingPUT(id).pipe((0,rxjs_operators__WEBPACK_IMPORTED_MODULE_11__.map)(res => {
      this.unsubscribeCampaignAction$.next(id);
      this.playerCampaignUnSubscribed$.next(null);
      this.refresherService.onRefresh(null);
      return res;
    }));
  }
  getCampaignDetailsById(id) {
    return this.campaignControllerService.getCampaignUsingGET(id);
  }
  getCampaignByPlayerId(id) {
    return this.campaignControllerService.getCampaignsByPlayerUsingGET(id);
  }
  getCompaniesForSubscription(campaignId) {
    return this.http.request('get', src_environments_environment__WEBPACK_IMPORTED_MODULE_16__.environment.serverUrl.pgaziendePublicUrl + `/campaigns/${encodeURIComponent(String(campaignId))}/companies`, {});
  }
  getCompanyOfTheUser(campaign) {
    var _this = this;
    return (0,_Users_smartcommunitylab_Desktop_newWork_playAndGo_playGo_node_modules_babel_runtime_helpers_esm_asyncToGenerator_js__WEBPACK_IMPORTED_MODULE_0__["default"])(function* () {
      return yield _this.http.request('get', src_environments_environment__WEBPACK_IMPORTED_MODULE_16__.environment.serverUrl.pgaziendeUrl + `/profile/campaign/${encodeURIComponent(String(campaign.campaign?.campaignId))}`, {}).toPromise();
    })();
  }
  getPersonalCampaign() {
    return this.myCampaigns$.pipe((0,rxjs_operators__WEBPACK_IMPORTED_MODULE_11__.map)(campaigns => campaigns.find(campaign => campaign?.campaign?.type === 'personal')), (0,rxjs_operators__WEBPACK_IMPORTED_MODULE_12__.shareReplay)(1));
  }
  /** returns ionic "color". For example "danger" */
  getCampaignColor(campaign) {
    if (!campaign) {
      return null;
    }
    return campaign.type;
  }
  /** returns app icon name. For example "leaf" */
  getCampaignTypeIcon(campaign) {
    if (!campaign) {
      return null;
    }
    if (campaign.type === 'city') {
      return 'ecoLeavesCity';
    }
    if (campaign.type === 'company') {
      return 'ecoLeavesCompany';
    }
    if (campaign.type === 'school') {
      return 'ecoLeavesHsc';
    }
    if (campaign.type === 'personal') {
      return 'co2';
    }
  }
  hasGame(campaign) {
    if (!campaign) {
      return false;
    }
    if (campaign.type === 'city') {
      return true;
    }
    if (campaign.type === 'company') {
      return false;
    }
    if (campaign.type === 'school') {
      return true;
    }
    if (campaign.type === 'personal') {
      return false;
    }
  }
  /** returns app-icon name. For example "flower" */
  getCampaignScoreIcon(campaign) {
    if (!campaign) {
      return null;
    }
    if (campaign.type === 'city') {
      return 'ecoLeavesCity';
    }
    if (campaign.type === 'school') {
      return 'ecoLeavesHsc';
    }
    if (campaign.type === 'company') {
      return 'ecoLeavesCompany';
    }
    return null;
  }
  getCampaignScoreLabel(campaign) {
    if (!campaign) {
      return null;
    }
    if (campaign.type === 'city') {
      return 'campaigns.score_label.flower';
    }
    if (campaign.type === 'school') {
      return 'campaigns.score_label.shield';
    }
    return null;
  }
  getFunctionalityByType(what, type) {
    if (!what || !type) {
      return null;
    }
    return this.mapFunctionalities[type]?.[what];
  }
  static #_ = _staticBlock = () => (this.ɵfac = function CampaignService_Factory(__ngFactoryType__) {
    return new (__ngFactoryType__ || CampaignService)(_angular_core__WEBPACK_IMPORTED_MODULE_19__["ɵɵinject"](_user_service__WEBPACK_IMPORTED_MODULE_20__.UserService), _angular_core__WEBPACK_IMPORTED_MODULE_19__["ɵɵinject"](_api_generated_controllers_campaignController_service__WEBPACK_IMPORTED_MODULE_21__.CampaignControllerService), _angular_core__WEBPACK_IMPORTED_MODULE_19__["ɵɵinject"](_local_storage_service__WEBPACK_IMPORTED_MODULE_22__.LocalStorageService), _angular_core__WEBPACK_IMPORTED_MODULE_19__["ɵɵinject"](_angular_common_http__WEBPACK_IMPORTED_MODULE_23__.HttpClient), _angular_core__WEBPACK_IMPORTED_MODULE_19__["ɵɵinject"](_error_service__WEBPACK_IMPORTED_MODULE_24__.ErrorService), _angular_core__WEBPACK_IMPORTED_MODULE_19__["ɵɵinject"](_refresher_service__WEBPACK_IMPORTED_MODULE_25__.RefresherService));
  }, this.ɵprov = /*@__PURE__*/_angular_core__WEBPACK_IMPORTED_MODULE_19__["ɵɵdefineInjectable"]({
    token: CampaignService,
    factory: CampaignService.ɵfac,
    providedIn: 'root'
  }));
}
_staticBlock();

/***/ }),

/***/ 76797:
/*!**************************************************************!*\
  !*** ./src/app/core/shared/plugin-mocks/DevicePluginMock.ts ***!
  \**************************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   DevicePluginMock: () => (/* binding */ DevicePluginMock)
/* harmony export */ });
/* harmony import */ var _Users_smartcommunitylab_Desktop_newWork_playAndGo_playGo_node_modules_babel_runtime_helpers_esm_asyncToGenerator_js__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./node_modules/@babel/runtime/helpers/esm/asyncToGenerator.js */ 89204);
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! tslib */ 24398);
/* harmony import */ var _mock_utils__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! ./mock-utils */ 79880);



const mockMethod = (0,_mock_utils__WEBPACK_IMPORTED_MODULE_2__.getMockMethodAnnotation)({
  doLog: false,
  logPrefix: 'DevicePluginMock'
});
class DevicePluginMock {
  constructor() {
    throw new Error('static mock');
  }
  static getInfo() {
    return (0,_Users_smartcommunitylab_Desktop_newWork_playAndGo_playGo_node_modules_babel_runtime_helpers_esm_asyncToGenerator_js__WEBPACK_IMPORTED_MODULE_0__["default"])(function* () {
      return {
        platform: 'web',
        name: 'mocked device info'
      };
    })();
  }
}
(0,tslib__WEBPACK_IMPORTED_MODULE_1__.__decorate)([mockMethod({
  async: true
})], DevicePluginMock, "getInfo", null);

/***/ }),

/***/ 77234:
/*!**********************************************************************************************************************************!*\
  !*** ./src/app/core/shared/campaigns/app-widget-campaign/app-home-campaign-challenges/app-home-campaign-challenges.component.ts ***!
  \**********************************************************************************************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   HomeCampaignChallengeComponent: () => (/* binding */ HomeCampaignChallengeComponent)
/* harmony export */ });
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! @angular/core */ 34205);
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @angular/core */ 12481);
/* harmony import */ var _services_challenge_service__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! ../../../services/challenge.service */ 16561);
/* harmony import */ var _ionic_angular__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @ionic/angular */ 4059);
/* harmony import */ var _angular_common__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! @angular/common */ 93683);
/* harmony import */ var _active_challenge_active_challenge_component__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! ../active-challenge/active-challenge.component */ 36092);
/* harmony import */ var _app_challenge_state_app_challenge_state_component__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! ./app-challenge-state/app-challenge-state.component */ 35808);
var _staticBlock;






function HomeCampaignChallengeComponent_ng_container_0_Template(rf, ctx) {
  if (rf & 1) {
    const _r1 = _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵgetCurrentView"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵelementContainerStart"](0);
    _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵelementStart"](1, "app-active-challenge", 1);
    _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵpipe"](2, "async");
    _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵlistener"]("click", function HomeCampaignChallengeComponent_ng_container_0_Template_app_active_challenge_click_1_listener($event) {
      _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵrestoreView"](_r1);
      const ctx_r1 = _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵnextContext"]();
      return _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵresetView"](ctx_r1.goToChallenge($event));
    });
    _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵelementEnd"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵelementContainerEnd"]();
  }
  if (rf & 2) {
    const ctx_r1 = _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵnextContext"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵadvance"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵproperty"]("challenge", _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵpipeBind1"](2, 3, ctx_r1.activeUncompleteChallenges$)[0])("team", ctx_r1.team)("campaign", ctx_r1.campaignContainer);
  }
}
function HomeCampaignChallengeComponent_ng_container_2_Template(rf, ctx) {
  if (rf & 1) {
    const _r3 = _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵgetCurrentView"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵelementContainerStart"](0);
    _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵelementStart"](1, "app-active-challenge", 1);
    _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵpipe"](2, "async");
    _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵlistener"]("click", function HomeCampaignChallengeComponent_ng_container_2_Template_app_active_challenge_click_1_listener($event) {
      _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵrestoreView"](_r3);
      const ctx_r1 = _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵnextContext"]();
      return _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵresetView"](ctx_r1.goToChallenge($event));
    });
    _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵelementEnd"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵelementContainerEnd"]();
  }
  if (rf & 2) {
    const ctx_r1 = _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵnextContext"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵadvance"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵproperty"]("challenge", _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵpipeBind1"](2, 3, ctx_r1.activeUncompleteChallengesTeam$)[0])("team", ctx_r1.team)("campaign", ctx_r1.campaignContainer);
  }
}
function HomeCampaignChallengeComponent_ng_container_4_Template(rf, ctx) {
  if (rf & 1) {
    _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵelementContainerStart"](0);
    _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵelement"](1, "app-challenge-state", 2);
    _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵelementContainerEnd"]();
  }
  if (rf & 2) {
    const ctx_r1 = _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵnextContext"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵadvance"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵproperty"]("activeUncompleteChallenges$", ctx_r1.activeUncompleteChallenges$)("activeUncompleteChallengesTeam$", ctx_r1.activeUncompleteChallengesTeam$)("configureChallenges$", ctx_r1.configureChallenges$)("invitesChallenges$", ctx_r1.invitesChallenges$)("canInvite$", ctx_r1.canInvite$)("campaignContainer", ctx_r1.campaignContainer)("onlyFutureChallenges$", ctx_r1.onlyFutureChallenges$);
  }
}
class HomeCampaignChallengeComponent {
  constructor(challengeService, navController) {
    this.challengeService = challengeService;
    this.navController = navController;
    this.team = false;
    this.futureChallenges = [];
  }
  ngOnInit() {
    this.activeUncompleteChallenges$ = this.challengeService.getActiveUncompletedChallengesByCampaign(this.campaignContainer?.campaign?.campaignId);
    this.activeUncompleteChallengesTeam$ = this.challengeService.getActiveUncompletedChallengesTeamByCampaign(this.campaignContainer?.campaign?.campaignId);
    this.activeChallenges$ = this.challengeService.getActiveChallengesByCampaign(this.campaignContainer?.campaign?.campaignId);
    this.activeChallengesTeam$ = this.challengeService.getActiveChallengesTeamByCampaign(this.campaignContainer?.campaign?.campaignId);
    this.onlyFutureChallenges$ = this.challengeService.getOnlyFutureChallengesByCampaign(this.campaignContainer?.campaign?.campaignId);
    this.configureChallenges$ = this.challengeService.configurableChallenges(this.campaignContainer?.campaign?.campaignId);
    this.canInvite$ = this.challengeService.canInviteByCampaign(this.campaignContainer?.campaign?.campaignId);
    this.invitesChallenges$ = this.challengeService.getInvitesChallengesByCampaign(this.campaignContainer?.campaign?.campaignId);
  }
  ngOnDestroy() {
    // this.subChallActive.unsubscribe();
  }
  goToChallenge(event) {
    if (event && event.stopPropagation) {
      event.stopPropagation();
    }
    this.navController.navigateRoot('/pages/tabs/challenges');
  }
  static #_ = _staticBlock = () => (this.ɵfac = function HomeCampaignChallengeComponent_Factory(__ngFactoryType__) {
    return new (__ngFactoryType__ || HomeCampaignChallengeComponent)(_angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵdirectiveInject"](_services_challenge_service__WEBPACK_IMPORTED_MODULE_2__.ChallengeService), _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵdirectiveInject"](_ionic_angular__WEBPACK_IMPORTED_MODULE_3__.NavController));
  }, this.ɵcmp = /*@__PURE__*/_angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵdefineComponent"]({
    type: HomeCampaignChallengeComponent,
    selectors: [["app-home-campaign-challenges"]],
    inputs: {
      campaignContainer: "campaignContainer",
      team: "team"
    },
    standalone: false,
    decls: 10,
    vars: 17,
    consts: [[4, "ngIf"], [3, "click", "challenge", "team", "campaign"], [3, "activeUncompleteChallenges$", "activeUncompleteChallengesTeam$", "configureChallenges$", "invitesChallenges$", "canInvite$", "campaignContainer", "onlyFutureChallenges$"]],
    template: function HomeCampaignChallengeComponent_Template(rf, ctx) {
      if (rf & 1) {
        _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵtemplate"](0, HomeCampaignChallengeComponent_ng_container_0_Template, 3, 5, "ng-container", 0);
        _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵpipe"](1, "async");
        _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵtemplate"](2, HomeCampaignChallengeComponent_ng_container_2_Template, 3, 5, "ng-container", 0);
        _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵpipe"](3, "async");
        _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵtemplate"](4, HomeCampaignChallengeComponent_ng_container_4_Template, 2, 7, "ng-container", 0);
        _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵpipe"](5, "async");
        _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵpipe"](6, "async");
        _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵpipe"](7, "async");
        _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵpipe"](8, "async");
        _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵpipe"](9, "async");
      }
      if (rf & 2) {
        let tmp_0_0;
        let tmp_1_0;
        let tmp_2_0;
        _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵproperty"]("ngIf", ((tmp_0_0 = _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵpipeBind1"](1, 3, ctx.activeUncompleteChallenges$)) == null ? null : tmp_0_0.length) > 0);
        _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵadvance"](2);
        _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵproperty"]("ngIf", ((tmp_1_0 = _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵpipeBind1"](3, 5, ctx.activeUncompleteChallengesTeam$)) == null ? null : tmp_1_0.length) > 0);
        _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵadvance"](2);
        _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵproperty"]("ngIf", ((tmp_2_0 = _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵpipeBind1"](5, 7, ctx.activeUncompleteChallenges$)) == null ? null : tmp_2_0.length) !== 0 || ((tmp_2_0 = _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵpipeBind1"](6, 9, ctx.activeUncompleteChallengesTeam$)) == null ? null : tmp_2_0.length) !== 0 || ((tmp_2_0 = _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵpipeBind1"](7, 11, ctx.configureChallenges$)) == null ? null : tmp_2_0.length) !== 0 || ((tmp_2_0 = _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵpipeBind1"](8, 13, ctx.invitesChallenges$)) == null ? null : tmp_2_0.length) !== 0 || _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵpipeBind1"](9, 15, ctx.canInvite$));
      }
    },
    dependencies: [_angular_common__WEBPACK_IMPORTED_MODULE_4__.NgIf, _active_challenge_active_challenge_component__WEBPACK_IMPORTED_MODULE_5__.ActiveChallengeComponent, _app_challenge_state_app_challenge_state_component__WEBPACK_IMPORTED_MODULE_6__.ChallengeStateComponent, _angular_common__WEBPACK_IMPORTED_MODULE_4__.AsyncPipe],
    styles: ["ion-item[_ngcontent-%COMP%] {\n  overflow: visible;\n}\n\nion-button[_ngcontent-%COMP%] {\n  --box-shadow: none;\n}\n\nion-avatar[_ngcontent-%COMP%] {\n  position: relative;\n  width: 64px;\n  height: 64px;\n  margin: auto;\n  display: flex;\n  flex-direction: column;\n  justify-content: center;\n  border: solid 4px var(--ion-color-city);\n  background-color: rgba(253, 216, 53, 0.5);\n}\nion-avatar[_ngcontent-%COMP%]   .type-notif[_ngcontent-%COMP%] {\n  width: 45px;\n  \n\n  margin: auto;\n  font-size: 33px;\n}\nion-avatar[_ngcontent-%COMP%]   ion-badge[_ngcontent-%COMP%] {\n  position: absolute;\n  right: -8px;\n  top: -8px;\n  border-radius: 100%;\n}\n/*# sourceMappingURL=data:application/json;charset=utf-8;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbIndlYnBhY2s6Ly8uL3NyYy9hcHAvY29yZS9zaGFyZWQvY2FtcGFpZ25zL2FwcC13aWRnZXQtY2FtcGFpZ24vYXBwLWhvbWUtY2FtcGFpZ24tY2hhbGxlbmdlcy9hcHAtaG9tZS1jYW1wYWlnbi1jaGFsbGVuZ2VzLmNvbXBvbmVudC5zY3NzIl0sIm5hbWVzIjpbXSwibWFwcGluZ3MiOiJBQUFBO0VBQ0UsaUJBQUE7QUFDRjs7QUFDQTtFQUNFLGtCQUFBO0FBRUY7O0FBQUE7RUFDRSxrQkFBQTtFQUNBLFdBQUE7RUFDQSxZQUFBO0VBQ0EsWUFBQTtFQUNBLGFBQUE7RUFDQSxzQkFBQTtFQUNBLHVCQUFBO0VBQ0EsdUNBQUE7RUFDQSx5Q0FBQTtBQUdGO0FBRkU7RUFDRSxXQUFBO0VBQ0Esa0JBQUE7RUFDQSxZQUFBO0VBQ0EsZUFBQTtBQUlKO0FBRkU7RUFDRSxrQkFBQTtFQUNBLFdBQUE7RUFDQSxTQUFBO0VBQ0EsbUJBQUE7QUFJSiIsInNvdXJjZXNDb250ZW50IjpbImlvbi1pdGVtIHtcbiAgb3ZlcmZsb3c6IHZpc2libGU7XG59XG5pb24tYnV0dG9uIHtcbiAgLS1ib3gtc2hhZG93OiBub25lO1xufVxuaW9uLWF2YXRhciB7XG4gIHBvc2l0aW9uOiByZWxhdGl2ZTtcbiAgd2lkdGg6IDY0cHg7XG4gIGhlaWdodDogNjRweDtcbiAgbWFyZ2luOiBhdXRvO1xuICBkaXNwbGF5OiBmbGV4O1xuICBmbGV4LWRpcmVjdGlvbjogY29sdW1uO1xuICBqdXN0aWZ5LWNvbnRlbnQ6IGNlbnRlcjtcbiAgYm9yZGVyOiBzb2xpZCA0cHggdmFyKC0taW9uLWNvbG9yLWNpdHkpO1xuICBiYWNrZ3JvdW5kLWNvbG9yOiByZ2JhKDI1MywgMjE2LCA1MywgMC41KTtcbiAgLnR5cGUtbm90aWYge1xuICAgIHdpZHRoOiA0NXB4O1xuICAgIC8qIHBhZGRpbmc6IDhweDsgKi9cbiAgICBtYXJnaW46IGF1dG87XG4gICAgZm9udC1zaXplOiAzM3B4O1xuICB9XG4gIGlvbi1iYWRnZSB7XG4gICAgcG9zaXRpb246IGFic29sdXRlO1xuICAgIHJpZ2h0OiAtOHB4O1xuICAgIHRvcDogLThweDtcbiAgICBib3JkZXItcmFkaXVzOiAxMDAlO1xuICB9XG59XG4iXSwic291cmNlUm9vdCI6IiJ9 */"]
  }));
}
_staticBlock();

/***/ }),

/***/ 78355:
/*!*********************************!*\
  !*** ./src/assets/i18n/it.json ***!
  \*********************************/
/***/ ((module) => {

"use strict";
module.exports = /*#__PURE__*/JSON.parse('{"---comment-cSpell-locales":"cSpell:locale it,en","helloWorld":"Ciao mondo","homeTtle":"Play&Go","profileTitle":"Profilo","campaignsTitle":"Campagne","tripsTitle":"Lista viaggi","challengeTitle":"Sfide","tripDetailTitle":"Dettagli viaggio","notifications_title":"Notifiche","discovercampaignbutton":"Scopri altre campagne","leaderboard.title":"Classifica","green leaves":"Badge ecoLeaves","bike aficionado":"Badge Viaggi in bici","sustainable life":"Badge Impatto zero","public transport aficionado":"Badge Trasporto pubblico","park and ride pioneer":"Badge Park And Ride ","bike sharing pioneer":"Badge Bike Sharing","recommendations":"Badge Raccomandazione utente","leaderboard top 3":"Badge Classifica","travels":" viaggi","appFooter":{"by":"By Fondazione Bruno Kessler","version":"Versione {{version}}","credits":"Credits","faq":"FAQ","help":"Help","privacy":"Privacy"},"appCredits":{"by":"Un progetto di ricerca di:","dslab":"DSLab","fbk":"Fondazione Bruno Kessler","version":"Versione {{version}}","credits":"Credits","faq":"FAQ","help":"Help","privacy":"Privacy","modis":"MoDiS","pmg":"PMG"},"firstTime":{"title":"Utilizzo della posizione","message":"Play&go raccoglie i dati sulla posizione per abilitare il tracciamento, validazione e premiazione di viaggi sostenibili anche quando l\'applicazione é chiusa o non utilizzata.","close":"Rifiuta","accept":"Accetta"},"permission":{"title":"Vuoi permettere a {applicationName} ad accedere alla tua posizione in background?","message":"Allo scopo di tracciare i tuoi percorsi in background, abilitare {backgroundPermissionOptionLabel} ","positiveAction":"Cambia {backgroundPermissionOptionLabel}","cancelAction":"Annulla"},"permission_denied":{"title":"Impossible iniziare il tracciamento","message":"Hai bloccato il permesso ad accedere alla tua posizione. Questo permesso é necessario per creare i tracciati per i tuoi viaggi sostenibili utilizzati per dare i punti per le tue campagne.  Puoi abilitare il permesso dalle impostazioni del tuo telefono."},"permission_when_in_use":{"title":"Attenzione","message":"Se non consenti di condividere la posizione in background, c\'è il rischio che le tue tracce siano incomplete. Considera la possibilità di modificare l\'autorizzazione in \\"Consenti sempre\\"."},"badges":{"empty":"Non hai ottenuto nessun badge per questa campagna. Gioca per scoprirli."},"login":{"login_page_title":"Login","labelSignin":"Autenticazione in corso","labelSignout":"Uscita dal sistema","loginCardHeader":"Login","loginButton":"Login","welcome":"Benvenuto","loginGoogleButton":"Entra con Google","loginFacebookButton":"Entra con Facebook","loginAppleButton":"Entra con Apple","loginInternalButton":"Entra con Username","title":"Benvenuti in Play&Go","subtitle":"App di mobilità sostenibile"},"notifications":{"empty":"Non ci sono notifiche da mostrare","close":"Chiudi"},"registration":{"title":"Nuovo utente","newUser":"New User. Fill the form with your information","avatar":{"title":"Avatar"},"name":"Nome","lastname":"Cognome","mail":"Email","nickname":"Nickname","lang":{"language":"Lingua","select":"Seleziona la lingua","it":"Italiano","en":"Inglese"},"territories":{"territory":"Territorio","select":"Seleziona il territorio"},"infoTerritory":"Il tuo territorio influenzerà le tue campagne. Per favore seleziona il tuo territorio","form":{"nameRequired":"Il nome é richiesto","nameMinLength":"La lunghezza minima é di 2 caratteri","lastNameRequired":"Il cognome é richiesto","lastNameMinLength":"La lunghezza minima é di 2 caratteri","mailRequired":"L’indirizzo email é richiesto","mailPattern":"L’indirizzo email non risulta valido","nicknameRequired":"Il nickname é richiesto","nicknameMinLength":"La lunghezza minima é di 2 caratteri","languageRequired":"Il linguaggio é richiesto","territoryRequired":"Il territorio é richiesto","privacyRequired":"La privacy é richiesta","nicknamePattern":"Utilizzare solo caratteri alfanumerici"},"territoryPopup":{"header":"Territorio","message":"La scelta del territorio determina la validazione dei viaggi e la disponibilità delle campagne di mobilità. Una volta selezionato non sarà più possibile modificarlo."},"privacyPopup":{"header":"Privacy","title":"Privacy","message":"<div class=\\"entry-content\\"><p style=\\"font: 18.7px ;text-align:center;\\"><b>PLAY&amp;GO</b></p><p style=\\"font: 18.7px ;\\"><span style=\\"font-weight: 400; font-weight:bld;\\"\\">INFORMATIVA IN MERITO AL TRATTAMENTO DEI DATI PERSONALI</span></p><p class=\\"p4\\"><span style=\\"font-weight: 400; font-weight:bld;\\"\\"></span><br></p><p style=\\"font: 16 ; font-weight:bold;\\"><span style=\\"font-weight: 400; font-weight:bld;\\"\\">Ai sensi dell’art. 13 del Regolamento UE n. 2016/679 (GDPR), ed in generale in osservanza del principio di trasparenza previsto dal Regolamento medesimo, di seguito forniamo le informazioni in merito al trattamento dei dati personali nell’ambito dell’applicazione Play&amp;Go (da qui in avanti “App”).</span></p><p style=\\"font: 16 ; font-weight:bold;\\"><span style=\\"font-weight: 400; font-weight:bld;\\"\\">L’App permette di tracciare spostamenti effettuati in mobilità integrata e multimodale (per esempio bus, treno, bici, piedi, car pooling e combinazioni di questi).</span></p><p class=\\"p6\\"><span style=\\"font-weight: 400; font-weight:bld;\\"\\"></span><br></p><p style=\\"font: 16 ; font-weight:bold;\\"><span style=\\"font-weight: 400; font-weight:bld;\\"\\">Merita precisare che l’App può essere utilizzata anche nel contesto di campagne di mobilità sostenibile per assegnare punti e premi in base agli spostamenti correttamente registrati dai partecipanti. Al fine di permettere lo svolgimento di tali campagne, si rendono necessari la raccolta ed il trattamento delle informazioni relative al tracciato di viaggi effettuati tramite l\'App.</span></p><p style=\\"font: 16 ; font-weight:bold;\\"><span class=\\"s2\\">Questa informativa deve essere considerata pertanto integrativa a quelle che verranno rese disponibili al momento dell’adesione alle varie campagne di </span><span style=\\"font-weight: 400; font-weight:bld;\\"\\">mobilità sostenibile </span><span class=\\"s2\\">proposte nel tempo attraverso l’App Play&amp;Go.</span></p><p class=\\"p6\\"><span style=\\"font-weight: 400; font-weight:bld;\\"\\"></span><br></p><p style=\\"font: 16 ; font-weight:bold;\\"><span style=\\"font-weight: 400; font-weight:bld;\\"\\">1. FINALITÀ DEL TRATTAMENTO</span></p><p style=\\"font: 16 ; font-weight:bold;\\"><span style=\\"font-weight: 400; font-weight:bld;\\"\\">Il trattamento dei dati personali avviene nell’ambito dell’App ed avrà le seguenti finalità:</span></p><ul class=\\"ul1\\">  <li class=\\"li5\\"><span class=\\"s3\\"></span><span style=\\"font-weight: 400; font-weight:bld;\\"\\">registrare gli utenti e consentire l’utilizzo dell’App;</span></li>  <li class=\\"li5\\"><span class=\\"s3\\"></span><span style=\\"font-weight: 400; font-weight:bld;\\"\\">garantire il corretto funzionamento dell’App;</span></li>  <li class=\\"li5\\"><span class=\\"s3\\"></span><span style=\\"font-weight: 400; font-weight:bld;\\"\\">consentire l’espletamento, la documentazione e il miglioramento delle attività dell’App;</span></li>  <li class=\\"li5\\"><span class=\\"s3\\"></span><span style=\\"font-weight: 400; font-weight:bld;\\"\\">tracciare e validare i viaggi tramite l’App;</span></li>  <li class=\\"li5\\"><span class=\\"s3\\"></span><span style=\\"font-weight: 400; font-weight:bld;\\"\\">provvedere a scopi di ricerca scientifica, storica e a fini statistici.</span></li></ul><p class=\\"p6\\"><span style=\\"font-weight: 400; font-weight:bld;\\"\\"></span><br></p><p style=\\"font: 16 ; font-weight:bold;\\"><span style=\\"font-weight: 400; font-weight:bld;\\"\\">2. OBBLIGATORIETÀ DEL CONFERIMENTO DEI DATI</span></p><p style=\\"font: 16 ; font-weight:bold;\\"><span style=\\"font-weight: 400; font-weight:bld;\\"\\">La base giuridica del trattamento è il consenso esplicitato al primo utilizzo dell’App.</span></p><p style=\\"font: 16 ; font-weight:bold;\\"><span style=\\"font-weight: 400; font-weight:bld;\\"\\">Tutte le finalità del trattamento sono riconducibili</span><span class=\\"s2\\"> all’utilizzo dell’App. Pur non sussistendo alcun obbligo di conferimento dei dati, il mancato conferimento comporterà l’impossibilità di procedere con l’accesso all’App e quindi di utilizzarla.</span><span style=\\"font-weight: 400; font-weight:bld;\\"\\"> Con riferimento alla geolocalizzazione, si precisa che il mancato consenso al tracciamento potrebbe compromettere la validazione degli spostamenti.</span></p><p class=\\"p6\\"><span style=\\"font-weight: 400; font-weight:bld;\\"\\"></span><br></p><p style=\\"font: 16 ; font-weight:bold;\\"><span style=\\"font-weight: 400; font-weight:bld;\\"\\">3. TIPOLOGIA DI DATI TRATTATI</span></p><p style=\\"font: 16 ; font-weight:bold;\\"><span style=\\"font-weight: 400; font-weight:bld;\\"\\">Per le esigenze di gestione dell’App potranno essere oggetto di trattamento le seguenti categorie di dati:</span></p><ul class=\\"ul1\\">  <li class=\\"li5\\"><span class=\\"s3\\"></span><span style=\\"font-weight: 400; font-weight:bld;\\"\\">dati anagrafici e dati di contatto;</span></li>  <li class=\\"li5\\"><span class=\\"s3\\"></span><span style=\\"font-weight: 400; font-weight:bld;\\"\\">dati di geolocalizzazione (dati sulla posizione dell’utente rilevati in tempo reale basati sul GPS presente sul dispositivo mobile su cui è installata l’App durante il tracciamento di un viaggio); </span></li>  <li class=\\"li5\\"><span class=\\"s3\\"></span><span style=\\"font-weight: 400; font-weight:bld;\\"\\">dati relativi al comportamento (modalità di spostamento, numero di Km percorsi).</span></li></ul><p style=\\"font: 16 ; font-weight:bold;\\"><span style=\\"font-weight: 400; font-weight:bld;\\"\\">I dati del profilo pubblico (Google, Facebook, Apple, Smart Community) dell’utente potrebbero essere utilizzati per personalizzare l’App.</span></p><p style=\\"font: 16 ; font-weight:bold;\\"><span style=\\"font-weight: 400; font-weight:bld;\\"\\">L’indirizzo di posta elettronica dell’utente viene utilizzato anche quale strumento per l’identificazione univoca dell’utente all’interno dei sistemi di Smart Community.</span></p><p class=\\"p6\\"><span style=\\"font-weight: 400; font-weight:bld;\\"\\"></span><br></p><p class=\\"p6\\"><span style=\\"font-weight: 400; font-weight:bld;\\"\\"></span><br></p><p class=\\"p6\\"><span style=\\"font-weight: 400; font-weight:bld;\\"\\"></span><br></p><p style=\\"font: 16 ; font-weight:bold;\\"><span style=\\"font-weight: 400; font-weight:bld;\\"\\">4. MODALITÀ DEL TRATTAMENTO</span></p><p style=\\"font: 16 ; font-weight:bold;\\"><span style=\\"font-weight: 400; font-weight:bld;\\"\\">Il trattamento sarà effettuato:</span></p><ul class=\\"ul1\\">  <li class=\\"li5\\"><span class=\\"s3\\"></span><span style=\\"font-weight: 400; font-weight:bld;\\"\\">mediante l’App e l’utilizzo di sistemi manuali e automatizzati;</span></li>  <li class=\\"li5\\"><span class=\\"s3\\"></span><span style=\\"font-weight: 400; font-weight:bld;\\"\\">da soggetti autorizzati ed istruiti all’assolvimento di tali compiti, ai sensi di legge;</span></li>  <li class=\\"li5\\"><span class=\\"s3\\"></span><span style=\\"font-weight: 400; font-weight:bld;\\"\\">con l’impiego di misure adeguate a garantire la riservatezza dei dati ed evitare l’accesso agli stessi da parte di terzi non autorizzati;</span></li>  <li class=\\"li5\\"><span class=\\"s3\\"></span><span style=\\"font-weight: 400; font-weight:bld;\\"\\">in contesti che non pregiudicano la dignità personale ed il decoro dell’interessato, assicurando le dovute accortezze per garantirne la riservatezza nell’utilizzo.</span></li></ul><p style=\\"font: 16 ; font-weight:bold;\\"><span style=\\"font-weight: 400; font-weight:bld;\\"\\">È possibile consultare tutte le misure tecniche ed organizzative adottate da FBK per assicurare proporzionalità e necessità del trattamento e prevenire l\'accesso illegittimo, la modifica indesiderata, la scomparsa e le violazioni esplicite dei dati personali al seguente link <a href=\\"https://www.google.com/url?q=https://bit.ly/MisureFBK&amp;sa=D&amp;source=editors&amp;ust=1749131537733032&amp;usg=AOvVaw03jEtMRyj_yuaW-rPsEEFO\\">bit.ly/MisureFBK</a>.</span></p><p style=\\"font: 16 ; font-weight:bold;\\"><span style=\\"font-weight: 400; font-weight:bld;\\"\\">Non è previsto alcun processo decisionale automatizzato, né alcuna attività di profilazione.</span></p><p class=\\"p6\\"><span style=\\"font-weight: 400; font-weight:bld;\\"\\"></span><br></p><p style=\\"font: 16 ; font-weight:bold;\\"><span style=\\"font-weight: 400; font-weight:bld;\\"\\">5. DURATA DEL TRATTAMENTO</span></p><p style=\\"font: 16 ; font-weight:bold;\\"><span style=\\"font-weight: 400; font-weight:bld;\\"\\">I dati verranno conservati fino a quando l’utente non ne richiede la cancellazione e, in ogni caso, per un </span><span class=\\"s5\\">periodo non superiore a quello necessario all’adempimento degli obblighi o dei compiti indicati al punto 1, e comunque per perseguire le specifiche finalità ivi indicate</span><span style=\\"font-weight: 400; font-weight:bld;\\"\\">. La cancellazione dei dati avverrà in modo graduale, in base all’esaurirsi delle singole finalità per le quali sono stati raccolti.</span></p><p style=\\"font: 16 ; font-weight:bold;\\"><span style=\\"font-weight: 400; font-weight:bld;\\"\\">In alcuni casi, i dati potranno essere conservati anche a seguito della chiusura dell’account, ad esempio nei backup o nel sistema di Disaster Recovery o, in forma aggregata e anonima, per scopi di ricerca scientifica.</span></p><p class=\\"p6\\"><span style=\\"font-weight: 400; font-weight:bld;\\"\\"></span><br></p><p style=\\"font: 16 ; font-weight:bold;\\"><span style=\\"font-weight: 400; font-weight:bld;\\"\\">6. COMUNICAZIONE DEI DATI</span></p><p style=\\"font: 16 ; font-weight:bold;\\"><span style=\\"font-weight: 400; font-weight:bld;\\"\\">I dati raccolti ed elaborati potranno essere comunicati esclusivamente per le suddette finalità specificate, e in forma aggregata, a Pubbliche Amministrazioni (ad esempio in quanto promotrici delle iniziative di mobilità sostenibile).</span></p><p style=\\"font: 16 ; font-weight:bold;\\"><span style=\\"font-weight: 400; font-weight:bld;\\"\\">I dati personali non sono soggetti a diffusione.</span></p><p style=\\"font: 16 ; font-weight:bold;\\"><span style=\\"font-weight: 400; font-weight:bld;\\"\\">Per esclusive finalità di divulgazione scientifica dei risultati statistici e/o scientifici (ad esempio mediante pubblicazione di articoli scientifici, partecipazione a convegni, ecc.), i dati potranno essere diffusi in forma anonima e aggregata e sempre secondo modalità che non rendano identificabile l’Interessato.</span></p><p class=\\"p7\\"><span style=\\"font-weight: 400; font-weight:bld;\\"\\"></span><br></p><p style=\\"font: 16 ; font-weight:bold;\\"><span style=\\"font-weight: 400; font-weight:bld;\\"\\">7. LUOGO DI TRATTAMENTO DEI DATI</span></p><p style=\\"font: 16 ; font-weight:bold;\\"><span style=\\"font-weight: 400; font-weight:bld;\\"\\">L’attività di trattamento dei dati personali avviene sul territorio dell’Unione Europea, oppure con l’ausilio di strumenti informatici che comportano il trattamento in Paesi per i quali la Commissione Europea ha assunto decisione di adeguatezza della protezione dei dati personali o, in sua mancanza, attraverso la sottoscrizione con il fornitore di Clausole Contrattuali Tipo (SCC) di protezione dei dati adottate dalla Commissione Europea.</span></p><p class=\\"p6\\"><span style=\\"font-weight: 400; font-weight:bld;\\"\\"></span><br></p><p style=\\"font: 16 ; font-weight:bold;\\"><span style=\\"font-weight: 400; font-weight:bld;\\"\\">8. DIRITTI DELL’INTERESSATO</span></p><p style=\\"font: 16 ; font-weight:bold;\\"><span class=\\"s2\\">L’interessato ha diritto di chiedere in ogni momento al Titolare per esercitare i diritti di cui agli artt. 15 e ss. del GDPR e, in particolare:</span></p><p class=\\"p8\\"><span class=\\"s2\\">-        chiedere la conferma dell’esistenza o meno di propri dati personali e richiederne l’accesso;</span></p><p class=\\"p8\\"><span class=\\"s2\\">-        ottenere le indicazioni circa le finalità del trattamento, le categorie dei dati personali, i destinatari o le categorie di destinatari a cui i dati personali sono stati o saranno comunicati e, quando possibile, il periodo di conservazione;</span></p><p class=\\"p8\\"><span class=\\"s2\\">-        ottenere la rettifica e la cancellazione dei dati;</span></p><p class=\\"p8\\"><span class=\\"s2\\">-        ottenere la limitazione del trattamento;</span></p><p class=\\"p8\\"><span class=\\"s2\\">-        opporsi al trattamento in qualsiasi momento.</span></p><p style=\\"font: 16 ; font-weight:bold;\\"><span class=\\"s2\\">Ha il diritto, inoltre, di revocare il consenso in qualsiasi momento senza pregiudicare la liceità del trattamento basato sul consenso prestato prima della revoca.</span></p><p style=\\"font: 16 ; font-weight:bold;\\"><span style=\\"font-weight: 400; font-weight:bld;\\"\\">Per l’esercizio dei suddetti diritti è possibile scrivere a: <a href=\\"mailto:privacy@fbk.eu\\">privacy@fbk.eu</a></span><span class=\\"s7\\">.</span><span style=\\"font-weight: 400; font-weight:bld;\\"\\"> </span></p><p style=\\"font: 16 ; font-weight:bold;\\"><span class=\\"s2\\">Resta salvo il diritto di proporre reclamo al Garante per la protezione dei dati personali.</span></p><p class=\\"p6\\"><span style=\\"font-weight: 400; font-weight:bld;\\"\\"></span><br></p><p style=\\"font: 16 ; font-weight:bold;\\"><span style=\\"font-weight: 400; font-weight:bld;\\"\\">9. TITOLARE DEL TRATTAMENTO</span></p><p style=\\"font: 16 ; font-weight:bold;\\"><span style=\\"font-weight: 400; font-weight:bld;\\"\\">Il Titolare del trattamento dei dati personali è la Fondazione Bruno Kessler, con sede a Trento, via Santa Croce, 77 - +39.0461.314.621-227 – <a href=\\"mailto:segr.presidenza@fbk.eu\\">segr.presidenza@fbk.eu</a></span></p><p class=\\"p6\\"><span style=\\"font-weight: 400; font-weight:bld;\\"\\"></span><br></p><p style=\\"font: 16 ; font-weight:bold;\\"><span style=\\"font-weight: 400; font-weight:bld;\\"\\">10. DATI DI CONTATTO DEL RESPONSABILE DELLA PROTEZIONE DEI DATI PERSONALI</span></p><p style=\\"font: 16 ; font-weight:bold;\\"><span class=\\"s2\\">Il Titolare ha designato un Responsabile della Protezione dei Dati personali (DPO) ai sensi dell’art. 37 del GDPR, contattabile attraverso i seguenti canali: +39.0461.314.370 - <a href=\\"mailto:privacy@fbk.eu\\">privacy@fbk.eu</a></span><span style=\\"font-weight: 400; font-weight:bld;\\"\\">.</span></p><p class=\\"p6\\"><span style=\\"font-weight: 400; font-weight:bld;\\"\\"></span><br></p><p style=\\"font: 16 ; font-weight:bold;\\"><span style=\\"font-weight: 400; font-weight:bld;\\"\\">11. MODIFICHE ALLA PRESENTE INFORMATIVA</span></p><p style=\\"font: 16 ; font-weight:bold;\\"><span class=\\"s2\\">Il Titolare si riserva di apportare, qualora necessario, le opportune modifiche alla presente Informativa Privacy – attualmente aggiornata al 16 maggio 2025 - dandone la più ampia visibilità agli Interessati.</span></p><p class=\\"p9\\"><span style=\\"font-weight: 400; font-weight:bld;\\"\\"></span><br></p><p class=\\"p9\\"><span style=\\"font-weight: 400; font-weight:bld;\\"\\"></span><br></p>  </div>"},"privacyLink":"Privacy Policy","privacy":"Ho letto e compreso l\'informativa privacy e acconsento al trattamento dei miei dati personali.","sumbmitButton":"Registrati","confirm":{"header":"Conferma territorio","message":"<h1>{{territory}}</h1><br><strong>{{nickname}} </strong> sei veramente sicuro di voler iscriverti all\'app Play&Go per il territorio selezionato?"}},"modal":{"cancel":"Annulla","ok":"OK","alert_title":"Attenzione","levelup":"Nuovo livello!","newbadge":"Nuovo badge!"},"tracking":{"low_accuracy":"Bassa precisione!","choose_means":"Seleziona un mezzo per tracciare","continue_low_accuracy_prompt":"Bassa precisione rilevata! Vuoi proseguire?","show_current_location":"Fammi vedere dove sono","too_short":"Il viaggio è troppo corto e non verrà aggiunto!","info":{"title":"Mezzi e tracciamento","subtitle":"Ciascuna icona può corrispondere a più mezzi differenti. Ecco una legenda per orientarti meglio:","car":"Automobile condivisa, Trasporto riservato ai diversamente abili con autisti o mezzi autorizzati","bike":"Bicicletta muscolare/elettrica, Corsa, Monopattino muscolare/elettrico, Skateboard, Segway, Pattini a rotelle","walk":"Camminata","train":"Trasporto ferroviario ","bus":"Autobus di linea urbano ed extraurbano","boat":"Battello o nave","unknown":"per ogni altro mezzo"},"car":{"choose_role":"Scegli il tuo ruolo","driver":"Guidatore","passenger":"Passeggero","manual_code":"Codice del viaggio:","manual_code_input_label":"Inserisci il codice manualmente:","manual_code_input_example":"Es: 12345","manual_code_input_confirm":"Conferma codice","or":"oppure scansiona il QR code","scan":"Leggilo","showCode":"<h3><b>Il tuo viaggio è iniziato.</b></h3><br>Ora aggiungi un passeggero.<br>Mostra il QR Code o condividi il codice.","confirm":"Inizia a guidare","errors":{"NO_ROLE_CHOSEN":"Nessun ruolo selezionato!","NO_CONFIRMED":"Il codice QR Code va confermato","NO_PASSENGER_CARPOOLING_ID":"Nessun codice passeggero inserito","INCORRECT_QR_CODE":"Codice QR Code errato"}},"stop_header":"Viaggio concluso!","stop_body":"Il tracciamento si è concluso. I dati del viaggio verranno inviati ai nostri server per la validazione.","errors":{"ACCESS_DENIED":"Accesso alla posizione in background rifiutata!","LOW_ACCURACY":"Bassa precisione nella posizione rilevata!","POWER_SAVE_MODE":"Modalità Risparmio Energetico attiva! Questo puó comportare un tracciamento impreciso!","UNABLE_TO_GET_POSITION":"Impossibile recuperare la tua locazione! Assicurati che i servizi di localizzazione siano attivi e riprovare."}},"profile":{"mail":"Email: ","activeFrom":"Attivo dal: ","territory":"Territorio: ","blacklistedUser":"Blacklist utente","Faq":"FAQ","Help":"Help","Privacy":"Privacy","logout":"Esci","logoutpopup":{"title":"Attenzione","message":"I dati non salvati veranno persi. Sei sicuro/a di voler uscire dall\'app?","cancel":"Annulla","ok":"OK"},"about":"About","deleteAccount":"Elimina account","changeButton":"Modifica","delete":{"title":"Eliminazione profilo","message":"Questa azione cancellerà tutti i tuoi dati e i tuoi progressi nell’app Play&Go","message2":"Si tratta di un’azione irreversibile: non potrai recuperare nessun dato del tuo storico (campagne, sfide, ecc.) se elimini il profilo","message3":"Sei sicuro di voler eliminare definitivamente il tuo profilo Play&Go?","close":"Annulla","accept":"Elimina"},"change":{"modalTitle":"Modifica Profilo","closeButton":"Chiudi","saveButton":"Salva","lang":{"language":"Lingua","select":"Seleziona la lingua","it":"Italiano","en":"Inglese"}},"status":{"totalKm":"{{totalKM}} fatti","travels":"{{totalTravels}} viaggi validi","activityDays":"{{activityDays}} giorni di gioco ","activeCampaigns":"{{activeCampaigns}} campagne attive","myCampaigns":"Campagne attive:"}},"report":{"stats":{"title":"Statistiche","title_team":"Statistiche squadra"}},"trips":{"filter_all_campaigns":"Tutte le campagne","filter_all_the_time":"Complessivo","empty":"Nessun viaggio presente"},"trip_detail":{"title":"Dettaglio viaggio","start":"Inizio","end":"Fine","distance":"Lunghezza","gl_for":"per","valid_for_campaigns":{"plural_form":{"one":"Valido per {{count}} campagna","other":"Valido per {{count}} campagne"}},"no_score":"Nessun punteggio associato a questo viaggio.","no_track":"Nessun tracciato associato a questo viaggio.","mean":{"car":"Carpooling","bike":"Bici","walk":"Piedi","train":"Treno","bus":"Autobus","boat":"Battello","unknown":"Mezzo sconosciuto"},"status":{"valid":"Valido","invalid":"Non valido","pending":"In attesa","not_synchronized":"Non sincronizzato","not_finished":"In corso","validation":"In validazione"},"historic_values_offline":"Per caricare i viaggi storici, devi essere online."},"errors":{"error_header":"Errore","not_recoverable":"L’applicazione ha riscontrato un errore irreversibile e verrà riavviata! \\n L’avanzamento del tuo viaggio verrà salvato.","offline":"Questa funzionalità é disponibile solo online.","userNotFound":"Utente non registrato","nickNameExist":"Questo soprannome é giá registrato","defaultErr":"Operazione fallita."},"offline":{"title":"Offline","header":"Puoi continuare a tracciare i tuoi viaggi, ma alcune pagine potrebbero non funzionare!","page":{"body_1":"Nessuna connessione disponibile!","body_2":"Questa pagina non può funzionare senza una connessione ad internet","body_3":"Puoi comunque tracciare i tuoi viaggi e continuare a giocare; i dati verranno inviati quando la connessione sarà ripristinata.","return_home":"Torna alla homepage"}},"campaigns":{"title":"Campaigns","join":"Iscriviti","notStarted":"La campagna non é attiva","cantSubscribe":"La campagna è in corso. <br> Il tuo nickname non appartiene a nessuna squadra. Per partecipare rivolgiti al docente referente","notStartedHSC":"La campagna non è ancora attiva. Per partecipare rivolgiti al docente referente","novaliddate":"Il periodo della campagna non risulta valido","removed":"La campagna è conclusa.","noDesc":"Nessuna descrizione fornita","myCampaigns":"Le mie","allCampaigns":"Tutte","registered":"Registrato","unregistered":"Utente disiscritto","public":{"last":"Durata:"},"campaignmodal":{"listTitle":"Aziende partecipanti","title":"Dettaglio azienda","close":"X"},"joinmodal":{"search":"Cerca","raccomandation":"Chi ti ha invitato?","nickname":"Inserisci il nickname","teamselection":"Seleziona la squadra","teams":"Squadre","noItems":"Nessuna azienda trovata","modalTitle":"Iscrizione a {{campaignTitle}}","close":"X","closeString":"Chiudi","pinRequired":"E\' richiesto il codice identificativo","companyselection":"Seleziona l’azienda con cui iscriverti","companyPIN":"Inserisci il codice identificativo","privacyLink":"Leggi l’informativa sulla privacy","privacy":"Ho letto e compreso l\'informativa privacy e acconsento al trattamento dei miei dati personali.","privacyRequired":"La privacy é richiesta","rulesLink":"Leggi il regolamento","rules":"Accetto il regolamento della campagna","rulesRequired":"Il regolamento é richiesto","companyRequired":"É necessario eseguire la selezione","error":{"ERROR_TEAM":"Errore nell\'iscrizione. Verificare il team selezionato"},"privacyPopup":{"header":"Privacy"},"rulesPopup":{"header":"Regolamento"},"codeInfo":{"header":"Codice giocatore","message":"Codice univoco rilasciato al giocatore"},"join":"Iscriviti","confirm":"Conferma iscrizione"},"unsub":{"title":"Disiscrizione","text":"Sei sicuro di voler disiscriverti dalla campagna?","close":"Chiudi","confirm":"Conferma"},"detail":{"not_subscribed":"Non iscritto","unregistered":"Abbandono","nMembersActive":"Membri attivi:","nMembersInvited":"Invitati:","nMembersMax":"Max squadra:","playerProgression":"Come stai andando","teamProgression":"Come sta andando la tua squadra","teamDetailRanking":"Classifica Generale:","teamAvg":"{{value}} Km/mese per utente","points":"Punteggio settimanale: ","noPoints":"Punteggio settimanale: 0","members":"{{members}} membri","member":"{{members}} membro","modalTeam":"<div class=\\"ion-text-start\\"><i>Questo componente mostra la performance della tua squadra in confronto alla squadra più attiva e a quella meno attiva <b> in questa settimana</b>.<br/><br/>A sinistra viene rappresentato il punteggio della squadra meno attiva.<br/><br/> A destra invece quello della squadra più attiva.<br/> La barra rappresenta il tuo posizionamento rispetto ai due punteggi. <br/><br/><b>Valori dal {{dateFrom}} al {{dateTo }}</b>:<br /><br/></i></div>","modalBestTeam":"Punteggio squadra migliore: ","modalActualTeam":"Punteggio della tua squadra: ","modalMinTeam":"Punteggio squadra peggiore:","modalPersonal":"<div class=\\"ion-text-start\\" ><i>Questo componente mostra la tua performance in confronto al giocatore più attivo e al meno attivo <b> in questa settimana</b>.<br/><br/>  A sinistra viene rappresentato il punteggio del giocatore meno attivo. <br/><br/>A destra invece quello del giocatore più attivo.<br/>La barra rappresenta il tuo posizionamento rispetto ai due punteggi. <br/><br/><b>Valori dal {{dateFrom}} al {{dateTo }}</b>:<br /><br/><i></div>","modalBestPersonal":"Punteggio massimo:","modalActualPersonal":"Il tuo punteggio: ","modalMinPersonal":"Punteggio minimo: ","modalTeamValid":"Vengono prese in considerazione solo le squadre che hanno compiuto almeno un viaggio valido.","modalPersonalValid":"Vengono prese in considerazione i giocatori che hanno compiuto almeno un viaggio valido.","myCompany":"Azienda:","youCompany":"La tua azienda","otherCompany":"Le altre aziende","companies":"Aziende partecipanti","companySubscribe":"Inserisci il codice identificativo","not_found":"Campagna non trovata","blacklist":"Utenti Bloccati","badges":"Badges","stats":"Statistiche","statsTeam":"Statistiche squadra","generalStat":"Informazioni generali","signal":"Contatta il supporto","unsubscribe":"Abbandona la campagna","prizes":"Premi","prize":{"title":"Premi","desc":"Il primo premio verrà assegnato di diritto al primo giocatore nella classifica settimanale delle eco-leaves mentre gli altri premi saranno estratti a sorte tra i primi 50 classificati. Verifica il regolamento per sapere qual giocatori possono concorrere ai premi settimanali, come sono gestiti i casi di parità e gli altri dettagli su modalità e tempi di assegnazione.","periodic":"Periodici","final":"Finali","prizefinal":"Premi finali","prizeactual":"Premi periodici in palio","actualWeekTitle":"Note premi periodici","finalWeekTitle":"Note premi finali","periodicWeekTitle":"Note premio","finalRewardTitle":"Informazioni premio","sponsorBy":"Offerto da:","website":"website","noFinal":"Nessun premio finale disponibile","noActual":"Nessun premio periodico disponibile","expand":"Mostra premi passati","expanded":"Premi passati"},"from":"Dal ","to":"al","info":"Informazione premi","current":"In corso","dateFrom":"Inizio: ","dateTo":"Fine: ","challenges":"Sfide","journeys":"Lista viaggi campagna","leaderboard":"Classifica","faq":"FAQ","sponsor":"Organizzatori e collaboratori","description":"Descrizione","details":"Dettagli campagna","limits_title":"Limiti previsti","limits_text":"Dal regolamento sono previsti i seguenti limiti: <ul><li>massimo 20 km al giorno;</li><li>massimo 250 km al mese;</li></ul> Superato il limite, i viaggi non vengono validati per la campagna e la ricompensa non viene riconosciuta.","contacts":"Contatti: ","name":"Nome: ","address":"Indirizzo: ","phone":"Telefono: ","mail":"Email: ","mm":"Mobility Manager","locations":"Lista sedi valide","location":"Sede {{index}}:","personalStatWeek":"Il tuo contributo questa settimana: {{value}}","companiesPage":{"website":"WWW","email":"Email","phone":"Tel","address":"Indirizzo: ","location":"Sedi"}},"homewidgets":{"personal":{"active":"Attivo dal: {{startDate}}","totalco2":"CO₂ risparmiata: {{totalCO2}} Kg","weeklyco2":"CO₂ settimanale: {{weeklyCO2}} Kg","weeklyRanking":"Posizione in classifica: {{weeklyRanking}}"},"stat":{"weekposition":"Settimanale:","totalposition":"Globale:","weekvalue":"<b>{{value}} {{unit}}</b> settimanale","monthvalue":"<b>{{value}} {{unit}}</b> mensile","totalvalue":"<b>{{value}} {{unit}}</b> totale","lastpaymentkm":"<b>{{value}} {{unit}}</b> dal {{date}} al {{dateTo}}","levelName":"<b>Livello {{levelIndex}}: {{levelName}}</b>","maxscore":"Hai raggiunto il livello massimo","score":" ","emptystatus":"Per visualizzare il tuo livello e il punteggio inizia a giocare! ","status":"{{score}} Kg CO₂ risparmiata","record":"{{record}} Record Settimanale","today":"Oggi: ","thisWeek":"Settimana: ","lastmonth":"{{lastmonth}}: ","max":" max","km":" Km"}},"stats":{"filter":{"unit":{"km":{"label":"Km","unit":"km"},"co2":{"label":"CO2","unit":"co2"}},"means":{"car":{"label":"Carpooling","unit":"car"},"bike":{"label":"Bici","unit":"bike"},"walk":{"label":"Piedi","unit":"walk"},"boat":{"label":"Battello","unit":"boat"},"bus":{"label":"Autobus","unit":"bus"},"train":{"label":"Treno","unit":"train"}},"GL":"ecoLeaves","period":{"week":"Settimana","month":"Mese","year":"Anno"},"mean_type":"Mezzo","unit_type":"Unità"}},"leaderboard":{"empty":"Nessun viaggio registrato nel periodo","filter":{"leaderboard_type":"Valore","period":"Periodo"},"period":{"today":"Oggi","this_week":"Questa settimana","last_week":"Settimana scorsa","this_month":"Questo mese","all_time":"Generale"},"leaderboard_type":{"co2":"Totale CO₂","km":"Totale km","GL":"ecoLeaves","virtualScore":"","virtualTrack":""},"select":{"co2":"CO₂","km":"Km","tracks":"Viaggi","duration":"Durata","virtualScore":"","virtualTrack":""},"unit":{"co2":"CO₂ Kg","km":"Km","tracks":"Numero tracce","duration":"Ore","virtualScore":"","virtualTrack":"Numero viaggi"},"unitChart":{"co2":"Kg","km":"Km","tracks":"","duration":"ore","virtualScore":"","virtualTrack":""},"leaderboard_type_unit":{"co2":"{{value}}","GL":"{{value}}","km":"{{value}}","duration":"{{value}} ore","tracks":"{{value}}","virtualScore":"{{value}}","virtualTrack":"{{value}}"},"all_means":"Tutti i mezzi","gl":"Punteggio","virtualScore":"Punteggio"},"score_label":{"flower":"ecoLeaves","shield":"ecoLeaves"}},"blacklist":{"blacklist":"Utenti Bloccati","intro1":"Qui trovi la lista di utenti che hai bloccato in questa campagna","intro2":"Gli utenti che hai bloccato non potranno lanciarti delle sfide nella campagna Trento Play & Go, nè tu potrai sfidare loro","empty":"Non ci sono utenti bloccati per questa campagna"},"teamprofile":{"title":"Profilo squadra"},"userprofile":{"period_challenge":"Sfide dell\'ultimo mese {{periodFrom}} - {{periodTo}}","title":"Profilo utente","last_month":"Attività dell’ultimo mese","personal_stat_bike":" in bici","personal_stat_walk":" a piedi","personal_stat_bus":" in bus","personal_stat_train":" in treno","personal_stat_car":" in carpooling","personal_stat_boat":" in battello","empty":"Non ci sono statistiche da mostrare","last_week_position":" questa settimana","general_position":" classifica generale","total_points":" punti totali","won":"{{won}} vinte","add_blacklist":"Blocca inviti","remove_blacklist":"Sblocca inviti","user_joined":"L\'utente partecipa a questa campagna","blacklist_user":"Attenzione: hai bloccato gli inviti per le sfide di questo utente. Non puoi inviare nè ricevere sfide da questo utente. "},"challenges":{"singleActivated":"Sfida attivata con successo!","singleDesc":"Hai attivato una sfida singola per la settimana tra il {{from}} e il {{to}}","active":"Sfide attive : {{active}}","configure":"Sfide configurabili: {{configurable}}","invitations":"Inviti ricevuti: {{invites}}","challenges":"Sfide","allchallenges":"Tutte le sfide","checkallchallenges":"Vedi tutte le sfide","detail":{"title":"Dettaglio sfida","close":"Chiudi"},"sent":"Invito inviato a {{nickname}}","received":"Invito ricevuto da {{nickname}}","activate":"Accetta invito","reject":"Rifiuta invito","cancel":"Annulla invito","ongoing":"Sfida in corso","singleproposal":"Sfida singola","proposed":"Sfide della prossima settimana","choose_single":"Scegli una delle seguenti sfide singole","choose_or_configure":"Configura una sfida di coppia","empty":"Non ci sono sfide da mostrare","past":"Passate","present":"Presenti","future":"Future","fromto":"Dal {{ from }} al {{ to }}","points":"{{ point }} points","challenge_container":"Sfide {{ type }} di campagna","info":{"title":"Sfide singole","body":"Ogni settimana puoi scegliere solo UNA sfida singola tra quelle proposte. <br> Una volta scelta una sfida, le alternative vengono automaticamente eliminate.","close":"Chiudi"},"infogroup":{"title":"Sfide di coppia","body":"Ogni settimana puoi scegliere solo UNA sfida di coppia.  Puoi mandare un solo invito e riceverne 3.<br><br> Accettare un invito equivale a scegliere una sfida di coppia, altri inviti ricevuti/mandati vengono automaticamente annullati. <br> <br> Se il tuo invito viene accettato, la sfida viene automaticamente assegnata ad entrambi i partecipanti, eventuali inviti ricevuti vengono automaticamente annullati.","close":"Chiudi"},"challenge_detail":{"challenge_future_start":"Questa sfida inizierà il giorno: {{startDate}}","survey":"Questionario","title":"Configura sfida","won":"Hai vinto!","prize":"Hai vinto {{prize}}","lost":"Hai perso!"},"stats":{"empty":"Per visualizzare le statistiche inizia a giocare con le sfide!","filter":{"campaign":"Campagna","no_campaigns":"Nessun gioco presente"},"totalChallenges":"{{totalChallenges}} sfide","totalWon":"{{totalWon}} vinte","singleChallengeWin":{"single":"vinta","plural":"vinte"},"singleChallengeLost":{"single":"persa","plural":"perse"}},"create":{"configure":"Sfida di coppia","button_create":"Clicca qui per creare la tua sfida!","title":"Configura sfida","choose_type":"Scegli tipologia di sfida","choose_metric":"Scegli metrica di sfida","choose_partner":"Scegli il compagno","activate":"Attiva sfida","invite":"INVITA","preview":{"model":"Tipo:","mean":"Modalità selezionata:","challengeable":"Giocatore da sfidare:","you":"Tu"},"sent_title":"Hai invitato {{nickname}} ad una sfida di coppia","sent_body":"L’invito sarà visibile sull’app di {{nickname}}. Riceverai una notifica se {{nickname}} accetta o rifiuta la sfida. Nel caso non rispondesse entro il tempo massimo (venerdì ore 12), la sfida sarà annullata. ","close":"Chiudi"},"challenge_model":{"title":"Che tipo di sfida vuoi creare?","name":{"groupCompetitivePerformance":"Competitiva a performance","groupCompetitiveTime":"Competitiva a tempo","groupCooperative":"Cooperativa","survey":"Questionario","default":"Sfida singola","default-team":"Sfida di squadra","teams":"Sfida fra squadre"},"description":{"groupCompetitivePerformance":"Supera il tuo avversario su una metrica a scelta entro una settimana","groupCompetitiveTime":"Raggiungi un traguardo prima del tuo avversario!","groupCooperative":"Raggiungi un obiettivo collaborando con un altro giocatore."},"disabled_until_level":"Tipologia sfida sbloccata al livello {{level}}!"},"challenge_mean":{"title":"Come preferisci affrontare la sfida?","label":{"Bike_Km":"Km in bici","Walk_Km":"Km a piedi","Boat_Km":"Km in battello","Bus_Km":"Km in bus","Car_Km":"Km in carpooling","Train_Km":"Km in treno"},"pointconcept":{"Bike_Km":"Km in bici","Walk_Km":"Km a piedi","green leaves":"ecoLeaves"}}},"wizard":{"next":"Avanti","back":"Indietro"},"outof":"{{current}} su {{total}}","Language":"Lingua","join":"Scopri","home":"Play&Go","home_title":"Home","profile_title":"Profilo","campaigns_title":"Campagne disponibili","playNow":"Gioca adesso","noMessages":"Nessun messaggio","noCampaigns":"Nessuna campagna","noOtherCampaigns":"Nessuna nuova campagna disponibile.","messages":"Messaggi","generalStatistics":"Statistiche attività","noStatistics":"Nessuna statistica disponibile","activities":"Le mie attività","noActivities":"Nessuna attività disponibile","greenLeaves":"Green Leaves","forNextLevel":"al prossimo livello","challenge":"Sfida","totals":"totali","thisWeek":"questa settimana","classificationList":"Posizione classifica","activeSince":"Attiva da","to":"a","madeToday":"Fatti oggi","maximumKmPerToday":"massimi per oggi","total":"totali","tier":"Classifica","adhesionCode":"Codice adesione","generalTier":"Classifica generale","weeklyTier":"Classifica settimanale","number":{"ordinal":{"one":"","two":"","few":"","other":"{{ordinal}}°","many":"{{ordinal}}°"}},"date":{"from_to":"dal {{from}} al {{to}}"}}');

/***/ }),

/***/ 79238:
/*!******************************************************************************************!*\
  !*** ./src/app/core/shared/campaigns/main-campaign-stat/main-campaign-stat.component.ts ***!
  \******************************************************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   MainCampaignStatComponent: () => (/* binding */ MainCampaignStatComponent)
/* harmony export */ });
/* harmony import */ var luxon__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! luxon */ 45967);
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @angular/core */ 12481);
/* harmony import */ var _services_campaign_service__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! ../../services/campaign.service */ 76658);
/* harmony import */ var _ngx_translate_core__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @ngx-translate/core */ 48503);
/* harmony import */ var src_app_core_shared_pipes_localDate_pipe__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! ../../pipes/localDate.pipe */ 86451);
/* harmony import */ var _angular_common__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! @angular/common */ 93683);
/* harmony import */ var _ionic_angular__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! @ionic/angular */ 21507);
/* harmony import */ var _globalization_ordinal_number_ordinal_number_component__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(/*! ../../globalization/ordinal-number/ordinal-number.component */ 6972);
/* harmony import */ var _record_status_record_status_component__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(/*! ./record-status/record-status.component */ 1284);
/* harmony import */ var _game_status_game_status_component__WEBPACK_IMPORTED_MODULE_9__ = __webpack_require__(/*! ./game-status/game-status.component */ 86208);
/* harmony import */ var _ui_icon_icon_component__WEBPACK_IMPORTED_MODULE_10__ = __webpack_require__(/*! ../../ui/icon/icon.component */ 59621);
/* harmony import */ var _limit_status_limit_status_component__WEBPACK_IMPORTED_MODULE_11__ = __webpack_require__(/*! ./limit-status/limit-status.component */ 59002);
/* harmony import */ var _pipes_localNumber_pipe__WEBPACK_IMPORTED_MODULE_12__ = __webpack_require__(/*! ../../pipes/localNumber.pipe */ 16024);
var _staticBlock;














const _c0 = (a0, a1) => ({
  value: a0,
  unit: a1
});
const _c1 = (a0, a1, a2, a3) => ({
  value: a0,
  unit: a1,
  date: a2,
  dateTo: a3
});
function MainCampaignStatComponent_ion_col_3_app_icon_1_Template(rf, ctx) {
  if (rf & 1) {
    _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵelement"](0, "app-icon", 10);
  }
}
function MainCampaignStatComponent_ion_col_3_ng_template_2_Template(rf, ctx) {
  if (rf & 1) {
    _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵelement"](0, "app-icon", 11);
  }
  if (rf & 2) {
    const ctx_r0 = _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵnextContext"](2);
    _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵproperty"]("name", ctx_r0.campaignService.getCampaignTypeIcon(ctx_r0.campaignContainer == null ? null : ctx_r0.campaignContainer.campaign));
  }
}
function MainCampaignStatComponent_ion_col_3_Template(rf, ctx) {
  if (rf & 1) {
    _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵelementStart"](0, "ion-col", 8);
    _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵtemplate"](1, MainCampaignStatComponent_ion_col_3_app_icon_1_Template, 1, 0, "app-icon", 9)(2, MainCampaignStatComponent_ion_col_3_ng_template_2_Template, 1, 1, "ng-template", null, 1, _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵtemplateRefExtractor"]);
    _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵelementEnd"]();
  }
  if (rf & 2) {
    const typeIcon_r2 = _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵreference"](3);
    const ctx_r0 = _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵnextContext"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵadvance"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵproperty"]("ngIf", ctx_r0.showRanking)("ngIfElse", typeIcon_r2);
  }
}
function MainCampaignStatComponent_ion_col_4_ng_container_1_span_15_Template(rf, ctx) {
  if (rf & 1) {
    _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵelementStart"](0, "span");
    _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵtext"](1);
    _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵelementEnd"]();
  }
  if (rf & 2) {
    const ctx_r0 = _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵnextContext"](3);
    _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵadvance"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵtextInterpolate"](ctx_r0.unit);
  }
}
function MainCampaignStatComponent_ion_col_4_ng_container_1_Template(rf, ctx) {
  if (rf & 1) {
    _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵelementContainerStart"](0);
    _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵelementStart"](1, "ion-row", 14)(2, "ion-col", 15)(3, "span", 16);
    _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵtext"](4);
    _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵpipe"](5, "translate");
    _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵelementEnd"]()();
    _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵelementStart"](6, "ion-col", 17);
    _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵelement"](7, "app-ordinal-number", 18);
    _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵelementEnd"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵelementStart"](8, "ion-col", 19);
    _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵtext"](9, " - ");
    _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵelementEnd"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵelementStart"](10, "ion-col", 17)(11, "p", 20)(12, "b");
    _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵtext"](13);
    _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵpipe"](14, "localNumber");
    _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵtemplate"](15, MainCampaignStatComponent_ion_col_4_ng_container_1_span_15_Template, 2, 1, "span", 7);
    _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵelementEnd"]()()();
    _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵelementStart"](16, "ion-col", 21);
    _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵelement"](17, "app-icon", 22);
    _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵelementEnd"]()();
    _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵelementContainerEnd"]();
  }
  if (rf & 2) {
    const ctx_r0 = _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵnextContext"](2);
    _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵadvance"](4);
    _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵtextInterpolate1"](" ", _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵpipeBind1"](5, 5, "campaigns.homewidgets.stat.weekposition"), " ");
    _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵadvance"](3);
    _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵproperty"]("value", ctx_r0.reportWeekStat == null ? null : ctx_r0.reportWeekStat.position);
    _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵadvance"](6);
    _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵtextInterpolate1"]("", _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵpipeBind2"](14, 7, ctx_r0.getValueByUnit(ctx_r0.reportWeekStat == null ? null : ctx_r0.reportWeekStat.value, ctx_r0.unit, ctx_r0.campaignContainer == null ? null : ctx_r0.campaignContainer.campaign == null ? null : ctx_r0.campaignContainer.campaign.specificData == null ? null : ctx_r0.campaignContainer.campaign.specificData.virtualScore), "0.0-1"), " ");
    _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵadvance"](2);
    _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵproperty"]("ngIf", ctx_r0.unit !== "eL");
    _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵadvance"](2);
    _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵproperty"]("name", ctx_r0.campaignService.getCampaignTypeIcon(ctx_r0.campaignContainer == null ? null : ctx_r0.campaignContainer.campaign));
  }
}
function MainCampaignStatComponent_ion_col_4_ng_container_2_span_15_Template(rf, ctx) {
  if (rf & 1) {
    _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵelementStart"](0, "span");
    _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵtext"](1);
    _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵelementEnd"]();
  }
  if (rf & 2) {
    const ctx_r0 = _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵnextContext"](3);
    _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵadvance"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵtextInterpolate"](ctx_r0.unit);
  }
}
function MainCampaignStatComponent_ion_col_4_ng_container_2_Template(rf, ctx) {
  if (rf & 1) {
    _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵelementContainerStart"](0, 16);
    _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵelementStart"](1, "ion-row", 14)(2, "ion-col", 15)(3, "span");
    _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵtext"](4);
    _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵpipe"](5, "translate");
    _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵelementEnd"]()();
    _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵelementStart"](6, "ion-col", 17);
    _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵelement"](7, "app-ordinal-number", 18);
    _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵelementEnd"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵelementStart"](8, "ion-col", 19);
    _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵtext"](9, " - ");
    _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵelementEnd"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵelementStart"](10, "ion-col", 17)(11, "p", 20)(12, "b");
    _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵtext"](13);
    _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵpipe"](14, "localNumber");
    _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵtemplate"](15, MainCampaignStatComponent_ion_col_4_ng_container_2_span_15_Template, 2, 1, "span", 7);
    _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵelementEnd"]()()();
    _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵelementStart"](16, "ion-col", 21);
    _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵelement"](17, "app-icon", 22);
    _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵelementEnd"]()();
    _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵelementContainerEnd"]();
  }
  if (rf & 2) {
    const ctx_r0 = _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵnextContext"](2);
    _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵadvance"](4);
    _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵtextInterpolate1"](" ", _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵpipeBind1"](5, 5, "campaigns.homewidgets.stat.totalposition"), " ");
    _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵadvance"](3);
    _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵproperty"]("value", ctx_r0.reportTotalStat == null ? null : ctx_r0.reportTotalStat.position);
    _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵadvance"](6);
    _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵtextInterpolate1"]("", _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵpipeBind2"](14, 7, ctx_r0.getValueByUnit(ctx_r0.reportTotalStat == null ? null : ctx_r0.reportTotalStat.value, ctx_r0.unit, ctx_r0.campaignContainer == null ? null : ctx_r0.campaignContainer.campaign == null ? null : ctx_r0.campaignContainer.campaign.specificData == null ? null : ctx_r0.campaignContainer.campaign.specificData.virtualScore), "0.0-1"), " ");
    _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵadvance"](2);
    _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵproperty"]("ngIf", ctx_r0.unit !== "eL");
    _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵadvance"](2);
    _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵproperty"]("name", ctx_r0.campaignService.getCampaignTypeIcon(ctx_r0.campaignContainer == null ? null : ctx_r0.campaignContainer.campaign));
  }
}
function MainCampaignStatComponent_ion_col_4_Template(rf, ctx) {
  if (rf & 1) {
    _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵelementStart"](0, "ion-col", 12);
    _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵtemplate"](1, MainCampaignStatComponent_ion_col_4_ng_container_1_Template, 18, 10, "ng-container", 7)(2, MainCampaignStatComponent_ion_col_4_ng_container_2_Template, 18, 10, "ng-container", 13);
    _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵelementEnd"]();
  }
  if (rf & 2) {
    const ctx_r0 = _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵnextContext"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵadvance"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵproperty"]("ngIf", ctx_r0.reportWeekStat);
    _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵadvance"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵproperty"]("ngIf", ctx_r0.reportTotalStat);
  }
}
function MainCampaignStatComponent_ion_col_5_p_1_Template(rf, ctx) {
  if (rf & 1) {
    _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵelement"](0, "p", 25);
    _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵpipe"](1, "localNumber");
    _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵpipe"](2, "translate");
  }
  if (rf & 2) {
    const ctx_r0 = _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵnextContext"](2);
    _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵproperty"]("innerHtml", _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵpipeBind2"](2, 4, "campaigns.homewidgets.stat.weekvalue", _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵpureFunction2"](7, _c0, _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵpipeBind2"](1, 1, ctx_r0.getValueByUnit(ctx_r0.reportWeekStat == null ? null : ctx_r0.reportWeekStat.value, ctx_r0.unit, ctx_r0.campaignContainer == null ? null : ctx_r0.campaignContainer.campaign == null ? null : ctx_r0.campaignContainer.campaign.specificData == null ? null : ctx_r0.campaignContainer.campaign.specificData.virtualScore), "0.0-1"), ctx_r0.unit)), _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵsanitizeHtml"]);
  }
}
function MainCampaignStatComponent_ion_col_5_p_2_Template(rf, ctx) {
  if (rf & 1) {
    _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵelement"](0, "p", 25);
    _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵpipe"](1, "localNumber");
    _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵpipe"](2, "translate");
  }
  if (rf & 2) {
    const ctx_r0 = _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵnextContext"](2);
    _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵproperty"]("innerHtml", _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵpipeBind2"](2, 4, "campaigns.homewidgets.stat.monthvalue", _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵpureFunction2"](7, _c0, _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵpipeBind2"](1, 1, ctx_r0.getValueByUnit(ctx_r0.reportMonthStat == null ? null : ctx_r0.reportMonthStat.value, ctx_r0.unit, ctx_r0.campaignContainer == null ? null : ctx_r0.campaignContainer.campaign == null ? null : ctx_r0.campaignContainer.campaign.specificData == null ? null : ctx_r0.campaignContainer.campaign.specificData.virtualScore), "0.0-1"), ctx_r0.unit)), _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵsanitizeHtml"]);
  }
}
function MainCampaignStatComponent_ion_col_5_p_3_Template(rf, ctx) {
  if (rf & 1) {
    _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵelement"](0, "p", 25);
    _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵpipe"](1, "localNumber");
    _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵpipe"](2, "translate");
  }
  if (rf & 2) {
    const ctx_r0 = _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵnextContext"](2);
    _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵproperty"]("innerHtml", _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵpipeBind2"](2, 4, "campaigns.homewidgets.stat.totalvalue", _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵpureFunction2"](7, _c0, _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵpipeBind2"](1, 1, ctx_r0.getValueByUnit(ctx_r0.reportTotalStat == null ? null : ctx_r0.reportTotalStat.value, ctx_r0.unit, ctx_r0.campaignContainer == null ? null : ctx_r0.campaignContainer.campaign == null ? null : ctx_r0.campaignContainer.campaign.specificData == null ? null : ctx_r0.campaignContainer.campaign.specificData.virtualScore), "0.0-1"), ctx_r0.unit)), _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵsanitizeHtml"]);
  }
}
function MainCampaignStatComponent_ion_col_5_p_4_Template(rf, ctx) {
  if (rf & 1) {
    _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵelement"](0, "p", 25);
    _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵpipe"](1, "localNumber");
    _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵpipe"](2, "localDate");
    _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵpipe"](3, "localDate");
    _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵpipe"](4, "translate");
  }
  if (rf & 2) {
    const ctx_r0 = _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵnextContext"](2);
    _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵproperty"]("innerHtml", _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵpipeBind2"](4, 8, "campaigns.homewidgets.stat.lastpaymentkm", _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵpureFunction4"](11, _c1, _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵpipeBind2"](1, 1, ctx_r0.getValueByUnit(ctx_r0.lastPaymentStat == null ? null : ctx_r0.lastPaymentStat.value, ctx_r0.unit, ctx_r0.campaignContainer == null ? null : ctx_r0.campaignContainer.campaign == null ? null : ctx_r0.campaignContainer.campaign.specificData == null ? null : ctx_r0.campaignContainer.campaign.specificData.virtualScore), "0.0-1"), ctx_r0.unit, _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵpipeBind1"](2, 4, ctx_r0.lastPaymentDate), _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵpipeBind1"](3, 6, ctx_r0.lastPaymentDateTo))), _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵsanitizeHtml"]);
  }
}
function MainCampaignStatComponent_ion_col_5_Template(rf, ctx) {
  if (rf & 1) {
    _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵelementStart"](0, "ion-col", 23);
    _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵtemplate"](1, MainCampaignStatComponent_ion_col_5_p_1_Template, 3, 10, "p", 24)(2, MainCampaignStatComponent_ion_col_5_p_2_Template, 3, 10, "p", 24)(3, MainCampaignStatComponent_ion_col_5_p_3_Template, 3, 10, "p", 24)(4, MainCampaignStatComponent_ion_col_5_p_4_Template, 5, 16, "p", 24);
    _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵelementEnd"]();
  }
  if (rf & 2) {
    const ctx_r0 = _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵnextContext"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵadvance"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵproperty"]("ngIf", ctx_r0.reportWeekStat);
    _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵadvance"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵproperty"]("ngIf", ctx_r0.reportMonthStat);
    _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵadvance"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵproperty"]("ngIf", ctx_r0.reportTotalStat);
    _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵadvance"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵproperty"]("ngIf", ctx_r0.lastPaymentStat);
  }
}
function MainCampaignStatComponent_ng_container_6_ion_row_1_Template(rf, ctx) {
  if (rf & 1) {
    _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵelementStart"](0, "ion-row")(1, "ion-col");
    _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵelement"](2, "app-game-status", 27);
    _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵelementEnd"]()();
  }
  if (rf & 2) {
    const ctx_r0 = _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵnextContext"](2);
    _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵadvance"](2);
    _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵproperty"]("status", ctx_r0.status)("campaign", ctx_r0.campaignContainer == null ? null : ctx_r0.campaignContainer.campaign)("type", ctx_r0.campaignContainer == null ? null : ctx_r0.campaignContainer.campaign == null ? null : ctx_r0.campaignContainer.campaign.type);
  }
}
function MainCampaignStatComponent_ng_container_6_Template(rf, ctx) {
  if (rf & 1) {
    _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵelementContainerStart"](0);
    _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵtemplate"](1, MainCampaignStatComponent_ng_container_6_ion_row_1_Template, 3, 3, "ion-row", 26);
    _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵelementContainerEnd"]();
  }
  if (rf & 2) {
    const ctx_r0 = _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵnextContext"]();
    const nullStatus_r3 = _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵreference"](11);
    _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵadvance"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵproperty"]("ngIf", ctx_r0.status !== null)("ngIfElse", nullStatus_r3);
  }
}
function MainCampaignStatComponent_ion_row_7_Template(rf, ctx) {
  if (rf & 1) {
    _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵelementStart"](0, "ion-row")(1, "ion-col");
    _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵelement"](2, "app-record-status", 28);
    _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵelementEnd"]()();
  }
  if (rf & 2) {
    const ctx_r0 = _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵnextContext"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵadvance"](2);
    _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵproperty"]("status", ctx_r0.reportWeekStat)("record", ctx_r0.record)("type", ctx_r0.campaignContainer == null ? null : ctx_r0.campaignContainer.campaign == null ? null : ctx_r0.campaignContainer.campaign.type);
  }
}
function MainCampaignStatComponent_ion_row_8_Template(rf, ctx) {
  if (rf & 1) {
    _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵelementStart"](0, "ion-row")(1, "ion-col");
    _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵelement"](2, "app-limit-status", 29);
    _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵelementEnd"]()();
  }
  if (rf & 2) {
    const ctx_r0 = _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵnextContext"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵadvance"](2);
    _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵproperty"]("campaign", ctx_r0.campaignContainer == null ? null : ctx_r0.campaignContainer.campaign)("limitMax", ctx_r0.limitDayMax)("limitValue", ctx_r0.limitDayValue)("infoBox", true)("virtualScoreLabel", ctx_r0.getLabel(ctx_r0.campaignContainer == null ? null : ctx_r0.campaignContainer.campaign == null ? null : ctx_r0.campaignContainer.campaign.specificData == null ? null : ctx_r0.campaignContainer.campaign.specificData.virtualScore == null ? null : ctx_r0.campaignContainer.campaign.specificData.virtualScore.firstLimitBar))("type", ctx_r0.campaignContainer == null ? null : ctx_r0.campaignContainer.campaign == null ? null : ctx_r0.campaignContainer.campaign.type)("header", ctx_r0.getHeader(ctx_r0.campaignContainer == null ? null : ctx_r0.campaignContainer.campaign == null ? null : ctx_r0.campaignContainer.campaign.specificData == null ? null : ctx_r0.campaignContainer.campaign.specificData.virtualScore == null ? null : ctx_r0.campaignContainer.campaign.specificData.virtualScore.firstLimitBar));
  }
}
function MainCampaignStatComponent_ion_row_9_Template(rf, ctx) {
  if (rf & 1) {
    _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵelementStart"](0, "ion-row")(1, "ion-col");
    _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵelement"](2, "app-limit-status", 30);
    _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵelementEnd"]()();
  }
  if (rf & 2) {
    const ctx_r0 = _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵnextContext"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵadvance"](2);
    _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵproperty"]("limitMax", ctx_r0.limitMonthMax)("limitValue", ctx_r0.limitMonthValue)("virtualScoreLabel", ctx_r0.getLabel(ctx_r0.campaignContainer == null ? null : ctx_r0.campaignContainer.campaign == null ? null : ctx_r0.campaignContainer.campaign.specificData == null ? null : ctx_r0.campaignContainer.campaign.specificData.virtualScore == null ? null : ctx_r0.campaignContainer.campaign.specificData.virtualScore.secondLimitBar))("type", ctx_r0.campaignContainer == null ? null : ctx_r0.campaignContainer.campaign == null ? null : ctx_r0.campaignContainer.campaign.type)("header", ctx_r0.getHeader(ctx_r0.campaignContainer == null ? null : ctx_r0.campaignContainer.campaign == null ? null : ctx_r0.campaignContainer.campaign.specificData == null ? null : ctx_r0.campaignContainer.campaign.specificData.virtualScore == null ? null : ctx_r0.campaignContainer.campaign.specificData.virtualScore.secondLimitBar));
  }
}
function MainCampaignStatComponent_ng_template_10_Template(rf, ctx) {
  if (rf & 1) {
    _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵelementStart"](0, "ion-row")(1, "ion-col");
    _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵtext"](2);
    _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵpipe"](3, "translate");
    _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵelementEnd"]()();
  }
  if (rf & 2) {
    _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵadvance"](2);
    _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵtextInterpolate1"](" ", _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵpipeBind1"](3, 1, "campaigns.homewidgets.stat.emptystatus"));
  }
}
class MainCampaignStatComponent {
  constructor(campaignService, translateService, localDatePipe) {
    this.campaignService = campaignService;
    this.translateService = translateService;
    this.localDatePipe = localDatePipe;
    this.status = undefined;
    this.record = undefined;
    this.showRanking = true;
    this.showGameStatus = false;
    this.unit = '';
  }
  getValueByUnit(value, unit, virtualSore) {
    if ('Km' === unit && !virtualSore) {
      return value / 1000;
    }
    return value;
  }
  ngOnInit() {
    this.month = luxon__WEBPACK_IMPORTED_MODULE_0__.DateTime.local().toMillis();
    console.log(this.month);
  }
  getLabel(metric) {
    if (!metric) {
      return '';
    }
    return metric.startsWith('score') ? this.campaignContainer?.campaign?.specificData?.virtualScore?.label : this.translateService.instant('travels');
  }
  getTitle(title) {
    if (!title) {
      return '';
    }
    return title[0].toUpperCase() + title.substr(1).toLowerCase();
  }
  getHeader(barMetric) {
    var category = this.categorize(barMetric);
    switch (category) {
      case 'Daily':
        return this.translateService.instant('campaigns.homewidgets.stat.today');
      case 'Weekly':
        return this.translateService.instant('campaigns.homewidgets.stat.thisWeek');
      case 'Monthly':
        // return this.translateService.instant('campaigns.homewidgets.stat.thisWeek');
        return this.getTitle(this.localDatePipe.transform(this.month, 'LLLL')) + ': ';
      default:
        return "";
    }
    return "";
    // 'campaigns.homewidgets.stat.today' | translate
    // getTitle(month|localDate: 'LLLL')
  }
  categorize(metric) {
    if (metric?.includes('Daily')) {
      return 'Daily';
    }
    if (metric?.includes('Monthly')) {
      return 'Monthly';
    }
    if (metric?.includes('eekly')) {
      return 'Weekly';
    }
  }
  static #_ = _staticBlock = () => (this.ɵfac = function MainCampaignStatComponent_Factory(__ngFactoryType__) {
    return new (__ngFactoryType__ || MainCampaignStatComponent)(_angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵdirectiveInject"](_services_campaign_service__WEBPACK_IMPORTED_MODULE_2__.CampaignService), _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵdirectiveInject"](_ngx_translate_core__WEBPACK_IMPORTED_MODULE_3__.TranslateService), _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵdirectiveInject"](src_app_core_shared_pipes_localDate_pipe__WEBPACK_IMPORTED_MODULE_4__.LocalDatePipe));
  }, this.ɵcmp = /*@__PURE__*/_angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵdefineComponent"]({
    type: MainCampaignStatComponent,
    selectors: [["app-main-campaign-stat"]],
    inputs: {
      campaignContainer: "campaignContainer",
      status: "status",
      record: "record",
      reportWeekStat: "reportWeekStat",
      reportMonthStat: "reportMonthStat",
      reportTotalStat: "reportTotalStat",
      limitMonthMax: "limitMonthMax",
      limitMonthValue: "limitMonthValue",
      limitDayMax: "limitDayMax",
      limitDayValue: "limitDayValue",
      showRanking: "showRanking",
      showGameStatus: "showGameStatus",
      unit: "unit",
      lastPaymentStat: "lastPaymentStat",
      lastPaymentDate: "lastPaymentDate",
      lastPaymentDateTo: "lastPaymentDateTo"
    },
    standalone: false,
    decls: 12,
    vars: 7,
    consts: [["nullStatus", ""], ["typeIcon", ""], [1, "container"], [1, "min-height", "ion-no-margin"], ["class", "ion-no-margin", "size", "2", 4, "ngIf"], ["size", "10", "class", "ranking ion-no-margin", 4, "ngIf"], ["class", "report", 4, "ngIf"], [4, "ngIf"], ["size", "2", 1, "ion-no-margin"], ["class", "icon-header", "name", "leaderboard", 4, "ngIf", "ngIfElse"], ["name", "leaderboard", 1, "icon-header"], [1, "icon-header", 3, "name"], ["size", "10", 1, "ranking", "ion-no-margin"], ["class", "ion-text-left", 4, "ngIf"], [1, "ion-no-margin", "stat-row"], ["size", "5", 1, "ion-no-margin", "ion-no-padding"], [1, "ion-text-left"], ["size", "auto", 1, "ion-no-margin", "ion-no-padding"], [3, "value"], ["size", "auto"], [1, "unit-value"], [1, "ion-text-start", "ion-margin-end", "ion-margin-end", "ion-no-padding"], [1, "icon-stat", 3, "name"], [1, "report"], ["class", "ion-text-left", 3, "innerHtml", 4, "ngIf"], [1, "ion-text-left", 3, "innerHtml"], [4, "ngIf", "ngIfElse"], [3, "status", "campaign", "type"], [3, "status", "record", "type"], [3, "campaign", "limitMax", "limitValue", "infoBox", "virtualScoreLabel", "type", "header"], [3, "limitMax", "limitValue", "virtualScoreLabel", "type", "header"]],
    template: function MainCampaignStatComponent_Template(rf, ctx) {
      if (rf & 1) {
        _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵelementStart"](0, "div", 2)(1, "ion-grid")(2, "ion-row", 3);
        _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵtemplate"](3, MainCampaignStatComponent_ion_col_3_Template, 4, 2, "ion-col", 4)(4, MainCampaignStatComponent_ion_col_4_Template, 3, 2, "ion-col", 5)(5, MainCampaignStatComponent_ion_col_5_Template, 5, 4, "ion-col", 6);
        _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵtemplate"](6, MainCampaignStatComponent_ng_container_6_Template, 2, 2, "ng-container", 7)(7, MainCampaignStatComponent_ion_row_7_Template, 3, 3, "ion-row", 7)(8, MainCampaignStatComponent_ion_row_8_Template, 3, 7, "ion-row", 7)(9, MainCampaignStatComponent_ion_row_9_Template, 3, 5, "ion-row", 7)(10, MainCampaignStatComponent_ng_template_10_Template, 4, 3, "ng-template", null, 0, _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵtemplateRefExtractor"]);
        _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵelementEnd"]()();
      }
      if (rf & 2) {
        _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵadvance"](3);
        _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵproperty"]("ngIf", ctx.reportWeekStat || ctx.reportMonthStat || ctx.reportTotalStat);
        _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵadvance"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵproperty"]("ngIf", ctx.showRanking);
        _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵadvance"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵproperty"]("ngIf", !ctx.showRanking);
        _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵadvance"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵproperty"]("ngIf", ctx.showGameStatus);
        _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵadvance"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵproperty"]("ngIf", ctx.record && ctx.reportWeekStat);
        _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵadvance"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵproperty"]("ngIf", ctx.limitDayValue);
        _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵadvance"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵproperty"]("ngIf", ctx.limitMonthValue !== null);
      }
    },
    dependencies: [_angular_common__WEBPACK_IMPORTED_MODULE_5__.NgIf, _ionic_angular__WEBPACK_IMPORTED_MODULE_6__.IonCol, _ionic_angular__WEBPACK_IMPORTED_MODULE_6__.IonGrid, _ionic_angular__WEBPACK_IMPORTED_MODULE_6__.IonRow, _globalization_ordinal_number_ordinal_number_component__WEBPACK_IMPORTED_MODULE_7__.OrdinalNumberComponent, _record_status_record_status_component__WEBPACK_IMPORTED_MODULE_8__.RecordStatusComponent, _game_status_game_status_component__WEBPACK_IMPORTED_MODULE_9__.GameStatusComponent, _ui_icon_icon_component__WEBPACK_IMPORTED_MODULE_10__.IconComponent, _limit_status_limit_status_component__WEBPACK_IMPORTED_MODULE_11__.LimitStatusComponent, _ngx_translate_core__WEBPACK_IMPORTED_MODULE_3__.TranslatePipe, src_app_core_shared_pipes_localDate_pipe__WEBPACK_IMPORTED_MODULE_4__.LocalDatePipe, _pipes_localNumber_pipe__WEBPACK_IMPORTED_MODULE_12__.LocalNumberPipe],
    styles: [".container[_ngcontent-%COMP%] {\n  color: black;\n}\n.container[_ngcontent-%COMP%]   ion-grid[_ngcontent-%COMP%]   .min-height[_ngcontent-%COMP%] {\n  min-height: 70px;\n}\n.container[_ngcontent-%COMP%]   ion-grid[_ngcontent-%COMP%]   ion-col[_ngcontent-%COMP%] {\n  display: flex;\n  flex-direction: column;\n  justify-content: center;\n}\n.container[_ngcontent-%COMP%]   ion-grid[_ngcontent-%COMP%]   app-ordinal-number[_ngcontent-%COMP%] {\n  font-weight: bold;\n}\n.container[_ngcontent-%COMP%]   ion-grid[_ngcontent-%COMP%]   .report[_ngcontent-%COMP%] {\n  display: flex;\n  flex-direction: column;\n  justify-content: space-around;\n  color: var(--dark-grey);\n}\n.container[_ngcontent-%COMP%]   ion-grid[_ngcontent-%COMP%]   .ranking[_ngcontent-%COMP%] {\n  font-size: 14px;\n  text-align: left;\n  color: var(--dark-grey);\n}\n.container[_ngcontent-%COMP%]   ion-grid[_ngcontent-%COMP%]   .icon-header[_ngcontent-%COMP%] {\n  font-size: 34px;\n}\n.container[_ngcontent-%COMP%]   ion-grid[_ngcontent-%COMP%]   .icon-header[_ngcontent-%COMP%]   ion-icon[_ngcontent-%COMP%] {\n  margin-top: 0px;\n  margin-bottom: 0px;\n}\n\n.unit-value[_ngcontent-%COMP%] {\n  min-width: 40px;\n}\n\n.stat-row[_ngcontent-%COMP%]   ion-col[_ngcontent-%COMP%] {\n  margin: 0px 2px;\n}\n.stat-row[_ngcontent-%COMP%]   ion-col[_ngcontent-%COMP%]   .icon-stat[_ngcontent-%COMP%] {\n  font-size: 18px;\n  margin-left: 2px;\n}\n/*# sourceMappingURL=data:application/json;charset=utf-8;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbIndlYnBhY2s6Ly8uL3NyYy9hcHAvY29yZS9zaGFyZWQvY2FtcGFpZ25zL21haW4tY2FtcGFpZ24tc3RhdC9tYWluLWNhbXBhaWduLXN0YXQuY29tcG9uZW50LnNjc3MiXSwibmFtZXMiOltdLCJtYXBwaW5ncyI6IkFBQUE7RUFFRSxZQUFBO0FBQUY7QUFFSTtFQUNFLGdCQUFBO0FBQU47QUFFSTtFQUNFLGFBQUE7RUFDQSxzQkFBQTtFQUNBLHVCQUFBO0FBQU47QUFFSTtFQUNFLGlCQUFBO0FBQU47QUFFSTtFQUNFLGFBQUE7RUFDQSxzQkFBQTtFQUNBLDZCQUFBO0VBQ0EsdUJBQUE7QUFBTjtBQUVJO0VBQ0UsZUFBQTtFQUNBLGdCQUFBO0VBQ0EsdUJBQUE7QUFBTjtBQUVJO0VBQ0UsZUFBQTtBQUFOO0FBQ007RUFDRSxlQUFBO0VBQ0Esa0JBQUE7QUFDUjs7QUFJQTtFQUNFLGVBQUE7QUFERjs7QUFJRTtFQUNFLGVBQUE7QUFESjtBQUVJO0VBQ0UsZUFBQTtFQUNBLGdCQUFBO0FBQU4iLCJzb3VyY2VzQ29udGVudCI6WyIuY29udGFpbmVyIHtcbiAgLy8gbWFyZ2luLXRvcDogMjRweDtcbiAgY29sb3I6IGJsYWNrO1xuICBpb24tZ3JpZCB7XG4gICAgLm1pbi1oZWlnaHQge1xuICAgICAgbWluLWhlaWdodDogNzBweDtcbiAgICB9XG4gICAgaW9uLWNvbCB7XG4gICAgICBkaXNwbGF5OiBmbGV4O1xuICAgICAgZmxleC1kaXJlY3Rpb246IGNvbHVtbjtcbiAgICAgIGp1c3RpZnktY29udGVudDogY2VudGVyO1xuICAgIH1cbiAgICBhcHAtb3JkaW5hbC1udW1iZXIge1xuICAgICAgZm9udC13ZWlnaHQ6IGJvbGQ7XG4gICAgfVxuICAgIC5yZXBvcnQge1xuICAgICAgZGlzcGxheTogZmxleDtcbiAgICAgIGZsZXgtZGlyZWN0aW9uOiBjb2x1bW47XG4gICAgICBqdXN0aWZ5LWNvbnRlbnQ6IHNwYWNlLWFyb3VuZDtcbiAgICAgIGNvbG9yOiB2YXIoLS1kYXJrLWdyZXkpO1xuICAgIH1cbiAgICAucmFua2luZyB7XG4gICAgICBmb250LXNpemU6IDE0cHg7XG4gICAgICB0ZXh0LWFsaWduOiBsZWZ0O1xuICAgICAgY29sb3I6IHZhcigtLWRhcmstZ3JleSk7XG4gICAgfVxuICAgIC5pY29uLWhlYWRlciB7XG4gICAgICBmb250LXNpemU6IDM0cHg7XG4gICAgICBpb24taWNvbiB7XG4gICAgICAgIG1hcmdpbi10b3A6IDBweDtcbiAgICAgICAgbWFyZ2luLWJvdHRvbTogMHB4O1xuICAgICAgfVxuICAgIH1cbiAgfVxufVxuLnVuaXQtdmFsdWUge1xuICBtaW4td2lkdGg6IDQwcHg7XG59XG4uc3RhdC1yb3cge1xuICBpb24tY29sIHtcbiAgICBtYXJnaW46IDBweCAycHg7XG4gICAgLmljb24tc3RhdCB7XG4gICAgICBmb250LXNpemU6IDE4cHg7XG4gICAgICBtYXJnaW4tbGVmdDogMnB4O1xuICAgIH1cbiAgfVxufVxuIl0sInNvdXJjZVJvb3QiOiIifQ== */"]
  }));
}
_staticBlock();

/***/ }),

/***/ 79811:
/*!*******************************************************************************!*\
  !*** ./src/app/core/api/generated/controllers/challengeController.service.ts ***!
  \*******************************************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   ChallengeControllerService: () => (/* binding */ ChallengeControllerService)
/* harmony export */ });
/* harmony import */ var src_environments_environment__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! src/environments/environment */ 45312);
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @angular/core */ 34205);
/* harmony import */ var _angular_common_http__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @angular/common/http */ 63855);
var _staticBlock;
/**
 * Play&Go Project
 * No description provided (generated by Swagger Codegen https://github.com/swagger-api/swagger-codegen)
 *
 * OpenAPI spec version: 2.0
 * Contact: info@smartcommunitylab.it
 *
 * NOTE: This class is auto generated by the swagger code generator program.
 * https://github.com/swagger-api/swagger-codegen.git
 * Do not edit the class manually.
 */



class ChallengeControllerService {
  constructor(http) {
    this.http = http;
  }
  /**
   * activateChallengeType
   *
   * @param challengeName challengeName
   * @param campaignId campaignId
   */
  activateChallengeTypeUsingPUT(args) {
    const {
      challengeName,
      campaignId
    } = args;
    return this.http.request('put', src_environments_environment__WEBPACK_IMPORTED_MODULE_0__.environment.serverUrl.api + `/playandgo/api/challenge/unlock/${encodeURIComponent(String(challengeName))}`, {
      params: removeNullOrUndefined({
        campaignId
      })
    });
  }
  /**
   * addToBlackList
   *
   * @param campaignId campaignId
   * @param blockedPlayerId blockedPlayerId
   */
  addToBlackListUsingPOST(args) {
    const {
      campaignId,
      blockedPlayerId
    } = args;
    return this.http.request('post', src_environments_environment__WEBPACK_IMPORTED_MODULE_0__.environment.serverUrl.api + `/playandgo/api/challenge/blacklist`, {
      params: removeNullOrUndefined({
        campaignId,
        blockedPlayerId
      })
    });
  }
  /**
   * changeInvitationStatus
   *
   * @param campaignId campaignId
   * @param challengeId challengeId
   * @param status status
   */
  changeInvitationStatusUsingPOST(args) {
    const {
      campaignId,
      challengeId,
      status
    } = args;
    return this.http.request('post', src_environments_environment__WEBPACK_IMPORTED_MODULE_0__.environment.serverUrl.api + `/playandgo/api/challenge/invitation/status/${encodeURIComponent(String(challengeId))}/${encodeURIComponent(String(status))}`, {
      params: removeNullOrUndefined({
        campaignId
      })
    });
  }
  /**
   * chooseChallenge
   *
   * @param challengeId challengeId
   * @param campaignId campaignId
   */
  chooseChallengeUsingPUT(args) {
    const {
      challengeId,
      campaignId
    } = args;
    return this.http.request('put', src_environments_environment__WEBPACK_IMPORTED_MODULE_0__.environment.serverUrl.api + `/playandgo/api/challenge/choose/${encodeURIComponent(String(challengeId))}`, {
      params: removeNullOrUndefined({
        campaignId
      })
    });
  }
  /**
   * deleteFromBlackList
   *
   * @param campaignId campaignId
   * @param blockedPlayerId blockedPlayerId
   */
  deleteFromBlackListUsingDELETE(args) {
    const {
      campaignId,
      blockedPlayerId
    } = args;
    return this.http.request('delete', src_environments_environment__WEBPACK_IMPORTED_MODULE_0__.environment.serverUrl.api + `/playandgo/api/challenge/blacklist`, {
      params: removeNullOrUndefined({
        campaignId,
        blockedPlayerId
      })
    });
  }
  /**
   * getBlackList
   *
   * @param campaignId campaignId
   */
  getBlackListUsingGET(campaignId) {
    return this.http.request('get', src_environments_environment__WEBPACK_IMPORTED_MODULE_0__.environment.serverUrl.api + `/playandgo/api/challenge/blacklist`, {
      params: removeNullOrUndefined({
        campaignId
      })
    });
  }
  /**
   * getChallengeStats
   *
   * @param campaignId campaignId
   * @param playerId playerId
   * @param groupMode groupMode
   * @param dateFrom yyyy-MM-dd
   * @param dateTo yyyy-MM-dd
   */
  getChallengeStatsUsingGET(args) {
    const {
      campaignId,
      playerId,
      groupMode,
      dateFrom,
      dateTo
    } = args;
    return this.http.request('get', src_environments_environment__WEBPACK_IMPORTED_MODULE_0__.environment.serverUrl.api + `/playandgo/api/challenge/stats`, {
      params: removeNullOrUndefined({
        campaignId,
        playerId,
        groupMode,
        dateFrom,
        dateTo
      })
    });
  }
  /**
   * getChallengeables
   *
   * @param campaignId campaignId
   */
  getChallengeablesUsingGET(campaignId) {
    return this.http.request('get', src_environments_environment__WEBPACK_IMPORTED_MODULE_0__.environment.serverUrl.api + `/playandgo/api/challenge/challengeables`, {
      params: removeNullOrUndefined({
        campaignId
      })
    });
  }
  /**
   * getChallengesStatus
   *
   * @param campaignId campaignId
   */
  getChallengesStatusUsingGET(campaignId) {
    return this.http.request('get', src_environments_environment__WEBPACK_IMPORTED_MODULE_0__.environment.serverUrl.api + `/playandgo/api/challenge/type`, {
      params: removeNullOrUndefined({
        campaignId
      })
    });
  }
  /**
   * getChallenges
   *
   * @param campaignId campaignId
   * @param filter filter
   */
  getChallengesUsingGET(args) {
    const {
      campaignId,
      filter
    } = args;
    return this.http.request('get', src_environments_environment__WEBPACK_IMPORTED_MODULE_0__.environment.serverUrl.api + `/playandgo/api/challenge`, {
      params: removeNullOrUndefined({
        campaignId,
        filter
      })
    });
  }
  /**
   * getCompletedChallanges
   *
   * @param campaignId campaignId
   * @param dateFrom UTC millis
   * @param dateTo UTC millis
   */
  getCompletedChallangesUsingGET(args) {
    const {
      campaignId,
      dateFrom,
      dateTo
    } = args;
    return this.http.request('get', src_environments_environment__WEBPACK_IMPORTED_MODULE_0__.environment.serverUrl.api + `/playandgo/api/challenge/completed`, {
      params: removeNullOrUndefined({
        campaignId,
        dateFrom,
        dateTo
      })
    });
  }
  /**
   * getGroupChallengePreview
   *
   * @param campaignId campaignId
   * @param body
   */
  getGroupChallengePreviewUsingPOST(args) {
    const {
      campaignId,
      body
    } = args;
    return this.http.request('post', src_environments_environment__WEBPACK_IMPORTED_MODULE_0__.environment.serverUrl.api + `/playandgo/api/challenge/invitation/preview`, {
      body,
      params: removeNullOrUndefined({
        campaignId
      })
    });
  }
  /**
   * getRewards
   *
   */
  getRewardsUsingGET() {
    return this.http.request('get', src_environments_environment__WEBPACK_IMPORTED_MODULE_0__.environment.serverUrl.api + `/playandgo/api/challenge/rewards`, {});
  }
  /**
   * sendInvitation
   *
   * @param campaignId campaignId
   * @param body
   */
  sendInvitationUsingPOST(args) {
    const {
      campaignId,
      body
    } = args;
    return this.http.request('post', src_environments_environment__WEBPACK_IMPORTED_MODULE_0__.environment.serverUrl.api + `/playandgo/api/challenge/invitation`, {
      body,
      params: removeNullOrUndefined({
        campaignId
      })
    });
  }
  /**
    * getCompletedChallangesByTeam
    *
    * @param campaignId campaignId
    * @param teamId teamId
    * @param dateFrom UTC millis
    * @param dateTo UTC millis
    */
  getCompletedChallangesByTeamUsingGET(args) {
    const {
      campaignId,
      teamId,
      dateFrom,
      dateTo
    } = args;
    return this.http.request('get', src_environments_environment__WEBPACK_IMPORTED_MODULE_0__.environment.serverUrl.api + `/playandgo/api/challenge/completed/team`, {
      params: removeNullOrUndefined({
        campaignId,
        teamId,
        dateFrom,
        dateTo
      })
    });
  }
  /**
   * getChallengesByTeam
   *
   * @param campaignId campaignId
   * @param teamId teamId
   * @param filter filter
   */
  getChallengesByTeamUsingGET(args) {
    const {
      campaignId,
      teamId,
      filter
    } = args;
    return this.http.request('get', src_environments_environment__WEBPACK_IMPORTED_MODULE_0__.environment.serverUrl.api + `/playandgo/api/challenge/team`, {
      params: removeNullOrUndefined({
        campaignId,
        teamId,
        filter
      })
    });
  }
  static #_ = _staticBlock = () => (this.ɵfac = function ChallengeControllerService_Factory(__ngFactoryType__) {
    return new (__ngFactoryType__ || ChallengeControllerService)(_angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵinject"](_angular_common_http__WEBPACK_IMPORTED_MODULE_2__.HttpClient));
  }, this.ɵprov = /*@__PURE__*/_angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵdefineInjectable"]({
    token: ChallengeControllerService,
    factory: ChallengeControllerService.ɵfac,
    providedIn: 'root'
  }));
}
_staticBlock();
function removeNullOrUndefined(obj) {
  const newObj = {};
  Object.keys(obj).forEach(key => {
    if (obj[key] != null) {
      newObj[key] = obj[key];
    }
  });
  return newObj;
}

/***/ }),

/***/ 79880:
/*!********************************************************!*\
  !*** ./src/app/core/shared/plugin-mocks/mock-utils.ts ***!
  \********************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   getMockMethodAnnotation: () => (/* binding */ getMockMethodAnnotation)
/* harmony export */ });
/* harmony import */ var _Users_smartcommunitylab_Desktop_newWork_playAndGo_playGo_node_modules_babel_runtime_helpers_esm_asyncToGenerator_js__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./node_modules/@babel/runtime/helpers/esm/asyncToGenerator.js */ 89204);

/* eslint-disable prefer-arrow/prefer-arrow-functions */
function getMockMethodAnnotation({
  doLog,
  logPrefix
}) {
  return function mockMethod(opts = {}) {
    opts = {
      async: false,
      wait: 200,
      ...opts
    };
    return function (target, propertyKey, descriptor) {
      const targetMethod = descriptor.value;
      descriptor.value = function (...args) {
        if (doLog) {
          console.log(`${logPrefix}.${propertyKey} called:`, ...args);
        }
        const res = targetMethod.apply(this, args);
        if (opts.async) {
          return (0,_Users_smartcommunitylab_Desktop_newWork_playAndGo_playGo_node_modules_babel_runtime_helpers_esm_asyncToGenerator_js__WEBPACK_IMPORTED_MODULE_0__["default"])(function* () {
            const promiseRes = yield res;
            yield time(opts.wait);
            if (doLog) {
              console.log(`${logPrefix}.${propertyKey} finished:`, promiseRes);
            }
            return promiseRes;
          })();
        } else {
          if (doLog) {
            console.log(`${logPrefix}.${propertyKey} result`, res);
          }
        }
      };
      return descriptor;
    };
  };
}
function time(_x) {
  return _time.apply(this, arguments);
}
function _time() {
  _time = (0,_Users_smartcommunitylab_Desktop_newWork_playAndGo_playGo_node_modules_babel_runtime_helpers_esm_asyncToGenerator_js__WEBPACK_IMPORTED_MODULE_0__["default"])(function* (ms) {
    return new Promise((resolve, reject) => {
      setTimeout(resolve, ms);
    });
  });
  return _time.apply(this, arguments);
}

/***/ }),

/***/ 82310:
/*!**************************************************!*\
  !*** ./src/app/core/shared/pipes/filter.pipe.ts ***!
  \**************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   FilterPipe: () => (/* binding */ FilterPipe)
/* harmony export */ });
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! @angular/core */ 12481);
var _staticBlock;

class FilterPipe {
  transform(items, field, value) {
    if (!items || !value || !field) {
      return items;
    }
    const lowSearch = value.toLowerCase();
    return items.filter(item => field.some(key => String(item[key]).toLowerCase().includes(lowSearch)));
  }
  static #_ = _staticBlock = () => (this.ɵfac = function FilterPipe_Factory(__ngFactoryType__) {
    return new (__ngFactoryType__ || FilterPipe)();
  }, this.ɵpipe = /*@__PURE__*/_angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵdefinePipe"]({
    name: "filterData",
    type: FilterPipe,
    pure: true,
    standalone: false
  }));
}
_staticBlock();

/***/ }),

/***/ 83239:
/*!********************************************************!*\
  !*** ./src/app/core/shared/campaigns/campaignUtils.ts ***!
  \********************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   getCampaignImage: () => (/* binding */ getCampaignImage)
/* harmony export */ });
function getCampaignImage(campaignContainer) {
  const logo = campaignContainer?.campaign?.logo;
  const base64Image = logo?.image ? 'data:image/jpg;base64,' + logo.image : null;
  return logo?.url ?? base64Image ?? transparentPixel;
}
const transparentPixel = 'data:image/gif;base64,R0lGODlhAQABAIAAAAAAAP///yH5BAEAAAAALAAAAAABAAEAAAIBRAA7';

/***/ }),

/***/ 83613:
/*!************************************************************************************************************!*\
  !*** ./src/app/pages/home/campaign-details/companies/company-detail-page/company-map/company-map.modal.ts ***!
  \************************************************************************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   CompanyMapModalPage: () => (/* binding */ CompanyMapModalPage)
/* harmony export */ });
/* harmony import */ var leaflet__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! leaflet */ 67381);
/* harmony import */ var leaflet__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(leaflet__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @angular/core */ 12481);
/* harmony import */ var _ionic_angular__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @ionic/angular */ 21507);
/* harmony import */ var _asymmetrik_ngx_leaflet__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @asymmetrik/ngx-leaflet */ 88355);
var _staticBlock;




class CompanyMapModalPage {
  constructor(modalController) {
    this.modalController = modalController;
    this.mapOptions = {
      layers: [(0,leaflet__WEBPACK_IMPORTED_MODULE_0__.tileLayer)('https://{s}.tile.openstreetmap.org/{z}/{x}/{y}.png', {
        maxZoom: 19,
        // for lower zooms there are no tiles!
        minZoom: 2,
        attribution: '&copy; <a href="http://www.openstreetmap.org/copyright">OpenStreetMap</a>'
      })],
      zoom: 15,
      center: (0,leaflet__WEBPACK_IMPORTED_MODULE_0__.latLng)([0.0, 0.0])
    };
    this.sedi = new leaflet__WEBPACK_IMPORTED_MODULE_0__.FeatureGroup();
  }
  ngOnInit() {}
  onMapReady(map) {
    this.initMap();
    map.invalidateSize();
    setTimeout(() => {
      map.fitBounds(this.sedi.getBounds());
      map.invalidateSize();
      this.sedi.eachLayer(layer => {
        if (layer._latlng.lat === this.selectedLocation.latitude && layer._latlng.lng === this.selectedLocation.longitude) {
          layer.openPopup();
        }
      });
    }, 500);
  }
  initMap() {
    for (const location of this.allLocations) {
      const newMarker = (0,leaflet__WEBPACK_IMPORTED_MODULE_0__.marker)([location.latitude, location.longitude], {
        icon: (0,leaflet__WEBPACK_IMPORTED_MODULE_0__.icon)({
          ...leaflet__WEBPACK_IMPORTED_MODULE_0__.Icon.Default.prototype.options,
          iconUrl: 'assets/marker-icon.png',
          iconRetinaUrl: 'assets/marker-icon-2x.png',
          shadowUrl: 'assets/marker-shadow.png'
        })
      }).bindPopup(`
      <div><span style="font-weight:bold">${location.id}</span></div>
      <div><span style="font-style:italic">${location.address} ${location.streetNumber}</span></div>
      `);
      newMarker.addTo(this.sedi);
    }
  }
  close() {
    this.modalController.dismiss(false);
  }
  static #_ = _staticBlock = () => (this.ɵfac = function CompanyMapModalPage_Factory(__ngFactoryType__) {
    return new (__ngFactoryType__ || CompanyMapModalPage)(_angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵdirectiveInject"](_ionic_angular__WEBPACK_IMPORTED_MODULE_2__.ModalController));
  }, this.ɵcmp = /*@__PURE__*/_angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵdefineComponent"]({
    type: CompanyMapModalPage,
    selectors: [["app-company-map-modal"]],
    standalone: false,
    decls: 3,
    vars: 2,
    consts: [["leaflet", "", 1, "ngx-leaflet", 3, "leafletMapReady", "leafletOptions"], [3, "leafletLayer"]],
    template: function CompanyMapModalPage_Template(rf, ctx) {
      if (rf & 1) {
        _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵelementContainerStart"](0);
        _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵelementStart"](1, "div", 0);
        _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵlistener"]("leafletMapReady", function CompanyMapModalPage_Template_div_leafletMapReady_1_listener($event) {
          return ctx.onMapReady($event);
        });
        _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵelement"](2, "div", 1);
        _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵelementContainerEnd"]();
      }
      if (rf & 2) {
        _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵadvance"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵproperty"]("leafletOptions", ctx.mapOptions);
        _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵadvance"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵproperty"]("leafletLayer", ctx.sedi);
      }
    },
    dependencies: [_asymmetrik_ngx_leaflet__WEBPACK_IMPORTED_MODULE_3__.LeafletDirective, _asymmetrik_ngx_leaflet__WEBPACK_IMPORTED_MODULE_3__.LeafletLayerDirective],
    styles: [".ngx-leaflet[_ngcontent-%COMP%] {\n  height: 100%;\n}\n/*# sourceMappingURL=data:application/json;charset=utf-8;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbIndlYnBhY2s6Ly8uL3NyYy9hcHAvcGFnZXMvaG9tZS9jYW1wYWlnbi1kZXRhaWxzL2NvbXBhbmllcy9jb21wYW55LWRldGFpbC1wYWdlL2NvbXBhbnktbWFwL2NvbXBhbnktbWFwLm1vZGFsLnNjc3MiXSwibmFtZXMiOltdLCJtYXBwaW5ncyI6IkFBQUE7RUFDRSxZQUFBO0FBQ0YiLCJzb3VyY2VzQ29udGVudCI6WyIubmd4LWxlYWZsZXQge1xuICBoZWlnaHQ6IDEwMCU7XG59XG4iXSwic291cmNlUm9vdCI6IiJ9 */"]
  }));
}
_staticBlock();

/***/ }),

/***/ 84429:
/*!*********************!*\
  !*** ./src/main.ts ***!
  \*********************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony import */ var _angular_platform_browser__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! @angular/platform-browser */ 62190);
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @angular/core */ 37580);
/* harmony import */ var _app_app_module__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! ./app/app.module */ 50635);
/* harmony import */ var _environments_environment__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! ./environments/environment */ 45312);




if (_environments_environment__WEBPACK_IMPORTED_MODULE_3__.environment.production) {
  (0,_angular_core__WEBPACK_IMPORTED_MODULE_1__.enableProdMode)();
}
_angular_platform_browser__WEBPACK_IMPORTED_MODULE_0__.platformBrowser().bootstrapModule(_app_app_module__WEBPACK_IMPORTED_MODULE_2__.AppModule).catch(err => console.log(err));

/***/ }),

/***/ 84661:
/*!*************************************************************************!*\
  !*** ./src/app/core/shared/layout/content/content-content.component.ts ***!
  \*************************************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   ContentContentComponent: () => (/* binding */ ContentContentComponent)
/* harmony export */ });
/* harmony import */ var rxjs__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! rxjs */ 70271);
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @angular/core */ 34205);
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @angular/core */ 12481);
/* harmony import */ var _services_refresher_service__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! ../../services/refresher.service */ 8780);
/* harmony import */ var _services_page_settings_service__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! ../../services/page-settings.service */ 40147);
/* harmony import */ var _ionic_angular__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! @ionic/angular */ 21507);
/* harmony import */ var _angular_common__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! @angular/common */ 93683);
var _staticBlock;






const _c0 = ["template"];
function ContentContentComponent_ng_template_0_Template(rf, ctx) {
  if (rf & 1) {
    const _r1 = _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵgetCurrentView"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵelementStart"](0, "ion-refresher", 1);
    _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵpipe"](1, "async");
    _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵlistener"]("ionRefresh", function ContentContentComponent_ng_template_0_Template_ion_refresher_ionRefresh_0_listener($event) {
      _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵrestoreView"](_r1);
      const ctx_r1 = _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵnextContext"]();
      return _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵresetView"](ctx_r1.refresh($event));
    });
    _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵelement"](2, "ion-refresher-content");
    _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵelementEnd"]();
  }
  if (rf & 2) {
    const ctx_r1 = _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵnextContext"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵproperty"]("disabled", _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵpipeBind1"](1, 1, ctx_r1.refresherDisabled$));
  }
}
class ContentContentComponent {
  constructor(refresherService, pageSettingsService) {
    this.refresherService = refresherService;
    this.pageSettingsService = pageSettingsService;
    this.refresherDisabled$ = this.pageSettingsService.pageSettings$.pipe((0,rxjs__WEBPACK_IMPORTED_MODULE_0__.map)(settings => !settings.refresher));
  }
  refresh(event) {
    this.refresherService.onRefresh(event);
  }
  ngOnInit() {}
  static #_ = _staticBlock = () => (this.ɵfac = function ContentContentComponent_Factory(__ngFactoryType__) {
    return new (__ngFactoryType__ || ContentContentComponent)(_angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵdirectiveInject"](_services_refresher_service__WEBPACK_IMPORTED_MODULE_3__.RefresherService), _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵdirectiveInject"](_services_page_settings_service__WEBPACK_IMPORTED_MODULE_4__.PageSettingsService));
  }, this.ɵcmp = /*@__PURE__*/_angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵdefineComponent"]({
    type: ContentContentComponent,
    selectors: [["app-content-content"]],
    viewQuery: function ContentContentComponent_Query(rf, ctx) {
      if (rf & 1) {
        _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵviewQuery"](_c0, 7);
      }
      if (rf & 2) {
        let _t;
        _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵqueryRefresh"](_t = _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵloadQuery"]()) && (ctx.template = _t.first);
      }
    },
    standalone: false,
    decls: 2,
    vars: 0,
    consts: [["template", ""], ["slot", "fixed", 3, "ionRefresh", "disabled"]],
    template: function ContentContentComponent_Template(rf, ctx) {
      if (rf & 1) {
        _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵtemplate"](0, ContentContentComponent_ng_template_0_Template, 3, 3, "ng-template", null, 0, _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵtemplateRefExtractor"]);
      }
    },
    dependencies: [_ionic_angular__WEBPACK_IMPORTED_MODULE_5__.IonRefresher, _ionic_angular__WEBPACK_IMPORTED_MODULE_5__.IonRefresherContent, _angular_common__WEBPACK_IMPORTED_MODULE_6__.AsyncPipe],
    styles: ["/*# sourceMappingURL=data:application/json;charset=utf-8;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbXSwibmFtZXMiOltdLCJtYXBwaW5ncyI6IiIsInNvdXJjZVJvb3QiOiIifQ== */"]
  }));
}
_staticBlock();

/***/ }),

/***/ 85039:
/*!***************************************************************!*\
  !*** ./src/app/core/shared/layout/header/header.directive.ts ***!
  \***************************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   HeaderDirective: () => (/* binding */ HeaderDirective)
/* harmony export */ });
/* harmony import */ var _header_content_component__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./header-content.component */ 38325);
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @angular/core */ 12481);
var _staticBlock;


/**
 * Ionic does not support extending behavior of ion-header component globally.
 * To avoid adding the same code to every page, we use a directive to add it automatically.
 *
 * We have special HeaderContentComponent which contains all content that we want to add
 * to the header (title, backButton....). This directive will add this component as
 * child of ion-header of every page.
 *
 * We tried also to have header component outside of router-outlet, but it was not
 * very good solution because it didn't play nice with ionic - which assumes some
 * page structure.
 *
 * One drawback of adding whole component is that there is not another component
 * between ion-header and ion-toolbar. This caused some problems in parallax
 * directive, so we had to change it a little.
 *
 * Note: Another approach would be to add just content of some template without
 * adding any component. We use this approach in ContentDirective, and it would
 * be possible to use it here too. And probably it would be better, but it is already working.
 *
 * Note 2: If there will be some delay in rendering of the header, then it is probably
 * caused by PageSettingsService, which sets data to the HeaderContentComponent.
 */
class HeaderDirective {
  constructor(
  // target element on which we have directive. (ion-header)
  element, viewContainerRef) {
    this.element = element;
    this.viewContainerRef = viewContainerRef;
  }
  ngOnInit() {
    // dynamically create element
    this.headerContentComponent = this.viewContainerRef.createComponent(_header_content_component__WEBPACK_IMPORTED_MODULE_0__.HeaderContentComponent);
    // add it as child of ion-header
    const host = this.element.nativeElement;
    host.insertBefore(this.headerContentComponent.location.nativeElement, host.firstChild);
  }
  static #_ = _staticBlock = () => (this.ɵfac = function HeaderDirective_Factory(__ngFactoryType__) {
    return new (__ngFactoryType__ || HeaderDirective)(_angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵdirectiveInject"](_angular_core__WEBPACK_IMPORTED_MODULE_1__.ElementRef), _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵdirectiveInject"](_angular_core__WEBPACK_IMPORTED_MODULE_1__.ViewContainerRef));
  }, this.ɵdir = /*@__PURE__*/_angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵdefineDirective"]({
    type: HeaderDirective,
    selectors: [["", "appHeader", ""]],
    standalone: false
  }));
}
_staticBlock();

/***/ }),

/***/ 86040:
/*!*******************************************!*\
  !*** ./src/app/core/shared/rxjs.utils.ts ***!
  \*******************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   asyncFilter: () => (/* binding */ asyncFilter),
/* harmony export */   beforeStartUse: () => (/* binding */ beforeStartUse),
/* harmony export */   castTo: () => (/* binding */ castTo),
/* harmony export */   framesToString: () => (/* binding */ framesToString),
/* harmony export */   ifOfflineUseStored: () => (/* binding */ ifOfflineUseStored),
/* harmony export */   mapTo: () => (/* binding */ mapTo),
/* harmony export */   runInContext: () => (/* binding */ runInContext),
/* harmony export */   runInZone: () => (/* binding */ runInZone),
/* harmony export */   runOutsideAngular: () => (/* binding */ runOutsideAngular),
/* harmony export */   startFrom: () => (/* binding */ startFrom),
/* harmony export */   tapLog: () => (/* binding */ tapLog),
/* harmony export */   throwIfNil: () => (/* binding */ throwIfNil),
/* harmony export */   withReplayedLatestFrom: () => (/* binding */ withReplayedLatestFrom)
/* harmony export */ });
/* harmony import */ var lodash_es__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! lodash-es */ 1261);
/* harmony import */ var lodash_es__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! lodash-es */ 80524);
/* harmony import */ var lodash_es__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! lodash-es */ 65206);
/* harmony import */ var lodash_es__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! lodash-es */ 11092);
/* harmony import */ var rxjs__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! rxjs */ 43942);
/* harmony import */ var rxjs__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! rxjs */ 44665);
/* harmony import */ var rxjs__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! rxjs */ 95429);
/* harmony import */ var rxjs__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(/*! rxjs */ 63617);
/* harmony import */ var rxjs__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(/*! rxjs */ 77919);
/* harmony import */ var rxjs__WEBPACK_IMPORTED_MODULE_9__ = __webpack_require__(/*! rxjs */ 61318);
/* harmony import */ var rxjs__WEBPACK_IMPORTED_MODULE_10__ = __webpack_require__(/*! rxjs */ 51903);
/* harmony import */ var rxjs__WEBPACK_IMPORTED_MODULE_11__ = __webpack_require__(/*! rxjs */ 51567);
/* harmony import */ var rxjs__WEBPACK_IMPORTED_MODULE_12__ = __webpack_require__(/*! rxjs */ 2435);
/* harmony import */ var rxjs__WEBPACK_IMPORTED_MODULE_13__ = __webpack_require__(/*! rxjs */ 70271);
/* harmony import */ var rxjs__WEBPACK_IMPORTED_MODULE_14__ = __webpack_require__(/*! rxjs */ 13255);
/* harmony import */ var rxjs__WEBPACK_IMPORTED_MODULE_15__ = __webpack_require__(/*! rxjs */ 86301);
/* harmony import */ var rxjs__WEBPACK_IMPORTED_MODULE_16__ = __webpack_require__(/*! rxjs */ 33900);
/* harmony import */ var rxjs__WEBPACK_IMPORTED_MODULE_17__ = __webpack_require__(/*! rxjs */ 98764);
/* harmony import */ var _utils__WEBPACK_IMPORTED_MODULE_18__ = __webpack_require__(/*! ./utils */ 7497);



function tapLog(...logMsgs) {
  return (0,rxjs__WEBPACK_IMPORTED_MODULE_17__.tap)(data => console.log(...logMsgs, data));
}
function mapTo(value) {
  return (0,rxjs__WEBPACK_IMPORTED_MODULE_13__.map)(() => value);
}
function castTo() {
  return source => source;
}
function asyncFilter(predicate) {
  return (0,rxjs__WEBPACK_IMPORTED_MODULE_10__.concatMap)((value, index) => (0,rxjs__WEBPACK_IMPORTED_MODULE_6__.from)(predicate(value, index)).pipe((0,rxjs__WEBPACK_IMPORTED_MODULE_11__.filter)(Boolean), (0,rxjs__WEBPACK_IMPORTED_MODULE_13__.map)(() => value)));
}
/// MERGING OF OBSERVABLES ///
function startFrom(start) {
  return source => (0,rxjs__WEBPACK_IMPORTED_MODULE_5__.concat)(start, source);
}
/** like concat, but don't wait to complete */
function beforeStartUse(start) {
  return source => (0,rxjs__WEBPACK_IMPORTED_MODULE_7__.merge)((0,rxjs__WEBPACK_IMPORTED_MODULE_6__.from)(start).pipe((0,rxjs__WEBPACK_IMPORTED_MODULE_16__.takeUntil)(source)), source);
}
/** `s.withLatestFrom(t)` will skip all `a` values until first `b` is emitted
 * this operator will emit all skipped `a` values at the same time when first `b` is emitted
 * than it behaves like `withLatestFrom`.
 */
function withReplayedLatestFrom(target) {
  return source => {
    const sharedTarget = target.pipe((0,rxjs__WEBPACK_IMPORTED_MODULE_15__.shareReplay)(1));
    sharedTarget.pipe((0,rxjs__WEBPACK_IMPORTED_MODULE_16__.takeUntil)(source)).subscribe();
    return source.pipe((0,rxjs__WEBPACK_IMPORTED_MODULE_14__.mergeMap)(sourceVal => sharedTarget.pipe((0,rxjs__WEBPACK_IMPORTED_MODULE_12__.first)(), (0,rxjs__WEBPACK_IMPORTED_MODULE_13__.map)(targetVal => [sourceVal, targetVal]))));
  };
}
/// RUNNING IN ANGULAR ///
function runInZone(zone) {
  return runInContext(zone.run.bind(zone));
}
function runOutsideAngular(zone) {
  return runInContext(zone.runOutsideAngular.bind(zone));
}
function runInContext(contextFunction) {
  return source => new rxjs__WEBPACK_IMPORTED_MODULE_4__.Observable(observer => source.subscribe({
    next: value => contextFunction(() => observer.next(value)),
    error: e => contextFunction(() => observer.error(e)),
    complete: () => contextFunction(() => observer.complete())
  }));
}
/// ERROR HANDLING ///
function ifOfflineUseStored(storage, integrityCheck = () => true) {
  return source => source.pipe((0,rxjs__WEBPACK_IMPORTED_MODULE_9__.catchError)(error => {
    if ((0,_utils__WEBPACK_IMPORTED_MODULE_18__.isOfflineError)(error)) {
      return (0,rxjs__WEBPACK_IMPORTED_MODULE_6__.from)(storage.get()).pipe((0,rxjs__WEBPACK_IMPORTED_MODULE_11__.filter)((0,lodash_es__WEBPACK_IMPORTED_MODULE_2__["default"])(lodash_es__WEBPACK_IMPORTED_MODULE_0__["default"])), (0,rxjs__WEBPACK_IMPORTED_MODULE_11__.filter)(integrityCheck));
    }
    return (0,rxjs__WEBPACK_IMPORTED_MODULE_8__.throwError)(() => error);
  }));
}
function throwIfNil(errorFn) {
  return source => source.pipe((0,rxjs__WEBPACK_IMPORTED_MODULE_13__.map)((value, index) => {
    if (value === null || value === undefined) {
      throw errorFn(value, index);
    }
    return value;
  }));
}
/// TESTING ///
/**
 * Useful function do display marble like strings
 *
 * returns string like: --x---x----|
 *
 * useful in matcher:
```
    testScheduler = new TestScheduler((actual, expected) => {
      expect(framesToString(actual)).toBe(framesToString(expected));
      expect(actual).toEqual(expected);
    });
```
 */
function framesToString(frames) {
  const notificationMap = {
    ['N']: 'x',
    ['E']: '#',
    ['C']: '|'
  };
  return (0,lodash_es__WEBPACK_IMPORTED_MODULE_3__["default"])((0,lodash_es__WEBPACK_IMPORTED_MODULE_1__["default"])(frames).frame + 1).map(idx => {
    const framesAtIndex = frames.filter(frame => frame.frame === idx);
    if (framesAtIndex.length === 1) {
      return notificationMap[framesAtIndex[0].notification.kind];
    }
    if (framesAtIndex.length > 1) {
      return framesAtIndex.length;
    }
    return '-';
  }).join('');
}

/***/ }),

/***/ 86208:
/*!***********************************************************************************************!*\
  !*** ./src/app/core/shared/campaigns/main-campaign-stat/game-status/game-status.component.ts ***!
  \***********************************************************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   GameStatusComponent: () => (/* binding */ GameStatusComponent)
/* harmony export */ });
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! @angular/core */ 12481);
/* harmony import */ var _services_campaign_service__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ../../../services/campaign.service */ 76658);
/* harmony import */ var _angular_common__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @angular/common */ 93683);
/* harmony import */ var _ionic_angular__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @ionic/angular */ 21507);
/* harmony import */ var _ui_icon_icon_component__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! ../../../ui/icon/icon.component */ 59621);
/* harmony import */ var _ngx_translate_core__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! @ngx-translate/core */ 48503);
var _staticBlock;






const _c0 = (a0, a1) => ({
  levelIndex: a0,
  levelName: a1
});
function GameStatusComponent_div_0_span_7_Template(rf, ctx) {
  if (rf & 1) {
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](0, "span", 8);
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵtext"](1);
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelement"](2, "app-icon", 9);
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵtext"](3);
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵpipe"](4, "translate");
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();
  }
  if (rf & 2) {
    const ctx_r0 = _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵnextContext"](2);
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵadvance"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵtextInterpolate1"]("", ctx_r0.status == null ? null : ctx_r0.status.levels[0] == null ? null : ctx_r0.status.levels[0].toNextLevel, " ");
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵadvance"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵproperty"]("name", ctx_r0.getIcon());
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵadvance"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵtextInterpolate1"](" ", _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵpipeBind1"](4, 3, "campaigns.homewidgets.stat.score"));
  }
}
function GameStatusComponent_div_0_div_8_Template(rf, ctx) {
  if (rf & 1) {
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](0, "div", 10);
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelement"](1, "ion-progress-bar", 11);
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();
  }
  if (rf & 2) {
    const ctx_r0 = _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵnextContext"](2);
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵadvance"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵproperty"]("color", ctx_r0.type)("value", ctx_r0.getValueScore());
  }
}
function GameStatusComponent_div_0_ng_template_9_Template(rf, ctx) {
  if (rf & 1) {
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](0, "div", 12);
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵtext"](1);
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵpipe"](2, "translate");
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();
  }
  if (rf & 2) {
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵadvance"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵtextInterpolate1"](" ", _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵpipeBind1"](2, 1, "campaigns.homewidgets.stat.maxscore"), " ");
  }
}
function GameStatusComponent_div_0_Template(rf, ctx) {
  if (rf & 1) {
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](0, "div", 2)(1, "ion-grid")(2, "ion-row")(3, "ion-col", 3);
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelement"](4, "span", 4);
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵpipe"](5, "translate");
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](6, "ion-col", 5);
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵtemplate"](7, GameStatusComponent_div_0_span_7_Template, 5, 5, "span", 6);
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]()()();
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵtemplate"](8, GameStatusComponent_div_0_div_8_Template, 2, 2, "div", 7)(9, GameStatusComponent_div_0_ng_template_9_Template, 3, 3, "ng-template", null, 0, _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵtemplateRefExtractor"]);
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();
  }
  if (rf & 2) {
    const topScore_r2 = _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵreference"](10);
    const ctx_r0 = _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵnextContext"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵadvance"](4);
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵproperty"]("innerHtml", _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵpipeBind2"](5, 4, "campaigns.homewidgets.stat.levelName", _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵpureFunction2"](7, _c0, ctx_r0.status == null ? null : ctx_r0.status.levels[0] == null ? null : ctx_r0.status.levels[0].levelIndex, ctx_r0.status == null ? null : ctx_r0.status.levels[0] == null ? null : ctx_r0.status.levels[0].levelValue)), _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵsanitizeHtml"]);
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵadvance"](3);
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵproperty"]("ngIf", (ctx_r0.status == null ? null : ctx_r0.status.levels[0] == null ? null : ctx_r0.status.levels[0].toNextLevel) > 0);
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵadvance"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵproperty"]("ngIf", (ctx_r0.status == null ? null : ctx_r0.status.levels[0] == null ? null : ctx_r0.status.levels[0].toNextLevel) > 0)("ngIfElse", topScore_r2);
  }
}
class GameStatusComponent {
  constructor(campaignService) {
    this.campaignService = campaignService;
    this.status = undefined;
  }
  ngOnInit() {
    // console.log(this.status);
    // console.log(
    //   (this.status?.score - this.status?.levels[0]?.startLevelScore) /
    //     (this.status?.levels[0]?.endLevelScore -
    //       this.status?.levels[0]?.startLevelScore)
    // );
  }
  getValueScore() {
    const score = (this.status?.score - this.status?.levels[0]?.startLevelScore) / (this.status?.levels[0]?.endLevelScore - this.status?.levels[0]?.startLevelScore);
    if (score > 0) {
      return score;
    } else {
      return 100;
    }
  }
  getIcon() {
    return this.campaignService.getCampaignTypeIcon(this.campaign);
  }
  static #_ = _staticBlock = () => (this.ɵfac = function GameStatusComponent_Factory(__ngFactoryType__) {
    return new (__ngFactoryType__ || GameStatusComponent)(_angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵdirectiveInject"](_services_campaign_service__WEBPACK_IMPORTED_MODULE_1__.CampaignService));
  }, this.ɵcmp = /*@__PURE__*/_angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵdefineComponent"]({
    type: GameStatusComponent,
    selectors: [["app-game-status"]],
    inputs: {
      status: "status",
      type: "type",
      campaign: "campaign"
    },
    standalone: false,
    decls: 1,
    vars: 1,
    consts: [["topScore", ""], ["class", "ion-text-left", 4, "ngIf"], [1, "ion-text-left"], ["size", "8"], [1, "level-name", 3, "innerHtml"], ["size", "4"], ["class", "score", 4, "ngIf"], ["class", "progress-bar", 4, "ngIf", "ngIfElse"], [1, "score"], [3, "name"], [1, "progress-bar"], [1, "level-bar", 3, "color", "value"], [1, "max"]],
    template: function GameStatusComponent_Template(rf, ctx) {
      if (rf & 1) {
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵtemplate"](0, GameStatusComponent_div_0_Template, 11, 10, "div", 1);
      }
      if (rf & 2) {
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵproperty"]("ngIf", ctx.status);
      }
    },
    dependencies: [_angular_common__WEBPACK_IMPORTED_MODULE_2__.NgIf, _ionic_angular__WEBPACK_IMPORTED_MODULE_3__.IonCol, _ionic_angular__WEBPACK_IMPORTED_MODULE_3__.IonGrid, _ionic_angular__WEBPACK_IMPORTED_MODULE_3__.IonProgressBar, _ionic_angular__WEBPACK_IMPORTED_MODULE_3__.IonRow, _ui_icon_icon_component__WEBPACK_IMPORTED_MODULE_4__.IconComponent, _ngx_translate_core__WEBPACK_IMPORTED_MODULE_5__.TranslatePipe],
    styles: [".level-bar[_ngcontent-%COMP%] {\n  height: 16px;\n  --background: none;\n}\n\n.score[_ngcontent-%COMP%] {\n  position: absolute;\n  display: flex;\n  right: 8px;\n  color: var(--dark-grey);\n}\n.score[_ngcontent-%COMP%]   app-icon[_ngcontent-%COMP%] {\n  margin-left: 4px;\n}\n\n.level-name[_ngcontent-%COMP%] {\n  color: var(--dark-grey);\n}\n\n.max[_ngcontent-%COMP%] {\n  text-align: center;\n  font-style: italic;\n}\n/*# sourceMappingURL=data:application/json;charset=utf-8;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbIndlYnBhY2s6Ly8uL3NyYy9hcHAvY29yZS9zaGFyZWQvY2FtcGFpZ25zL21haW4tY2FtcGFpZ24tc3RhdC9nYW1lLXN0YXR1cy9nYW1lLXN0YXR1cy5jb21wb25lbnQuc2NzcyJdLCJuYW1lcyI6W10sIm1hcHBpbmdzIjoiQUFBQTtFQUNFLFlBQUE7RUFDQSxrQkFBQTtBQUNGOztBQUNBO0VBQ0Usa0JBQUE7RUFDQSxhQUFBO0VBQ0EsVUFBQTtFQUNBLHVCQUFBO0FBRUY7QUFERTtFQUNFLGdCQUFBO0FBR0o7O0FBQUE7RUFDRSx1QkFBQTtBQUdGOztBQURBO0VBQ0Usa0JBQUE7RUFDQSxrQkFBQTtBQUlGIiwic291cmNlc0NvbnRlbnQiOlsiLmxldmVsLWJhciB7XG4gIGhlaWdodDogMTZweDtcbiAgLS1iYWNrZ3JvdW5kOiBub25lO1xufVxuLnNjb3JlIHtcbiAgcG9zaXRpb246IGFic29sdXRlO1xuICBkaXNwbGF5OiBmbGV4O1xuICByaWdodDogOHB4O1xuICBjb2xvcjogdmFyKC0tZGFyay1ncmV5KTtcbiAgYXBwLWljb24ge1xuICAgIG1hcmdpbi1sZWZ0OiA0cHg7XG4gIH1cbn1cbi5sZXZlbC1uYW1lIHtcbiAgY29sb3I6IHZhcigtLWRhcmstZ3JleSk7XG59XG4ubWF4IHtcbiAgdGV4dC1hbGlnbjogY2VudGVyO1xuICBmb250LXN0eWxlOiBpdGFsaWM7XG59XG4iXSwic291cmNlUm9vdCI6IiJ9 */"]
  }));
}
_staticBlock();

/***/ }),

/***/ 86313:
/*!*****************************************************!*\
  !*** ./src/app/core/shared/ui/icon/icon.service.ts ***!
  \*****************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   IconService: () => (/* binding */ IconService)
/* harmony export */ });
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! @angular/core */ 34205);
/* harmony import */ var _angular_platform_browser__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @angular/platform-browser */ 80436);
var _staticBlock;


class IconService {
  constructor(domSanitizer) {
    this.domSanitizer = domSanitizer;
    this.svgIcons = {};
  }
  registerSvgIcons(svgIcons) {
    this.svgIcons = svgIcons;
  }
  isIconSvg(iconName) {
    return this.svgIcons[iconName] !== undefined;
  }
  getSvgSrc(iconName) {
    return this.svgIcons[iconName];
  }
  static #_ = _staticBlock = () => (this.ɵfac = function IconService_Factory(__ngFactoryType__) {
    return new (__ngFactoryType__ || IconService)(_angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵinject"](_angular_platform_browser__WEBPACK_IMPORTED_MODULE_1__.DomSanitizer));
  }, this.ɵprov = /*@__PURE__*/_angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵdefineInjectable"]({
    token: IconService,
    factory: IconService.ɵfac,
    providedIn: 'root'
  }));
}
_staticBlock();

/***/ }),

/***/ 86451:
/*!*****************************************************!*\
  !*** ./src/app/core/shared/pipes/localDate.pipe.ts ***!
  \*****************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   LocalDatePipe: () => (/* binding */ LocalDatePipe)
/* harmony export */ });
/* harmony import */ var _angular_common__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! @angular/common */ 93683);
/* harmony import */ var rxjs__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! rxjs */ 70271);
/* harmony import */ var _abstractObservablePipe__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! ./abstractObservablePipe */ 13875);
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @angular/core */ 12481);
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! @angular/core */ 37580);
/* harmony import */ var _services_user_service__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! ../services/user.service */ 89815);
/* harmony import */ var _services_error_service__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! ../services/error.service */ 46078);
var _staticBlock;






class LocalDatePipe extends _abstractObservablePipe__WEBPACK_IMPORTED_MODULE_2__.AbstractObservablePipe {
  constructor(userService, ref, errorService) {
    super(ref);
    this.userService = userService;
    this.ref = ref;
    this.errorService = errorService;
  }
  transform(value, format) {
    return this.doTransform({
      value,
      format
    });
  }
  /**
   * @override
   */
  transformToObservable(input) {
    return this.userService.userLocale$.pipe((0,rxjs__WEBPACK_IMPORTED_MODULE_1__.map)(locale => {
      try {
        return this.format(input.value, input.format, locale);
      } catch (e) {
        this.errorService.handleError(e, 'silent');
        return '';
      }
    }));
  }
  format(value, format, locale) {
    if (!value) {
      return '';
    }
    if (!format) {
      format = 'shortDate';
    }
    if (typeof format !== 'string') {
      try {
        return Intl.DateTimeFormat(locale, format).format(value);
      } catch (e) {
        // fallback if there is some problem with Intl
        return (0,_angular_common__WEBPACK_IMPORTED_MODULE_0__.formatDate)(value, 'shortDate', locale);
      }
    }
    // basic string format
    return (0,_angular_common__WEBPACK_IMPORTED_MODULE_0__.formatDate)(value, format, locale);
  }
  ngOnDestroy() {
    super.destroy();
  }
  static #_ = _staticBlock = () => (this.ɵfac = function LocalDatePipe_Factory(__ngFactoryType__) {
    return new (__ngFactoryType__ || LocalDatePipe)(_angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵdirectiveInject"](_services_user_service__WEBPACK_IMPORTED_MODULE_5__.UserService, 16), _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵdirectiveInject"](_angular_core__WEBPACK_IMPORTED_MODULE_4__.ChangeDetectorRef, 16), _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵdirectiveInject"](_services_error_service__WEBPACK_IMPORTED_MODULE_6__.ErrorService, 16));
  }, this.ɵpipe = /*@__PURE__*/_angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵdefinePipe"]({
    name: "localDate",
    type: LocalDatePipe,
    pure: false,
    standalone: false
  }));
}
_staticBlock();

/***/ }),

/***/ 88996:
/*!******************************************************************************************************************************************!*\
  !*** ./node_modules/@ionic/core/dist/esm/ lazy ^\.\/.*\.entry\.js$ include: \.entry\.js$ exclude: \.system\.entry\.js$ namespace object ***!
  \******************************************************************************************************************************************/
/***/ ((module, __unused_webpack_exports, __webpack_require__) => {

var map = {
	"./ion-accordion_2.entry.js": [
		37518,
		"common",
		"node_modules_ionic_core_dist_esm_ion-accordion_2_entry_js"
	],
	"./ion-action-sheet.entry.js": [
		41981,
		"common",
		"node_modules_ionic_core_dist_esm_ion-action-sheet_entry_js"
	],
	"./ion-alert.entry.js": [
		71603,
		"common",
		"node_modules_ionic_core_dist_esm_ion-alert_entry_js"
	],
	"./ion-app_8.entry.js": [
		82273,
		"common",
		"node_modules_ionic_core_dist_esm_ion-app_8_entry_js"
	],
	"./ion-avatar_3.entry.js": [
		19642,
		"node_modules_ionic_core_dist_esm_ion-avatar_3_entry_js"
	],
	"./ion-back-button.entry.js": [
		32095,
		"common",
		"node_modules_ionic_core_dist_esm_ion-back-button_entry_js"
	],
	"./ion-backdrop.entry.js": [
		72335,
		"node_modules_ionic_core_dist_esm_ion-backdrop_entry_js"
	],
	"./ion-breadcrumb_2.entry.js": [
		78221,
		"common",
		"node_modules_ionic_core_dist_esm_ion-breadcrumb_2_entry_js"
	],
	"./ion-button_2.entry.js": [
		47184,
		"node_modules_ionic_core_dist_esm_ion-button_2_entry_js"
	],
	"./ion-card_5.entry.js": [
		38759,
		"node_modules_ionic_core_dist_esm_ion-card_5_entry_js"
	],
	"./ion-checkbox.entry.js": [
		24248,
		"node_modules_ionic_core_dist_esm_ion-checkbox_entry_js"
	],
	"./ion-chip.entry.js": [
		69863,
		"node_modules_ionic_core_dist_esm_ion-chip_entry_js"
	],
	"./ion-col_3.entry.js": [
		51769,
		"node_modules_ionic_core_dist_esm_ion-col_3_entry_js"
	],
	"./ion-datetime-button.entry.js": [
		2569,
		"default-node_modules_ionic_core_dist_esm_data-DCORV9FH_js",
		"node_modules_ionic_core_dist_esm_ion-datetime-button_entry_js"
	],
	"./ion-datetime_3.entry.js": [
		76534,
		"default-node_modules_ionic_core_dist_esm_data-DCORV9FH_js",
		"common",
		"node_modules_ionic_core_dist_esm_ion-datetime_3_entry_js"
	],
	"./ion-fab_3.entry.js": [
		25458,
		"common",
		"node_modules_ionic_core_dist_esm_ion-fab_3_entry_js"
	],
	"./ion-img.entry.js": [
		70654,
		"node_modules_ionic_core_dist_esm_ion-img_entry_js"
	],
	"./ion-infinite-scroll_2.entry.js": [
		36034,
		"common",
		"node_modules_ionic_core_dist_esm_ion-infinite-scroll_2_entry_js"
	],
	"./ion-input-otp.entry.js": [
		20381,
		"common",
		"node_modules_ionic_core_dist_esm_ion-input-otp_entry_js"
	],
	"./ion-input-password-toggle.entry.js": [
		5196,
		"common",
		"node_modules_ionic_core_dist_esm_ion-input-password-toggle_entry_js"
	],
	"./ion-input.entry.js": [
		20761,
		"default-node_modules_ionic_core_dist_esm_input_utils-DrvTa8gz_js-node_modules_ionic_core_dist-ed3a0b",
		"common",
		"node_modules_ionic_core_dist_esm_ion-input_entry_js"
	],
	"./ion-item-option_3.entry.js": [
		6492,
		"common",
		"node_modules_ionic_core_dist_esm_ion-item-option_3_entry_js"
	],
	"./ion-item_8.entry.js": [
		29557,
		"common",
		"node_modules_ionic_core_dist_esm_ion-item_8_entry_js"
	],
	"./ion-loading.entry.js": [
		68353,
		"common",
		"node_modules_ionic_core_dist_esm_ion-loading_entry_js"
	],
	"./ion-menu_3.entry.js": [
		51024,
		"common",
		"node_modules_ionic_core_dist_esm_ion-menu_3_entry_js"
	],
	"./ion-modal.entry.js": [
		29160,
		"common",
		"node_modules_ionic_core_dist_esm_ion-modal_entry_js"
	],
	"./ion-nav_2.entry.js": [
		60393,
		"node_modules_ionic_core_dist_esm_ion-nav_2_entry_js"
	],
	"./ion-picker-column-option.entry.js": [
		68442,
		"node_modules_ionic_core_dist_esm_ion-picker-column-option_entry_js"
	],
	"./ion-picker-column.entry.js": [
		43110,
		"common",
		"node_modules_ionic_core_dist_esm_ion-picker-column_entry_js"
	],
	"./ion-picker.entry.js": [
		15575,
		"node_modules_ionic_core_dist_esm_ion-picker_entry_js"
	],
	"./ion-popover.entry.js": [
		16772,
		"common",
		"node_modules_ionic_core_dist_esm_ion-popover_entry_js"
	],
	"./ion-progress-bar.entry.js": [
		34810,
		"node_modules_ionic_core_dist_esm_ion-progress-bar_entry_js"
	],
	"./ion-radio_2.entry.js": [
		14639,
		"common",
		"node_modules_ionic_core_dist_esm_ion-radio_2_entry_js"
	],
	"./ion-range.entry.js": [
		90628,
		"common",
		"node_modules_ionic_core_dist_esm_ion-range_entry_js"
	],
	"./ion-refresher_2.entry.js": [
		10852,
		"common",
		"node_modules_ionic_core_dist_esm_ion-refresher_2_entry_js"
	],
	"./ion-reorder_2.entry.js": [
		61479,
		"common",
		"node_modules_ionic_core_dist_esm_ion-reorder_2_entry_js"
	],
	"./ion-ripple-effect.entry.js": [
		24065,
		"node_modules_ionic_core_dist_esm_ion-ripple-effect_entry_js"
	],
	"./ion-route_4.entry.js": [
		57971,
		"node_modules_ionic_core_dist_esm_ion-route_4_entry_js"
	],
	"./ion-searchbar.entry.js": [
		93184,
		"common",
		"node_modules_ionic_core_dist_esm_ion-searchbar_entry_js"
	],
	"./ion-segment-content.entry.js": [
		94312,
		"node_modules_ionic_core_dist_esm_ion-segment-content_entry_js"
	],
	"./ion-segment-view.entry.js": [
		54540,
		"common",
		"node_modules_ionic_core_dist_esm_ion-segment-view_entry_js"
	],
	"./ion-segment_2.entry.js": [
		469,
		"common",
		"node_modules_ionic_core_dist_esm_ion-segment_2_entry_js"
	],
	"./ion-select-modal.entry.js": [
		57101,
		"node_modules_ionic_core_dist_esm_ion-select-modal_entry_js"
	],
	"./ion-select_3.entry.js": [
		78471,
		"common",
		"node_modules_ionic_core_dist_esm_ion-select_3_entry_js"
	],
	"./ion-spinner.entry.js": [
		40388,
		"common",
		"node_modules_ionic_core_dist_esm_ion-spinner_entry_js"
	],
	"./ion-split-pane.entry.js": [
		42392,
		"node_modules_ionic_core_dist_esm_ion-split-pane_entry_js"
	],
	"./ion-tab-bar_2.entry.js": [
		36059,
		"common",
		"node_modules_ionic_core_dist_esm_ion-tab-bar_2_entry_js"
	],
	"./ion-tab_2.entry.js": [
		5427,
		"node_modules_ionic_core_dist_esm_ion-tab_2_entry_js"
	],
	"./ion-text.entry.js": [
		50198,
		"node_modules_ionic_core_dist_esm_ion-text_entry_js"
	],
	"./ion-textarea.entry.js": [
		1735,
		"default-node_modules_ionic_core_dist_esm_input_utils-DrvTa8gz_js-node_modules_ionic_core_dist-ed3a0b",
		"node_modules_ionic_core_dist_esm_ion-textarea_entry_js"
	],
	"./ion-toast.entry.js": [
		7510,
		"common",
		"node_modules_ionic_core_dist_esm_ion-toast_entry_js"
	],
	"./ion-toggle.entry.js": [
		45297,
		"common",
		"node_modules_ionic_core_dist_esm_ion-toggle_entry_js"
	]
};
function webpackAsyncContext(req) {
	if(!__webpack_require__.o(map, req)) {
		return Promise.resolve().then(() => {
			var e = new Error("Cannot find module '" + req + "'");
			e.code = 'MODULE_NOT_FOUND';
			throw e;
		});
	}

	var ids = map[req], id = ids[0];
	return Promise.all(ids.slice(1).map(__webpack_require__.e)).then(() => {
		return __webpack_require__(id);
	});
}
webpackAsyncContext.keys = () => (Object.keys(map));
webpackAsyncContext.id = 88996;
module.exports = webpackAsyncContext;

/***/ }),

/***/ 89815:
/*!******************************************************!*\
  !*** ./src/app/core/shared/services/user.service.ts ***!
  \******************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   UserService: () => (/* binding */ UserService)
/* harmony export */ });
/* harmony import */ var _Users_smartcommunitylab_Desktop_newWork_playAndGo_playGo_node_modules_babel_runtime_helpers_esm_asyncToGenerator_js__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./node_modules/@babel/runtime/helpers/esm/asyncToGenerator.js */ 89204);
/* harmony import */ var rxjs__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! rxjs */ 10819);
/* harmony import */ var rxjs__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! rxjs */ 75797);
/* harmony import */ var rxjs__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! rxjs */ 19999);
/* harmony import */ var rxjs__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! rxjs */ 63617);
/* harmony import */ var rxjs__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! rxjs */ 59452);
/* harmony import */ var src_environments_environment__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! src/environments/environment */ 45312);
/* harmony import */ var _angular_common_http__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(/*! @angular/common/http */ 63855);
/* harmony import */ var rxjs_operators__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(/*! rxjs/operators */ 61318);
/* harmony import */ var rxjs_operators__WEBPACK_IMPORTED_MODULE_9__ = __webpack_require__(/*! rxjs/operators */ 91817);
/* harmony import */ var rxjs_operators__WEBPACK_IMPORTED_MODULE_10__ = __webpack_require__(/*! rxjs/operators */ 51567);
/* harmony import */ var rxjs_operators__WEBPACK_IMPORTED_MODULE_11__ = __webpack_require__(/*! rxjs/operators */ 70271);
/* harmony import */ var rxjs_operators__WEBPACK_IMPORTED_MODULE_12__ = __webpack_require__(/*! rxjs/operators */ 86301);
/* harmony import */ var rxjs_operators__WEBPACK_IMPORTED_MODULE_13__ = __webpack_require__(/*! rxjs/operators */ 36647);
/* harmony import */ var _utils__WEBPACK_IMPORTED_MODULE_14__ = __webpack_require__(/*! ../utils */ 7497);
/* harmony import */ var _rxjs_utils__WEBPACK_IMPORTED_MODULE_15__ = __webpack_require__(/*! ../rxjs.utils */ 86040);
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_16__ = __webpack_require__(/*! @angular/core */ 34205);
/* harmony import */ var _ngx_translate_core__WEBPACK_IMPORTED_MODULE_17__ = __webpack_require__(/*! @ngx-translate/core */ 48503);
/* harmony import */ var _territory_service__WEBPACK_IMPORTED_MODULE_18__ = __webpack_require__(/*! ./territory.service */ 11630);
/* harmony import */ var _local_storage_service__WEBPACK_IMPORTED_MODULE_19__ = __webpack_require__(/*! ./local-storage.service */ 9891);
/* harmony import */ var _ionic_angular__WEBPACK_IMPORTED_MODULE_20__ = __webpack_require__(/*! @ionic/angular */ 4059);
/* harmony import */ var _auth_auth_service__WEBPACK_IMPORTED_MODULE_21__ = __webpack_require__(/*! ../../auth/auth.service */ 35524);
/* harmony import */ var _api_generated_controllers_playerController_service__WEBPACK_IMPORTED_MODULE_22__ = __webpack_require__(/*! ../../api/generated/controllers/playerController.service */ 63971);
/* harmony import */ var _refresher_service__WEBPACK_IMPORTED_MODULE_23__ = __webpack_require__(/*! ./refresher.service */ 8780);
/* harmony import */ var _alert_service__WEBPACK_IMPORTED_MODULE_24__ = __webpack_require__(/*! ./alert.service */ 67406);
/* harmony import */ var _error_service__WEBPACK_IMPORTED_MODULE_25__ = __webpack_require__(/*! ./error.service */ 46078);

var _staticBlock;

















class UserService {
  constructor(translateService, territoryService, localStorageService, navCtrl, authService, http, playerControllerService, refresherService, alertService, errorService) {
    var _this = this;
    this.translateService = translateService;
    this.territoryService = territoryService;
    this.localStorageService = localStorageService;
    this.navCtrl = navCtrl;
    this.authService = authService;
    this.http = http;
    this.playerControllerService = playerControllerService;
    this.refresherService = refresherService;
    this.alertService = alertService;
    this.errorService = errorService;
    this.userLanguageSubject = new rxjs__WEBPACK_IMPORTED_MODULE_2__.BehaviorSubject('it');
    this.userLanguage$ = this.userLanguageSubject.pipe((0,rxjs_operators__WEBPACK_IMPORTED_MODULE_9__.distinctUntilChanged)(), (0,rxjs_operators__WEBPACK_IMPORTED_MODULE_12__.shareReplay)(1));
    this.userLocaleSubject = new rxjs__WEBPACK_IMPORTED_MODULE_2__.BehaviorSubject(null);
    this.userLocale$ = this.userLocaleSubject.pipe((0,rxjs_operators__WEBPACK_IMPORTED_MODULE_9__.distinctUntilChanged)(), (0,rxjs_operators__WEBPACK_IMPORTED_MODULE_10__.filter)(locale => locale !== null), (0,rxjs_operators__WEBPACK_IMPORTED_MODULE_12__.shareReplay)(1));
    this.pluralRules$ = this.userLocale$.pipe((0,rxjs_operators__WEBPACK_IMPORTED_MODULE_11__.map)(locale => new Intl.PluralRules(locale)), (0,rxjs_operators__WEBPACK_IMPORTED_MODULE_12__.shareReplay)(1));
    this.userProfileEditedSubject = new rxjs__WEBPACK_IMPORTED_MODULE_1__.Subject();
    this.userProfileCouldBeChanged$ = (0,rxjs__WEBPACK_IMPORTED_MODULE_4__.merge)(this.authService.isReadyForApi$.pipe((0,_rxjs_utils__WEBPACK_IMPORTED_MODULE_15__.mapTo)({
      isFirst: true
    })), this.refresherService.refreshed$.pipe((0,_rxjs_utils__WEBPACK_IMPORTED_MODULE_15__.mapTo)({
      isFirst: false
    })));
    this.userProfile$ = (0,rxjs__WEBPACK_IMPORTED_MODULE_4__.merge)(this.userProfileCouldBeChanged$.pipe((0,rxjs_operators__WEBPACK_IMPORTED_MODULE_13__.switchMap)(/*#__PURE__*/function () {
      var _ref = (0,_Users_smartcommunitylab_Desktop_newWork_playAndGo_playGo_node_modules_babel_runtime_helpers_esm_asyncToGenerator_js__WEBPACK_IMPORTED_MODULE_0__["default"])(function* (trigger) {
        try {
          return yield _this.getUserProfile();
        } catch (e) {
          _this.errorService.handleError(e, trigger.isFirst ? 'blocking' : 'normal');
          return null;
        }
      });
      return function (_x) {
        return _ref.apply(this, arguments);
      };
    }())), this.userProfileEditedSubject).pipe((0,rxjs_operators__WEBPACK_IMPORTED_MODULE_10__.filter)(Boolean),
    // we don't want distinctUntilChanged because of avatarUrl, which should be updated
    // on every read (after update same url will contain different image)
    // distinctUntilChanged(isEqual),
    (0,rxjs_operators__WEBPACK_IMPORTED_MODULE_13__.switchMap)(/*#__PURE__*/function () {
      var _ref2 = (0,_Users_smartcommunitylab_Desktop_newWork_playAndGo_playGo_node_modules_babel_runtime_helpers_esm_asyncToGenerator_js__WEBPACK_IMPORTED_MODULE_0__["default"])(function* (user) {
        _this.changeLanguage(user.language);
        yield _this.storeUserInLocalStorage(user);
        return user;
      });
      return function (_x2) {
        return _ref2.apply(this, arguments);
      };
    }()), (0,rxjs_operators__WEBPACK_IMPORTED_MODULE_12__.shareReplay)(1));
    this.userStorage = this.localStorageService.getStorageOf('user');
    this.userProfileTerritory$ = (0,rxjs__WEBPACK_IMPORTED_MODULE_3__.combineLatest)([this.userProfile$, this.territoryService.territories$]).pipe((0,rxjs_operators__WEBPACK_IMPORTED_MODULE_11__.map)(([userProfile, territories]) => territories.find(territory => territory.territoryId === userProfile.territoryId)));
  }
  /**
   * User language
   *
   * Format: 'it' / 'en'
   * Returned from server.
   * */
  getLanguage() {
    return this.userLanguageSubject.value;
  }
  /**
   * User locale.
   *
   * Format is Unicode Locale Identifier. For example: 'it-IT' or 'en-US'.
   * Right now derived from the user language.
   * */
  getLocale() {
    return this.userLocaleSubject.value;
  }
  /**
   * @throws http error
   */
  uploadAvatar(player, file) {
    var _this2 = this;
    return (0,_Users_smartcommunitylab_Desktop_newWork_playAndGo_playGo_node_modules_babel_runtime_helpers_esm_asyncToGenerator_js__WEBPACK_IMPORTED_MODULE_0__["default"])(function* () {
      const formData = new FormData();
      formData.append('data', file);
      const avatar = yield _this2.playerControllerService.uploadPlayerAvatarUsingPOST(formData).toPromise();
      const timestampedAvatar = _this2.timestampAvatarUrls(avatar);
      _this2.userProfileEditedSubject.next({
        ...player,
        avatar: timestampedAvatar
      });
      return avatar;
    })();
  }
  /**
   * do not throw http error
   */
  getAvatar(player) {
    const avatarDefaults = {
      avatarSmallUrl: 'assets/images/registration/generic_user.png',
      avatarUrl: 'assets/images/registration/generic_user.png'
    };
    return this.playerControllerService.getPlayerAvatarUsingGET(player?.playerId).pipe((0,rxjs_operators__WEBPACK_IMPORTED_MODULE_8__.catchError)(error => {
      if (error instanceof _angular_common_http__WEBPACK_IMPORTED_MODULE_7__.HttpErrorResponse && (error?.status === 404 || error?.status === 400 || error?.status === 500) && error?.error?.ex === 'avatar not found') {
        return (0,rxjs__WEBPACK_IMPORTED_MODULE_5__.of)(avatarDefaults);
      }
      // we do not want to block app completely.
      this.errorService.handleError(error, 'normal');
      return (0,rxjs__WEBPACK_IMPORTED_MODULE_5__.of)(avatarDefaults);
    }), (0,rxjs_operators__WEBPACK_IMPORTED_MODULE_11__.map)(avatar => ({
      ...avatarDefaults,
      ...this.timestampAvatarUrls(avatar)
    }))).toPromise();
  }
  timestampAvatarUrls(avatar) {
    return {
      ...avatar,
      avatarUrl: this.timestampUrl(avatar.avatarUrl),
      avatarSmallUrl: this.timestampUrl(avatar.avatarSmallUrl)
    };
  }
  timestampUrl(url) {
    if (!url || url.includes('?')) {
      return url;
    }
    return url + '?t=' + new Date().getTime();
  }
  /**
   * do not throw http error
   */
  getOtherPlayerAvatar(playerId) {
    const avatarDefaults = {
      avatarSmallUrl: 'assets/images/registration/generic_user.png',
      avatarUrl: 'assets/images/registration/generic_user.png'
    };
    return this.playerControllerService.getPlayerAvatarUsingGET(playerId).pipe((0,rxjs_operators__WEBPACK_IMPORTED_MODULE_8__.catchError)(error => {
      if (error instanceof _angular_common_http__WEBPACK_IMPORTED_MODULE_7__.HttpErrorResponse && (error.status === 404 || error.status === 400) && error.error?.ex === 'avatar not found') {
        return (0,rxjs__WEBPACK_IMPORTED_MODULE_5__.of)(avatarDefaults);
      }
      // we do not want to block app completely.
      this.errorService.handleError(error, 'normal');
      return (0,rxjs__WEBPACK_IMPORTED_MODULE_5__.of)(avatarDefaults);
    }), (0,rxjs_operators__WEBPACK_IMPORTED_MODULE_11__.map)(avatar => ({
      ...avatarDefaults,
      ...avatar
    })));
  }
  /**
   * @throws http error
   */
  getAACUserInfo() {
    return this.http.request('GET', src_environments_environment__WEBPACK_IMPORTED_MODULE_6__.environment.authConfig.server_host + '/userinfo').toPromise();
  }
  /**
   * does not throw http error
   */
  changeLanguage(language) {
    if (!language) {
      return;
    }
    this.translateService.use(language);
    this.userLanguageSubject.next(language);
    switch (language) {
      case 'it':
        {
          this.userLocaleSubject.next('it-IT');
          break;
        }
      case 'en':
        {
          this.userLocaleSubject.next('en-US');
          break;
        }
    }
  }
  /**
   * @throws http error
   */
  getUserProfile() {
    var _this3 = this;
    return (0,_Users_smartcommunitylab_Desktop_newWork_playAndGo_playGo_node_modules_babel_runtime_helpers_esm_asyncToGenerator_js__WEBPACK_IMPORTED_MODULE_0__["default"])(function* () {
      let user;
      try {
        const profile = yield _this3.getProfile();
        const avatar = yield _this3.getAvatar(profile);
        user = {
          ...profile,
          avatar
        };
      } catch (e) {
        if ((0,_utils__WEBPACK_IMPORTED_MODULE_14__.isOfflineError)(e)) {
          user = yield _this3.userStorage.get();
        } else {
          throw e;
        }
      }
      if (!user) {
        _this3.navCtrl.navigateRoot('/pages/registration');
        return;
      }
      return user;
    })();
  }
  storeUserInLocalStorage(userWithAvatar) {
    var _this4 = this;
    return (0,_Users_smartcommunitylab_Desktop_newWork_playAndGo_playGo_node_modules_babel_runtime_helpers_esm_asyncToGenerator_js__WEBPACK_IMPORTED_MODULE_0__["default"])(function* () {
      const lastStoredUser = yield _this4.userStorage.get();
      if (lastStoredUser && lastStoredUser.playerId !== userWithAvatar.playerId) {
        _this4.localStorageService.clearAll();
      }
      _this4.userStorage.set(userWithAvatar);
    })();
  }
  /**
   *
   * @param user
   * @returns
   * @throws http error
   */
  registerPlayer(playerData) {
    //TODO update local profile
    const newPlayer = this.playerControllerService.registerPlayerUsingPOST(playerData).toPromise();
    this.userProfileEditedSubject.next({
      ...playerData,
      avatar: null
    });
    return newPlayer;
  }
  /**
   * Call api to test if user is registered
   *
   * @returns true / false / null = not known
   *
   * does not throw http error
   */
  isUserRegistered() {
    var _this5 = this;
    return (0,_Users_smartcommunitylab_Desktop_newWork_playAndGo_playGo_node_modules_babel_runtime_helpers_esm_asyncToGenerator_js__WEBPACK_IMPORTED_MODULE_0__["default"])(function* () {
      try {
        const user = yield _this5.playerControllerService.getProfileUsingGET().toPromise();
        if (user) {
          //user registered
          return true;
        } else {
          //user not registered
          return false;
        }
      } catch (e) {
        // toto check local storage
        console.warn(e);
        return null;
      }
    })();
  }
  /**
   *
   * @returns player profile
   * @throws http error
   */
  getProfile() {
    return this.playerControllerService.getProfileUsingGET().toPromise();
  }
  /**
   *
   * @param user player profile
   * @returns updated player profile
   * @throws http error
   */
  updatePlayer(user) {
    var _this6 = this;
    return (0,_Users_smartcommunitylab_Desktop_newWork_playAndGo_playGo_node_modules_babel_runtime_helpers_esm_asyncToGenerator_js__WEBPACK_IMPORTED_MODULE_0__["default"])(function* () {
      //TODO update local profile
      const player = yield _this6.playerControllerService.updateProfileUsingPUT(user).toPromise();
      _this6.userProfileEditedSubject.next({
        ...player,
        avatar: user.avatar
      });
      return player;
    })();
  }
  deleteAccount() {
    var _this7 = this;
    return (0,_Users_smartcommunitylab_Desktop_newWork_playAndGo_playGo_node_modules_babel_runtime_helpers_esm_asyncToGenerator_js__WEBPACK_IMPORTED_MODULE_0__["default"])(function* () {
      return yield _this7.playerControllerService.unregisterPlayerUsingPUT().toPromise();
    })();
  }
  static #_ = _staticBlock = () => (this.ɵfac = function UserService_Factory(__ngFactoryType__) {
    return new (__ngFactoryType__ || UserService)(_angular_core__WEBPACK_IMPORTED_MODULE_16__["ɵɵinject"](_ngx_translate_core__WEBPACK_IMPORTED_MODULE_17__.TranslateService), _angular_core__WEBPACK_IMPORTED_MODULE_16__["ɵɵinject"](_territory_service__WEBPACK_IMPORTED_MODULE_18__.TerritoryService), _angular_core__WEBPACK_IMPORTED_MODULE_16__["ɵɵinject"](_local_storage_service__WEBPACK_IMPORTED_MODULE_19__.LocalStorageService), _angular_core__WEBPACK_IMPORTED_MODULE_16__["ɵɵinject"](_ionic_angular__WEBPACK_IMPORTED_MODULE_20__.NavController), _angular_core__WEBPACK_IMPORTED_MODULE_16__["ɵɵinject"](_auth_auth_service__WEBPACK_IMPORTED_MODULE_21__.AuthService), _angular_core__WEBPACK_IMPORTED_MODULE_16__["ɵɵinject"](_angular_common_http__WEBPACK_IMPORTED_MODULE_7__.HttpClient), _angular_core__WEBPACK_IMPORTED_MODULE_16__["ɵɵinject"](_api_generated_controllers_playerController_service__WEBPACK_IMPORTED_MODULE_22__.PlayerControllerService), _angular_core__WEBPACK_IMPORTED_MODULE_16__["ɵɵinject"](_refresher_service__WEBPACK_IMPORTED_MODULE_23__.RefresherService), _angular_core__WEBPACK_IMPORTED_MODULE_16__["ɵɵinject"](_alert_service__WEBPACK_IMPORTED_MODULE_24__.AlertService), _angular_core__WEBPACK_IMPORTED_MODULE_16__["ɵɵinject"](_error_service__WEBPACK_IMPORTED_MODULE_25__.ErrorService));
  }, this.ɵprov = /*@__PURE__*/_angular_core__WEBPACK_IMPORTED_MODULE_16__["ɵɵdefineInjectable"]({
    token: UserService,
    factory: UserService.ɵfac,
    providedIn: 'root'
  }));
}
_staticBlock();

/***/ }),

/***/ 91502:
/*!********************************************************************************************!*\
  !*** ./src/app/core/shared/campaigns/app-widget-campaign/app-widget-campaign.component.ts ***!
  \********************************************************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   WidgetComponent: () => (/* binding */ WidgetComponent)
/* harmony export */ });
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! @angular/core */ 34205);
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @angular/core */ 12481);
/* harmony import */ var _angular_router__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @angular/router */ 85422);
/* harmony import */ var _angular_common__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @angular/common */ 93683);
/* harmony import */ var _home_widget_types_home_campaign_city_home_campaign_city_component__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! ../home-widget-types/home-campaign-city/home-campaign-city.component */ 23797);
/* harmony import */ var _home_widget_types_home_campaign_school_home_campaign_school_component__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! ../home-widget-types/home-campaign-school/home-campaign-school.component */ 34127);
/* harmony import */ var _home_widget_types_home_campaign_company_home_campaign_company_component__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! ../home-widget-types/home-campaign-company/home-campaign-company.component */ 14055);
/* harmony import */ var _home_widget_types_home_campaign_personal_home_campaign_personal_component__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(/*! ../home-widget-types/home-campaign-personal/home-campaign-personal.component */ 29639);
var _staticBlock;







function WidgetComponent_ng_container_1_Template(rf, ctx) {
  if (rf & 1) {
    const _r1 = _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵgetCurrentView"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵelementContainerStart"](0);
    _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵelementStart"](1, "app-home-campaign-personal", 3);
    _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵlistener"]("click", function WidgetComponent_ng_container_1_Template_app_home_campaign_personal_click_1_listener() {
      _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵrestoreView"](_r1);
      const ctx_r1 = _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵnextContext"]();
      return _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵresetView"](ctx_r1.detailCampaign(ctx_r1.campaign));
    });
    _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵelementEnd"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵelementContainerEnd"]();
  }
  if (rf & 2) {
    const ctx_r1 = _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵnextContext"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵadvance"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵproperty"]("header", ctx_r1.header)("campaignContainer", ctx_r1.campaign);
  }
}
function WidgetComponent_ng_container_2_Template(rf, ctx) {
  if (rf & 1) {
    const _r3 = _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵgetCurrentView"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵelementContainerStart"](0);
    _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵelementStart"](1, "app-home-campaign-city", 3);
    _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵlistener"]("click", function WidgetComponent_ng_container_2_Template_app_home_campaign_city_click_1_listener() {
      _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵrestoreView"](_r3);
      const ctx_r1 = _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵnextContext"]();
      return _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵresetView"](ctx_r1.detailCampaign(ctx_r1.campaign));
    });
    _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵelementEnd"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵelementContainerEnd"]();
  }
  if (rf & 2) {
    const ctx_r1 = _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵnextContext"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵadvance"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵproperty"]("header", ctx_r1.header)("campaignContainer", ctx_r1.campaign);
  }
}
function WidgetComponent_ng_container_3_Template(rf, ctx) {
  if (rf & 1) {
    const _r4 = _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵgetCurrentView"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵelementContainerStart"](0);
    _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵelementStart"](1, "app-home-campaign-company", 3);
    _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵlistener"]("click", function WidgetComponent_ng_container_3_Template_app_home_campaign_company_click_1_listener() {
      _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵrestoreView"](_r4);
      const ctx_r1 = _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵnextContext"]();
      return _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵresetView"](ctx_r1.detailCampaign(ctx_r1.campaign));
    });
    _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵelementEnd"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵelementContainerEnd"]();
  }
  if (rf & 2) {
    const ctx_r1 = _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵnextContext"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵadvance"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵproperty"]("header", ctx_r1.header)("campaignContainer", ctx_r1.campaign);
  }
}
function WidgetComponent_ng_container_4_Template(rf, ctx) {
  if (rf & 1) {
    const _r5 = _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵgetCurrentView"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵelementContainerStart"](0);
    _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵelementStart"](1, "app-home-campaign-school", 3);
    _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵlistener"]("click", function WidgetComponent_ng_container_4_Template_app_home_campaign_school_click_1_listener() {
      _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵrestoreView"](_r5);
      const ctx_r1 = _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵnextContext"]();
      return _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵresetView"](ctx_r1.detailCampaign(ctx_r1.campaign));
    });
    _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵelementEnd"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵelementContainerEnd"]();
  }
  if (rf & 2) {
    const ctx_r1 = _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵnextContext"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵadvance"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵproperty"]("header", ctx_r1.header)("campaignContainer", ctx_r1.campaign);
  }
}
function WidgetComponent_ng_container_5_Template(rf, ctx) {
  if (rf & 1) {
    _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵelementContainerStart"](0);
    _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵtext"](1, " default ");
    _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵelementContainerEnd"]();
  }
}
class WidgetComponent {
  constructor(router) {
    this.router = router;
    this.header = false;
  }
  ngOnInit() {}
  ngOnDestroy() {}
  detailCampaign(campaign) {
    this.router.navigateByUrl('/pages/tabs/home/details/' + campaign.campaign.campaignId);
  }
  static #_ = _staticBlock = () => (this.ɵfac = function WidgetComponent_Factory(__ngFactoryType__) {
    return new (__ngFactoryType__ || WidgetComponent)(_angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵdirectiveInject"](_angular_router__WEBPACK_IMPORTED_MODULE_2__.Router));
  }, this.ɵcmp = /*@__PURE__*/_angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵdefineComponent"]({
    type: WidgetComponent,
    selectors: [["app-widget-campaign"]],
    inputs: {
      campaign: "campaign",
      header: "header"
    },
    standalone: false,
    decls: 6,
    vars: 5,
    consts: [[3, "ngSwitch"], [4, "ngSwitchCase"], [4, "ngSwitchDefault"], [3, "click", "header", "campaignContainer"]],
    template: function WidgetComponent_Template(rf, ctx) {
      if (rf & 1) {
        _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵelementContainerStart"](0, 0);
        _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵtemplate"](1, WidgetComponent_ng_container_1_Template, 2, 2, "ng-container", 1)(2, WidgetComponent_ng_container_2_Template, 2, 2, "ng-container", 1)(3, WidgetComponent_ng_container_3_Template, 2, 2, "ng-container", 1)(4, WidgetComponent_ng_container_4_Template, 2, 2, "ng-container", 1)(5, WidgetComponent_ng_container_5_Template, 2, 0, "ng-container", 2);
        _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵelementContainerEnd"]();
      }
      if (rf & 2) {
        _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵproperty"]("ngSwitch", ctx.campaign.campaign.type);
        _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵadvance"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵproperty"]("ngSwitchCase", "personal");
        _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵadvance"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵproperty"]("ngSwitchCase", "city");
        _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵadvance"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵproperty"]("ngSwitchCase", "company");
        _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵadvance"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵproperty"]("ngSwitchCase", "school");
      }
    },
    dependencies: [_angular_common__WEBPACK_IMPORTED_MODULE_3__.NgSwitch, _angular_common__WEBPACK_IMPORTED_MODULE_3__.NgSwitchCase, _angular_common__WEBPACK_IMPORTED_MODULE_3__.NgSwitchDefault, _home_widget_types_home_campaign_city_home_campaign_city_component__WEBPACK_IMPORTED_MODULE_4__.HomeCampaignCityComponent, _home_widget_types_home_campaign_school_home_campaign_school_component__WEBPACK_IMPORTED_MODULE_5__.HomeCampaignSchoolComponent, _home_widget_types_home_campaign_company_home_campaign_company_component__WEBPACK_IMPORTED_MODULE_6__.HomeCampaignCompanyComponent, _home_widget_types_home_campaign_personal_home_campaign_personal_component__WEBPACK_IMPORTED_MODULE_7__.HomeCampaignPersonalComponent],
    styles: ["/*# sourceMappingURL=data:application/json;charset=utf-8;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbXSwibmFtZXMiOltdLCJtYXBwaW5ncyI6IiIsInNvdXJjZVJvb3QiOiIifQ== */"]
  }));
}
_staticBlock();

/***/ }),

/***/ 94114:
/*!***************************************!*\
  !*** ./src/app/app-routing.module.ts ***!
  \***************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   AppRoutingModule: () => (/* binding */ AppRoutingModule)
/* harmony export */ });
/* harmony import */ var _angular_router__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! @angular/router */ 34487);
/* harmony import */ var _core_auth_auth_guard_service__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ./core/auth/auth-guard.service */ 63352);
/* harmony import */ var _core_shared_services_offline_guard__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! ./core/shared/services/offline.guard */ 2661);
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @angular/core */ 34205);
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! @angular/core */ 12481);
var _staticBlock;





const routes = [{
  path: '',
  redirectTo: 'pages',
  pathMatch: 'full'
}, {
  path: 'pages',
  canActivate: [_core_auth_auth_guard_service__WEBPACK_IMPORTED_MODULE_1__.AuthGuardService, _core_shared_services_offline_guard__WEBPACK_IMPORTED_MODULE_2__.OfflineGuard],
  canActivateChild: [_core_shared_services_offline_guard__WEBPACK_IMPORTED_MODULE_2__.OfflineGuard],
  loadChildren: () => __webpack_require__.e(/*! import() */ "src_app_pages_pages-routing_module_ts").then(__webpack_require__.bind(__webpack_require__, /*! ./pages/pages-routing.module */ 9390)).then(m => m.PagesRoutingModule)
}, {
  path: 'login',
  loadChildren: () => __webpack_require__.e(/*! import() */ "src_app_auth-pages_login_login_module_ts").then(__webpack_require__.bind(__webpack_require__, /*! ./auth-pages/login/login.module */ 50593)).then(m => m.LoginPageModule)
}, {
  path: 'auth/callback',
  loadChildren: () => __webpack_require__.e(/*! import() */ "src_app_auth-pages_auth-callback_auth-callback_module_ts").then(__webpack_require__.bind(__webpack_require__, /*! ./auth-pages/auth-callback/auth-callback.module */ 37261)).then(m => m.AuthCallbackPageModule)
}, {
  path: 'auth/endsession',
  loadChildren: () => __webpack_require__.e(/*! import() */ "src_app_auth-pages_end-session_end-session_module_ts").then(__webpack_require__.bind(__webpack_require__, /*! ./auth-pages/end-session/end-session.module */ 57481)).then(m => m.EndSessionPageModule)
}];
class AppRoutingModule {
  static #_ = _staticBlock = () => (this.ɵfac = function AppRoutingModule_Factory(__ngFactoryType__) {
    return new (__ngFactoryType__ || AppRoutingModule)();
  }, this.ɵmod = /*@__PURE__*/_angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵdefineNgModule"]({
    type: AppRoutingModule
  }), this.ɵinj = /*@__PURE__*/_angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵdefineInjector"]({
    imports: [_angular_router__WEBPACK_IMPORTED_MODULE_0__.RouterModule.forRoot(routes, {
      preloadingStrategy: _angular_router__WEBPACK_IMPORTED_MODULE_0__.PreloadAllModules
    }), _angular_router__WEBPACK_IMPORTED_MODULE_0__.RouterModule]
  }));
}
_staticBlock();
(function () {
  (typeof ngJitMode === "undefined" || ngJitMode) && _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵsetNgModuleScope"](AppRoutingModule, {
    imports: [_angular_router__WEBPACK_IMPORTED_MODULE_0__.RouterModule],
    exports: [_angular_router__WEBPACK_IMPORTED_MODULE_0__.RouterModule]
  });
})();

/***/ }),

/***/ 98486:
/*!**********************************************!*\
  !*** ./src/app/core/auth/factories/index.ts ***!
  \**********************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   authFactory: () => (/* reexport safe */ _auth_factory__WEBPACK_IMPORTED_MODULE_0__.authFactory)
/* harmony export */ });
/* harmony import */ var _auth_factory__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./auth.factory */ 27242);


/***/ })

},
/******/ __webpack_require__ => { // webpackRuntimeModules
/******/ var __webpack_exec__ = (moduleId) => (__webpack_require__(__webpack_require__.s = moduleId))
/******/ __webpack_require__.O(0, ["vendor"], () => (__webpack_exec__(84429)));
/******/ var __webpack_exports__ = __webpack_require__.O();
/******/ }
]);
//# sourceMappingURL=main.js.map