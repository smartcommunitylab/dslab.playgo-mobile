"use strict";
(self["webpackChunkapp"] = self["webpackChunkapp"] || []).push([["src_app_pages_campaigns_campaign-join_campaign-join_module_ts"],{

/***/ 6167:
/*!********************************************************************************!*\
  !*** ./src/app/pages/home/campaign-details/companies-modal/companies.modal.ts ***!
  \********************************************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   CompaniesCampaignModalPage: () => (/* binding */ CompaniesCampaignModalPage)
/* harmony export */ });
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! @angular/core */ 12481);
/* harmony import */ var _ionic_angular__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @ionic/angular */ 21507);
/* harmony import */ var src_app_core_shared_services_campaign_service__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! src/app/core/shared/services/campaign.service */ 76658);
/* harmony import */ var _angular_common__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @angular/common */ 93683);
/* harmony import */ var _ngx_translate_core__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! @ngx-translate/core */ 48503);
var _staticBlock;





function CompaniesCampaignModalPage_div_10_Template(rf, ctx) {
  if (rf & 1) {
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](0, "div")(1, "ion-item")(2, "ion-label");
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵtext"](3);
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]()()();
  }
  if (rf & 2) {
    const company_r1 = ctx.$implicit;
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵadvance"](3);
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵtextInterpolate"](company_r1.name);
  }
}
class CompaniesCampaignModalPage {
  constructor(modalController, campaignService) {
    this.modalController = modalController;
    this.campaignService = campaignService;
  }
  ngOnInit() {
    this.sub = this.campaignService.getCompaniesForSubscription(this?.campaign?.campaignId).subscribe(result => {
      if (result) {
        this.companies = result;
      }
    });
  }
  close() {
    this.modalController.dismiss(false);
  }
  static #_ = _staticBlock = () => (this.ɵfac = function CompaniesCampaignModalPage_Factory(__ngFactoryType__) {
    return new (__ngFactoryType__ || CompaniesCampaignModalPage)(_angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵdirectiveInject"](_ionic_angular__WEBPACK_IMPORTED_MODULE_1__.ModalController), _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵdirectiveInject"](src_app_core_shared_services_campaign_service__WEBPACK_IMPORTED_MODULE_2__.CampaignService));
  }, this.ɵcmp = /*@__PURE__*/_angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵdefineComponent"]({
    type: CompaniesCampaignModalPage,
    selectors: [["app-detail-modal"]],
    standalone: false,
    decls: 11,
    vars: 7,
    consts: [["color", "playgo"], ["slot", "end"], [3, "click"], [1, "ion-padding"], [4, "ngFor", "ngForOf"]],
    template: function CompaniesCampaignModalPage_Template(rf, ctx) {
      if (rf & 1) {
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](0, "ion-header")(1, "ion-toolbar", 0)(2, "ion-title");
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵtext"](3);
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵpipe"](4, "translate");
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](5, "ion-buttons", 1)(6, "ion-button", 2);
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵlistener"]("click", function CompaniesCampaignModalPage_Template_ion_button_click_6_listener() {
          return ctx.close();
        });
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵtext"](7);
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵpipe"](8, "translate");
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]()()()();
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](9, "ion-content", 3);
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵtemplate"](10, CompaniesCampaignModalPage_div_10_Template, 4, 1, "div", 4);
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();
      }
      if (rf & 2) {
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵadvance"](3);
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵtextInterpolate"](_angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵpipeBind1"](4, 3, "campaigns.campaignmodal.title"));
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵadvance"](4);
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵtextInterpolate"](_angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵpipeBind1"](8, 5, "campaigns.campaignmodal.close"));
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵadvance"](3);
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵproperty"]("ngForOf", ctx.companies);
      }
    },
    dependencies: [_angular_common__WEBPACK_IMPORTED_MODULE_3__.NgForOf, _ionic_angular__WEBPACK_IMPORTED_MODULE_1__.IonButton, _ionic_angular__WEBPACK_IMPORTED_MODULE_1__.IonButtons, _ionic_angular__WEBPACK_IMPORTED_MODULE_1__.IonContent, _ionic_angular__WEBPACK_IMPORTED_MODULE_1__.IonHeader, _ionic_angular__WEBPACK_IMPORTED_MODULE_1__.IonItem, _ionic_angular__WEBPACK_IMPORTED_MODULE_1__.IonLabel, _ionic_angular__WEBPACK_IMPORTED_MODULE_1__.IonTitle, _ionic_angular__WEBPACK_IMPORTED_MODULE_1__.IonToolbar, _ngx_translate_core__WEBPACK_IMPORTED_MODULE_4__.TranslatePipe],
    styles: ["/*# sourceMappingURL=data:application/json;charset=utf-8;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbXSwibmFtZXMiOltdLCJtYXBwaW5ncyI6IiIsInNvdXJjZVJvb3QiOiIifQ== */"]
  }));
}
_staticBlock();

/***/ }),

/***/ 8682:
/*!***********************************************************************!*\
  !*** ./src/app/pages/campaigns/campaign-join/campaign-join.module.ts ***!
  \***********************************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   CampaignJoinPageModule: () => (/* binding */ CampaignJoinPageModule)
/* harmony export */ });
/* harmony import */ var _campaign_join_routing_module__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./campaign-join-routing.module */ 35691);
/* harmony import */ var _campaign_join_page__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ./campaign-join.page */ 53789);
/* harmony import */ var src_app_core_shared_shared_module__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! src/app/core/shared/shared.module */ 62657);
/* harmony import */ var _join_company_join_company_modal__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! ./join-company/join-company.modal */ 25749);
/* harmony import */ var _join_city_join_city_modal__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! ./join-city/join-city.modal */ 86591);
/* harmony import */ var _join_school_join_school_modal__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! ./join-school/join-school.modal */ 52035);
/* harmony import */ var _ionic_angular__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! @ionic/angular */ 21507);
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(/*! @angular/core */ 34205);
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(/*! @angular/core */ 12481);
var _staticBlock;








class CampaignJoinPageModule {
  static #_ = _staticBlock = () => (this.ɵfac = function CampaignJoinPageModule_Factory(__ngFactoryType__) {
    return new (__ngFactoryType__ || CampaignJoinPageModule)();
  }, this.ɵmod = /*@__PURE__*/_angular_core__WEBPACK_IMPORTED_MODULE_8__["ɵɵdefineNgModule"]({
    type: CampaignJoinPageModule
  }), this.ɵinj = /*@__PURE__*/_angular_core__WEBPACK_IMPORTED_MODULE_7__["ɵɵdefineInjector"]({
    imports: [_campaign_join_routing_module__WEBPACK_IMPORTED_MODULE_0__.CampaignJoinPageRoutingModule, src_app_core_shared_shared_module__WEBPACK_IMPORTED_MODULE_2__.PlayGoSharedModule, _ionic_angular__WEBPACK_IMPORTED_MODULE_6__.IonicModule]
  }));
}
_staticBlock();
(function () {
  (typeof ngJitMode === "undefined" || ngJitMode) && _angular_core__WEBPACK_IMPORTED_MODULE_8__["ɵɵsetNgModuleScope"](CampaignJoinPageModule, {
    declarations: [_campaign_join_page__WEBPACK_IMPORTED_MODULE_1__.CampaignJoinPage, _join_company_join_company_modal__WEBPACK_IMPORTED_MODULE_3__.JoinCompanyModalPage, _join_city_join_city_modal__WEBPACK_IMPORTED_MODULE_4__.JoinCityModalPage, _join_school_join_school_modal__WEBPACK_IMPORTED_MODULE_5__.JoinSchoolModalPage],
    imports: [_campaign_join_routing_module__WEBPACK_IMPORTED_MODULE_0__.CampaignJoinPageRoutingModule, src_app_core_shared_shared_module__WEBPACK_IMPORTED_MODULE_2__.PlayGoSharedModule, _ionic_angular__WEBPACK_IMPORTED_MODULE_6__.IonicModule]
  });
})();

/***/ }),

/***/ 25749:
/*!**********************************************************************************!*\
  !*** ./src/app/pages/campaigns/campaign-join/join-company/join-company.modal.ts ***!
  \**********************************************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   JoinCompanyModalPage: () => (/* binding */ JoinCompanyModalPage)
/* harmony export */ });
/* harmony import */ var _angular_forms__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! @angular/forms */ 34456);
/* harmony import */ var src_app_core_shared_pipes_languageMap_pipe__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ../../../../core/shared/pipes/languageMap.pipe */ 69618);
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @angular/core */ 34205);
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @angular/core */ 12481);
/* harmony import */ var _ionic_angular__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! @ionic/angular */ 21507);
/* harmony import */ var _ionic_angular__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! @ionic/angular */ 4059);
/* harmony import */ var src_app_core_shared_services_error_service__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! src/app/core/shared/services/error.service */ 46078);
/* harmony import */ var src_app_core_shared_services_alert_service__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(/*! src/app/core/shared/services/alert.service */ 67406);
/* harmony import */ var src_app_core_shared_services_campaign_service__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(/*! src/app/core/shared/services/campaign.service */ 76658);
/* harmony import */ var src_app_core_shared_services_user_service__WEBPACK_IMPORTED_MODULE_9__ = __webpack_require__(/*! src/app/core/shared/services/user.service */ 89815);
/* harmony import */ var _angular_common__WEBPACK_IMPORTED_MODULE_10__ = __webpack_require__(/*! @angular/common */ 93683);
/* harmony import */ var ionic_selectable__WEBPACK_IMPORTED_MODULE_11__ = __webpack_require__(/*! ionic-selectable */ 56885);
/* harmony import */ var _ngx_translate_core__WEBPACK_IMPORTED_MODULE_12__ = __webpack_require__(/*! @ngx-translate/core */ 48503);
var _staticBlock;














const _c0 = a0 => ({
  campaignTitle: a0
});
const _c1 = a0 => ({
  "hide-company-selection": a0
});
function JoinCompanyModalPage_ng_template_21_Template(rf, ctx) {
  if (rf & 1) {
    _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵtext"](0);
    _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵpipe"](1, "translate");
  }
  if (rf & 2) {
    _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵtextInterpolate1"](" ", _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵpipeBind1"](1, 1, "campaigns.detail.companies"), " ");
  }
}
function JoinCompanyModalPage_ng_template_22_Template(rf, ctx) {
  if (rf & 1) {
    _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵelement"](0, "ion-icon", 19);
  }
}
function JoinCompanyModalPage_ng_template_23_Template(rf, ctx) {
  if (rf & 1) {
    _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵelement"](0, "ion-icon", 20);
  }
  if (rf & 2) {
    const isPortSelected_r1 = ctx.isItemSelected;
    _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵproperty"]("name", isPortSelected_r1 ? "checkmark-circle" : "radio-button-off")("color", isPortSelected_r1 ? "light" : null);
  }
}
function JoinCompanyModalPage_div_24_Template(rf, ctx) {
  if (rf & 1) {
    _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵelementStart"](0, "div", 21);
    _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵtext"](1);
    _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵpipe"](2, "translate");
    _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵelementEnd"]();
  }
  if (rf & 2) {
    _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵadvance"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵtextInterpolate1"](" ", _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵpipeBind1"](2, 1, "campaigns.joinmodal.companyRequired"), " ");
  }
}
function JoinCompanyModalPage_div_34_Template(rf, ctx) {
  if (rf & 1) {
    _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵelementStart"](0, "div", 21);
    _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵtext"](1);
    _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵpipe"](2, "translate");
    _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵelementEnd"]();
  }
  if (rf & 2) {
    _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵadvance"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵtextInterpolate1"](" ", _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵpipeBind1"](2, 1, "campaigns.joinmodal.pinRequired"), " ");
  }
}
function JoinCompanyModalPage_ion_row_35_Template(rf, ctx) {
  if (rf & 1) {
    const _r2 = _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵgetCurrentView"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵelementStart"](0, "ion-row", 11)(1, "ion-col", 12)(2, "ion-label", 22);
    _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵtext"](3);
    _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵpipe"](4, "translate");
    _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵelementEnd"]()();
    _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵelementStart"](5, "ion-col", 23);
    _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵlistener"]("click", function JoinCompanyModalPage_ion_row_35_Template_ion_col_click_5_listener() {
      _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵrestoreView"](_r2);
      const ctx_r2 = _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵnextContext"]();
      return _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵresetView"](ctx_r2.openPrivacyPopup());
    });
    _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵelement"](6, "ion-icon", 24);
    _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵelementEnd"]()();
  }
  if (rf & 2) {
    _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵadvance"](3);
    _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵtextInterpolate"](_angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵpipeBind1"](4, 1, "campaigns.joinmodal.privacyLink"));
  }
}
function JoinCompanyModalPage_ion_row_36_Template(rf, ctx) {
  if (rf & 1) {
    _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵelementStart"](0, "ion-row", 11)(1, "ion-col")(2, "ion-item", 0);
    _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵelement"](3, "ion-checkbox", 25);
    _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵelementStart"](4, "ion-label", 26);
    _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵtext"](5);
    _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵpipe"](6, "translate");
    _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵelementEnd"]()()()();
  }
  if (rf & 2) {
    _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵadvance"](5);
    _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵtextInterpolate"](_angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵpipeBind1"](6, 1, "campaigns.joinmodal.privacy"));
  }
}
function JoinCompanyModalPage_div_37_Template(rf, ctx) {
  if (rf & 1) {
    _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵelementStart"](0, "div", 21);
    _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵtext"](1);
    _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵpipe"](2, "translate");
    _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵelementEnd"]();
  }
  if (rf & 2) {
    _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵadvance"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵtextInterpolate1"](" ", _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵpipeBind1"](2, 1, "campaigns.joinmodal.privacyRequired"), " ");
  }
}
function JoinCompanyModalPage_ion_row_38_Template(rf, ctx) {
  if (rf & 1) {
    const _r4 = _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵgetCurrentView"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵelementStart"](0, "ion-row", 11)(1, "ion-col", 12)(2, "ion-label", 22);
    _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵtext"](3);
    _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵpipe"](4, "translate");
    _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵelementEnd"]()();
    _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵelementStart"](5, "ion-col", 23);
    _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵlistener"]("click", function JoinCompanyModalPage_ion_row_38_Template_ion_col_click_5_listener() {
      _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵrestoreView"](_r4);
      const ctx_r2 = _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵnextContext"]();
      return _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵresetView"](ctx_r2.openRulesPopup());
    });
    _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵelement"](6, "ion-icon", 24);
    _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵelementEnd"]()();
  }
  if (rf & 2) {
    _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵadvance"](3);
    _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵtextInterpolate"](_angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵpipeBind1"](4, 1, "campaigns.joinmodal.rulesLink"));
  }
}
function JoinCompanyModalPage_ion_row_39_Template(rf, ctx) {
  if (rf & 1) {
    _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵelementStart"](0, "ion-row", 11)(1, "ion-col")(2, "ion-item", 0);
    _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵelement"](3, "ion-checkbox", 27);
    _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵelementStart"](4, "ion-label", 26);
    _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵtext"](5);
    _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵpipe"](6, "translate");
    _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵelementEnd"]()()()();
  }
  if (rf & 2) {
    _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵadvance"](5);
    _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵtextInterpolate"](_angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵpipeBind1"](6, 1, "campaigns.joinmodal.rules"));
  }
}
function JoinCompanyModalPage_div_40_Template(rf, ctx) {
  if (rf & 1) {
    _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵelementStart"](0, "div", 21);
    _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵtext"](1);
    _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵpipe"](2, "translate");
    _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵelementEnd"]();
  }
  if (rf & 2) {
    _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵadvance"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵtextInterpolate1"](" ", _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵpipeBind1"](2, 1, "campaigns.joinmodal.rulesRequired"), " ");
  }
}
class JoinCompanyModalPage {
  constructor(modalController, errorService, alertService, campaignService, formBuilder, userService, navCtrl, languageMap) {
    this.modalController = modalController;
    this.errorService = errorService;
    this.alertService = alertService;
    this.campaignService = campaignService;
    this.formBuilder = formBuilder;
    this.userService = userService;
    this.navCtrl = navCtrl;
    this.languageMap = languageMap;
    this.isSubmitted = false;
    this.hasOnlyOne = false;
  }
  ngOnInit() {
    this.language = this.userService.getLanguage();
    const rules = this.campaign.details[this.language];
    this.rules = rules?.find(detail => detail.type === 'rules');
    this.privacy = rules?.find(detail => detail.type === 'privacy');
    this.joinCompanyForm = this.formBuilder.group({
      companySelected: ['', [_angular_forms__WEBPACK_IMPORTED_MODULE_0__.Validators.required]],
      companyPIN: ['', [_angular_forms__WEBPACK_IMPORTED_MODULE_0__.Validators.required]],
      ...(this.privacy && {
        privacy: [false, _angular_forms__WEBPACK_IMPORTED_MODULE_0__.Validators.requiredTrue]
      }),
      ...(this.rules && {
        rules: [false, _angular_forms__WEBPACK_IMPORTED_MODULE_0__.Validators.requiredTrue]
      })
    });
    this.sub = this.campaignService.getCompaniesForSubscription(this.campaign.campaignId).subscribe(result => {
      if (result) {
        this.companies = result;
        if (this.companies.length === 1) {
          this.companySelected = this.companies[0];
          this.hasOnlyOne = true;
        }
      }
    });
  }
  ngOnDestroy() {
    this.sub.unsubscribe();
  }
  //computed errorcontrol
  get errorControl() {
    return this.joinCompanyForm.controls;
  }
  close() {
    this.modalController.dismiss(false);
  }
  openPrivacyPopup() {
    this.alertService.presentAlert({
      headerTranslateKey: 'campaigns.joinmodal.privacyPopup.header',
      messageString: this.privacy.content,
      cssClass: 'modalJoin'
    });
  }
  openRulesPopup() {
    this.alertService.presentAlert({
      headerTranslateKey: 'campaigns.joinmodal.rulesPopup.header',
      messageString: this.rules.content,
      cssClass: 'modalJoin'
    });
  }
  openCodeInfoPopup(event) {
    this.alertService.presentAlert({
      headerTranslateKey: 'campaigns.joinmodal.codeInfo.header',
      messageTranslateKey: this.campaign.specificData.registrationCompanyDesc ? this.languageMap.transform(this.campaign.specificData.registrationCompanyDesc) : 'campaigns.joinmodal.companyPIN',
      cssClass: 'modalConfirm'
    });
  }
  joinCompanySubmit() {
    // call join with all params
    this.isSubmitted = true;
    if (!this.joinCompanyForm.valid) {
      return false;
    } else {
      // console.log('employeeCode' + this.joinCompanyForm.value?.companyPIN + 'companyKey' + );
      const body = {
        companyKey: this.joinCompanyForm.value?.companySelected?.code,
        employeeCode: this.joinCompanyForm.value?.companyPIN
      };
      this.sub = this.campaignService.subscribeToCampaign(this.campaign.campaignId, body).subscribe(result => {
        if (result) {
          this.alertService.showToast({
            messageTranslateKey: 'campaigns.registered'
          });
          this.modalController.dismiss(true);
          this.navCtrl.navigateRoot('/pages/tabs/home');
        }
      }, err => {
        this.errorService.handleError(err);
      });
    }
  }
  onSelect(event) {
    console.log('item' + JSON.stringify(event.item) + 'isSelected' + event.isSelected);
  }
  static #_ = _staticBlock = () => (this.ɵfac = function JoinCompanyModalPage_Factory(__ngFactoryType__) {
    return new (__ngFactoryType__ || JoinCompanyModalPage)(_angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵdirectiveInject"](_ionic_angular__WEBPACK_IMPORTED_MODULE_4__.ModalController), _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵdirectiveInject"](src_app_core_shared_services_error_service__WEBPACK_IMPORTED_MODULE_6__.ErrorService), _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵdirectiveInject"](src_app_core_shared_services_alert_service__WEBPACK_IMPORTED_MODULE_7__.AlertService), _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵdirectiveInject"](src_app_core_shared_services_campaign_service__WEBPACK_IMPORTED_MODULE_8__.CampaignService), _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵdirectiveInject"](_angular_forms__WEBPACK_IMPORTED_MODULE_0__.FormBuilder), _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵdirectiveInject"](src_app_core_shared_services_user_service__WEBPACK_IMPORTED_MODULE_9__.UserService), _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵdirectiveInject"](_ionic_angular__WEBPACK_IMPORTED_MODULE_5__.NavController), _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵdirectiveInject"](src_app_core_shared_pipes_languageMap_pipe__WEBPACK_IMPORTED_MODULE_1__.LanguageMapPipe));
  }, this.ɵcmp = /*@__PURE__*/_angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵdefineComponent"]({
    type: JoinCompanyModalPage,
    selectors: [["app-join-company"]],
    standalone: false,
    features: [_angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵProvidersFeature"]([src_app_core_shared_pipes_languageMap_pipe__WEBPACK_IMPORTED_MODULE_1__.LanguageMapPipe])],
    decls: 46,
    vars: 39,
    consts: [["color", "playgo"], ["slot", "end"], [3, "click"], ["name", "close-circle-outline"], [3, "ngSubmit", "formGroup"], [1, "ion-margin-top", 3, "ngClass"], ["itemValueField", "code", "itemTextField", "name", "formControlName", "companySelected", "hasSearchText", "false", "headerColor", "playgo", "groupColor", "playgo", "modalCssClass", "modal-search-playgo", 3, "ngModelChange", "onSelect", "ngModel", "items", "searchFailText", "canSearch", "searchPlaceholder"], ["ionicSelectableTitleTemplate", ""], ["ionicSelectableCloseButtonTemplate", ""], ["ionicSelectableItemIconTemplate", ""], ["class", "error-message ion-padding", 4, "ngIf"], [1, "ion-margin-top"], ["size", "10"], ["position", "floating"], ["formControlName", "companyPIN", 3, "ngModelChange", "ngModel"], ["size", "2", 1, "info"], ["name", "information-circle-outline", 1, "popup-icon", 3, "click"], ["class", "ion-margin-top", 4, "ngIf"], ["color", "light", "type", "submit", "expand", "block"], ["name", "close-circle", 2, "font-size", "24px"], [3, "name", "color"], [1, "error-message", "ion-padding"], [1, "privacy-info"], [1, "ion-text-center", 3, "click"], ["name", "information-circle-outline", 1, "popup-icon"], ["slot", "start", "color", "playgo", "formControlName", "privacy"], [1, "ion-text-wrap"], ["slot", "start", "color", "playgo", "formControlName", "rules"]],
    template: function JoinCompanyModalPage_Template(rf, ctx) {
      if (rf & 1) {
        _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵelementStart"](0, "ion-header")(1, "ion-toolbar", 0)(2, "ion-title");
        _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵtext"](3);
        _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵpipe"](4, "languageMap");
        _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵpipe"](5, "translate");
        _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵelementStart"](6, "ion-buttons", 1)(7, "ion-button", 2);
        _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵlistener"]("click", function JoinCompanyModalPage_Template_ion_button_click_7_listener() {
          return ctx.close();
        });
        _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵelement"](8, "ion-icon", 3);
        _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵelementEnd"]()()()();
        _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵelementStart"](9, "ion-content", 0)(10, "form", 4);
        _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵlistener"]("ngSubmit", function JoinCompanyModalPage_Template_form_ngSubmit_10_listener() {
          return ctx.joinCompanySubmit();
        });
        _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵelementStart"](11, "ion-grid")(12, "ion-row", 5)(13, "ion-col")(14, "ion-item", 0)(15, "ion-label");
        _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵtext"](16);
        _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵpipe"](17, "translate");
        _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵelementStart"](18, "ionic-selectable", 6);
        _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵpipe"](19, "translate");
        _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵpipe"](20, "translate");
        _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵtwoWayListener"]("ngModelChange", function JoinCompanyModalPage_Template_ionic_selectable_ngModelChange_18_listener($event) {
          _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵtwoWayBindingSet"](ctx.companySelected, $event) || (ctx.companySelected = $event);
          return $event;
        });
        _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵlistener"]("onSelect", function JoinCompanyModalPage_Template_ionic_selectable_onSelect_18_listener($event) {
          return ctx.onSelect($event);
        });
        _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵtemplate"](21, JoinCompanyModalPage_ng_template_21_Template, 2, 3, "ng-template", 7)(22, JoinCompanyModalPage_ng_template_22_Template, 1, 0, "ng-template", 8)(23, JoinCompanyModalPage_ng_template_23_Template, 1, 2, "ng-template", 9);
        _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵelementEnd"]()()()();
        _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵtemplate"](24, JoinCompanyModalPage_div_24_Template, 3, 3, "div", 10);
        _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵelementStart"](25, "ion-row", 11)(26, "ion-col", 12)(27, "ion-item", 0)(28, "ion-label", 13);
        _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵtext"](29);
        _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵpipe"](30, "translate");
        _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵelementStart"](31, "ion-input", 14);
        _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵtwoWayListener"]("ngModelChange", function JoinCompanyModalPage_Template_ion_input_ngModelChange_31_listener($event) {
          _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵtwoWayBindingSet"](ctx.companyPIN, $event) || (ctx.companyPIN = $event);
          return $event;
        });
        _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵelementEnd"]()()();
        _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵelementStart"](32, "ion-col", 15)(33, "ion-icon", 16);
        _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵlistener"]("click", function JoinCompanyModalPage_Template_ion_icon_click_33_listener($event) {
          return ctx.openCodeInfoPopup($event);
        });
        _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵelementEnd"]()()();
        _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵtemplate"](34, JoinCompanyModalPage_div_34_Template, 3, 3, "div", 10)(35, JoinCompanyModalPage_ion_row_35_Template, 7, 3, "ion-row", 17)(36, JoinCompanyModalPage_ion_row_36_Template, 7, 3, "ion-row", 17)(37, JoinCompanyModalPage_div_37_Template, 3, 3, "div", 10)(38, JoinCompanyModalPage_ion_row_38_Template, 7, 3, "ion-row", 17)(39, JoinCompanyModalPage_ion_row_39_Template, 7, 3, "ion-row", 17)(40, JoinCompanyModalPage_div_40_Template, 3, 3, "div", 10);
        _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵelementStart"](41, "ion-row")(42, "ion-col")(43, "ion-button", 18);
        _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵtext"](44);
        _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵpipe"](45, "translate");
        _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵelementEnd"]()()()()()();
      }
      if (rf & 2) {
        _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵadvance"](3);
        _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵtextInterpolate"](_angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵpipeBind2"](5, 22, "campaigns.joinmodal.modalTitle", _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵpureFunction1"](35, _c0, _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵpipeBind1"](4, 20, ctx.campaign == null ? null : ctx.campaign.name))));
        _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵadvance"](7);
        _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵproperty"]("formGroup", ctx.joinCompanyForm);
        _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵadvance"](2);
        _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵproperty"]("ngClass", _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵpureFunction1"](37, _c1, ctx.hasOnlyOne));
        _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵadvance"](4);
        _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵtextInterpolate"](_angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵpipeBind1"](17, 25, "campaigns.joinmodal.companyselection"));
        _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵadvance"](2);
        _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵtwoWayProperty"]("ngModel", ctx.companySelected);
        _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵproperty"]("items", ctx.companies)("searchFailText", _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵpipeBind1"](19, 27, "campaigns.joinmodal.noItems"))("canSearch", true)("searchPlaceholder", _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵpipeBind1"](20, 29, "campaigns.joinmodal.search"));
        _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵadvance"](6);
        _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵproperty"]("ngIf", ctx.isSubmitted && (ctx.errorControl == null ? null : ctx.errorControl.companySelected == null ? null : ctx.errorControl.companySelected.errors));
        _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵadvance"](5);
        _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵtextInterpolate1"](" ", _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵpipeBind1"](30, 31, "campaigns.detail.companySubscribe"), " ");
        _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵadvance"](2);
        _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵtwoWayProperty"]("ngModel", ctx.companyPIN);
        _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵadvance"](3);
        _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵproperty"]("ngIf", ctx.isSubmitted && ctx.isSubmitted && (ctx.errorControl == null ? null : ctx.errorControl.companyPIN == null ? null : ctx.errorControl.companyPIN.errors));
        _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵadvance"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵproperty"]("ngIf", ctx.privacy);
        _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵadvance"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵproperty"]("ngIf", ctx.privacy);
        _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵadvance"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵproperty"]("ngIf", ctx.isSubmitted && (ctx.errorControl == null ? null : ctx.errorControl.privacy == null ? null : ctx.errorControl.privacy.errors));
        _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵadvance"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵproperty"]("ngIf", ctx.rules);
        _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵadvance"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵproperty"]("ngIf", ctx.rules);
        _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵadvance"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵproperty"]("ngIf", ctx.isSubmitted && (ctx.errorControl == null ? null : ctx.errorControl.rules == null ? null : ctx.errorControl.rules.errors));
        _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵadvance"](4);
        _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵtextInterpolate1"]("", _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵpipeBind1"](45, 33, "campaigns.joinmodal.confirm"), " ");
      }
    },
    dependencies: [_angular_common__WEBPACK_IMPORTED_MODULE_10__.NgClass, _angular_common__WEBPACK_IMPORTED_MODULE_10__.NgIf, _angular_forms__WEBPACK_IMPORTED_MODULE_0__["ɵNgNoValidate"], _angular_forms__WEBPACK_IMPORTED_MODULE_0__.NgControlStatus, _angular_forms__WEBPACK_IMPORTED_MODULE_0__.NgControlStatusGroup, _angular_forms__WEBPACK_IMPORTED_MODULE_0__.FormGroupDirective, _angular_forms__WEBPACK_IMPORTED_MODULE_0__.FormControlName, _ionic_angular__WEBPACK_IMPORTED_MODULE_4__.IonButton, _ionic_angular__WEBPACK_IMPORTED_MODULE_4__.IonButtons, _ionic_angular__WEBPACK_IMPORTED_MODULE_4__.IonCheckbox, _ionic_angular__WEBPACK_IMPORTED_MODULE_4__.IonCol, _ionic_angular__WEBPACK_IMPORTED_MODULE_4__.IonContent, _ionic_angular__WEBPACK_IMPORTED_MODULE_4__.IonGrid, _ionic_angular__WEBPACK_IMPORTED_MODULE_4__.IonHeader, _ionic_angular__WEBPACK_IMPORTED_MODULE_4__.IonIcon, _ionic_angular__WEBPACK_IMPORTED_MODULE_4__.IonInput, _ionic_angular__WEBPACK_IMPORTED_MODULE_4__.IonItem, _ionic_angular__WEBPACK_IMPORTED_MODULE_4__.IonLabel, _ionic_angular__WEBPACK_IMPORTED_MODULE_4__.IonRow, _ionic_angular__WEBPACK_IMPORTED_MODULE_4__.IonTitle, _ionic_angular__WEBPACK_IMPORTED_MODULE_4__.IonToolbar, _ionic_angular__WEBPACK_IMPORTED_MODULE_4__.BooleanValueAccessor, _ionic_angular__WEBPACK_IMPORTED_MODULE_4__.TextValueAccessor, ionic_selectable__WEBPACK_IMPORTED_MODULE_11__.IonicSelectableComponent, ionic_selectable__WEBPACK_IMPORTED_MODULE_11__.IonicSelectableCloseButtonTemplateDirective, ionic_selectable__WEBPACK_IMPORTED_MODULE_11__.IonicSelectableTitleTemplateDirective, _ngx_translate_core__WEBPACK_IMPORTED_MODULE_12__.TranslatePipe, src_app_core_shared_pipes_languageMap_pipe__WEBPACK_IMPORTED_MODULE_1__.LanguageMapPipe],
    styles: [".hide-company-selection[_ngcontent-%COMP%] {\n  height: 0px;\n  overflow: hidden;\n}\n\n.info[_ngcontent-%COMP%] {\n  display: flex;\n  align-items: center;\n  justify-content: center;\n  font-size: 26px;\n}\n/*# sourceMappingURL=data:application/json;charset=utf-8;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbIndlYnBhY2s6Ly8uL3NyYy9hcHAvcGFnZXMvY2FtcGFpZ25zL2NhbXBhaWduLWpvaW4vam9pbi1jb21wYW55L2pvaW4tY29tcGFueS5tb2RhbC5zY3NzIl0sIm5hbWVzIjpbXSwibWFwcGluZ3MiOiJBQUFBO0VBQ0UsV0FBQTtFQUNBLGdCQUFBO0FBQ0Y7O0FBQ0E7RUFDRSxhQUFBO0VBQ0EsbUJBQUE7RUFDQSx1QkFBQTtFQUNBLGVBQUE7QUFFRiIsInNvdXJjZXNDb250ZW50IjpbIi5oaWRlLWNvbXBhbnktc2VsZWN0aW9uIHtcbiAgaGVpZ2h0OiAwcHg7XG4gIG92ZXJmbG93OiBoaWRkZW47XG59XG4uaW5mbyB7XG4gIGRpc3BsYXk6IGZsZXg7XG4gIGFsaWduLWl0ZW1zOiBjZW50ZXI7XG4gIGp1c3RpZnktY29udGVudDogY2VudGVyO1xuICBmb250LXNpemU6IDI2cHg7XG59XG4vLyAubW9kYWwtc2VsZWN0YWJsZSB7XG4vLyAgIC5zZWFyY2hiYXItaW5wdXQge1xuLy8gICAgIGNvbG9yOiB3aGl0ZTtcbi8vICAgfVxuLy8gfVxuIl0sInNvdXJjZVJvb3QiOiIifQ== */"]
  }));
}
_staticBlock();

/***/ }),

/***/ 28751:
/*!**************************************************************************!*\
  !*** ./src/app/pages/home/campaign-details/detail-modal/detail.modal.ts ***!
  \**************************************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   DetailCampaignModalPage: () => (/* binding */ DetailCampaignModalPage)
/* harmony export */ });
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! @angular/core */ 12481);
/* harmony import */ var _ionic_angular__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @ionic/angular */ 21507);
var _staticBlock;


class DetailCampaignModalPage {
  constructor(modalController) {
    this.modalController = modalController;
    this.type = 'playgo';
  }
  ngOnInit() {}
  close() {
    this.modalController.dismiss(false);
  }
  static #_ = _staticBlock = () => (this.ɵfac = function DetailCampaignModalPage_Factory(__ngFactoryType__) {
    return new (__ngFactoryType__ || DetailCampaignModalPage)(_angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵdirectiveInject"](_ionic_angular__WEBPACK_IMPORTED_MODULE_1__.ModalController));
  }, this.ɵcmp = /*@__PURE__*/_angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵdefineComponent"]({
    type: DetailCampaignModalPage,
    selectors: [["app-detail-modal"]],
    standalone: false,
    decls: 9,
    vars: 3,
    consts: [[3, "color"], ["slot", "end"], [3, "click"], ["name", "close-circle-outline"], [1, "ion-padding"], [3, "innerHTML"]],
    template: function DetailCampaignModalPage_Template(rf, ctx) {
      if (rf & 1) {
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](0, "ion-header")(1, "ion-toolbar", 0)(2, "ion-title");
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵtext"](3);
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](4, "ion-buttons", 1)(5, "ion-button", 2);
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵlistener"]("click", function DetailCampaignModalPage_Template_ion_button_click_5_listener() {
          return ctx.close();
        });
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelement"](6, "ion-icon", 3);
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]()()()();
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](7, "ion-content", 4);
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelement"](8, "div", 5);
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();
      }
      if (rf & 2) {
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵadvance"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵproperty"]("color", ctx.type);
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵadvance"](2);
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵtextInterpolate"](ctx.detail == null ? null : ctx.detail.name);
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵadvance"](5);
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵproperty"]("innerHTML", ctx.detail == null ? null : ctx.detail.content, _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵsanitizeHtml"]);
      }
    },
    dependencies: [_ionic_angular__WEBPACK_IMPORTED_MODULE_1__.IonButton, _ionic_angular__WEBPACK_IMPORTED_MODULE_1__.IonButtons, _ionic_angular__WEBPACK_IMPORTED_MODULE_1__.IonContent, _ionic_angular__WEBPACK_IMPORTED_MODULE_1__.IonHeader, _ionic_angular__WEBPACK_IMPORTED_MODULE_1__.IonIcon, _ionic_angular__WEBPACK_IMPORTED_MODULE_1__.IonTitle, _ionic_angular__WEBPACK_IMPORTED_MODULE_1__.IonToolbar],
    styles: ["/*# sourceMappingURL=data:application/json;charset=utf-8;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbXSwibmFtZXMiOltdLCJtYXBwaW5ncyI6IiIsInNvdXJjZVJvb3QiOiIifQ== */"]
  }));
}
_staticBlock();

/***/ }),

/***/ 35691:
/*!*******************************************************************************!*\
  !*** ./src/app/pages/campaigns/campaign-join/campaign-join-routing.module.ts ***!
  \*******************************************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   CampaignJoinPageRoutingModule: () => (/* binding */ CampaignJoinPageRoutingModule)
/* harmony export */ });
/* harmony import */ var _angular_router__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! @angular/router */ 34487);
/* harmony import */ var _campaign_join_page__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ./campaign-join.page */ 53789);
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @angular/core */ 34205);
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @angular/core */ 12481);
var _staticBlock;




const routes = [{
  path: '',
  component: _campaign_join_page__WEBPACK_IMPORTED_MODULE_1__.CampaignJoinPage,
  data: {
    title: '',
    defaultHref: '/pages/tabs/campaigns'
  }
}];
class CampaignJoinPageRoutingModule {
  static #_ = _staticBlock = () => (this.ɵfac = function CampaignJoinPageRoutingModule_Factory(__ngFactoryType__) {
    return new (__ngFactoryType__ || CampaignJoinPageRoutingModule)();
  }, this.ɵmod = /*@__PURE__*/_angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵdefineNgModule"]({
    type: CampaignJoinPageRoutingModule
  }), this.ɵinj = /*@__PURE__*/_angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵdefineInjector"]({
    imports: [_angular_router__WEBPACK_IMPORTED_MODULE_0__.RouterModule.forChild(routes), _angular_router__WEBPACK_IMPORTED_MODULE_0__.RouterModule]
  }));
}
_staticBlock();
(function () {
  (typeof ngJitMode === "undefined" || ngJitMode) && _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵsetNgModuleScope"](CampaignJoinPageRoutingModule, {
    imports: [_angular_router__WEBPACK_IMPORTED_MODULE_0__.RouterModule],
    exports: [_angular_router__WEBPACK_IMPORTED_MODULE_0__.RouterModule]
  });
})();

/***/ }),

/***/ 52035:
/*!********************************************************************************!*\
  !*** ./src/app/pages/campaigns/campaign-join/join-school/join-school.modal.ts ***!
  \********************************************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   JoinSchoolModalPage: () => (/* binding */ JoinSchoolModalPage)
/* harmony export */ });
/* harmony import */ var _angular_forms__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! @angular/forms */ 34456);
/* harmony import */ var src_app_core_shared_services_error_service__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! src/app/core/shared/services/error.service */ 46078);
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @angular/core */ 34205);
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @angular/core */ 12481);
/* harmony import */ var _ionic_angular__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! @ionic/angular */ 21507);
/* harmony import */ var _ionic_angular__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! @ionic/angular */ 4059);
/* harmony import */ var src_app_core_shared_services_team_service__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! src/app/core/shared/services/team.service */ 62625);
/* harmony import */ var src_app_core_shared_services_alert_service__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(/*! src/app/core/shared/services/alert.service */ 67406);
/* harmony import */ var src_app_core_shared_services_campaign_service__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(/*! src/app/core/shared/services/campaign.service */ 76658);
/* harmony import */ var src_app_core_shared_services_user_service__WEBPACK_IMPORTED_MODULE_9__ = __webpack_require__(/*! src/app/core/shared/services/user.service */ 89815);
/* harmony import */ var _angular_common__WEBPACK_IMPORTED_MODULE_10__ = __webpack_require__(/*! @angular/common */ 93683);
/* harmony import */ var ionic_selectable__WEBPACK_IMPORTED_MODULE_11__ = __webpack_require__(/*! ionic-selectable */ 56885);
/* harmony import */ var _ngx_translate_core__WEBPACK_IMPORTED_MODULE_12__ = __webpack_require__(/*! @ngx-translate/core */ 48503);
/* harmony import */ var _core_shared_pipes_languageMap_pipe__WEBPACK_IMPORTED_MODULE_13__ = __webpack_require__(/*! ../../../../core/shared/pipes/languageMap.pipe */ 69618);
var _staticBlock;














const _c0 = a0 => ({
  campaignTitle: a0
});
function JoinSchoolModalPage_ng_template_20_Template(rf, ctx) {
  if (rf & 1) {
    _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵtext"](0);
    _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵpipe"](1, "translate");
  }
  if (rf & 2) {
    _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵtextInterpolate1"](" ", _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵpipeBind1"](1, 1, "campaigns.joinmodal.teams"), " ");
  }
}
function JoinSchoolModalPage_ng_template_21_Template(rf, ctx) {
  if (rf & 1) {
    _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵelement"](0, "ion-icon", 15);
  }
}
function JoinSchoolModalPage_ng_template_22_Template(rf, ctx) {
  if (rf & 1) {
    _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵelement"](0, "ion-icon", 16);
  }
  if (rf & 2) {
    const isPortSelected_r1 = ctx.isItemSelected;
    _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵproperty"]("name", isPortSelected_r1 ? "checkmark-circle" : "radio-button-off")("color", isPortSelected_r1 ? "light" : null);
  }
}
function JoinSchoolModalPage_ng_template_23_Template(rf, ctx) {
  if (rf & 1) {
    _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵelementStart"](0, "span", 17);
    _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵtext"](1);
    _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵelementEnd"]();
  }
  if (rf & 2) {
    const port_r2 = ctx.item;
    _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵadvance"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵtextInterpolate"](port_r2.customData.name);
  }
}
function JoinSchoolModalPage_ng_template_24_Template(rf, ctx) {
  if (rf & 1) {
    _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵelementStart"](0, "span");
    _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵtext"](1);
    _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵelementEnd"]();
  }
  if (rf & 2) {
    const port_r3 = ctx.value;
    _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵadvance"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵtextInterpolate"](port_r3.customData.name);
  }
}
function JoinSchoolModalPage_div_25_Template(rf, ctx) {
  if (rf & 1) {
    _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵelementStart"](0, "div", 18);
    _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵtext"](1);
    _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵpipe"](2, "translate");
    _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵelementEnd"]();
  }
  if (rf & 2) {
    _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵadvance"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵtextInterpolate1"](" ", _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵpipeBind1"](2, 1, "campaigns.joinmodal.companyRequired"), " ");
  }
}
function JoinSchoolModalPage_ion_row_26_Template(rf, ctx) {
  if (rf & 1) {
    const _r4 = _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵgetCurrentView"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵelementStart"](0, "ion-row", 5)(1, "ion-col", 19)(2, "ion-label", 20);
    _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵtext"](3);
    _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵpipe"](4, "translate");
    _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵelementEnd"]()();
    _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵelementStart"](5, "ion-col", 21);
    _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵlistener"]("click", function JoinSchoolModalPage_ion_row_26_Template_ion_col_click_5_listener() {
      _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵrestoreView"](_r4);
      const ctx_r4 = _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵnextContext"]();
      return _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵresetView"](ctx_r4.openPrivacyPopup());
    });
    _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵelement"](6, "ion-icon", 22);
    _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵelementEnd"]()();
  }
  if (rf & 2) {
    _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵadvance"](3);
    _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵtextInterpolate"](_angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵpipeBind1"](4, 1, "campaigns.joinmodal.privacyLink"));
  }
}
function JoinSchoolModalPage_ion_row_27_Template(rf, ctx) {
  if (rf & 1) {
    _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵelementStart"](0, "ion-row", 5)(1, "ion-col")(2, "ion-item", 0);
    _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵelement"](3, "ion-checkbox", 23);
    _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵelementStart"](4, "ion-label", 24);
    _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵtext"](5);
    _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵpipe"](6, "translate");
    _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵelementEnd"]()()()();
  }
  if (rf & 2) {
    _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵadvance"](5);
    _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵtextInterpolate"](_angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵpipeBind1"](6, 1, "campaigns.joinmodal.privacy"));
  }
}
function JoinSchoolModalPage_div_28_Template(rf, ctx) {
  if (rf & 1) {
    _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵelementStart"](0, "div", 18)(1, "span");
    _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵtext"](2);
    _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵpipe"](3, "translate");
    _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵelementEnd"]()();
  }
  if (rf & 2) {
    _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵadvance"](2);
    _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵtextInterpolate"](_angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵpipeBind1"](3, 1, "campaigns.joinmodal.privacyRequired"));
  }
}
function JoinSchoolModalPage_ion_row_29_Template(rf, ctx) {
  if (rf & 1) {
    const _r6 = _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵgetCurrentView"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵelementStart"](0, "ion-row", 5)(1, "ion-col", 19)(2, "ion-label", 20);
    _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵtext"](3);
    _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵpipe"](4, "translate");
    _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵelementEnd"]()();
    _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵelementStart"](5, "ion-col", 21);
    _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵlistener"]("click", function JoinSchoolModalPage_ion_row_29_Template_ion_col_click_5_listener() {
      _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵrestoreView"](_r6);
      const ctx_r4 = _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵnextContext"]();
      return _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵresetView"](ctx_r4.openRulesPopup());
    });
    _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵelement"](6, "ion-icon", 22);
    _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵelementEnd"]()();
  }
  if (rf & 2) {
    _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵadvance"](3);
    _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵtextInterpolate"](_angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵpipeBind1"](4, 1, "campaigns.joinmodal.rulesLink"));
  }
}
function JoinSchoolModalPage_ion_row_30_Template(rf, ctx) {
  if (rf & 1) {
    _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵelementStart"](0, "ion-row", 5)(1, "ion-col")(2, "ion-item", 0);
    _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵelement"](3, "ion-checkbox", 25);
    _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵelementStart"](4, "ion-label", 24);
    _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵtext"](5);
    _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵpipe"](6, "translate");
    _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵelementEnd"]()()()();
  }
  if (rf & 2) {
    _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵadvance"](5);
    _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵtextInterpolate"](_angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵpipeBind1"](6, 1, "campaigns.joinmodal.rules"));
  }
}
function JoinSchoolModalPage_div_31_Template(rf, ctx) {
  if (rf & 1) {
    _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵelementStart"](0, "div", 18)(1, "span");
    _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵtext"](2);
    _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵpipe"](3, "translate");
    _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵelementEnd"]()();
  }
  if (rf & 2) {
    _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵadvance"](2);
    _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵtextInterpolate"](_angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵpipeBind1"](3, 1, "campaigns.joinmodal.rulesRequired"));
  }
}
class JoinSchoolModalPage {
  constructor(modalController, teamService, errorService, alertService, campaignService, formBuilder, userService, navCtrl, elementRef) {
    this.modalController = modalController;
    this.teamService = teamService;
    this.errorService = errorService;
    this.alertService = alertService;
    this.campaignService = campaignService;
    this.formBuilder = formBuilder;
    this.userService = userService;
    this.navCtrl = navCtrl;
    this.elementRef = elementRef;
    this.isSubmitted = false;
  }
  ngOnInit() {
    this.language = this.userService.getLanguage();
    const rules = this.campaign.details[this.language];
    this.rules = rules?.find(detail => detail.type === 'rules');
    this.privacy = rules?.find(detail => detail.type === 'privacy');
    this.joinSchoolForm = this.formBuilder.group({
      teamSelected: ['', [_angular_forms__WEBPACK_IMPORTED_MODULE_0__.Validators.required]],
      ...(this.privacy && {
        privacy: [false, _angular_forms__WEBPACK_IMPORTED_MODULE_0__.Validators.requiredTrue]
      }),
      ...(this.rules && {
        rules: [false, _angular_forms__WEBPACK_IMPORTED_MODULE_0__.Validators.requiredTrue]
      })
    });
    this.sub = this.teamService.getTeamsForSubscription(this.campaign.campaignId).subscribe(result => {
      if (result) {
        this.teams = result.map(t => ({
          ...t,
          displayName: t.customData?.name
        }));
      }
    });
  }
  ngOnDestroy() {
    this.sub.unsubscribe();
  }
  //computed errorcontrol
  get errorControl() {
    return this.joinSchoolForm.controls;
  }
  close() {
    this.modalController.dismiss(false);
  }
  openPrivacyPopup() {
    this.alertService.presentAlert({
      headerTranslateKey: 'campaigns.joinmodal.privacyPopup.header',
      messageString: this.privacy.content,
      cssClass: 'modalJoin'
    });
  }
  openRulesPopup() {
    this.alertService.presentAlert({
      headerTranslateKey: 'campaigns.joinmodal.rulesPopup.header',
      messageString: this.rules.content,
      cssClass: 'modalJoin'
    });
  }
  openCodeInfoPopup() {
    this.alertService.presentAlert({
      headerTranslateKey: 'campaigns.joinmodal.codeInfo.header',
      messageString: 'campaigns.joinmodal.codeInfo.message',
      cssClass: 'modalConfirm'
    });
  }
  joinSchoolSubmit() {
    // call join with all params
    this.isSubmitted = true;
    if (!this.joinSchoolForm.valid) {
      return false;
    } else {
      const body = {
        teamId: this.teamSelected.id
      };
      this.campaignService.subscribeToCampaign(this.campaign.campaignId, body).subscribe(result => {
        if (result) {
          this.alertService.showToast({
            messageTranslateKey: 'campaigns.registered'
          });
          this.modalController.dismiss(true);
          this.navCtrl.navigateRoot('/pages/tabs/home');
        }
      }, err => {
        const error = new src_app_core_shared_services_error_service__WEBPACK_IMPORTED_MODULE_1__.UserError({
          id: 'ERROR_TEAM',
          message: 'campaigns.joinmodal.error.ERROR_TEAM'
        });
        this.errorService.handleError(error);
      });
    }
  }
  onSelect(event) {
    console.log('item' + JSON.stringify(event.item) + 'isSelected' + event.isSelected);
  }
  static #_ = _staticBlock = () => (this.ɵfac = function JoinSchoolModalPage_Factory(__ngFactoryType__) {
    return new (__ngFactoryType__ || JoinSchoolModalPage)(_angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵdirectiveInject"](_ionic_angular__WEBPACK_IMPORTED_MODULE_4__.ModalController), _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵdirectiveInject"](src_app_core_shared_services_team_service__WEBPACK_IMPORTED_MODULE_6__.TeamService), _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵdirectiveInject"](src_app_core_shared_services_error_service__WEBPACK_IMPORTED_MODULE_1__.ErrorService), _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵdirectiveInject"](src_app_core_shared_services_alert_service__WEBPACK_IMPORTED_MODULE_7__.AlertService), _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵdirectiveInject"](src_app_core_shared_services_campaign_service__WEBPACK_IMPORTED_MODULE_8__.CampaignService), _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵdirectiveInject"](_angular_forms__WEBPACK_IMPORTED_MODULE_0__.FormBuilder), _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵdirectiveInject"](src_app_core_shared_services_user_service__WEBPACK_IMPORTED_MODULE_9__.UserService), _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵdirectiveInject"](_ionic_angular__WEBPACK_IMPORTED_MODULE_5__.NavController), _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵdirectiveInject"](_angular_core__WEBPACK_IMPORTED_MODULE_3__.ElementRef));
  }, this.ɵcmp = /*@__PURE__*/_angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵdefineComponent"]({
    type: JoinSchoolModalPage,
    selectors: [["app-join-school"]],
    standalone: false,
    decls: 37,
    vars: 28,
    consts: [["color", "playgo"], ["slot", "end"], [3, "click"], ["name", "close-circle-outline"], [3, "ngSubmit", "formGroup"], [1, "ion-margin-top"], ["itemValueField", "id", "itemTextField", "displayName", "formControlName", "teamSelected", "hasSearchText", "false", "headerColor", "playgo", "groupColor", "playgo", "modalCssClass", "modal-search-playgo", 3, "ngModelChange", "onSelect", "ngModel", "items", "searchFailText", "canSearch"], ["ionicSelectableTitleTemplate", ""], ["ionicSelectableCloseButtonTemplate", ""], ["ionicSelectableItemIconTemplate", ""], ["ionicSelectableItemTemplate", ""], ["ionicSelectableValueTemplate", ""], ["class", "error-message ion-padding", 4, "ngIf"], ["class", "ion-margin-top", 4, "ngIf"], ["color", "light", "type", "submit", "expand", "block"], ["name", "close-circle", 2, "font-size", "24px"], [3, "name", "color"], [2, "width", "100%"], [1, "error-message", "ion-padding"], ["size", "10"], [1, "privacy-info"], [1, "ion-text-center", 3, "click"], ["name", "information-circle-outline", 1, "popup-icon"], ["slot", "start", "color", "playgo", "formControlName", "privacy"], [1, "ion-text-wrap"], ["slot", "start", "color", "playgo", "formControlName", "rules"]],
    template: function JoinSchoolModalPage_Template(rf, ctx) {
      if (rf & 1) {
        _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵelementStart"](0, "ion-header")(1, "ion-toolbar", 0)(2, "ion-title");
        _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵtext"](3);
        _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵpipe"](4, "languageMap");
        _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵpipe"](5, "translate");
        _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵelementStart"](6, "ion-buttons", 1)(7, "ion-button", 2);
        _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵlistener"]("click", function JoinSchoolModalPage_Template_ion_button_click_7_listener() {
          return ctx.close();
        });
        _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵelement"](8, "ion-icon", 3);
        _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵelementEnd"]()()()();
        _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵelementStart"](9, "ion-content", 0)(10, "form", 4);
        _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵlistener"]("ngSubmit", function JoinSchoolModalPage_Template_form_ngSubmit_10_listener() {
          return ctx.joinSchoolSubmit();
        });
        _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵelementStart"](11, "ion-grid")(12, "ion-row", 5)(13, "ion-col")(14, "ion-item", 0)(15, "ion-label");
        _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵtext"](16);
        _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵpipe"](17, "translate");
        _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵelementStart"](18, "ionic-selectable", 6);
        _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵpipe"](19, "translate");
        _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵtwoWayListener"]("ngModelChange", function JoinSchoolModalPage_Template_ionic_selectable_ngModelChange_18_listener($event) {
          _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵtwoWayBindingSet"](ctx.teamSelected, $event) || (ctx.teamSelected = $event);
          return $event;
        });
        _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵlistener"]("onSelect", function JoinSchoolModalPage_Template_ionic_selectable_onSelect_18_listener($event) {
          return ctx.onSelect($event);
        });
        _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵtemplate"](20, JoinSchoolModalPage_ng_template_20_Template, 2, 3, "ng-template", 7)(21, JoinSchoolModalPage_ng_template_21_Template, 1, 0, "ng-template", 8)(22, JoinSchoolModalPage_ng_template_22_Template, 1, 2, "ng-template", 9)(23, JoinSchoolModalPage_ng_template_23_Template, 2, 1, "ng-template", 10)(24, JoinSchoolModalPage_ng_template_24_Template, 2, 1, "ng-template", 11);
        _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵelementEnd"]()()()();
        _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵtemplate"](25, JoinSchoolModalPage_div_25_Template, 3, 3, "div", 12)(26, JoinSchoolModalPage_ion_row_26_Template, 7, 3, "ion-row", 13)(27, JoinSchoolModalPage_ion_row_27_Template, 7, 3, "ion-row", 13)(28, JoinSchoolModalPage_div_28_Template, 4, 3, "div", 12)(29, JoinSchoolModalPage_ion_row_29_Template, 7, 3, "ion-row", 13)(30, JoinSchoolModalPage_ion_row_30_Template, 7, 3, "ion-row", 13)(31, JoinSchoolModalPage_div_31_Template, 4, 3, "div", 12);
        _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵelementStart"](32, "ion-row")(33, "ion-col")(34, "ion-button", 14);
        _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵtext"](35);
        _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵpipe"](36, "translate");
        _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵelementEnd"]()()()()()();
      }
      if (rf & 2) {
        _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵadvance"](3);
        _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵtextInterpolate"](_angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵpipeBind2"](5, 17, "campaigns.joinmodal.modalTitle", _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵpureFunction1"](26, _c0, _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵpipeBind1"](4, 15, ctx.campaign == null ? null : ctx.campaign.name))));
        _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵadvance"](7);
        _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵproperty"]("formGroup", ctx.joinSchoolForm);
        _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵadvance"](6);
        _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵtextInterpolate"](_angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵpipeBind1"](17, 20, "campaigns.joinmodal.teamselection"));
        _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵadvance"](2);
        _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵtwoWayProperty"]("ngModel", ctx.teamSelected);
        _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵproperty"]("items", ctx.teams)("searchFailText", _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵpipeBind1"](19, 22, "campaigns.joinmodal.noItems"))("canSearch", true);
        _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵadvance"](7);
        _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵproperty"]("ngIf", ctx.isSubmitted && (ctx.errorControl == null ? null : ctx.errorControl.teamSelected == null ? null : ctx.errorControl.teamSelected.errors));
        _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵadvance"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵproperty"]("ngIf", ctx.privacy);
        _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵadvance"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵproperty"]("ngIf", ctx.privacy);
        _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵadvance"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵproperty"]("ngIf", ctx.isSubmitted && (ctx.errorControl == null ? null : ctx.errorControl.privacy == null ? null : ctx.errorControl.privacy.errors));
        _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵadvance"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵproperty"]("ngIf", ctx.rules);
        _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵadvance"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵproperty"]("ngIf", ctx.rules);
        _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵadvance"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵproperty"]("ngIf", ctx.isSubmitted && (ctx.errorControl == null ? null : ctx.errorControl.rules == null ? null : ctx.errorControl.rules.errors));
        _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵadvance"](4);
        _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵtextInterpolate1"]("", _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵpipeBind1"](36, 24, "campaigns.joinmodal.confirm"), " ");
      }
    },
    dependencies: [_angular_common__WEBPACK_IMPORTED_MODULE_10__.NgIf, _angular_forms__WEBPACK_IMPORTED_MODULE_0__["ɵNgNoValidate"], _angular_forms__WEBPACK_IMPORTED_MODULE_0__.NgControlStatus, _angular_forms__WEBPACK_IMPORTED_MODULE_0__.NgControlStatusGroup, _angular_forms__WEBPACK_IMPORTED_MODULE_0__.FormGroupDirective, _angular_forms__WEBPACK_IMPORTED_MODULE_0__.FormControlName, _ionic_angular__WEBPACK_IMPORTED_MODULE_4__.IonButton, _ionic_angular__WEBPACK_IMPORTED_MODULE_4__.IonButtons, _ionic_angular__WEBPACK_IMPORTED_MODULE_4__.IonCheckbox, _ionic_angular__WEBPACK_IMPORTED_MODULE_4__.IonCol, _ionic_angular__WEBPACK_IMPORTED_MODULE_4__.IonContent, _ionic_angular__WEBPACK_IMPORTED_MODULE_4__.IonGrid, _ionic_angular__WEBPACK_IMPORTED_MODULE_4__.IonHeader, _ionic_angular__WEBPACK_IMPORTED_MODULE_4__.IonIcon, _ionic_angular__WEBPACK_IMPORTED_MODULE_4__.IonItem, _ionic_angular__WEBPACK_IMPORTED_MODULE_4__.IonLabel, _ionic_angular__WEBPACK_IMPORTED_MODULE_4__.IonRow, _ionic_angular__WEBPACK_IMPORTED_MODULE_4__.IonTitle, _ionic_angular__WEBPACK_IMPORTED_MODULE_4__.IonToolbar, _ionic_angular__WEBPACK_IMPORTED_MODULE_4__.BooleanValueAccessor, ionic_selectable__WEBPACK_IMPORTED_MODULE_11__.IonicSelectableComponent, ionic_selectable__WEBPACK_IMPORTED_MODULE_11__.IonicSelectableItemTemplateDirective, ionic_selectable__WEBPACK_IMPORTED_MODULE_11__.IonicSelectableValueTemplateDirective, ionic_selectable__WEBPACK_IMPORTED_MODULE_11__.IonicSelectableCloseButtonTemplateDirective, ionic_selectable__WEBPACK_IMPORTED_MODULE_11__.IonicSelectableTitleTemplateDirective, _ngx_translate_core__WEBPACK_IMPORTED_MODULE_12__.TranslatePipe, _core_shared_pipes_languageMap_pipe__WEBPACK_IMPORTED_MODULE_13__.LanguageMapPipe],
    styles: ["/*# sourceMappingURL=data:application/json;charset=utf-8;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbXSwibmFtZXMiOltdLCJtYXBwaW5ncyI6IiIsInNvdXJjZVJvb3QiOiIifQ== */"]
  }));
}
_staticBlock();

/***/ }),

/***/ 53789:
/*!*********************************************************************!*\
  !*** ./src/app/pages/campaigns/campaign-join/campaign-join.page.ts ***!
  \*********************************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   CampaignJoinPage: () => (/* binding */ CampaignJoinPage)
/* harmony export */ });
/* harmony import */ var _Users_smartcommunitylab_Desktop_newWork_playAndGo_playGo_node_modules_babel_runtime_helpers_esm_asyncToGenerator_js__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./node_modules/@babel/runtime/helpers/esm/asyncToGenerator.js */ 89204);
/* harmony import */ var luxon__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! luxon */ 45967);
/* harmony import */ var rxjs__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! rxjs */ 19999);
/* harmony import */ var _home_campaign_details_companies_modal_companies_modal__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! ../../home/campaign-details/companies-modal/companies.modal */ 6167);
/* harmony import */ var _home_campaign_details_detail_modal_detail_modal__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! ../../home/campaign-details/detail-modal/detail.modal */ 28751);
/* harmony import */ var _join_city_join_city_modal__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! ./join-city/join-city.modal */ 86591);
/* harmony import */ var _join_company_join_company_modal__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! ./join-company/join-company.modal */ 25749);
/* harmony import */ var _join_school_join_school_modal__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(/*! ./join-school/join-school.modal */ 52035);
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(/*! @angular/core */ 34205);
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_9__ = __webpack_require__(/*! @angular/core */ 12481);
/* harmony import */ var _angular_router__WEBPACK_IMPORTED_MODULE_10__ = __webpack_require__(/*! @angular/router */ 85422);
/* harmony import */ var src_app_core_shared_services_campaign_service__WEBPACK_IMPORTED_MODULE_11__ = __webpack_require__(/*! src/app/core/shared/services/campaign.service */ 76658);
/* harmony import */ var src_app_core_shared_services_alert_service__WEBPACK_IMPORTED_MODULE_12__ = __webpack_require__(/*! src/app/core/shared/services/alert.service */ 67406);
/* harmony import */ var _ionic_angular__WEBPACK_IMPORTED_MODULE_13__ = __webpack_require__(/*! @ionic/angular */ 4059);
/* harmony import */ var _ionic_angular__WEBPACK_IMPORTED_MODULE_14__ = __webpack_require__(/*! @ionic/angular */ 21507);
/* harmony import */ var src_app_core_shared_services_user_service__WEBPACK_IMPORTED_MODULE_15__ = __webpack_require__(/*! src/app/core/shared/services/user.service */ 89815);
/* harmony import */ var src_app_core_shared_services_page_settings_service__WEBPACK_IMPORTED_MODULE_16__ = __webpack_require__(/*! src/app/core/shared/services/page-settings.service */ 40147);
/* harmony import */ var src_app_core_api_generated_hsc_controllers_playerTeamController_service__WEBPACK_IMPORTED_MODULE_17__ = __webpack_require__(/*! src/app/core/api/generated-hsc/controllers/playerTeamController.service */ 40459);
/* harmony import */ var _angular_common__WEBPACK_IMPORTED_MODULE_18__ = __webpack_require__(/*! @angular/common */ 93683);
/* harmony import */ var _core_shared_layout_header_header_directive__WEBPACK_IMPORTED_MODULE_19__ = __webpack_require__(/*! ../../../core/shared/layout/header/header.directive */ 85039);
/* harmony import */ var _core_shared_layout_content_content_directive__WEBPACK_IMPORTED_MODULE_20__ = __webpack_require__(/*! ../../../core/shared/layout/content/content.directive */ 75855);
/* harmony import */ var _core_shared_directives_parallax_header_directive__WEBPACK_IMPORTED_MODULE_21__ = __webpack_require__(/*! ../../../core/shared/directives/parallax-header.directive */ 56195);
/* harmony import */ var _ngx_translate_core__WEBPACK_IMPORTED_MODULE_22__ = __webpack_require__(/*! @ngx-translate/core */ 48503);
/* harmony import */ var _core_shared_pipes_localDate_pipe__WEBPACK_IMPORTED_MODULE_23__ = __webpack_require__(/*! ../../../core/shared/pipes/localDate.pipe */ 86451);
/* harmony import */ var _core_shared_pipes_languageMap_pipe__WEBPACK_IMPORTED_MODULE_24__ = __webpack_require__(/*! ../../../core/shared/pipes/languageMap.pipe */ 69618);

var _staticBlock;






















function CampaignJoinPage_ng_container_0_ion_button_8_Template(rf, ctx) {
  if (rf & 1) {
    const _r2 = _angular_core__WEBPACK_IMPORTED_MODULE_9__["ɵɵgetCurrentView"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_9__["ɵɵelementStart"](0, "ion-button", 18);
    _angular_core__WEBPACK_IMPORTED_MODULE_9__["ɵɵlistener"]("click", function CampaignJoinPage_ng_container_0_ion_button_8_Template_ion_button_click_0_listener() {
      _angular_core__WEBPACK_IMPORTED_MODULE_8__["ɵɵrestoreView"](_r2);
      const ctx_r2 = _angular_core__WEBPACK_IMPORTED_MODULE_9__["ɵɵnextContext"](2);
      return _angular_core__WEBPACK_IMPORTED_MODULE_8__["ɵɵresetView"](ctx_r2.joinCampaign(ctx_r2.campaign));
    });
    _angular_core__WEBPACK_IMPORTED_MODULE_9__["ɵɵtext"](1);
    _angular_core__WEBPACK_IMPORTED_MODULE_9__["ɵɵpipe"](2, "translate");
    _angular_core__WEBPACK_IMPORTED_MODULE_9__["ɵɵelementEnd"]();
  }
  if (rf & 2) {
    const ctx_r2 = _angular_core__WEBPACK_IMPORTED_MODULE_9__["ɵɵnextContext"](2);
    _angular_core__WEBPACK_IMPORTED_MODULE_9__["ɵɵproperty"]("disabled", ctx_r2.campaignNotStarted(ctx_r2.campaign) || !ctx_r2.canSubscribe);
    _angular_core__WEBPACK_IMPORTED_MODULE_9__["ɵɵadvance"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_9__["ɵɵtextInterpolate1"](" ", _angular_core__WEBPACK_IMPORTED_MODULE_9__["ɵɵpipeBind1"](2, 2, "campaigns.join"), " ");
  }
}
function CampaignJoinPage_ng_container_0_div_10_span_1_Template(rf, ctx) {
  if (rf & 1) {
    _angular_core__WEBPACK_IMPORTED_MODULE_9__["ɵɵelementStart"](0, "span");
    _angular_core__WEBPACK_IMPORTED_MODULE_9__["ɵɵtext"](1);
    _angular_core__WEBPACK_IMPORTED_MODULE_9__["ɵɵpipe"](2, "translate");
    _angular_core__WEBPACK_IMPORTED_MODULE_9__["ɵɵelementEnd"]();
  }
  if (rf & 2) {
    _angular_core__WEBPACK_IMPORTED_MODULE_9__["ɵɵadvance"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_9__["ɵɵtextInterpolate"](_angular_core__WEBPACK_IMPORTED_MODULE_9__["ɵɵpipeBind1"](2, 1, "campaigns.notStartedHSC"));
  }
}
function CampaignJoinPage_ng_container_0_div_10_ng_template_2_Template(rf, ctx) {
  if (rf & 1) {
    _angular_core__WEBPACK_IMPORTED_MODULE_9__["ɵɵelementStart"](0, "span");
    _angular_core__WEBPACK_IMPORTED_MODULE_9__["ɵɵtext"](1);
    _angular_core__WEBPACK_IMPORTED_MODULE_9__["ɵɵpipe"](2, "translate");
    _angular_core__WEBPACK_IMPORTED_MODULE_9__["ɵɵelementEnd"]();
  }
  if (rf & 2) {
    _angular_core__WEBPACK_IMPORTED_MODULE_9__["ɵɵadvance"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_9__["ɵɵtextInterpolate"](_angular_core__WEBPACK_IMPORTED_MODULE_9__["ɵɵpipeBind1"](2, 1, "campaigns.notStarted"));
  }
}
function CampaignJoinPage_ng_container_0_div_10_Template(rf, ctx) {
  if (rf & 1) {
    _angular_core__WEBPACK_IMPORTED_MODULE_9__["ɵɵelementStart"](0, "div");
    _angular_core__WEBPACK_IMPORTED_MODULE_9__["ɵɵtemplate"](1, CampaignJoinPage_ng_container_0_div_10_span_1_Template, 3, 3, "span", 10)(2, CampaignJoinPage_ng_container_0_div_10_ng_template_2_Template, 3, 3, "ng-template", null, 1, _angular_core__WEBPACK_IMPORTED_MODULE_9__["ɵɵtemplateRefExtractor"]);
    _angular_core__WEBPACK_IMPORTED_MODULE_9__["ɵɵelementEnd"]();
  }
  if (rf & 2) {
    const notHsc_r4 = _angular_core__WEBPACK_IMPORTED_MODULE_9__["ɵɵreference"](3);
    const ctx_r2 = _angular_core__WEBPACK_IMPORTED_MODULE_9__["ɵɵnextContext"](2);
    _angular_core__WEBPACK_IMPORTED_MODULE_9__["ɵɵadvance"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_9__["ɵɵproperty"]("ngIf", ctx_r2.isSchool())("ngIfElse", notHsc_r4);
  }
}
function CampaignJoinPage_ng_container_0_ng_template_11_span_0_Template(rf, ctx) {
  if (rf & 1) {
    _angular_core__WEBPACK_IMPORTED_MODULE_9__["ɵɵelement"](0, "span", 20);
    _angular_core__WEBPACK_IMPORTED_MODULE_9__["ɵɵpipe"](1, "translate");
  }
  if (rf & 2) {
    _angular_core__WEBPACK_IMPORTED_MODULE_9__["ɵɵproperty"]("innerHTML", _angular_core__WEBPACK_IMPORTED_MODULE_9__["ɵɵpipeBind1"](1, 1, "campaigns.cantSubscribe"), _angular_core__WEBPACK_IMPORTED_MODULE_9__["ɵɵsanitizeHtml"]);
  }
}
function CampaignJoinPage_ng_container_0_ng_template_11_Template(rf, ctx) {
  if (rf & 1) {
    _angular_core__WEBPACK_IMPORTED_MODULE_9__["ɵɵtemplate"](0, CampaignJoinPage_ng_container_0_ng_template_11_span_0_Template, 2, 3, "span", 19);
  }
  if (rf & 2) {
    const ctx_r2 = _angular_core__WEBPACK_IMPORTED_MODULE_9__["ɵɵnextContext"](2);
    _angular_core__WEBPACK_IMPORTED_MODULE_9__["ɵɵproperty"]("ngIf", !ctx_r2.canSubscribe);
  }
}
function CampaignJoinPage_ng_container_0_div_15_Template(rf, ctx) {
  if (rf & 1) {
    _angular_core__WEBPACK_IMPORTED_MODULE_9__["ɵɵelementStart"](0, "div");
    _angular_core__WEBPACK_IMPORTED_MODULE_9__["ɵɵelement"](1, "div", 20);
    _angular_core__WEBPACK_IMPORTED_MODULE_9__["ɵɵpipe"](2, "languageMap");
    _angular_core__WEBPACK_IMPORTED_MODULE_9__["ɵɵelementEnd"]();
  }
  if (rf & 2) {
    let tmp_3_0;
    const ctx_r2 = _angular_core__WEBPACK_IMPORTED_MODULE_9__["ɵɵnextContext"](2);
    _angular_core__WEBPACK_IMPORTED_MODULE_9__["ɵɵadvance"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_9__["ɵɵproperty"]("innerHTML", (tmp_3_0 = ctx_r2.getCampaignSponsor(_angular_core__WEBPACK_IMPORTED_MODULE_9__["ɵɵpipeBind1"](2, 1, ctx_r2.campaign == null ? null : ctx_r2.campaign.details))) == null ? null : tmp_3_0.content, _angular_core__WEBPACK_IMPORTED_MODULE_9__["ɵɵsanitizeHtml"]);
  }
}
function CampaignJoinPage_ng_container_0_ion_icon_35_Template(rf, ctx) {
  if (rf & 1) {
    _angular_core__WEBPACK_IMPORTED_MODULE_9__["ɵɵelement"](0, "ion-icon", 21);
  }
}
function CampaignJoinPage_ng_container_0_ion_icon_36_Template(rf, ctx) {
  if (rf & 1) {
    _angular_core__WEBPACK_IMPORTED_MODULE_9__["ɵɵelement"](0, "ion-icon", 22);
  }
}
function CampaignJoinPage_ng_container_0_div_37_ng_container_1_div_1_Template(rf, ctx) {
  if (rf & 1) {
    const _r5 = _angular_core__WEBPACK_IMPORTED_MODULE_9__["ɵɵgetCurrentView"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_9__["ɵɵelementStart"](0, "div", 25);
    _angular_core__WEBPACK_IMPORTED_MODULE_9__["ɵɵlistener"]("click", function CampaignJoinPage_ng_container_0_div_37_ng_container_1_div_1_Template_div_click_0_listener() {
      _angular_core__WEBPACK_IMPORTED_MODULE_8__["ɵɵrestoreView"](_r5);
      const detail_r6 = _angular_core__WEBPACK_IMPORTED_MODULE_9__["ɵɵnextContext"]().$implicit;
      const ctx_r2 = _angular_core__WEBPACK_IMPORTED_MODULE_9__["ɵɵnextContext"](3);
      return _angular_core__WEBPACK_IMPORTED_MODULE_8__["ɵɵresetView"](ctx_r2.openDetail(detail_r6));
    });
    _angular_core__WEBPACK_IMPORTED_MODULE_9__["ɵɵelementStart"](1, "ion-item", 26)(2, "ion-label")(3, "span", 27);
    _angular_core__WEBPACK_IMPORTED_MODULE_9__["ɵɵtext"](4);
    _angular_core__WEBPACK_IMPORTED_MODULE_9__["ɵɵelementEnd"]()();
    _angular_core__WEBPACK_IMPORTED_MODULE_9__["ɵɵelement"](5, "ion-icon", 28);
    _angular_core__WEBPACK_IMPORTED_MODULE_9__["ɵɵelementEnd"]()();
  }
  if (rf & 2) {
    const detail_r6 = _angular_core__WEBPACK_IMPORTED_MODULE_9__["ɵɵnextContext"]().$implicit;
    _angular_core__WEBPACK_IMPORTED_MODULE_9__["ɵɵadvance"](4);
    _angular_core__WEBPACK_IMPORTED_MODULE_9__["ɵɵtextInterpolate1"](" ", detail_r6.name);
  }
}
function CampaignJoinPage_ng_container_0_div_37_ng_container_1_Template(rf, ctx) {
  if (rf & 1) {
    _angular_core__WEBPACK_IMPORTED_MODULE_9__["ɵɵelementContainerStart"](0);
    _angular_core__WEBPACK_IMPORTED_MODULE_9__["ɵɵtemplate"](1, CampaignJoinPage_ng_container_0_div_37_ng_container_1_div_1_Template, 6, 1, "div", 24);
    _angular_core__WEBPACK_IMPORTED_MODULE_9__["ɵɵelementContainerEnd"]();
  }
  if (rf & 2) {
    const detail_r6 = ctx.$implicit;
    _angular_core__WEBPACK_IMPORTED_MODULE_9__["ɵɵadvance"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_9__["ɵɵproperty"]("ngIf", detail_r6.type !== "sponsor");
  }
}
function CampaignJoinPage_ng_container_0_div_37_div_2_Template(rf, ctx) {
  if (rf & 1) {
    const _r7 = _angular_core__WEBPACK_IMPORTED_MODULE_9__["ɵɵgetCurrentView"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_9__["ɵɵelementStart"](0, "div")(1, "ion-item", 29);
    _angular_core__WEBPACK_IMPORTED_MODULE_9__["ɵɵlistener"]("click", function CampaignJoinPage_ng_container_0_div_37_div_2_Template_ion_item_click_1_listener() {
      _angular_core__WEBPACK_IMPORTED_MODULE_8__["ɵɵrestoreView"](_r7);
      const ctx_r2 = _angular_core__WEBPACK_IMPORTED_MODULE_9__["ɵɵnextContext"](3);
      return _angular_core__WEBPACK_IMPORTED_MODULE_8__["ɵɵresetView"](ctx_r2.openCompanies());
    });
    _angular_core__WEBPACK_IMPORTED_MODULE_9__["ɵɵelementStart"](2, "ion-label")(3, "span", 27);
    _angular_core__WEBPACK_IMPORTED_MODULE_9__["ɵɵtext"](4);
    _angular_core__WEBPACK_IMPORTED_MODULE_9__["ɵɵpipe"](5, "translate");
    _angular_core__WEBPACK_IMPORTED_MODULE_9__["ɵɵelementEnd"]()();
    _angular_core__WEBPACK_IMPORTED_MODULE_9__["ɵɵelement"](6, "ion-icon", 28);
    _angular_core__WEBPACK_IMPORTED_MODULE_9__["ɵɵelementEnd"]()();
  }
  if (rf & 2) {
    _angular_core__WEBPACK_IMPORTED_MODULE_9__["ɵɵadvance"](4);
    _angular_core__WEBPACK_IMPORTED_MODULE_9__["ɵɵtextInterpolate1"](" ", _angular_core__WEBPACK_IMPORTED_MODULE_9__["ɵɵpipeBind1"](5, 1, "campaigns.detail.companies"), " ");
  }
}
function CampaignJoinPage_ng_container_0_div_37_Template(rf, ctx) {
  if (rf & 1) {
    _angular_core__WEBPACK_IMPORTED_MODULE_9__["ɵɵelementStart"](0, "div");
    _angular_core__WEBPACK_IMPORTED_MODULE_9__["ɵɵtemplate"](1, CampaignJoinPage_ng_container_0_div_37_ng_container_1_Template, 2, 1, "ng-container", 23)(2, CampaignJoinPage_ng_container_0_div_37_div_2_Template, 7, 3, "div", 2);
    _angular_core__WEBPACK_IMPORTED_MODULE_9__["ɵɵelementEnd"]();
  }
  if (rf & 2) {
    const details_r8 = ctx.ngIf;
    const ctx_r2 = _angular_core__WEBPACK_IMPORTED_MODULE_9__["ɵɵnextContext"](2);
    _angular_core__WEBPACK_IMPORTED_MODULE_9__["ɵɵadvance"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_9__["ɵɵproperty"]("ngForOf", details_r8);
    _angular_core__WEBPACK_IMPORTED_MODULE_9__["ɵɵadvance"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_9__["ɵɵproperty"]("ngIf", ctx_r2.isCompany() && (ctx_r2.campaign == null ? null : ctx_r2.campaign.specificData == null ? null : ctx_r2.campaign.specificData.hideCompanyDesc) !== true);
  }
}
function CampaignJoinPage_ng_container_0_Template(rf, ctx) {
  if (rf & 1) {
    const _r1 = _angular_core__WEBPACK_IMPORTED_MODULE_9__["ɵɵgetCurrentView"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_9__["ɵɵelementContainerStart"](0);
    _angular_core__WEBPACK_IMPORTED_MODULE_9__["ɵɵelement"](1, "ion-header", 3);
    _angular_core__WEBPACK_IMPORTED_MODULE_9__["ɵɵpipe"](2, "localDate");
    _angular_core__WEBPACK_IMPORTED_MODULE_9__["ɵɵpipe"](3, "localDate");
    _angular_core__WEBPACK_IMPORTED_MODULE_9__["ɵɵelementStart"](4, "ion-content", 4)(5, "div", 5)(6, "ion-avatar", 6);
    _angular_core__WEBPACK_IMPORTED_MODULE_9__["ɵɵelement"](7, "img", 7);
    _angular_core__WEBPACK_IMPORTED_MODULE_9__["ɵɵelementEnd"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_9__["ɵɵtemplate"](8, CampaignJoinPage_ng_container_0_ion_button_8_Template, 3, 4, "ion-button", 8);
    _angular_core__WEBPACK_IMPORTED_MODULE_9__["ɵɵelementStart"](9, "div", 9);
    _angular_core__WEBPACK_IMPORTED_MODULE_9__["ɵɵtemplate"](10, CampaignJoinPage_ng_container_0_div_10_Template, 4, 2, "div", 10)(11, CampaignJoinPage_ng_container_0_ng_template_11_Template, 1, 1, "ng-template", null, 0, _angular_core__WEBPACK_IMPORTED_MODULE_9__["ɵɵtemplateRefExtractor"]);
    _angular_core__WEBPACK_IMPORTED_MODULE_9__["ɵɵelementEnd"]()();
    _angular_core__WEBPACK_IMPORTED_MODULE_9__["ɵɵelementStart"](13, "ion-card")(14, "ion-card-content");
    _angular_core__WEBPACK_IMPORTED_MODULE_9__["ɵɵtemplate"](15, CampaignJoinPage_ng_container_0_div_15_Template, 3, 3, "div", 2);
    _angular_core__WEBPACK_IMPORTED_MODULE_9__["ɵɵpipe"](16, "languageMap");
    _angular_core__WEBPACK_IMPORTED_MODULE_9__["ɵɵelementStart"](17, "ion-item", 11)(18, "ion-label");
    _angular_core__WEBPACK_IMPORTED_MODULE_9__["ɵɵtext"](19);
    _angular_core__WEBPACK_IMPORTED_MODULE_9__["ɵɵpipe"](20, "translate");
    _angular_core__WEBPACK_IMPORTED_MODULE_9__["ɵɵelementStart"](21, "span", 12);
    _angular_core__WEBPACK_IMPORTED_MODULE_9__["ɵɵtext"](22);
    _angular_core__WEBPACK_IMPORTED_MODULE_9__["ɵɵpipe"](23, "localDate");
    _angular_core__WEBPACK_IMPORTED_MODULE_9__["ɵɵelementEnd"]()()();
    _angular_core__WEBPACK_IMPORTED_MODULE_9__["ɵɵelementStart"](24, "ion-item", 11)(25, "ion-label");
    _angular_core__WEBPACK_IMPORTED_MODULE_9__["ɵɵtext"](26);
    _angular_core__WEBPACK_IMPORTED_MODULE_9__["ɵɵpipe"](27, "translate");
    _angular_core__WEBPACK_IMPORTED_MODULE_9__["ɵɵelementStart"](28, "span", 12);
    _angular_core__WEBPACK_IMPORTED_MODULE_9__["ɵɵtext"](29);
    _angular_core__WEBPACK_IMPORTED_MODULE_9__["ɵɵpipe"](30, "localDate");
    _angular_core__WEBPACK_IMPORTED_MODULE_9__["ɵɵelementEnd"]()()();
    _angular_core__WEBPACK_IMPORTED_MODULE_9__["ɵɵelementStart"](31, "div", 13);
    _angular_core__WEBPACK_IMPORTED_MODULE_9__["ɵɵlistener"]("click", function CampaignJoinPage_ng_container_0_Template_div_click_31_listener() {
      _angular_core__WEBPACK_IMPORTED_MODULE_8__["ɵɵrestoreView"](_r1);
      const ctx_r2 = _angular_core__WEBPACK_IMPORTED_MODULE_9__["ɵɵnextContext"]();
      return _angular_core__WEBPACK_IMPORTED_MODULE_8__["ɵɵresetView"](ctx_r2.clickDescription());
    });
    _angular_core__WEBPACK_IMPORTED_MODULE_9__["ɵɵelement"](32, "div", 14);
    _angular_core__WEBPACK_IMPORTED_MODULE_9__["ɵɵpipe"](33, "languageMap");
    _angular_core__WEBPACK_IMPORTED_MODULE_9__["ɵɵelementEnd"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_9__["ɵɵelementStart"](34, "div", 15);
    _angular_core__WEBPACK_IMPORTED_MODULE_9__["ɵɵlistener"]("click", function CampaignJoinPage_ng_container_0_Template_div_click_34_listener() {
      _angular_core__WEBPACK_IMPORTED_MODULE_8__["ɵɵrestoreView"](_r1);
      const ctx_r2 = _angular_core__WEBPACK_IMPORTED_MODULE_9__["ɵɵnextContext"]();
      return _angular_core__WEBPACK_IMPORTED_MODULE_8__["ɵɵresetView"](ctx_r2.clickDescription());
    });
    _angular_core__WEBPACK_IMPORTED_MODULE_9__["ɵɵtemplate"](35, CampaignJoinPage_ng_container_0_ion_icon_35_Template, 1, 0, "ion-icon", 16)(36, CampaignJoinPage_ng_container_0_ion_icon_36_Template, 1, 0, "ion-icon", 17);
    _angular_core__WEBPACK_IMPORTED_MODULE_9__["ɵɵelementEnd"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_9__["ɵɵtemplate"](37, CampaignJoinPage_ng_container_0_div_37_Template, 3, 2, "div", 2);
    _angular_core__WEBPACK_IMPORTED_MODULE_9__["ɵɵpipe"](38, "languageMap");
    _angular_core__WEBPACK_IMPORTED_MODULE_9__["ɵɵelementEnd"]()()();
    _angular_core__WEBPACK_IMPORTED_MODULE_9__["ɵɵelementContainerEnd"]();
  }
  if (rf & 2) {
    const started_r9 = _angular_core__WEBPACK_IMPORTED_MODULE_9__["ɵɵreference"](12);
    const ctx_r2 = _angular_core__WEBPACK_IMPORTED_MODULE_9__["ɵɵnextContext"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_9__["ɵɵadvance"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_9__["ɵɵproperty"]("text", _angular_core__WEBPACK_IMPORTED_MODULE_9__["ɵɵinterpolate2"]("", _angular_core__WEBPACK_IMPORTED_MODULE_9__["ɵɵpipeBind2"](2, 21, ctx_r2.campaign == null ? null : ctx_r2.campaign.dateFrom, "dd MMMM y"), " - ", _angular_core__WEBPACK_IMPORTED_MODULE_9__["ɵɵpipeBind2"](3, 24, ctx_r2.campaign == null ? null : ctx_r2.campaign.dateTo, "dd MMMM y")))("imageUrl", ctx_r2.campaign == null ? null : ctx_r2.campaign.banner == null ? null : ctx_r2.campaign.banner.url)("logo", ctx_r2.imagePath);
    _angular_core__WEBPACK_IMPORTED_MODULE_9__["ɵɵadvance"](3);
    _angular_core__WEBPACK_IMPORTED_MODULE_9__["ɵɵproperty"]("fullscreen", true);
    _angular_core__WEBPACK_IMPORTED_MODULE_9__["ɵɵadvance"](2);
    _angular_core__WEBPACK_IMPORTED_MODULE_9__["ɵɵproperty"]("ngClass", ctx_r2.campaign.type);
    _angular_core__WEBPACK_IMPORTED_MODULE_9__["ɵɵadvance"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_9__["ɵɵproperty"]("src", ctx_r2.imagePath, _angular_core__WEBPACK_IMPORTED_MODULE_9__["ɵɵsanitizeUrl"]);
    _angular_core__WEBPACK_IMPORTED_MODULE_9__["ɵɵadvance"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_9__["ɵɵproperty"]("ngIf", ctx_r2.joinIsVisible(ctx_r2.campaign));
    _angular_core__WEBPACK_IMPORTED_MODULE_9__["ɵɵadvance"](2);
    _angular_core__WEBPACK_IMPORTED_MODULE_9__["ɵɵproperty"]("ngIf", ctx_r2.campaignNotStarted(ctx_r2.campaign))("ngIfElse", started_r9);
    _angular_core__WEBPACK_IMPORTED_MODULE_9__["ɵɵadvance"](5);
    _angular_core__WEBPACK_IMPORTED_MODULE_9__["ɵɵproperty"]("ngIf", ctx_r2.campaignHasSponsor(_angular_core__WEBPACK_IMPORTED_MODULE_9__["ɵɵpipeBind1"](16, 27, ctx_r2.campaign == null ? null : ctx_r2.campaign.details)));
    _angular_core__WEBPACK_IMPORTED_MODULE_9__["ɵɵadvance"](4);
    _angular_core__WEBPACK_IMPORTED_MODULE_9__["ɵɵtextInterpolate"](_angular_core__WEBPACK_IMPORTED_MODULE_9__["ɵɵpipeBind1"](20, 29, "campaigns.detail.dateFrom"));
    _angular_core__WEBPACK_IMPORTED_MODULE_9__["ɵɵadvance"](3);
    _angular_core__WEBPACK_IMPORTED_MODULE_9__["ɵɵtextInterpolate"](_angular_core__WEBPACK_IMPORTED_MODULE_9__["ɵɵpipeBind1"](23, 31, ctx_r2.campaign.dateFrom));
    _angular_core__WEBPACK_IMPORTED_MODULE_9__["ɵɵadvance"](4);
    _angular_core__WEBPACK_IMPORTED_MODULE_9__["ɵɵtextInterpolate"](_angular_core__WEBPACK_IMPORTED_MODULE_9__["ɵɵpipeBind1"](27, 33, "campaigns.detail.dateTo"));
    _angular_core__WEBPACK_IMPORTED_MODULE_9__["ɵɵadvance"](3);
    _angular_core__WEBPACK_IMPORTED_MODULE_9__["ɵɵtextInterpolate"](_angular_core__WEBPACK_IMPORTED_MODULE_9__["ɵɵpipeBind1"](30, 35, ctx_r2.campaign.dateTo));
    _angular_core__WEBPACK_IMPORTED_MODULE_9__["ɵɵadvance"](2);
    _angular_core__WEBPACK_IMPORTED_MODULE_9__["ɵɵproperty"]("ngClass", ctx_r2.descriptionExpanded ? "open" : "");
    _angular_core__WEBPACK_IMPORTED_MODULE_9__["ɵɵadvance"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_9__["ɵɵproperty"]("innerHTML", _angular_core__WEBPACK_IMPORTED_MODULE_9__["ɵɵpipeBind1"](33, 37, ctx_r2.campaign.description), _angular_core__WEBPACK_IMPORTED_MODULE_9__["ɵɵsanitizeHtml"]);
    _angular_core__WEBPACK_IMPORTED_MODULE_9__["ɵɵadvance"](3);
    _angular_core__WEBPACK_IMPORTED_MODULE_9__["ɵɵproperty"]("ngIf", ctx_r2.descriptionExpanded);
    _angular_core__WEBPACK_IMPORTED_MODULE_9__["ɵɵadvance"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_9__["ɵɵproperty"]("ngIf", !ctx_r2.descriptionExpanded);
    _angular_core__WEBPACK_IMPORTED_MODULE_9__["ɵɵadvance"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_9__["ɵɵproperty"]("ngIf", _angular_core__WEBPACK_IMPORTED_MODULE_9__["ɵɵpipeBind1"](38, 39, ctx_r2.campaign.details));
  }
}
class CampaignJoinPage {
  constructor(route, campaignService, alertService, navCtrl, modalController, userService, pageSettingsService, playerTeamControllerService) {
    this.route = route;
    this.campaignService = campaignService;
    this.alertService = alertService;
    this.navCtrl = navCtrl;
    this.modalController = modalController;
    this.userService = userService;
    this.pageSettingsService = pageSettingsService;
    this.playerTeamControllerService = playerTeamControllerService;
    this.descriptionExpanded = false;
    this.canSubscribe = false;
    this.route.params.subscribe(params => this.id = params.id);
  }
  ngOnInit() {
    // combineLatest tra profile e campaign per chiamare manageSpecificDetail
    this.sub = (0,rxjs__WEBPACK_IMPORTED_MODULE_2__.combineLatest)([this.userService.userProfile$, this.campaignService.getCampaignDetailsById(this.id)]).subscribe(([profile, campaign]) => {
      this.profile = profile;
      if (campaign) {
        this.campaign = campaign;
        this.imagePath = this.campaign.logo.url ? this.campaign.logo.url : 'data:image/jpg;base64,' + this.campaign.logo.image;
        this.changePageSettings();
        this.manageSpecificDetail(this.campaign, this.profile?.nickname);
      }
    });
    // this.subProf = this.userService.userProfile$.subscribe((profile) => {
    //   this.profile = profile;
    // });
    // this.sub = this.campaignService
    //   .getCampaignDetailsById(this.id)
    //   .subscribe((result) => {
    //     if (result) {
    //       this.campaign = result;
    //       this.imagePath = this.campaign.logo.url
    //         ? this.campaign.logo.url
    //         : 'data:image/jpg;base64,' + this.campaign.logo.image;
    //       this.changePageSettings();
    //       this.manageSpecificDetail(this.campaign);
    //     }
    //   });
  }
  manageSpecificDetail(campaign, nickname) {
    switch (campaign.type) {
      case 'city':
        this.canSubscribe = true;
        break;
      case 'school':
        this.subSchool = this.playerTeamControllerService.checkSubscribeTeamMemberUsingGET({
          initiativeId: this.id,
          nickname
        }).subscribe(res => this.canSubscribe = res);
        break;
      case 'company':
        this.canSubscribe = true;
        break;
      default:
        break;
    }
  }
  ionViewWillEnter() {
    this.changePageSettings();
  }
  clickDescription() {
    this.descriptionExpanded = !this.descriptionExpanded;
  }
  ngOnDestroy() {}
  ionViewDidLeave() {
    this.sub?.unsubscribe();
    this.subSchool?.unsubscribe();
  }
  changePageSettings() {
    const language = this.userService.getLanguage();
    this.pageSettingsService.set({
      color: this.campaign?.type,
      // FIXME: ! title is already translated!
      title: this.campaign?.name[language]
    });
  }
  //based on the type, change interaction
  joinCampaign(campaign) {
    if (!this.campaignNotStarted(campaign)) {
      switch (campaign.type) {
        case 'city':
          this.registerToCity(campaign);
          break;
        case 'school':
          this.openRegisterSchool(campaign);
          break;
        case 'company':
          this.openRegisterCompany(campaign);
          break;
        default:
          break;
      }
    } else {
      this.alertService.showToast({
        messageString: 'campaigns.novaliddate'
      });
    }
  }
  openRegisterSchool(campaign) {
    var _this = this;
    return (0,_Users_smartcommunitylab_Desktop_newWork_playAndGo_playGo_node_modules_babel_runtime_helpers_esm_asyncToGenerator_js__WEBPACK_IMPORTED_MODULE_0__["default"])(function* () {
      const language = _this.userService.getLanguage();
      const modal = yield _this.modalController.create({
        component: _join_school_join_school_modal__WEBPACK_IMPORTED_MODULE_7__.JoinSchoolModalPage,
        componentProps: {
          campaign,
          language
        },
        cssClass: 'modalConfirm',
        canDismiss: true
      });
      yield modal.present();
      const {
        data
      } = yield modal.onWillDismiss();
      if (data) {
        _this.navCtrl.navigateRoot('/pages/tabs/home');
      }
    })();
  }
  openRegisterCompany(campaign) {
    var _this2 = this;
    return (0,_Users_smartcommunitylab_Desktop_newWork_playAndGo_playGo_node_modules_babel_runtime_helpers_esm_asyncToGenerator_js__WEBPACK_IMPORTED_MODULE_0__["default"])(function* () {
      const language = _this2.userService.getLanguage();
      const modal = yield _this2.modalController.create({
        component: _join_company_join_company_modal__WEBPACK_IMPORTED_MODULE_6__.JoinCompanyModalPage,
        componentProps: {
          campaign,
          language
        },
        cssClass: 'modalConfirm',
        canDismiss: true
      });
      yield modal.present();
      const {
        data
      } = yield modal.onWillDismiss();
      if (data) {
        //update list of campaign
        _this2.navCtrl.navigateRoot('/pages/tabs/home');
      }
    })();
  }
  getCampaignSponsor(details) {
    return details.filter(detail => detail.type === 'sponsor')[0];
  }
  campaignHasSponsor(details) {
    return details.filter(detail => detail.type === 'sponsor').length > 0;
  }
  isCompany() {
    return this.campaign.type === 'company';
  }
  isSchool() {
    return this.campaign.type === 'school';
  }
  openCompanies() {
    var _this3 = this;
    return (0,_Users_smartcommunitylab_Desktop_newWork_playAndGo_playGo_node_modules_babel_runtime_helpers_esm_asyncToGenerator_js__WEBPACK_IMPORTED_MODULE_0__["default"])(function* () {
      const modal = yield _this3.modalController.create({
        component: _home_campaign_details_companies_modal_companies_modal__WEBPACK_IMPORTED_MODULE_3__.CompaniesCampaignModalPage,
        cssClass: 'modalConfirm',
        componentProps: {
          campaign: _this3.campaign
        }
      });
      yield modal.present();
      yield modal.onWillDismiss();
    })();
  }
  // registerToCompany(campaign: any, data: any) {
  //   this.sub = this.campaignService
  //     .subscribeToCampaign(campaign.campaignId, data)
  //     .subscribe((result) => {
  //       if (result) {
  //         this.alertService.showToast(
  //           this.translateService.instant('campaigns.registered')
  //         );
  //       }
  //     });
  // }
  campaignNotStarted(campaign) {
    // compare campaign.dateFrom and dateTo with now
    const now = luxon__WEBPACK_IMPORTED_MODULE_1__.DateTime.utc().toMillis();
    if (now > campaign.dateFrom && now < campaign.dateTo) {
      return false;
    }
    return true;
  }
  joinIsVisible(campaign) {
    let joinable = false;
    switch (campaign.type) {
      case 'city':
        joinable = true;
        break;
      case 'school':
        joinable = true;
        break;
      case 'company':
        joinable = true;
        break;
      default:
        break;
    }
    return joinable;
  }
  registerToCity(campaign) {
    var _this4 = this;
    return (0,_Users_smartcommunitylab_Desktop_newWork_playAndGo_playGo_node_modules_babel_runtime_helpers_esm_asyncToGenerator_js__WEBPACK_IMPORTED_MODULE_0__["default"])(function* () {
      const language = _this4.userService.getLanguage();
      const modal = yield _this4.modalController.create({
        component: _join_city_join_city_modal__WEBPACK_IMPORTED_MODULE_5__.JoinCityModalPage,
        componentProps: {
          campaign,
          language,
          profile: _this4.profile
        },
        cssClass: 'modalConfirm',
        canDismiss: true
      });
      yield modal.present();
      const {
        data
      } = yield modal.onWillDismiss();
      //this.registerToCompany(campaign, data);
      if (data) {
        //update list of campaign
        _this4.navCtrl.navigateRoot('/pages/tabs/home');
      }
      // this.sub = this.campaignService
      //   .subscribeToCampaign(campaign.campaignId)
      //   .subscribe((result) => {
      //     if (result) {
      //       this.alertService.showToast({
      //         messageTranslateKey: 'campaigns.registered',
      //       });
      //     }
      //   });
    })();
  }
  back() {
    this.navCtrl.back();
  }
  openDetail(detail) {
    var _this5 = this;
    return (0,_Users_smartcommunitylab_Desktop_newWork_playAndGo_playGo_node_modules_babel_runtime_helpers_esm_asyncToGenerator_js__WEBPACK_IMPORTED_MODULE_0__["default"])(function* () {
      const modal = yield _this5.modalController.create({
        component: _home_campaign_details_detail_modal_detail_modal__WEBPACK_IMPORTED_MODULE_4__.DetailCampaignModalPage,
        cssClass: 'modalInfo',
        componentProps: {
          detail
        }
      });
      yield modal.present();
      yield modal.onWillDismiss();
    })();
  }
  static #_ = _staticBlock = () => (this.ɵfac = function CampaignJoinPage_Factory(__ngFactoryType__) {
    return new (__ngFactoryType__ || CampaignJoinPage)(_angular_core__WEBPACK_IMPORTED_MODULE_9__["ɵɵdirectiveInject"](_angular_router__WEBPACK_IMPORTED_MODULE_10__.ActivatedRoute), _angular_core__WEBPACK_IMPORTED_MODULE_9__["ɵɵdirectiveInject"](src_app_core_shared_services_campaign_service__WEBPACK_IMPORTED_MODULE_11__.CampaignService), _angular_core__WEBPACK_IMPORTED_MODULE_9__["ɵɵdirectiveInject"](src_app_core_shared_services_alert_service__WEBPACK_IMPORTED_MODULE_12__.AlertService), _angular_core__WEBPACK_IMPORTED_MODULE_9__["ɵɵdirectiveInject"](_ionic_angular__WEBPACK_IMPORTED_MODULE_13__.NavController), _angular_core__WEBPACK_IMPORTED_MODULE_9__["ɵɵdirectiveInject"](_ionic_angular__WEBPACK_IMPORTED_MODULE_14__.ModalController), _angular_core__WEBPACK_IMPORTED_MODULE_9__["ɵɵdirectiveInject"](src_app_core_shared_services_user_service__WEBPACK_IMPORTED_MODULE_15__.UserService), _angular_core__WEBPACK_IMPORTED_MODULE_9__["ɵɵdirectiveInject"](src_app_core_shared_services_page_settings_service__WEBPACK_IMPORTED_MODULE_16__.PageSettingsService), _angular_core__WEBPACK_IMPORTED_MODULE_9__["ɵɵdirectiveInject"](src_app_core_api_generated_hsc_controllers_playerTeamController_service__WEBPACK_IMPORTED_MODULE_17__.PlayerTeamControllerService));
  }, this.ɵcmp = /*@__PURE__*/_angular_core__WEBPACK_IMPORTED_MODULE_9__["ɵɵdefineComponent"]({
    type: CampaignJoinPage,
    selectors: [["app-campaign-join"]],
    standalone: false,
    decls: 1,
    vars: 1,
    consts: [["started", ""], ["notHsc", ""], [4, "ngIf"], ["mode", "ios", "appHeader", "", "parallax", "", "height", "30vh", 3, "imageUrl", "text", "logo"], ["appContent", "", 1, "page", 3, "fullscreen"], [1, "ion-padding"], [1, "avatar-campaign", 3, "ngClass"], ["title", "campaign avatar", 3, "src"], ["class", "ion-margin-start ion-margin-end", "expand", "block", "color", "playgo", 3, "disabled", "click", 4, "ngIf"], [1, "ion-text-center"], [4, "ngIf", "ngIfElse"], ["lines", "none", 1, "ion-no-padding", "ion-no-margin"], [1, "text-bold"], [1, "box", 3, "click", "ngClass"], [1, "text", 3, "innerHTML"], [1, "expansion", 3, "click"], ["name", "chevron-up-outline", 4, "ngIf"], ["name", "chevron-down-outline", 4, "ngIf"], ["expand", "block", "color", "playgo", 1, "ion-margin-start", "ion-margin-end", 3, "click", "disabled"], [3, "innerHTML", 4, "ngIf"], [3, "innerHTML"], ["name", "chevron-up-outline"], ["name", "chevron-down-outline"], [4, "ngFor", "ngForOf"], [3, "click", 4, "ngIf"], [3, "click"], ["lines", "none"], [1, "text-bold", "text-underlined"], ["name", "information-circle-outline", "end", ""], ["lines", "none", 3, "click"]],
    template: function CampaignJoinPage_Template(rf, ctx) {
      if (rf & 1) {
        _angular_core__WEBPACK_IMPORTED_MODULE_9__["ɵɵtemplate"](0, CampaignJoinPage_ng_container_0_Template, 39, 41, "ng-container", 2);
      }
      if (rf & 2) {
        _angular_core__WEBPACK_IMPORTED_MODULE_9__["ɵɵproperty"]("ngIf", ctx.campaign);
      }
    },
    dependencies: [_angular_common__WEBPACK_IMPORTED_MODULE_18__.NgClass, _angular_common__WEBPACK_IMPORTED_MODULE_18__.NgForOf, _angular_common__WEBPACK_IMPORTED_MODULE_18__.NgIf, _ionic_angular__WEBPACK_IMPORTED_MODULE_14__.IonAvatar, _ionic_angular__WEBPACK_IMPORTED_MODULE_14__.IonButton, _ionic_angular__WEBPACK_IMPORTED_MODULE_14__.IonCard, _ionic_angular__WEBPACK_IMPORTED_MODULE_14__.IonCardContent, _ionic_angular__WEBPACK_IMPORTED_MODULE_14__.IonContent, _ionic_angular__WEBPACK_IMPORTED_MODULE_14__.IonHeader, _ionic_angular__WEBPACK_IMPORTED_MODULE_14__.IonIcon, _ionic_angular__WEBPACK_IMPORTED_MODULE_14__.IonItem, _ionic_angular__WEBPACK_IMPORTED_MODULE_14__.IonLabel, _core_shared_layout_header_header_directive__WEBPACK_IMPORTED_MODULE_19__.HeaderDirective, _core_shared_layout_content_content_directive__WEBPACK_IMPORTED_MODULE_20__.ContentDirective, _core_shared_directives_parallax_header_directive__WEBPACK_IMPORTED_MODULE_21__.ParallaxDirective, _ngx_translate_core__WEBPACK_IMPORTED_MODULE_22__.TranslatePipe, _core_shared_pipes_localDate_pipe__WEBPACK_IMPORTED_MODULE_23__.LocalDatePipe, _core_shared_pipes_languageMap_pipe__WEBPACK_IMPORTED_MODULE_24__.LanguageMapPipe],
    styles: [".avatar-campaign[_ngcontent-%COMP%] {\n  margin: 16px auto;\n}\n\n.company[_ngcontent-%COMP%] {\n  border: 3px solid var(--ion-color-company);\n}\n\n.school[_ngcontent-%COMP%] {\n  border: 3px solid var(--ion-color-school);\n}\n\n.city[_ngcontent-%COMP%] {\n  border: 3px solid var(--ion-color-city);\n}\n\n\n\n.box[_ngcontent-%COMP%] {\n  max-height: 162px;\n  overflow: hidden;\n  transition: max-height 0.3s cubic-bezier(0, 1, 0, 1);\n}\n\n.box.open[_ngcontent-%COMP%] {\n  max-height: 100rem;\n  transition: max-height 0.3s cubic-bezier(0.9, 0, 0.8, 0.2);\n}\n\n.expansion[_ngcontent-%COMP%] {\n  text-align: center;\n  font-size: xx-large;\n}\n\n.text[_ngcontent-%COMP%] {\n  display: -webkit-box;\n  -webkit-box-orient: vertical;\n  padding: 2px;\n  text-overflow: ellipsis;\n  overflow: hidden;\n  margin: 12px 0;\n  animation: _ngcontent-%COMP%_close 0.1s linear 0.1s forwards;\n}\n\n.open[_ngcontent-%COMP%]   .text[_ngcontent-%COMP%] {\n  animation: _ngcontent-%COMP%_open 0.1s linear 0s forwards;\n}\n\n\n\n@keyframes _ngcontent-%COMP%_open {\n  from {\n    display: -webkit-box;\n    line-clamp: 3;\n    -webkit-line-clamp: 3;\n    -webkit-box-orient: vertical;\n  }\n  to {\n    display: -webkit-box;\n    line-clamp: initial;\n    -webkit-line-clamp: initial;\n    -webkit-box-orient: vertical;\n  }\n}\n@keyframes _ngcontent-%COMP%_close {\n  from {\n    display: -webkit-box;\n    line-clamp: initial;\n    -webkit-line-clamp: initial;\n    -webkit-box-orient: vertical;\n  }\n  to {\n    display: -webkit-box;\n    line-clamp: 3;\n    -webkit-line-clamp: 3;\n    -webkit-box-orient: vertical;\n  }\n}\n/*# sourceMappingURL=data:application/json;charset=utf-8;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbIndlYnBhY2s6Ly8uL3NyYy9hcHAvcGFnZXMvY2FtcGFpZ25zL2NhbXBhaWduLWpvaW4vY2FtcGFpZ24tam9pbi5wYWdlLnNjc3MiXSwibmFtZXMiOltdLCJtYXBwaW5ncyI6IkFBQUE7RUFDRSxpQkFBQTtBQUNGOztBQUNBO0VBQ0UsMENBQUE7QUFFRjs7QUFBQTtFQUNFLHlDQUFBO0FBR0Y7O0FBREE7RUFDRSx1Q0FBQTtBQUlGOztBQUZBLFFBQUE7QUFDQTtFQUlFLGlCQUFBO0VBQ0EsZ0JBQUE7RUFDQSxvREFBQTtBQUVGOztBQUNBO0VBQ0Usa0JBQUE7RUFDQSwwREFBQTtBQUVGOztBQUFBO0VBQ0Usa0JBQUE7RUFDQSxtQkFBQTtBQUdGOztBQURBO0VBQ0Usb0JBQUE7RUFDQSw0QkFBQTtFQUNBLFlBQUE7RUFDQSx1QkFBQTtFQUNBLGdCQUFBO0VBQ0EsY0FBQTtFQUNBLDBDQUFBO0FBSUY7O0FBRkE7RUFDRSx1Q0FBQTtBQUtGOztBQUZBLFNBQUE7QUFDQTtFQUNFO0lBQ0Usb0JBQUE7SUFDQSxhQUFBO0lBQ0EscUJBQUE7SUFDQSw0QkFBQTtFQUtGO0VBSEE7SUFDRSxvQkFBQTtJQUNBLG1CQUFBO0lBQ0EsMkJBQUE7SUFDQSw0QkFBQTtFQUtGO0FBQ0Y7QUFGQTtFQUNFO0lBQ0Usb0JBQUE7SUFDQSxtQkFBQTtJQUNBLDJCQUFBO0lBQ0EsNEJBQUE7RUFJRjtFQUZBO0lBQ0Usb0JBQUE7SUFDQSxhQUFBO0lBQ0EscUJBQUE7SUFDQSw0QkFBQTtFQUlGO0FBQ0YiLCJzb3VyY2VzQ29udGVudCI6WyIuYXZhdGFyLWNhbXBhaWduIHtcbiAgbWFyZ2luOiAxNnB4IGF1dG87XG59XG4uY29tcGFueSB7XG4gIGJvcmRlcjogM3B4IHNvbGlkIHZhcigtLWlvbi1jb2xvci1jb21wYW55KTtcbn1cbi5zY2hvb2wge1xuICBib3JkZXI6IDNweCBzb2xpZCB2YXIoLS1pb24tY29sb3Itc2Nob29sKTtcbn1cbi5jaXR5IHtcbiAgYm9yZGVyOiAzcHggc29saWQgdmFyKC0taW9uLWNvbG9yLWNpdHkpO1xufVxuLyogQm94ICovXG4uYm94IHtcbiAgLy8gbWFyZ2luOiAyMnB4IGF1dG87XG4gIC8vIHdpZHRoOiAzMjBweDtcbiAgLy8gcGFkZGluZzogMTJweCAzMnB4IDY0cHg7XG4gIG1heC1oZWlnaHQ6IDE2MnB4O1xuICBvdmVyZmxvdzogaGlkZGVuO1xuICB0cmFuc2l0aW9uOiBtYXgtaGVpZ2h0IDAuM3MgY3ViaWMtYmV6aWVyKDAsIDEsIDAsIDEpO1xufVxuXG4uYm94Lm9wZW4ge1xuICBtYXgtaGVpZ2h0OiAxMDByZW07XG4gIHRyYW5zaXRpb246IG1heC1oZWlnaHQgMC4zcyBjdWJpYy1iZXppZXIoMC45LCAwLCAwLjgsIDAuMik7XG59XG4uZXhwYW5zaW9uIHtcbiAgdGV4dC1hbGlnbjogY2VudGVyO1xuICBmb250LXNpemU6IHh4LWxhcmdlO1xufVxuLnRleHQge1xuICBkaXNwbGF5OiAtd2Via2l0LWJveDtcbiAgLXdlYmtpdC1ib3gtb3JpZW50OiB2ZXJ0aWNhbDtcbiAgcGFkZGluZzogMnB4O1xuICB0ZXh0LW92ZXJmbG93OiBlbGxpcHNpcztcbiAgb3ZlcmZsb3c6IGhpZGRlbjtcbiAgbWFyZ2luOiAxMnB4IDA7XG4gIGFuaW1hdGlvbjogY2xvc2UgMC4xcyBsaW5lYXIgMC4xcyBmb3J3YXJkcztcbn1cbi5vcGVuIC50ZXh0IHtcbiAgYW5pbWF0aW9uOiBvcGVuIDAuMXMgbGluZWFyIDBzIGZvcndhcmRzO1xufVxuXG4vKiBUZXh0ICovXG5Aa2V5ZnJhbWVzIG9wZW4ge1xuICBmcm9tIHtcbiAgICBkaXNwbGF5OiAtd2Via2l0LWJveDtcbiAgICBsaW5lLWNsYW1wOiAzO1xuICAgIC13ZWJraXQtbGluZS1jbGFtcDogMztcbiAgICAtd2Via2l0LWJveC1vcmllbnQ6IHZlcnRpY2FsO1xuICB9XG4gIHRvIHtcbiAgICBkaXNwbGF5OiAtd2Via2l0LWJveDtcbiAgICBsaW5lLWNsYW1wOiBpbml0aWFsO1xuICAgIC13ZWJraXQtbGluZS1jbGFtcDogaW5pdGlhbDtcbiAgICAtd2Via2l0LWJveC1vcmllbnQ6IHZlcnRpY2FsO1xuICB9XG59XG5cbkBrZXlmcmFtZXMgY2xvc2Uge1xuICBmcm9tIHtcbiAgICBkaXNwbGF5OiAtd2Via2l0LWJveDtcbiAgICBsaW5lLWNsYW1wOiBpbml0aWFsO1xuICAgIC13ZWJraXQtbGluZS1jbGFtcDogaW5pdGlhbDtcbiAgICAtd2Via2l0LWJveC1vcmllbnQ6IHZlcnRpY2FsO1xuICB9XG4gIHRvIHtcbiAgICBkaXNwbGF5OiAtd2Via2l0LWJveDtcbiAgICBsaW5lLWNsYW1wOiAzO1xuICAgIC13ZWJraXQtbGluZS1jbGFtcDogMztcbiAgICAtd2Via2l0LWJveC1vcmllbnQ6IHZlcnRpY2FsO1xuICB9XG59XG4iXSwic291cmNlUm9vdCI6IiJ9 */"]
  }));
}
_staticBlock();

/***/ }),

/***/ 86591:
/*!****************************************************************************!*\
  !*** ./src/app/pages/campaigns/campaign-join/join-city/join-city.modal.ts ***!
  \****************************************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   JoinCityModalPage: () => (/* binding */ JoinCityModalPage)
/* harmony export */ });
/* harmony import */ var _angular_forms__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! @angular/forms */ 34456);
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @angular/core */ 34205);
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @angular/core */ 12481);
/* harmony import */ var _ionic_angular__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @ionic/angular */ 21507);
/* harmony import */ var _ionic_angular__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! @ionic/angular */ 4059);
/* harmony import */ var src_app_core_shared_services_alert_service__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! src/app/core/shared/services/alert.service */ 67406);
/* harmony import */ var src_app_core_shared_services_error_service__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! src/app/core/shared/services/error.service */ 46078);
/* harmony import */ var src_app_core_shared_services_campaign_service__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(/*! src/app/core/shared/services/campaign.service */ 76658);
/* harmony import */ var src_app_core_shared_services_user_service__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(/*! src/app/core/shared/services/user.service */ 89815);
/* harmony import */ var _angular_common__WEBPACK_IMPORTED_MODULE_9__ = __webpack_require__(/*! @angular/common */ 93683);
/* harmony import */ var _ngx_translate_core__WEBPACK_IMPORTED_MODULE_10__ = __webpack_require__(/*! @ngx-translate/core */ 48503);
/* harmony import */ var _core_shared_pipes_languageMap_pipe__WEBPACK_IMPORTED_MODULE_11__ = __webpack_require__(/*! ../../../../core/shared/pipes/languageMap.pipe */ 69618);
var _staticBlock;











const _c0 = a0 => ({
  campaignTitle: a0
});
function JoinCityModalPage_ion_row_12_Template(rf, ctx) {
  if (rf & 1) {
    _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵelementStart"](0, "ion-row", 9)(1, "ion-col")(2, "ion-item", 10)(3, "ion-label", 11);
    _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵtext"](4);
    _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵpipe"](5, "translate");
    _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵelementEnd"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵelement"](6, "ion-input", 12);
    _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵpipe"](7, "translate");
    _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵelementEnd"]()()();
  }
  if (rf & 2) {
    _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵadvance"](4);
    _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵtextInterpolate"](_angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵpipeBind1"](5, 3, "campaigns.joinmodal.raccomandation"));
    _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵadvance"](2);
    _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵproperty"]("placeholder", _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵinterpolate"](_angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵpipeBind1"](7, 5, "campaigns.joinmodal.nickname")));
  }
}
function JoinCityModalPage_ion_row_13_Template(rf, ctx) {
  if (rf & 1) {
    const _r1 = _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵgetCurrentView"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵelementStart"](0, "ion-row", 9)(1, "ion-col", 13)(2, "ion-label", 14);
    _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵtext"](3);
    _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵpipe"](4, "translate");
    _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵelementEnd"]()();
    _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵelementStart"](5, "ion-col", 15);
    _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵlistener"]("click", function JoinCityModalPage_ion_row_13_Template_ion_col_click_5_listener() {
      _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵrestoreView"](_r1);
      const ctx_r1 = _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵnextContext"]();
      return _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵresetView"](ctx_r1.openPrivacyPopup());
    });
    _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵelement"](6, "ion-icon", 16);
    _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵelementEnd"]()();
  }
  if (rf & 2) {
    _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵadvance"](3);
    _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵtextInterpolate"](_angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵpipeBind1"](4, 1, "campaigns.joinmodal.privacyLink"));
  }
}
function JoinCityModalPage_ion_row_14_Template(rf, ctx) {
  if (rf & 1) {
    _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵelementStart"](0, "ion-row", 9)(1, "ion-col")(2, "ion-item", 0);
    _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵelement"](3, "ion-checkbox", 17);
    _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵelementStart"](4, "ion-label", 18);
    _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵtext"](5);
    _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵpipe"](6, "translate");
    _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵelementEnd"]()()()();
  }
  if (rf & 2) {
    _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵadvance"](5);
    _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵtextInterpolate"](_angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵpipeBind1"](6, 1, "campaigns.joinmodal.privacy"));
  }
}
function JoinCityModalPage_div_15_Template(rf, ctx) {
  if (rf & 1) {
    _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵelementStart"](0, "div", 19)(1, "span");
    _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵtext"](2);
    _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵpipe"](3, "translate");
    _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵelementEnd"]()();
  }
  if (rf & 2) {
    _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵadvance"](2);
    _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵtextInterpolate"](_angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵpipeBind1"](3, 1, "campaigns.joinmodal.privacyRequired"));
  }
}
function JoinCityModalPage_ion_row_16_Template(rf, ctx) {
  if (rf & 1) {
    const _r3 = _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵgetCurrentView"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵelementStart"](0, "ion-row", 9)(1, "ion-col", 13)(2, "ion-label", 14);
    _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵtext"](3);
    _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵpipe"](4, "translate");
    _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵelementEnd"]()();
    _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵelementStart"](5, "ion-col", 15);
    _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵlistener"]("click", function JoinCityModalPage_ion_row_16_Template_ion_col_click_5_listener() {
      _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵrestoreView"](_r3);
      const ctx_r1 = _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵnextContext"]();
      return _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵresetView"](ctx_r1.openRulesPopup());
    });
    _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵelement"](6, "ion-icon", 16);
    _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵelementEnd"]()();
  }
  if (rf & 2) {
    _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵadvance"](3);
    _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵtextInterpolate"](_angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵpipeBind1"](4, 1, "campaigns.joinmodal.rulesLink"));
  }
}
function JoinCityModalPage_ion_row_17_Template(rf, ctx) {
  if (rf & 1) {
    _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵelementStart"](0, "ion-row", 9)(1, "ion-col")(2, "ion-item", 0);
    _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵelement"](3, "ion-checkbox", 20);
    _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵelementStart"](4, "ion-label", 18);
    _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵtext"](5);
    _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵpipe"](6, "translate");
    _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵelementEnd"]()()()();
  }
  if (rf & 2) {
    _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵadvance"](5);
    _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵtextInterpolate"](_angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵpipeBind1"](6, 1, "campaigns.joinmodal.rules"));
  }
}
function JoinCityModalPage_div_18_Template(rf, ctx) {
  if (rf & 1) {
    _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵelementStart"](0, "div", 19)(1, "span");
    _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵtext"](2);
    _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵpipe"](3, "translate");
    _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵelementEnd"]()();
  }
  if (rf & 2) {
    _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵadvance"](2);
    _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵtextInterpolate"](_angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵpipeBind1"](3, 1, "campaigns.joinmodal.rulesRequired"));
  }
}
class JoinCityModalPage {
  constructor(modalController, alertService, errorService, campaignService, formBuilder, userService, navCtrl) {
    this.modalController = modalController;
    this.alertService = alertService;
    this.errorService = errorService;
    this.campaignService = campaignService;
    this.formBuilder = formBuilder;
    this.userService = userService;
    this.navCtrl = navCtrl;
    this.isSubmitted = false;
  }
  ngOnInit() {
    this.language = this.userService.getLanguage();
    const rules = this.campaign.details[this.language];
    this.rules = rules?.find(detail => detail.type === 'rules');
    this.privacy = rules?.find(detail => detail.type === 'privacy');
    this.joinCityForm = this.formBuilder.group({
      name: [''],
      ...(this.privacy && {
        privacy: [false, _angular_forms__WEBPACK_IMPORTED_MODULE_0__.Validators.requiredTrue]
      }),
      ...(this.rules && {
        rules: [false, _angular_forms__WEBPACK_IMPORTED_MODULE_0__.Validators.requiredTrue]
      })
    });
  }
  //computed errorcontrol
  get errorControl() {
    return this.joinCityForm.controls;
  }
  close() {
    this.modalController.dismiss(false);
  }
  isAlreadySubscribed() {
    return this.profile?.personalData?.registeredIds?.includes(this.campaign?.campaignId);
  }
  openPrivacyPopup() {
    this.alertService.presentAlert({
      headerTranslateKey: 'campaigns.joinmodal.privacyPopup.header',
      messageString: this.privacy.content,
      cssClass: 'modalJoin'
    });
  }
  openRulesPopup() {
    this.alertService.presentAlert({
      headerTranslateKey: 'campaigns.joinmodal.rulesPopup.header',
      messageString: this.rules.content,
      cssClass: 'modalJoin'
    });
  }
  openCodeInfoPopup() {
    this.alertService.presentAlert({
      headerTranslateKey: 'campaigns.joinmodal.codeInfo.header',
      messageString: 'campaigns.joinmodal.codeInfo.message',
      cssClass: 'modalConfirm'
    });
  }
  joinCitySubmit() {
    // call join with all params
    this.isSubmitted = true;
    if (!this.joinCityForm.valid) {
      return false;
    } else {
      const body = {
        // eslint-disable-next-line @typescript-eslint/naming-convention
        nick_recommandation: this.joinCityForm.value.name
      };
      this.campaignService.subscribeToCampaign(this.campaign.campaignId, body).subscribe(result => {
        if (result) {
          this.alertService.showToast({
            messageTranslateKey: 'campaigns.registered'
          });
          this.modalController.dismiss(true);
        }
      }, err => {
        this.errorService.handleError(err);
      });
    }
  }
  static #_ = _staticBlock = () => (this.ɵfac = function JoinCityModalPage_Factory(__ngFactoryType__) {
    return new (__ngFactoryType__ || JoinCityModalPage)(_angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵdirectiveInject"](_ionic_angular__WEBPACK_IMPORTED_MODULE_3__.ModalController), _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵdirectiveInject"](src_app_core_shared_services_alert_service__WEBPACK_IMPORTED_MODULE_5__.AlertService), _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵdirectiveInject"](src_app_core_shared_services_error_service__WEBPACK_IMPORTED_MODULE_6__.ErrorService), _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵdirectiveInject"](src_app_core_shared_services_campaign_service__WEBPACK_IMPORTED_MODULE_7__.CampaignService), _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵdirectiveInject"](_angular_forms__WEBPACK_IMPORTED_MODULE_0__.FormBuilder), _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵdirectiveInject"](src_app_core_shared_services_user_service__WEBPACK_IMPORTED_MODULE_8__.UserService), _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵdirectiveInject"](_ionic_angular__WEBPACK_IMPORTED_MODULE_4__.NavController));
  }, this.ɵcmp = /*@__PURE__*/_angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵdefineComponent"]({
    type: JoinCityModalPage,
    selectors: [["app-join-city"]],
    standalone: false,
    decls: 24,
    vars: 19,
    consts: [["color", "playgo"], ["slot", "end"], [3, "click"], ["name", "close-circle-outline"], ["color", "playgo", "scroll", "false"], [3, "ngSubmit", "formGroup"], ["class", "ion-margin-top", 4, "ngIf"], ["class", "error-message ion-padding", 4, "ngIf"], ["color", "light", "type", "submit", "expand", "block"], [1, "ion-margin-top"], ["lines", "full", "color", "playgo"], ["position", "floating"], ["type", "text", "formControlName", "name", "clearInput", "", 3, "placeholder"], ["size", "10"], [1, "privacy-info"], [1, "ion-text-center", 3, "click"], ["name", "information-circle-outline", 1, "popup-icon"], ["slot", "start", "color", "playgo", "formControlName", "privacy"], [1, "ion-text-wrap"], [1, "error-message", "ion-padding"], ["slot", "start", "color", "playgo", "formControlName", "rules"]],
    template: function JoinCityModalPage_Template(rf, ctx) {
      if (rf & 1) {
        _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵelementStart"](0, "ion-header")(1, "ion-toolbar", 0)(2, "ion-title");
        _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵtext"](3);
        _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵpipe"](4, "languageMap");
        _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵpipe"](5, "translate");
        _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵelementStart"](6, "ion-buttons", 1)(7, "ion-button", 2);
        _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵlistener"]("click", function JoinCityModalPage_Template_ion_button_click_7_listener() {
          return ctx.close();
        });
        _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵelement"](8, "ion-icon", 3);
        _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵelementEnd"]()()()();
        _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵelementStart"](9, "ion-content", 4)(10, "form", 5);
        _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵlistener"]("ngSubmit", function JoinCityModalPage_Template_form_ngSubmit_10_listener() {
          return ctx.joinCitySubmit();
        });
        _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵelementStart"](11, "ion-grid");
        _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵtemplate"](12, JoinCityModalPage_ion_row_12_Template, 8, 7, "ion-row", 6)(13, JoinCityModalPage_ion_row_13_Template, 7, 3, "ion-row", 6)(14, JoinCityModalPage_ion_row_14_Template, 7, 3, "ion-row", 6)(15, JoinCityModalPage_div_15_Template, 4, 3, "div", 7)(16, JoinCityModalPage_ion_row_16_Template, 7, 3, "ion-row", 6)(17, JoinCityModalPage_ion_row_17_Template, 7, 3, "ion-row", 6)(18, JoinCityModalPage_div_18_Template, 4, 3, "div", 7);
        _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵelementStart"](19, "ion-row")(20, "ion-col")(21, "ion-button", 8);
        _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵtext"](22);
        _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵpipe"](23, "translate");
        _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵelementEnd"]()()()()()();
      }
      if (rf & 2) {
        _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵadvance"](3);
        _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵtextInterpolate"](_angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵpipeBind2"](5, 12, "campaigns.joinmodal.modalTitle", _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵpureFunction1"](17, _c0, _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵpipeBind1"](4, 10, ctx.campaign == null ? null : ctx.campaign.name))));
        _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵadvance"](7);
        _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵproperty"]("formGroup", ctx.joinCityForm);
        _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵadvance"](2);
        _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵproperty"]("ngIf", !ctx.isAlreadySubscribed());
        _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵadvance"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵproperty"]("ngIf", ctx.privacy);
        _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵadvance"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵproperty"]("ngIf", ctx.privacy);
        _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵadvance"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵproperty"]("ngIf", ctx.isSubmitted && (ctx.errorControl == null ? null : ctx.errorControl.privacy == null ? null : ctx.errorControl.privacy.errors));
        _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵadvance"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵproperty"]("ngIf", ctx.rules);
        _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵadvance"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵproperty"]("ngIf", ctx.rules);
        _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵadvance"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵproperty"]("ngIf", ctx.isSubmitted && (ctx.errorControl == null ? null : ctx.errorControl.rules == null ? null : ctx.errorControl.rules.errors));
        _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵadvance"](4);
        _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵtextInterpolate1"]("", _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵpipeBind1"](23, 15, "campaigns.joinmodal.confirm"), " ");
      }
    },
    dependencies: [_angular_common__WEBPACK_IMPORTED_MODULE_9__.NgIf, _angular_forms__WEBPACK_IMPORTED_MODULE_0__["ɵNgNoValidate"], _angular_forms__WEBPACK_IMPORTED_MODULE_0__.NgControlStatus, _angular_forms__WEBPACK_IMPORTED_MODULE_0__.NgControlStatusGroup, _angular_forms__WEBPACK_IMPORTED_MODULE_0__.FormGroupDirective, _angular_forms__WEBPACK_IMPORTED_MODULE_0__.FormControlName, _ionic_angular__WEBPACK_IMPORTED_MODULE_3__.IonButton, _ionic_angular__WEBPACK_IMPORTED_MODULE_3__.IonButtons, _ionic_angular__WEBPACK_IMPORTED_MODULE_3__.IonCheckbox, _ionic_angular__WEBPACK_IMPORTED_MODULE_3__.IonCol, _ionic_angular__WEBPACK_IMPORTED_MODULE_3__.IonContent, _ionic_angular__WEBPACK_IMPORTED_MODULE_3__.IonGrid, _ionic_angular__WEBPACK_IMPORTED_MODULE_3__.IonHeader, _ionic_angular__WEBPACK_IMPORTED_MODULE_3__.IonIcon, _ionic_angular__WEBPACK_IMPORTED_MODULE_3__.IonInput, _ionic_angular__WEBPACK_IMPORTED_MODULE_3__.IonItem, _ionic_angular__WEBPACK_IMPORTED_MODULE_3__.IonLabel, _ionic_angular__WEBPACK_IMPORTED_MODULE_3__.IonRow, _ionic_angular__WEBPACK_IMPORTED_MODULE_3__.IonTitle, _ionic_angular__WEBPACK_IMPORTED_MODULE_3__.IonToolbar, _ionic_angular__WEBPACK_IMPORTED_MODULE_3__.BooleanValueAccessor, _ionic_angular__WEBPACK_IMPORTED_MODULE_3__.TextValueAccessor, _ngx_translate_core__WEBPACK_IMPORTED_MODULE_10__.TranslatePipe, _core_shared_pipes_languageMap_pipe__WEBPACK_IMPORTED_MODULE_11__.LanguageMapPipe],
    styles: ["/*# sourceMappingURL=data:application/json;charset=utf-8;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbXSwibmFtZXMiOltdLCJtYXBwaW5ncyI6IiIsInNvdXJjZVJvb3QiOiIifQ== */"]
  }));
}
_staticBlock();

/***/ })

}]);
//# sourceMappingURL=src_app_pages_campaigns_campaign-join_campaign-join_module_ts.js.map