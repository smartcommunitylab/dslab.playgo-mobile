"use strict";
(self["webpackChunkapp"] = self["webpackChunkapp"] || []).push([["default-src_app_pages_home_campaign-details_campaign-details_module_ts"],{

/***/ 887:
/*!************************************************************************************!*\
  !*** ./src/app/pages/home/campaign-details/unsubscribe-modal/unsubscribe.modal.ts ***!
  \************************************************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   UnsubscribeModalPage: () => (/* binding */ UnsubscribeModalPage)
/* harmony export */ });
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! @angular/core */ 12481);
/* harmony import */ var _ionic_angular__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @ionic/angular */ 21507);
/* harmony import */ var _ngx_translate_core__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @ngx-translate/core */ 48503);
var _staticBlock;



const _c0 = ["class", "modal"];
class UnsubscribeModalPage {
  constructor(modalController) {
    this.modalController = modalController;
  }
  ngOnInit() {}
  close() {
    this.modalController.dismiss(false);
  }
  confirm() {
    this.modalController.dismiss(true);
  }
  static #_ = _staticBlock = () => (this.ɵfac = function UnsubscribeModalPage_Factory(__ngFactoryType__) {
    return new (__ngFactoryType__ || UnsubscribeModalPage)(_angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵdirectiveInject"](_ionic_angular__WEBPACK_IMPORTED_MODULE_1__.ModalController));
  }, this.ɵcmp = /*@__PURE__*/_angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵdefineComponent"]({
    type: UnsubscribeModalPage,
    selectors: [["app-unsubscribe", 8, "modal"]],
    standalone: false,
    attrs: _c0,
    decls: 18,
    vars: 12,
    consts: [["color", "playgo", 1, "external"], [1, "title"], ["color", "playgo", 1, "internal"], [1, "body"], ["size", "6"], ["expand", "block", "color", "light", 3, "click"], ["expand", "block", "color", "danger", 3, "click"]],
    template: function UnsubscribeModalPage_Template(rf, ctx) {
      if (rf & 1) {
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](0, "ion-content", 0)(1, "p", 1);
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵtext"](2);
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵpipe"](3, "translate");
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](4, "div", 2)(5, "p", 3);
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵtext"](6);
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵpipe"](7, "translate");
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]()();
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](8, "ion-grid")(9, "ion-row")(10, "ion-col", 4)(11, "ion-button", 5);
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵlistener"]("click", function UnsubscribeModalPage_Template_ion_button_click_11_listener() {
          return ctx.close();
        });
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵtext"](12);
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵpipe"](13, "translate");
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]()();
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](14, "ion-col", 4)(15, "ion-button", 6);
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵlistener"]("click", function UnsubscribeModalPage_Template_ion_button_click_15_listener() {
          return ctx.confirm();
        });
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵtext"](16);
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵpipe"](17, "translate");
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]()()()()();
      }
      if (rf & 2) {
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵadvance"](2);
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵtextInterpolate"](_angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵpipeBind1"](3, 4, "campaigns.unsub.title"));
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵadvance"](4);
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵtextInterpolate"](_angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵpipeBind1"](7, 6, "campaigns.unsub.text"));
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵadvance"](6);
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵtextInterpolate"](_angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵpipeBind1"](13, 8, "campaigns.unsub.close"));
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵadvance"](4);
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵtextInterpolate"](_angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵpipeBind1"](17, 10, "campaigns.unsub.confirm"));
      }
    },
    dependencies: [_ionic_angular__WEBPACK_IMPORTED_MODULE_1__.IonButton, _ionic_angular__WEBPACK_IMPORTED_MODULE_1__.IonCol, _ionic_angular__WEBPACK_IMPORTED_MODULE_1__.IonContent, _ionic_angular__WEBPACK_IMPORTED_MODULE_1__.IonGrid, _ionic_angular__WEBPACK_IMPORTED_MODULE_1__.IonRow, _ngx_translate_core__WEBPACK_IMPORTED_MODULE_2__.TranslatePipe],
    styles: [".external[_ngcontent-%COMP%]   .title[_ngcontent-%COMP%] {\n  text-align: center;\n  font-weight: bold;\n  padding: 8px;\n}\n.external[_ngcontent-%COMP%]   .internal[_ngcontent-%COMP%]   .body[_ngcontent-%COMP%] {\n  text-align: justify;\n  padding: 8px;\n}\n.external[_ngcontent-%COMP%]   ion-grid[_ngcontent-%COMP%] {\n  position: absolute;\n  bottom: 0px;\n  width: 100%;\n}\n/*# sourceMappingURL=data:application/json;charset=utf-8;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbIndlYnBhY2s6Ly8uL3NyYy9hcHAvcGFnZXMvaG9tZS9jYW1wYWlnbi1kZXRhaWxzL3Vuc3Vic2NyaWJlLW1vZGFsL3Vuc3Vic2NyaWJlLm1vZGFsLnNjc3MiXSwibmFtZXMiOltdLCJtYXBwaW5ncyI6IkFBQ0U7RUFDRSxrQkFBQTtFQUNBLGlCQUFBO0VBQ0EsWUFBQTtBQUFKO0FBR0k7RUFDRSxtQkFBQTtFQUNBLFlBQUE7QUFETjtBQUlFO0VBQ0Usa0JBQUE7RUFDQSxXQUFBO0VBQ0EsV0FBQTtBQUZKIiwic291cmNlc0NvbnRlbnQiOlsiLmV4dGVybmFsIHtcbiAgLnRpdGxlIHtcbiAgICB0ZXh0LWFsaWduOiBjZW50ZXI7XG4gICAgZm9udC13ZWlnaHQ6IGJvbGQ7XG4gICAgcGFkZGluZzogOHB4O1xuICB9XG4gIC5pbnRlcm5hbCB7XG4gICAgLmJvZHkge1xuICAgICAgdGV4dC1hbGlnbjoganVzdGlmeTtcbiAgICAgIHBhZGRpbmc6IDhweDtcbiAgICB9XG4gIH1cbiAgaW9uLWdyaWQge1xuICAgIHBvc2l0aW9uOiBhYnNvbHV0ZTtcbiAgICBib3R0b206IDBweDtcbiAgICB3aWR0aDogMTAwJTtcbiAgfVxufVxuIl0sInNvdXJjZVJvb3QiOiIifQ== */"]
  }));
}
_staticBlock();

/***/ }),

/***/ 3117:
/*!**********************************************************************!*\
  !*** ./src/app/pages/home/campaign-details/campaign-details.page.ts ***!
  \**********************************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   CampaignDetailsPage: () => (/* binding */ CampaignDetailsPage)
/* harmony export */ });
/* harmony import */ var _Users_smartcommunitylab_Desktop_newWork_playAndGo_playGo_node_modules_babel_runtime_helpers_esm_asyncToGenerator_js__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./node_modules/@babel/runtime/helpers/esm/asyncToGenerator.js */ 89204);
/* harmony import */ var _detail_modal_detail_modal__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ./detail-modal/detail.modal */ 28751);
/* harmony import */ var rxjs__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! rxjs */ 10819);
/* harmony import */ var rxjs__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! rxjs */ 19999);
/* harmony import */ var rxjs__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! rxjs */ 59452);
/* harmony import */ var rxjs__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! rxjs */ 59400);
/* harmony import */ var rxjs__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! rxjs */ 91817);
/* harmony import */ var rxjs__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(/*! rxjs */ 70271);
/* harmony import */ var rxjs__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(/*! rxjs */ 86301);
/* harmony import */ var rxjs__WEBPACK_IMPORTED_MODULE_9__ = __webpack_require__(/*! rxjs */ 36647);
/* harmony import */ var rxjs__WEBPACK_IMPORTED_MODULE_10__ = __webpack_require__(/*! rxjs */ 33900);
/* harmony import */ var rxjs__WEBPACK_IMPORTED_MODULE_11__ = __webpack_require__(/*! rxjs */ 98764);
/* harmony import */ var _unsubscribe_modal_unsubscribe_modal__WEBPACK_IMPORTED_MODULE_12__ = __webpack_require__(/*! ./unsubscribe-modal/unsubscribe.modal */ 887);
/* harmony import */ var src_app_core_shared_rxjs_utils__WEBPACK_IMPORTED_MODULE_13__ = __webpack_require__(/*! src/app/core/shared/rxjs.utils */ 86040);
/* harmony import */ var src_environments_environment__WEBPACK_IMPORTED_MODULE_14__ = __webpack_require__(/*! src/environments/environment */ 45312);
/* harmony import */ var src_app_core_shared_services_error_service__WEBPACK_IMPORTED_MODULE_15__ = __webpack_require__(/*! src/app/core/shared/services/error.service */ 46078);
/* harmony import */ var _companies_modal_companies_modal__WEBPACK_IMPORTED_MODULE_16__ = __webpack_require__(/*! ./companies-modal/companies.modal */ 6167);
/* harmony import */ var lodash_es__WEBPACK_IMPORTED_MODULE_17__ = __webpack_require__(/*! lodash-es */ 24979);
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_18__ = __webpack_require__(/*! @angular/core */ 34205);
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_19__ = __webpack_require__(/*! @angular/core */ 12481);
/* harmony import */ var _angular_router__WEBPACK_IMPORTED_MODULE_20__ = __webpack_require__(/*! @angular/router */ 85422);
/* harmony import */ var _angular_router__WEBPACK_IMPORTED_MODULE_21__ = __webpack_require__(/*! @angular/router */ 34487);
/* harmony import */ var src_app_core_shared_services_campaign_service__WEBPACK_IMPORTED_MODULE_22__ = __webpack_require__(/*! src/app/core/shared/services/campaign.service */ 76658);
/* harmony import */ var src_app_core_shared_services_alert_service__WEBPACK_IMPORTED_MODULE_23__ = __webpack_require__(/*! src/app/core/shared/services/alert.service */ 67406);
/* harmony import */ var src_app_core_shared_services_user_service__WEBPACK_IMPORTED_MODULE_24__ = __webpack_require__(/*! src/app/core/shared/services/user.service */ 89815);
/* harmony import */ var _ionic_angular__WEBPACK_IMPORTED_MODULE_25__ = __webpack_require__(/*! @ionic/angular */ 4059);
/* harmony import */ var _ionic_angular__WEBPACK_IMPORTED_MODULE_26__ = __webpack_require__(/*! @ionic/angular */ 21507);
/* harmony import */ var src_app_core_shared_services_notifications_notifications_service__WEBPACK_IMPORTED_MODULE_27__ = __webpack_require__(/*! src/app/core/shared/services/notifications/notifications.service */ 16095);
/* harmony import */ var src_app_core_shared_services_page_settings_service__WEBPACK_IMPORTED_MODULE_28__ = __webpack_require__(/*! src/app/core/shared/services/page-settings.service */ 40147);
/* harmony import */ var src_app_core_shared_services_team_service__WEBPACK_IMPORTED_MODULE_29__ = __webpack_require__(/*! src/app/core/shared/services/team.service */ 62625);
/* harmony import */ var _angular_common__WEBPACK_IMPORTED_MODULE_30__ = __webpack_require__(/*! @angular/common */ 93683);
/* harmony import */ var _core_shared_layout_header_header_directive__WEBPACK_IMPORTED_MODULE_31__ = __webpack_require__(/*! ../../../core/shared/layout/header/header.directive */ 85039);
/* harmony import */ var _core_shared_layout_content_content_directive__WEBPACK_IMPORTED_MODULE_32__ = __webpack_require__(/*! ../../../core/shared/layout/content/content.directive */ 75855);
/* harmony import */ var _core_shared_directives_parallax_header_directive__WEBPACK_IMPORTED_MODULE_33__ = __webpack_require__(/*! ../../../core/shared/directives/parallax-header.directive */ 56195);
/* harmony import */ var _core_shared_campaigns_app_widget_campaign_app_widget_campaign_component__WEBPACK_IMPORTED_MODULE_34__ = __webpack_require__(/*! ../../../core/shared/campaigns/app-widget-campaign/app-widget-campaign.component */ 91502);
/* harmony import */ var _core_shared_ui_icon_icon_component__WEBPACK_IMPORTED_MODULE_35__ = __webpack_require__(/*! ../../../core/shared/ui/icon/icon.component */ 59621);
/* harmony import */ var _campaign_notification_campaign_notification_component__WEBPACK_IMPORTED_MODULE_36__ = __webpack_require__(/*! ./campaign-notification/campaign-notification.component */ 93797);
/* harmony import */ var _ngx_translate_core__WEBPACK_IMPORTED_MODULE_37__ = __webpack_require__(/*! @ngx-translate/core */ 48503);
/* harmony import */ var _core_shared_pipes_localDate_pipe__WEBPACK_IMPORTED_MODULE_38__ = __webpack_require__(/*! ../../../core/shared/pipes/localDate.pipe */ 86451);
/* harmony import */ var _core_shared_pipes_languageMap_pipe__WEBPACK_IMPORTED_MODULE_39__ = __webpack_require__(/*! ../../../core/shared/pipes/languageMap.pipe */ 69618);

var _staticBlock;




























const _c0 = ["ionContent"];
const _c1 = ["descText"];
const _c2 = a0 => ["/pages/tabs/trips/campaign", a0];
const _c3 = a0 => [a0];
const _c4 = () => ["/pages/tabs/challenges"];
function CampaignDetailsPage_ng_container_0_ion_content_4_ng_container_2_Template(rf, ctx) {
  if (rf & 1) {
    _angular_core__WEBPACK_IMPORTED_MODULE_19__["ɵɵelementContainerStart"](0);
    _angular_core__WEBPACK_IMPORTED_MODULE_19__["ɵɵelement"](1, "app-campaign-notification", 16);
    _angular_core__WEBPACK_IMPORTED_MODULE_19__["ɵɵelementContainerEnd"]();
  }
  if (rf & 2) {
    const notification_r2 = ctx.$implicit;
    const ctx_r2 = _angular_core__WEBPACK_IMPORTED_MODULE_19__["ɵɵnextContext"](3);
    _angular_core__WEBPACK_IMPORTED_MODULE_19__["ɵɵadvance"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_19__["ɵɵproperty"]("campaign", ctx_r2.campaignContainer)("notification", notification_r2);
  }
}
function CampaignDetailsPage_ng_container_0_ion_content_4_ion_card_3_Template(rf, ctx) {
  if (rf & 1) {
    _angular_core__WEBPACK_IMPORTED_MODULE_19__["ɵɵelementStart"](0, "ion-card", 7)(1, "ion-item", 8)(2, "ion-label");
    _angular_core__WEBPACK_IMPORTED_MODULE_19__["ɵɵtext"](3);
    _angular_core__WEBPACK_IMPORTED_MODULE_19__["ɵɵpipe"](4, "translate");
    _angular_core__WEBPACK_IMPORTED_MODULE_19__["ɵɵelementEnd"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_19__["ɵɵelement"](5, "app-icon", 17);
    _angular_core__WEBPACK_IMPORTED_MODULE_19__["ɵɵelementEnd"]()();
  }
  if (rf & 2) {
    const ctx_r2 = _angular_core__WEBPACK_IMPORTED_MODULE_19__["ɵɵnextContext"](3);
    _angular_core__WEBPACK_IMPORTED_MODULE_19__["ɵɵproperty"]("routerLink", ctx_r2.getLeaderboardLink());
    _angular_core__WEBPACK_IMPORTED_MODULE_19__["ɵɵadvance"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_19__["ɵɵproperty"]("color", ctx_r2.campaignContainer == null ? null : ctx_r2.campaignContainer.campaign == null ? null : ctx_r2.campaignContainer.campaign.type);
    _angular_core__WEBPACK_IMPORTED_MODULE_19__["ɵɵadvance"](2);
    _angular_core__WEBPACK_IMPORTED_MODULE_19__["ɵɵtextInterpolate1"]("", _angular_core__WEBPACK_IMPORTED_MODULE_19__["ɵɵpipeBind1"](4, 3, "campaigns.detail.leaderboard"), " ");
  }
}
function CampaignDetailsPage_ng_container_0_ion_content_4_ion_card_4_Template(rf, ctx) {
  if (rf & 1) {
    _angular_core__WEBPACK_IMPORTED_MODULE_19__["ɵɵelementStart"](0, "ion-card", 7)(1, "ion-item", 8)(2, "ion-label");
    _angular_core__WEBPACK_IMPORTED_MODULE_19__["ɵɵtext"](3);
    _angular_core__WEBPACK_IMPORTED_MODULE_19__["ɵɵpipe"](4, "translate");
    _angular_core__WEBPACK_IMPORTED_MODULE_19__["ɵɵelementEnd"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_19__["ɵɵelement"](5, "app-icon", 18);
    _angular_core__WEBPACK_IMPORTED_MODULE_19__["ɵɵelementEnd"]()();
  }
  if (rf & 2) {
    const ctx_r2 = _angular_core__WEBPACK_IMPORTED_MODULE_19__["ɵɵnextContext"](3);
    _angular_core__WEBPACK_IMPORTED_MODULE_19__["ɵɵproperty"]("routerLink", _angular_core__WEBPACK_IMPORTED_MODULE_19__["ɵɵpureFunction1"](5, _c3, "/pages/tabs/home/details/" + ctx_r2.campaignContainer.campaign.campaignId + "/stats"));
    _angular_core__WEBPACK_IMPORTED_MODULE_19__["ɵɵadvance"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_19__["ɵɵproperty"]("color", ctx_r2.campaignContainer == null ? null : ctx_r2.campaignContainer.campaign == null ? null : ctx_r2.campaignContainer.campaign.type);
    _angular_core__WEBPACK_IMPORTED_MODULE_19__["ɵɵadvance"](2);
    _angular_core__WEBPACK_IMPORTED_MODULE_19__["ɵɵtextInterpolate1"]("", _angular_core__WEBPACK_IMPORTED_MODULE_19__["ɵɵpipeBind1"](4, 3, "campaigns.detail.stats"), " ");
  }
}
function CampaignDetailsPage_ng_container_0_ion_content_4_ion_card_5_Template(rf, ctx) {
  if (rf & 1) {
    _angular_core__WEBPACK_IMPORTED_MODULE_19__["ɵɵelementStart"](0, "ion-card", 7)(1, "ion-item", 8)(2, "ion-label");
    _angular_core__WEBPACK_IMPORTED_MODULE_19__["ɵɵtext"](3);
    _angular_core__WEBPACK_IMPORTED_MODULE_19__["ɵɵpipe"](4, "translate");
    _angular_core__WEBPACK_IMPORTED_MODULE_19__["ɵɵelementEnd"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_19__["ɵɵelement"](5, "app-icon", 18);
    _angular_core__WEBPACK_IMPORTED_MODULE_19__["ɵɵelementEnd"]()();
  }
  if (rf & 2) {
    const ctx_r2 = _angular_core__WEBPACK_IMPORTED_MODULE_19__["ɵɵnextContext"](3);
    _angular_core__WEBPACK_IMPORTED_MODULE_19__["ɵɵproperty"]("routerLink", _angular_core__WEBPACK_IMPORTED_MODULE_19__["ɵɵpureFunction1"](5, _c3, "/pages/tabs/home/details/" + ctx_r2.campaignContainer.campaign.campaignId + "/stats-team"));
    _angular_core__WEBPACK_IMPORTED_MODULE_19__["ɵɵadvance"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_19__["ɵɵproperty"]("color", ctx_r2.campaignContainer == null ? null : ctx_r2.campaignContainer.campaign == null ? null : ctx_r2.campaignContainer.campaign.type);
    _angular_core__WEBPACK_IMPORTED_MODULE_19__["ɵɵadvance"](2);
    _angular_core__WEBPACK_IMPORTED_MODULE_19__["ɵɵtextInterpolate1"]("", _angular_core__WEBPACK_IMPORTED_MODULE_19__["ɵɵpipeBind1"](4, 3, "campaigns.detail.statsTeam"), " ");
  }
}
function CampaignDetailsPage_ng_container_0_ion_content_4_ion_card_6_Template(rf, ctx) {
  if (rf & 1) {
    _angular_core__WEBPACK_IMPORTED_MODULE_19__["ɵɵelementStart"](0, "ion-card", 7)(1, "ion-item", 8)(2, "ion-label");
    _angular_core__WEBPACK_IMPORTED_MODULE_19__["ɵɵtext"](3);
    _angular_core__WEBPACK_IMPORTED_MODULE_19__["ɵɵpipe"](4, "translate");
    _angular_core__WEBPACK_IMPORTED_MODULE_19__["ɵɵelementEnd"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_19__["ɵɵelement"](5, "app-icon", 19);
    _angular_core__WEBPACK_IMPORTED_MODULE_19__["ɵɵelementEnd"]()();
  }
  if (rf & 2) {
    const ctx_r2 = _angular_core__WEBPACK_IMPORTED_MODULE_19__["ɵɵnextContext"](3);
    _angular_core__WEBPACK_IMPORTED_MODULE_19__["ɵɵproperty"]("routerLink", _angular_core__WEBPACK_IMPORTED_MODULE_19__["ɵɵpureFunction0"](5, _c4));
    _angular_core__WEBPACK_IMPORTED_MODULE_19__["ɵɵadvance"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_19__["ɵɵproperty"]("color", ctx_r2.campaignContainer == null ? null : ctx_r2.campaignContainer.campaign == null ? null : ctx_r2.campaignContainer.campaign.type);
    _angular_core__WEBPACK_IMPORTED_MODULE_19__["ɵɵadvance"](2);
    _angular_core__WEBPACK_IMPORTED_MODULE_19__["ɵɵtextInterpolate1"]("", _angular_core__WEBPACK_IMPORTED_MODULE_19__["ɵɵpipeBind1"](4, 3, "campaigns.detail.challenges"), " ");
  }
}
function CampaignDetailsPage_ng_container_0_ion_content_4_ion_card_7_Template(rf, ctx) {
  if (rf & 1) {
    _angular_core__WEBPACK_IMPORTED_MODULE_19__["ɵɵelementStart"](0, "ion-card", 7)(1, "ion-item", 8)(2, "ion-label");
    _angular_core__WEBPACK_IMPORTED_MODULE_19__["ɵɵtext"](3);
    _angular_core__WEBPACK_IMPORTED_MODULE_19__["ɵɵpipe"](4, "translate");
    _angular_core__WEBPACK_IMPORTED_MODULE_19__["ɵɵelementEnd"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_19__["ɵɵelement"](5, "app-icon", 20);
    _angular_core__WEBPACK_IMPORTED_MODULE_19__["ɵɵelementEnd"]()();
  }
  if (rf & 2) {
    const ctx_r2 = _angular_core__WEBPACK_IMPORTED_MODULE_19__["ɵɵnextContext"](3);
    _angular_core__WEBPACK_IMPORTED_MODULE_19__["ɵɵproperty"]("routerLink", _angular_core__WEBPACK_IMPORTED_MODULE_19__["ɵɵpureFunction1"](5, _c3, "/pages/tabs/home/details/" + ctx_r2.campaignContainer.campaign.campaignId + "/badges"));
    _angular_core__WEBPACK_IMPORTED_MODULE_19__["ɵɵadvance"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_19__["ɵɵproperty"]("color", ctx_r2.campaignContainer == null ? null : ctx_r2.campaignContainer.campaign == null ? null : ctx_r2.campaignContainer.campaign.type);
    _angular_core__WEBPACK_IMPORTED_MODULE_19__["ɵɵadvance"](2);
    _angular_core__WEBPACK_IMPORTED_MODULE_19__["ɵɵtextInterpolate1"]("", _angular_core__WEBPACK_IMPORTED_MODULE_19__["ɵɵpipeBind1"](4, 3, "campaigns.detail.badges"), " ");
  }
}
function CampaignDetailsPage_ng_container_0_ion_content_4_ion_card_8_Template(rf, ctx) {
  if (rf & 1) {
    _angular_core__WEBPACK_IMPORTED_MODULE_19__["ɵɵelementStart"](0, "ion-card", 7)(1, "ion-item", 8)(2, "ion-label");
    _angular_core__WEBPACK_IMPORTED_MODULE_19__["ɵɵtext"](3);
    _angular_core__WEBPACK_IMPORTED_MODULE_19__["ɵɵpipe"](4, "translate");
    _angular_core__WEBPACK_IMPORTED_MODULE_19__["ɵɵelementEnd"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_19__["ɵɵelement"](5, "ion-icon", 21);
    _angular_core__WEBPACK_IMPORTED_MODULE_19__["ɵɵelementEnd"]()();
  }
  if (rf & 2) {
    const ctx_r2 = _angular_core__WEBPACK_IMPORTED_MODULE_19__["ɵɵnextContext"](3);
    _angular_core__WEBPACK_IMPORTED_MODULE_19__["ɵɵproperty"]("routerLink", _angular_core__WEBPACK_IMPORTED_MODULE_19__["ɵɵpureFunction1"](5, _c3, "/pages/tabs/home/details/" + ctx_r2.campaignContainer.campaign.campaignId + "/prizes"));
    _angular_core__WEBPACK_IMPORTED_MODULE_19__["ɵɵadvance"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_19__["ɵɵproperty"]("color", ctx_r2.campaignContainer == null ? null : ctx_r2.campaignContainer.campaign == null ? null : ctx_r2.campaignContainer.campaign.type);
    _angular_core__WEBPACK_IMPORTED_MODULE_19__["ɵɵadvance"](2);
    _angular_core__WEBPACK_IMPORTED_MODULE_19__["ɵɵtextInterpolate1"]("", _angular_core__WEBPACK_IMPORTED_MODULE_19__["ɵɵpipeBind1"](4, 3, "campaigns.detail.prizes"), " ");
  }
}
function CampaignDetailsPage_ng_container_0_ion_content_4_ion_card_15_Template(rf, ctx) {
  if (rf & 1) {
    _angular_core__WEBPACK_IMPORTED_MODULE_19__["ɵɵelementStart"](0, "ion-card", 7)(1, "ion-item", 8)(2, "ion-label");
    _angular_core__WEBPACK_IMPORTED_MODULE_19__["ɵɵtext"](3);
    _angular_core__WEBPACK_IMPORTED_MODULE_19__["ɵɵpipe"](4, "translate");
    _angular_core__WEBPACK_IMPORTED_MODULE_19__["ɵɵelementEnd"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_19__["ɵɵelement"](5, "app-icon", 22);
    _angular_core__WEBPACK_IMPORTED_MODULE_19__["ɵɵelementEnd"]()();
  }
  if (rf & 2) {
    const ctx_r2 = _angular_core__WEBPACK_IMPORTED_MODULE_19__["ɵɵnextContext"](3);
    _angular_core__WEBPACK_IMPORTED_MODULE_19__["ɵɵproperty"]("routerLink", _angular_core__WEBPACK_IMPORTED_MODULE_19__["ɵɵpureFunction1"](5, _c3, "/pages/blacklist/" + ctx_r2.campaignContainer.campaign.campaignId));
    _angular_core__WEBPACK_IMPORTED_MODULE_19__["ɵɵadvance"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_19__["ɵɵproperty"]("color", ctx_r2.campaignContainer == null ? null : ctx_r2.campaignContainer.campaign == null ? null : ctx_r2.campaignContainer.campaign.type);
    _angular_core__WEBPACK_IMPORTED_MODULE_19__["ɵɵadvance"](2);
    _angular_core__WEBPACK_IMPORTED_MODULE_19__["ɵɵtextInterpolate1"]("", _angular_core__WEBPACK_IMPORTED_MODULE_19__["ɵɵpipeBind1"](4, 3, "campaigns.detail.blacklist"), " ");
  }
}
function CampaignDetailsPage_ng_container_0_ion_content_4_div_26_ion_icon_1_Template(rf, ctx) {
  if (rf & 1) {
    _angular_core__WEBPACK_IMPORTED_MODULE_19__["ɵɵelement"](0, "ion-icon", 26);
  }
}
function CampaignDetailsPage_ng_container_0_ion_content_4_div_26_ion_icon_2_Template(rf, ctx) {
  if (rf & 1) {
    _angular_core__WEBPACK_IMPORTED_MODULE_19__["ɵɵelement"](0, "ion-icon", 27);
  }
}
function CampaignDetailsPage_ng_container_0_ion_content_4_div_26_Template(rf, ctx) {
  if (rf & 1) {
    const _r4 = _angular_core__WEBPACK_IMPORTED_MODULE_19__["ɵɵgetCurrentView"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_19__["ɵɵelementStart"](0, "div", 23);
    _angular_core__WEBPACK_IMPORTED_MODULE_19__["ɵɵlistener"]("click", function CampaignDetailsPage_ng_container_0_ion_content_4_div_26_Template_div_click_0_listener() {
      _angular_core__WEBPACK_IMPORTED_MODULE_18__["ɵɵrestoreView"](_r4);
      const ctx_r2 = _angular_core__WEBPACK_IMPORTED_MODULE_19__["ɵɵnextContext"](3);
      return _angular_core__WEBPACK_IMPORTED_MODULE_18__["ɵɵresetView"](ctx_r2.clickDescription());
    });
    _angular_core__WEBPACK_IMPORTED_MODULE_19__["ɵɵtemplate"](1, CampaignDetailsPage_ng_container_0_ion_content_4_div_26_ion_icon_1_Template, 1, 0, "ion-icon", 24)(2, CampaignDetailsPage_ng_container_0_ion_content_4_div_26_ion_icon_2_Template, 1, 0, "ion-icon", 25);
    _angular_core__WEBPACK_IMPORTED_MODULE_19__["ɵɵelementEnd"]();
  }
  if (rf & 2) {
    const ctx_r2 = _angular_core__WEBPACK_IMPORTED_MODULE_19__["ɵɵnextContext"](3);
    _angular_core__WEBPACK_IMPORTED_MODULE_19__["ɵɵadvance"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_19__["ɵɵproperty"]("ngIf", ctx_r2.descriptionExpanded);
    _angular_core__WEBPACK_IMPORTED_MODULE_19__["ɵɵadvance"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_19__["ɵɵproperty"]("ngIf", !ctx_r2.descriptionExpanded);
  }
}
function CampaignDetailsPage_ng_container_0_ion_content_4_div_27_ng_container_1_div_1_Template(rf, ctx) {
  if (rf & 1) {
    const _r5 = _angular_core__WEBPACK_IMPORTED_MODULE_19__["ɵɵgetCurrentView"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_19__["ɵɵelementStart"](0, "div", 28);
    _angular_core__WEBPACK_IMPORTED_MODULE_19__["ɵɵlistener"]("click", function CampaignDetailsPage_ng_container_0_ion_content_4_div_27_ng_container_1_div_1_Template_div_click_0_listener() {
      _angular_core__WEBPACK_IMPORTED_MODULE_18__["ɵɵrestoreView"](_r5);
      const detail_r6 = _angular_core__WEBPACK_IMPORTED_MODULE_19__["ɵɵnextContext"]().$implicit;
      const ctx_r2 = _angular_core__WEBPACK_IMPORTED_MODULE_19__["ɵɵnextContext"](4);
      return _angular_core__WEBPACK_IMPORTED_MODULE_18__["ɵɵresetView"](ctx_r2.openDetail(detail_r6));
    });
    _angular_core__WEBPACK_IMPORTED_MODULE_19__["ɵɵelementStart"](1, "ion-item", 29)(2, "ion-label")(3, "span", 30);
    _angular_core__WEBPACK_IMPORTED_MODULE_19__["ɵɵtext"](4);
    _angular_core__WEBPACK_IMPORTED_MODULE_19__["ɵɵelementEnd"]()();
    _angular_core__WEBPACK_IMPORTED_MODULE_19__["ɵɵelement"](5, "ion-icon", 31);
    _angular_core__WEBPACK_IMPORTED_MODULE_19__["ɵɵelementEnd"]()();
  }
  if (rf & 2) {
    const detail_r6 = _angular_core__WEBPACK_IMPORTED_MODULE_19__["ɵɵnextContext"]().$implicit;
    _angular_core__WEBPACK_IMPORTED_MODULE_19__["ɵɵadvance"](4);
    _angular_core__WEBPACK_IMPORTED_MODULE_19__["ɵɵtextInterpolate1"](" ", detail_r6.name);
  }
}
function CampaignDetailsPage_ng_container_0_ion_content_4_div_27_ng_container_1_Template(rf, ctx) {
  if (rf & 1) {
    _angular_core__WEBPACK_IMPORTED_MODULE_19__["ɵɵelementContainerStart"](0);
    _angular_core__WEBPACK_IMPORTED_MODULE_19__["ɵɵtemplate"](1, CampaignDetailsPage_ng_container_0_ion_content_4_div_27_ng_container_1_div_1_Template, 6, 1, "div", 15);
    _angular_core__WEBPACK_IMPORTED_MODULE_19__["ɵɵelementContainerEnd"]();
  }
  if (rf & 2) {
    const detail_r6 = ctx.$implicit;
    _angular_core__WEBPACK_IMPORTED_MODULE_19__["ɵɵadvance"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_19__["ɵɵproperty"]("ngIf", detail_r6.type !== "sponsor" && detail_r6.type !== "faq");
  }
}
function CampaignDetailsPage_ng_container_0_ion_content_4_div_27_Template(rf, ctx) {
  if (rf & 1) {
    _angular_core__WEBPACK_IMPORTED_MODULE_19__["ɵɵelementStart"](0, "div");
    _angular_core__WEBPACK_IMPORTED_MODULE_19__["ɵɵtemplate"](1, CampaignDetailsPage_ng_container_0_ion_content_4_div_27_ng_container_1_Template, 2, 1, "ng-container", 5);
    _angular_core__WEBPACK_IMPORTED_MODULE_19__["ɵɵelementEnd"]();
  }
  if (rf & 2) {
    const details_r7 = ctx.ngIf;
    _angular_core__WEBPACK_IMPORTED_MODULE_19__["ɵɵadvance"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_19__["ɵɵproperty"]("ngForOf", details_r7);
  }
}
function CampaignDetailsPage_ng_container_0_ion_content_4_ion_card_29_Template(rf, ctx) {
  if (rf & 1) {
    _angular_core__WEBPACK_IMPORTED_MODULE_19__["ɵɵelementStart"](0, "ion-card", 7)(1, "ion-item", 8)(2, "ion-label");
    _angular_core__WEBPACK_IMPORTED_MODULE_19__["ɵɵtext"](3);
    _angular_core__WEBPACK_IMPORTED_MODULE_19__["ɵɵpipe"](4, "translate");
    _angular_core__WEBPACK_IMPORTED_MODULE_19__["ɵɵelementEnd"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_19__["ɵɵelement"](5, "ion-icon", 32);
    _angular_core__WEBPACK_IMPORTED_MODULE_19__["ɵɵelementEnd"]()();
  }
  if (rf & 2) {
    const ctx_r2 = _angular_core__WEBPACK_IMPORTED_MODULE_19__["ɵɵnextContext"](3);
    _angular_core__WEBPACK_IMPORTED_MODULE_19__["ɵɵproperty"]("routerLink", _angular_core__WEBPACK_IMPORTED_MODULE_19__["ɵɵpureFunction1"](5, _c3, "/pages/tabs/home/details/" + ctx_r2.campaignContainer.campaign.campaignId + "/companies"));
    _angular_core__WEBPACK_IMPORTED_MODULE_19__["ɵɵadvance"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_19__["ɵɵproperty"]("color", ctx_r2.campaignContainer == null ? null : ctx_r2.campaignContainer.campaign == null ? null : ctx_r2.campaignContainer.campaign.type);
    _angular_core__WEBPACK_IMPORTED_MODULE_19__["ɵɵadvance"](2);
    _angular_core__WEBPACK_IMPORTED_MODULE_19__["ɵɵtextInterpolate1"](" ", _angular_core__WEBPACK_IMPORTED_MODULE_19__["ɵɵpipeBind1"](4, 3, "campaigns.detail.companies"));
  }
}
function CampaignDetailsPage_ng_container_0_ion_content_4_ion_card_30_Template(rf, ctx) {
  if (rf & 1) {
    _angular_core__WEBPACK_IMPORTED_MODULE_19__["ɵɵelementStart"](0, "ion-card", 7)(1, "ion-item", 8)(2, "ion-label");
    _angular_core__WEBPACK_IMPORTED_MODULE_19__["ɵɵtext"](3);
    _angular_core__WEBPACK_IMPORTED_MODULE_19__["ɵɵpipe"](4, "translate");
    _angular_core__WEBPACK_IMPORTED_MODULE_19__["ɵɵelementEnd"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_19__["ɵɵelement"](5, "ion-icon", 33);
    _angular_core__WEBPACK_IMPORTED_MODULE_19__["ɵɵelementEnd"]()();
  }
  if (rf & 2) {
    const ctx_r2 = _angular_core__WEBPACK_IMPORTED_MODULE_19__["ɵɵnextContext"](3);
    _angular_core__WEBPACK_IMPORTED_MODULE_19__["ɵɵproperty"]("routerLink", _angular_core__WEBPACK_IMPORTED_MODULE_19__["ɵɵpureFunction1"](5, _c3, "/pages/tabs/home/details/" + ctx_r2.campaignContainer.campaign.campaignId + "/faq"));
    _angular_core__WEBPACK_IMPORTED_MODULE_19__["ɵɵadvance"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_19__["ɵɵproperty"]("color", ctx_r2.campaignContainer == null ? null : ctx_r2.campaignContainer.campaign == null ? null : ctx_r2.campaignContainer.campaign.type);
    _angular_core__WEBPACK_IMPORTED_MODULE_19__["ɵɵadvance"](2);
    _angular_core__WEBPACK_IMPORTED_MODULE_19__["ɵɵtextInterpolate1"](" ", _angular_core__WEBPACK_IMPORTED_MODULE_19__["ɵɵpipeBind1"](4, 3, "campaigns.detail.faq"));
  }
}
function CampaignDetailsPage_ng_container_0_ion_content_4_ion_card_38_Template(rf, ctx) {
  if (rf & 1) {
    _angular_core__WEBPACK_IMPORTED_MODULE_19__["ɵɵelementStart"](0, "ion-card")(1, "ion-card-title")(2, "ion-item", 8)(3, "ion-label");
    _angular_core__WEBPACK_IMPORTED_MODULE_19__["ɵɵtext"](4);
    _angular_core__WEBPACK_IMPORTED_MODULE_19__["ɵɵpipe"](5, "translate");
    _angular_core__WEBPACK_IMPORTED_MODULE_19__["ɵɵelementEnd"]()()();
    _angular_core__WEBPACK_IMPORTED_MODULE_19__["ɵɵelementStart"](6, "ion-card-content");
    _angular_core__WEBPACK_IMPORTED_MODULE_19__["ɵɵelement"](7, "div", 34);
    _angular_core__WEBPACK_IMPORTED_MODULE_19__["ɵɵpipe"](8, "languageMap");
    _angular_core__WEBPACK_IMPORTED_MODULE_19__["ɵɵelementEnd"]()();
  }
  if (rf & 2) {
    let tmp_5_0;
    const ctx_r2 = _angular_core__WEBPACK_IMPORTED_MODULE_19__["ɵɵnextContext"](3);
    _angular_core__WEBPACK_IMPORTED_MODULE_19__["ɵɵadvance"](2);
    _angular_core__WEBPACK_IMPORTED_MODULE_19__["ɵɵproperty"]("color", ctx_r2.campaignContainer == null ? null : ctx_r2.campaignContainer.campaign == null ? null : ctx_r2.campaignContainer.campaign.type);
    _angular_core__WEBPACK_IMPORTED_MODULE_19__["ɵɵadvance"](2);
    _angular_core__WEBPACK_IMPORTED_MODULE_19__["ɵɵtextInterpolate"](_angular_core__WEBPACK_IMPORTED_MODULE_19__["ɵɵpipeBind1"](5, 3, "campaigns.detail.sponsor"));
    _angular_core__WEBPACK_IMPORTED_MODULE_19__["ɵɵadvance"](3);
    _angular_core__WEBPACK_IMPORTED_MODULE_19__["ɵɵproperty"]("innerHTML", (tmp_5_0 = ctx_r2.getCampaignSponsor(_angular_core__WEBPACK_IMPORTED_MODULE_19__["ɵɵpipeBind1"](8, 5, ctx_r2.campaignContainer == null ? null : ctx_r2.campaignContainer.campaign == null ? null : ctx_r2.campaignContainer.campaign.details))) == null ? null : tmp_5_0.content, _angular_core__WEBPACK_IMPORTED_MODULE_19__["ɵɵsanitizeHtml"]);
  }
}
function CampaignDetailsPage_ng_container_0_ion_content_4_ion_card_40_Template(rf, ctx) {
  if (rf & 1) {
    const _r8 = _angular_core__WEBPACK_IMPORTED_MODULE_19__["ɵɵgetCurrentView"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_19__["ɵɵelementStart"](0, "ion-card", 28);
    _angular_core__WEBPACK_IMPORTED_MODULE_19__["ɵɵlistener"]("click", function CampaignDetailsPage_ng_container_0_ion_content_4_ion_card_40_Template_ion_card_click_0_listener() {
      _angular_core__WEBPACK_IMPORTED_MODULE_18__["ɵɵrestoreView"](_r8);
      const ctx_r2 = _angular_core__WEBPACK_IMPORTED_MODULE_19__["ɵɵnextContext"](3);
      return _angular_core__WEBPACK_IMPORTED_MODULE_18__["ɵɵresetView"](ctx_r2.unsubscribeCampaign());
    });
    _angular_core__WEBPACK_IMPORTED_MODULE_19__["ɵɵelementStart"](1, "ion-item", 35)(2, "ion-label");
    _angular_core__WEBPACK_IMPORTED_MODULE_19__["ɵɵtext"](3);
    _angular_core__WEBPACK_IMPORTED_MODULE_19__["ɵɵpipe"](4, "translate");
    _angular_core__WEBPACK_IMPORTED_MODULE_19__["ɵɵelementEnd"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_19__["ɵɵelement"](5, "app-icon", 36);
    _angular_core__WEBPACK_IMPORTED_MODULE_19__["ɵɵelementEnd"]()();
  }
  if (rf & 2) {
    _angular_core__WEBPACK_IMPORTED_MODULE_19__["ɵɵadvance"](3);
    _angular_core__WEBPACK_IMPORTED_MODULE_19__["ɵɵtextInterpolate1"]("", _angular_core__WEBPACK_IMPORTED_MODULE_19__["ɵɵpipeBind1"](4, 1, "campaigns.detail.unsubscribe"), " ");
  }
}
function CampaignDetailsPage_ng_container_0_ion_content_4_Template(rf, ctx) {
  if (rf & 1) {
    const _r1 = _angular_core__WEBPACK_IMPORTED_MODULE_19__["ɵɵgetCurrentView"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_19__["ɵɵelementStart"](0, "ion-content", 3);
    _angular_core__WEBPACK_IMPORTED_MODULE_19__["ɵɵelement"](1, "app-widget-campaign", 4);
    _angular_core__WEBPACK_IMPORTED_MODULE_19__["ɵɵtemplate"](2, CampaignDetailsPage_ng_container_0_ion_content_4_ng_container_2_Template, 2, 2, "ng-container", 5)(3, CampaignDetailsPage_ng_container_0_ion_content_4_ion_card_3_Template, 6, 5, "ion-card", 6)(4, CampaignDetailsPage_ng_container_0_ion_content_4_ion_card_4_Template, 6, 7, "ion-card", 6)(5, CampaignDetailsPage_ng_container_0_ion_content_4_ion_card_5_Template, 6, 7, "ion-card", 6)(6, CampaignDetailsPage_ng_container_0_ion_content_4_ion_card_6_Template, 6, 6, "ion-card", 6)(7, CampaignDetailsPage_ng_container_0_ion_content_4_ion_card_7_Template, 6, 7, "ion-card", 6)(8, CampaignDetailsPage_ng_container_0_ion_content_4_ion_card_8_Template, 6, 7, "ion-card", 6);
    _angular_core__WEBPACK_IMPORTED_MODULE_19__["ɵɵelementStart"](9, "ion-card", 7)(10, "ion-item", 8)(11, "ion-label");
    _angular_core__WEBPACK_IMPORTED_MODULE_19__["ɵɵtext"](12);
    _angular_core__WEBPACK_IMPORTED_MODULE_19__["ɵɵpipe"](13, "translate");
    _angular_core__WEBPACK_IMPORTED_MODULE_19__["ɵɵelementEnd"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_19__["ɵɵelement"](14, "ion-icon", 9);
    _angular_core__WEBPACK_IMPORTED_MODULE_19__["ɵɵelementEnd"]()();
    _angular_core__WEBPACK_IMPORTED_MODULE_19__["ɵɵtemplate"](15, CampaignDetailsPage_ng_container_0_ion_content_4_ion_card_15_Template, 6, 7, "ion-card", 6);
    _angular_core__WEBPACK_IMPORTED_MODULE_19__["ɵɵelementStart"](16, "ion-card")(17, "ion-card-title")(18, "ion-item", 8)(19, "ion-label");
    _angular_core__WEBPACK_IMPORTED_MODULE_19__["ɵɵtext"](20);
    _angular_core__WEBPACK_IMPORTED_MODULE_19__["ɵɵpipe"](21, "translate");
    _angular_core__WEBPACK_IMPORTED_MODULE_19__["ɵɵelementEnd"]()()();
    _angular_core__WEBPACK_IMPORTED_MODULE_19__["ɵɵelementStart"](22, "ion-card-content")(23, "div", 10);
    _angular_core__WEBPACK_IMPORTED_MODULE_19__["ɵɵlistener"]("click", function CampaignDetailsPage_ng_container_0_ion_content_4_Template_div_click_23_listener() {
      _angular_core__WEBPACK_IMPORTED_MODULE_18__["ɵɵrestoreView"](_r1);
      const ctx_r2 = _angular_core__WEBPACK_IMPORTED_MODULE_19__["ɵɵnextContext"](2);
      return _angular_core__WEBPACK_IMPORTED_MODULE_18__["ɵɵresetView"](ctx_r2.clickDescription());
    });
    _angular_core__WEBPACK_IMPORTED_MODULE_19__["ɵɵelement"](24, "div", 11);
    _angular_core__WEBPACK_IMPORTED_MODULE_19__["ɵɵpipe"](25, "languageMap");
    _angular_core__WEBPACK_IMPORTED_MODULE_19__["ɵɵelementEnd"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_19__["ɵɵtemplate"](26, CampaignDetailsPage_ng_container_0_ion_content_4_div_26_Template, 3, 2, "div", 12)(27, CampaignDetailsPage_ng_container_0_ion_content_4_div_27_Template, 2, 1, "div", 0);
    _angular_core__WEBPACK_IMPORTED_MODULE_19__["ɵɵpipe"](28, "languageMap");
    _angular_core__WEBPACK_IMPORTED_MODULE_19__["ɵɵelementEnd"]()();
    _angular_core__WEBPACK_IMPORTED_MODULE_19__["ɵɵtemplate"](29, CampaignDetailsPage_ng_container_0_ion_content_4_ion_card_29_Template, 6, 7, "ion-card", 6)(30, CampaignDetailsPage_ng_container_0_ion_content_4_ion_card_30_Template, 6, 7, "ion-card", 6);
    _angular_core__WEBPACK_IMPORTED_MODULE_19__["ɵɵpipe"](31, "languageMap");
    _angular_core__WEBPACK_IMPORTED_MODULE_19__["ɵɵelementStart"](32, "ion-card")(33, "ion-item", 13);
    _angular_core__WEBPACK_IMPORTED_MODULE_19__["ɵɵlistener"]("click", function CampaignDetailsPage_ng_container_0_ion_content_4_Template_ion_item_click_33_listener() {
      _angular_core__WEBPACK_IMPORTED_MODULE_18__["ɵɵrestoreView"](_r1);
      const ctx_r2 = _angular_core__WEBPACK_IMPORTED_MODULE_19__["ɵɵnextContext"](2);
      return _angular_core__WEBPACK_IMPORTED_MODULE_18__["ɵɵresetView"](ctx_r2.openSupport());
    });
    _angular_core__WEBPACK_IMPORTED_MODULE_19__["ɵɵelementStart"](34, "ion-label");
    _angular_core__WEBPACK_IMPORTED_MODULE_19__["ɵɵtext"](35);
    _angular_core__WEBPACK_IMPORTED_MODULE_19__["ɵɵpipe"](36, "translate");
    _angular_core__WEBPACK_IMPORTED_MODULE_19__["ɵɵelementEnd"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_19__["ɵɵelement"](37, "ion-icon", 14);
    _angular_core__WEBPACK_IMPORTED_MODULE_19__["ɵɵelementEnd"]()();
    _angular_core__WEBPACK_IMPORTED_MODULE_19__["ɵɵtemplate"](38, CampaignDetailsPage_ng_container_0_ion_content_4_ion_card_38_Template, 9, 7, "ion-card", 0);
    _angular_core__WEBPACK_IMPORTED_MODULE_19__["ɵɵpipe"](39, "languageMap");
    _angular_core__WEBPACK_IMPORTED_MODULE_19__["ɵɵtemplate"](40, CampaignDetailsPage_ng_container_0_ion_content_4_ion_card_40_Template, 6, 3, "ion-card", 15);
    _angular_core__WEBPACK_IMPORTED_MODULE_19__["ɵɵelementEnd"]();
  }
  if (rf & 2) {
    const ctx_r2 = _angular_core__WEBPACK_IMPORTED_MODULE_19__["ɵɵnextContext"](2);
    _angular_core__WEBPACK_IMPORTED_MODULE_19__["ɵɵproperty"]("fullscreen", true)("scrollEvents", true);
    _angular_core__WEBPACK_IMPORTED_MODULE_19__["ɵɵadvance"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_19__["ɵɵproperty"]("campaign", ctx_r2.campaignContainer)("header", false);
    _angular_core__WEBPACK_IMPORTED_MODULE_19__["ɵɵadvance"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_19__["ɵɵproperty"]("ngForOf", ctx_r2.unreadNotifications);
    _angular_core__WEBPACK_IMPORTED_MODULE_19__["ɵɵadvance"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_19__["ɵɵproperty"]("ngIf", ctx_r2.campaignHas("leaderboard"));
    _angular_core__WEBPACK_IMPORTED_MODULE_19__["ɵɵadvance"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_19__["ɵɵproperty"]("ngIf", ctx_r2.campaignHas("stats"));
    _angular_core__WEBPACK_IMPORTED_MODULE_19__["ɵɵadvance"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_19__["ɵɵproperty"]("ngIf", ctx_r2.campaignHas("statsTeam"));
    _angular_core__WEBPACK_IMPORTED_MODULE_19__["ɵɵadvance"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_19__["ɵɵproperty"]("ngIf", ctx_r2.campaignHas("challenge"));
    _angular_core__WEBPACK_IMPORTED_MODULE_19__["ɵɵadvance"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_19__["ɵɵproperty"]("ngIf", ctx_r2.campaignHas("badges"));
    _angular_core__WEBPACK_IMPORTED_MODULE_19__["ɵɵadvance"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_19__["ɵɵproperty"]("ngIf", ctx_r2.campaignHas("prizes") && (ctx_r2.campaignContainer == null ? null : ctx_r2.campaignContainer.campaign == null ? null : ctx_r2.campaignContainer.campaign.weekConfs));
    _angular_core__WEBPACK_IMPORTED_MODULE_19__["ɵɵadvance"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_19__["ɵɵproperty"]("routerLink", _angular_core__WEBPACK_IMPORTED_MODULE_19__["ɵɵpureFunction1"](41, _c2, ctx_r2.campaignContainer == null ? null : ctx_r2.campaignContainer.campaign == null ? null : ctx_r2.campaignContainer.campaign.campaignId));
    _angular_core__WEBPACK_IMPORTED_MODULE_19__["ɵɵadvance"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_19__["ɵɵproperty"]("color", ctx_r2.campaignContainer == null ? null : ctx_r2.campaignContainer.campaign == null ? null : ctx_r2.campaignContainer.campaign.type);
    _angular_core__WEBPACK_IMPORTED_MODULE_19__["ɵɵadvance"](2);
    _angular_core__WEBPACK_IMPORTED_MODULE_19__["ɵɵtextInterpolate1"]("", _angular_core__WEBPACK_IMPORTED_MODULE_19__["ɵɵpipeBind1"](13, 27, "campaigns.detail.journeys"), " ");
    _angular_core__WEBPACK_IMPORTED_MODULE_19__["ɵɵadvance"](3);
    _angular_core__WEBPACK_IMPORTED_MODULE_19__["ɵɵproperty"]("ngIf", ctx_r2.campaignHas("blacklist"));
    _angular_core__WEBPACK_IMPORTED_MODULE_19__["ɵɵadvance"](3);
    _angular_core__WEBPACK_IMPORTED_MODULE_19__["ɵɵproperty"]("color", ctx_r2.campaignContainer == null ? null : ctx_r2.campaignContainer.campaign == null ? null : ctx_r2.campaignContainer.campaign.type);
    _angular_core__WEBPACK_IMPORTED_MODULE_19__["ɵɵadvance"](2);
    _angular_core__WEBPACK_IMPORTED_MODULE_19__["ɵɵtextInterpolate"](_angular_core__WEBPACK_IMPORTED_MODULE_19__["ɵɵpipeBind1"](21, 29, "campaigns.detail.details"));
    _angular_core__WEBPACK_IMPORTED_MODULE_19__["ɵɵadvance"](3);
    _angular_core__WEBPACK_IMPORTED_MODULE_19__["ɵɵproperty"]("ngClass", ctx_r2.descriptionExpanded ? "open" : "");
    _angular_core__WEBPACK_IMPORTED_MODULE_19__["ɵɵadvance"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_19__["ɵɵproperty"]("innerHTML", _angular_core__WEBPACK_IMPORTED_MODULE_19__["ɵɵpipeBind1"](25, 31, ctx_r2.campaignContainer == null ? null : ctx_r2.campaignContainer.campaign == null ? null : ctx_r2.campaignContainer.campaign.description), _angular_core__WEBPACK_IMPORTED_MODULE_19__["ɵɵsanitizeHtml"]);
    _angular_core__WEBPACK_IMPORTED_MODULE_19__["ɵɵadvance"](2);
    _angular_core__WEBPACK_IMPORTED_MODULE_19__["ɵɵproperty"]("ngIf", ctx_r2.descriptionExpanded || ctx_r2.isTextOverflow("descText"));
    _angular_core__WEBPACK_IMPORTED_MODULE_19__["ɵɵadvance"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_19__["ɵɵproperty"]("ngIf", _angular_core__WEBPACK_IMPORTED_MODULE_19__["ɵɵpipeBind1"](28, 33, ctx_r2.campaignContainer == null ? null : ctx_r2.campaignContainer.campaign == null ? null : ctx_r2.campaignContainer.campaign.details));
    _angular_core__WEBPACK_IMPORTED_MODULE_19__["ɵɵadvance"](2);
    _angular_core__WEBPACK_IMPORTED_MODULE_19__["ɵɵproperty"]("ngIf", ctx_r2.campaignHas("companies") && (ctx_r2.campaignContainer == null ? null : ctx_r2.campaignContainer.campaign == null ? null : ctx_r2.campaignContainer.campaign.specificData.hideCompanyDesc) !== true);
    _angular_core__WEBPACK_IMPORTED_MODULE_19__["ɵɵadvance"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_19__["ɵɵproperty"]("ngIf", ctx_r2.campaignHasFAQ(_angular_core__WEBPACK_IMPORTED_MODULE_19__["ɵɵpipeBind1"](31, 35, ctx_r2.campaignContainer == null ? null : ctx_r2.campaignContainer.campaign == null ? null : ctx_r2.campaignContainer.campaign.details)));
    _angular_core__WEBPACK_IMPORTED_MODULE_19__["ɵɵadvance"](3);
    _angular_core__WEBPACK_IMPORTED_MODULE_19__["ɵɵproperty"]("color", ctx_r2.campaignContainer == null ? null : ctx_r2.campaignContainer.campaign == null ? null : ctx_r2.campaignContainer.campaign.type);
    _angular_core__WEBPACK_IMPORTED_MODULE_19__["ɵɵadvance"](2);
    _angular_core__WEBPACK_IMPORTED_MODULE_19__["ɵɵtextInterpolate1"]("", _angular_core__WEBPACK_IMPORTED_MODULE_19__["ɵɵpipeBind1"](36, 37, "campaigns.detail.signal"), " ");
    _angular_core__WEBPACK_IMPORTED_MODULE_19__["ɵɵadvance"](3);
    _angular_core__WEBPACK_IMPORTED_MODULE_19__["ɵɵproperty"]("ngIf", ctx_r2.campaignHasSponsor(_angular_core__WEBPACK_IMPORTED_MODULE_19__["ɵɵpipeBind1"](39, 39, ctx_r2.campaignContainer == null ? null : ctx_r2.campaignContainer.campaign == null ? null : ctx_r2.campaignContainer.campaign.details)));
    _angular_core__WEBPACK_IMPORTED_MODULE_19__["ɵɵadvance"](2);
    _angular_core__WEBPACK_IMPORTED_MODULE_19__["ɵɵproperty"]("ngIf", !ctx_r2.isPersonal() && !ctx_r2.isSchool());
  }
}
function CampaignDetailsPage_ng_container_0_Template(rf, ctx) {
  if (rf & 1) {
    _angular_core__WEBPACK_IMPORTED_MODULE_19__["ɵɵelementContainerStart"](0);
    _angular_core__WEBPACK_IMPORTED_MODULE_19__["ɵɵelement"](1, "ion-header", 1);
    _angular_core__WEBPACK_IMPORTED_MODULE_19__["ɵɵpipe"](2, "localDate");
    _angular_core__WEBPACK_IMPORTED_MODULE_19__["ɵɵpipe"](3, "localDate");
    _angular_core__WEBPACK_IMPORTED_MODULE_19__["ɵɵtemplate"](4, CampaignDetailsPage_ng_container_0_ion_content_4_Template, 41, 43, "ion-content", 2);
    _angular_core__WEBPACK_IMPORTED_MODULE_19__["ɵɵelementContainerEnd"]();
  }
  if (rf & 2) {
    const ctx_r2 = _angular_core__WEBPACK_IMPORTED_MODULE_19__["ɵɵnextContext"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_19__["ɵɵadvance"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_19__["ɵɵproperty"]("text", _angular_core__WEBPACK_IMPORTED_MODULE_19__["ɵɵinterpolate2"]("", _angular_core__WEBPACK_IMPORTED_MODULE_19__["ɵɵpipeBind2"](2, 6, ctx_r2.campaignContainer == null ? null : ctx_r2.campaignContainer.campaign == null ? null : ctx_r2.campaignContainer.campaign.dateFrom, "dd MMMM y"), " - ", _angular_core__WEBPACK_IMPORTED_MODULE_19__["ɵɵpipeBind2"](3, 9, ctx_r2.campaignContainer == null ? null : ctx_r2.campaignContainer.campaign == null ? null : ctx_r2.campaignContainer.campaign.dateTo, "dd MMMM y")))("imageUrl", ctx_r2.campaignContainer == null ? null : ctx_r2.campaignContainer.campaign == null ? null : ctx_r2.campaignContainer.campaign.banner == null ? null : ctx_r2.campaignContainer.campaign.banner.url)("logo", ctx_r2.imagePath);
    _angular_core__WEBPACK_IMPORTED_MODULE_19__["ɵɵadvance"](3);
    _angular_core__WEBPACK_IMPORTED_MODULE_19__["ɵɵproperty"]("ngIf", ctx_r2.campaignContainer);
  }
}
class CampaignDetailsPage {
  constructor(route, campaignService, alertService, userService, navCtrl, modalController, notificationService, pageSettingsService, errorService, teamService) {
    this.route = route;
    this.campaignService = campaignService;
    this.alertService = alertService;
    this.userService = userService;
    this.navCtrl = navCtrl;
    this.modalController = modalController;
    this.notificationService = notificationService;
    this.pageSettingsService = pageSettingsService;
    this.errorService = errorService;
    this.teamService = teamService;
    this.titlePage = '';
    this.colorCampaign = null;
    this.isDestroyed$ = new rxjs__WEBPACK_IMPORTED_MODULE_2__.Subject();
    this.unreadNotifications = [];
    this.descriptionExpanded = false;
    this.campaignId$ = this.route.params.pipe((0,rxjs__WEBPACK_IMPORTED_MODULE_7__.map)(params => params.id), (0,rxjs__WEBPACK_IMPORTED_MODULE_6__.distinctUntilChanged)(), (0,rxjs__WEBPACK_IMPORTED_MODULE_8__.shareReplay)(1));
    this.playerCampaign$ = this.campaignId$.pipe((0,rxjs__WEBPACK_IMPORTED_MODULE_9__.switchMap)(campaignId => this.campaignService.myCampaigns$.pipe((0,rxjs__WEBPACK_IMPORTED_MODULE_7__.map)(campaigns => (0,lodash_es__WEBPACK_IMPORTED_MODULE_17__["default"])(campaigns, playercampaign => playercampaign.subscription.campaignId === campaignId)), (0,rxjs__WEBPACK_IMPORTED_MODULE_11__.tap)(campaigns => console.log(campaigns)),
    // throwIfNil(() => new Error('Campaign not found')),
    this.errorService.getErrorHandler())), (0,rxjs__WEBPACK_IMPORTED_MODULE_11__.tap)(campaign => console.log('playercampaign' + campaign)), (0,rxjs__WEBPACK_IMPORTED_MODULE_8__.shareReplay)(1));
    this.teamId$ = this.playerCampaign$.pipe((0,rxjs__WEBPACK_IMPORTED_MODULE_7__.map)(campaign => {
      console.log(campaign);
      return campaign?.subscription?.campaignData?.teamId;
    }), (0,rxjs__WEBPACK_IMPORTED_MODULE_11__.tap)(team => console.log(team)), (0,rxjs__WEBPACK_IMPORTED_MODULE_8__.shareReplay)(1));
    this.route.params.subscribe(params => this.id = params.id);
  }
  ngOnDestroy() {
    this.isDestroyed$.next();
    this.isDestroyed$.complete();
  }
  ionViewDidLeave() {
    this.subStat?.unsubscribe();
    this.myCampaignSub?.unsubscribe();
  }
  ngAfterViewChecked() {
    if (this.descText?.nativeElement) {
      console.log(this.descText.nativeElement.offsetHeight < this.descText.nativeElement.scrollHeight || this.descText.nativeElement.offsetWidth < this.descText.nativeElement.scrollWidth);
      return this.descText.nativeElement.offsetHeight < this.descText.nativeElement.scrollHeight || this.descText.nativeElement.offsetWidth < this.descText.nativeElement.scrollWidth;
    }
    return false;
  }
  ngOnInit() {
    this.subTeam = (0,rxjs__WEBPACK_IMPORTED_MODULE_3__.combineLatest)([this.campaignId$, this.teamId$]).pipe((0,rxjs__WEBPACK_IMPORTED_MODULE_9__.switchMap)(([campaignId, teamId]) => teamId ? this.teamService.getMyTeam(campaignId, teamId) : rxjs__WEBPACK_IMPORTED_MODULE_5__.EMPTY), this.errorService.getErrorHandler()).subscribe(team => this.team = team);
    this.subStat = this.userService.userProfile$.subscribe(profile => {
      this.profile = profile;
    });
    this.language = this.userService.getLanguage();
    this.notificationService.getUnreadCampaignNotifications(this.id).pipe((0,rxjs__WEBPACK_IMPORTED_MODULE_10__.takeUntil)(this.isDestroyed$)).subscribe(notifications => {
      this.unreadNotifications = notifications;
    });
    this.myCampaignSub = this.campaignService.myCampaigns$.pipe((0,rxjs__WEBPACK_IMPORTED_MODULE_10__.takeUntil)(this.isDestroyed$), (0,rxjs__WEBPACK_IMPORTED_MODULE_9__.switchMap)(campaigns => {
      const campaignContainer = campaigns.find(eachCampaignContainer => eachCampaignContainer.campaign.campaignId === this.id);
      if (campaignContainer) {
        return (0,rxjs__WEBPACK_IMPORTED_MODULE_4__.of)(campaignContainer);
      } else {
        return this.campaignService.getCampaignDetailsById(this.id).pipe((0,src_app_core_shared_rxjs_utils__WEBPACK_IMPORTED_MODULE_13__.throwIfNil)(() => new src_app_core_shared_services_error_service__WEBPACK_IMPORTED_MODULE_15__.UserError({
          id: 'campaign-not-found',
          message: 'campaigns.detail.not_found'
        })), (0,rxjs__WEBPACK_IMPORTED_MODULE_7__.map)(campaign => ({
          campaign,
          player: null
        })), this.errorService.getErrorHandler('normal'));
      }
    })).subscribe(campaignContainer => {
      this.campaignContainer = campaignContainer;
      this.titlePage = this.campaignContainer?.campaign?.name[this.language];
      this.colorCampaign = this.campaignContainer?.campaign?.type;
      this.imagePath = this.campaignContainer?.campaign?.logo.url ? this.campaignContainer?.campaign?.logo.url : 'data:image/jpg;base64,' + this.campaignContainer?.campaign?.logo.image;
      this.changePageSettings();
    });
  }
  ionViewWillEnter() {
    this.changePageSettings();
  }
  changePageSettings() {
    this.pageSettingsService.set({
      color: this.colorCampaign,
      // FIXME: ! title is already translated!
      title: this.titlePage
    });
  }
  openDetail(detail) {
    var _this = this;
    return (0,_Users_smartcommunitylab_Desktop_newWork_playAndGo_playGo_node_modules_babel_runtime_helpers_esm_asyncToGenerator_js__WEBPACK_IMPORTED_MODULE_0__["default"])(function* () {
      const modal = yield _this.modalController.create({
        component: _detail_modal_detail_modal__WEBPACK_IMPORTED_MODULE_1__.DetailCampaignModalPage,
        cssClass: 'modalInfo',
        componentProps: {
          detail,
          type: _this.campaignContainer?.campaign?.type
        }
      });
      yield modal.present();
      yield modal.onWillDismiss();
    })();
  }
  openCompanies() {
    var _this2 = this;
    return (0,_Users_smartcommunitylab_Desktop_newWork_playAndGo_playGo_node_modules_babel_runtime_helpers_esm_asyncToGenerator_js__WEBPACK_IMPORTED_MODULE_0__["default"])(function* () {
      const modal = yield _this2.modalController.create({
        component: _companies_modal_companies_modal__WEBPACK_IMPORTED_MODULE_16__.CompaniesCampaignModalPage,
        cssClass: 'modalConfirm',
        componentProps: {
          campaign: _this2.campaignContainer.campaign
        }
      });
      yield modal.present();
      yield modal.onWillDismiss();
    })();
  }
  getCampaignSponsor(details) {
    return details.filter(detail => detail.type === 'sponsor')[0];
  }
  campaignHasSponsor(details) {
    return details.filter(detail => detail.type === 'sponsor').length > 0;
  }
  getCampaignFAQ(details) {
    return details.filter(detail => detail.type === 'faq')[0];
  }
  campaignHasFAQ(details) {
    return details.filter(detail => detail.type === 'faq').length > 0;
  }
  clickDescription() {
    if (this.isTextOverflow('descText') || this.descriptionExpanded) {
      this.descriptionExpanded = !this.descriptionExpanded;
    }
  }
  getCampaign() {
    return JSON.stringify(this.campaignContainer.campaign);
  }
  isPersonal() {
    return this.campaignContainer.campaign.type === 'personal';
  }
  isCompany() {
    return this.campaignContainer.campaign.type === 'company';
  }
  isSchool() {
    return this.campaignContainer.campaign.type === 'school';
  }
  getLeaderboardLink() {
    const isSchool = this.campaignContainer.campaign.type === 'school';
    const page = isSchool ? 'school-leaderboard' : 'leaderboard';
    const campaignId = this.campaignContainer.campaign.campaignId;
    return [`/pages/tabs/home/details/${campaignId}/${page}`];
  }
  campaignHas(what) {
    return this.campaignService.getFunctionalityByType(what, this.campaignContainer.campaign.type)?.present || false || what === 'leaderboard' && this.campaignHasPlacement(this.campaignContainer.campaign);
  }
  campaignHasPlacement(campaign) {
    return campaign.type === 'company' && campaign.campaignPlacement?.active;
  }
  unsubscribeCampaign() {
    var _this3 = this;
    return (0,_Users_smartcommunitylab_Desktop_newWork_playAndGo_playGo_node_modules_babel_runtime_helpers_esm_asyncToGenerator_js__WEBPACK_IMPORTED_MODULE_0__["default"])(function* () {
      const modal = yield _this3.modalController.create({
        component: _unsubscribe_modal_unsubscribe_modal__WEBPACK_IMPORTED_MODULE_12__.UnsubscribeModalPage,
        cssClass: 'modal-challenge',
        canDismiss: true
      });
      yield modal.present();
      const {
        data
      } = yield modal.onWillDismiss();
      if (data) {
        _this3.unsubSub = _this3.campaignService.unsubscribeCampaign(_this3.campaignContainer.campaign.campaignId).subscribe(result => {
          _this3.alertService.showToast({
            messageTranslateKey: 'campaigns.unregistered'
          });
          _this3.subStat?.unsubscribe();
          _this3.myCampaignSub?.unsubscribe();
          _this3.navCtrl.navigateRoot('/pages/tabs/home');
        });
      }
    })();
  }
  back() {
    this.navCtrl.back();
  }
  isTextOverflow(elementId) {
    const elem = document.getElementById(elementId);
    if (elem) {
      return elem.offsetHeight < elem.scrollHeight;
    } else {
      return false;
    }
  }
  openSupport() {
    window.open('mailto:' + src_environments_environment__WEBPACK_IMPORTED_MODULE_14__.environment.support.email + '?subject=Play%26go%20' + this.campaignContainer?.campaign?.name.it + '%20Supporto&body=-----------NON CANCELLARE-----------%0D%0A%0D%0A' + 'territoryId: ' + this.profile.territoryId + '%0D%0Acampagna: ' + this.campaignContainer?.campaign?.campaignId + (this.campaignContainer?.campaign?.type === 'school' ? '%0D%0Ateam: ' + this.team?.customData?.name : '') + '%0D%0AplayerId: ' + this.profile.playerId + '%0D%0A%0D%0A-----SCRIVI IL TUO MESSAGGIO QUI SOTTO----');
    // territorio, campagna, nome squadra, ID utente (Oggetto: "Play&go <nome campagna> Supporto"
  }
  static #_ = _staticBlock = () => (this.ɵfac = function CampaignDetailsPage_Factory(__ngFactoryType__) {
    return new (__ngFactoryType__ || CampaignDetailsPage)(_angular_core__WEBPACK_IMPORTED_MODULE_19__["ɵɵdirectiveInject"](_angular_router__WEBPACK_IMPORTED_MODULE_20__.ActivatedRoute), _angular_core__WEBPACK_IMPORTED_MODULE_19__["ɵɵdirectiveInject"](src_app_core_shared_services_campaign_service__WEBPACK_IMPORTED_MODULE_22__.CampaignService), _angular_core__WEBPACK_IMPORTED_MODULE_19__["ɵɵdirectiveInject"](src_app_core_shared_services_alert_service__WEBPACK_IMPORTED_MODULE_23__.AlertService), _angular_core__WEBPACK_IMPORTED_MODULE_19__["ɵɵdirectiveInject"](src_app_core_shared_services_user_service__WEBPACK_IMPORTED_MODULE_24__.UserService), _angular_core__WEBPACK_IMPORTED_MODULE_19__["ɵɵdirectiveInject"](_ionic_angular__WEBPACK_IMPORTED_MODULE_25__.NavController), _angular_core__WEBPACK_IMPORTED_MODULE_19__["ɵɵdirectiveInject"](_ionic_angular__WEBPACK_IMPORTED_MODULE_26__.ModalController), _angular_core__WEBPACK_IMPORTED_MODULE_19__["ɵɵdirectiveInject"](src_app_core_shared_services_notifications_notifications_service__WEBPACK_IMPORTED_MODULE_27__.NotificationService), _angular_core__WEBPACK_IMPORTED_MODULE_19__["ɵɵdirectiveInject"](src_app_core_shared_services_page_settings_service__WEBPACK_IMPORTED_MODULE_28__.PageSettingsService), _angular_core__WEBPACK_IMPORTED_MODULE_19__["ɵɵdirectiveInject"](src_app_core_shared_services_error_service__WEBPACK_IMPORTED_MODULE_15__.ErrorService), _angular_core__WEBPACK_IMPORTED_MODULE_19__["ɵɵdirectiveInject"](src_app_core_shared_services_team_service__WEBPACK_IMPORTED_MODULE_29__.TeamService));
  }, this.ɵcmp = /*@__PURE__*/_angular_core__WEBPACK_IMPORTED_MODULE_19__["ɵɵdefineComponent"]({
    type: CampaignDetailsPage,
    selectors: [["app-campaign-details"]],
    viewQuery: function CampaignDetailsPage_Query(rf, ctx) {
      if (rf & 1) {
        _angular_core__WEBPACK_IMPORTED_MODULE_19__["ɵɵviewQuery"](_c0, 5);
        _angular_core__WEBPACK_IMPORTED_MODULE_19__["ɵɵviewQuery"](_c1, 5);
      }
      if (rf & 2) {
        let _t;
        _angular_core__WEBPACK_IMPORTED_MODULE_19__["ɵɵqueryRefresh"](_t = _angular_core__WEBPACK_IMPORTED_MODULE_19__["ɵɵloadQuery"]()) && (ctx.ionContent = _t.first);
        _angular_core__WEBPACK_IMPORTED_MODULE_19__["ɵɵqueryRefresh"](_t = _angular_core__WEBPACK_IMPORTED_MODULE_19__["ɵɵloadQuery"]()) && (ctx.descText = _t.first);
      }
    },
    standalone: false,
    decls: 1,
    vars: 1,
    consts: [[4, "ngIf"], ["mode", "ios", "appHeader", "", "parallax", "", "height", "30vh", 3, "imageUrl", "text", "logo"], ["appContent", "", "class", "page", 3, "fullscreen", "scrollEvents", 4, "ngIf"], ["appContent", "", 1, "page", 3, "fullscreen", "scrollEvents"], [3, "campaign", "header"], [4, "ngFor", "ngForOf"], [3, "routerLink", 4, "ngIf"], [3, "routerLink"], [3, "color"], ["name", "list", 1, "icon-size-normal"], [1, "box", 3, "click", "ngClass"], ["id", "descText", 1, "text", 3, "innerHTML"], ["class", "expansion", 3, "click", 4, "ngIf"], [3, "click", "color"], ["name", "mail-outline", "end", ""], [3, "click", 4, "ngIf"], [3, "campaign", "notification"], ["name", "leaderboard", 1, "icon-size-normal"], ["name", "stat", 1, "icon-size-normal"], ["name", "default", 1, "icon-size-normal"], ["name", "badges", 1, "icon-size-normal"], ["name", "gift", 1, "icon-size-normal"], ["name", "blacklist", 1, "icon-size-normal"], [1, "expansion", 3, "click"], ["name", "chevron-up-outline", 4, "ngIf"], ["name", "chevron-down-outline", 4, "ngIf"], ["name", "chevron-up-outline"], ["name", "chevron-down-outline"], [3, "click"], ["lines", "none"], [1, "text-bold", "text-underlined"], ["name", "information-circle-outline", "end", ""], ["name", "list", "end", ""], ["name", "help-circle-outline", "end", ""], [3, "innerHTML"], ["color", "danger"], ["name", "leave", 1, "icon-size-normal"]],
    template: function CampaignDetailsPage_Template(rf, ctx) {
      if (rf & 1) {
        _angular_core__WEBPACK_IMPORTED_MODULE_19__["ɵɵtemplate"](0, CampaignDetailsPage_ng_container_0_Template, 5, 12, "ng-container", 0);
      }
      if (rf & 2) {
        _angular_core__WEBPACK_IMPORTED_MODULE_19__["ɵɵproperty"]("ngIf", ctx.campaignContainer);
      }
    },
    dependencies: [_angular_router__WEBPACK_IMPORTED_MODULE_21__.RouterLink, _angular_common__WEBPACK_IMPORTED_MODULE_30__.NgClass, _angular_common__WEBPACK_IMPORTED_MODULE_30__.NgForOf, _angular_common__WEBPACK_IMPORTED_MODULE_30__.NgIf, _ionic_angular__WEBPACK_IMPORTED_MODULE_26__.IonCard, _ionic_angular__WEBPACK_IMPORTED_MODULE_26__.IonCardContent, _ionic_angular__WEBPACK_IMPORTED_MODULE_26__.IonCardTitle, _ionic_angular__WEBPACK_IMPORTED_MODULE_26__.IonContent, _ionic_angular__WEBPACK_IMPORTED_MODULE_26__.IonHeader, _ionic_angular__WEBPACK_IMPORTED_MODULE_26__.IonIcon, _ionic_angular__WEBPACK_IMPORTED_MODULE_26__.IonItem, _ionic_angular__WEBPACK_IMPORTED_MODULE_26__.IonLabel, _ionic_angular__WEBPACK_IMPORTED_MODULE_26__.RouterLinkDelegate, _core_shared_layout_header_header_directive__WEBPACK_IMPORTED_MODULE_31__.HeaderDirective, _core_shared_layout_content_content_directive__WEBPACK_IMPORTED_MODULE_32__.ContentDirective, _core_shared_directives_parallax_header_directive__WEBPACK_IMPORTED_MODULE_33__.ParallaxDirective, _core_shared_campaigns_app_widget_campaign_app_widget_campaign_component__WEBPACK_IMPORTED_MODULE_34__.WidgetComponent, _core_shared_ui_icon_icon_component__WEBPACK_IMPORTED_MODULE_35__.IconComponent, _campaign_notification_campaign_notification_component__WEBPACK_IMPORTED_MODULE_36__.CampaignNotificationComponent, _ngx_translate_core__WEBPACK_IMPORTED_MODULE_37__.TranslatePipe, _core_shared_pipes_localDate_pipe__WEBPACK_IMPORTED_MODULE_38__.LocalDatePipe, _core_shared_pipes_languageMap_pipe__WEBPACK_IMPORTED_MODULE_39__.LanguageMapPipe],
    styles: [".avatar-campaign[_ngcontent-%COMP%] {\n  margin: 16px auto;\n}\n\n.expansion[_ngcontent-%COMP%] {\n  text-align: center;\n  font-size: xx-large;\n}\n\n\n\n.box[_ngcontent-%COMP%] {\n  max-height: 162px;\n  overflow: hidden;\n  transition: max-height 0.3s cubic-bezier(0, 1, 0, 1);\n}\n\nion-card[_ngcontent-%COMP%] {\n  margin-top: 40px;\n}\nion-card[_ngcontent-%COMP%]   ion-card-title[_ngcontent-%COMP%] {\n  font-weight: 600;\n}\nion-card[_ngcontent-%COMP%]   ion-item[_ngcontent-%COMP%]   ion-label[_ngcontent-%COMP%] {\n  font-weight: 600;\n}\n\n.box.open[_ngcontent-%COMP%] {\n  max-height: 100rem;\n  transition: max-height 0.3s cubic-bezier(0.9, 0, 0.8, 0.2);\n}\n\n.text[_ngcontent-%COMP%] {\n  display: -webkit-box;\n  -webkit-box-orient: vertical;\n  padding: 2px;\n  text-overflow: ellipsis;\n  overflow: hidden;\n  margin: 12px 0;\n  animation: _ngcontent-%COMP%_close 0.1s linear 0.1s forwards;\n}\n\n.open[_ngcontent-%COMP%]   .text[_ngcontent-%COMP%] {\n  animation: _ngcontent-%COMP%_open 0.1s linear 0s forwards;\n}\n\n\n\n@keyframes _ngcontent-%COMP%_open {\n  from {\n    display: -webkit-box;\n    line-clamp: 3;\n    -webkit-line-clamp: 3;\n    -webkit-box-orient: vertical;\n  }\n  to {\n    display: -webkit-box;\n    line-clamp: initial;\n    -webkit-line-clamp: initial;\n    -webkit-box-orient: vertical;\n  }\n}\n@keyframes _ngcontent-%COMP%_close {\n  from {\n    display: -webkit-box;\n    line-clamp: initial;\n    -webkit-line-clamp: initial;\n    -webkit-box-orient: vertical;\n  }\n  to {\n    display: -webkit-box;\n    line-clamp: 3;\n    -webkit-line-clamp: 3;\n    -webkit-box-orient: vertical;\n  }\n}\n/*# sourceMappingURL=data:application/json;charset=utf-8;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbIndlYnBhY2s6Ly8uL3NyYy9hcHAvcGFnZXMvaG9tZS9jYW1wYWlnbi1kZXRhaWxzL2NhbXBhaWduLWRldGFpbHMucGFnZS5zY3NzIl0sIm5hbWVzIjpbXSwibWFwcGluZ3MiOiJBQUFBO0VBQ0UsaUJBQUE7QUFDRjs7QUFDQTtFQUNFLGtCQUFBO0VBQ0EsbUJBQUE7QUFFRjs7QUFBQSxRQUFBO0FBQ0E7RUFJRSxpQkFBQTtFQUNBLGdCQUFBO0VBQ0Esb0RBQUE7QUFBRjs7QUFFQTtFQUNFLGdCQUFBO0FBQ0Y7QUFBRTtFQUNFLGdCQUFBO0FBRUo7QUFDSTtFQUNFLGdCQUFBO0FBQ047O0FBSUE7RUFDRSxrQkFBQTtFQUNBLDBEQUFBO0FBREY7O0FBR0E7RUFDRSxvQkFBQTtFQUNBLDRCQUFBO0VBQ0EsWUFBQTtFQUNBLHVCQUFBO0VBQ0EsZ0JBQUE7RUFDQSxjQUFBO0VBQ0EsMENBQUE7QUFBRjs7QUFFQTtFQUNFLHVDQUFBO0FBQ0Y7O0FBRUEsU0FBQTtBQUNBO0VBQ0U7SUFDRSxvQkFBQTtJQUNBLGFBQUE7SUFDQSxxQkFBQTtJQUNBLDRCQUFBO0VBQ0Y7RUFDQTtJQUNFLG9CQUFBO0lBQ0EsbUJBQUE7SUFDQSwyQkFBQTtJQUNBLDRCQUFBO0VBQ0Y7QUFDRjtBQUVBO0VBQ0U7SUFDRSxvQkFBQTtJQUNBLG1CQUFBO0lBQ0EsMkJBQUE7SUFDQSw0QkFBQTtFQUFGO0VBRUE7SUFDRSxvQkFBQTtJQUNBLGFBQUE7SUFDQSxxQkFBQTtJQUNBLDRCQUFBO0VBQUY7QUFDRiIsInNvdXJjZXNDb250ZW50IjpbIi5hdmF0YXItY2FtcGFpZ24ge1xuICBtYXJnaW46IDE2cHggYXV0bztcbn1cbi5leHBhbnNpb24ge1xuICB0ZXh0LWFsaWduOiBjZW50ZXI7XG4gIGZvbnQtc2l6ZTogeHgtbGFyZ2U7XG59XG4vKiBCb3ggKi9cbi5ib3gge1xuICAvLyBtYXJnaW46IDIycHggYXV0bztcbiAgLy8gd2lkdGg6IDMyMHB4O1xuICAvLyBwYWRkaW5nOiAxMnB4IDMycHggNjRweDtcbiAgbWF4LWhlaWdodDogMTYycHg7XG4gIG92ZXJmbG93OiBoaWRkZW47XG4gIHRyYW5zaXRpb246IG1heC1oZWlnaHQgMC4zcyBjdWJpYy1iZXppZXIoMCwgMSwgMCwgMSk7XG59XG5pb24tY2FyZCB7XG4gIG1hcmdpbi10b3A6IDQwcHg7XG4gIGlvbi1jYXJkLXRpdGxlIHtcbiAgICBmb250LXdlaWdodDogNjAwO1xuICB9XG4gIGlvbi1pdGVtIHtcbiAgICBpb24tbGFiZWwge1xuICAgICAgZm9udC13ZWlnaHQ6IDYwMDtcbiAgICB9XG4gIH1cbn1cblxuLmJveC5vcGVuIHtcbiAgbWF4LWhlaWdodDogMTAwcmVtO1xuICB0cmFuc2l0aW9uOiBtYXgtaGVpZ2h0IDAuM3MgY3ViaWMtYmV6aWVyKDAuOSwgMCwgMC44LCAwLjIpO1xufVxuLnRleHQge1xuICBkaXNwbGF5OiAtd2Via2l0LWJveDtcbiAgLXdlYmtpdC1ib3gtb3JpZW50OiB2ZXJ0aWNhbDtcbiAgcGFkZGluZzogMnB4O1xuICB0ZXh0LW92ZXJmbG93OiBlbGxpcHNpcztcbiAgb3ZlcmZsb3c6IGhpZGRlbjtcbiAgbWFyZ2luOiAxMnB4IDA7XG4gIGFuaW1hdGlvbjogY2xvc2UgMC4xcyBsaW5lYXIgMC4xcyBmb3J3YXJkcztcbn1cbi5vcGVuIC50ZXh0IHtcbiAgYW5pbWF0aW9uOiBvcGVuIDAuMXMgbGluZWFyIDBzIGZvcndhcmRzO1xufVxuXG4vKiBUZXh0ICovXG5Aa2V5ZnJhbWVzIG9wZW4ge1xuICBmcm9tIHtcbiAgICBkaXNwbGF5OiAtd2Via2l0LWJveDtcbiAgICBsaW5lLWNsYW1wOiAzO1xuICAgIC13ZWJraXQtbGluZS1jbGFtcDogMztcbiAgICAtd2Via2l0LWJveC1vcmllbnQ6IHZlcnRpY2FsO1xuICB9XG4gIHRvIHtcbiAgICBkaXNwbGF5OiAtd2Via2l0LWJveDtcbiAgICBsaW5lLWNsYW1wOiBpbml0aWFsO1xuICAgIC13ZWJraXQtbGluZS1jbGFtcDogaW5pdGlhbDtcbiAgICAtd2Via2l0LWJveC1vcmllbnQ6IHZlcnRpY2FsO1xuICB9XG59XG5cbkBrZXlmcmFtZXMgY2xvc2Uge1xuICBmcm9tIHtcbiAgICBkaXNwbGF5OiAtd2Via2l0LWJveDtcbiAgICBsaW5lLWNsYW1wOiBpbml0aWFsO1xuICAgIC13ZWJraXQtbGluZS1jbGFtcDogaW5pdGlhbDtcbiAgICAtd2Via2l0LWJveC1vcmllbnQ6IHZlcnRpY2FsO1xuICB9XG4gIHRvIHtcbiAgICBkaXNwbGF5OiAtd2Via2l0LWJveDtcbiAgICBsaW5lLWNsYW1wOiAzO1xuICAgIC13ZWJraXQtbGluZS1jbGFtcDogMztcbiAgICAtd2Via2l0LWJveC1vcmllbnQ6IHZlcnRpY2FsO1xuICB9XG59XG4iXSwic291cmNlUm9vdCI6IiJ9 */"]
  }));
}
_staticBlock();

/***/ }),

/***/ 6167:
/*!********************************************************************************!*\
  !*** ./src/app/pages/home/campaign-details/companies-modal/companies.modal.ts ***!
  \********************************************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   CompaniesCampaignModalPage: () => (/* binding */ CompaniesCampaignModalPage)
/* harmony export */ });
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! @angular/core */ 12481);
/* harmony import */ var _ionic_angular__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @ionic/angular */ 21507);
/* harmony import */ var src_app_core_shared_services_campaign_service__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! src/app/core/shared/services/campaign.service */ 76658);
/* harmony import */ var _angular_common__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @angular/common */ 93683);
/* harmony import */ var _ngx_translate_core__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! @ngx-translate/core */ 48503);
var _staticBlock;





function CompaniesCampaignModalPage_div_10_Template(rf, ctx) {
  if (rf & 1) {
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](0, "div")(1, "ion-item")(2, "ion-label");
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵtext"](3);
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]()()();
  }
  if (rf & 2) {
    const company_r1 = ctx.$implicit;
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵadvance"](3);
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵtextInterpolate"](company_r1.name);
  }
}
class CompaniesCampaignModalPage {
  constructor(modalController, campaignService) {
    this.modalController = modalController;
    this.campaignService = campaignService;
  }
  ngOnInit() {
    this.sub = this.campaignService.getCompaniesForSubscription(this?.campaign?.campaignId).subscribe(result => {
      if (result) {
        this.companies = result;
      }
    });
  }
  close() {
    this.modalController.dismiss(false);
  }
  static #_ = _staticBlock = () => (this.ɵfac = function CompaniesCampaignModalPage_Factory(__ngFactoryType__) {
    return new (__ngFactoryType__ || CompaniesCampaignModalPage)(_angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵdirectiveInject"](_ionic_angular__WEBPACK_IMPORTED_MODULE_1__.ModalController), _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵdirectiveInject"](src_app_core_shared_services_campaign_service__WEBPACK_IMPORTED_MODULE_2__.CampaignService));
  }, this.ɵcmp = /*@__PURE__*/_angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵdefineComponent"]({
    type: CompaniesCampaignModalPage,
    selectors: [["app-detail-modal"]],
    standalone: false,
    decls: 11,
    vars: 7,
    consts: [["color", "playgo"], ["slot", "end"], [3, "click"], [1, "ion-padding"], [4, "ngFor", "ngForOf"]],
    template: function CompaniesCampaignModalPage_Template(rf, ctx) {
      if (rf & 1) {
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](0, "ion-header")(1, "ion-toolbar", 0)(2, "ion-title");
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵtext"](3);
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵpipe"](4, "translate");
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](5, "ion-buttons", 1)(6, "ion-button", 2);
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵlistener"]("click", function CompaniesCampaignModalPage_Template_ion_button_click_6_listener() {
          return ctx.close();
        });
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵtext"](7);
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵpipe"](8, "translate");
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]()()()();
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](9, "ion-content", 3);
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵtemplate"](10, CompaniesCampaignModalPage_div_10_Template, 4, 1, "div", 4);
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();
      }
      if (rf & 2) {
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵadvance"](3);
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵtextInterpolate"](_angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵpipeBind1"](4, 3, "campaigns.campaignmodal.title"));
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵadvance"](4);
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵtextInterpolate"](_angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵpipeBind1"](8, 5, "campaigns.campaignmodal.close"));
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵadvance"](3);
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵproperty"]("ngForOf", ctx.companies);
      }
    },
    dependencies: [_angular_common__WEBPACK_IMPORTED_MODULE_3__.NgForOf, _ionic_angular__WEBPACK_IMPORTED_MODULE_1__.IonButton, _ionic_angular__WEBPACK_IMPORTED_MODULE_1__.IonButtons, _ionic_angular__WEBPACK_IMPORTED_MODULE_1__.IonContent, _ionic_angular__WEBPACK_IMPORTED_MODULE_1__.IonHeader, _ionic_angular__WEBPACK_IMPORTED_MODULE_1__.IonItem, _ionic_angular__WEBPACK_IMPORTED_MODULE_1__.IonLabel, _ionic_angular__WEBPACK_IMPORTED_MODULE_1__.IonTitle, _ionic_angular__WEBPACK_IMPORTED_MODULE_1__.IonToolbar, _ngx_translate_core__WEBPACK_IMPORTED_MODULE_4__.TranslatePipe],
    styles: ["/*# sourceMappingURL=data:application/json;charset=utf-8;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbXSwibmFtZXMiOltdLCJtYXBwaW5ncyI6IiIsInNvdXJjZVJvb3QiOiIifQ== */"]
  }));
}
_staticBlock();

/***/ }),

/***/ 6683:
/*!********************************************************************************!*\
  !*** ./src/app/pages/home/campaign-details/campaign-details-routing.module.ts ***!
  \********************************************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   CampaignDetailsPageRoutingModule: () => (/* binding */ CampaignDetailsPageRoutingModule)
/* harmony export */ });
/* harmony import */ var _angular_router__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! @angular/router */ 34487);
/* harmony import */ var _campaign_details_page__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ./campaign-details.page */ 3117);
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @angular/core */ 34205);
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @angular/core */ 12481);
var _staticBlock;




const routes = [{
  path: '',
  component: _campaign_details_page__WEBPACK_IMPORTED_MODULE_1__.CampaignDetailsPage,
  data: {
    title: '',
    customHeader: true,
    showPlayButton: true,
    backButton: true
  }
}, {
  path: 'leaderboard',
  loadChildren: () => __webpack_require__.e(/*! import() */ "src_app_pages_home_campaign-details_leaderboard_leaderboard_module_ts").then(__webpack_require__.bind(__webpack_require__, /*! ./leaderboard/leaderboard.module */ 23368)).then(m => m.LeaderboardModule)
}, {
  path: 'school-leaderboard',
  loadChildren: () => __webpack_require__.e(/*! import() */ "src_app_pages_home_campaign-details_school-leaderboard_school-leaderboard_module_ts").then(__webpack_require__.bind(__webpack_require__, /*! ./school-leaderboard/school-leaderboard.module */ 73142)).then(m => m.SchoolLeaderboardPageModule)
}, {
  path: 'prizes',
  loadChildren: () => __webpack_require__.e(/*! import() */ "src_app_pages_home_campaign-details_prizes_prizes_module_ts").then(__webpack_require__.bind(__webpack_require__, /*! ./prizes/prizes.module */ 96160)).then(m => m.PrizesPageModule)
}, {
  path: 'stats',
  loadChildren: () => Promise.all(/*! import() */[__webpack_require__.e("default-node_modules_chart_js_dist_chart_js"), __webpack_require__.e("src_app_pages_home_campaign-details_stats_stats_module_ts")]).then(__webpack_require__.bind(__webpack_require__, /*! ./stats/stats.module */ 20136)).then(m => m.StatsPageModule)
}, {
  path: 'stats-team',
  loadChildren: () => Promise.all(/*! import() */[__webpack_require__.e("default-node_modules_chart_js_dist_chart_js"), __webpack_require__.e("common"), __webpack_require__.e("src_app_pages_home_campaign-details_stats-team_stats-team_module_ts")]).then(__webpack_require__.bind(__webpack_require__, /*! ./stats-team/stats-team.module */ 87520)).then(m => m.StatsTeamPageModule)
}, {
  path: 'faq',
  loadChildren: () => __webpack_require__.e(/*! import() */ "src_app_pages_home_campaign-details_faq_faq_module_ts").then(__webpack_require__.bind(__webpack_require__, /*! ./faq/faq.module */ 1668)).then(m => m.FaqPageModule)
}, {
  path: 'badges',
  loadChildren: () => __webpack_require__.e(/*! import() */ "src_app_pages_home_campaign-details_badges_badges_module_ts").then(__webpack_require__.bind(__webpack_require__, /*! ./badges/badges.module */ 53918)).then(m => m.BadgesPageModule)
}, {
  path: 'companies',
  loadChildren: () => __webpack_require__.e(/*! import() */ "src_app_pages_home_campaign-details_companies_companies_module_ts").then(__webpack_require__.bind(__webpack_require__, /*! ./companies/companies.module */ 71000)).then(m => m.CompaniesPageModule)
}];
class CampaignDetailsPageRoutingModule {
  static #_ = _staticBlock = () => (this.ɵfac = function CampaignDetailsPageRoutingModule_Factory(__ngFactoryType__) {
    return new (__ngFactoryType__ || CampaignDetailsPageRoutingModule)();
  }, this.ɵmod = /*@__PURE__*/_angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵdefineNgModule"]({
    type: CampaignDetailsPageRoutingModule
  }), this.ɵinj = /*@__PURE__*/_angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵdefineInjector"]({
    imports: [_angular_router__WEBPACK_IMPORTED_MODULE_0__.RouterModule.forChild(routes), _angular_router__WEBPACK_IMPORTED_MODULE_0__.RouterModule]
  }));
}
_staticBlock();
(function () {
  (typeof ngJitMode === "undefined" || ngJitMode) && _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵsetNgModuleScope"](CampaignDetailsPageRoutingModule, {
    imports: [_angular_router__WEBPACK_IMPORTED_MODULE_0__.RouterModule],
    exports: [_angular_router__WEBPACK_IMPORTED_MODULE_0__.RouterModule]
  });
})();

/***/ }),

/***/ 28751:
/*!**************************************************************************!*\
  !*** ./src/app/pages/home/campaign-details/detail-modal/detail.modal.ts ***!
  \**************************************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   DetailCampaignModalPage: () => (/* binding */ DetailCampaignModalPage)
/* harmony export */ });
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! @angular/core */ 12481);
/* harmony import */ var _ionic_angular__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @ionic/angular */ 21507);
var _staticBlock;


class DetailCampaignModalPage {
  constructor(modalController) {
    this.modalController = modalController;
    this.type = 'playgo';
  }
  ngOnInit() {}
  close() {
    this.modalController.dismiss(false);
  }
  static #_ = _staticBlock = () => (this.ɵfac = function DetailCampaignModalPage_Factory(__ngFactoryType__) {
    return new (__ngFactoryType__ || DetailCampaignModalPage)(_angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵdirectiveInject"](_ionic_angular__WEBPACK_IMPORTED_MODULE_1__.ModalController));
  }, this.ɵcmp = /*@__PURE__*/_angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵdefineComponent"]({
    type: DetailCampaignModalPage,
    selectors: [["app-detail-modal"]],
    standalone: false,
    decls: 9,
    vars: 3,
    consts: [[3, "color"], ["slot", "end"], [3, "click"], ["name", "close-circle-outline"], [1, "ion-padding"], [3, "innerHTML"]],
    template: function DetailCampaignModalPage_Template(rf, ctx) {
      if (rf & 1) {
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](0, "ion-header")(1, "ion-toolbar", 0)(2, "ion-title");
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵtext"](3);
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](4, "ion-buttons", 1)(5, "ion-button", 2);
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵlistener"]("click", function DetailCampaignModalPage_Template_ion_button_click_5_listener() {
          return ctx.close();
        });
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelement"](6, "ion-icon", 3);
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]()()()();
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](7, "ion-content", 4);
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelement"](8, "div", 5);
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();
      }
      if (rf & 2) {
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵadvance"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵproperty"]("color", ctx.type);
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵadvance"](2);
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵtextInterpolate"](ctx.detail == null ? null : ctx.detail.name);
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵadvance"](5);
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵproperty"]("innerHTML", ctx.detail == null ? null : ctx.detail.content, _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵsanitizeHtml"]);
      }
    },
    dependencies: [_ionic_angular__WEBPACK_IMPORTED_MODULE_1__.IonButton, _ionic_angular__WEBPACK_IMPORTED_MODULE_1__.IonButtons, _ionic_angular__WEBPACK_IMPORTED_MODULE_1__.IonContent, _ionic_angular__WEBPACK_IMPORTED_MODULE_1__.IonHeader, _ionic_angular__WEBPACK_IMPORTED_MODULE_1__.IonIcon, _ionic_angular__WEBPACK_IMPORTED_MODULE_1__.IonTitle, _ionic_angular__WEBPACK_IMPORTED_MODULE_1__.IonToolbar],
    styles: ["/*# sourceMappingURL=data:application/json;charset=utf-8;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbXSwibmFtZXMiOltdLCJtYXBwaW5ncyI6IiIsInNvdXJjZVJvb3QiOiIifQ== */"]
  }));
}
_staticBlock();

/***/ }),

/***/ 49658:
/*!************************************************************************!*\
  !*** ./src/app/pages/home/campaign-details/campaign-details.module.ts ***!
  \************************************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   CampaignDetailsPageModule: () => (/* binding */ CampaignDetailsPageModule)
/* harmony export */ });
/* harmony import */ var _campaign_details_routing_module__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./campaign-details-routing.module */ 6683);
/* harmony import */ var _campaign_details_page__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ./campaign-details.page */ 3117);
/* harmony import */ var src_app_core_shared_shared_module__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! src/app/core/shared/shared.module */ 62657);
/* harmony import */ var _detail_modal_detail_modal__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! ./detail-modal/detail.modal */ 28751);
/* harmony import */ var _campaign_notification_campaign_notification_component__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! ./campaign-notification/campaign-notification.component */ 93797);
/* harmony import */ var _unsubscribe_modal_unsubscribe_modal__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! ./unsubscribe-modal/unsubscribe.modal */ 887);
/* harmony import */ var _companies_modal_companies_modal__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! ./companies-modal/companies.modal */ 6167);
/* harmony import */ var _ionic_angular__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(/*! @ionic/angular */ 21507);
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(/*! @angular/core */ 34205);
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_9__ = __webpack_require__(/*! @angular/core */ 12481);
var _staticBlock;









class CampaignDetailsPageModule {
  static #_ = _staticBlock = () => (this.ɵfac = function CampaignDetailsPageModule_Factory(__ngFactoryType__) {
    return new (__ngFactoryType__ || CampaignDetailsPageModule)();
  }, this.ɵmod = /*@__PURE__*/_angular_core__WEBPACK_IMPORTED_MODULE_9__["ɵɵdefineNgModule"]({
    type: CampaignDetailsPageModule
  }), this.ɵinj = /*@__PURE__*/_angular_core__WEBPACK_IMPORTED_MODULE_8__["ɵɵdefineInjector"]({
    imports: [_campaign_details_routing_module__WEBPACK_IMPORTED_MODULE_0__.CampaignDetailsPageRoutingModule, src_app_core_shared_shared_module__WEBPACK_IMPORTED_MODULE_2__.PlayGoSharedModule, _ionic_angular__WEBPACK_IMPORTED_MODULE_7__.IonicModule]
  }));
}
_staticBlock();
(function () {
  (typeof ngJitMode === "undefined" || ngJitMode) && _angular_core__WEBPACK_IMPORTED_MODULE_9__["ɵɵsetNgModuleScope"](CampaignDetailsPageModule, {
    declarations: [_campaign_details_page__WEBPACK_IMPORTED_MODULE_1__.CampaignDetailsPage, _detail_modal_detail_modal__WEBPACK_IMPORTED_MODULE_3__.DetailCampaignModalPage, _companies_modal_companies_modal__WEBPACK_IMPORTED_MODULE_6__.CompaniesCampaignModalPage, _campaign_notification_campaign_notification_component__WEBPACK_IMPORTED_MODULE_4__.CampaignNotificationComponent, _unsubscribe_modal_unsubscribe_modal__WEBPACK_IMPORTED_MODULE_5__.UnsubscribeModalPage],
    imports: [_campaign_details_routing_module__WEBPACK_IMPORTED_MODULE_0__.CampaignDetailsPageRoutingModule, src_app_core_shared_shared_module__WEBPACK_IMPORTED_MODULE_2__.PlayGoSharedModule, _ionic_angular__WEBPACK_IMPORTED_MODULE_7__.IonicModule]
  });
})();

/***/ }),

/***/ 93797:
/*!******************************************************************************************************!*\
  !*** ./src/app/pages/home/campaign-details/campaign-notification/campaign-notification.component.ts ***!
  \******************************************************************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   CampaignNotificationComponent: () => (/* binding */ CampaignNotificationComponent)
/* harmony export */ });
/* harmony import */ var _Users_smartcommunitylab_Desktop_newWork_playAndGo_playGo_node_modules_babel_runtime_helpers_esm_asyncToGenerator_js__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./node_modules/@babel/runtime/helpers/esm/asyncToGenerator.js */ 89204);
/* harmony import */ var src_app_core_shared_detail_notification_detail_notification_modal__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! src/app/core/shared/detail-notification/detail-notification.modal */ 37572);
/* harmony import */ var src_app_core_shared_services_notifications_notifications_service__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! src/app/core/shared/services/notifications/notifications.service */ 16095);
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @angular/core */ 12481);
/* harmony import */ var _ionic_angular__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! @ionic/angular */ 21507);
/* harmony import */ var _ngx_translate_core__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! @ngx-translate/core */ 48503);
/* harmony import */ var _core_shared_ui_icon_icon_component__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! ../../../../core/shared/ui/icon/icon.component */ 59621);

var _staticBlock;







class CampaignNotificationComponent {
  constructor(modalController, notificationService, translateService) {
    this.modalController = modalController;
    this.notificationService = notificationService;
    this.translateService = translateService;
  }
  ngOnInit() {}
  openDetail(notification) {
    var _this = this;
    return (0,_Users_smartcommunitylab_Desktop_newWork_playAndGo_playGo_node_modules_babel_runtime_helpers_esm_asyncToGenerator_js__WEBPACK_IMPORTED_MODULE_0__["default"])(function* () {
      const modal = yield _this.modalController.create({
        component: src_app_core_shared_detail_notification_detail_notification_modal__WEBPACK_IMPORTED_MODULE_1__.DetailNotificationModalPage,
        cssClass: 'campaign-notification',
        componentProps: {
          notification,
          campaign: _this.campaign
        }
      });
      yield modal.present();
      //mark as read the notification
      _this.notificationService.markListOfNotificationAsRead([notification]);
      yield modal.onWillDismiss();
    })();
  }
  getTitle(notification) {
    switch (notification?.content?.type) {
      case src_app_core_shared_services_notifications_notifications_service__WEBPACK_IMPORTED_MODULE_2__.NotificationType.level:
        return this.translateService.instant('modal.levelup');
      case src_app_core_shared_services_notifications_notifications_service__WEBPACK_IMPORTED_MODULE_2__.NotificationType.badge:
        return this.translateService.instant('modal.newbadge');
      default:
        return '';
    }
  }
  getImage(notification) {
    switch (notification?.content?.type) {
      case src_app_core_shared_services_notifications_notifications_service__WEBPACK_IMPORTED_MODULE_2__.NotificationType.level:
        return 'leaderboard';
      case src_app_core_shared_services_notifications_notifications_service__WEBPACK_IMPORTED_MODULE_2__.NotificationType.badge:
        return 'badges';
      default:
        return '';
    }
  }
  static #_ = _staticBlock = () => (this.ɵfac = function CampaignNotificationComponent_Factory(__ngFactoryType__) {
    return new (__ngFactoryType__ || CampaignNotificationComponent)(_angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵdirectiveInject"](_ionic_angular__WEBPACK_IMPORTED_MODULE_4__.ModalController), _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵdirectiveInject"](src_app_core_shared_services_notifications_notifications_service__WEBPACK_IMPORTED_MODULE_2__.NotificationService), _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵdirectiveInject"](_ngx_translate_core__WEBPACK_IMPORTED_MODULE_5__.TranslateService));
  }, this.ɵcmp = /*@__PURE__*/_angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵdefineComponent"]({
    type: CampaignNotificationComponent,
    selectors: [["app-campaign-notification"]],
    inputs: {
      notification: "notification",
      campaign: "campaign"
    },
    standalone: false,
    decls: 17,
    vars: 4,
    consts: [[3, "click", "color"], ["color", "danger"], ["name", "alert"], ["size", "10"], [1, "description"], ["size", "2"], [1, "icon-size-big", 3, "name"]],
    template: function CampaignNotificationComponent_Template(rf, ctx) {
      if (rf & 1) {
        _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵelementStart"](0, "ion-card", 0);
        _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵlistener"]("click", function CampaignNotificationComponent_Template_ion_card_click_0_listener() {
          return ctx.openDetail(ctx.notification);
        });
        _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵelementStart"](1, "ion-badge", 1);
        _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵelement"](2, "ion-icon", 2);
        _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵelementStart"](3, "ion-grid")(4, "ion-row")(5, "ion-col", 3)(6, "ion-row")(7, "ion-col")(8, "span")(9, "b");
        _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵtext"](10);
        _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵelementEnd"]()()();
        _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵelementStart"](11, "ion-row")(12, "ion-col")(13, "span", 4);
        _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵtext"](14);
        _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵelementEnd"]()()()()();
        _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵelementStart"](15, "ion-col", 5);
        _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵelement"](16, "app-icon", 6);
        _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵelementEnd"]()()()();
      }
      if (rf & 2) {
        _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵproperty"]("color", (ctx.campaign == null ? null : ctx.campaign.campaign == null ? null : ctx.campaign.campaign.type) + "-light");
        _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵadvance"](10);
        _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵtextInterpolate"](ctx.getTitle(ctx.notification));
        _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵadvance"](4);
        _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵtextInterpolate"](ctx.notification.description);
        _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵadvance"](2);
        _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵproperty"]("name", ctx.getImage(ctx.notification));
      }
    },
    dependencies: [_ionic_angular__WEBPACK_IMPORTED_MODULE_4__.IonBadge, _ionic_angular__WEBPACK_IMPORTED_MODULE_4__.IonCard, _ionic_angular__WEBPACK_IMPORTED_MODULE_4__.IonCol, _ionic_angular__WEBPACK_IMPORTED_MODULE_4__.IonGrid, _ionic_angular__WEBPACK_IMPORTED_MODULE_4__.IonIcon, _ionic_angular__WEBPACK_IMPORTED_MODULE_4__.IonRow, _core_shared_ui_icon_icon_component__WEBPACK_IMPORTED_MODULE_6__.IconComponent],
    styles: ["ion-card[_ngcontent-%COMP%] {\n  overflow: visible;\n}\nion-card[_ngcontent-%COMP%]   .description[_ngcontent-%COMP%] {\n  font-style: italic;\n  font-size: 13px;\n  \n\n  width: 100%;\n  display: -webkit-box;\n  -webkit-line-clamp: 2;\n  -webkit-box-orient: vertical;\n  overflow: hidden;\n  text-overflow: ellipsis;\n}\nion-card[_ngcontent-%COMP%]   ion-badge[_ngcontent-%COMP%] {\n  position: absolute;\n  z-index: 99;\n  right: 2px;\n  top: 2px;\n}\n/*# sourceMappingURL=data:application/json;charset=utf-8;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbIndlYnBhY2s6Ly8uL3NyYy9hcHAvcGFnZXMvaG9tZS9jYW1wYWlnbi1kZXRhaWxzL2NhbXBhaWduLW5vdGlmaWNhdGlvbi9jYW1wYWlnbi1ub3RpZmljYXRpb24uY29tcG9uZW50LnNjc3MiXSwibmFtZXMiOltdLCJtYXBwaW5ncyI6IkFBQUE7RUFDRSxpQkFBQTtBQUNGO0FBQUU7RUFDRSxrQkFBQTtFQUNBLGVBQUE7RUFDQSxxQkFBQTtFQUNBLFdBQUE7RUFDQSxvQkFBQTtFQUNBLHFCQUFBO0VBQ0EsNEJBQUE7RUFDQSxnQkFBQTtFQUNBLHVCQUFBO0FBRUo7QUFBRTtFQUNFLGtCQUFBO0VBQ0EsV0FBQTtFQUNBLFVBQUE7RUFDQSxRQUFBO0FBRUoiLCJzb3VyY2VzQ29udGVudCI6WyJpb24tY2FyZCB7XG4gIG92ZXJmbG93OiB2aXNpYmxlO1xuICAuZGVzY3JpcHRpb24ge1xuICAgIGZvbnQtc3R5bGU6IGl0YWxpYztcbiAgICBmb250LXNpemU6IDEzcHg7XG4gICAgLyogZm9udC1zaXplOiAxN3B4OyAqL1xuICAgIHdpZHRoOiAxMDAlO1xuICAgIGRpc3BsYXk6IC13ZWJraXQtYm94O1xuICAgIC13ZWJraXQtbGluZS1jbGFtcDogMjtcbiAgICAtd2Via2l0LWJveC1vcmllbnQ6IHZlcnRpY2FsO1xuICAgIG92ZXJmbG93OiBoaWRkZW47XG4gICAgdGV4dC1vdmVyZmxvdzogZWxsaXBzaXM7XG4gIH1cbiAgaW9uLWJhZGdlIHtcbiAgICBwb3NpdGlvbjogYWJzb2x1dGU7XG4gICAgei1pbmRleDogOTk7XG4gICAgcmlnaHQ6IDJweDtcbiAgICB0b3A6IDJweDtcbiAgfVxufVxuIl0sInNvdXJjZVJvb3QiOiIifQ== */"]
  }));
}
_staticBlock();

/***/ })

}]);
//# sourceMappingURL=default-src_app_pages_home_campaign-details_campaign-details_module_ts.js.map