"use strict";
(self["webpackChunkapp"] = self["webpackChunkapp"] || []).push([["src_app_pages_home_campaign-details_leaderboard_leaderboard_module_ts"],{

/***/ 23368:
/*!*******************************************************************************!*\
  !*** ./src/app/pages/home/campaign-details/leaderboard/leaderboard.module.ts ***!
  \*******************************************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   LeaderboardModule: () => (/* binding */ LeaderboardModule)
/* harmony export */ });
/* harmony import */ var src_app_core_shared_shared_module__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! src/app/core/shared/shared.module */ 62657);
/* harmony import */ var _leaderboard_routing_module__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ./leaderboard-routing.module */ 88305);
/* harmony import */ var _leaderboard_page__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! ./leaderboard.page */ 54355);
/* harmony import */ var _placing_detail_placing_detail_component__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! ./placing-detail/placing-detail.component */ 67183);
/* harmony import */ var _ionic_angular__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! @ionic/angular */ 21507);
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! @angular/core */ 34205);
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! @angular/core */ 12481);
var _staticBlock;






class LeaderboardModule {
  static #_ = _staticBlock = () => (this.ɵfac = function LeaderboardModule_Factory(__ngFactoryType__) {
    return new (__ngFactoryType__ || LeaderboardModule)();
  }, this.ɵmod = /*@__PURE__*/_angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵdefineNgModule"]({
    type: LeaderboardModule
  }), this.ɵinj = /*@__PURE__*/_angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵdefineInjector"]({
    imports: [_leaderboard_routing_module__WEBPACK_IMPORTED_MODULE_1__.LeaderboardPageRoutingModule, src_app_core_shared_shared_module__WEBPACK_IMPORTED_MODULE_0__.PlayGoSharedModule, _ionic_angular__WEBPACK_IMPORTED_MODULE_4__.IonicModule]
  }));
}
_staticBlock();
(function () {
  (typeof ngJitMode === "undefined" || ngJitMode) && _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵsetNgModuleScope"](LeaderboardModule, {
    declarations: [_leaderboard_page__WEBPACK_IMPORTED_MODULE_2__.LeaderboardPage, _placing_detail_placing_detail_component__WEBPACK_IMPORTED_MODULE_3__.PlacingDetailComponent],
    imports: [_leaderboard_routing_module__WEBPACK_IMPORTED_MODULE_1__.LeaderboardPageRoutingModule, src_app_core_shared_shared_module__WEBPACK_IMPORTED_MODULE_0__.PlayGoSharedModule, _ionic_angular__WEBPACK_IMPORTED_MODULE_4__.IonicModule]
  });
})();

/***/ }),

/***/ 54355:
/*!*****************************************************************************!*\
  !*** ./src/app/pages/home/campaign-details/leaderboard/leaderboard.page.ts ***!
  \*****************************************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   LeaderboardPage: () => (/* binding */ LeaderboardPage)
/* harmony export */ });
/* harmony import */ var lodash_es__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! lodash-es */ 24979);
/* harmony import */ var rxjs__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! rxjs */ 10819);
/* harmony import */ var rxjs__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! rxjs */ 19999);
/* harmony import */ var rxjs__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! rxjs */ 59452);
/* harmony import */ var rxjs_operators__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! rxjs/operators */ 91817);
/* harmony import */ var rxjs_operators__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! rxjs/operators */ 2435);
/* harmony import */ var rxjs_operators__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! rxjs/operators */ 70271);
/* harmony import */ var rxjs_operators__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(/*! rxjs/operators */ 86301);
/* harmony import */ var rxjs_operators__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(/*! rxjs/operators */ 63037);
/* harmony import */ var rxjs_operators__WEBPACK_IMPORTED_MODULE_9__ = __webpack_require__(/*! rxjs/operators */ 36647);
/* harmony import */ var luxon__WEBPACK_IMPORTED_MODULE_10__ = __webpack_require__(/*! luxon */ 45967);
/* harmony import */ var src_app_core_shared_tracking_trip_model__WEBPACK_IMPORTED_MODULE_11__ = __webpack_require__(/*! src/app/core/shared/tracking/trip.model */ 23126);
/* harmony import */ var src_app_core_shared_rxjs_utils__WEBPACK_IMPORTED_MODULE_12__ = __webpack_require__(/*! src/app/core/shared/rxjs.utils */ 86040);
/* harmony import */ var src_app_core_shared_time_utils__WEBPACK_IMPORTED_MODULE_13__ = __webpack_require__(/*! src/app/core/shared/time.utils */ 27780);
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_14__ = __webpack_require__(/*! @angular/core */ 34205);
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_15__ = __webpack_require__(/*! @angular/core */ 12481);
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_16__ = __webpack_require__(/*! @angular/core */ 37580);
/* harmony import */ var _angular_router__WEBPACK_IMPORTED_MODULE_17__ = __webpack_require__(/*! @angular/router */ 85422);
/* harmony import */ var src_app_core_api_generated_controllers_reportController_service__WEBPACK_IMPORTED_MODULE_18__ = __webpack_require__(/*! src/app/core/api/generated/controllers/reportController.service */ 32076);
/* harmony import */ var src_app_core_shared_services_user_service__WEBPACK_IMPORTED_MODULE_19__ = __webpack_require__(/*! src/app/core/shared/services/user.service */ 89815);
/* harmony import */ var src_app_core_shared_services_campaign_service__WEBPACK_IMPORTED_MODULE_20__ = __webpack_require__(/*! src/app/core/shared/services/campaign.service */ 76658);
/* harmony import */ var src_app_core_shared_services_error_service__WEBPACK_IMPORTED_MODULE_21__ = __webpack_require__(/*! src/app/core/shared/services/error.service */ 46078);
/* harmony import */ var src_app_core_shared_services_page_settings_service__WEBPACK_IMPORTED_MODULE_22__ = __webpack_require__(/*! src/app/core/shared/services/page-settings.service */ 40147);
/* harmony import */ var _angular_common__WEBPACK_IMPORTED_MODULE_23__ = __webpack_require__(/*! @angular/common */ 93683);
/* harmony import */ var _ionic_angular__WEBPACK_IMPORTED_MODULE_24__ = __webpack_require__(/*! @ionic/angular */ 21507);
/* harmony import */ var _core_shared_layout_header_header_directive__WEBPACK_IMPORTED_MODULE_25__ = __webpack_require__(/*! ../../../../core/shared/layout/header/header.directive */ 85039);
/* harmony import */ var _core_shared_layout_content_content_directive__WEBPACK_IMPORTED_MODULE_26__ = __webpack_require__(/*! ../../../../core/shared/layout/content/content.directive */ 75855);
/* harmony import */ var _core_shared_infinite_scroll_infinite_scroll_component__WEBPACK_IMPORTED_MODULE_27__ = __webpack_require__(/*! ../../../../core/shared/infinite-scroll/infinite-scroll.component */ 666);
/* harmony import */ var _placing_detail_placing_detail_component__WEBPACK_IMPORTED_MODULE_28__ = __webpack_require__(/*! ./placing-detail/placing-detail.component */ 67183);
/* harmony import */ var _ngx_translate_core__WEBPACK_IMPORTED_MODULE_29__ = __webpack_require__(/*! @ngx-translate/core */ 48503);
var _staticBlock;





















const _c0 = ["periodSelect"];
const _c1 = ["metricSelect"];
const _c2 = () => ({
  cssClass: "app-alert"
});
function LeaderboardPage_ng_container_2_ng_container_9_ion_select_option_1_Template(rf, ctx) {
  if (rf & 1) {
    _angular_core__WEBPACK_IMPORTED_MODULE_15__["ɵɵelementStart"](0, "ion-select-option", 18);
    _angular_core__WEBPACK_IMPORTED_MODULE_15__["ɵɵtext"](1);
    _angular_core__WEBPACK_IMPORTED_MODULE_15__["ɵɵpipe"](2, "translate");
    _angular_core__WEBPACK_IMPORTED_MODULE_15__["ɵɵelementEnd"]();
  }
  if (rf & 2) {
    const mean_r3 = ctx.$implicit;
    const ctx_r1 = _angular_core__WEBPACK_IMPORTED_MODULE_15__["ɵɵnextContext"](3);
    _angular_core__WEBPACK_IMPORTED_MODULE_15__["ɵɵproperty"]("value", mean_r3);
    _angular_core__WEBPACK_IMPORTED_MODULE_15__["ɵɵadvance"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_15__["ɵɵtextInterpolate1"](" ", _angular_core__WEBPACK_IMPORTED_MODULE_15__["ɵɵpipeBind1"](2, 2, ctx_r1.meanLabels[mean_r3]), " ");
  }
}
function LeaderboardPage_ng_container_2_ng_container_9_Template(rf, ctx) {
  if (rf & 1) {
    _angular_core__WEBPACK_IMPORTED_MODULE_15__["ɵɵelementContainerStart"](0);
    _angular_core__WEBPACK_IMPORTED_MODULE_15__["ɵɵtemplate"](1, LeaderboardPage_ng_container_2_ng_container_9_ion_select_option_1_Template, 3, 4, "ion-select-option", 17);
    _angular_core__WEBPACK_IMPORTED_MODULE_15__["ɵɵpipe"](2, "async");
    _angular_core__WEBPACK_IMPORTED_MODULE_15__["ɵɵelementContainerEnd"]();
  }
  if (rf & 2) {
    const ctx_r1 = _angular_core__WEBPACK_IMPORTED_MODULE_15__["ɵɵnextContext"](2);
    _angular_core__WEBPACK_IMPORTED_MODULE_15__["ɵɵadvance"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_15__["ɵɵproperty"]("ngForOf", _angular_core__WEBPACK_IMPORTED_MODULE_15__["ɵɵpipeBind1"](2, 1, ctx_r1.means$));
  }
}
function LeaderboardPage_ng_container_2_ng_template_11_ion_select_option_0_Template(rf, ctx) {
  if (rf & 1) {
    _angular_core__WEBPACK_IMPORTED_MODULE_15__["ɵɵelementStart"](0, "ion-select-option", 18);
    _angular_core__WEBPACK_IMPORTED_MODULE_15__["ɵɵtext"](1);
    _angular_core__WEBPACK_IMPORTED_MODULE_15__["ɵɵpipe"](2, "translate");
    _angular_core__WEBPACK_IMPORTED_MODULE_15__["ɵɵelementEnd"]();
  }
  if (rf & 2) {
    const mean_r4 = ctx.$implicit;
    const ctx_r1 = _angular_core__WEBPACK_IMPORTED_MODULE_15__["ɵɵnextContext"](3);
    _angular_core__WEBPACK_IMPORTED_MODULE_15__["ɵɵproperty"]("value", mean_r4);
    _angular_core__WEBPACK_IMPORTED_MODULE_15__["ɵɵadvance"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_15__["ɵɵtextInterpolate1"](" ", _angular_core__WEBPACK_IMPORTED_MODULE_15__["ɵɵpipeBind1"](2, 2, ctx_r1.meanLabels[mean_r4]), " ");
  }
}
function LeaderboardPage_ng_container_2_ng_template_11_Template(rf, ctx) {
  if (rf & 1) {
    _angular_core__WEBPACK_IMPORTED_MODULE_15__["ɵɵtemplate"](0, LeaderboardPage_ng_container_2_ng_template_11_ion_select_option_0_Template, 3, 4, "ion-select-option", 17);
    _angular_core__WEBPACK_IMPORTED_MODULE_15__["ɵɵpipe"](1, "async");
  }
  if (rf & 2) {
    const ctx_r1 = _angular_core__WEBPACK_IMPORTED_MODULE_15__["ɵɵnextContext"](2);
    _angular_core__WEBPACK_IMPORTED_MODULE_15__["ɵɵproperty"]("ngForOf", _angular_core__WEBPACK_IMPORTED_MODULE_15__["ɵɵpipeBind1"](1, 1, ctx_r1.meansForCompany$));
  }
}
function LeaderboardPage_ng_container_2_ion_col_13_ng_container_5_ion_select_option_1_p_1_Template(rf, ctx) {
  if (rf & 1) {
    _angular_core__WEBPACK_IMPORTED_MODULE_15__["ɵɵelementStart"](0, "p");
    _angular_core__WEBPACK_IMPORTED_MODULE_15__["ɵɵtext"](1);
    _angular_core__WEBPACK_IMPORTED_MODULE_15__["ɵɵpipe"](2, "translate");
    _angular_core__WEBPACK_IMPORTED_MODULE_15__["ɵɵelementEnd"]();
  }
  if (rf & 2) {
    const metric_r6 = _angular_core__WEBPACK_IMPORTED_MODULE_15__["ɵɵnextContext"]().$implicit;
    const ctx_r1 = _angular_core__WEBPACK_IMPORTED_MODULE_15__["ɵɵnextContext"](4);
    _angular_core__WEBPACK_IMPORTED_MODULE_15__["ɵɵadvance"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_15__["ɵɵtextInterpolate"](_angular_core__WEBPACK_IMPORTED_MODULE_15__["ɵɵpipeBind1"](2, 1, ctx_r1.metricToUnitLabel[metric_r6]));
  }
}
function LeaderboardPage_ng_container_2_ion_col_13_ng_container_5_ion_select_option_1_p_2_Template(rf, ctx) {
  if (rf & 1) {
    _angular_core__WEBPACK_IMPORTED_MODULE_15__["ɵɵelementStart"](0, "p");
    _angular_core__WEBPACK_IMPORTED_MODULE_15__["ɵɵtext"](1);
    _angular_core__WEBPACK_IMPORTED_MODULE_15__["ɵɵpipe"](2, "async");
    _angular_core__WEBPACK_IMPORTED_MODULE_15__["ɵɵelementEnd"]();
  }
  if (rf & 2) {
    let tmp_12_0;
    const ctx_r1 = _angular_core__WEBPACK_IMPORTED_MODULE_15__["ɵɵnextContext"](5);
    _angular_core__WEBPACK_IMPORTED_MODULE_15__["ɵɵadvance"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_15__["ɵɵtextInterpolate"]((tmp_12_0 = _angular_core__WEBPACK_IMPORTED_MODULE_15__["ɵɵpipeBind1"](2, 1, ctx_r1.campaign$)) == null ? null : tmp_12_0.specificData == null ? null : tmp_12_0.specificData.virtualScore == null ? null : tmp_12_0.specificData.virtualScore.label);
  }
}
function LeaderboardPage_ng_container_2_ion_col_13_ng_container_5_ion_select_option_1_Template(rf, ctx) {
  if (rf & 1) {
    _angular_core__WEBPACK_IMPORTED_MODULE_15__["ɵɵelementStart"](0, "ion-select-option", 18);
    _angular_core__WEBPACK_IMPORTED_MODULE_15__["ɵɵtemplate"](1, LeaderboardPage_ng_container_2_ion_col_13_ng_container_5_ion_select_option_1_p_1_Template, 3, 3, "p", 8)(2, LeaderboardPage_ng_container_2_ion_col_13_ng_container_5_ion_select_option_1_p_2_Template, 3, 3, "p", 8);
    _angular_core__WEBPACK_IMPORTED_MODULE_15__["ɵɵelementEnd"]();
  }
  if (rf & 2) {
    const metric_r6 = ctx.$implicit;
    _angular_core__WEBPACK_IMPORTED_MODULE_15__["ɵɵproperty"]("value", metric_r6);
    _angular_core__WEBPACK_IMPORTED_MODULE_15__["ɵɵadvance"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_15__["ɵɵproperty"]("ngIf", metric_r6 !== "virtualScore");
    _angular_core__WEBPACK_IMPORTED_MODULE_15__["ɵɵadvance"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_15__["ɵɵproperty"]("ngIf", metric_r6 === "virtualScore");
  }
}
function LeaderboardPage_ng_container_2_ion_col_13_ng_container_5_Template(rf, ctx) {
  if (rf & 1) {
    _angular_core__WEBPACK_IMPORTED_MODULE_15__["ɵɵelementContainerStart"](0);
    _angular_core__WEBPACK_IMPORTED_MODULE_15__["ɵɵtemplate"](1, LeaderboardPage_ng_container_2_ion_col_13_ng_container_5_ion_select_option_1_Template, 3, 3, "ion-select-option", 17);
    _angular_core__WEBPACK_IMPORTED_MODULE_15__["ɵɵpipe"](2, "async");
    _angular_core__WEBPACK_IMPORTED_MODULE_15__["ɵɵelementContainerEnd"]();
  }
  if (rf & 2) {
    const ctx_r1 = _angular_core__WEBPACK_IMPORTED_MODULE_15__["ɵɵnextContext"](3);
    _angular_core__WEBPACK_IMPORTED_MODULE_15__["ɵɵadvance"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_15__["ɵɵproperty"]("ngForOf", _angular_core__WEBPACK_IMPORTED_MODULE_15__["ɵɵpipeBind1"](2, 1, ctx_r1.metrics$));
  }
}
function LeaderboardPage_ng_container_2_ion_col_13_ng_template_7_ion_select_option_0_p_1_Template(rf, ctx) {
  if (rf & 1) {
    _angular_core__WEBPACK_IMPORTED_MODULE_15__["ɵɵelementStart"](0, "p");
    _angular_core__WEBPACK_IMPORTED_MODULE_15__["ɵɵtext"](1);
    _angular_core__WEBPACK_IMPORTED_MODULE_15__["ɵɵpipe"](2, "translate");
    _angular_core__WEBPACK_IMPORTED_MODULE_15__["ɵɵelementEnd"]();
  }
  if (rf & 2) {
    const metric_r7 = _angular_core__WEBPACK_IMPORTED_MODULE_15__["ɵɵnextContext"]().$implicit;
    const ctx_r1 = _angular_core__WEBPACK_IMPORTED_MODULE_15__["ɵɵnextContext"](4);
    _angular_core__WEBPACK_IMPORTED_MODULE_15__["ɵɵadvance"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_15__["ɵɵtextInterpolate"](_angular_core__WEBPACK_IMPORTED_MODULE_15__["ɵɵpipeBind1"](2, 1, ctx_r1.metricToUnitLabel[metric_r7]));
  }
}
function LeaderboardPage_ng_container_2_ion_col_13_ng_template_7_ion_select_option_0_p_2_Template(rf, ctx) {
  if (rf & 1) {
    _angular_core__WEBPACK_IMPORTED_MODULE_15__["ɵɵelementStart"](0, "p");
    _angular_core__WEBPACK_IMPORTED_MODULE_15__["ɵɵtext"](1);
    _angular_core__WEBPACK_IMPORTED_MODULE_15__["ɵɵpipe"](2, "async");
    _angular_core__WEBPACK_IMPORTED_MODULE_15__["ɵɵelementEnd"]();
  }
  if (rf & 2) {
    let tmp_12_0;
    const ctx_r1 = _angular_core__WEBPACK_IMPORTED_MODULE_15__["ɵɵnextContext"](5);
    _angular_core__WEBPACK_IMPORTED_MODULE_15__["ɵɵadvance"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_15__["ɵɵtextInterpolate"]((tmp_12_0 = _angular_core__WEBPACK_IMPORTED_MODULE_15__["ɵɵpipeBind1"](2, 1, ctx_r1.campaign$)) == null ? null : tmp_12_0.specificData == null ? null : tmp_12_0.specificData.virtualScore == null ? null : tmp_12_0.specificData.virtualScore.label);
  }
}
function LeaderboardPage_ng_container_2_ion_col_13_ng_template_7_ion_select_option_0_Template(rf, ctx) {
  if (rf & 1) {
    _angular_core__WEBPACK_IMPORTED_MODULE_15__["ɵɵelementStart"](0, "ion-select-option", 18);
    _angular_core__WEBPACK_IMPORTED_MODULE_15__["ɵɵtemplate"](1, LeaderboardPage_ng_container_2_ion_col_13_ng_template_7_ion_select_option_0_p_1_Template, 3, 3, "p", 8)(2, LeaderboardPage_ng_container_2_ion_col_13_ng_template_7_ion_select_option_0_p_2_Template, 3, 3, "p", 8);
    _angular_core__WEBPACK_IMPORTED_MODULE_15__["ɵɵelementEnd"]();
  }
  if (rf & 2) {
    const metric_r7 = ctx.$implicit;
    _angular_core__WEBPACK_IMPORTED_MODULE_15__["ɵɵproperty"]("value", metric_r7);
    _angular_core__WEBPACK_IMPORTED_MODULE_15__["ɵɵadvance"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_15__["ɵɵproperty"]("ngIf", metric_r7 !== "virtualScore");
    _angular_core__WEBPACK_IMPORTED_MODULE_15__["ɵɵadvance"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_15__["ɵɵproperty"]("ngIf", metric_r7 === "virtualScore");
  }
}
function LeaderboardPage_ng_container_2_ion_col_13_ng_template_7_Template(rf, ctx) {
  if (rf & 1) {
    _angular_core__WEBPACK_IMPORTED_MODULE_15__["ɵɵtemplate"](0, LeaderboardPage_ng_container_2_ion_col_13_ng_template_7_ion_select_option_0_Template, 3, 3, "ion-select-option", 17);
    _angular_core__WEBPACK_IMPORTED_MODULE_15__["ɵɵpipe"](1, "async");
  }
  if (rf & 2) {
    const ctx_r1 = _angular_core__WEBPACK_IMPORTED_MODULE_15__["ɵɵnextContext"](3);
    _angular_core__WEBPACK_IMPORTED_MODULE_15__["ɵɵproperty"]("ngForOf", _angular_core__WEBPACK_IMPORTED_MODULE_15__["ɵɵpipeBind1"](1, 1, ctx_r1.metricsCompany$));
  }
}
function LeaderboardPage_ng_container_2_ion_col_13_Template(rf, ctx) {
  if (rf & 1) {
    const _r5 = _angular_core__WEBPACK_IMPORTED_MODULE_15__["ɵɵgetCurrentView"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_15__["ɵɵelementStart"](0, "ion-col")(1, "ion-item", 11)(2, "ion-select", 15, 4);
    _angular_core__WEBPACK_IMPORTED_MODULE_15__["ɵɵpipe"](4, "async");
    _angular_core__WEBPACK_IMPORTED_MODULE_15__["ɵɵlistener"]("ionChange", function LeaderboardPage_ng_container_2_ion_col_13_Template_ion_select_ionChange_2_listener($event) {
      _angular_core__WEBPACK_IMPORTED_MODULE_14__["ɵɵrestoreView"](_r5);
      const ctx_r1 = _angular_core__WEBPACK_IMPORTED_MODULE_15__["ɵɵnextContext"](2);
      return _angular_core__WEBPACK_IMPORTED_MODULE_14__["ɵɵresetView"](ctx_r1.selectedMetricChangedSubject.next($event));
    });
    _angular_core__WEBPACK_IMPORTED_MODULE_15__["ɵɵtemplate"](5, LeaderboardPage_ng_container_2_ion_col_13_ng_container_5_Template, 3, 3, "ng-container", 13);
    _angular_core__WEBPACK_IMPORTED_MODULE_15__["ɵɵpipe"](6, "async");
    _angular_core__WEBPACK_IMPORTED_MODULE_15__["ɵɵtemplate"](7, LeaderboardPage_ng_container_2_ion_col_13_ng_template_7_Template, 2, 3, "ng-template", null, 5, _angular_core__WEBPACK_IMPORTED_MODULE_15__["ɵɵtemplateRefExtractor"]);
    _angular_core__WEBPACK_IMPORTED_MODULE_15__["ɵɵelementEnd"]()()();
  }
  if (rf & 2) {
    const metricCompany_r8 = _angular_core__WEBPACK_IMPORTED_MODULE_15__["ɵɵreference"](8);
    const ctx_r1 = _angular_core__WEBPACK_IMPORTED_MODULE_15__["ɵɵnextContext"](2);
    _angular_core__WEBPACK_IMPORTED_MODULE_15__["ɵɵadvance"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_15__["ɵɵproperty"]("color", ctx_r1.campaignContainer == null ? null : ctx_r1.campaignContainer.campaign == null ? null : ctx_r1.campaignContainer.campaign.type);
    _angular_core__WEBPACK_IMPORTED_MODULE_15__["ɵɵadvance"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_15__["ɵɵproperty"]("interfaceOptions", _angular_core__WEBPACK_IMPORTED_MODULE_15__["ɵɵpureFunction0"](9, _c2))("value", _angular_core__WEBPACK_IMPORTED_MODULE_15__["ɵɵpipeBind1"](4, 5, ctx_r1.selectedMetric$));
    _angular_core__WEBPACK_IMPORTED_MODULE_15__["ɵɵadvance"](3);
    _angular_core__WEBPACK_IMPORTED_MODULE_15__["ɵɵproperty"]("ngIf", _angular_core__WEBPACK_IMPORTED_MODULE_15__["ɵɵpipeBind1"](6, 7, ctx_r1.campaign$).type !== "company")("ngIfElse", metricCompany_r8);
  }
}
function LeaderboardPage_ng_container_2_ion_col_15_Template(rf, ctx) {
  if (rf & 1) {
    _angular_core__WEBPACK_IMPORTED_MODULE_15__["ɵɵelementStart"](0, "ion-col")(1, "ion-item", 14);
    _angular_core__WEBPACK_IMPORTED_MODULE_15__["ɵɵtext"](2);
    _angular_core__WEBPACK_IMPORTED_MODULE_15__["ɵɵpipe"](3, "translate");
    _angular_core__WEBPACK_IMPORTED_MODULE_15__["ɵɵelementEnd"]()();
  }
  if (rf & 2) {
    const ctx_r1 = _angular_core__WEBPACK_IMPORTED_MODULE_15__["ɵɵnextContext"](2);
    _angular_core__WEBPACK_IMPORTED_MODULE_15__["ɵɵadvance"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_15__["ɵɵproperty"]("color", ctx_r1.campaignContainer == null ? null : ctx_r1.campaignContainer.campaign == null ? null : ctx_r1.campaignContainer.campaign.type);
    _angular_core__WEBPACK_IMPORTED_MODULE_15__["ɵɵadvance"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_15__["ɵɵtextInterpolate1"](" ", _angular_core__WEBPACK_IMPORTED_MODULE_15__["ɵɵpipeBind1"](3, 2, "campaigns.leaderboard.leaderboard_type.GL"), " ");
  }
}
function LeaderboardPage_ng_container_2_ng_container_23_ion_select_option_1_Template(rf, ctx) {
  if (rf & 1) {
    _angular_core__WEBPACK_IMPORTED_MODULE_15__["ɵɵelementStart"](0, "ion-select-option", 18);
    _angular_core__WEBPACK_IMPORTED_MODULE_15__["ɵɵtext"](1);
    _angular_core__WEBPACK_IMPORTED_MODULE_15__["ɵɵpipe"](2, "translate");
    _angular_core__WEBPACK_IMPORTED_MODULE_15__["ɵɵelementEnd"]();
  }
  if (rf & 2) {
    const period_r9 = ctx.$implicit;
    _angular_core__WEBPACK_IMPORTED_MODULE_15__["ɵɵproperty"]("value", period_r9);
    _angular_core__WEBPACK_IMPORTED_MODULE_15__["ɵɵadvance"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_15__["ɵɵtextInterpolate1"](" ", _angular_core__WEBPACK_IMPORTED_MODULE_15__["ɵɵpipeBind1"](2, 2, period_r9.labelKey), " ");
  }
}
function LeaderboardPage_ng_container_2_ng_container_23_Template(rf, ctx) {
  if (rf & 1) {
    _angular_core__WEBPACK_IMPORTED_MODULE_15__["ɵɵelementContainerStart"](0);
    _angular_core__WEBPACK_IMPORTED_MODULE_15__["ɵɵtemplate"](1, LeaderboardPage_ng_container_2_ng_container_23_ion_select_option_1_Template, 3, 4, "ion-select-option", 17);
    _angular_core__WEBPACK_IMPORTED_MODULE_15__["ɵɵelementContainerEnd"]();
  }
  if (rf & 2) {
    const ctx_r1 = _angular_core__WEBPACK_IMPORTED_MODULE_15__["ɵɵnextContext"](2);
    _angular_core__WEBPACK_IMPORTED_MODULE_15__["ɵɵadvance"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_15__["ɵɵproperty"]("ngForOf", ctx_r1.periods);
  }
}
function LeaderboardPage_ng_container_2_ng_template_25_ion_select_option_0_Template(rf, ctx) {
  if (rf & 1) {
    _angular_core__WEBPACK_IMPORTED_MODULE_15__["ɵɵelementStart"](0, "ion-select-option", 18);
    _angular_core__WEBPACK_IMPORTED_MODULE_15__["ɵɵtext"](1);
    _angular_core__WEBPACK_IMPORTED_MODULE_15__["ɵɵpipe"](2, "translate");
    _angular_core__WEBPACK_IMPORTED_MODULE_15__["ɵɵelementEnd"]();
  }
  if (rf & 2) {
    const period_r10 = ctx.$implicit;
    _angular_core__WEBPACK_IMPORTED_MODULE_15__["ɵɵproperty"]("value", period_r10);
    _angular_core__WEBPACK_IMPORTED_MODULE_15__["ɵɵadvance"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_15__["ɵɵtextInterpolate1"](" ", _angular_core__WEBPACK_IMPORTED_MODULE_15__["ɵɵpipeBind1"](2, 2, period_r10.labelKey), " ");
  }
}
function LeaderboardPage_ng_container_2_ng_template_25_Template(rf, ctx) {
  if (rf & 1) {
    _angular_core__WEBPACK_IMPORTED_MODULE_15__["ɵɵtemplate"](0, LeaderboardPage_ng_container_2_ng_template_25_ion_select_option_0_Template, 3, 4, "ion-select-option", 17);
  }
  if (rf & 2) {
    const ctx_r1 = _angular_core__WEBPACK_IMPORTED_MODULE_15__["ɵɵnextContext"](2);
    _angular_core__WEBPACK_IMPORTED_MODULE_15__["ɵɵproperty"]("ngForOf", ctx_r1.periodsCompany);
  }
}
function LeaderboardPage_ng_container_2_app_placing_detail_27_Template(rf, ctx) {
  if (rf & 1) {
    _angular_core__WEBPACK_IMPORTED_MODULE_15__["ɵɵelement"](0, "app-placing-detail", 19);
    _angular_core__WEBPACK_IMPORTED_MODULE_15__["ɵɵpipe"](1, "async");
    _angular_core__WEBPACK_IMPORTED_MODULE_15__["ɵɵpipe"](2, "async");
  }
  if (rf & 2) {
    const ctx_r1 = _angular_core__WEBPACK_IMPORTED_MODULE_15__["ɵɵnextContext"](2);
    _angular_core__WEBPACK_IMPORTED_MODULE_15__["ɵɵproperty"]("placing", _angular_core__WEBPACK_IMPORTED_MODULE_15__["ɵɵpipeBind1"](1, 4, ctx_r1.playerPosition$))("unitLabelKey", _angular_core__WEBPACK_IMPORTED_MODULE_15__["ɵɵpipeBind1"](2, 6, ctx_r1.numberWithUnitKey$))("first", true)("campaign", ctx_r1.campaignContainer);
  }
}
function LeaderboardPage_ng_container_2_ng_container_29_ng_template_4_Template(rf, ctx) {
  if (rf & 1) {
    _angular_core__WEBPACK_IMPORTED_MODULE_15__["ɵɵelement"](0, "app-placing-detail", 19);
    _angular_core__WEBPACK_IMPORTED_MODULE_15__["ɵɵpipe"](1, "async");
  }
  if (rf & 2) {
    const placing_r12 = ctx.item;
    const ctx_r1 = _angular_core__WEBPACK_IMPORTED_MODULE_15__["ɵɵnextContext"](3);
    _angular_core__WEBPACK_IMPORTED_MODULE_15__["ɵɵproperty"]("placing", placing_r12)("unitLabelKey", _angular_core__WEBPACK_IMPORTED_MODULE_15__["ɵɵpipeBind1"](1, 4, ctx_r1.numberWithUnitKey$))("first", false)("campaign", ctx_r1.campaignContainer);
  }
}
function LeaderboardPage_ng_container_2_ng_container_29_Template(rf, ctx) {
  if (rf & 1) {
    const _r11 = _angular_core__WEBPACK_IMPORTED_MODULE_15__["ɵɵgetCurrentView"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_15__["ɵɵelementContainerStart"](0);
    _angular_core__WEBPACK_IMPORTED_MODULE_15__["ɵɵelementStart"](1, "app-infinite-scroll", 20);
    _angular_core__WEBPACK_IMPORTED_MODULE_15__["ɵɵpipe"](2, "async");
    _angular_core__WEBPACK_IMPORTED_MODULE_15__["ɵɵpipe"](3, "async");
    _angular_core__WEBPACK_IMPORTED_MODULE_15__["ɵɵlistener"]("request", function LeaderboardPage_ng_container_2_ng_container_29_Template_app_infinite_scroll_request_1_listener($event) {
      _angular_core__WEBPACK_IMPORTED_MODULE_14__["ɵɵrestoreView"](_r11);
      const ctx_r1 = _angular_core__WEBPACK_IMPORTED_MODULE_15__["ɵɵnextContext"](2);
      return _angular_core__WEBPACK_IMPORTED_MODULE_14__["ɵɵresetView"](ctx_r1.scrollRequestSubject.next($event));
    });
    _angular_core__WEBPACK_IMPORTED_MODULE_15__["ɵɵtemplate"](4, LeaderboardPage_ng_container_2_ng_container_29_ng_template_4_Template, 2, 6, "ng-template", 21);
    _angular_core__WEBPACK_IMPORTED_MODULE_15__["ɵɵelementEnd"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_15__["ɵɵelementContainerEnd"]();
  }
  if (rf & 2) {
    const ctx_r1 = _angular_core__WEBPACK_IMPORTED_MODULE_15__["ɵɵnextContext"](2);
    _angular_core__WEBPACK_IMPORTED_MODULE_15__["ɵɵadvance"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_15__["ɵɵproperty"]("resetItems", _angular_core__WEBPACK_IMPORTED_MODULE_15__["ɵɵpipeBind1"](2, 2, ctx_r1.resetItems$))("response", _angular_core__WEBPACK_IMPORTED_MODULE_15__["ɵɵpipeBind1"](3, 4, ctx_r1.leaderboardScrollResponse$));
  }
}
function LeaderboardPage_ng_container_2_ng_template_32_Template(rf, ctx) {
  if (rf & 1) {
    _angular_core__WEBPACK_IMPORTED_MODULE_15__["ɵɵelementStart"](0, "ion-col")(1, "div", 22);
    _angular_core__WEBPACK_IMPORTED_MODULE_15__["ɵɵtext"](2);
    _angular_core__WEBPACK_IMPORTED_MODULE_15__["ɵɵpipe"](3, "translate");
    _angular_core__WEBPACK_IMPORTED_MODULE_15__["ɵɵelementEnd"]()();
  }
  if (rf & 2) {
    _angular_core__WEBPACK_IMPORTED_MODULE_15__["ɵɵadvance"](2);
    _angular_core__WEBPACK_IMPORTED_MODULE_15__["ɵɵtextInterpolate"](_angular_core__WEBPACK_IMPORTED_MODULE_15__["ɵɵpipeBind1"](3, 1, "campaigns.leaderboard.empty"));
  }
}
function LeaderboardPage_ng_container_2_Template(rf, ctx) {
  if (rf & 1) {
    const _r1 = _angular_core__WEBPACK_IMPORTED_MODULE_15__["ɵɵgetCurrentView"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_15__["ɵɵelementContainerStart"](0);
    _angular_core__WEBPACK_IMPORTED_MODULE_15__["ɵɵelementStart"](1, "div", 9)(2, "div", 10)(3, "ion-row")(4, "ion-col")(5, "ion-item", 11)(6, "ion-select", 12);
    _angular_core__WEBPACK_IMPORTED_MODULE_15__["ɵɵpipe"](7, "async");
    _angular_core__WEBPACK_IMPORTED_MODULE_15__["ɵɵpipe"](8, "async");
    _angular_core__WEBPACK_IMPORTED_MODULE_15__["ɵɵlistener"]("ionChange", function LeaderboardPage_ng_container_2_Template_ion_select_ionChange_6_listener($event) {
      _angular_core__WEBPACK_IMPORTED_MODULE_14__["ɵɵrestoreView"](_r1);
      const ctx_r1 = _angular_core__WEBPACK_IMPORTED_MODULE_15__["ɵɵnextContext"]();
      return _angular_core__WEBPACK_IMPORTED_MODULE_14__["ɵɵresetView"](ctx_r1.selectedMeanChangedSubject.next($event));
    });
    _angular_core__WEBPACK_IMPORTED_MODULE_15__["ɵɵtemplate"](9, LeaderboardPage_ng_container_2_ng_container_9_Template, 3, 3, "ng-container", 13);
    _angular_core__WEBPACK_IMPORTED_MODULE_15__["ɵɵpipe"](10, "async");
    _angular_core__WEBPACK_IMPORTED_MODULE_15__["ɵɵtemplate"](11, LeaderboardPage_ng_container_2_ng_template_11_Template, 2, 3, "ng-template", null, 0, _angular_core__WEBPACK_IMPORTED_MODULE_15__["ɵɵtemplateRefExtractor"]);
    _angular_core__WEBPACK_IMPORTED_MODULE_15__["ɵɵelementEnd"]()()();
    _angular_core__WEBPACK_IMPORTED_MODULE_15__["ɵɵtemplate"](13, LeaderboardPage_ng_container_2_ion_col_13_Template, 9, 10, "ion-col", 8);
    _angular_core__WEBPACK_IMPORTED_MODULE_15__["ɵɵpipe"](14, "async");
    _angular_core__WEBPACK_IMPORTED_MODULE_15__["ɵɵtemplate"](15, LeaderboardPage_ng_container_2_ion_col_15_Template, 4, 4, "ion-col", 8);
    _angular_core__WEBPACK_IMPORTED_MODULE_15__["ɵɵpipe"](16, "async");
    _angular_core__WEBPACK_IMPORTED_MODULE_15__["ɵɵelementEnd"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_15__["ɵɵelementStart"](17, "ion-row")(18, "ion-col")(19, "ion-item", 14)(20, "ion-select", 15, 1);
    _angular_core__WEBPACK_IMPORTED_MODULE_15__["ɵɵpipe"](22, "async");
    _angular_core__WEBPACK_IMPORTED_MODULE_15__["ɵɵlistener"]("ionChange", function LeaderboardPage_ng_container_2_Template_ion_select_ionChange_20_listener($event) {
      _angular_core__WEBPACK_IMPORTED_MODULE_14__["ɵɵrestoreView"](_r1);
      const ctx_r1 = _angular_core__WEBPACK_IMPORTED_MODULE_15__["ɵɵnextContext"]();
      return _angular_core__WEBPACK_IMPORTED_MODULE_14__["ɵɵresetView"](ctx_r1.periodChangedSubject.next($event));
    });
    _angular_core__WEBPACK_IMPORTED_MODULE_15__["ɵɵtemplate"](23, LeaderboardPage_ng_container_2_ng_container_23_Template, 2, 1, "ng-container", 13);
    _angular_core__WEBPACK_IMPORTED_MODULE_15__["ɵɵpipe"](24, "async");
    _angular_core__WEBPACK_IMPORTED_MODULE_15__["ɵɵtemplate"](25, LeaderboardPage_ng_container_2_ng_template_25_Template, 1, 1, "ng-template", null, 2, _angular_core__WEBPACK_IMPORTED_MODULE_15__["ɵɵtemplateRefExtractor"]);
    _angular_core__WEBPACK_IMPORTED_MODULE_15__["ɵɵelementEnd"]()()()();
    _angular_core__WEBPACK_IMPORTED_MODULE_15__["ɵɵtemplate"](27, LeaderboardPage_ng_container_2_app_placing_detail_27_Template, 3, 8, "app-placing-detail", 16);
    _angular_core__WEBPACK_IMPORTED_MODULE_15__["ɵɵpipe"](28, "async");
    _angular_core__WEBPACK_IMPORTED_MODULE_15__["ɵɵelementEnd"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_15__["ɵɵtemplate"](29, LeaderboardPage_ng_container_2_ng_container_29_Template, 5, 6, "ng-container", 13);
    _angular_core__WEBPACK_IMPORTED_MODULE_15__["ɵɵpipe"](30, "async");
    _angular_core__WEBPACK_IMPORTED_MODULE_15__["ɵɵpipe"](31, "async");
    _angular_core__WEBPACK_IMPORTED_MODULE_15__["ɵɵtemplate"](32, LeaderboardPage_ng_container_2_ng_template_32_Template, 4, 3, "ng-template", null, 3, _angular_core__WEBPACK_IMPORTED_MODULE_15__["ɵɵtemplateRefExtractor"]);
    _angular_core__WEBPACK_IMPORTED_MODULE_15__["ɵɵelementEnd"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_15__["ɵɵelementContainerEnd"]();
  }
  if (rf & 2) {
    let tmp_20_0;
    let tmp_21_0;
    const meansCompany_r13 = _angular_core__WEBPACK_IMPORTED_MODULE_15__["ɵɵreference"](12);
    const periodCompany_r14 = _angular_core__WEBPACK_IMPORTED_MODULE_15__["ɵɵreference"](26);
    const emptyLead_r15 = _angular_core__WEBPACK_IMPORTED_MODULE_15__["ɵɵreference"](33);
    const ctx_r1 = _angular_core__WEBPACK_IMPORTED_MODULE_15__["ɵɵnextContext"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_15__["ɵɵadvance"](2);
    _angular_core__WEBPACK_IMPORTED_MODULE_15__["ɵɵstyleProp"]("color", "var(--ion-color-" + ctx_r1.campaignContainer.campaign.type + "-stat-contrast)")("background-color", "var(--ion-color-" + ctx_r1.campaignContainer.campaign.type + ")");
    _angular_core__WEBPACK_IMPORTED_MODULE_15__["ɵɵadvance"](3);
    _angular_core__WEBPACK_IMPORTED_MODULE_15__["ɵɵproperty"]("color", ctx_r1.campaignContainer == null ? null : ctx_r1.campaignContainer.campaign == null ? null : ctx_r1.campaignContainer.campaign.type);
    _angular_core__WEBPACK_IMPORTED_MODULE_15__["ɵɵadvance"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_15__["ɵɵproperty"]("disabled", _angular_core__WEBPACK_IMPORTED_MODULE_15__["ɵɵpipeBind1"](7, 20, ctx_r1.useMeanAndMetric$) === false)("interfaceOptions", _angular_core__WEBPACK_IMPORTED_MODULE_15__["ɵɵpureFunction0"](40, _c2))("value", _angular_core__WEBPACK_IMPORTED_MODULE_15__["ɵɵpipeBind1"](8, 22, ctx_r1.selectedMean$));
    _angular_core__WEBPACK_IMPORTED_MODULE_15__["ɵɵadvance"](3);
    _angular_core__WEBPACK_IMPORTED_MODULE_15__["ɵɵproperty"]("ngIf", _angular_core__WEBPACK_IMPORTED_MODULE_15__["ɵɵpipeBind1"](10, 24, ctx_r1.campaign$).type !== "company")("ngIfElse", meansCompany_r13);
    _angular_core__WEBPACK_IMPORTED_MODULE_15__["ɵɵadvance"](4);
    _angular_core__WEBPACK_IMPORTED_MODULE_15__["ɵɵproperty"]("ngIf", _angular_core__WEBPACK_IMPORTED_MODULE_15__["ɵɵpipeBind1"](14, 26, ctx_r1.useMeanAndMetric$));
    _angular_core__WEBPACK_IMPORTED_MODULE_15__["ɵɵadvance"](2);
    _angular_core__WEBPACK_IMPORTED_MODULE_15__["ɵɵproperty"]("ngIf", _angular_core__WEBPACK_IMPORTED_MODULE_15__["ɵɵpipeBind1"](16, 28, ctx_r1.useMeanAndMetric$) === false);
    _angular_core__WEBPACK_IMPORTED_MODULE_15__["ɵɵadvance"](4);
    _angular_core__WEBPACK_IMPORTED_MODULE_15__["ɵɵproperty"]("color", ctx_r1.campaignContainer == null ? null : ctx_r1.campaignContainer.campaign == null ? null : ctx_r1.campaignContainer.campaign.type);
    _angular_core__WEBPACK_IMPORTED_MODULE_15__["ɵɵadvance"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_15__["ɵɵproperty"]("interfaceOptions", _angular_core__WEBPACK_IMPORTED_MODULE_15__["ɵɵpureFunction0"](41, _c2))("value", _angular_core__WEBPACK_IMPORTED_MODULE_15__["ɵɵpipeBind1"](22, 30, ctx_r1.selectedPeriod$));
    _angular_core__WEBPACK_IMPORTED_MODULE_15__["ɵɵadvance"](3);
    _angular_core__WEBPACK_IMPORTED_MODULE_15__["ɵɵproperty"]("ngIf", _angular_core__WEBPACK_IMPORTED_MODULE_15__["ɵɵpipeBind1"](24, 32, ctx_r1.campaign$).type !== "company")("ngIfElse", periodCompany_r14);
    _angular_core__WEBPACK_IMPORTED_MODULE_15__["ɵɵadvance"](4);
    _angular_core__WEBPACK_IMPORTED_MODULE_15__["ɵɵproperty"]("ngIf", ((tmp_20_0 = _angular_core__WEBPACK_IMPORTED_MODULE_15__["ɵɵpipeBind1"](28, 34, ctx_r1.leaderboardScrollResponse$)) == null ? null : tmp_20_0.totalElements) > 0);
    _angular_core__WEBPACK_IMPORTED_MODULE_15__["ɵɵadvance"](2);
    _angular_core__WEBPACK_IMPORTED_MODULE_15__["ɵɵproperty"]("ngIf", ((tmp_21_0 = _angular_core__WEBPACK_IMPORTED_MODULE_15__["ɵɵpipeBind1"](30, 36, ctx_r1.leaderboardScrollResponse$)) == null ? null : tmp_21_0.totalElements) > 0 && _angular_core__WEBPACK_IMPORTED_MODULE_15__["ɵɵpipeBind1"](31, 38, ctx_r1.filterOptions$))("ngIfElse", emptyLead_r15);
  }
}
class LeaderboardPage {
  getMetricsCompany(campaign) {
    // based on available metrics in campaign
    return this.metricsCompany?.filter(metricCompany => campaign?.campaignPlacement?.configuration[metricsCompanyConfigurations.find(metricConf => metricConf.metric === metricCompany).configurationKey] === true);
  }
  constructor(route, reportControllerService, userService, campaignService, errorService, pageSettingsService, cdref) {
    this.route = route;
    this.reportControllerService = reportControllerService;
    this.userService = userService;
    this.campaignService = campaignService;
    this.errorService = errorService;
    this.pageSettingsService = pageSettingsService;
    this.cdref = cdref;
    this.referenceDate = luxon__WEBPACK_IMPORTED_MODULE_10__.DateTime.local();
    this.periods = this.getPeriods(this.referenceDate);
    this.metricToNumberWithUnitLabel = {
      co2: 'campaigns.leaderboard.leaderboard_type_unit.co2',
      km: 'campaigns.leaderboard.leaderboard_type_unit.km',
      virtualScore: 'campaigns.leaderboard.leaderboard_type_unit.GL',
      time: 'campaigns.leaderboard.leaderboard_type_unit.duration',
      tracks: 'campaigns.leaderboard.leaderboard_type_unit.tracks',
      virtualTrack: 'campaigns.leaderboard.leaderboard_type_unit.virtualTrack'
    };
    this.metricToUnitLabel = {
      co2: 'campaigns.leaderboard.unit.co2',
      km: 'campaigns.leaderboard.unit.km',
      virtualScore: 'campaigns.leaderboard.unit.virtualScore',
      time: 'campaigns.leaderboard.unit.duration',
      tracks: 'campaigns.leaderboard.unit.tracks',
      virtualTrack: 'campaigns.leaderboard.unit.virtualTrack'
    };
    this.meanLabels = {
      ...src_app_core_shared_tracking_trip_model__WEBPACK_IMPORTED_MODULE_11__.transportTypeLabels,
      [ALL_MEANS]: 'campaigns.leaderboard.all_means'
    };
    this.campaignId$ = this.route.params.pipe((0,rxjs_operators__WEBPACK_IMPORTED_MODULE_6__.map)(params => params.id), (0,rxjs_operators__WEBPACK_IMPORTED_MODULE_4__.distinctUntilChanged)(), (0,rxjs_operators__WEBPACK_IMPORTED_MODULE_7__.shareReplay)(1));
    this.campaign$ = this.campaignId$.pipe((0,rxjs_operators__WEBPACK_IMPORTED_MODULE_9__.switchMap)(campaignId => this.campaignService.allCampaigns$.pipe((0,rxjs_operators__WEBPACK_IMPORTED_MODULE_6__.map)(campaigns => (0,lodash_es__WEBPACK_IMPORTED_MODULE_0__["default"])(campaigns, {
      campaignId
    })), (0,src_app_core_shared_rxjs_utils__WEBPACK_IMPORTED_MODULE_12__.throwIfNil)(() => new Error('Campaign not found')), this.errorService.getErrorHandler())), (0,rxjs_operators__WEBPACK_IMPORTED_MODULE_7__.shareReplay)(1));
    this.useMeanAndMetric$ = this.campaign$.pipe((0,rxjs_operators__WEBPACK_IMPORTED_MODULE_6__.map)(campaign => campaign.type === 'personal' || campaign.type === 'company' && this.campaignContainer?.campaign?.campaignPlacement.active));
    this.means$ = this.campaignService.availableMeans$.pipe((0,rxjs_operators__WEBPACK_IMPORTED_MODULE_6__.map)(availableMeans => [ALL_MEANS, ...availableMeans]));
    this.meansForCompany$ = (0,rxjs__WEBPACK_IMPORTED_MODULE_2__.combineLatest)([this.means$, this.campaign$]).pipe((0,rxjs_operators__WEBPACK_IMPORTED_MODULE_9__.switchMap)(([means, campaign]) => {
      if (!campaign?.campaignPlacement?.configuration?.meansShow) {
        return (0,rxjs__WEBPACK_IMPORTED_MODULE_3__.of)([ALL_MEANS]);
      }
      return (0,rxjs__WEBPACK_IMPORTED_MODULE_3__.of)([...means]);
    }));
    this.selectedMeanChangedSubject = new rxjs__WEBPACK_IMPORTED_MODULE_1__.Subject();
    this.selectedMean$ = this.selectedMeanChangedSubject.pipe((0,rxjs_operators__WEBPACK_IMPORTED_MODULE_6__.map)(event => event.detail.value), (0,rxjs_operators__WEBPACK_IMPORTED_MODULE_8__.startWith)(ALL_MEANS), (0,rxjs_operators__WEBPACK_IMPORTED_MODULE_7__.shareReplay)(1));
    this.metrics = ['co2', 'km'];
    this.metricsCompany = ['co2', 'km', 'virtualScore', 'time', 'tracks', 'virtualTrack'];
    this.metrics$ = this.campaign$.pipe((0,rxjs_operators__WEBPACK_IMPORTED_MODULE_6__.map)(campaign => {
      campaign?.campaignPlacement?.active ? this.metricToUnitLabel['virtualScore'] = 'campaigns.leaderboard.unit.virtualScore' : null;
      return campaign?.campaignPlacement?.active ? [...this.metrics, 'virtualScore'] : [...this.metrics];
    }));
    this.metricsCompany$ = this.campaign$.pipe((0,rxjs_operators__WEBPACK_IMPORTED_MODULE_6__.map)(campaign => {
      return this.getMetricsCompany(campaign);
    }));
    this.selectedMetricChangedSubject = new rxjs__WEBPACK_IMPORTED_MODULE_1__.Subject();
    this.selectedMetric$ = this.selectedMetricChangedSubject.pipe((0,rxjs_operators__WEBPACK_IMPORTED_MODULE_6__.map)(event => event.detail.value), (0,rxjs_operators__WEBPACK_IMPORTED_MODULE_8__.startWith)(
    // initial select value
    'co2'), (0,rxjs_operators__WEBPACK_IMPORTED_MODULE_7__.shareReplay)(1));
    this.periodChangedSubject = new rxjs__WEBPACK_IMPORTED_MODULE_1__.Subject();
    this.selectedPeriod$ = this.periodChangedSubject.pipe((0,rxjs_operators__WEBPACK_IMPORTED_MODULE_6__.map)(event => event.detail.value), (0,rxjs_operators__WEBPACK_IMPORTED_MODULE_8__.startWith)((0,lodash_es__WEBPACK_IMPORTED_MODULE_0__["default"])(this.periods, {
      default: true
    })),
    // initial select value
    (0,rxjs_operators__WEBPACK_IMPORTED_MODULE_7__.shareReplay)(1));
    this.playerId$ = this.userService.userProfile$.pipe((0,rxjs_operators__WEBPACK_IMPORTED_MODULE_6__.map)(userProfile => userProfile.playerId), (0,rxjs_operators__WEBPACK_IMPORTED_MODULE_4__.distinctUntilChanged)());
    this.filterOptions$ = (0,rxjs__WEBPACK_IMPORTED_MODULE_2__.combineLatest)({
      mean: this.selectedMean$,
      metric: this.selectedMetric$,
      period: this.selectedPeriod$,
      campaignId: this.campaignId$,
      useMeanAndMetric: this.useMeanAndMetric$,
      playerId: this.playerId$
    });
    this.numberWithUnitKey$ = this.filterOptions$.pipe((0,rxjs_operators__WEBPACK_IMPORTED_MODULE_6__.map)(({
      useMeanAndMetric,
      metric
    }) => useMeanAndMetric ? this.metricToNumberWithUnitLabel[metric] : 'campaigns.leaderboard.leaderboard_type_unit.GL'), (0,rxjs_operators__WEBPACK_IMPORTED_MODULE_7__.shareReplay)(1));
    this.playerPosition$ = this.filterOptions$.pipe((0,rxjs_operators__WEBPACK_IMPORTED_MODULE_9__.switchMap)(({
      useMeanAndMetric,
      metric,
      mean,
      period,
      campaignId,
      playerId
    }) => {
      if (useMeanAndMetric) {
        return this.reportControllerService.getPlayerCampaingPlacingByTransportModeUsingGET({
          campaignId,
          metric,
          mean: mean === ALL_MEANS ? null : mean,
          playerId,
          dateFrom: period.from,
          dateTo: period.to,
          filterByGroupId: filterByGroup(this.campaignContainer) ? this.campaignContainer?.subscription?.campaignData?.companyKey : null
        }).pipe(this.errorService.getErrorHandler());
      } else {
        return this.reportControllerService.getPlayerCampaingPlacingByGameUsingGET({
          campaignId,
          playerId,
          dateFrom: period.from,
          dateTo: period.to
        }).pipe(this.errorService.getErrorHandler());
      }
    }), (0,rxjs_operators__WEBPACK_IMPORTED_MODULE_7__.shareReplay)(1));
    this.scrollRequestSubject = new rxjs__WEBPACK_IMPORTED_MODULE_1__.Subject();
    this.leaderboardScrollResponse$ = this.filterOptions$.pipe((0,rxjs_operators__WEBPACK_IMPORTED_MODULE_9__.switchMap)(({
      useMeanAndMetric,
      metric,
      mean,
      period,
      campaignId
    }) => this.scrollRequestSubject.pipe((0,rxjs_operators__WEBPACK_IMPORTED_MODULE_8__.startWith)({
      page: 0,
      size: 10
    }), (0,rxjs_operators__WEBPACK_IMPORTED_MODULE_9__.switchMap)(({
      page,
      size
    }) => {
      if (useMeanAndMetric) {
        return this.reportControllerService.getCampaingPlacingByTransportStatsUsingGET({
          page,
          size,
          campaignId,
          metric,
          mean: mean === ALL_MEANS ? null : mean,
          dateFrom: period.from,
          dateTo: period.to,
          filterByGroupId: filterByGroup(this.campaignContainer) ? this.campaignContainer?.subscription?.campaignData?.companyKey : null
        }).pipe(this.errorService.getErrorHandler());
      } else {
        return this.reportControllerService.getCampaingPlacingByGameUsingGET({
          page,
          size,
          campaignId,
          dateFrom: period.from,
          dateTo: period.to
        }).pipe(this.errorService.getErrorHandler());
      }
    }))));
    this.resetItems$ = this.filterOptions$.pipe((0,rxjs_operators__WEBPACK_IMPORTED_MODULE_6__.map)(() => Symbol()));
    this.subId = this.route.params.subscribe(params => {
      this.id = params.id;
      this.subCampaign = this.campaignService.myCampaigns$.subscribe(campaigns => {
        this.campaignContainer = campaigns.find(campaignContainer => campaignContainer.campaign.campaignId === this.id);
        this.filterPeriods(this.campaignContainer);
        this.filterMetrics(this.campaignContainer);
      });
    });
  }
  ngAfterContentChecked() {
    this.cdref.detectChanges();
  }
  filterMetrics(campaign) {
    if (campaign?.campaign?.type === 'company') {
      this.selectedMetricChangedSubject.next({
        detail: {
          value: this.metricsCompany.find(metric => campaign?.campaign?.campaignPlacement?.configuration?.metricDefault === metricsCompanyConfigurations.find(metricConf => metricConf.metric === metric).configurationKey)
        }
      });
    }
  }
  filterPeriods(campaign) {
    if (campaign?.campaign?.type === 'company') {
      this.periodsCompany = this.getPeriods(this.referenceDate).filter(period => campaign?.campaign?.campaignPlacement?.configuration[period.configurationKey] === true);
      this.periodChangedSubject.next({
        detail: {
          value: this.periodsCompany.find(period => campaign?.campaign?.campaignPlacement?.configuration?.periodDefault === period.configurationKey)
        }
      });
    }
  }
  ngOnDestroy() {
    this.subCampaign.unsubscribe();
    this.subId.unsubscribe();
  }
  ionViewWillEnter() {
    this.changePageSettings();
  }
  ngAfterViewInit() {
    setTimeout(() => {
      this.subSelectChange = this.selects.changes.pipe((0,rxjs_operators__WEBPACK_IMPORTED_MODULE_8__.startWith)(undefined)).subscribe(comps => {
        if (comps?.length > 0) {
          this.periodSelect = comps.first;
        }
        this.filterPeriods(this.campaignContainer);
      });
      this.subMetricSelectChange = this.metricSelects.changes.pipe((0,rxjs_operators__WEBPACK_IMPORTED_MODULE_8__.startWith)(undefined)).subscribe(comps => {
        if (comps?.length > 0) {
          this.metricSelect = comps.first;
        }
        console.log(this.metricSelect);
        this.filterMetrics(this.campaignContainer);
      });
    }, 0);
  }
  changePageSettings() {
    this.pageSettingsService.set({
      color: this.campaignContainer?.campaign?.type
    });
  }
  getPeriods(referenceDate) {
    return [{
      labelKey: 'campaigns.leaderboard.period.today',
      from: this.toServerDate(referenceDate.startOf('day')),
      to: this.toServerDate(referenceDate),
      configurationKey: 'periodToday',
      default: false
    }, {
      labelKey: 'campaigns.leaderboard.period.this_week',
      from: this.toServerDate(referenceDate.startOf('week')),
      to: this.toServerDate(referenceDate),
      configurationKey: 'periodCurrentWeek',
      default: true
    }, {
      labelKey: 'campaigns.leaderboard.period.last_week',
      from: this.toServerDate(referenceDate.startOf('week').minus({
        weeks: 1
      })),
      to: this.toServerDate(referenceDate.startOf('week').minus({
        weeks: 1
      }).endOf('week')),
      configurationKey: 'periodLastWeek',
      default: false
    }, {
      labelKey: 'campaigns.leaderboard.period.this_month',
      from: this.toServerDate(referenceDate.startOf('month')),
      to: this.toServerDate(referenceDate),
      configurationKey: 'periodCurrentMonth',
      default: false
    }, {
      labelKey: 'campaigns.leaderboard.period.all_time',
      // not specifying dates, will improve the server performance because of special handling
      // but we will lose the confidence that player position and leaderboard are in sync.
      // maybe it is not such deal, "All Time" leaderboard will not change so rapidly.
      from: null,
      //this.toServerDate(minusInfDate),
      to: null,
      //this.toServerDate(referenceDate),
      configurationKey: 'periodGeneral',
      default: false
    }];
  }
  toServerDate(dateTime) {
    // TODO: This is actually quite tricky bug.
    // When we round reference date to the start of the day, than we get this period
    // from beginning of the day to now, where events affecting this period will
    // cause inconsistent data between the loaded pages of pagination.
    return (0,src_app_core_shared_time_utils__WEBPACK_IMPORTED_MODULE_13__.toServerDateOnly)(dateTime);
  }
  ngOnInit() {}
  static #_ = _staticBlock = () => (this.ɵfac = function LeaderboardPage_Factory(__ngFactoryType__) {
    return new (__ngFactoryType__ || LeaderboardPage)(_angular_core__WEBPACK_IMPORTED_MODULE_15__["ɵɵdirectiveInject"](_angular_router__WEBPACK_IMPORTED_MODULE_17__.ActivatedRoute), _angular_core__WEBPACK_IMPORTED_MODULE_15__["ɵɵdirectiveInject"](src_app_core_api_generated_controllers_reportController_service__WEBPACK_IMPORTED_MODULE_18__.ReportControllerService), _angular_core__WEBPACK_IMPORTED_MODULE_15__["ɵɵdirectiveInject"](src_app_core_shared_services_user_service__WEBPACK_IMPORTED_MODULE_19__.UserService), _angular_core__WEBPACK_IMPORTED_MODULE_15__["ɵɵdirectiveInject"](src_app_core_shared_services_campaign_service__WEBPACK_IMPORTED_MODULE_20__.CampaignService), _angular_core__WEBPACK_IMPORTED_MODULE_15__["ɵɵdirectiveInject"](src_app_core_shared_services_error_service__WEBPACK_IMPORTED_MODULE_21__.ErrorService), _angular_core__WEBPACK_IMPORTED_MODULE_15__["ɵɵdirectiveInject"](src_app_core_shared_services_page_settings_service__WEBPACK_IMPORTED_MODULE_22__.PageSettingsService), _angular_core__WEBPACK_IMPORTED_MODULE_15__["ɵɵdirectiveInject"](_angular_core__WEBPACK_IMPORTED_MODULE_16__.ChangeDetectorRef));
  }, this.ɵcmp = /*@__PURE__*/_angular_core__WEBPACK_IMPORTED_MODULE_15__["ɵɵdefineComponent"]({
    type: LeaderboardPage,
    selectors: [["app-leaderboard"]],
    viewQuery: function LeaderboardPage_Query(rf, ctx) {
      if (rf & 1) {
        _angular_core__WEBPACK_IMPORTED_MODULE_15__["ɵɵviewQuery"](_c0, 5);
        _angular_core__WEBPACK_IMPORTED_MODULE_15__["ɵɵviewQuery"](_c1, 5);
      }
      if (rf & 2) {
        let _t;
        _angular_core__WEBPACK_IMPORTED_MODULE_15__["ɵɵqueryRefresh"](_t = _angular_core__WEBPACK_IMPORTED_MODULE_15__["ɵɵloadQuery"]()) && (ctx.selects = _t);
        _angular_core__WEBPACK_IMPORTED_MODULE_15__["ɵɵqueryRefresh"](_t = _angular_core__WEBPACK_IMPORTED_MODULE_15__["ɵɵloadQuery"]()) && (ctx.metricSelects = _t);
      }
    },
    standalone: false,
    decls: 4,
    vars: 3,
    consts: [["meansCompany", ""], ["periodSelect", ""], ["periodCompany", ""], ["emptyLead", ""], ["metricSelect", ""], ["metricCompany", ""], ["appHeader", ""], ["appContent", "", 1, "page"], [4, "ngIf"], [1, "header-margin"], [1, "header-sticky"], [1, "header-radius", 3, "color"], ["interface", "popover", 3, "ionChange", "disabled", "interfaceOptions", "value"], [4, "ngIf", "ngIfElse"], [3, "color"], ["interface", "popover", 3, "ionChange", "interfaceOptions", "value"], [3, "placing", "unitLabelKey", "first", "campaign", 4, "ngIf"], [3, "value", 4, "ngFor", "ngForOf"], [3, "value"], [3, "placing", "unitLabelKey", "first", "campaign"], [3, "request", "resetItems", "response"], ["appInfiniteScrollContent", ""], [1, "empty-lead"]],
    template: function LeaderboardPage_Template(rf, ctx) {
      if (rf & 1) {
        _angular_core__WEBPACK_IMPORTED_MODULE_15__["ɵɵelement"](0, "ion-header", 6);
        _angular_core__WEBPACK_IMPORTED_MODULE_15__["ɵɵelementStart"](1, "ion-content", 7);
        _angular_core__WEBPACK_IMPORTED_MODULE_15__["ɵɵtemplate"](2, LeaderboardPage_ng_container_2_Template, 34, 42, "ng-container", 8);
        _angular_core__WEBPACK_IMPORTED_MODULE_15__["ɵɵpipe"](3, "async");
        _angular_core__WEBPACK_IMPORTED_MODULE_15__["ɵɵelementEnd"]();
      }
      if (rf & 2) {
        _angular_core__WEBPACK_IMPORTED_MODULE_15__["ɵɵadvance"](2);
        _angular_core__WEBPACK_IMPORTED_MODULE_15__["ɵɵproperty"]("ngIf", _angular_core__WEBPACK_IMPORTED_MODULE_15__["ɵɵpipeBind1"](3, 1, ctx.campaign$) !== null && ctx.campaignContainer !== null);
      }
    },
    dependencies: [_angular_common__WEBPACK_IMPORTED_MODULE_23__.NgForOf, _angular_common__WEBPACK_IMPORTED_MODULE_23__.NgIf, _ionic_angular__WEBPACK_IMPORTED_MODULE_24__.IonCol, _ionic_angular__WEBPACK_IMPORTED_MODULE_24__.IonContent, _ionic_angular__WEBPACK_IMPORTED_MODULE_24__.IonHeader, _ionic_angular__WEBPACK_IMPORTED_MODULE_24__.IonItem, _ionic_angular__WEBPACK_IMPORTED_MODULE_24__.IonRow, _ionic_angular__WEBPACK_IMPORTED_MODULE_24__.IonSelect, _ionic_angular__WEBPACK_IMPORTED_MODULE_24__.IonSelectOption, _ionic_angular__WEBPACK_IMPORTED_MODULE_24__.SelectValueAccessor, _core_shared_layout_header_header_directive__WEBPACK_IMPORTED_MODULE_25__.HeaderDirective, _core_shared_layout_content_content_directive__WEBPACK_IMPORTED_MODULE_26__.ContentDirective, _core_shared_infinite_scroll_infinite_scroll_component__WEBPACK_IMPORTED_MODULE_27__.InfiniteScrollComponent, _core_shared_infinite_scroll_infinite_scroll_component__WEBPACK_IMPORTED_MODULE_27__.InfiniteScrollContentDirective, _placing_detail_placing_detail_component__WEBPACK_IMPORTED_MODULE_28__.PlacingDetailComponent, _angular_common__WEBPACK_IMPORTED_MODULE_23__.AsyncPipe, _ngx_translate_core__WEBPACK_IMPORTED_MODULE_29__.TranslatePipe],
    styles: [".header-margin[_ngcontent-%COMP%] {\n  margin: 8px;\n}\n.header-margin[_ngcontent-%COMP%]   .header-radius[_ngcontent-%COMP%] {\n  border-radius: 8px 8px 0 0;\n}\n\n.empty-lead[_ngcontent-%COMP%] {\n  margin: auto;\n  padding: 8px;\n  font-size: 20px;\n  text-align: center;\n}\n/*# sourceMappingURL=data:application/json;charset=utf-8;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbIndlYnBhY2s6Ly8uL3NyYy9hcHAvcGFnZXMvaG9tZS9jYW1wYWlnbi1kZXRhaWxzL2xlYWRlcmJvYXJkL2xlYWRlcmJvYXJkLnBhZ2Uuc2NzcyJdLCJuYW1lcyI6W10sIm1hcHBpbmdzIjoiQUFBQTtFQUNFLFdBQUE7QUFDRjtBQUFFO0VBQ0UsMEJBQUE7QUFFSjs7QUFDQTtFQUNFLFlBQUE7RUFDQSxZQUFBO0VBQ0EsZUFBQTtFQUNBLGtCQUFBO0FBRUYiLCJzb3VyY2VzQ29udGVudCI6WyIuaGVhZGVyLW1hcmdpbiB7XG4gIG1hcmdpbjogOHB4O1xuICAuaGVhZGVyLXJhZGl1cyB7XG4gICAgYm9yZGVyLXJhZGl1czogOHB4IDhweCAwIDA7XG4gIH1cbn1cbi5lbXB0eS1sZWFkIHtcbiAgbWFyZ2luOiBhdXRvO1xuICBwYWRkaW5nOiA4cHg7XG4gIGZvbnQtc2l6ZTogMjBweDtcbiAgdGV4dC1hbGlnbjogY2VudGVyO1xufVxuIl0sInNvdXJjZVJvb3QiOiIifQ== */"]
  }));
}
_staticBlock();
const ALL_MEANS = 'ALL_MEANS';
function filterByGroup(campaignContainer) {
  return campaignContainer?.campaign?.campaignPlacement?.active;
}
function waitFor(signal) {
  return source => signal.pipe((0,rxjs_operators__WEBPACK_IMPORTED_MODULE_5__.first)(), (0,rxjs_operators__WEBPACK_IMPORTED_MODULE_9__.switchMap)(_ => source));
}
const metricsCompanyConfigurations = [{
  metric: 'co2',
  configurationKey: 'metricCo2'
}, {
  metric: 'km',
  configurationKey: 'metricDistance'
}, {
  metric: 'virtualScore',
  configurationKey: 'metricVirtualScore'
}, {
  metric: 'time',
  configurationKey: 'metricDuration'
}, {
  metric: 'tracks',
  configurationKey: 'metricTrackNumber'
}, {
  metric: 'virtualTrack',
  configurationKey: 'metricVirtualTrack'
}];

/***/ }),

/***/ 67183:
/*!****************************************************************************************************!*\
  !*** ./src/app/pages/home/campaign-details/leaderboard/placing-detail/placing-detail.component.ts ***!
  \****************************************************************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   PlacingDetailComponent: () => (/* binding */ PlacingDetailComponent)
/* harmony export */ });
/* harmony import */ var rxjs_operators__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! rxjs/operators */ 70271);
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @angular/core */ 12481);
/* harmony import */ var src_app_core_shared_services_user_service__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! src/app/core/shared/services/user.service */ 89815);
/* harmony import */ var src_app_core_shared_services_campaign_service__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! src/app/core/shared/services/campaign.service */ 76658);
/* harmony import */ var _angular_router__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! @angular/router */ 34487);
/* harmony import */ var _angular_common__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! @angular/common */ 93683);
/* harmony import */ var _ionic_angular__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! @ionic/angular */ 21507);
/* harmony import */ var _core_shared_globalization_ordinal_number_ordinal_number_component__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(/*! ../../../../../core/shared/globalization/ordinal-number/ordinal-number.component */ 6972);
/* harmony import */ var _core_shared_ui_icon_icon_component__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(/*! ../../../../../core/shared/ui/icon/icon.component */ 59621);
/* harmony import */ var _ngx_translate_core__WEBPACK_IMPORTED_MODULE_9__ = __webpack_require__(/*! @ngx-translate/core */ 48503);
/* harmony import */ var _core_shared_pipes_localNumber_pipe__WEBPACK_IMPORTED_MODULE_10__ = __webpack_require__(/*! ../../../../../core/shared/pipes/localNumber.pipe */ 16024);
var _staticBlock;











const _c0 = a0 => ({
  border: a0
});
const _c1 = a0 => [a0];
const _c2 = () => [];
const _c3 = a0 => ({
  value: a0
});
function PlacingDetailComponent_ion_item_0_ng_container_7_Template(rf, ctx) {
  if (rf & 1) {
    _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵelementContainerStart"](0);
    _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵelementStart"](1, "ion-col", 3)(2, "ion-avatar");
    _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵelement"](3, "img", 11);
    _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵpipe"](4, "async");
    _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵelementEnd"]()();
    _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵelementContainerEnd"]();
  }
  if (rf & 2) {
    const ctx_r0 = _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵnextContext"](2);
    _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵadvance"](3);
    _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵproperty"]("src", _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵpipeBind1"](4, 1, ctx_r0.playerAvatarUrl$), _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵsanitizeUrl"]);
  }
}
function PlacingDetailComponent_ion_item_0_ng_container_9_ion_avatar_2_Template(rf, ctx) {
  if (rf & 1) {
    _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵelementStart"](0, "ion-avatar");
    _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵelement"](1, "img", 11);
    _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵelementEnd"]();
  }
  if (rf & 2) {
    const ctx_r0 = _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵnextContext"](3);
    _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵadvance"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵproperty"]("src", ctx_r0.placing.avatar.url, _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵsanitizeUrl"]);
  }
}
function PlacingDetailComponent_ion_item_0_ng_container_9_ng_template_3_Template(rf, ctx) {
  if (rf & 1) {
    _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵelementStart"](0, "ion-avatar");
    _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵelement"](1, "ion-icon", 13);
    _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵelementEnd"]();
  }
}
function PlacingDetailComponent_ion_item_0_ng_container_9_Template(rf, ctx) {
  if (rf & 1) {
    _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵelementContainerStart"](0);
    _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵelementStart"](1, "ion-col", 3);
    _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵtemplate"](2, PlacingDetailComponent_ion_item_0_ng_container_9_ion_avatar_2_Template, 2, 1, "ion-avatar", 12)(3, PlacingDetailComponent_ion_item_0_ng_container_9_ng_template_3_Template, 2, 0, "ng-template", null, 0, _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵtemplateRefExtractor"]);
    _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵelementEnd"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵelementContainerEnd"]();
  }
  if (rf & 2) {
    const alternativeAvatar_r2 = _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵreference"](4);
    const ctx_r0 = _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵnextContext"](2);
    _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵadvance"](2);
    _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵproperty"]("ngIf", ctx_r0.placing.avatar)("ngIfElse", alternativeAvatar_r2);
  }
}
function PlacingDetailComponent_ion_item_0_Template(rf, ctx) {
  if (rf & 1) {
    _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵelementStart"](0, "ion-item", 2);
    _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵpipe"](1, "async");
    _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵpipe"](2, "async");
    _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵelementStart"](3, "ion-grid")(4, "ion-row")(5, "ion-col", 3);
    _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵelement"](6, "app-ordinal-number", 4);
    _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵelementEnd"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵtemplate"](7, PlacingDetailComponent_ion_item_0_ng_container_7_Template, 5, 3, "ng-container", 5);
    _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵpipe"](8, "async");
    _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵtemplate"](9, PlacingDetailComponent_ion_item_0_ng_container_9_Template, 5, 2, "ng-container", 5);
    _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵpipe"](10, "async");
    _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵelementStart"](11, "ion-col", 6)(12, "span", 7);
    _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵtext"](13);
    _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵelementEnd"]()();
    _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵelementStart"](14, "ion-col", 8)(15, "div", 9);
    _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵtext"](16);
    _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵpipe"](17, "localNumber");
    _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵpipe"](18, "translate");
    _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵelement"](19, "app-icon", 10);
    _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵelementEnd"]()()()()();
  }
  if (rf & 2) {
    const ctx_r0 = _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵnextContext"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵclassProp"]("my-placing", _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵpipeBind1"](1, 10, ctx_r0.playerId$) === ctx_r0.placing.playerId);
    _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵproperty"]("ngStyle", _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵpureFunction1"](24, _c0, ctx_r0.first ? "3px solid var(--ion-color-" + (ctx_r0.campaign == null ? null : ctx_r0.campaign.campaign == null ? null : ctx_r0.campaign.campaign.type) + ")" : ""))("routerLink", _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵpipeBind1"](2, 12, ctx_r0.playerId$) !== ctx_r0.placing.playerId ? _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵpureFunction1"](26, _c1, "/pages/user-profile/" + ctx_r0.placing.playerId + "/" + ctx_r0.placing.nickname) : _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵpureFunction0"](28, _c2));
    _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵadvance"](6);
    _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵproperty"]("value", ctx_r0.placing.position);
    _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵadvance"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵproperty"]("ngIf", _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵpipeBind1"](8, 14, ctx_r0.playerId$) === ctx_r0.placing.playerId);
    _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵadvance"](2);
    _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵproperty"]("ngIf", _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵpipeBind1"](10, 16, ctx_r0.playerId$) !== ctx_r0.placing.playerId);
    _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵadvance"](4);
    _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵtextInterpolate"](ctx_r0.placing.nickname);
    _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵadvance"](3);
    _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵtextInterpolate1"]("", _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵpipeBind2"](18, 21, ctx_r0.unitLabelKey, _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵpureFunction1"](29, _c3, _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵpipeBind2"](17, 18, ctx_r0.getValue(ctx_r0.placing.value), "0.0-1"))), " ");
    _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵadvance"](3);
    _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵproperty"]("name", ctx_r0.getIcon());
  }
}
class PlacingDetailComponent {
  constructor(userService, campaignService) {
    this.userService = userService;
    this.campaignService = campaignService;
    this.playerId$ = this.userService.userProfile$.pipe((0,rxjs_operators__WEBPACK_IMPORTED_MODULE_0__.map)(userProfile => userProfile.playerId));
    this.playerAvatarUrl$ = this.userService.userProfile$.pipe((0,rxjs_operators__WEBPACK_IMPORTED_MODULE_0__.map)(userProfile => userProfile.avatar.avatarSmallUrl));
  }
  getValue(value) {
    if (this.unitLabelKey === 'campaigns.leaderboard.leaderboard_type_unit.km') {
      return value / 1000;
    }
    return value;
  }
  ngOnInit() {}
  getIcon() {
    //get icon based on unitLabelKey
    switch (this.unitLabelKey) {
      case 'campaigns.leaderboard.leaderboard_type_unit.km':
        return 'km';
      case 'campaigns.leaderboard.leaderboard_type_unit.co2':
        return 'co2';
      case 'campaigns.leaderboard.leaderboard_type_unit.GL':
        return this.campaignService.getCampaignTypeIcon(this.campaign?.campaign) || 'ecoLeavesCity';
      default:
        return '';
    }
  }
  static #_ = _staticBlock = () => (this.ɵfac = function PlacingDetailComponent_Factory(__ngFactoryType__) {
    return new (__ngFactoryType__ || PlacingDetailComponent)(_angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵdirectiveInject"](src_app_core_shared_services_user_service__WEBPACK_IMPORTED_MODULE_2__.UserService), _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵdirectiveInject"](src_app_core_shared_services_campaign_service__WEBPACK_IMPORTED_MODULE_3__.CampaignService));
  }, this.ɵcmp = /*@__PURE__*/_angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵdefineComponent"]({
    type: PlacingDetailComponent,
    selectors: [["app-placing-detail"]],
    inputs: {
      placing: "placing",
      unitLabelKey: "unitLabelKey",
      first: "first",
      campaign: "campaign"
    },
    standalone: false,
    decls: 1,
    vars: 1,
    consts: [["alternativeAvatar", ""], ["detail", "false", 3, "my-placing", "ngStyle", "routerLink", 4, "ngIf"], ["detail", "false", 3, "ngStyle", "routerLink"], ["size", "2"], [3, "value"], [4, "ngIf"], ["size", "5", 1, "ion-text-start"], [1, "nickname"], ["size", "3", 1, "ion-text-end"], [1, "points"], [3, "name"], [3, "src"], [4, "ngIf", "ngIfElse"], ["name", "person-circle-outline"]],
    template: function PlacingDetailComponent_Template(rf, ctx) {
      if (rf & 1) {
        _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵtemplate"](0, PlacingDetailComponent_ion_item_0_Template, 20, 31, "ion-item", 1);
      }
      if (rf & 2) {
        _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵproperty"]("ngIf", ctx.placing);
      }
    },
    dependencies: [_angular_router__WEBPACK_IMPORTED_MODULE_4__.RouterLink, _angular_common__WEBPACK_IMPORTED_MODULE_5__.NgIf, _angular_common__WEBPACK_IMPORTED_MODULE_5__.NgStyle, _ionic_angular__WEBPACK_IMPORTED_MODULE_6__.IonAvatar, _ionic_angular__WEBPACK_IMPORTED_MODULE_6__.IonCol, _ionic_angular__WEBPACK_IMPORTED_MODULE_6__.IonGrid, _ionic_angular__WEBPACK_IMPORTED_MODULE_6__.IonIcon, _ionic_angular__WEBPACK_IMPORTED_MODULE_6__.IonItem, _ionic_angular__WEBPACK_IMPORTED_MODULE_6__.IonRow, _ionic_angular__WEBPACK_IMPORTED_MODULE_6__.RouterLinkDelegate, _core_shared_globalization_ordinal_number_ordinal_number_component__WEBPACK_IMPORTED_MODULE_7__.OrdinalNumberComponent, _core_shared_ui_icon_icon_component__WEBPACK_IMPORTED_MODULE_8__.IconComponent, _angular_common__WEBPACK_IMPORTED_MODULE_5__.AsyncPipe, _ngx_translate_core__WEBPACK_IMPORTED_MODULE_9__.TranslatePipe, _core_shared_pipes_localNumber_pipe__WEBPACK_IMPORTED_MODULE_10__.LocalNumberPipe],
    styles: [".my-placing[_ngcontent-%COMP%] {\n  font-weight: bold;\n}\n\n.nickname[_ngcontent-%COMP%] {\n  text-overflow: ellipsis;\n  white-space: nowrap;\n  overflow: hidden;\n}\n\nion-row[_ngcontent-%COMP%] {\n  align-items: center;\n}\n\nion-avatar[_ngcontent-%COMP%] {\n  max-width: 40px;\n  max-height: 40px;\n}\n\nion-icon[_ngcontent-%COMP%] {\n  width: 45px;\n  height: 45px;\n}\n\n.points[_ngcontent-%COMP%] {\n  display: flex;\n  align-items: center;\n  justify-content: flex-end;\n}\n.points[_ngcontent-%COMP%]   app-icon[_ngcontent-%COMP%] {\n  margin: 0px 4px;\n  font-size: 20px;\n}\n/*# sourceMappingURL=data:application/json;charset=utf-8;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbIndlYnBhY2s6Ly8uL3NyYy9hcHAvcGFnZXMvaG9tZS9jYW1wYWlnbi1kZXRhaWxzL2xlYWRlcmJvYXJkL3BsYWNpbmctZGV0YWlsL3BsYWNpbmctZGV0YWlsLmNvbXBvbmVudC5zY3NzIl0sIm5hbWVzIjpbXSwibWFwcGluZ3MiOiJBQUFBO0VBQ0UsaUJBQUE7QUFDRjs7QUFDQTtFQUNFLHVCQUFBO0VBQ0EsbUJBQUE7RUFDQSxnQkFBQTtBQUVGOztBQUFBO0VBQ0UsbUJBQUE7QUFHRjs7QUFEQTtFQUNFLGVBQUE7RUFDQSxnQkFBQTtBQUlGOztBQUZBO0VBQ0UsV0FBQTtFQUNBLFlBQUE7QUFLRjs7QUFIQTtFQUNFLGFBQUE7RUFDQSxtQkFBQTtFQUNBLHlCQUFBO0FBTUY7QUFKRTtFQUNFLGVBQUE7RUFDQSxlQUFBO0FBTUoiLCJzb3VyY2VzQ29udGVudCI6WyIubXktcGxhY2luZyB7XG4gIGZvbnQtd2VpZ2h0OiBib2xkO1xufVxuLm5pY2tuYW1lIHtcbiAgdGV4dC1vdmVyZmxvdzogZWxsaXBzaXM7XG4gIHdoaXRlLXNwYWNlOiBub3dyYXA7XG4gIG92ZXJmbG93OiBoaWRkZW47XG59XG5pb24tcm93IHtcbiAgYWxpZ24taXRlbXM6IGNlbnRlcjtcbn1cbmlvbi1hdmF0YXIge1xuICBtYXgtd2lkdGg6IDQwcHg7XG4gIG1heC1oZWlnaHQ6IDQwcHg7XG59XG5pb24taWNvbiB7XG4gIHdpZHRoOiA0NXB4O1xuICBoZWlnaHQ6IDQ1cHg7XG59XG4ucG9pbnRzIHtcbiAgZGlzcGxheTogZmxleDtcbiAgYWxpZ24taXRlbXM6IGNlbnRlcjtcbiAganVzdGlmeS1jb250ZW50OiBmbGV4LWVuZDtcblxuICBhcHAtaWNvbiB7XG4gICAgbWFyZ2luOiAwcHggNHB4O1xuICAgIGZvbnQtc2l6ZTogMjBweDtcbiAgfVxufVxuIl0sInNvdXJjZVJvb3QiOiIifQ== */"]
  }));
}
_staticBlock();

/***/ }),

/***/ 88305:
/*!***************************************************************************************!*\
  !*** ./src/app/pages/home/campaign-details/leaderboard/leaderboard-routing.module.ts ***!
  \***************************************************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   LeaderboardPageRoutingModule: () => (/* binding */ LeaderboardPageRoutingModule)
/* harmony export */ });
/* harmony import */ var _angular_router__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! @angular/router */ 34487);
/* harmony import */ var _leaderboard_page__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ./leaderboard.page */ 54355);
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @angular/core */ 34205);
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @angular/core */ 12481);
var _staticBlock;




const routes = [{
  path: '',
  component: _leaderboard_page__WEBPACK_IMPORTED_MODULE_1__.LeaderboardPage,
  data: {
    title: 'leaderboard.title'
  }
}];
class LeaderboardPageRoutingModule {
  static #_ = _staticBlock = () => (this.ɵfac = function LeaderboardPageRoutingModule_Factory(__ngFactoryType__) {
    return new (__ngFactoryType__ || LeaderboardPageRoutingModule)();
  }, this.ɵmod = /*@__PURE__*/_angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵdefineNgModule"]({
    type: LeaderboardPageRoutingModule
  }), this.ɵinj = /*@__PURE__*/_angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵdefineInjector"]({
    imports: [_angular_router__WEBPACK_IMPORTED_MODULE_0__.RouterModule.forChild(routes), _angular_router__WEBPACK_IMPORTED_MODULE_0__.RouterModule]
  }));
}
_staticBlock();
(function () {
  (typeof ngJitMode === "undefined" || ngJitMode) && _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵsetNgModuleScope"](LeaderboardPageRoutingModule, {
    imports: [_angular_router__WEBPACK_IMPORTED_MODULE_0__.RouterModule],
    exports: [_angular_router__WEBPACK_IMPORTED_MODULE_0__.RouterModule]
  });
})();

/***/ })

}]);
//# sourceMappingURL=src_app_pages_home_campaign-details_leaderboard_leaderboard_module_ts.js.map