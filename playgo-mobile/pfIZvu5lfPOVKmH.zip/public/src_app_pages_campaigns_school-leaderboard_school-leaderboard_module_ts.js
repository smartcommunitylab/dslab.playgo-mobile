"use strict";
(self["webpackChunkapp"] = self["webpackChunkapp"] || []).push([["src_app_pages_campaigns_school-leaderboard_school-leaderboard_module_ts"],{

/***/ 12915:
/*!*****************************************************************************************!*\
  !*** ./src/app/pages/campaigns/school-leaderboard/school-leaderboard-routing.module.ts ***!
  \*****************************************************************************************/
/***/ (function(__unused_webpack_module, __webpack_exports__, __webpack_require__) {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "SchoolLeaderboardPageRoutingModule": function() { return /* binding */ SchoolLeaderboardPageRoutingModule; }
/* harmony export */ });
/* harmony import */ var _Users_smartcommunitylab_Documents_work_projects_dslab_playgo_mobile_playgo_mobile_node_modules_babel_runtime_helpers_esm_createClass_js__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./node_modules/@babel/runtime/helpers/esm/createClass.js */ 48047);
/* harmony import */ var _Users_smartcommunitylab_Documents_work_projects_dslab_playgo_mobile_playgo_mobile_node_modules_babel_runtime_helpers_esm_classCallCheck_js__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ./node_modules/@babel/runtime/helpers/esm/classCallCheck.js */ 78069);
/* harmony import */ var _angular_router__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! @angular/router */ 52816);
/* harmony import */ var _school_leaderboard_page__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! ./school-leaderboard.page */ 33475);
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @angular/core */ 3184);






var routes = [{
  path: '',
  component: _school_leaderboard_page__WEBPACK_IMPORTED_MODULE_2__.SchoolLeaderboardPage,
  data: {
    title: 'leaderboard.title'
  }
}];
var SchoolLeaderboardPageRoutingModule = /*#__PURE__*/(0,_Users_smartcommunitylab_Documents_work_projects_dslab_playgo_mobile_playgo_mobile_node_modules_babel_runtime_helpers_esm_createClass_js__WEBPACK_IMPORTED_MODULE_0__["default"])(function SchoolLeaderboardPageRoutingModule() {
  (0,_Users_smartcommunitylab_Documents_work_projects_dslab_playgo_mobile_playgo_mobile_node_modules_babel_runtime_helpers_esm_classCallCheck_js__WEBPACK_IMPORTED_MODULE_1__["default"])(this, SchoolLeaderboardPageRoutingModule);
});

SchoolLeaderboardPageRoutingModule.ɵfac = function SchoolLeaderboardPageRoutingModule_Factory(t) {
  return new (t || SchoolLeaderboardPageRoutingModule)();
};

SchoolLeaderboardPageRoutingModule.ɵmod = /*@__PURE__*/_angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵdefineNgModule"]({
  type: SchoolLeaderboardPageRoutingModule
});
SchoolLeaderboardPageRoutingModule.ɵinj = /*@__PURE__*/_angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵdefineInjector"]({
  imports: [[_angular_router__WEBPACK_IMPORTED_MODULE_4__.RouterModule.forChild(routes)], _angular_router__WEBPACK_IMPORTED_MODULE_4__.RouterModule]
});

(function () {
  (typeof ngJitMode === "undefined" || ngJitMode) && _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵsetNgModuleScope"](SchoolLeaderboardPageRoutingModule, {
    imports: [_angular_router__WEBPACK_IMPORTED_MODULE_4__.RouterModule],
    exports: [_angular_router__WEBPACK_IMPORTED_MODULE_4__.RouterModule]
  });
})();

/***/ }),

/***/ 31872:
/*!*********************************************************************************!*\
  !*** ./src/app/pages/campaigns/school-leaderboard/school-leaderboard.module.ts ***!
  \*********************************************************************************/
/***/ (function(__unused_webpack_module, __webpack_exports__, __webpack_require__) {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "SchoolLeaderboardPageModule": function() { return /* binding */ SchoolLeaderboardPageModule; }
/* harmony export */ });
/* harmony import */ var _Users_smartcommunitylab_Documents_work_projects_dslab_playgo_mobile_playgo_mobile_node_modules_babel_runtime_helpers_esm_createClass_js__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./node_modules/@babel/runtime/helpers/esm/createClass.js */ 48047);
/* harmony import */ var _Users_smartcommunitylab_Documents_work_projects_dslab_playgo_mobile_playgo_mobile_node_modules_babel_runtime_helpers_esm_classCallCheck_js__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ./node_modules/@babel/runtime/helpers/esm/classCallCheck.js */ 78069);
/* harmony import */ var _school_leaderboard_routing_module__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! ./school-leaderboard-routing.module */ 12915);
/* harmony import */ var _school_leaderboard_page__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! ./school-leaderboard.page */ 33475);
/* harmony import */ var src_app_core_shared_shared_module__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! src/app/core/shared/shared.module */ 97205);
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! @angular/core */ 3184);






var SchoolLeaderboardPageModule = /*#__PURE__*/(0,_Users_smartcommunitylab_Documents_work_projects_dslab_playgo_mobile_playgo_mobile_node_modules_babel_runtime_helpers_esm_createClass_js__WEBPACK_IMPORTED_MODULE_0__["default"])(function SchoolLeaderboardPageModule() {
  (0,_Users_smartcommunitylab_Documents_work_projects_dslab_playgo_mobile_playgo_mobile_node_modules_babel_runtime_helpers_esm_classCallCheck_js__WEBPACK_IMPORTED_MODULE_1__["default"])(this, SchoolLeaderboardPageModule);
});

SchoolLeaderboardPageModule.ɵfac = function SchoolLeaderboardPageModule_Factory(t) {
  return new (t || SchoolLeaderboardPageModule)();
};

SchoolLeaderboardPageModule.ɵmod = /*@__PURE__*/_angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵdefineNgModule"]({
  type: SchoolLeaderboardPageModule
});
SchoolLeaderboardPageModule.ɵinj = /*@__PURE__*/_angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵdefineInjector"]({
  imports: [[_school_leaderboard_routing_module__WEBPACK_IMPORTED_MODULE_2__.SchoolLeaderboardPageRoutingModule, src_app_core_shared_shared_module__WEBPACK_IMPORTED_MODULE_4__.PlayGoSharedModule]]
});

(function () {
  (typeof ngJitMode === "undefined" || ngJitMode) && _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵsetNgModuleScope"](SchoolLeaderboardPageModule, {
    declarations: [_school_leaderboard_page__WEBPACK_IMPORTED_MODULE_3__.SchoolLeaderboardPage],
    imports: [_school_leaderboard_routing_module__WEBPACK_IMPORTED_MODULE_2__.SchoolLeaderboardPageRoutingModule, src_app_core_shared_shared_module__WEBPACK_IMPORTED_MODULE_4__.PlayGoSharedModule]
  });
})();

/***/ }),

/***/ 33475:
/*!*******************************************************************************!*\
  !*** ./src/app/pages/campaigns/school-leaderboard/school-leaderboard.page.ts ***!
  \*******************************************************************************/
/***/ (function(__unused_webpack_module, __webpack_exports__, __webpack_require__) {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "SchoolLeaderboardPage": function() { return /* binding */ SchoolLeaderboardPage; }
/* harmony export */ });
/* harmony import */ var _Users_smartcommunitylab_Documents_work_projects_dslab_playgo_mobile_playgo_mobile_node_modules_babel_runtime_helpers_esm_classCallCheck_js__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./node_modules/@babel/runtime/helpers/esm/classCallCheck.js */ 78069);
/* harmony import */ var _Users_smartcommunitylab_Documents_work_projects_dslab_playgo_mobile_playgo_mobile_node_modules_babel_runtime_helpers_esm_createClass_js__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ./node_modules/@babel/runtime/helpers/esm/createClass.js */ 48047);
/* harmony import */ var rxjs__WEBPACK_IMPORTED_MODULE_9__ = __webpack_require__(/*! rxjs */ 50635);
/* harmony import */ var rxjs__WEBPACK_IMPORTED_MODULE_10__ = __webpack_require__(/*! rxjs */ 98977);
/* harmony import */ var rxjs__WEBPACK_IMPORTED_MODULE_11__ = __webpack_require__(/*! rxjs */ 89196);
/* harmony import */ var rxjs__WEBPACK_IMPORTED_MODULE_12__ = __webpack_require__(/*! rxjs */ 32673);
/* harmony import */ var src_app_core_shared_utils__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! src/app/core/shared/utils */ 68647);
/* harmony import */ var src_environments_environment__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! src/environments/environment */ 92340);
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(/*! @angular/core */ 3184);
/* harmony import */ var _angular_common_http__WEBPACK_IMPORTED_MODULE_13__ = __webpack_require__(/*! @angular/common/http */ 28784);
/* harmony import */ var _angular_router__WEBPACK_IMPORTED_MODULE_14__ = __webpack_require__(/*! @angular/router */ 52816);
/* harmony import */ var src_app_core_shared_services_error_service__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! src/app/core/shared/services/error.service */ 96204);
/* harmony import */ var _ionic_angular__WEBPACK_IMPORTED_MODULE_15__ = __webpack_require__(/*! @ionic/angular */ 93819);
/* harmony import */ var _core_shared_layout_header_header_directive__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! ../../../core/shared/layout/header/header.directive */ 34161);
/* harmony import */ var _angular_common__WEBPACK_IMPORTED_MODULE_16__ = __webpack_require__(/*! @angular/common */ 36362);
/* harmony import */ var _core_shared_globalization_ordinal_number_ordinal_number_component__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! ../../../core/shared/globalization/ordinal-number/ordinal-number.component */ 56032);
/* harmony import */ var _ngx_translate_core__WEBPACK_IMPORTED_MODULE_17__ = __webpack_require__(/*! @ngx-translate/core */ 87514);
/* harmony import */ var _core_shared_pipes_localNumber_pipe__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(/*! ../../../core/shared/pipes/localNumber.pipe */ 89713);
















var _c0 = function _c0(a0) {
  return {
    value: a0
  };
};

function SchoolLeaderboardPage_ng_container_2_ion_item_1_Template(rf, ctx) {
  if (rf & 1) {
    _angular_core__WEBPACK_IMPORTED_MODULE_8__["ɵɵelementStart"](0, "ion-item")(1, "ion-label");
    _angular_core__WEBPACK_IMPORTED_MODULE_8__["ɵɵelement"](2, "app-ordinal-number", 3);
    _angular_core__WEBPACK_IMPORTED_MODULE_8__["ɵɵelementEnd"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_8__["ɵɵtext"](3);
    _angular_core__WEBPACK_IMPORTED_MODULE_8__["ɵɵpipe"](4, "translate");
    _angular_core__WEBPACK_IMPORTED_MODULE_8__["ɵɵpipe"](5, "localNumber");
    _angular_core__WEBPACK_IMPORTED_MODULE_8__["ɵɵelementEnd"]();
  }

  if (rf & 2) {
    var placing_r3 = ctx.$implicit;
    _angular_core__WEBPACK_IMPORTED_MODULE_8__["ɵɵadvance"](2);
    _angular_core__WEBPACK_IMPORTED_MODULE_8__["ɵɵproperty"]("value", placing_r3.position);
    _angular_core__WEBPACK_IMPORTED_MODULE_8__["ɵɵadvance"](1);
    _angular_core__WEBPACK_IMPORTED_MODULE_8__["ɵɵtextInterpolate4"](" ", placing_r3.customData.institute, " | ", placing_r3.customData.school, " | ", placing_r3.customData.cls, " | ", _angular_core__WEBPACK_IMPORTED_MODULE_8__["ɵɵpipeBind2"](4, 5, "campaigns.leaderboard.leaderboard_type_unit.GL", _angular_core__WEBPACK_IMPORTED_MODULE_8__["ɵɵpureFunction1"](11, _c0, _angular_core__WEBPACK_IMPORTED_MODULE_8__["ɵɵpipeBind2"](5, 8, placing_r3.score, ".0"))), " ");
  }
}

function SchoolLeaderboardPage_ng_container_2_Template(rf, ctx) {
  if (rf & 1) {
    _angular_core__WEBPACK_IMPORTED_MODULE_8__["ɵɵelementContainerStart"](0);
    _angular_core__WEBPACK_IMPORTED_MODULE_8__["ɵɵtemplate"](1, SchoolLeaderboardPage_ng_container_2_ion_item_1_Template, 6, 13, "ion-item", 2);
    _angular_core__WEBPACK_IMPORTED_MODULE_8__["ɵɵelementContainerEnd"]();
  }

  if (rf & 2) {
    var leaderboard_r1 = ctx.ngIf;
    var ctx_r0 = _angular_core__WEBPACK_IMPORTED_MODULE_8__["ɵɵnextContext"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_8__["ɵɵadvance"](1);
    _angular_core__WEBPACK_IMPORTED_MODULE_8__["ɵɵproperty"]("ngForOf", leaderboard_r1)("ngForTrackBy", ctx_r0.placingTracking);
  }
}

var SchoolLeaderboardPage = /*#__PURE__*/function () {
  function SchoolLeaderboardPage(http, route, errorService) {
    var _this = this;

    (0,_Users_smartcommunitylab_Documents_work_projects_dslab_playgo_mobile_playgo_mobile_node_modules_babel_runtime_helpers_esm_classCallCheck_js__WEBPACK_IMPORTED_MODULE_0__["default"])(this, SchoolLeaderboardPage);

    this.http = http;
    this.route = route;
    this.errorService = errorService;
    this.campaignId$ = this.route.params.pipe((0,rxjs__WEBPACK_IMPORTED_MODULE_9__.map)(function (params) {
      return params.id;
    }), (0,rxjs__WEBPACK_IMPORTED_MODULE_10__.distinctUntilChanged)(), (0,rxjs__WEBPACK_IMPORTED_MODULE_11__.shareReplay)(1));
    this.leaderboard$ = this.campaignId$.pipe((0,rxjs__WEBPACK_IMPORTED_MODULE_12__.switchMap)(function (campaignId) {
      return _this.getLeaderboard(campaignId).pipe(_this.errorService.getErrorHandler());
    }), (0,rxjs__WEBPACK_IMPORTED_MODULE_11__.shareReplay)(1));
    this.placingTracking = (0,src_app_core_shared_utils__WEBPACK_IMPORTED_MODULE_2__.trackByProperty)('id');
  }

  (0,_Users_smartcommunitylab_Documents_work_projects_dslab_playgo_mobile_playgo_mobile_node_modules_babel_runtime_helpers_esm_createClass_js__WEBPACK_IMPORTED_MODULE_1__["default"])(SchoolLeaderboardPage, [{
    key: "ngOnInit",
    value: function ngOnInit() {}
  }, {
    key: "getLeaderboard",
    value: function getLeaderboard(campaignId) {
      return this.http.get("".concat(src_environments_environment__WEBPACK_IMPORTED_MODULE_3__.environment.serverUrl.hscApi, "/").concat(campaignId, "/board"));
    }
  }]);

  return SchoolLeaderboardPage;
}();

SchoolLeaderboardPage.ɵfac = function SchoolLeaderboardPage_Factory(t) {
  return new (t || SchoolLeaderboardPage)(_angular_core__WEBPACK_IMPORTED_MODULE_8__["ɵɵdirectiveInject"](_angular_common_http__WEBPACK_IMPORTED_MODULE_13__.HttpClient), _angular_core__WEBPACK_IMPORTED_MODULE_8__["ɵɵdirectiveInject"](_angular_router__WEBPACK_IMPORTED_MODULE_14__.ActivatedRoute), _angular_core__WEBPACK_IMPORTED_MODULE_8__["ɵɵdirectiveInject"](src_app_core_shared_services_error_service__WEBPACK_IMPORTED_MODULE_4__.ErrorService));
};

SchoolLeaderboardPage.ɵcmp = /*@__PURE__*/_angular_core__WEBPACK_IMPORTED_MODULE_8__["ɵɵdefineComponent"]({
  type: SchoolLeaderboardPage,
  selectors: [["app-school-leaderboard"]],
  decls: 4,
  vars: 3,
  consts: [["appHeader", ""], [4, "ngIf"], [4, "ngFor", "ngForOf", "ngForTrackBy"], [3, "value"]],
  template: function SchoolLeaderboardPage_Template(rf, ctx) {
    if (rf & 1) {
      _angular_core__WEBPACK_IMPORTED_MODULE_8__["ɵɵelement"](0, "ion-header", 0);
      _angular_core__WEBPACK_IMPORTED_MODULE_8__["ɵɵelementStart"](1, "ion-content");
      _angular_core__WEBPACK_IMPORTED_MODULE_8__["ɵɵtemplate"](2, SchoolLeaderboardPage_ng_container_2_Template, 2, 2, "ng-container", 1);
      _angular_core__WEBPACK_IMPORTED_MODULE_8__["ɵɵpipe"](3, "async");
      _angular_core__WEBPACK_IMPORTED_MODULE_8__["ɵɵelementEnd"]();
    }

    if (rf & 2) {
      _angular_core__WEBPACK_IMPORTED_MODULE_8__["ɵɵadvance"](2);
      _angular_core__WEBPACK_IMPORTED_MODULE_8__["ɵɵproperty"]("ngIf", _angular_core__WEBPACK_IMPORTED_MODULE_8__["ɵɵpipeBind1"](3, 1, ctx.leaderboard$));
    }
  },
  directives: [_ionic_angular__WEBPACK_IMPORTED_MODULE_15__.IonHeader, _core_shared_layout_header_header_directive__WEBPACK_IMPORTED_MODULE_5__.HeaderDirective, _ionic_angular__WEBPACK_IMPORTED_MODULE_15__.IonContent, _angular_common__WEBPACK_IMPORTED_MODULE_16__.NgIf, _angular_common__WEBPACK_IMPORTED_MODULE_16__.NgForOf, _ionic_angular__WEBPACK_IMPORTED_MODULE_15__.IonItem, _ionic_angular__WEBPACK_IMPORTED_MODULE_15__.IonLabel, _core_shared_globalization_ordinal_number_ordinal_number_component__WEBPACK_IMPORTED_MODULE_6__.OrdinalNumberComponent],
  pipes: [_angular_common__WEBPACK_IMPORTED_MODULE_16__.AsyncPipe, _ngx_translate_core__WEBPACK_IMPORTED_MODULE_17__.TranslatePipe, _core_shared_pipes_localNumber_pipe__WEBPACK_IMPORTED_MODULE_7__.LocalNumberPipe],
  styles: ["\n/*# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbXSwibmFtZXMiOltdLCJtYXBwaW5ncyI6IiIsImZpbGUiOiJzY2hvb2wtbGVhZGVyYm9hcmQucGFnZS5zY3NzIn0= */"]
});

/***/ })

}]);
//# sourceMappingURL=src_app_pages_campaigns_school-leaderboard_school-leaderboard_module_ts.js.map