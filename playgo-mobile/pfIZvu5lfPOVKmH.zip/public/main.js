(self["webpackChunkapp"] = self["webpackChunkapp"] || []).push([["main"],{

/***/ 90158:
/*!***************************************!*\
  !*** ./src/app/app-routing.module.ts ***!
  \***************************************/
/***/ (function(__unused_webpack_module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "AppRoutingModule": function() { return /* binding */ AppRoutingModule; }
/* harmony export */ });
/* harmony import */ var _Users_smartcommunitylab_Documents_work_projects_dslab_playgo_mobile_playgo_mobile_node_modules_babel_runtime_helpers_esm_createClass_js__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./node_modules/@babel/runtime/helpers/esm/createClass.js */ 48047);
/* harmony import */ var _Users_smartcommunitylab_Documents_work_projects_dslab_playgo_mobile_playgo_mobile_node_modules_babel_runtime_helpers_esm_classCallCheck_js__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ./node_modules/@babel/runtime/helpers/esm/classCallCheck.js */ 78069);
/* harmony import */ var _angular_router__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! @angular/router */ 52816);
/* harmony import */ var _core_auth_auth_guard_service__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! ./core/auth/auth-guard.service */ 31265);
/* harmony import */ var _core_shared_services_offline_guard__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! ./core/shared/services/offline.guard */ 69509);
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! @angular/core */ 3184);







var routes = [{
  path: '',
  redirectTo: 'pages',
  pathMatch: 'full'
}, {
  path: 'pages',
  canActivate: [_core_auth_auth_guard_service__WEBPACK_IMPORTED_MODULE_2__.AuthGuardService, _core_shared_services_offline_guard__WEBPACK_IMPORTED_MODULE_3__.OfflineGuard],
  canActivateChild: [_core_shared_services_offline_guard__WEBPACK_IMPORTED_MODULE_3__.OfflineGuard],
  loadChildren: function loadChildren() {
    return __webpack_require__.e(/*! import() */ "src_app_pages_pages-routing_module_ts").then(__webpack_require__.bind(__webpack_require__, /*! ./pages/pages-routing.module */ 39730)).then(function (m) {
      return m.PagesRoutingModule;
    });
  }
}, {
  path: 'login',
  loadChildren: function loadChildren() {
    return __webpack_require__.e(/*! import() */ "src_app_auth-pages_login_login_module_ts").then(__webpack_require__.bind(__webpack_require__, /*! ./auth-pages/login/login.module */ 51633)).then(function (m) {
      return m.LoginPageModule;
    });
  }
}, {
  path: 'auth/callback',
  loadChildren: function loadChildren() {
    return __webpack_require__.e(/*! import() */ "src_app_auth-pages_auth-callback_auth-callback_module_ts").then(__webpack_require__.bind(__webpack_require__, /*! ./auth-pages/auth-callback/auth-callback.module */ 49099)).then(function (m) {
      return m.AuthCallbackPageModule;
    });
  }
}, {
  path: 'auth/endsession',
  loadChildren: function loadChildren() {
    return __webpack_require__.e(/*! import() */ "src_app_auth-pages_end-session_end-session_module_ts").then(__webpack_require__.bind(__webpack_require__, /*! ./auth-pages/end-session/end-session.module */ 49086)).then(function (m) {
      return m.EndSessionPageModule;
    });
  }
}];
var AppRoutingModule = /*#__PURE__*/(0,_Users_smartcommunitylab_Documents_work_projects_dslab_playgo_mobile_playgo_mobile_node_modules_babel_runtime_helpers_esm_createClass_js__WEBPACK_IMPORTED_MODULE_0__["default"])(function AppRoutingModule() {
  (0,_Users_smartcommunitylab_Documents_work_projects_dslab_playgo_mobile_playgo_mobile_node_modules_babel_runtime_helpers_esm_classCallCheck_js__WEBPACK_IMPORTED_MODULE_1__["default"])(this, AppRoutingModule);
});

AppRoutingModule.ɵfac = function AppRoutingModule_Factory(t) {
  return new (t || AppRoutingModule)();
};

AppRoutingModule.ɵmod = /*@__PURE__*/_angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵdefineNgModule"]({
  type: AppRoutingModule
});
AppRoutingModule.ɵinj = /*@__PURE__*/_angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵdefineInjector"]({
  imports: [[_angular_router__WEBPACK_IMPORTED_MODULE_5__.RouterModule.forRoot(routes, {
    preloadingStrategy: _angular_router__WEBPACK_IMPORTED_MODULE_5__.PreloadAllModules
  })], _angular_router__WEBPACK_IMPORTED_MODULE_5__.RouterModule]
});

(function () {
  (typeof ngJitMode === "undefined" || ngJitMode) && _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵsetNgModuleScope"](AppRoutingModule, {
    imports: [_angular_router__WEBPACK_IMPORTED_MODULE_5__.RouterModule],
    exports: [_angular_router__WEBPACK_IMPORTED_MODULE_5__.RouterModule]
  });
})();

/***/ }),

/***/ 55041:
/*!**********************************!*\
  !*** ./src/app/app.component.ts ***!
  \**********************************/
/***/ (function(__unused_webpack_module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "AppComponent": function() { return /* binding */ AppComponent; }
/* harmony export */ });
/* harmony import */ var _Users_smartcommunitylab_Documents_work_projects_dslab_playgo_mobile_playgo_mobile_node_modules_babel_runtime_helpers_esm_classCallCheck_js__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./node_modules/@babel/runtime/helpers/esm/classCallCheck.js */ 78069);
/* harmony import */ var _Users_smartcommunitylab_Documents_work_projects_dslab_playgo_mobile_playgo_mobile_node_modules_babel_runtime_helpers_esm_createClass_js__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ./node_modules/@babel/runtime/helpers/esm/createClass.js */ 48047);
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_10__ = __webpack_require__(/*! tslib */ 34929);
/* harmony import */ var _capacitor_splash_screen__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @capacitor/splash-screen */ 82239);
/* harmony import */ var src_environments_environment__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! src/environments/environment */ 92340);
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_11__ = __webpack_require__(/*! @angular/core */ 3184);
/* harmony import */ var _ngx_translate_core__WEBPACK_IMPORTED_MODULE_12__ = __webpack_require__(/*! @ngx-translate/core */ 87514);
/* harmony import */ var _ionic_angular__WEBPACK_IMPORTED_MODULE_13__ = __webpack_require__(/*! @ionic/angular */ 93819);
/* harmony import */ var _core_shared_tracking_background_tracking_service__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! ./core/shared/tracking/background-tracking.service */ 29872);
/* harmony import */ var _core_shared_services_app_status_service__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! ./core/shared/services/app-status.service */ 93656);
/* harmony import */ var _core_shared_ui_icon_icon_service__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! ./core/shared/ui/icon/icon.service */ 34610);
/* harmony import */ var _core_auth_auth_service__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(/*! ./core/auth/auth.service */ 88951);
/* harmony import */ var _core_shared_services_notifications_notifications_service__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(/*! ./core/shared/services/notifications/notifications.service */ 30299);
/* harmony import */ var _core_shared_services_badge_service__WEBPACK_IMPORTED_MODULE_9__ = __webpack_require__(/*! ./core/shared/services/badge.service */ 70891);



function _regeneratorRuntime() { "use strict"; /*! regenerator-runtime -- Copyright (c) 2014-present, Facebook, Inc. -- license (MIT): https://github.com/facebook/regenerator/blob/main/LICENSE */ _regeneratorRuntime = function _regeneratorRuntime() { return exports; }; var exports = {}, Op = Object.prototype, hasOwn = Op.hasOwnProperty, $Symbol = "function" == typeof Symbol ? Symbol : {}, iteratorSymbol = $Symbol.iterator || "@@iterator", asyncIteratorSymbol = $Symbol.asyncIterator || "@@asyncIterator", toStringTagSymbol = $Symbol.toStringTag || "@@toStringTag"; function define(obj, key, value) { return Object.defineProperty(obj, key, { value: value, enumerable: !0, configurable: !0, writable: !0 }), obj[key]; } try { define({}, ""); } catch (err) { define = function define(obj, key, value) { return obj[key] = value; }; } function wrap(innerFn, outerFn, self, tryLocsList) { var protoGenerator = outerFn && outerFn.prototype instanceof Generator ? outerFn : Generator, generator = Object.create(protoGenerator.prototype), context = new Context(tryLocsList || []); return generator._invoke = function (innerFn, self, context) { var state = "suspendedStart"; return function (method, arg) { if ("executing" === state) throw new Error("Generator is already running"); if ("completed" === state) { if ("throw" === method) throw arg; return doneResult(); } for (context.method = method, context.arg = arg;;) { var delegate = context.delegate; if (delegate) { var delegateResult = maybeInvokeDelegate(delegate, context); if (delegateResult) { if (delegateResult === ContinueSentinel) continue; return delegateResult; } } if ("next" === context.method) context.sent = context._sent = context.arg;else if ("throw" === context.method) { if ("suspendedStart" === state) throw state = "completed", context.arg; context.dispatchException(context.arg); } else "return" === context.method && context.abrupt("return", context.arg); state = "executing"; var record = tryCatch(innerFn, self, context); if ("normal" === record.type) { if (state = context.done ? "completed" : "suspendedYield", record.arg === ContinueSentinel) continue; return { value: record.arg, done: context.done }; } "throw" === record.type && (state = "completed", context.method = "throw", context.arg = record.arg); } }; }(innerFn, self, context), generator; } function tryCatch(fn, obj, arg) { try { return { type: "normal", arg: fn.call(obj, arg) }; } catch (err) { return { type: "throw", arg: err }; } } exports.wrap = wrap; var ContinueSentinel = {}; function Generator() {} function GeneratorFunction() {} function GeneratorFunctionPrototype() {} var IteratorPrototype = {}; define(IteratorPrototype, iteratorSymbol, function () { return this; }); var getProto = Object.getPrototypeOf, NativeIteratorPrototype = getProto && getProto(getProto(values([]))); NativeIteratorPrototype && NativeIteratorPrototype !== Op && hasOwn.call(NativeIteratorPrototype, iteratorSymbol) && (IteratorPrototype = NativeIteratorPrototype); var Gp = GeneratorFunctionPrototype.prototype = Generator.prototype = Object.create(IteratorPrototype); function defineIteratorMethods(prototype) { ["next", "throw", "return"].forEach(function (method) { define(prototype, method, function (arg) { return this._invoke(method, arg); }); }); } function AsyncIterator(generator, PromiseImpl) { function invoke(method, arg, resolve, reject) { var record = tryCatch(generator[method], generator, arg); if ("throw" !== record.type) { var result = record.arg, value = result.value; return value && "object" == typeof value && hasOwn.call(value, "__await") ? PromiseImpl.resolve(value.__await).then(function (value) { invoke("next", value, resolve, reject); }, function (err) { invoke("throw", err, resolve, reject); }) : PromiseImpl.resolve(value).then(function (unwrapped) { result.value = unwrapped, resolve(result); }, function (error) { return invoke("throw", error, resolve, reject); }); } reject(record.arg); } var previousPromise; this._invoke = function (method, arg) { function callInvokeWithMethodAndArg() { return new PromiseImpl(function (resolve, reject) { invoke(method, arg, resolve, reject); }); } return previousPromise = previousPromise ? previousPromise.then(callInvokeWithMethodAndArg, callInvokeWithMethodAndArg) : callInvokeWithMethodAndArg(); }; } function maybeInvokeDelegate(delegate, context) { var method = delegate.iterator[context.method]; if (undefined === method) { if (context.delegate = null, "throw" === context.method) { if (delegate.iterator.return && (context.method = "return", context.arg = undefined, maybeInvokeDelegate(delegate, context), "throw" === context.method)) return ContinueSentinel; context.method = "throw", context.arg = new TypeError("The iterator does not provide a 'throw' method"); } return ContinueSentinel; } var record = tryCatch(method, delegate.iterator, context.arg); if ("throw" === record.type) return context.method = "throw", context.arg = record.arg, context.delegate = null, ContinueSentinel; var info = record.arg; return info ? info.done ? (context[delegate.resultName] = info.value, context.next = delegate.nextLoc, "return" !== context.method && (context.method = "next", context.arg = undefined), context.delegate = null, ContinueSentinel) : info : (context.method = "throw", context.arg = new TypeError("iterator result is not an object"), context.delegate = null, ContinueSentinel); } function pushTryEntry(locs) { var entry = { tryLoc: locs[0] }; 1 in locs && (entry.catchLoc = locs[1]), 2 in locs && (entry.finallyLoc = locs[2], entry.afterLoc = locs[3]), this.tryEntries.push(entry); } function resetTryEntry(entry) { var record = entry.completion || {}; record.type = "normal", delete record.arg, entry.completion = record; } function Context(tryLocsList) { this.tryEntries = [{ tryLoc: "root" }], tryLocsList.forEach(pushTryEntry, this), this.reset(!0); } function values(iterable) { if (iterable) { var iteratorMethod = iterable[iteratorSymbol]; if (iteratorMethod) return iteratorMethod.call(iterable); if ("function" == typeof iterable.next) return iterable; if (!isNaN(iterable.length)) { var i = -1, next = function next() { for (; ++i < iterable.length;) { if (hasOwn.call(iterable, i)) return next.value = iterable[i], next.done = !1, next; } return next.value = undefined, next.done = !0, next; }; return next.next = next; } } return { next: doneResult }; } function doneResult() { return { value: undefined, done: !0 }; } return GeneratorFunction.prototype = GeneratorFunctionPrototype, define(Gp, "constructor", GeneratorFunctionPrototype), define(GeneratorFunctionPrototype, "constructor", GeneratorFunction), GeneratorFunction.displayName = define(GeneratorFunctionPrototype, toStringTagSymbol, "GeneratorFunction"), exports.isGeneratorFunction = function (genFun) { var ctor = "function" == typeof genFun && genFun.constructor; return !!ctor && (ctor === GeneratorFunction || "GeneratorFunction" === (ctor.displayName || ctor.name)); }, exports.mark = function (genFun) { return Object.setPrototypeOf ? Object.setPrototypeOf(genFun, GeneratorFunctionPrototype) : (genFun.__proto__ = GeneratorFunctionPrototype, define(genFun, toStringTagSymbol, "GeneratorFunction")), genFun.prototype = Object.create(Gp), genFun; }, exports.awrap = function (arg) { return { __await: arg }; }, defineIteratorMethods(AsyncIterator.prototype), define(AsyncIterator.prototype, asyncIteratorSymbol, function () { return this; }), exports.AsyncIterator = AsyncIterator, exports.async = function (innerFn, outerFn, self, tryLocsList, PromiseImpl) { void 0 === PromiseImpl && (PromiseImpl = Promise); var iter = new AsyncIterator(wrap(innerFn, outerFn, self, tryLocsList), PromiseImpl); return exports.isGeneratorFunction(outerFn) ? iter : iter.next().then(function (result) { return result.done ? result.value : iter.next(); }); }, defineIteratorMethods(Gp), define(Gp, toStringTagSymbol, "Generator"), define(Gp, iteratorSymbol, function () { return this; }), define(Gp, "toString", function () { return "[object Generator]"; }), exports.keys = function (object) { var keys = []; for (var key in object) { keys.push(key); } return keys.reverse(), function next() { for (; keys.length;) { var key = keys.pop(); if (key in object) return next.value = key, next.done = !1, next; } return next.done = !0, next; }; }, exports.values = values, Context.prototype = { constructor: Context, reset: function reset(skipTempReset) { if (this.prev = 0, this.next = 0, this.sent = this._sent = undefined, this.done = !1, this.delegate = null, this.method = "next", this.arg = undefined, this.tryEntries.forEach(resetTryEntry), !skipTempReset) for (var name in this) { "t" === name.charAt(0) && hasOwn.call(this, name) && !isNaN(+name.slice(1)) && (this[name] = undefined); } }, stop: function stop() { this.done = !0; var rootRecord = this.tryEntries[0].completion; if ("throw" === rootRecord.type) throw rootRecord.arg; return this.rval; }, dispatchException: function dispatchException(exception) { if (this.done) throw exception; var context = this; function handle(loc, caught) { return record.type = "throw", record.arg = exception, context.next = loc, caught && (context.method = "next", context.arg = undefined), !!caught; } for (var i = this.tryEntries.length - 1; i >= 0; --i) { var entry = this.tryEntries[i], record = entry.completion; if ("root" === entry.tryLoc) return handle("end"); if (entry.tryLoc <= this.prev) { var hasCatch = hasOwn.call(entry, "catchLoc"), hasFinally = hasOwn.call(entry, "finallyLoc"); if (hasCatch && hasFinally) { if (this.prev < entry.catchLoc) return handle(entry.catchLoc, !0); if (this.prev < entry.finallyLoc) return handle(entry.finallyLoc); } else if (hasCatch) { if (this.prev < entry.catchLoc) return handle(entry.catchLoc, !0); } else { if (!hasFinally) throw new Error("try statement without catch or finally"); if (this.prev < entry.finallyLoc) return handle(entry.finallyLoc); } } } }, abrupt: function abrupt(type, arg) { for (var i = this.tryEntries.length - 1; i >= 0; --i) { var entry = this.tryEntries[i]; if (entry.tryLoc <= this.prev && hasOwn.call(entry, "finallyLoc") && this.prev < entry.finallyLoc) { var finallyEntry = entry; break; } } finallyEntry && ("break" === type || "continue" === type) && finallyEntry.tryLoc <= arg && arg <= finallyEntry.finallyLoc && (finallyEntry = null); var record = finallyEntry ? finallyEntry.completion : {}; return record.type = type, record.arg = arg, finallyEntry ? (this.method = "next", this.next = finallyEntry.finallyLoc, ContinueSentinel) : this.complete(record); }, complete: function complete(record, afterLoc) { if ("throw" === record.type) throw record.arg; return "break" === record.type || "continue" === record.type ? this.next = record.arg : "return" === record.type ? (this.rval = this.arg = record.arg, this.method = "return", this.next = "end") : "normal" === record.type && afterLoc && (this.next = afterLoc), ContinueSentinel; }, finish: function finish(finallyLoc) { for (var i = this.tryEntries.length - 1; i >= 0; --i) { var entry = this.tryEntries[i]; if (entry.finallyLoc === finallyLoc) return this.complete(entry.completion, entry.afterLoc), resetTryEntry(entry), ContinueSentinel; } }, catch: function _catch(tryLoc) { for (var i = this.tryEntries.length - 1; i >= 0; --i) { var entry = this.tryEntries[i]; if (entry.tryLoc === tryLoc) { var record = entry.completion; if ("throw" === record.type) { var thrown = record.arg; resetTryEntry(entry); } return thrown; } } throw new Error("illegal catch attempt"); }, delegateYield: function delegateYield(iterable, resultName, nextLoc) { return this.delegate = { iterator: values(iterable), resultName: resultName, nextLoc: nextLoc }, "next" === this.method && (this.arg = undefined), ContinueSentinel; } }, exports; }













var AppComponent = /*#__PURE__*/function () {
  function AppComponent(translate, platform, backgroundTrackingService, appStatusService, iconService, authService, notificationService, badgeService, codePushPlugin) {
    (0,_Users_smartcommunitylab_Documents_work_projects_dslab_playgo_mobile_playgo_mobile_node_modules_babel_runtime_helpers_esm_classCallCheck_js__WEBPACK_IMPORTED_MODULE_0__["default"])(this, AppComponent);

    this.translate = translate;
    this.platform = platform;
    this.backgroundTrackingService = backgroundTrackingService;
    this.appStatusService = appStatusService;
    this.iconService = iconService;
    this.authService = authService;
    this.notificationService = notificationService;
    this.badgeService = badgeService;
    this.codePushPlugin = codePushPlugin;
    this.initializeApp();
  }

  (0,_Users_smartcommunitylab_Documents_work_projects_dslab_playgo_mobile_playgo_mobile_node_modules_babel_runtime_helpers_esm_createClass_js__WEBPACK_IMPORTED_MODULE_1__["default"])(AppComponent, [{
    key: "initializeApp",
    value: function initializeApp() {
      return (0,tslib__WEBPACK_IMPORTED_MODULE_10__.__awaiter)(this, void 0, void 0, /*#__PURE__*/_regeneratorRuntime().mark(function _callee() {
        return _regeneratorRuntime().wrap(function _callee$(_context) {
          while (1) {
            switch (_context.prev = _context.next) {
              case 0:
                this.translate.setDefaultLang('it');
                this.loadCustomIcons();
                this.pushInit();
                this.badgeService.init();
                _context.next = 6;
                return this.platform.ready();

              case 6:
                _context.next = 8;
                return Promise.all([this.authService.init(), this.codePushSync(), this.backgroundTrackingService.start()]);

              case 8:
                _capacitor_splash_screen__WEBPACK_IMPORTED_MODULE_2__.SplashScreen.hide();

              case 9:
              case "end":
                return _context.stop();
            }
          }
        }, _callee, this);
      }));
    }
  }, {
    key: "pushInit",
    value: function pushInit() {
      var _this = this;

      this.authService.isReadyForApi$.subscribe(function () {
        console.log('Initializing HomePage'); //init push notification setup after login

        try {
          _this.notificationService.initPush();
        } catch (error) {
          console.error('initPush error:', error);
        }
      });
    }
  }, {
    key: "codePushSync",
    value: function codePushSync() {
      return (0,tslib__WEBPACK_IMPORTED_MODULE_10__.__awaiter)(this, void 0, void 0, /*#__PURE__*/_regeneratorRuntime().mark(function _callee2() {
        var syncStatus;
        return _regeneratorRuntime().wrap(function _callee2$(_context2) {
          while (1) {
            switch (_context2.prev = _context2.next) {
              case 0:
                _context2.prev = 0;
                syncStatus = 'sync_disabled';

                if (!src_environments_environment__WEBPACK_IMPORTED_MODULE_3__.environment.useCodePush) {
                  _context2.next = 6;
                  break;
                }

                _context2.next = 5;
                return this.codePushPlugin.sync({});

              case 5:
                syncStatus = _context2.sent;

              case 6:
                console.log('codePushSync syncStatus:', syncStatus);
                _context2.next = 12;
                break;

              case 9:
                _context2.prev = 9;
                _context2.t0 = _context2["catch"](0);
                console.error('codePushSync error:', _context2.t0);

              case 12:
                _context2.prev = 12;
                this.appStatusService.codePushSyncFinished();
                return _context2.finish(12);

              case 15:
              case "end":
                return _context2.stop();
            }
          }
        }, _callee2, this, [[0, 9, 12, 15]]);
      }));
    }
  }, {
    key: "loadCustomIcons",
    value: function loadCustomIcons() {
      var icons = {
        custom_carpooling: '../assets/icon/carpooling.svg',
        cup: '../assets/icon/cup.svg',
        passenger: '../assets/icon/passenger.svg',
        driver: '../assets/icon/driver.svg',
        co2: '../assets/icon/co2.svg',
        flower: '../assets/icon/flower.svg',
        shield: '../assets/icon/shield.svg',
        offline: '../assets/icon/offline.svg',
        badges: '../assets/icon/badges.svg',
        blockUserColor: '../assets/icon/blockUserColor.svg',
        blacklist: '../assets/icon/blacklist.svg',
        invitation: '../assets/icon/invitation.svg',
        leaderboard: '../assets/icon/leaderboard.svg',
        stat: '../assets/icon/stat.svg',
        leave: '../assets/icon/leave.svg',
        groupCompetitivePerformance: '../assets/images/challenges/groupCompetitivePerformance.svg',
        groupCompetitiveTime: '../assets/images/challenges/groupCompetitiveTime.svg',
        groupCooperative: '../assets/images/challenges/groupCooperative.svg',
        default: '../assets/images/challenges/default.svg'
      };
      this.iconService.registerSvgIcons(icons);
    }
  }, {
    key: "ngAfterContentInit",
    value: function ngAfterContentInit() {}
  }]);

  return AppComponent;
}();

AppComponent.ɵfac = function AppComponent_Factory(t) {
  return new (t || AppComponent)(_angular_core__WEBPACK_IMPORTED_MODULE_11__["ɵɵdirectiveInject"](_ngx_translate_core__WEBPACK_IMPORTED_MODULE_12__.TranslateService), _angular_core__WEBPACK_IMPORTED_MODULE_11__["ɵɵdirectiveInject"](_ionic_angular__WEBPACK_IMPORTED_MODULE_13__.Platform), _angular_core__WEBPACK_IMPORTED_MODULE_11__["ɵɵdirectiveInject"](_core_shared_tracking_background_tracking_service__WEBPACK_IMPORTED_MODULE_4__.BackgroundTrackingService), _angular_core__WEBPACK_IMPORTED_MODULE_11__["ɵɵdirectiveInject"](_core_shared_services_app_status_service__WEBPACK_IMPORTED_MODULE_5__.AppStatusService), _angular_core__WEBPACK_IMPORTED_MODULE_11__["ɵɵdirectiveInject"](_core_shared_ui_icon_icon_service__WEBPACK_IMPORTED_MODULE_6__.IconService), _angular_core__WEBPACK_IMPORTED_MODULE_11__["ɵɵdirectiveInject"](_core_auth_auth_service__WEBPACK_IMPORTED_MODULE_7__.AuthService), _angular_core__WEBPACK_IMPORTED_MODULE_11__["ɵɵdirectiveInject"](_core_shared_services_notifications_notifications_service__WEBPACK_IMPORTED_MODULE_8__.NotificationService), _angular_core__WEBPACK_IMPORTED_MODULE_11__["ɵɵdirectiveInject"](_core_shared_services_badge_service__WEBPACK_IMPORTED_MODULE_9__.BadgeService), _angular_core__WEBPACK_IMPORTED_MODULE_11__["ɵɵdirectiveInject"]('CodePushPlugin'));
};

AppComponent.ɵcmp = /*@__PURE__*/_angular_core__WEBPACK_IMPORTED_MODULE_11__["ɵɵdefineComponent"]({
  type: AppComponent,
  selectors: [["app-root"]],
  decls: 2,
  vars: 0,
  template: function AppComponent_Template(rf, ctx) {
    if (rf & 1) {
      _angular_core__WEBPACK_IMPORTED_MODULE_11__["ɵɵelementStart"](0, "ion-app");
      _angular_core__WEBPACK_IMPORTED_MODULE_11__["ɵɵelement"](1, "ion-router-outlet");
      _angular_core__WEBPACK_IMPORTED_MODULE_11__["ɵɵelementEnd"]();
    }
  },
  directives: [_ionic_angular__WEBPACK_IMPORTED_MODULE_13__.IonApp, _ionic_angular__WEBPACK_IMPORTED_MODULE_13__.IonRouterOutlet],
  styles: ["\n/*# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbXSwibmFtZXMiOltdLCJtYXBwaW5ncyI6IiIsImZpbGUiOiJhcHAuY29tcG9uZW50LnNjc3MifQ== */"]
});

/***/ }),

/***/ 36747:
/*!*******************************!*\
  !*** ./src/app/app.module.ts ***!
  \*******************************/
/***/ (function(__unused_webpack_module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "AppModule": function() { return /* binding */ AppModule; },
/* harmony export */   "createTranslateLoader": function() { return /* binding */ createTranslateLoader; }
/* harmony export */ });
/* harmony import */ var _Users_smartcommunitylab_Documents_work_projects_dslab_playgo_mobile_playgo_mobile_node_modules_babel_runtime_helpers_esm_createClass_js__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./node_modules/@babel/runtime/helpers/esm/createClass.js */ 48047);
/* harmony import */ var _Users_smartcommunitylab_Documents_work_projects_dslab_playgo_mobile_playgo_mobile_node_modules_babel_runtime_helpers_esm_classCallCheck_js__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ./node_modules/@babel/runtime/helpers/esm/classCallCheck.js */ 78069);
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_19__ = __webpack_require__(/*! @angular/core */ 3184);
/* harmony import */ var _angular_platform_browser__WEBPACK_IMPORTED_MODULE_22__ = __webpack_require__(/*! @angular/platform-browser */ 50318);
/* harmony import */ var _angular_router__WEBPACK_IMPORTED_MODULE_20__ = __webpack_require__(/*! @angular/router */ 52816);
/* harmony import */ var _ionic_angular__WEBPACK_IMPORTED_MODULE_21__ = __webpack_require__(/*! @ionic/angular */ 93819);
/* harmony import */ var _app_component__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! ./app.component */ 55041);
/* harmony import */ var _app_routing_module__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! ./app-routing.module */ 90158);
/* harmony import */ var _core_shared_shared_module__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! ./core/shared/shared.module */ 97205);
/* harmony import */ var _ngx_translate_core__WEBPACK_IMPORTED_MODULE_23__ = __webpack_require__(/*! @ngx-translate/core */ 87514);
/* harmony import */ var _angular_common_http__WEBPACK_IMPORTED_MODULE_24__ = __webpack_require__(/*! @angular/common/http */ 28784);
/* harmony import */ var _ngx_translate_http_loader__WEBPACK_IMPORTED_MODULE_18__ = __webpack_require__(/*! @ngx-translate/http-loader */ 75347);
/* harmony import */ var _core_auth_auth_module__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! ./core/auth/auth.module */ 26734);
/* harmony import */ var _transistorsoft_capacitor_background_geolocation__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! @transistorsoft/capacitor-background-geolocation */ 61505);
/* harmony import */ var _core_shared_plugin_mocks_BackgroundGeolocationMock__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(/*! ./core/shared/plugin-mocks/BackgroundGeolocationMock */ 91157);
/* harmony import */ var _capacitor_app__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(/*! @capacitor/app */ 93253);
/* harmony import */ var _core_shared_plugin_mocks_AppPluginMock__WEBPACK_IMPORTED_MODULE_9__ = __webpack_require__(/*! ./core/shared/plugin-mocks/AppPluginMock */ 81386);
/* harmony import */ var capacitor_codepush__WEBPACK_IMPORTED_MODULE_10__ = __webpack_require__(/*! capacitor-codepush */ 81867);
/* harmony import */ var _core_shared_services_global_error_handler__WEBPACK_IMPORTED_MODULE_11__ = __webpack_require__(/*! ./core/shared/services/global-error-handler */ 69961);
/* harmony import */ var _capacitor_device__WEBPACK_IMPORTED_MODULE_12__ = __webpack_require__(/*! @capacitor/device */ 4744);
/* harmony import */ var _core_shared_plugin_mocks_DevicePluginMock__WEBPACK_IMPORTED_MODULE_13__ = __webpack_require__(/*! ./core/shared/plugin-mocks/DevicePluginMock */ 45536);
/* harmony import */ var _angular_common_locales_it__WEBPACK_IMPORTED_MODULE_14__ = __webpack_require__(/*! @angular/common/locales/it */ 4129);
/* harmony import */ var _angular_common__WEBPACK_IMPORTED_MODULE_17__ = __webpack_require__(/*! @angular/common */ 36362);
/* harmony import */ var _core_shared_plugin_mocks_CodePushPluginMock__WEBPACK_IMPORTED_MODULE_15__ = __webpack_require__(/*! ./core/shared/plugin-mocks/CodePushPluginMock */ 87833);
/* harmony import */ var _ionic_storage_angular__WEBPACK_IMPORTED_MODULE_25__ = __webpack_require__(/*! @ionic/storage-angular */ 47566);
/* harmony import */ var localforage_cordovasqlitedriver__WEBPACK_IMPORTED_MODULE_16__ = __webpack_require__(/*! localforage-cordovasqlitedriver */ 7878);
/* harmony import */ var localforage_cordovasqlitedriver__WEBPACK_IMPORTED_MODULE_16___default = /*#__PURE__*/__webpack_require__.n(localforage_cordovasqlitedriver__WEBPACK_IMPORTED_MODULE_16__);



/* eslint-disable @typescript-eslint/naming-convention */



























 // this is somehow not exported from '@ionic/storage-angular'

var Drivers = {
  SecureStorage: 'ionicSecureStorage',
  IndexedDB: 'asyncStorage',
  LocalStorage: 'localStorageWrapper'
};
(0,_angular_common__WEBPACK_IMPORTED_MODULE_17__.registerLocaleData)(_angular_common_locales_it__WEBPACK_IMPORTED_MODULE_14__["default"]);
function createTranslateLoader(http) {
  return new _ngx_translate_http_loader__WEBPACK_IMPORTED_MODULE_18__.TranslateHttpLoader(http, './assets/i18n/', '.json');
}
var AppModule = /*#__PURE__*/(0,_Users_smartcommunitylab_Documents_work_projects_dslab_playgo_mobile_playgo_mobile_node_modules_babel_runtime_helpers_esm_createClass_js__WEBPACK_IMPORTED_MODULE_0__["default"])(function AppModule() {
  (0,_Users_smartcommunitylab_Documents_work_projects_dslab_playgo_mobile_playgo_mobile_node_modules_babel_runtime_helpers_esm_classCallCheck_js__WEBPACK_IMPORTED_MODULE_1__["default"])(this, AppModule);
});

AppModule.ɵfac = function AppModule_Factory(t) {
  return new (t || AppModule)();
};

AppModule.ɵmod = /*@__PURE__*/_angular_core__WEBPACK_IMPORTED_MODULE_19__["ɵɵdefineNgModule"]({
  type: AppModule,
  bootstrap: [_app_component__WEBPACK_IMPORTED_MODULE_2__.AppComponent]
});
AppModule.ɵinj = /*@__PURE__*/_angular_core__WEBPACK_IMPORTED_MODULE_19__["ɵɵdefineInjector"]({
  providers: [{
    provide: _angular_router__WEBPACK_IMPORTED_MODULE_20__.RouteReuseStrategy,
    useClass: _ionic_angular__WEBPACK_IMPORTED_MODULE_21__.IonicRouteStrategy
  }, {
    provide: 'BackgroundGeolocationPlugin',
    useFactory: function useFactory() {
      return useMock() ? _core_shared_plugin_mocks_BackgroundGeolocationMock__WEBPACK_IMPORTED_MODULE_7__.BackgroundGeolocationMock : _transistorsoft_capacitor_background_geolocation__WEBPACK_IMPORTED_MODULE_6__["default"];
    }
  }, {
    provide: 'AppPlugin',
    useFactory: function useFactory() {
      return useMock() ? _core_shared_plugin_mocks_AppPluginMock__WEBPACK_IMPORTED_MODULE_9__.AppPluginMock : _capacitor_app__WEBPACK_IMPORTED_MODULE_8__.App;
    }
  }, {
    provide: 'DevicePlugin',
    useFactory: function useFactory() {
      return useMock() ? _core_shared_plugin_mocks_DevicePluginMock__WEBPACK_IMPORTED_MODULE_13__.DevicePluginMock : _capacitor_device__WEBPACK_IMPORTED_MODULE_12__.Device;
    }
  }, {
    provide: 'CodePushPlugin',
    useFactory: function useFactory() {
      return useMock() ? _core_shared_plugin_mocks_CodePushPluginMock__WEBPACK_IMPORTED_MODULE_15__.CodePushPluginMock : capacitor_codepush__WEBPACK_IMPORTED_MODULE_10__.codePush;
    }
  }, {
    provide: _angular_core__WEBPACK_IMPORTED_MODULE_19__.ErrorHandler,
    useClass: _core_shared_services_global_error_handler__WEBPACK_IMPORTED_MODULE_11__.GlobalErrorHandler
  }],
  imports: [[_core_auth_auth_module__WEBPACK_IMPORTED_MODULE_5__.AuthModule, _angular_platform_browser__WEBPACK_IMPORTED_MODULE_22__.BrowserModule, _core_shared_shared_module__WEBPACK_IMPORTED_MODULE_4__.PlayGoSharedModule, _ngx_translate_core__WEBPACK_IMPORTED_MODULE_23__.TranslateModule.forRoot({
    loader: {
      provide: _ngx_translate_core__WEBPACK_IMPORTED_MODULE_23__.TranslateLoader,
      useFactory: createTranslateLoader,
      deps: [_angular_common_http__WEBPACK_IMPORTED_MODULE_24__.HttpClient]
    }
  }), _ionic_angular__WEBPACK_IMPORTED_MODULE_21__.IonicModule.forRoot(), _ionic_storage_angular__WEBPACK_IMPORTED_MODULE_25__.IonicStorageModule.forRoot({
    driverOrder: [// eslint-disable-next-line no-underscore-dangle
    localforage_cordovasqlitedriver__WEBPACK_IMPORTED_MODULE_16__._driver, Drivers.IndexedDB, Drivers.LocalStorage]
  }), _app_routing_module__WEBPACK_IMPORTED_MODULE_3__.AppRoutingModule]]
});

(function () {
  (typeof ngJitMode === "undefined" || ngJitMode) && _angular_core__WEBPACK_IMPORTED_MODULE_19__["ɵɵsetNgModuleScope"](AppModule, {
    declarations: [_app_component__WEBPACK_IMPORTED_MODULE_2__.AppComponent],
    imports: [_core_auth_auth_module__WEBPACK_IMPORTED_MODULE_5__.AuthModule, _angular_platform_browser__WEBPACK_IMPORTED_MODULE_22__.BrowserModule, _core_shared_shared_module__WEBPACK_IMPORTED_MODULE_4__.PlayGoSharedModule, _ngx_translate_core__WEBPACK_IMPORTED_MODULE_23__.TranslateModule, _ionic_angular__WEBPACK_IMPORTED_MODULE_21__.IonicModule, _ionic_storage_angular__WEBPACK_IMPORTED_MODULE_25__.IonicStorageModule, _app_routing_module__WEBPACK_IMPORTED_MODULE_3__.AppRoutingModule]
  });
})();

var useMock = function useMock() {
  return (0,_angular_core__WEBPACK_IMPORTED_MODULE_19__.isDevMode)() && getPlatformId(window) === 'web';
}; // copied from capacitor core source (it is not exported)


var getPlatformId = function getPlatformId(win) {
  var _a, _b;

  if (win === null || win === void 0 ? void 0 : win.androidBridge) {
    return 'android';
  } else if ((_b = (_a = win === null || win === void 0 ? void 0 : win.webkit) === null || _a === void 0 ? void 0 : _a.messageHandlers) === null || _b === void 0 ? void 0 : _b.bridge) {
    return 'ios';
  } else {
    return 'web';
  }
};

/***/ }),

/***/ 66846:
/*!******************************************************************************!*\
  !*** ./src/app/core/api/generated/controllers/campaignController.service.ts ***!
  \******************************************************************************/
/***/ (function(__unused_webpack_module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "CampaignControllerService": function() { return /* binding */ CampaignControllerService; }
/* harmony export */ });
/* harmony import */ var _Users_smartcommunitylab_Documents_work_projects_dslab_playgo_mobile_playgo_mobile_node_modules_babel_runtime_helpers_esm_classCallCheck_js__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./node_modules/@babel/runtime/helpers/esm/classCallCheck.js */ 78069);
/* harmony import */ var _Users_smartcommunitylab_Documents_work_projects_dslab_playgo_mobile_playgo_mobile_node_modules_babel_runtime_helpers_esm_createClass_js__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ./node_modules/@babel/runtime/helpers/esm/createClass.js */ 48047);
/* harmony import */ var src_environments_environment__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! src/environments/environment */ 92340);
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @angular/core */ 3184);
/* harmony import */ var _angular_common_http__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! @angular/common/http */ 28784);



/**
 * Play&Go Project
 * No description provided (generated by Swagger Codegen https://github.com/swagger-api/swagger-codegen)
 *
 * OpenAPI spec version: 2.0
 * Contact: info@smartcommunitylab.it
 *
 * NOTE: This class is auto generated by the swagger code generator program.
 * https://github.com/swagger-api/swagger-codegen.git
 * Do not edit the class manually.
 */



var CampaignControllerService = /*#__PURE__*/function () {
  function CampaignControllerService(http) {
    (0,_Users_smartcommunitylab_Documents_work_projects_dslab_playgo_mobile_playgo_mobile_node_modules_babel_runtime_helpers_esm_classCallCheck_js__WEBPACK_IMPORTED_MODULE_0__["default"])(this, CampaignControllerService);

    this.http = http;
  }
  /**
   * addCampaign
   *
   * @param body
   */


  (0,_Users_smartcommunitylab_Documents_work_projects_dslab_playgo_mobile_playgo_mobile_node_modules_babel_runtime_helpers_esm_createClass_js__WEBPACK_IMPORTED_MODULE_1__["default"])(CampaignControllerService, [{
    key: "addCampaignUsingPOST",
    value: function addCampaignUsingPOST(body) {
      return this.http.request('post', src_environments_environment__WEBPACK_IMPORTED_MODULE_2__.environment.serverUrl.api + "/playandgo/api/campaign", {
        body: body
      });
    }
    /**
     * addSurvey
     *
     * @param campaignId campaignId
     * @param body
     */

  }, {
    key: "addSurveyUsingPOST",
    value: function addSurveyUsingPOST(args) {
      var campaignId = args.campaignId,
          body = args.body;
      return this.http.request('post', src_environments_environment__WEBPACK_IMPORTED_MODULE_2__.environment.serverUrl.api + "/playandgo/api/campaign/".concat(encodeURIComponent(String(campaignId)), "/survey"), {
        body: body
      });
    }
    /**
     * deleteCampaign
     *
     * @param campaignId campaignId
     */

  }, {
    key: "deleteCampaignUsingDELETE",
    value: function deleteCampaignUsingDELETE(campaignId) {
      return this.http.request('delete', src_environments_environment__WEBPACK_IMPORTED_MODULE_2__.environment.serverUrl.api + "/playandgo/api/campaign/".concat(encodeURIComponent(String(campaignId))), {});
    }
    /**
     * deleteSurvey
     *
     * @param campaignId campaignId
     * @param name name
     */

  }, {
    key: "deleteSurveyUsingDELETE",
    value: function deleteSurveyUsingDELETE(args) {
      var campaignId = args.campaignId,
          name = args.name;
      return this.http.request('delete', src_environments_environment__WEBPACK_IMPORTED_MODULE_2__.environment.serverUrl.api + "/playandgo/api/campaign/".concat(encodeURIComponent(String(campaignId)), "/survey"), {
        params: removeNullOrUndefined({
          name: name
        })
      });
    }
    /**
     * deleteWebhook
     *
     * @param campaignId campaignId
     */

  }, {
    key: "deleteWebhookUsingDELETE",
    value: function deleteWebhookUsingDELETE(campaignId) {
      return this.http.request('delete', src_environments_environment__WEBPACK_IMPORTED_MODULE_2__.environment.serverUrl.api + "/playandgo/api/campaign/".concat(encodeURIComponent(String(campaignId)), "/webhook"), {});
    }
    /**
     * getCampaign
     *
     * @param campaignId campaignId
     */

  }, {
    key: "getCampaignUsingGET",
    value: function getCampaignUsingGET(campaignId) {
      return this.http.request('get', src_environments_environment__WEBPACK_IMPORTED_MODULE_2__.environment.serverUrl.api + "/playandgo/api/campaign/".concat(encodeURIComponent(String(campaignId))), {});
    }
    /**
     * getCampaignsByPlayer
     *
     * @param playerId playerId
     */

  }, {
    key: "getCampaignsByPlayerUsingGET",
    value: function getCampaignsByPlayerUsingGET(playerId) {
      return this.http.request('get', src_environments_environment__WEBPACK_IMPORTED_MODULE_2__.environment.serverUrl.api + "/playandgo/api/campaign/player", {
        params: removeNullOrUndefined({
          playerId: playerId
        })
      });
    }
    /**
     * getCampaigns
     *
     * @param territoryId territoryId
     * @param type type
     */

  }, {
    key: "getCampaignsUsingGET",
    value: function getCampaignsUsingGET(args) {
      var territoryId = args.territoryId,
          type = args.type;
      return this.http.request('get', src_environments_environment__WEBPACK_IMPORTED_MODULE_2__.environment.serverUrl.api + "/playandgo/api/campaign", {
        params: removeNullOrUndefined({
          territoryId: territoryId,
          type: type
        })
      });
    }
    /**
     * getMyCampaigns
     *
     */

  }, {
    key: "getMyCampaignsUsingGET",
    value: function getMyCampaignsUsingGET() {
      return this.http.request('get', src_environments_environment__WEBPACK_IMPORTED_MODULE_2__.environment.serverUrl.api + "/playandgo/api/campaign/my", {});
    }
    /**
     * getWebhook
     *
     * @param campaignId campaignId
     */

  }, {
    key: "getWebhookUsingGET",
    value: function getWebhookUsingGET(campaignId) {
      return this.http.request('get', src_environments_environment__WEBPACK_IMPORTED_MODULE_2__.environment.serverUrl.api + "/playandgo/api/campaign/".concat(encodeURIComponent(String(campaignId)), "/webhook"), {});
    }
    /**
     * setWebhook
     *
     * @param campaignId campaignId
     * @param body
     */

  }, {
    key: "setWebhookUsingPOST",
    value: function setWebhookUsingPOST(args) {
      var campaignId = args.campaignId,
          body = args.body;
      return this.http.request('post', src_environments_environment__WEBPACK_IMPORTED_MODULE_2__.environment.serverUrl.api + "/playandgo/api/campaign/".concat(encodeURIComponent(String(campaignId)), "/webhook"), {
        body: body
      });
    }
    /**
     * subscribeCampaign
     *
     * @param campaignId campaignId
     * @param body
     */

  }, {
    key: "subscribeCampaignUsingPOST",
    value: function subscribeCampaignUsingPOST(args) {
      var campaignId = args.campaignId,
          body = args.body;
      return this.http.request('post', src_environments_environment__WEBPACK_IMPORTED_MODULE_2__.environment.serverUrl.api + "/playandgo/api/campaign/".concat(encodeURIComponent(String(campaignId)), "/subscribe"), {
        body: body
      });
    }
    /**
     * unsubscribeCampaign
     *
     * @param campaignId campaignId
     */

  }, {
    key: "unsubscribeCampaignUsingPUT",
    value: function unsubscribeCampaignUsingPUT(campaignId) {
      return this.http.request('put', src_environments_environment__WEBPACK_IMPORTED_MODULE_2__.environment.serverUrl.api + "/playandgo/api/campaign/".concat(encodeURIComponent(String(campaignId)), "/unsubscribe"), {});
    }
    /**
     * updateCampaign
     *
     * @param body
     */

  }, {
    key: "updateCampaignUsingPUT",
    value: function updateCampaignUsingPUT(body) {
      return this.http.request('put', src_environments_environment__WEBPACK_IMPORTED_MODULE_2__.environment.serverUrl.api + "/playandgo/api/campaign", {
        body: body
      });
    }
    /**
     * uploadCampaignBanner
     *
     * @param campaignId campaignId
     * @param body
     */

  }, {
    key: "uploadCampaignBannerUsingPOST",
    value: function uploadCampaignBannerUsingPOST(args) {
      var campaignId = args.campaignId,
          body = args.body;
      return this.http.request('post', src_environments_environment__WEBPACK_IMPORTED_MODULE_2__.environment.serverUrl.api + "/playandgo/api/campaign/".concat(encodeURIComponent(String(campaignId)), "/banner"), {
        body: body
      });
    }
    /**
     * uploadCampaignLogo
     *
     * @param campaignId campaignId
     * @param body
     */

  }, {
    key: "uploadCampaignLogoUsingPOST",
    value: function uploadCampaignLogoUsingPOST(args) {
      var campaignId = args.campaignId,
          body = args.body;
      return this.http.request('post', src_environments_environment__WEBPACK_IMPORTED_MODULE_2__.environment.serverUrl.api + "/playandgo/api/campaign/".concat(encodeURIComponent(String(campaignId)), "/logo"), {
        body: body
      });
    }
    /**
     * uploadRewards
     *
     * @param campaignId campaignId
     * @param body
     */

  }, {
    key: "uploadRewardsUsingPOST",
    value: function uploadRewardsUsingPOST(args) {
      var campaignId = args.campaignId,
          body = args.body;
      return this.http.request('post', src_environments_environment__WEBPACK_IMPORTED_MODULE_2__.environment.serverUrl.api + "/playandgo/api/campaign/".concat(encodeURIComponent(String(campaignId)), "/reward"), {
        body: body
      });
    }
    /**
     * uploadWeekConfs
     *
     * @param campaignId campaignId
     * @param body
     */

  }, {
    key: "uploadWeekConfsUsingPOST",
    value: function uploadWeekConfsUsingPOST(args) {
      var campaignId = args.campaignId,
          body = args.body;
      return this.http.request('post', src_environments_environment__WEBPACK_IMPORTED_MODULE_2__.environment.serverUrl.api + "/playandgo/api/campaign/".concat(encodeURIComponent(String(campaignId)), "/weekconf"), {
        body: body
      });
    }
  }]);

  return CampaignControllerService;
}();

CampaignControllerService.ɵfac = function CampaignControllerService_Factory(t) {
  return new (t || CampaignControllerService)(_angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵinject"](_angular_common_http__WEBPACK_IMPORTED_MODULE_4__.HttpClient));
};

CampaignControllerService.ɵprov = /*@__PURE__*/_angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵdefineInjectable"]({
  token: CampaignControllerService,
  factory: CampaignControllerService.ɵfac,
  providedIn: 'root'
});

function removeNullOrUndefined(obj) {
  var newObj = {};
  Object.keys(obj).forEach(function (key) {
    if (obj[key] != null) {
      newObj[key] = obj[key];
    }
  });
  return newObj;
}

/***/ }),

/***/ 74458:
/*!*******************************************************************************!*\
  !*** ./src/app/core/api/generated/controllers/challengeController.service.ts ***!
  \*******************************************************************************/
/***/ (function(__unused_webpack_module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "ChallengeControllerService": function() { return /* binding */ ChallengeControllerService; }
/* harmony export */ });
/* harmony import */ var _Users_smartcommunitylab_Documents_work_projects_dslab_playgo_mobile_playgo_mobile_node_modules_babel_runtime_helpers_esm_classCallCheck_js__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./node_modules/@babel/runtime/helpers/esm/classCallCheck.js */ 78069);
/* harmony import */ var _Users_smartcommunitylab_Documents_work_projects_dslab_playgo_mobile_playgo_mobile_node_modules_babel_runtime_helpers_esm_createClass_js__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ./node_modules/@babel/runtime/helpers/esm/createClass.js */ 48047);
/* harmony import */ var src_environments_environment__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! src/environments/environment */ 92340);
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @angular/core */ 3184);
/* harmony import */ var _angular_common_http__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! @angular/common/http */ 28784);



/**
 * Play&Go Project
 * No description provided (generated by Swagger Codegen https://github.com/swagger-api/swagger-codegen)
 *
 * OpenAPI spec version: 2.0
 * Contact: info@smartcommunitylab.it
 *
 * NOTE: This class is auto generated by the swagger code generator program.
 * https://github.com/swagger-api/swagger-codegen.git
 * Do not edit the class manually.
 */



var ChallengeControllerService = /*#__PURE__*/function () {
  function ChallengeControllerService(http) {
    (0,_Users_smartcommunitylab_Documents_work_projects_dslab_playgo_mobile_playgo_mobile_node_modules_babel_runtime_helpers_esm_classCallCheck_js__WEBPACK_IMPORTED_MODULE_0__["default"])(this, ChallengeControllerService);

    this.http = http;
  }
  /**
   * activateChallengeType
   *
   * @param challengeName challengeName
   * @param campaignId campaignId
   */


  (0,_Users_smartcommunitylab_Documents_work_projects_dslab_playgo_mobile_playgo_mobile_node_modules_babel_runtime_helpers_esm_createClass_js__WEBPACK_IMPORTED_MODULE_1__["default"])(ChallengeControllerService, [{
    key: "activateChallengeTypeUsingPUT",
    value: function activateChallengeTypeUsingPUT(args) {
      var challengeName = args.challengeName,
          campaignId = args.campaignId;
      return this.http.request('put', src_environments_environment__WEBPACK_IMPORTED_MODULE_2__.environment.serverUrl.api + "/playandgo/api/challenge/unlock/".concat(encodeURIComponent(String(challengeName))), {
        params: removeNullOrUndefined({
          campaignId: campaignId
        })
      });
    }
    /**
     * addToBlackList
     *
     * @param campaignId campaignId
     * @param blockedPlayerId blockedPlayerId
     */

  }, {
    key: "addToBlackListUsingPOST",
    value: function addToBlackListUsingPOST(args) {
      var campaignId = args.campaignId,
          blockedPlayerId = args.blockedPlayerId;
      return this.http.request('post', src_environments_environment__WEBPACK_IMPORTED_MODULE_2__.environment.serverUrl.api + "/playandgo/api/challenge/blacklist", {
        params: removeNullOrUndefined({
          campaignId: campaignId,
          blockedPlayerId: blockedPlayerId
        })
      });
    }
    /**
     * changeInvitationStatus
     *
     * @param campaignId campaignId
     * @param challengeName challengeName
     * @param status status
     */

  }, {
    key: "changeInvitationStatusUsingPOST",
    value: function changeInvitationStatusUsingPOST(args) {
      var campaignId = args.campaignId,
          challengeName = args.challengeName,
          status = args.status;
      return this.http.request('post', src_environments_environment__WEBPACK_IMPORTED_MODULE_2__.environment.serverUrl.api + "/playandgo/api/challenge/invitation/status/".concat(encodeURIComponent(String(challengeName)), "/").concat(encodeURIComponent(String(status))), {
        params: removeNullOrUndefined({
          campaignId: campaignId
        })
      });
    }
    /**
     * chooseChallenge
     *
     * @param challengeId challengeId
     * @param campaignId campaignId
     */

  }, {
    key: "chooseChallengeUsingPUT",
    value: function chooseChallengeUsingPUT(args) {
      var challengeId = args.challengeId,
          campaignId = args.campaignId;
      return this.http.request('put', src_environments_environment__WEBPACK_IMPORTED_MODULE_2__.environment.serverUrl.api + "/playandgo/api/challenge/choose/".concat(encodeURIComponent(String(challengeId))), {
        params: removeNullOrUndefined({
          campaignId: campaignId
        })
      });
    }
    /**
     * deleteFromBlackList
     *
     * @param campaignId campaignId
     * @param blockedPlayerId blockedPlayerId
     */

  }, {
    key: "deleteFromBlackListUsingDELETE",
    value: function deleteFromBlackListUsingDELETE(args) {
      var campaignId = args.campaignId,
          blockedPlayerId = args.blockedPlayerId;
      return this.http.request('delete', src_environments_environment__WEBPACK_IMPORTED_MODULE_2__.environment.serverUrl.api + "/playandgo/api/challenge/blacklist", {
        params: removeNullOrUndefined({
          campaignId: campaignId,
          blockedPlayerId: blockedPlayerId
        })
      });
    }
    /**
     * getBlackList
     *
     * @param campaignId campaignId
     */

  }, {
    key: "getBlackListUsingGET",
    value: function getBlackListUsingGET(campaignId) {
      return this.http.request('get', src_environments_environment__WEBPACK_IMPORTED_MODULE_2__.environment.serverUrl.api + "/playandgo/api/challenge/blacklist", {
        params: removeNullOrUndefined({
          campaignId: campaignId
        })
      });
    }
    /**
     * getChallengeStats
     *
     * @param campaignId campaignId
     * @param playerId playerId
     * @param groupMode groupMode
     * @param dateFrom yyyy-MM-dd
     * @param dateTo yyyy-MM-dd
     */

  }, {
    key: "getChallengeStatsUsingGET",
    value: function getChallengeStatsUsingGET(args) {
      var campaignId = args.campaignId,
          playerId = args.playerId,
          groupMode = args.groupMode,
          dateFrom = args.dateFrom,
          dateTo = args.dateTo;
      return this.http.request('get', src_environments_environment__WEBPACK_IMPORTED_MODULE_2__.environment.serverUrl.api + "/playandgo/api/challenge/stats", {
        params: removeNullOrUndefined({
          campaignId: campaignId,
          playerId: playerId,
          groupMode: groupMode,
          dateFrom: dateFrom,
          dateTo: dateTo
        })
      });
    }
    /**
     * getChallengeables
     *
     * @param campaignId campaignId
     */

  }, {
    key: "getChallengeablesUsingGET",
    value: function getChallengeablesUsingGET(campaignId) {
      return this.http.request('get', src_environments_environment__WEBPACK_IMPORTED_MODULE_2__.environment.serverUrl.api + "/playandgo/api/challenge/challengeables", {
        params: removeNullOrUndefined({
          campaignId: campaignId
        })
      });
    }
    /**
     * getChallengesStatus
     *
     * @param campaignId campaignId
     */

  }, {
    key: "getChallengesStatusUsingGET",
    value: function getChallengesStatusUsingGET(campaignId) {
      return this.http.request('get', src_environments_environment__WEBPACK_IMPORTED_MODULE_2__.environment.serverUrl.api + "/playandgo/api/challenge/type", {
        params: removeNullOrUndefined({
          campaignId: campaignId
        })
      });
    }
    /**
     * getChallenges
     *
     * @param campaignId campaignId
     * @param filter filter
     */

  }, {
    key: "getChallengesUsingGET",
    value: function getChallengesUsingGET(args) {
      var campaignId = args.campaignId,
          filter = args.filter;
      return this.http.request('get', src_environments_environment__WEBPACK_IMPORTED_MODULE_2__.environment.serverUrl.api + "/playandgo/api/challenge", {
        params: removeNullOrUndefined({
          campaignId: campaignId,
          filter: filter
        })
      });
    }
    /**
     * getGroupChallengePreview
     *
     * @param campaignId campaignId
     * @param body
     */

  }, {
    key: "getGroupChallengePreviewUsingPOST",
    value: function getGroupChallengePreviewUsingPOST(args) {
      var campaignId = args.campaignId,
          body = args.body;
      return this.http.request('post', src_environments_environment__WEBPACK_IMPORTED_MODULE_2__.environment.serverUrl.api + "/playandgo/api/challenge/invitation/preview", {
        body: body,
        params: removeNullOrUndefined({
          campaignId: campaignId
        })
      });
    }
    /**
     * getRewards
     *
     */

  }, {
    key: "getRewardsUsingGET",
    value: function getRewardsUsingGET() {
      return this.http.request('get', src_environments_environment__WEBPACK_IMPORTED_MODULE_2__.environment.serverUrl.api + "/playandgo/api/challenge/rewards", {});
    }
    /**
     * sendInvitation
     *
     * @param campaignId campaignId
     * @param body
     */

  }, {
    key: "sendInvitationUsingPOST",
    value: function sendInvitationUsingPOST(args) {
      var campaignId = args.campaignId,
          body = args.body;
      return this.http.request('post', src_environments_environment__WEBPACK_IMPORTED_MODULE_2__.environment.serverUrl.api + "/playandgo/api/challenge/invitation", {
        body: body,
        params: removeNullOrUndefined({
          campaignId: campaignId
        })
      });
    }
  }]);

  return ChallengeControllerService;
}();

ChallengeControllerService.ɵfac = function ChallengeControllerService_Factory(t) {
  return new (t || ChallengeControllerService)(_angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵinject"](_angular_common_http__WEBPACK_IMPORTED_MODULE_4__.HttpClient));
};

ChallengeControllerService.ɵprov = /*@__PURE__*/_angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵdefineInjectable"]({
  token: ChallengeControllerService,
  factory: ChallengeControllerService.ɵfac,
  providedIn: 'root'
});

function removeNullOrUndefined(obj) {
  var newObj = {};
  Object.keys(obj).forEach(function (key) {
    if (obj[key] != null) {
      newObj[key] = obj[key];
    }
  });
  return newObj;
}

/***/ }),

/***/ 94078:
/*!******************************************************************************************!*\
  !*** ./src/app/core/api/generated/controllers/communicationAccountController.service.ts ***!
  \******************************************************************************************/
/***/ (function(__unused_webpack_module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "CommunicationAccountControllerService": function() { return /* binding */ CommunicationAccountControllerService; }
/* harmony export */ });
/* harmony import */ var _Users_smartcommunitylab_Documents_work_projects_dslab_playgo_mobile_playgo_mobile_node_modules_babel_runtime_helpers_esm_classCallCheck_js__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./node_modules/@babel/runtime/helpers/esm/classCallCheck.js */ 78069);
/* harmony import */ var _Users_smartcommunitylab_Documents_work_projects_dslab_playgo_mobile_playgo_mobile_node_modules_babel_runtime_helpers_esm_createClass_js__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ./node_modules/@babel/runtime/helpers/esm/createClass.js */ 48047);
/* harmony import */ var src_environments_environment__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! src/environments/environment */ 92340);
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @angular/core */ 3184);
/* harmony import */ var _angular_common_http__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! @angular/common/http */ 28784);



/**
 * Play&Go Project
 * No description provided (generated by Swagger Codegen https://github.com/swagger-api/swagger-codegen)
 *
 * OpenAPI spec version: 2.0
 * Contact: info@smartcommunitylab.it
 *
 * NOTE: This class is auto generated by the swagger code generator program.
 * https://github.com/swagger-api/swagger-codegen.git
 * Do not edit the class manually.
 */



var CommunicationAccountControllerService = /*#__PURE__*/function () {
  function CommunicationAccountControllerService(http) {
    (0,_Users_smartcommunitylab_Documents_work_projects_dslab_playgo_mobile_playgo_mobile_node_modules_babel_runtime_helpers_esm_classCallCheck_js__WEBPACK_IMPORTED_MODULE_0__["default"])(this, CommunicationAccountControllerService);

    this.http = http;
  }
  /**
   * getPlayerNotifications
   *
   * @param since since
   * @param skip skip
   * @param limit limit
   */


  (0,_Users_smartcommunitylab_Documents_work_projects_dslab_playgo_mobile_playgo_mobile_node_modules_babel_runtime_helpers_esm_createClass_js__WEBPACK_IMPORTED_MODULE_1__["default"])(CommunicationAccountControllerService, [{
    key: "getPlayerNotificationsUsingGET",
    value: function getPlayerNotificationsUsingGET(args) {
      var since = args.since,
          skip = args.skip,
          limit = args.limit;
      return this.http.request('get', src_environments_environment__WEBPACK_IMPORTED_MODULE_2__.environment.serverUrl.api + "/playandgo/api/app/notifications", {
        params: removeNullOrUndefined({
          since: since,
          skip: skip,
          limit: limit
        })
      });
    }
    /**
     * registerUserToPush
     *
     * @param body
     */

  }, {
    key: "registerUserToPushUsingPOST",
    value: function registerUserToPushUsingPOST(body) {
      return this.http.request('post', src_environments_environment__WEBPACK_IMPORTED_MODULE_2__.environment.serverUrl.api + "/playandgo/api/app/register", {
        body: body
      });
    }
  }]);

  return CommunicationAccountControllerService;
}();

CommunicationAccountControllerService.ɵfac = function CommunicationAccountControllerService_Factory(t) {
  return new (t || CommunicationAccountControllerService)(_angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵinject"](_angular_common_http__WEBPACK_IMPORTED_MODULE_4__.HttpClient));
};

CommunicationAccountControllerService.ɵprov = /*@__PURE__*/_angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵdefineInjectable"]({
  token: CommunicationAccountControllerService,
  factory: CommunicationAccountControllerService.ɵfac,
  providedIn: 'root'
});

function removeNullOrUndefined(obj) {
  var newObj = {};
  Object.keys(obj).forEach(function (key) {
    if (obj[key] != null) {
      newObj[key] = obj[key];
    }
  });
  return newObj;
}

/***/ }),

/***/ 89903:
/*!**************************************************************************!*\
  !*** ./src/app/core/api/generated/controllers/gameController.service.ts ***!
  \**************************************************************************/
/***/ (function(__unused_webpack_module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "GameControllerService": function() { return /* binding */ GameControllerService; }
/* harmony export */ });
/* harmony import */ var _Users_smartcommunitylab_Documents_work_projects_dslab_playgo_mobile_playgo_mobile_node_modules_babel_runtime_helpers_esm_classCallCheck_js__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./node_modules/@babel/runtime/helpers/esm/classCallCheck.js */ 78069);
/* harmony import */ var _Users_smartcommunitylab_Documents_work_projects_dslab_playgo_mobile_playgo_mobile_node_modules_babel_runtime_helpers_esm_createClass_js__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ./node_modules/@babel/runtime/helpers/esm/createClass.js */ 48047);
/* harmony import */ var src_environments_environment__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! src/environments/environment */ 92340);
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @angular/core */ 3184);
/* harmony import */ var _angular_common_http__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! @angular/common/http */ 28784);



/**
 * Play&Go Project
 * No description provided (generated by Swagger Codegen https://github.com/swagger-api/swagger-codegen)
 *
 * OpenAPI spec version: 2.0
 * Contact: info@smartcommunitylab.it
 *
 * NOTE: This class is auto generated by the swagger code generator program.
 * https://github.com/swagger-api/swagger-codegen.git
 * Do not edit the class manually.
 */



var GameControllerService = /*#__PURE__*/function () {
  function GameControllerService(http) {
    (0,_Users_smartcommunitylab_Documents_work_projects_dslab_playgo_mobile_playgo_mobile_node_modules_babel_runtime_helpers_esm_classCallCheck_js__WEBPACK_IMPORTED_MODULE_0__["default"])(this, GameControllerService);

    this.http = http;
  }
  /**
   * getAllBadges
   *
   */


  (0,_Users_smartcommunitylab_Documents_work_projects_dslab_playgo_mobile_playgo_mobile_node_modules_babel_runtime_helpers_esm_createClass_js__WEBPACK_IMPORTED_MODULE_1__["default"])(GameControllerService, [{
    key: "getAllBadgesUsingGET",
    value: function getAllBadgesUsingGET() {
      return this.http.request('get', src_environments_environment__WEBPACK_IMPORTED_MODULE_2__.environment.serverUrl.api + "/playandgo/api/game/badge", {});
    }
    /**
     * getCampaignGameStatus
     *
     * @param campaignId campaignId
     */

  }, {
    key: "getCampaignGameStatusUsingGET",
    value: function getCampaignGameStatusUsingGET(campaignId) {
      return this.http.request('get', src_environments_environment__WEBPACK_IMPORTED_MODULE_2__.environment.serverUrl.api + "/playandgo/api/game/campaign", {
        params: removeNullOrUndefined({
          campaignId: campaignId
        })
      });
    }
  }]);

  return GameControllerService;
}();

GameControllerService.ɵfac = function GameControllerService_Factory(t) {
  return new (t || GameControllerService)(_angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵinject"](_angular_common_http__WEBPACK_IMPORTED_MODULE_4__.HttpClient));
};

GameControllerService.ɵprov = /*@__PURE__*/_angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵdefineInjectable"]({
  token: GameControllerService,
  factory: GameControllerService.ɵfac,
  providedIn: 'root'
});

function removeNullOrUndefined(obj) {
  var newObj = {};
  Object.keys(obj).forEach(function (key) {
    if (obj[key] != null) {
      newObj[key] = obj[key];
    }
  });
  return newObj;
}

/***/ }),

/***/ 60148:
/*!****************************************************************************!*\
  !*** ./src/app/core/api/generated/controllers/playerController.service.ts ***!
  \****************************************************************************/
/***/ (function(__unused_webpack_module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "PlayerControllerService": function() { return /* binding */ PlayerControllerService; }
/* harmony export */ });
/* harmony import */ var _Users_smartcommunitylab_Documents_work_projects_dslab_playgo_mobile_playgo_mobile_node_modules_babel_runtime_helpers_esm_classCallCheck_js__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./node_modules/@babel/runtime/helpers/esm/classCallCheck.js */ 78069);
/* harmony import */ var _Users_smartcommunitylab_Documents_work_projects_dslab_playgo_mobile_playgo_mobile_node_modules_babel_runtime_helpers_esm_createClass_js__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ./node_modules/@babel/runtime/helpers/esm/createClass.js */ 48047);
/* harmony import */ var src_environments_environment__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! src/environments/environment */ 92340);
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @angular/core */ 3184);
/* harmony import */ var _angular_common_http__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! @angular/common/http */ 28784);



/**
 * Play&Go Project
 * No description provided (generated by Swagger Codegen https://github.com/swagger-api/swagger-codegen)
 *
 * OpenAPI spec version: 2.0
 * Contact: info@smartcommunitylab.it
 *
 * NOTE: This class is auto generated by the swagger code generator program.
 * https://github.com/swagger-api/swagger-codegen.git
 * Do not edit the class manually.
 */



var PlayerControllerService = /*#__PURE__*/function () {
  function PlayerControllerService(http) {
    (0,_Users_smartcommunitylab_Documents_work_projects_dslab_playgo_mobile_playgo_mobile_node_modules_babel_runtime_helpers_esm_classCallCheck_js__WEBPACK_IMPORTED_MODULE_0__["default"])(this, PlayerControllerService);

    this.http = http;
  }
  /**
   * addPlayer
   *
   * @param body
   */


  (0,_Users_smartcommunitylab_Documents_work_projects_dslab_playgo_mobile_playgo_mobile_node_modules_babel_runtime_helpers_esm_createClass_js__WEBPACK_IMPORTED_MODULE_1__["default"])(PlayerControllerService, [{
    key: "addPlayerUsingPOST",
    value: function addPlayerUsingPOST(body) {
      return this.http.request('post', src_environments_environment__WEBPACK_IMPORTED_MODULE_2__.environment.serverUrl.api + "/playandgo/api/player", {
        body: body
      });
    }
    /**
     * checkNickname
     *
     * @param nickname nickname
     */

  }, {
    key: "checkNicknameUsingGET",
    value: function checkNicknameUsingGET(nickname) {
      return this.http.request('get', src_environments_environment__WEBPACK_IMPORTED_MODULE_2__.environment.serverUrl.api + "/playandgo/api/player/nick", {
        params: removeNullOrUndefined({
          nickname: nickname
        })
      });
    }
    /**
     * deletePlayer
     *
     * @param playerId playerId
     */

  }, {
    key: "deletePlayerUsingDELETE",
    value: function deletePlayerUsingDELETE(playerId) {
      return this.http.request('delete', src_environments_environment__WEBPACK_IMPORTED_MODULE_2__.environment.serverUrl.api + "/playandgo/api/player/".concat(encodeURIComponent(String(playerId))), {});
    }
    /**
     * getPlayerAvatar
     *
     * @param playerId playerId
     */

  }, {
    key: "getPlayerAvatarUsingGET",
    value: function getPlayerAvatarUsingGET(playerId) {
      return this.http.request('get', src_environments_environment__WEBPACK_IMPORTED_MODULE_2__.environment.serverUrl.api + "/playandgo/api/player/avatar", {
        params: removeNullOrUndefined({
          playerId: playerId
        })
      });
    }
    /**
     * getPlayer
     *
     * @param playerId playerId
     */

  }, {
    key: "getPlayerUsingGET1",
    value: function getPlayerUsingGET1(playerId) {
      return this.http.request('get', src_environments_environment__WEBPACK_IMPORTED_MODULE_2__.environment.serverUrl.api + "/playandgo/api/player/".concat(encodeURIComponent(String(playerId))), {});
    }
    /**
     * getProfile
     *
     */

  }, {
    key: "getProfileUsingGET",
    value: function getProfileUsingGET() {
      return this.http.request('get', src_environments_environment__WEBPACK_IMPORTED_MODULE_2__.environment.serverUrl.api + "/playandgo/api/player/profile", {});
    }
    /**
     * registerPlayer
     *
     * @param body
     */

  }, {
    key: "registerPlayerUsingPOST",
    value: function registerPlayerUsingPOST(body) {
      return this.http.request('post', src_environments_environment__WEBPACK_IMPORTED_MODULE_2__.environment.serverUrl.api + "/playandgo/api/player/register", {
        body: body
      });
    }
    /**
     * searchNickname
     *
     * @param nickname nickname
     */

  }, {
    key: "searchNicknameUsingGET",
    value: function searchNicknameUsingGET(nickname) {
      return this.http.request('get', src_environments_environment__WEBPACK_IMPORTED_MODULE_2__.environment.serverUrl.api + "/playandgo/api/player/search", {
        params: removeNullOrUndefined({
          nickname: nickname
        })
      });
    }
    /**
     * updateProfile
     *
     * @param body
     */

  }, {
    key: "updateProfileUsingPUT",
    value: function updateProfileUsingPUT(body) {
      return this.http.request('put', src_environments_environment__WEBPACK_IMPORTED_MODULE_2__.environment.serverUrl.api + "/playandgo/api/player/profile", {
        body: body
      });
    }
    /**
     * uploadPlayerAvatar
     *
     * @param body
     */

  }, {
    key: "uploadPlayerAvatarUsingPOST",
    value: function uploadPlayerAvatarUsingPOST(body) {
      return this.http.request('post', src_environments_environment__WEBPACK_IMPORTED_MODULE_2__.environment.serverUrl.api + "/playandgo/api/player/avatar", {
        body: body
      });
    }
  }]);

  return PlayerControllerService;
}();

PlayerControllerService.ɵfac = function PlayerControllerService_Factory(t) {
  return new (t || PlayerControllerService)(_angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵinject"](_angular_common_http__WEBPACK_IMPORTED_MODULE_4__.HttpClient));
};

PlayerControllerService.ɵprov = /*@__PURE__*/_angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵdefineInjectable"]({
  token: PlayerControllerService,
  factory: PlayerControllerService.ɵfac,
  providedIn: 'root'
});

function removeNullOrUndefined(obj) {
  var newObj = {};
  Object.keys(obj).forEach(function (key) {
    if (obj[key] != null) {
      newObj[key] = obj[key];
    }
  });
  return newObj;
}

/***/ }),

/***/ 59730:
/*!****************************************************************************!*\
  !*** ./src/app/core/api/generated/controllers/reportController.service.ts ***!
  \****************************************************************************/
/***/ (function(__unused_webpack_module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "ReportControllerService": function() { return /* binding */ ReportControllerService; }
/* harmony export */ });
/* harmony import */ var _Users_smartcommunitylab_Documents_work_projects_dslab_playgo_mobile_playgo_mobile_node_modules_babel_runtime_helpers_esm_classCallCheck_js__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./node_modules/@babel/runtime/helpers/esm/classCallCheck.js */ 78069);
/* harmony import */ var _Users_smartcommunitylab_Documents_work_projects_dslab_playgo_mobile_playgo_mobile_node_modules_babel_runtime_helpers_esm_createClass_js__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ./node_modules/@babel/runtime/helpers/esm/createClass.js */ 48047);
/* harmony import */ var src_environments_environment__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! src/environments/environment */ 92340);
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @angular/core */ 3184);
/* harmony import */ var _angular_common_http__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! @angular/common/http */ 28784);



/**
 * Play&Go Project
 * No description provided (generated by Swagger Codegen https://github.com/swagger-api/swagger-codegen)
 *
 * OpenAPI spec version: 2.0
 * Contact: info@smartcommunitylab.it
 *
 * NOTE: This class is auto generated by the swagger code generator program.
 * https://github.com/swagger-api/swagger-codegen.git
 * Do not edit the class manually.
 */



var ReportControllerService = /*#__PURE__*/function () {
  function ReportControllerService(http) {
    (0,_Users_smartcommunitylab_Documents_work_projects_dslab_playgo_mobile_playgo_mobile_node_modules_babel_runtime_helpers_esm_classCallCheck_js__WEBPACK_IMPORTED_MODULE_0__["default"])(this, ReportControllerService);

    this.http = http;
  }
  /**
   * getCampaingPlacingByGame
   *
   * @param campaignId campaignId
   * @param page Results page you want to retrieve (0..N)
   * @param size Number of records per page
   * @param sort Sorting option: field,[asc,desc]
   * @param dateFrom yyyy-MM-dd
   * @param dateTo yyyy-MM-dd
   */


  (0,_Users_smartcommunitylab_Documents_work_projects_dslab_playgo_mobile_playgo_mobile_node_modules_babel_runtime_helpers_esm_createClass_js__WEBPACK_IMPORTED_MODULE_1__["default"])(ReportControllerService, [{
    key: "getCampaingPlacingByGameUsingGET",
    value: function getCampaingPlacingByGameUsingGET(args) {
      var campaignId = args.campaignId,
          page = args.page,
          size = args.size,
          sort = args.sort,
          dateFrom = args.dateFrom,
          dateTo = args.dateTo;
      return this.http.request('get', src_environments_environment__WEBPACK_IMPORTED_MODULE_2__.environment.serverUrl.api + "/playandgo/api/report/campaign/placing/game", {
        params: removeNullOrUndefined({
          campaignId: campaignId,
          page: page,
          size: size,
          sort: sort,
          dateFrom: dateFrom,
          dateTo: dateTo
        })
      });
    }
    /**
     * getCampaingPlacingByTransportStats
     *
     * @param campaignId campaignId
     * @param page Results page you want to retrieve (0..N)
     * @param size Number of records per page
     * @param metric metric
     * @param sort Sorting option: field,[asc,desc]
     * @param mean mean
     * @param dateFrom yyyy-MM-dd
     * @param dateTo yyyy-MM-dd
     */

  }, {
    key: "getCampaingPlacingByTransportStatsUsingGET",
    value: function getCampaingPlacingByTransportStatsUsingGET(args) {
      var campaignId = args.campaignId,
          page = args.page,
          size = args.size,
          metric = args.metric,
          sort = args.sort,
          mean = args.mean,
          dateFrom = args.dateFrom,
          dateTo = args.dateTo;
      return this.http.request('get', src_environments_environment__WEBPACK_IMPORTED_MODULE_2__.environment.serverUrl.api + "/playandgo/api/report/campaign/placing/transport", {
        params: removeNullOrUndefined({
          campaignId: campaignId,
          page: page,
          size: size,
          sort: sort,
          metric: metric,
          mean: mean,
          dateFrom: dateFrom,
          dateTo: dateTo
        })
      });
    }
    /**
     * getPlayerCampaingPlacingByGame
     *
     * @param campaignId campaignId
     * @param playerId playerId
     * @param dateFrom yyyy-MM-dd
     * @param dateTo yyyy-MM-dd
     */

  }, {
    key: "getPlayerCampaingPlacingByGameUsingGET",
    value: function getPlayerCampaingPlacingByGameUsingGET(args) {
      var campaignId = args.campaignId,
          playerId = args.playerId,
          dateFrom = args.dateFrom,
          dateTo = args.dateTo;
      return this.http.request('get', src_environments_environment__WEBPACK_IMPORTED_MODULE_2__.environment.serverUrl.api + "/playandgo/api/report/campaign/placing/player/game", {
        params: removeNullOrUndefined({
          campaignId: campaignId,
          playerId: playerId,
          dateFrom: dateFrom,
          dateTo: dateTo
        })
      });
    }
    /**
     * getPlayerCampaingPlacingByTransportMode
     *
     * @param campaignId campaignId
     * @param playerId playerId
     * @param metric metric
     * @param mean mean
     * @param dateFrom yyyy-MM-dd
     * @param dateTo yyyy-MM-dd
     */

  }, {
    key: "getPlayerCampaingPlacingByTransportModeUsingGET",
    value: function getPlayerCampaingPlacingByTransportModeUsingGET(args) {
      var campaignId = args.campaignId,
          playerId = args.playerId,
          metric = args.metric,
          mean = args.mean,
          dateFrom = args.dateFrom,
          dateTo = args.dateTo;
      return this.http.request('get', src_environments_environment__WEBPACK_IMPORTED_MODULE_2__.environment.serverUrl.api + "/playandgo/api/report/campaign/placing/player/transport", {
        params: removeNullOrUndefined({
          campaignId: campaignId,
          playerId: playerId,
          metric: metric,
          mean: mean,
          dateFrom: dateFrom,
          dateTo: dateTo
        })
      });
    }
    /**
     * getPlayerGameStats
     *
     * @param campaignId campaignId
     * @param playerId playerId
     * @param groupMode groupMode
     * @param dateFrom yyyy-MM-dd
     * @param dateTo yyyy-MM-dd
     */

  }, {
    key: "getPlayerGameStatsUsingGET1",
    value: function getPlayerGameStatsUsingGET1(args) {
      var campaignId = args.campaignId,
          playerId = args.playerId,
          groupMode = args.groupMode,
          dateFrom = args.dateFrom,
          dateTo = args.dateTo;
      return this.http.request('get', src_environments_environment__WEBPACK_IMPORTED_MODULE_2__.environment.serverUrl.api + "/playandgo/api/report/player/game/stats", {
        params: removeNullOrUndefined({
          campaignId: campaignId,
          playerId: playerId,
          groupMode: groupMode,
          dateFrom: dateFrom,
          dateTo: dateTo
        })
      });
    }
    /**
     * getPlayerStatus
     *
     */

  }, {
    key: "getPlayerStatusUsingGET",
    value: function getPlayerStatusUsingGET() {
      return this.http.request('get', src_environments_environment__WEBPACK_IMPORTED_MODULE_2__.environment.serverUrl.api + "/playandgo/api/report/player/status", {});
    }
    /**
     * getPlayerTransportRecord
     *
     * @param campaignId campaignId
     * @param playerId playerId
     * @param metric metric
     * @param groupMode groupMode
     * @param mean mean
     */

  }, {
    key: "getPlayerTransportRecordUsingGET",
    value: function getPlayerTransportRecordUsingGET(args) {
      var campaignId = args.campaignId,
          playerId = args.playerId,
          metric = args.metric,
          groupMode = args.groupMode,
          mean = args.mean;
      return this.http.request('get', src_environments_environment__WEBPACK_IMPORTED_MODULE_2__.environment.serverUrl.api + "/playandgo/api/report/player/transport/record", {
        params: removeNullOrUndefined({
          campaignId: campaignId,
          playerId: playerId,
          metric: metric,
          groupMode: groupMode,
          mean: mean
        })
      });
    }
    /**
     * getPlayerTransportStatsGroupByMean
     *
     * @param campaignId campaignId
     * @param playerId playerId
     * @param metric metric
     * @param dateFrom yyyy-MM-dd
     * @param dateTo yyyy-MM-dd
     */

  }, {
    key: "getPlayerTransportStatsGroupByMeanUsingGET",
    value: function getPlayerTransportStatsGroupByMeanUsingGET(args) {
      var campaignId = args.campaignId,
          playerId = args.playerId,
          metric = args.metric,
          dateFrom = args.dateFrom,
          dateTo = args.dateTo;
      return this.http.request('get', src_environments_environment__WEBPACK_IMPORTED_MODULE_2__.environment.serverUrl.api + "/playandgo/api/report/player/transport/stats/mean", {
        params: removeNullOrUndefined({
          campaignId: campaignId,
          playerId: playerId,
          metric: metric,
          dateFrom: dateFrom,
          dateTo: dateTo
        })
      });
    }
    /**
     * getPlayerTransportStats
     *
     * @param campaignId campaignId
     * @param playerId playerId
     * @param metric metric
     * @param groupMode groupMode
     * @param mean mean
     * @param dateFrom yyyy-MM-dd
     * @param dateTo yyyy-MM-dd
     */

  }, {
    key: "getPlayerTransportStatsUsingGET",
    value: function getPlayerTransportStatsUsingGET(args) {
      var campaignId = args.campaignId,
          playerId = args.playerId,
          metric = args.metric,
          groupMode = args.groupMode,
          mean = args.mean,
          dateFrom = args.dateFrom,
          dateTo = args.dateTo;
      return this.http.request('get', src_environments_environment__WEBPACK_IMPORTED_MODULE_2__.environment.serverUrl.api + "/playandgo/api/report/player/transport/stats", {
        params: removeNullOrUndefined({
          campaignId: campaignId,
          playerId: playerId,
          metric: metric,
          groupMode: groupMode,
          mean: mean,
          dateFrom: dateFrom,
          dateTo: dateTo
        })
      });
    }
  }]);

  return ReportControllerService;
}();

ReportControllerService.ɵfac = function ReportControllerService_Factory(t) {
  return new (t || ReportControllerService)(_angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵinject"](_angular_common_http__WEBPACK_IMPORTED_MODULE_4__.HttpClient));
};

ReportControllerService.ɵprov = /*@__PURE__*/_angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵdefineInjectable"]({
  token: ReportControllerService,
  factory: ReportControllerService.ɵfac,
  providedIn: 'root'
});

function removeNullOrUndefined(obj) {
  var newObj = {};
  Object.keys(obj).forEach(function (key) {
    if (obj[key] != null) {
      newObj[key] = obj[key];
    }
  });
  return newObj;
}

/***/ }),

/***/ 21236:
/*!*******************************************************************************!*\
  !*** ./src/app/core/api/generated/controllers/territoryController.service.ts ***!
  \*******************************************************************************/
/***/ (function(__unused_webpack_module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "TerritoryControllerService": function() { return /* binding */ TerritoryControllerService; }
/* harmony export */ });
/* harmony import */ var _Users_smartcommunitylab_Documents_work_projects_dslab_playgo_mobile_playgo_mobile_node_modules_babel_runtime_helpers_esm_classCallCheck_js__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./node_modules/@babel/runtime/helpers/esm/classCallCheck.js */ 78069);
/* harmony import */ var _Users_smartcommunitylab_Documents_work_projects_dslab_playgo_mobile_playgo_mobile_node_modules_babel_runtime_helpers_esm_createClass_js__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ./node_modules/@babel/runtime/helpers/esm/createClass.js */ 48047);
/* harmony import */ var src_environments_environment__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! src/environments/environment */ 92340);
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @angular/core */ 3184);
/* harmony import */ var _angular_common_http__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! @angular/common/http */ 28784);



/**
 * Play&Go Project
 * No description provided (generated by Swagger Codegen https://github.com/swagger-api/swagger-codegen)
 *
 * OpenAPI spec version: 2.0
 * Contact: info@smartcommunitylab.it
 *
 * NOTE: This class is auto generated by the swagger code generator program.
 * https://github.com/swagger-api/swagger-codegen.git
 * Do not edit the class manually.
 */



var TerritoryControllerService = /*#__PURE__*/function () {
  function TerritoryControllerService(http) {
    (0,_Users_smartcommunitylab_Documents_work_projects_dslab_playgo_mobile_playgo_mobile_node_modules_babel_runtime_helpers_esm_classCallCheck_js__WEBPACK_IMPORTED_MODULE_0__["default"])(this, TerritoryControllerService);

    this.http = http;
  }
  /**
   * deleteTerritory
   *
   * @param territoryId territoryId
   */


  (0,_Users_smartcommunitylab_Documents_work_projects_dslab_playgo_mobile_playgo_mobile_node_modules_babel_runtime_helpers_esm_createClass_js__WEBPACK_IMPORTED_MODULE_1__["default"])(TerritoryControllerService, [{
    key: "deleteTerritoryUsingDELETE",
    value: function deleteTerritoryUsingDELETE(territoryId) {
      return this.http.request('delete', src_environments_environment__WEBPACK_IMPORTED_MODULE_2__.environment.serverUrl.api + "/playandgo/api/territory/".concat(encodeURIComponent(String(territoryId))), {});
    }
    /**
     * getTerritories
     *
     */

  }, {
    key: "getTerritoriesUsingGET",
    value: function getTerritoriesUsingGET() {
      return this.http.request('get', src_environments_environment__WEBPACK_IMPORTED_MODULE_2__.environment.serverUrl.api + "/playandgo/api/territory", {});
    }
    /**
     * getTerritory
     *
     * @param territoryId territoryId
     */

  }, {
    key: "getTerritoryUsingGET",
    value: function getTerritoryUsingGET(territoryId) {
      return this.http.request('get', src_environments_environment__WEBPACK_IMPORTED_MODULE_2__.environment.serverUrl.api + "/playandgo/api/territory/".concat(encodeURIComponent(String(territoryId))), {});
    }
    /**
     * saveTerritory
     *
     * @param body
     */

  }, {
    key: "saveTerritoryUsingPOST",
    value: function saveTerritoryUsingPOST(body) {
      return this.http.request('post', src_environments_environment__WEBPACK_IMPORTED_MODULE_2__.environment.serverUrl.api + "/playandgo/api/territory", {
        body: body
      });
    }
    /**
     * updateTerritory
     *
     * @param body
     */

  }, {
    key: "updateTerritoryUsingPUT",
    value: function updateTerritoryUsingPUT(body) {
      return this.http.request('put', src_environments_environment__WEBPACK_IMPORTED_MODULE_2__.environment.serverUrl.api + "/playandgo/api/territory", {
        body: body
      });
    }
  }]);

  return TerritoryControllerService;
}();

TerritoryControllerService.ɵfac = function TerritoryControllerService_Factory(t) {
  return new (t || TerritoryControllerService)(_angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵinject"](_angular_common_http__WEBPACK_IMPORTED_MODULE_4__.HttpClient));
};

TerritoryControllerService.ɵprov = /*@__PURE__*/_angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵdefineInjectable"]({
  token: TerritoryControllerService,
  factory: TerritoryControllerService.ɵfac,
  providedIn: 'root'
});

function removeNullOrUndefined(obj) {
  var newObj = {};
  Object.keys(obj).forEach(function (key) {
    if (obj[key] != null) {
      newObj[key] = obj[key];
    }
  });
  return newObj;
}

/***/ }),

/***/ 31265:
/*!*************************************************!*\
  !*** ./src/app/core/auth/auth-guard.service.ts ***!
  \*************************************************/
/***/ (function(__unused_webpack_module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "AuthGuardService": function() { return /* binding */ AuthGuardService; }
/* harmony export */ });
/* harmony import */ var _Users_smartcommunitylab_Documents_work_projects_dslab_playgo_mobile_playgo_mobile_node_modules_babel_runtime_helpers_esm_classCallCheck_js__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./node_modules/@babel/runtime/helpers/esm/classCallCheck.js */ 78069);
/* harmony import */ var _Users_smartcommunitylab_Documents_work_projects_dslab_playgo_mobile_playgo_mobile_node_modules_babel_runtime_helpers_esm_createClass_js__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ./node_modules/@babel/runtime/helpers/esm/createClass.js */ 48047);
/* harmony import */ var rxjs_operators__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! rxjs/operators */ 19337);
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! @angular/core */ 3184);
/* harmony import */ var _auth_service__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! ./auth.service */ 88951);
/* harmony import */ var _shared_services_user_service__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! ../shared/services/user.service */ 50749);
/* harmony import */ var _ionic_angular__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! @ionic/angular */ 93819);







var AuthGuardService = /*#__PURE__*/function () {
  function AuthGuardService(authService, userService, navCtrl) {
    (0,_Users_smartcommunitylab_Documents_work_projects_dslab_playgo_mobile_playgo_mobile_node_modules_babel_runtime_helpers_esm_classCallCheck_js__WEBPACK_IMPORTED_MODULE_0__["default"])(this, AuthGuardService);

    this.authService = authService;
    this.userService = userService;
    this.navCtrl = navCtrl;
  }

  (0,_Users_smartcommunitylab_Documents_work_projects_dslab_playgo_mobile_playgo_mobile_node_modules_babel_runtime_helpers_esm_createClass_js__WEBPACK_IMPORTED_MODULE_1__["default"])(AuthGuardService, [{
    key: "canActivate",
    value: function canActivate(route, state) {
      var _this = this;

      return this.authService.isAuthenticated$.pipe((0,rxjs_operators__WEBPACK_IMPORTED_MODULE_4__.tap)(function (isAuthenticated) {
        if (!isAuthenticated) {
          _this.authService.logout();
        }

        if (isAuthenticated) {
          _this.userService.isUserRegistered().then(function (isRegistered) {
            if (isRegistered === false) {
              _this.navCtrl.navigateRoot('/pages/registration');
            }
          });
        }
      }));
    }
  }]);

  return AuthGuardService;
}();

AuthGuardService.ɵfac = function AuthGuardService_Factory(t) {
  return new (t || AuthGuardService)(_angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵinject"](_auth_service__WEBPACK_IMPORTED_MODULE_2__.AuthService), _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵinject"](_shared_services_user_service__WEBPACK_IMPORTED_MODULE_3__.UserService), _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵinject"](_ionic_angular__WEBPACK_IMPORTED_MODULE_6__.NavController));
};

AuthGuardService.ɵprov = /*@__PURE__*/_angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵdefineInjectable"]({
  token: AuthGuardService,
  factory: AuthGuardService.ɵfac,
  providedIn: 'root'
});

/***/ }),

/***/ 2026:
/*!***********************************************!*\
  !*** ./src/app/core/auth/auth.interceptor.ts ***!
  \***********************************************/
/***/ (function(__unused_webpack_module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "AuthInterceptor": function() { return /* binding */ AuthInterceptor; }
/* harmony export */ });
/* harmony import */ var _Users_smartcommunitylab_Documents_work_projects_dslab_playgo_mobile_playgo_mobile_node_modules_babel_runtime_helpers_esm_createForOfIteratorHelper_js__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./node_modules/@babel/runtime/helpers/esm/createForOfIteratorHelper.js */ 95106);
/* harmony import */ var _Users_smartcommunitylab_Documents_work_projects_dslab_playgo_mobile_playgo_mobile_node_modules_babel_runtime_helpers_esm_classCallCheck_js__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ./node_modules/@babel/runtime/helpers/esm/classCallCheck.js */ 78069);
/* harmony import */ var _Users_smartcommunitylab_Documents_work_projects_dslab_playgo_mobile_playgo_mobile_node_modules_babel_runtime_helpers_esm_createClass_js__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! ./node_modules/@babel/runtime/helpers/esm/createClass.js */ 48047);
/* harmony import */ var _angular_common_http__WEBPACK_IMPORTED_MODULE_9__ = __webpack_require__(/*! @angular/common/http */ 28784);
/* harmony import */ var rxjs__WEBPACK_IMPORTED_MODULE_10__ = __webpack_require__(/*! rxjs */ 25474);
/* harmony import */ var rxjs__WEBPACK_IMPORTED_MODULE_12__ = __webpack_require__(/*! rxjs */ 59346);
/* harmony import */ var rxjs_operators__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! rxjs/operators */ 59295);
/* harmony import */ var rxjs_operators__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! rxjs/operators */ 19337);
/* harmony import */ var rxjs_operators__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(/*! rxjs/operators */ 63853);
/* harmony import */ var rxjs_operators__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(/*! rxjs/operators */ 53158);
/* harmony import */ var rxjs_operators__WEBPACK_IMPORTED_MODULE_11__ = __webpack_require__(/*! rxjs/operators */ 32313);
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_13__ = __webpack_require__(/*! @angular/core */ 3184);
/* harmony import */ var _auth_service__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! ./auth.service */ 88951);
/* harmony import */ var _shared_services_spinner_service__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! ../shared/services/spinner.service */ 75309);









var AuthInterceptor = /*#__PURE__*/function () {
  function AuthInterceptor(authService, spinnerService) {
    (0,_Users_smartcommunitylab_Documents_work_projects_dslab_playgo_mobile_playgo_mobile_node_modules_babel_runtime_helpers_esm_classCallCheck_js__WEBPACK_IMPORTED_MODULE_1__["default"])(this, AuthInterceptor);

    this.authService = authService;
    this.spinnerService = spinnerService;
    this.sharedToken$ = this.authService.validToken$;
    this.urlsToNotUse = [];
  } // eslint-disable-next-line @typescript-eslint/ban-types


  (0,_Users_smartcommunitylab_Documents_work_projects_dslab_playgo_mobile_playgo_mobile_node_modules_babel_runtime_helpers_esm_createClass_js__WEBPACK_IMPORTED_MODULE_2__["default"])(AuthInterceptor, [{
    key: "intercept",
    value: function intercept(request, next) {
      if (!this.isValidRequestForInterceptor(request.url)) {
        return next.handle(request);
      }

      return this.handle(request, next);
    }
  }, {
    key: "handle",
    value: function handle(request, next) {
      var _this = this;

      return this.sharedToken$.pipe((0,rxjs_operators__WEBPACK_IMPORTED_MODULE_5__.take)(1), // timeout({ first: 5000 }),
      (0,rxjs_operators__WEBPACK_IMPORTED_MODULE_6__.tap)(function () {
        return _this.spinnerService.show();
      }), (0,rxjs_operators__WEBPACK_IMPORTED_MODULE_7__.concatMap)(function (token) {
        var requestWithToken = request.clone({
          // eslint-disable-next-line @typescript-eslint/naming-convention
          setHeaders: {
            // eslint-disable-next-line @typescript-eslint/naming-convention
            Authorization: "".concat(token.tokenType === 'bearer' ? 'Bearer' : token.tokenType, " ").concat(token.accessToken),
            // eslint-disable-next-line @typescript-eslint/naming-convention
            Accept: '*/*'
          }
        });
        return next.handle(requestWithToken).pipe((0,rxjs_operators__WEBPACK_IMPORTED_MODULE_8__.catchError)(function (error) {
          if (error instanceof _angular_common_http__WEBPACK_IMPORTED_MODULE_9__.HttpErrorResponse && error.status === 401) {
            return _this.handle401Error(requestWithToken, next);
          }

          return (0,rxjs__WEBPACK_IMPORTED_MODULE_10__.throwError)(function () {
            return error;
          });
        }));
      }), (0,rxjs_operators__WEBPACK_IMPORTED_MODULE_11__.finalize)(function () {
        _this.spinnerService.hide();
      }));
    }
  }, {
    key: "handle401Error",
    value: function handle401Error(request, next) {
      var _this2 = this;

      return (0,rxjs__WEBPACK_IMPORTED_MODULE_12__.from)(this.authService.forceRefreshToken()).pipe((0,rxjs_operators__WEBPACK_IMPORTED_MODULE_7__.concatMap)(function () {
        return _this2.sharedToken$.pipe((0,rxjs_operators__WEBPACK_IMPORTED_MODULE_5__.take)(1));
      }), (0,rxjs_operators__WEBPACK_IMPORTED_MODULE_7__.concatMap)(function (newToken) {
        return next.handle(_this2.changeToken(newToken.accessToken, request));
      }), (0,rxjs_operators__WEBPACK_IMPORTED_MODULE_8__.catchError)(function (err) {
        _this2.authService.logoutAfterAuthFailed();

        return (0,rxjs__WEBPACK_IMPORTED_MODULE_10__.throwError)(function () {
          return err;
        });
      }));
    }
  }, {
    key: "changeToken",
    value: function changeToken(accessToken, request) {
      return request.clone({
        headers: request.headers.set('Authorization', "Bearer ".concat(accessToken))
      });
    }
  }, {
    key: "isValidRequestForInterceptor",
    value: function isValidRequestForInterceptor(requestUrl) {
      if (requestUrl.indexOf('/userinfo') > 0) {
        return true;
      }

      var positionIndicator = 'playandgo/api/';
      var position = requestUrl.indexOf(positionIndicator);

      if (position > 0) {
        var destination = requestUrl.substr(position + positionIndicator.length);

        var _iterator = (0,_Users_smartcommunitylab_Documents_work_projects_dslab_playgo_mobile_playgo_mobile_node_modules_babel_runtime_helpers_esm_createForOfIteratorHelper_js__WEBPACK_IMPORTED_MODULE_0__["default"])(this.urlsToNotUse),
            _step;

        try {
          for (_iterator.s(); !(_step = _iterator.n()).done;) {
            var address = _step.value;

            if (new RegExp(address).test(destination)) {
              return false;
            }
          }
        } catch (err) {
          _iterator.e(err);
        } finally {
          _iterator.f();
        }

        return true;
      }

      return false;
    }
  }]);

  return AuthInterceptor;
}();

AuthInterceptor.ɵfac = function AuthInterceptor_Factory(t) {
  return new (t || AuthInterceptor)(_angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵinject"](_auth_service__WEBPACK_IMPORTED_MODULE_3__.AuthService), _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵinject"](_shared_services_spinner_service__WEBPACK_IMPORTED_MODULE_4__.SpinnerService));
};

AuthInterceptor.ɵprov = /*@__PURE__*/_angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵdefineInjectable"]({
  token: AuthInterceptor,
  factory: AuthInterceptor.ɵfac
});

/***/ }),

/***/ 26734:
/*!******************************************!*\
  !*** ./src/app/core/auth/auth.module.ts ***!
  \******************************************/
/***/ (function(__unused_webpack_module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "AuthModule": function() { return /* binding */ AuthModule; }
/* harmony export */ });
/* harmony import */ var _Users_smartcommunitylab_Documents_work_projects_dslab_playgo_mobile_playgo_mobile_node_modules_babel_runtime_helpers_esm_createClass_js__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./node_modules/@babel/runtime/helpers/esm/createClass.js */ 48047);
/* harmony import */ var _Users_smartcommunitylab_Documents_work_projects_dslab_playgo_mobile_playgo_mobile_node_modules_babel_runtime_helpers_esm_classCallCheck_js__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ./node_modules/@babel/runtime/helpers/esm/classCallCheck.js */ 78069);
/* harmony import */ var _ionic_angular__WEBPACK_IMPORTED_MODULE_11__ = __webpack_require__(/*! @ionic/angular */ 93819);
/* harmony import */ var _openid_appauth_built_storage__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @openid/appauth/built/storage */ 87432);
/* harmony import */ var _openid_appauth_built_storage__WEBPACK_IMPORTED_MODULE_2___default = /*#__PURE__*/__webpack_require__.n(_openid_appauth_built_storage__WEBPACK_IMPORTED_MODULE_2__);
/* harmony import */ var _openid_appauth_built_xhr__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @openid/appauth/built/xhr */ 60085);
/* harmony import */ var _openid_appauth_built_xhr__WEBPACK_IMPORTED_MODULE_3___default = /*#__PURE__*/__webpack_require__.n(_openid_appauth_built_xhr__WEBPACK_IMPORTED_MODULE_3__);
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_9__ = __webpack_require__(/*! @angular/core */ 3184);
/* harmony import */ var _angular_common__WEBPACK_IMPORTED_MODULE_12__ = __webpack_require__(/*! @angular/common */ 36362);
/* harmony import */ var ionic_appauth__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! ionic-appauth */ 77798);
/* harmony import */ var ionic_appauth_lib_capacitor__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! ionic-appauth/lib/capacitor */ 5638);
/* harmony import */ var _ng_http_service__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! ./ng-http.service */ 60753);
/* harmony import */ var _factories__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(/*! ./factories */ 21626);
/* harmony import */ var _angular_common_http__WEBPACK_IMPORTED_MODULE_10__ = __webpack_require__(/*! @angular/common/http */ 28784);
/* harmony import */ var _auth_interceptor__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(/*! ./auth.interceptor */ 2026);














var AuthModule = /*#__PURE__*/(0,_Users_smartcommunitylab_Documents_work_projects_dslab_playgo_mobile_playgo_mobile_node_modules_babel_runtime_helpers_esm_createClass_js__WEBPACK_IMPORTED_MODULE_0__["default"])(function AuthModule() {
  (0,_Users_smartcommunitylab_Documents_work_projects_dslab_playgo_mobile_playgo_mobile_node_modules_babel_runtime_helpers_esm_classCallCheck_js__WEBPACK_IMPORTED_MODULE_1__["default"])(this, AuthModule);
});

AuthModule.ɵfac = function AuthModule_Factory(t) {
  return new (t || AuthModule)();
};

AuthModule.ɵmod = /*@__PURE__*/_angular_core__WEBPACK_IMPORTED_MODULE_9__["ɵɵdefineNgModule"]({
  type: AuthModule
});
AuthModule.ɵinj = /*@__PURE__*/_angular_core__WEBPACK_IMPORTED_MODULE_9__["ɵɵdefineInjector"]({
  providers: [{
    provide: _angular_common_http__WEBPACK_IMPORTED_MODULE_10__.HTTP_INTERCEPTORS,
    useClass: _auth_interceptor__WEBPACK_IMPORTED_MODULE_8__.AuthInterceptor,
    multi: true
  }, {
    provide: _openid_appauth_built_storage__WEBPACK_IMPORTED_MODULE_2__.StorageBackend,
    useClass: ionic_appauth_lib_capacitor__WEBPACK_IMPORTED_MODULE_5__.CapacitorSecureStorage
  }, {
    provide: _openid_appauth_built_xhr__WEBPACK_IMPORTED_MODULE_3__.Requestor,
    useClass: _ng_http_service__WEBPACK_IMPORTED_MODULE_6__.NgHttpService
  }, {
    provide: ionic_appauth__WEBPACK_IMPORTED_MODULE_4__.Browser,
    useClass: ionic_appauth_lib_capacitor__WEBPACK_IMPORTED_MODULE_5__.CapacitorBrowser
  }, {
    provide: 'IonicAppAuthService',
    useFactory: _factories__WEBPACK_IMPORTED_MODULE_7__.authFactory,
    deps: [_ionic_angular__WEBPACK_IMPORTED_MODULE_11__.Platform, _angular_core__WEBPACK_IMPORTED_MODULE_9__.NgZone, _openid_appauth_built_xhr__WEBPACK_IMPORTED_MODULE_3__.Requestor, ionic_appauth__WEBPACK_IMPORTED_MODULE_4__.Browser, _openid_appauth_built_storage__WEBPACK_IMPORTED_MODULE_2__.StorageBackend]
  }],
  imports: [[_angular_common__WEBPACK_IMPORTED_MODULE_12__.CommonModule, _angular_common_http__WEBPACK_IMPORTED_MODULE_10__.HttpClientModule]]
});

(function () {
  (typeof ngJitMode === "undefined" || ngJitMode) && _angular_core__WEBPACK_IMPORTED_MODULE_9__["ɵɵsetNgModuleScope"](AuthModule, {
    imports: [_angular_common__WEBPACK_IMPORTED_MODULE_12__.CommonModule, _angular_common_http__WEBPACK_IMPORTED_MODULE_10__.HttpClientModule]
  });
})();

/***/ }),

/***/ 88951:
/*!*******************************************!*\
  !*** ./src/app/core/auth/auth.service.ts ***!
  \*******************************************/
/***/ (function(__unused_webpack_module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "AuthService": function() { return /* binding */ AuthService; }
/* harmony export */ });
/* harmony import */ var _Users_smartcommunitylab_Documents_work_projects_dslab_playgo_mobile_playgo_mobile_node_modules_babel_runtime_helpers_esm_classCallCheck_js__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./node_modules/@babel/runtime/helpers/esm/classCallCheck.js */ 78069);
/* harmony import */ var _Users_smartcommunitylab_Documents_work_projects_dslab_playgo_mobile_playgo_mobile_node_modules_babel_runtime_helpers_esm_createClass_js__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ./node_modules/@babel/runtime/helpers/esm/createClass.js */ 48047);
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_14__ = __webpack_require__(/*! tslib */ 34929);
/* harmony import */ var ionic_appauth__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! ionic-appauth */ 77798);
/* harmony import */ var rxjs__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(/*! rxjs */ 60116);
/* harmony import */ var rxjs__WEBPACK_IMPORTED_MODULE_9__ = __webpack_require__(/*! rxjs */ 50635);
/* harmony import */ var rxjs__WEBPACK_IMPORTED_MODULE_10__ = __webpack_require__(/*! rxjs */ 59295);
/* harmony import */ var rxjs__WEBPACK_IMPORTED_MODULE_11__ = __webpack_require__(/*! rxjs */ 89196);
/* harmony import */ var rxjs__WEBPACK_IMPORTED_MODULE_12__ = __webpack_require__(/*! rxjs */ 32673);
/* harmony import */ var rxjs__WEBPACK_IMPORTED_MODULE_13__ = __webpack_require__(/*! rxjs */ 80155);
/* harmony import */ var rxjs__WEBPACK_IMPORTED_MODULE_15__ = __webpack_require__(/*! rxjs */ 78611);
/* harmony import */ var src_environments_environment__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! src/environments/environment */ 92340);
/* harmony import */ var _shared_tracking_background_tracking_service__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! ../shared/tracking/background-tracking.service */ 29872);
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_16__ = __webpack_require__(/*! @angular/core */ 3184);
/* harmony import */ var _shared_services_alert_service__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! ../shared/services/alert.service */ 46407);
/* harmony import */ var _angular_router__WEBPACK_IMPORTED_MODULE_17__ = __webpack_require__(/*! @angular/router */ 52816);
/* harmony import */ var _ionic_angular__WEBPACK_IMPORTED_MODULE_18__ = __webpack_require__(/*! @ionic/angular */ 93819);
/* harmony import */ var _shared_services_local_storage_service__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! ../shared/services/local-storage.service */ 49397);
/* harmony import */ var _api_generated_controllers_playerController_service__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(/*! ../api/generated/controllers/playerController.service */ 60148);



function _regeneratorRuntime() { "use strict"; /*! regenerator-runtime -- Copyright (c) 2014-present, Facebook, Inc. -- license (MIT): https://github.com/facebook/regenerator/blob/main/LICENSE */ _regeneratorRuntime = function _regeneratorRuntime() { return exports; }; var exports = {}, Op = Object.prototype, hasOwn = Op.hasOwnProperty, $Symbol = "function" == typeof Symbol ? Symbol : {}, iteratorSymbol = $Symbol.iterator || "@@iterator", asyncIteratorSymbol = $Symbol.asyncIterator || "@@asyncIterator", toStringTagSymbol = $Symbol.toStringTag || "@@toStringTag"; function define(obj, key, value) { return Object.defineProperty(obj, key, { value: value, enumerable: !0, configurable: !0, writable: !0 }), obj[key]; } try { define({}, ""); } catch (err) { define = function define(obj, key, value) { return obj[key] = value; }; } function wrap(innerFn, outerFn, self, tryLocsList) { var protoGenerator = outerFn && outerFn.prototype instanceof Generator ? outerFn : Generator, generator = Object.create(protoGenerator.prototype), context = new Context(tryLocsList || []); return generator._invoke = function (innerFn, self, context) { var state = "suspendedStart"; return function (method, arg) { if ("executing" === state) throw new Error("Generator is already running"); if ("completed" === state) { if ("throw" === method) throw arg; return doneResult(); } for (context.method = method, context.arg = arg;;) { var delegate = context.delegate; if (delegate) { var delegateResult = maybeInvokeDelegate(delegate, context); if (delegateResult) { if (delegateResult === ContinueSentinel) continue; return delegateResult; } } if ("next" === context.method) context.sent = context._sent = context.arg;else if ("throw" === context.method) { if ("suspendedStart" === state) throw state = "completed", context.arg; context.dispatchException(context.arg); } else "return" === context.method && context.abrupt("return", context.arg); state = "executing"; var record = tryCatch(innerFn, self, context); if ("normal" === record.type) { if (state = context.done ? "completed" : "suspendedYield", record.arg === ContinueSentinel) continue; return { value: record.arg, done: context.done }; } "throw" === record.type && (state = "completed", context.method = "throw", context.arg = record.arg); } }; }(innerFn, self, context), generator; } function tryCatch(fn, obj, arg) { try { return { type: "normal", arg: fn.call(obj, arg) }; } catch (err) { return { type: "throw", arg: err }; } } exports.wrap = wrap; var ContinueSentinel = {}; function Generator() {} function GeneratorFunction() {} function GeneratorFunctionPrototype() {} var IteratorPrototype = {}; define(IteratorPrototype, iteratorSymbol, function () { return this; }); var getProto = Object.getPrototypeOf, NativeIteratorPrototype = getProto && getProto(getProto(values([]))); NativeIteratorPrototype && NativeIteratorPrototype !== Op && hasOwn.call(NativeIteratorPrototype, iteratorSymbol) && (IteratorPrototype = NativeIteratorPrototype); var Gp = GeneratorFunctionPrototype.prototype = Generator.prototype = Object.create(IteratorPrototype); function defineIteratorMethods(prototype) { ["next", "throw", "return"].forEach(function (method) { define(prototype, method, function (arg) { return this._invoke(method, arg); }); }); } function AsyncIterator(generator, PromiseImpl) { function invoke(method, arg, resolve, reject) { var record = tryCatch(generator[method], generator, arg); if ("throw" !== record.type) { var result = record.arg, value = result.value; return value && "object" == typeof value && hasOwn.call(value, "__await") ? PromiseImpl.resolve(value.__await).then(function (value) { invoke("next", value, resolve, reject); }, function (err) { invoke("throw", err, resolve, reject); }) : PromiseImpl.resolve(value).then(function (unwrapped) { result.value = unwrapped, resolve(result); }, function (error) { return invoke("throw", error, resolve, reject); }); } reject(record.arg); } var previousPromise; this._invoke = function (method, arg) { function callInvokeWithMethodAndArg() { return new PromiseImpl(function (resolve, reject) { invoke(method, arg, resolve, reject); }); } return previousPromise = previousPromise ? previousPromise.then(callInvokeWithMethodAndArg, callInvokeWithMethodAndArg) : callInvokeWithMethodAndArg(); }; } function maybeInvokeDelegate(delegate, context) { var method = delegate.iterator[context.method]; if (undefined === method) { if (context.delegate = null, "throw" === context.method) { if (delegate.iterator.return && (context.method = "return", context.arg = undefined, maybeInvokeDelegate(delegate, context), "throw" === context.method)) return ContinueSentinel; context.method = "throw", context.arg = new TypeError("The iterator does not provide a 'throw' method"); } return ContinueSentinel; } var record = tryCatch(method, delegate.iterator, context.arg); if ("throw" === record.type) return context.method = "throw", context.arg = record.arg, context.delegate = null, ContinueSentinel; var info = record.arg; return info ? info.done ? (context[delegate.resultName] = info.value, context.next = delegate.nextLoc, "return" !== context.method && (context.method = "next", context.arg = undefined), context.delegate = null, ContinueSentinel) : info : (context.method = "throw", context.arg = new TypeError("iterator result is not an object"), context.delegate = null, ContinueSentinel); } function pushTryEntry(locs) { var entry = { tryLoc: locs[0] }; 1 in locs && (entry.catchLoc = locs[1]), 2 in locs && (entry.finallyLoc = locs[2], entry.afterLoc = locs[3]), this.tryEntries.push(entry); } function resetTryEntry(entry) { var record = entry.completion || {}; record.type = "normal", delete record.arg, entry.completion = record; } function Context(tryLocsList) { this.tryEntries = [{ tryLoc: "root" }], tryLocsList.forEach(pushTryEntry, this), this.reset(!0); } function values(iterable) { if (iterable) { var iteratorMethod = iterable[iteratorSymbol]; if (iteratorMethod) return iteratorMethod.call(iterable); if ("function" == typeof iterable.next) return iterable; if (!isNaN(iterable.length)) { var i = -1, next = function next() { for (; ++i < iterable.length;) { if (hasOwn.call(iterable, i)) return next.value = iterable[i], next.done = !1, next; } return next.value = undefined, next.done = !0, next; }; return next.next = next; } } return { next: doneResult }; } function doneResult() { return { value: undefined, done: !0 }; } return GeneratorFunction.prototype = GeneratorFunctionPrototype, define(Gp, "constructor", GeneratorFunctionPrototype), define(GeneratorFunctionPrototype, "constructor", GeneratorFunction), GeneratorFunction.displayName = define(GeneratorFunctionPrototype, toStringTagSymbol, "GeneratorFunction"), exports.isGeneratorFunction = function (genFun) { var ctor = "function" == typeof genFun && genFun.constructor; return !!ctor && (ctor === GeneratorFunction || "GeneratorFunction" === (ctor.displayName || ctor.name)); }, exports.mark = function (genFun) { return Object.setPrototypeOf ? Object.setPrototypeOf(genFun, GeneratorFunctionPrototype) : (genFun.__proto__ = GeneratorFunctionPrototype, define(genFun, toStringTagSymbol, "GeneratorFunction")), genFun.prototype = Object.create(Gp), genFun; }, exports.awrap = function (arg) { return { __await: arg }; }, defineIteratorMethods(AsyncIterator.prototype), define(AsyncIterator.prototype, asyncIteratorSymbol, function () { return this; }), exports.AsyncIterator = AsyncIterator, exports.async = function (innerFn, outerFn, self, tryLocsList, PromiseImpl) { void 0 === PromiseImpl && (PromiseImpl = Promise); var iter = new AsyncIterator(wrap(innerFn, outerFn, self, tryLocsList), PromiseImpl); return exports.isGeneratorFunction(outerFn) ? iter : iter.next().then(function (result) { return result.done ? result.value : iter.next(); }); }, defineIteratorMethods(Gp), define(Gp, toStringTagSymbol, "Generator"), define(Gp, iteratorSymbol, function () { return this; }), define(Gp, "toString", function () { return "[object Generator]"; }), exports.keys = function (object) { var keys = []; for (var key in object) { keys.push(key); } return keys.reverse(), function next() { for (; keys.length;) { var key = keys.pop(); if (key in object) return next.value = key, next.done = !1, next; } return next.done = !0, next; }; }, exports.values = values, Context.prototype = { constructor: Context, reset: function reset(skipTempReset) { if (this.prev = 0, this.next = 0, this.sent = this._sent = undefined, this.done = !1, this.delegate = null, this.method = "next", this.arg = undefined, this.tryEntries.forEach(resetTryEntry), !skipTempReset) for (var name in this) { "t" === name.charAt(0) && hasOwn.call(this, name) && !isNaN(+name.slice(1)) && (this[name] = undefined); } }, stop: function stop() { this.done = !0; var rootRecord = this.tryEntries[0].completion; if ("throw" === rootRecord.type) throw rootRecord.arg; return this.rval; }, dispatchException: function dispatchException(exception) { if (this.done) throw exception; var context = this; function handle(loc, caught) { return record.type = "throw", record.arg = exception, context.next = loc, caught && (context.method = "next", context.arg = undefined), !!caught; } for (var i = this.tryEntries.length - 1; i >= 0; --i) { var entry = this.tryEntries[i], record = entry.completion; if ("root" === entry.tryLoc) return handle("end"); if (entry.tryLoc <= this.prev) { var hasCatch = hasOwn.call(entry, "catchLoc"), hasFinally = hasOwn.call(entry, "finallyLoc"); if (hasCatch && hasFinally) { if (this.prev < entry.catchLoc) return handle(entry.catchLoc, !0); if (this.prev < entry.finallyLoc) return handle(entry.finallyLoc); } else if (hasCatch) { if (this.prev < entry.catchLoc) return handle(entry.catchLoc, !0); } else { if (!hasFinally) throw new Error("try statement without catch or finally"); if (this.prev < entry.finallyLoc) return handle(entry.finallyLoc); } } } }, abrupt: function abrupt(type, arg) { for (var i = this.tryEntries.length - 1; i >= 0; --i) { var entry = this.tryEntries[i]; if (entry.tryLoc <= this.prev && hasOwn.call(entry, "finallyLoc") && this.prev < entry.finallyLoc) { var finallyEntry = entry; break; } } finallyEntry && ("break" === type || "continue" === type) && finallyEntry.tryLoc <= arg && arg <= finallyEntry.finallyLoc && (finallyEntry = null); var record = finallyEntry ? finallyEntry.completion : {}; return record.type = type, record.arg = arg, finallyEntry ? (this.method = "next", this.next = finallyEntry.finallyLoc, ContinueSentinel) : this.complete(record); }, complete: function complete(record, afterLoc) { if ("throw" === record.type) throw record.arg; return "break" === record.type || "continue" === record.type ? this.next = record.arg : "return" === record.type ? (this.rval = this.arg = record.arg, this.method = "return", this.next = "end") : "normal" === record.type && afterLoc && (this.next = afterLoc), ContinueSentinel; }, finish: function finish(finallyLoc) { for (var i = this.tryEntries.length - 1; i >= 0; --i) { var entry = this.tryEntries[i]; if (entry.finallyLoc === finallyLoc) return this.complete(entry.completion, entry.afterLoc), resetTryEntry(entry), ContinueSentinel; } }, catch: function _catch(tryLoc) { for (var i = this.tryEntries.length - 1; i >= 0; --i) { var entry = this.tryEntries[i]; if (entry.tryLoc === tryLoc) { var record = entry.completion; if ("throw" === record.type) { var thrown = record.arg; resetTryEntry(entry); } return thrown; } } throw new Error("illegal catch attempt"); }, delegateYield: function delegateYield(iterable, resultName, nextLoc) { return this.delegate = { iterator: values(iterable), resultName: resultName, nextLoc: nextLoc }, "next" === this.method && (this.arg = undefined), ContinueSentinel; } }, exports; }













/**
 * Wrapper around ionic-appauth service.
 */

var AuthService = /*#__PURE__*/function () {
  function AuthService(ionicAppAuthService, alertService, router, navController, localStorageService, playerControllerService, injector) {
    var _this = this;

    (0,_Users_smartcommunitylab_Documents_work_projects_dslab_playgo_mobile_playgo_mobile_node_modules_babel_runtime_helpers_esm_classCallCheck_js__WEBPACK_IMPORTED_MODULE_0__["default"])(this, AuthService);

    this.ionicAppAuthService = ionicAppAuthService;
    this.alertService = alertService;
    this.router = router;
    this.navController = navController;
    this.localStorageService = localStorageService;
    this.playerControllerService = playerControllerService;
    this.injector = injector;
    this.isInitComplete$ = this.ionicAppAuthService.initComplete$.pipe((0,rxjs__WEBPACK_IMPORTED_MODULE_8__.filter)(Boolean), (0,rxjs__WEBPACK_IMPORTED_MODULE_9__.map)(function () {
      return undefined;
    }), (0,rxjs__WEBPACK_IMPORTED_MODULE_10__.take)(1), (0,rxjs__WEBPACK_IMPORTED_MODULE_11__.shareReplay)(1));
    this.isAuthenticated$ = this.isInitComplete$.pipe((0,rxjs__WEBPACK_IMPORTED_MODULE_12__.switchMap)(function () {
      return _this.ionicAppAuthService.isAuthenticated$;
    }), (0,rxjs__WEBPACK_IMPORTED_MODULE_11__.shareReplay)(1));
    this.validToken$ = this.ionicAppAuthService.token$.pipe((0,rxjs__WEBPACK_IMPORTED_MODULE_8__.filter)(Boolean), (0,rxjs__WEBPACK_IMPORTED_MODULE_11__.shareReplay)(1));
    this.isReadyForApi$ = this.validToken$.pipe((0,rxjs__WEBPACK_IMPORTED_MODULE_9__.map)(function () {
      return undefined;
    }), (0,rxjs__WEBPACK_IMPORTED_MODULE_13__.first)(), (0,rxjs__WEBPACK_IMPORTED_MODULE_11__.shareReplay)(1));
    this.refreshTokenCallPromise = null;
  }

  (0,_Users_smartcommunitylab_Documents_work_projects_dslab_playgo_mobile_playgo_mobile_node_modules_babel_runtime_helpers_esm_createClass_js__WEBPACK_IMPORTED_MODULE_1__["default"])(AuthService, [{
    key: "init",
    value: function init() {
      return (0,tslib__WEBPACK_IMPORTED_MODULE_14__.__awaiter)(this, void 0, void 0, /*#__PURE__*/_regeneratorRuntime().mark(function _callee() {
        var _this2 = this;

        return _regeneratorRuntime().wrap(function _callee$(_context) {
          while (1) {
            switch (_context.prev = _context.next) {
              case 0:
                _context.next = 2;
                return this.ionicAppAuthService.init();

              case 2:
                this.ionicAppAuthService.events$.subscribe(function (action) {
                  if (action.action === ionic_appauth__WEBPACK_IMPORTED_MODULE_2__.AuthActions.SignInSuccess) {
                    _this2.onSignInSuccess(action);
                  }

                  if (action.action === ionic_appauth__WEBPACK_IMPORTED_MODULE_2__.AuthActions.SignOutSuccess) {
                    _this2.postLogoutCleanup();
                  }

                  if (action.action === ionic_appauth__WEBPACK_IMPORTED_MODULE_2__.AuthActions.SignOutFailed) {
                    console.error('sign out failed', action); // there is nothing else to do...

                    _this2.postLogoutCleanup();
                  }

                  if (action.action === ionic_appauth__WEBPACK_IMPORTED_MODULE_2__.AuthActions.SignInFailed || action.action === ionic_appauth__WEBPACK_IMPORTED_MODULE_2__.AuthActions.RefreshFailed) {
                    console.error('auth error', action);

                    _this2.logoutAfterAuthFailed();
                  }

                  if (action.action === ionic_appauth__WEBPACK_IMPORTED_MODULE_2__.AuthActions.RefreshSuccess || action.action === ionic_appauth__WEBPACK_IMPORTED_MODULE_2__.AuthActions.RefreshFailed) {
                    _this2.refreshTokenCallPromise = null;
                  }
                });

              case 3:
              case "end":
                return _context.stop();
            }
          }
        }, _callee, this);
      }));
    }
    /**
     * Waits for the first token available, but later it will return latest token immediately
     *
     * This api is just promise version of authService.validToken$
     * */

  }, {
    key: "getToken",
    value: function getToken() {
      return (0,tslib__WEBPACK_IMPORTED_MODULE_14__.__awaiter)(this, void 0, void 0, /*#__PURE__*/_regeneratorRuntime().mark(function _callee2() {
        return _regeneratorRuntime().wrap(function _callee2$(_context2) {
          while (1) {
            switch (_context2.prev = _context2.next) {
              case 0:
                _context2.next = 2;
                return (0,rxjs__WEBPACK_IMPORTED_MODULE_15__.lastValueFrom)(this.validToken$.pipe((0,rxjs__WEBPACK_IMPORTED_MODULE_10__.take)(1)));

              case 2:
                return _context2.abrupt("return", _context2.sent);

              case 3:
              case "end":
                return _context2.stop();
            }
          }
        }, _callee2, this);
      }));
    }
  }, {
    key: "login",
    value: function login(provider) {
      return (0,tslib__WEBPACK_IMPORTED_MODULE_14__.__awaiter)(this, void 0, void 0, /*#__PURE__*/_regeneratorRuntime().mark(function _callee3() {
        return _regeneratorRuntime().wrap(function _callee3$(_context3) {
          while (1) {
            switch (_context3.prev = _context3.next) {
              case 0:
                _context3.next = 2;
                return this.ionicAppAuthService.signIn(provider ? this.getExtraIdp(provider) : undefined);

              case 2:
              case "end":
                return _context3.stop();
            }
          }
        }, _callee3, this);
      }));
    }
  }, {
    key: "getExtraIdp",
    value: function getExtraIdp(provider) {
      if (src_environments_environment__WEBPACK_IMPORTED_MODULE_3__.environment.idp_hint[provider]) {
        // eslint-disable-next-line @typescript-eslint/naming-convention
        return {
          idp_hint: src_environments_environment__WEBPACK_IMPORTED_MODULE_3__.environment.idp_hint[provider]
        };
      }

      return undefined;
    }
  }, {
    key: "logout",
    value: function logout() {
      return (0,tslib__WEBPACK_IMPORTED_MODULE_14__.__awaiter)(this, void 0, void 0, /*#__PURE__*/_regeneratorRuntime().mark(function _callee4() {
        return _regeneratorRuntime().wrap(function _callee4$(_context4) {
          while (1) {
            switch (_context4.prev = _context4.next) {
              case 0:
                _context4.prev = 0;
                _context4.next = 3;
                return this.ionicAppAuthService.signOut();

              case 3:
                _context4.next = 9;
                break;

              case 5:
                _context4.prev = 5;
                _context4.t0 = _context4["catch"](0);
                console.log('sign out failed - probably no one is logged in', _context4.t0);
                this.postLogoutCleanup();

              case 9:
              case "end":
                return _context4.stop();
            }
          }
        }, _callee4, this, [[0, 5]]);
      }));
    }
  }, {
    key: "logoutAfterAuthFailed",
    value: function logoutAfterAuthFailed() {
      return (0,tslib__WEBPACK_IMPORTED_MODULE_14__.__awaiter)(this, void 0, void 0, /*#__PURE__*/_regeneratorRuntime().mark(function _callee5() {
        return _regeneratorRuntime().wrap(function _callee5$(_context5) {
          while (1) {
            switch (_context5.prev = _context5.next) {
              case 0:
                alert('You are not longer logged in, please log in again.');
                _context5.prev = 1;
                _context5.next = 4;
                return this.ionicAppAuthService.signOut();

              case 4:
                _context5.prev = 4;
                // redirect should be handled from global event subscription,
                // but if not, we do it manually
                this.postLogoutCleanup();
                return _context5.finish(4);

              case 7:
              case "end":
                return _context5.stop();
            }
          }
        }, _callee5, this, [[1,, 4, 7]]);
      }));
    }
  }, {
    key: "postLogoutCleanup",
    value: function postLogoutCleanup() {
      return (0,tslib__WEBPACK_IMPORTED_MODULE_14__.__awaiter)(this, void 0, void 0, /*#__PURE__*/_regeneratorRuntime().mark(function _callee6() {
        var backgroundTrackingService;
        return _regeneratorRuntime().wrap(function _callee6$(_context6) {
          while (1) {
            switch (_context6.prev = _context6.next) {
              case 0:
                _context6.next = 2;
                return this.localStorageService.clearAll();

              case 2:
                // clear stored data of plugins
                backgroundTrackingService = this.injector.get(_shared_tracking_background_tracking_service__WEBPACK_IMPORTED_MODULE_4__.BackgroundTrackingService);

                if (!backgroundTrackingService) {
                  _context6.next = 6;
                  break;
                }

                _context6.next = 6;
                return backgroundTrackingService.clearPluginData();

              case 6:
                // clear local state stored in variables of all services. By doing
                // hard page reload.
                location.replace('login');

              case 7:
              case "end":
                return _context6.stop();
            }
          }
        }, _callee6, this);
      }));
    }
    /**
     * Uses one time refresh token, to get a new token from aac.
     *
     * Function guarantees that the token will be asked only once, even if there are multiple calls.
     */

  }, {
    key: "forceRefreshToken",
    value: function forceRefreshToken() {
      if (!this.refreshTokenCallPromise) {
        this.refreshTokenCallPromise = this.ionicAppAuthService.refreshToken();
      }

      return this.refreshTokenCallPromise;
    }
    /** called from EndSessionPage */

  }, {
    key: "endSessionCallback",
    value: function endSessionCallback() {
      this.ionicAppAuthService.endSessionCallback();
      this.navController.navigateRoot('login');
    }
    /** called from AuthCallbackPage */

  }, {
    key: "authorizationCallback",
    value: function authorizationCallback() {
      return this.ionicAppAuthService.authorizationCallback(window.location.origin + this.router.url);
    }
  }, {
    key: "onSignInSuccess",
    value: function onSignInSuccess(action) {
      return (0,tslib__WEBPACK_IMPORTED_MODULE_14__.__awaiter)(this, void 0, void 0, /*#__PURE__*/_regeneratorRuntime().mark(function _callee7() {
        var userIsRegistered;
        return _regeneratorRuntime().wrap(function _callee7$(_context7) {
          while (1) {
            switch (_context7.prev = _context7.next) {
              case 0:
                _context7.next = 2;
                return this.isUserRegistered();

              case 2:
                userIsRegistered = _context7.sent;

                if (userIsRegistered === true) {
                  this.alertService.showToast({
                    messageTranslateKey: 'login.welcome'
                  });
                  this.navController.navigateRoot('/pages/tabs/home');
                } else if (userIsRegistered === false) {
                  this.navController.navigateRoot('/pages/registration');
                } else {
                  // api call failed... but token should be there
                  console.error('failed to check if user is registered after log in!', action);
                  this.navController.navigateRoot('login');
                }

              case 4:
              case "end":
                return _context7.stop();
            }
          }
        }, _callee7, this);
      }));
    }
    /**
     * TODO: this could be included in the token response.
     *
     * We cannot use user service, because of the circular dependency.
     * */

  }, {
    key: "isUserRegistered",
    value: function isUserRegistered() {
      return (0,tslib__WEBPACK_IMPORTED_MODULE_14__.__awaiter)(this, void 0, void 0, /*#__PURE__*/_regeneratorRuntime().mark(function _callee8() {
        var user;
        return _regeneratorRuntime().wrap(function _callee8$(_context8) {
          while (1) {
            switch (_context8.prev = _context8.next) {
              case 0:
                _context8.prev = 0;
                _context8.next = 3;
                return this.playerControllerService.getProfileUsingGET().toPromise();

              case 3:
                user = _context8.sent;

                if (!user) {
                  _context8.next = 8;
                  break;
                }

                return _context8.abrupt("return", true);

              case 8:
                return _context8.abrupt("return", false);

              case 9:
                _context8.next = 15;
                break;

              case 11:
                _context8.prev = 11;
                _context8.t0 = _context8["catch"](0);
                // toto check local storage
                console.warn(_context8.t0);
                return _context8.abrupt("return", null);

              case 15:
              case "end":
                return _context8.stop();
            }
          }
        }, _callee8, this, [[0, 11]]);
      }));
    }
  }]);

  return AuthService;
}();

AuthService.ɵfac = function AuthService_Factory(t) {
  return new (t || AuthService)(_angular_core__WEBPACK_IMPORTED_MODULE_16__["ɵɵinject"]('IonicAppAuthService'), _angular_core__WEBPACK_IMPORTED_MODULE_16__["ɵɵinject"](_shared_services_alert_service__WEBPACK_IMPORTED_MODULE_5__.AlertService), _angular_core__WEBPACK_IMPORTED_MODULE_16__["ɵɵinject"](_angular_router__WEBPACK_IMPORTED_MODULE_17__.Router), _angular_core__WEBPACK_IMPORTED_MODULE_16__["ɵɵinject"](_ionic_angular__WEBPACK_IMPORTED_MODULE_18__.NavController), _angular_core__WEBPACK_IMPORTED_MODULE_16__["ɵɵinject"](_shared_services_local_storage_service__WEBPACK_IMPORTED_MODULE_6__.LocalStorageService), _angular_core__WEBPACK_IMPORTED_MODULE_16__["ɵɵinject"](_api_generated_controllers_playerController_service__WEBPACK_IMPORTED_MODULE_7__.PlayerControllerService), _angular_core__WEBPACK_IMPORTED_MODULE_16__["ɵɵinject"](_angular_core__WEBPACK_IMPORTED_MODULE_16__.Injector));
};

AuthService.ɵprov = /*@__PURE__*/_angular_core__WEBPACK_IMPORTED_MODULE_16__["ɵɵdefineInjectable"]({
  token: AuthService,
  factory: AuthService.ɵfac,
  providedIn: 'root'
});

/***/ }),

/***/ 28130:
/*!*****************************************************!*\
  !*** ./src/app/core/auth/factories/auth.factory.ts ***!
  \*****************************************************/
/***/ (function(__unused_webpack_module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "authFactory": function() { return /* binding */ authFactory; }
/* harmony export */ });
/* harmony import */ var ionic_appauth__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ionic-appauth */ 77798);
/* harmony import */ var _capacitor_app__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @capacitor/app */ 93253);
/* harmony import */ var src_environments_environment__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! src/environments/environment */ 92340);



var authFactory = function authFactory(platform, ngZone, requestor, browser, storage) {
  var authService = new ionic_appauth__WEBPACK_IMPORTED_MODULE_0__.AuthService(browser, storage, requestor);
  authService.authConfig = src_environments_environment__WEBPACK_IMPORTED_MODULE_2__.environment.authConfig;

  if (!platform.is('cordova')) {
    authService.authConfig.redirect_url = window.location.origin + '/auth/callback';
    authService.authConfig.end_session_redirect_url = window.location.origin + '/auth/endsession';
  }

  if (platform.is('capacitor')) {
    console.log('capacitor');
    _capacitor_app__WEBPACK_IMPORTED_MODULE_1__.App.addListener('appUrlOpen', function (data) {
      if (data.url !== undefined) {
        ngZone.run(function () {
          if (data.url.indexOf(authService.authConfig.redirect_url) === 0) {
            authService.authorizationCallback(data.url);
          } else {
            authService.endSessionCallback();
          }
        });
      }
    });
  }

  return authService;
};

/***/ }),

/***/ 21626:
/*!**********************************************!*\
  !*** ./src/app/core/auth/factories/index.ts ***!
  \**********************************************/
/***/ (function(__unused_webpack_module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "authFactory": function() { return /* reexport safe */ _auth_factory__WEBPACK_IMPORTED_MODULE_0__.authFactory; }
/* harmony export */ });
/* harmony import */ var _auth_factory__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./auth.factory */ 28130);


/***/ }),

/***/ 60753:
/*!**********************************************!*\
  !*** ./src/app/core/auth/ng-http.service.ts ***!
  \**********************************************/
/***/ (function(__unused_webpack_module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "NgHttpService": function() { return /* binding */ NgHttpService; }
/* harmony export */ });
/* harmony import */ var _Users_smartcommunitylab_Documents_work_projects_dslab_playgo_mobile_playgo_mobile_node_modules_babel_runtime_helpers_esm_classCallCheck_js__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./node_modules/@babel/runtime/helpers/esm/classCallCheck.js */ 78069);
/* harmony import */ var _Users_smartcommunitylab_Documents_work_projects_dslab_playgo_mobile_playgo_mobile_node_modules_babel_runtime_helpers_esm_createClass_js__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ./node_modules/@babel/runtime/helpers/esm/createClass.js */ 48047);
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! tslib */ 34929);
/* harmony import */ var _angular_common_http__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @angular/common/http */ 28784);
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! @angular/core */ 3184);



function _regeneratorRuntime() { "use strict"; /*! regenerator-runtime -- Copyright (c) 2014-present, Facebook, Inc. -- license (MIT): https://github.com/facebook/regenerator/blob/main/LICENSE */ _regeneratorRuntime = function _regeneratorRuntime() { return exports; }; var exports = {}, Op = Object.prototype, hasOwn = Op.hasOwnProperty, $Symbol = "function" == typeof Symbol ? Symbol : {}, iteratorSymbol = $Symbol.iterator || "@@iterator", asyncIteratorSymbol = $Symbol.asyncIterator || "@@asyncIterator", toStringTagSymbol = $Symbol.toStringTag || "@@toStringTag"; function define(obj, key, value) { return Object.defineProperty(obj, key, { value: value, enumerable: !0, configurable: !0, writable: !0 }), obj[key]; } try { define({}, ""); } catch (err) { define = function define(obj, key, value) { return obj[key] = value; }; } function wrap(innerFn, outerFn, self, tryLocsList) { var protoGenerator = outerFn && outerFn.prototype instanceof Generator ? outerFn : Generator, generator = Object.create(protoGenerator.prototype), context = new Context(tryLocsList || []); return generator._invoke = function (innerFn, self, context) { var state = "suspendedStart"; return function (method, arg) { if ("executing" === state) throw new Error("Generator is already running"); if ("completed" === state) { if ("throw" === method) throw arg; return doneResult(); } for (context.method = method, context.arg = arg;;) { var delegate = context.delegate; if (delegate) { var delegateResult = maybeInvokeDelegate(delegate, context); if (delegateResult) { if (delegateResult === ContinueSentinel) continue; return delegateResult; } } if ("next" === context.method) context.sent = context._sent = context.arg;else if ("throw" === context.method) { if ("suspendedStart" === state) throw state = "completed", context.arg; context.dispatchException(context.arg); } else "return" === context.method && context.abrupt("return", context.arg); state = "executing"; var record = tryCatch(innerFn, self, context); if ("normal" === record.type) { if (state = context.done ? "completed" : "suspendedYield", record.arg === ContinueSentinel) continue; return { value: record.arg, done: context.done }; } "throw" === record.type && (state = "completed", context.method = "throw", context.arg = record.arg); } }; }(innerFn, self, context), generator; } function tryCatch(fn, obj, arg) { try { return { type: "normal", arg: fn.call(obj, arg) }; } catch (err) { return { type: "throw", arg: err }; } } exports.wrap = wrap; var ContinueSentinel = {}; function Generator() {} function GeneratorFunction() {} function GeneratorFunctionPrototype() {} var IteratorPrototype = {}; define(IteratorPrototype, iteratorSymbol, function () { return this; }); var getProto = Object.getPrototypeOf, NativeIteratorPrototype = getProto && getProto(getProto(values([]))); NativeIteratorPrototype && NativeIteratorPrototype !== Op && hasOwn.call(NativeIteratorPrototype, iteratorSymbol) && (IteratorPrototype = NativeIteratorPrototype); var Gp = GeneratorFunctionPrototype.prototype = Generator.prototype = Object.create(IteratorPrototype); function defineIteratorMethods(prototype) { ["next", "throw", "return"].forEach(function (method) { define(prototype, method, function (arg) { return this._invoke(method, arg); }); }); } function AsyncIterator(generator, PromiseImpl) { function invoke(method, arg, resolve, reject) { var record = tryCatch(generator[method], generator, arg); if ("throw" !== record.type) { var result = record.arg, value = result.value; return value && "object" == typeof value && hasOwn.call(value, "__await") ? PromiseImpl.resolve(value.__await).then(function (value) { invoke("next", value, resolve, reject); }, function (err) { invoke("throw", err, resolve, reject); }) : PromiseImpl.resolve(value).then(function (unwrapped) { result.value = unwrapped, resolve(result); }, function (error) { return invoke("throw", error, resolve, reject); }); } reject(record.arg); } var previousPromise; this._invoke = function (method, arg) { function callInvokeWithMethodAndArg() { return new PromiseImpl(function (resolve, reject) { invoke(method, arg, resolve, reject); }); } return previousPromise = previousPromise ? previousPromise.then(callInvokeWithMethodAndArg, callInvokeWithMethodAndArg) : callInvokeWithMethodAndArg(); }; } function maybeInvokeDelegate(delegate, context) { var method = delegate.iterator[context.method]; if (undefined === method) { if (context.delegate = null, "throw" === context.method) { if (delegate.iterator.return && (context.method = "return", context.arg = undefined, maybeInvokeDelegate(delegate, context), "throw" === context.method)) return ContinueSentinel; context.method = "throw", context.arg = new TypeError("The iterator does not provide a 'throw' method"); } return ContinueSentinel; } var record = tryCatch(method, delegate.iterator, context.arg); if ("throw" === record.type) return context.method = "throw", context.arg = record.arg, context.delegate = null, ContinueSentinel; var info = record.arg; return info ? info.done ? (context[delegate.resultName] = info.value, context.next = delegate.nextLoc, "return" !== context.method && (context.method = "next", context.arg = undefined), context.delegate = null, ContinueSentinel) : info : (context.method = "throw", context.arg = new TypeError("iterator result is not an object"), context.delegate = null, ContinueSentinel); } function pushTryEntry(locs) { var entry = { tryLoc: locs[0] }; 1 in locs && (entry.catchLoc = locs[1]), 2 in locs && (entry.finallyLoc = locs[2], entry.afterLoc = locs[3]), this.tryEntries.push(entry); } function resetTryEntry(entry) { var record = entry.completion || {}; record.type = "normal", delete record.arg, entry.completion = record; } function Context(tryLocsList) { this.tryEntries = [{ tryLoc: "root" }], tryLocsList.forEach(pushTryEntry, this), this.reset(!0); } function values(iterable) { if (iterable) { var iteratorMethod = iterable[iteratorSymbol]; if (iteratorMethod) return iteratorMethod.call(iterable); if ("function" == typeof iterable.next) return iterable; if (!isNaN(iterable.length)) { var i = -1, next = function next() { for (; ++i < iterable.length;) { if (hasOwn.call(iterable, i)) return next.value = iterable[i], next.done = !1, next; } return next.value = undefined, next.done = !0, next; }; return next.next = next; } } return { next: doneResult }; } function doneResult() { return { value: undefined, done: !0 }; } return GeneratorFunction.prototype = GeneratorFunctionPrototype, define(Gp, "constructor", GeneratorFunctionPrototype), define(GeneratorFunctionPrototype, "constructor", GeneratorFunction), GeneratorFunction.displayName = define(GeneratorFunctionPrototype, toStringTagSymbol, "GeneratorFunction"), exports.isGeneratorFunction = function (genFun) { var ctor = "function" == typeof genFun && genFun.constructor; return !!ctor && (ctor === GeneratorFunction || "GeneratorFunction" === (ctor.displayName || ctor.name)); }, exports.mark = function (genFun) { return Object.setPrototypeOf ? Object.setPrototypeOf(genFun, GeneratorFunctionPrototype) : (genFun.__proto__ = GeneratorFunctionPrototype, define(genFun, toStringTagSymbol, "GeneratorFunction")), genFun.prototype = Object.create(Gp), genFun; }, exports.awrap = function (arg) { return { __await: arg }; }, defineIteratorMethods(AsyncIterator.prototype), define(AsyncIterator.prototype, asyncIteratorSymbol, function () { return this; }), exports.AsyncIterator = AsyncIterator, exports.async = function (innerFn, outerFn, self, tryLocsList, PromiseImpl) { void 0 === PromiseImpl && (PromiseImpl = Promise); var iter = new AsyncIterator(wrap(innerFn, outerFn, self, tryLocsList), PromiseImpl); return exports.isGeneratorFunction(outerFn) ? iter : iter.next().then(function (result) { return result.done ? result.value : iter.next(); }); }, defineIteratorMethods(Gp), define(Gp, toStringTagSymbol, "Generator"), define(Gp, iteratorSymbol, function () { return this; }), define(Gp, "toString", function () { return "[object Generator]"; }), exports.keys = function (object) { var keys = []; for (var key in object) { keys.push(key); } return keys.reverse(), function next() { for (; keys.length;) { var key = keys.pop(); if (key in object) return next.value = key, next.done = !1, next; } return next.done = !0, next; }; }, exports.values = values, Context.prototype = { constructor: Context, reset: function reset(skipTempReset) { if (this.prev = 0, this.next = 0, this.sent = this._sent = undefined, this.done = !1, this.delegate = null, this.method = "next", this.arg = undefined, this.tryEntries.forEach(resetTryEntry), !skipTempReset) for (var name in this) { "t" === name.charAt(0) && hasOwn.call(this, name) && !isNaN(+name.slice(1)) && (this[name] = undefined); } }, stop: function stop() { this.done = !0; var rootRecord = this.tryEntries[0].completion; if ("throw" === rootRecord.type) throw rootRecord.arg; return this.rval; }, dispatchException: function dispatchException(exception) { if (this.done) throw exception; var context = this; function handle(loc, caught) { return record.type = "throw", record.arg = exception, context.next = loc, caught && (context.method = "next", context.arg = undefined), !!caught; } for (var i = this.tryEntries.length - 1; i >= 0; --i) { var entry = this.tryEntries[i], record = entry.completion; if ("root" === entry.tryLoc) return handle("end"); if (entry.tryLoc <= this.prev) { var hasCatch = hasOwn.call(entry, "catchLoc"), hasFinally = hasOwn.call(entry, "finallyLoc"); if (hasCatch && hasFinally) { if (this.prev < entry.catchLoc) return handle(entry.catchLoc, !0); if (this.prev < entry.finallyLoc) return handle(entry.finallyLoc); } else if (hasCatch) { if (this.prev < entry.catchLoc) return handle(entry.catchLoc, !0); } else { if (!hasFinally) throw new Error("try statement without catch or finally"); if (this.prev < entry.finallyLoc) return handle(entry.finallyLoc); } } } }, abrupt: function abrupt(type, arg) { for (var i = this.tryEntries.length - 1; i >= 0; --i) { var entry = this.tryEntries[i]; if (entry.tryLoc <= this.prev && hasOwn.call(entry, "finallyLoc") && this.prev < entry.finallyLoc) { var finallyEntry = entry; break; } } finallyEntry && ("break" === type || "continue" === type) && finallyEntry.tryLoc <= arg && arg <= finallyEntry.finallyLoc && (finallyEntry = null); var record = finallyEntry ? finallyEntry.completion : {}; return record.type = type, record.arg = arg, finallyEntry ? (this.method = "next", this.next = finallyEntry.finallyLoc, ContinueSentinel) : this.complete(record); }, complete: function complete(record, afterLoc) { if ("throw" === record.type) throw record.arg; return "break" === record.type || "continue" === record.type ? this.next = record.arg : "return" === record.type ? (this.rval = this.arg = record.arg, this.method = "return", this.next = "end") : "normal" === record.type && afterLoc && (this.next = afterLoc), ContinueSentinel; }, finish: function finish(finallyLoc) { for (var i = this.tryEntries.length - 1; i >= 0; --i) { var entry = this.tryEntries[i]; if (entry.finallyLoc === finallyLoc) return this.complete(entry.completion, entry.afterLoc), resetTryEntry(entry), ContinueSentinel; } }, catch: function _catch(tryLoc) { for (var i = this.tryEntries.length - 1; i >= 0; --i) { var entry = this.tryEntries[i]; if (entry.tryLoc === tryLoc) { var record = entry.completion; if ("throw" === record.type) { var thrown = record.arg; resetTryEntry(entry); } return thrown; } } throw new Error("illegal catch attempt"); }, delegateYield: function delegateYield(iterable, resultName, nextLoc) { return this.delegate = { iterator: values(iterable), resultName: resultName, nextLoc: nextLoc }, "next" === this.method && (this.arg = undefined), ContinueSentinel; } }, exports; }





var NgHttpService = /*#__PURE__*/function () {
  function NgHttpService(http) {
    (0,_Users_smartcommunitylab_Documents_work_projects_dslab_playgo_mobile_playgo_mobile_node_modules_babel_runtime_helpers_esm_classCallCheck_js__WEBPACK_IMPORTED_MODULE_0__["default"])(this, NgHttpService);

    this.http = http;
  }

  (0,_Users_smartcommunitylab_Documents_work_projects_dslab_playgo_mobile_playgo_mobile_node_modules_babel_runtime_helpers_esm_createClass_js__WEBPACK_IMPORTED_MODULE_1__["default"])(NgHttpService, [{
    key: "xhr",
    value: function xhr(settings) {
      return (0,tslib__WEBPACK_IMPORTED_MODULE_2__.__awaiter)(this, void 0, void 0, /*#__PURE__*/_regeneratorRuntime().mark(function _callee() {
        return _regeneratorRuntime().wrap(function _callee$(_context) {
          while (1) {
            switch (_context.prev = _context.next) {
              case 0:
                if (!settings.method) {
                  settings.method = 'GET';
                }

                _context.t0 = settings.method;
                _context.next = _context.t0 === 'GET' ? 4 : _context.t0 === 'POST' ? 5 : _context.t0 === 'PUT' ? 6 : _context.t0 === 'DELETE' ? 7 : 8;
                break;

              case 4:
                return _context.abrupt("return", this.http.get(settings.url, {
                  headers: this.getHeaders(settings.headers)
                }).toPromise());

              case 5:
                return _context.abrupt("return", this.http.post(settings.url, settings.data, {
                  headers: this.getHeaders(settings.headers)
                }).toPromise());

              case 6:
                return _context.abrupt("return", this.http.put(settings.url, settings.data, {
                  headers: this.getHeaders(settings.headers)
                }).toPromise());

              case 7:
                return _context.abrupt("return", this.http.delete(settings.url, {
                  headers: this.getHeaders(settings.headers)
                }).toPromise());

              case 8:
              case "end":
                return _context.stop();
            }
          }
        }, _callee, this);
      }));
    }
  }, {
    key: "getHeaders",
    value: function getHeaders(headers) {
      var httpHeaders = new _angular_common_http__WEBPACK_IMPORTED_MODULE_3__.HttpHeaders();

      if (headers !== undefined) {
        Object.keys(headers).forEach(function (key) {
          httpHeaders = httpHeaders.append(key, headers[key]);
        });
      }

      return httpHeaders;
    }
  }]);

  return NgHttpService;
}();

NgHttpService.ɵfac = function NgHttpService_Factory(t) {
  return new (t || NgHttpService)(_angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵinject"](_angular_common_http__WEBPACK_IMPORTED_MODULE_3__.HttpClient));
};

NgHttpService.ɵprov = /*@__PURE__*/_angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵdefineInjectable"]({
  token: NgHttpService,
  factory: NgHttpService.ɵfac,
  providedIn: 'root'
});

/***/ }),

/***/ 95750:
/*!***************************************************!*\
  !*** ./src/app/core/constants/error.constants.ts ***!
  \***************************************************/
/***/ (function(__unused_webpack_module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "ERRORS": function() { return /* binding */ ERRORS; }
/* harmony export */ });
var ERRORS = [{
  value: 401,
  msg: 'user not found',
  errorString: 'errors.userNotFound'
}, {
  value: 400,
  msg: 'nickname already exists',
  errorString: 'errors.nickNameExist'
}];

/***/ }),

/***/ 4765:
/*!**********************************************************************************************************!*\
  !*** ./src/app/core/shared/campaigns/app-widget-campaign/active-challenge/active-challenge.component.ts ***!
  \**********************************************************************************************************/
/***/ (function(__unused_webpack_module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "ActiveChallengeComponent": function() { return /* binding */ ActiveChallengeComponent; }
/* harmony export */ });
/* harmony import */ var _Users_smartcommunitylab_Documents_work_projects_dslab_playgo_mobile_playgo_mobile_node_modules_babel_runtime_helpers_esm_classCallCheck_js__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./node_modules/@babel/runtime/helpers/esm/classCallCheck.js */ 78069);
/* harmony import */ var _Users_smartcommunitylab_Documents_work_projects_dslab_playgo_mobile_playgo_mobile_node_modules_babel_runtime_helpers_esm_createClass_js__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ./node_modules/@babel/runtime/helpers/esm/createClass.js */ 48047);
/* harmony import */ var _core_shared_utils__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! ../../../../../core/shared/utils */ 68647);
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(/*! @angular/core */ 3184);
/* harmony import */ var _ionic_angular__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(/*! @ionic/angular */ 93819);
/* harmony import */ var _ui_icon_icon_component__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! ../../../ui/icon/icon.component */ 71888);
/* harmony import */ var _angular_common__WEBPACK_IMPORTED_MODULE_9__ = __webpack_require__(/*! @angular/common */ 36362);
/* harmony import */ var _challenge_users_status_challenge_users_status_component__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! ../../challenge-users-status/challenge-users-status.component */ 47298);
/* harmony import */ var _challenge_bar_status_challenge_bar_status_component__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! ../../challenge-bar-status/challenge-bar-status.component */ 69723);
/* harmony import */ var _pipes_languageMap_pipe__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! ../../../pipes/languageMap.pipe */ 73088);











function ActiveChallengeComponent_app_challenge_users_status_10_Template(rf, ctx) {
  if (rf & 1) {
    _angular_core__WEBPACK_IMPORTED_MODULE_7__["ɵɵelement"](0, "app-challenge-users-status", 7);
  }

  if (rf & 2) {
    var ctx_r0 = _angular_core__WEBPACK_IMPORTED_MODULE_7__["ɵɵnextContext"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_7__["ɵɵproperty"]("position", "home")("status", ctx_r0.challenge.status)("rowStatus", ctx_r0.challenge.row_status)("type", "type")("challengeType", ctx_r0.challenge.type)("otherUser", ctx_r0.challenge.otherAttendeeData);
  }
}

function ActiveChallengeComponent_app_challenge_bar_status_11_Template(rf, ctx) {
  if (rf & 1) {
    _angular_core__WEBPACK_IMPORTED_MODULE_7__["ɵɵelement"](0, "app-challenge-bar-status", 8);
  }

  if (rf & 2) {
    var ctx_r1 = _angular_core__WEBPACK_IMPORTED_MODULE_7__["ɵɵnextContext"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_7__["ɵɵproperty"]("status", ctx_r1.challenge.status)("rowStatus", ctx_r1.challenge.row_status)("otherStatus", ctx_r1.challenge.otherAttendeeData == null ? null : ctx_r1.challenge.otherAttendeeData.status)("challengeType", ctx_r1.challenge.type)("type", ctx_r1.type);
  }
}

var ActiveChallengeComponent = /*#__PURE__*/function () {
  function ActiveChallengeComponent() {
    (0,_Users_smartcommunitylab_Documents_work_projects_dslab_playgo_mobile_playgo_mobile_node_modules_babel_runtime_helpers_esm_classCallCheck_js__WEBPACK_IMPORTED_MODULE_0__["default"])(this, ActiveChallengeComponent);

    this.imgChallenge = _core_shared_utils__WEBPACK_IMPORTED_MODULE_2__.getImgChallenge;
    this.type = 'active';
  }

  (0,_Users_smartcommunitylab_Documents_work_projects_dslab_playgo_mobile_playgo_mobile_node_modules_babel_runtime_helpers_esm_createClass_js__WEBPACK_IMPORTED_MODULE_1__["default"])(ActiveChallengeComponent, [{
    key: "ngOnInit",
    value: function ngOnInit() {}
  }, {
    key: "fillSurvey",
    value: function fillSurvey() {
      console.log('fill survey');
    }
  }]);

  return ActiveChallengeComponent;
}();

ActiveChallengeComponent.ɵfac = function ActiveChallengeComponent_Factory(t) {
  return new (t || ActiveChallengeComponent)();
};

ActiveChallengeComponent.ɵcmp = /*@__PURE__*/_angular_core__WEBPACK_IMPORTED_MODULE_7__["ɵɵdefineComponent"]({
  type: ActiveChallengeComponent,
  selectors: [["app-active-challenge"]],
  inputs: {
    challenge: "challenge"
  },
  decls: 12,
  vars: 7,
  consts: [[1, "ion-no-padding", 3, "color"], [1, "ion-no-padding"], ["size", "2", 1, "ion-no-padding"], [1, "challenge-icon", "icon-size-big", 3, "name"], [3, "innerHTML"], [3, "position", "status", "rowStatus", "type", "challengeType", "otherUser", 4, "ngIf"], [3, "status", "rowStatus", "otherStatus", "challengeType", "type", 4, "ngIf"], [3, "position", "status", "rowStatus", "type", "challengeType", "otherUser"], [3, "status", "rowStatus", "otherStatus", "challengeType", "type"]],
  template: function ActiveChallengeComponent_Template(rf, ctx) {
    if (rf & 1) {
      _angular_core__WEBPACK_IMPORTED_MODULE_7__["ɵɵelementStart"](0, "ion-card", 0)(1, "ion-card-header", 1)(2, "ion-grid", 1)(3, "ion-row", 1)(4, "ion-col", 2);
      _angular_core__WEBPACK_IMPORTED_MODULE_7__["ɵɵelement"](5, "app-icon", 3);
      _angular_core__WEBPACK_IMPORTED_MODULE_7__["ɵɵelementEnd"]();
      _angular_core__WEBPACK_IMPORTED_MODULE_7__["ɵɵelementStart"](6, "ion-col");
      _angular_core__WEBPACK_IMPORTED_MODULE_7__["ɵɵelement"](7, "p", 4);
      _angular_core__WEBPACK_IMPORTED_MODULE_7__["ɵɵpipe"](8, "languageMap");
      _angular_core__WEBPACK_IMPORTED_MODULE_7__["ɵɵelementEnd"]()()()();
      _angular_core__WEBPACK_IMPORTED_MODULE_7__["ɵɵelementStart"](9, "ion-card-content");
      _angular_core__WEBPACK_IMPORTED_MODULE_7__["ɵɵtemplate"](10, ActiveChallengeComponent_app_challenge_users_status_10_Template, 1, 6, "app-challenge-users-status", 5);
      _angular_core__WEBPACK_IMPORTED_MODULE_7__["ɵɵtemplate"](11, ActiveChallengeComponent_app_challenge_bar_status_11_Template, 1, 5, "app-challenge-bar-status", 6);
      _angular_core__WEBPACK_IMPORTED_MODULE_7__["ɵɵelementEnd"]()();
    }

    if (rf & 2) {
      _angular_core__WEBPACK_IMPORTED_MODULE_7__["ɵɵproperty"]("color", ctx.challenge.challengeType);
      _angular_core__WEBPACK_IMPORTED_MODULE_7__["ɵɵadvance"](5);
      _angular_core__WEBPACK_IMPORTED_MODULE_7__["ɵɵproperty"]("name", ctx.imgChallenge(ctx.challenge.type));
      _angular_core__WEBPACK_IMPORTED_MODULE_7__["ɵɵadvance"](2);
      _angular_core__WEBPACK_IMPORTED_MODULE_7__["ɵɵproperty"]("innerHTML", _angular_core__WEBPACK_IMPORTED_MODULE_7__["ɵɵpipeBind1"](8, 5, ctx.challenge.challDesc), _angular_core__WEBPACK_IMPORTED_MODULE_7__["ɵɵsanitizeHtml"]);
      _angular_core__WEBPACK_IMPORTED_MODULE_7__["ɵɵadvance"](3);
      _angular_core__WEBPACK_IMPORTED_MODULE_7__["ɵɵproperty"]("ngIf", ctx.challenge.type !== "survey");
      _angular_core__WEBPACK_IMPORTED_MODULE_7__["ɵɵadvance"](1);
      _angular_core__WEBPACK_IMPORTED_MODULE_7__["ɵɵproperty"]("ngIf", ctx.challenge.type !== "survey");
    }
  },
  directives: [_ionic_angular__WEBPACK_IMPORTED_MODULE_8__.IonCard, _ionic_angular__WEBPACK_IMPORTED_MODULE_8__.IonCardHeader, _ionic_angular__WEBPACK_IMPORTED_MODULE_8__.IonGrid, _ionic_angular__WEBPACK_IMPORTED_MODULE_8__.IonRow, _ionic_angular__WEBPACK_IMPORTED_MODULE_8__.IonCol, _ui_icon_icon_component__WEBPACK_IMPORTED_MODULE_3__.IconComponent, _ionic_angular__WEBPACK_IMPORTED_MODULE_8__.IonCardContent, _angular_common__WEBPACK_IMPORTED_MODULE_9__.NgIf, _challenge_users_status_challenge_users_status_component__WEBPACK_IMPORTED_MODULE_4__.ChallengeUsersStatusComponent, _challenge_bar_status_challenge_bar_status_component__WEBPACK_IMPORTED_MODULE_5__.ChallengeBarStatusComponent],
  pipes: [_pipes_languageMap_pipe__WEBPACK_IMPORTED_MODULE_6__.LanguageMapPipe],
  styles: ["\n/*# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbXSwibmFtZXMiOltdLCJtYXBwaW5ncyI6IiIsImZpbGUiOiJhY3RpdmUtY2hhbGxlbmdlLmNvbXBvbmVudC5zY3NzIn0= */"]
});

/***/ }),

/***/ 40201:
/*!**********************************************************************************************************************************!*\
  !*** ./src/app/core/shared/campaigns/app-widget-campaign/app-home-campaign-challenges/app-home-campaign-challenges.component.ts ***!
  \**********************************************************************************************************************************/
/***/ (function(__unused_webpack_module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "HomeCampaignChallengeComponent": function() { return /* binding */ HomeCampaignChallengeComponent; }
/* harmony export */ });
/* harmony import */ var _Users_smartcommunitylab_Documents_work_projects_dslab_playgo_mobile_playgo_mobile_node_modules_babel_runtime_helpers_esm_classCallCheck_js__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./node_modules/@babel/runtime/helpers/esm/classCallCheck.js */ 78069);
/* harmony import */ var _Users_smartcommunitylab_Documents_work_projects_dslab_playgo_mobile_playgo_mobile_node_modules_babel_runtime_helpers_esm_createClass_js__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ./node_modules/@babel/runtime/helpers/esm/createClass.js */ 48047);
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! @angular/core */ 3184);
/* harmony import */ var _services_challenge_service__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! ../../../services/challenge.service */ 66324);
/* harmony import */ var _ionic_angular__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! @ionic/angular */ 93819);
/* harmony import */ var _home_widget_types_notification_badge_notification_badge_component__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! ../../home-widget-types/notification-badge/notification-badge.component */ 36036);
/* harmony import */ var _angular_common__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(/*! @angular/common */ 36362);
/* harmony import */ var _active_challenge_active_challenge_component__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! ../active-challenge/active-challenge.component */ 4765);









function HomeCampaignChallengeComponent_app_active_challenge_3_Template(rf, ctx) {
  if (rf & 1) {
    var _r3 = _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵgetCurrentView"]();

    _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵelementStart"](0, "app-active-challenge", 3);
    _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵlistener"]("click", function HomeCampaignChallengeComponent_app_active_challenge_3_Template_app_active_challenge_click_0_listener($event) {
      _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵrestoreView"](_r3);
      var ctx_r2 = _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵnextContext"]();
      return ctx_r2.goToChallenge($event);
    });
    _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵelementEnd"]();
  }

  if (rf & 2) {
    var challenge_r1 = ctx.$implicit;
    _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵproperty"]("challenge", challenge_r1);
  }
}

var HomeCampaignChallengeComponent = /*#__PURE__*/function () {
  function HomeCampaignChallengeComponent(challengeService, navController) {
    (0,_Users_smartcommunitylab_Documents_work_projects_dslab_playgo_mobile_playgo_mobile_node_modules_babel_runtime_helpers_esm_classCallCheck_js__WEBPACK_IMPORTED_MODULE_0__["default"])(this, HomeCampaignChallengeComponent);

    this.challengeService = challengeService;
    this.navController = navController;
    this.activeChallenges = [];
    this.futureChallenges = [];
  }

  (0,_Users_smartcommunitylab_Documents_work_projects_dslab_playgo_mobile_playgo_mobile_node_modules_babel_runtime_helpers_esm_createClass_js__WEBPACK_IMPORTED_MODULE_1__["default"])(HomeCampaignChallengeComponent, [{
    key: "ngOnInit",
    value: function ngOnInit() {
      var _this = this;

      var _a, _b, _c, _d;

      this.activeChallenges$ = this.challengeService.getActiveChallengesByCampaign((_b = (_a = this.campaignContainer) === null || _a === void 0 ? void 0 : _a.campaign) === null || _b === void 0 ? void 0 : _b.campaignId);
      this.subChallActive = this.activeChallenges$.subscribe(function (challenges) {
        _this.activeChallenges = challenges;
      });
      this.futureChallenges$ = this.challengeService.getFutureChallengesByCampaign((_d = (_c = this.campaignContainer) === null || _c === void 0 ? void 0 : _c.campaign) === null || _d === void 0 ? void 0 : _d.campaignId);
      this.subChallFuture = this.futureChallenges$.subscribe(function (challenges) {
        _this.futureChallenges = challenges;
      });
    }
  }, {
    key: "ngOnDestroy",
    value: function ngOnDestroy() {}
  }, {
    key: "goToChallenge",
    value: function goToChallenge(event) {
      if (event && event.stopPropagation) {
        event.stopPropagation();
      }

      this.navController.navigateRoot('/pages/tabs/challenges');
    }
  }]);

  return HomeCampaignChallengeComponent;
}();

HomeCampaignChallengeComponent.ɵfac = function HomeCampaignChallengeComponent_Factory(t) {
  return new (t || HomeCampaignChallengeComponent)(_angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵdirectiveInject"](_services_challenge_service__WEBPACK_IMPORTED_MODULE_2__.ChallengeService), _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵdirectiveInject"](_ionic_angular__WEBPACK_IMPORTED_MODULE_6__.NavController));
};

HomeCampaignChallengeComponent.ɵcmp = /*@__PURE__*/_angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵdefineComponent"]({
  type: HomeCampaignChallengeComponent,
  selectors: [["app-home-campaign-challenges"]],
  inputs: {
    campaignContainer: "campaignContainer"
  },
  decls: 4,
  vars: 4,
  consts: [[3, "color"], [3, "type", "campaignContainer"], [3, "challenge", "click", 4, "ngFor", "ngForOf"], [3, "challenge", "click"]],
  template: function HomeCampaignChallengeComponent_Template(rf, ctx) {
    if (rf & 1) {
      _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵelementStart"](0, "ion-item", 0);
      _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵtext"](1, " Sezione sfide ");
      _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵelement"](2, "app-notification-badge", 1);
      _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵelementEnd"]();
      _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵtemplate"](3, HomeCampaignChallengeComponent_app_active_challenge_3_Template, 1, 1, "app-active-challenge", 2);
    }

    if (rf & 2) {
      _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵproperty"]("color", ctx.campaignContainer == null ? null : ctx.campaignContainer.campaign == null ? null : ctx.campaignContainer.campaign.type);
      _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵadvance"](2);
      _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵproperty"]("type", "challenge")("campaignContainer", ctx.campaignContainer);
      _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵadvance"](1);
      _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵproperty"]("ngForOf", ctx.activeChallenges);
    }
  },
  directives: [_ionic_angular__WEBPACK_IMPORTED_MODULE_6__.IonItem, _home_widget_types_notification_badge_notification_badge_component__WEBPACK_IMPORTED_MODULE_3__.NotificationBadgeComponent, _angular_common__WEBPACK_IMPORTED_MODULE_7__.NgForOf, _active_challenge_active_challenge_component__WEBPACK_IMPORTED_MODULE_4__.ActiveChallengeComponent],
  styles: ["ion-item[_ngcontent-%COMP%] {\n  overflow: visible;\n}\n/*# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbImFwcC1ob21lLWNhbXBhaWduLWNoYWxsZW5nZXMuY29tcG9uZW50LnNjc3MiXSwibmFtZXMiOltdLCJtYXBwaW5ncyI6IkFBQUE7RUFDRSxpQkFBQTtBQUNGIiwiZmlsZSI6ImFwcC1ob21lLWNhbXBhaWduLWNoYWxsZW5nZXMuY29tcG9uZW50LnNjc3MiLCJzb3VyY2VzQ29udGVudCI6WyJpb24taXRlbSB7XG4gIG92ZXJmbG93OiB2aXNpYmxlO1xufVxuIl19 */"]
});

/***/ }),

/***/ 519:
/*!********************************************************************************************!*\
  !*** ./src/app/core/shared/campaigns/app-widget-campaign/app-widget-campaign.component.ts ***!
  \********************************************************************************************/
/***/ (function(__unused_webpack_module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "WidgetComponent": function() { return /* binding */ WidgetComponent; }
/* harmony export */ });
/* harmony import */ var _Users_smartcommunitylab_Documents_work_projects_dslab_playgo_mobile_playgo_mobile_node_modules_babel_runtime_helpers_esm_classCallCheck_js__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./node_modules/@babel/runtime/helpers/esm/classCallCheck.js */ 78069);
/* harmony import */ var _Users_smartcommunitylab_Documents_work_projects_dslab_playgo_mobile_playgo_mobile_node_modules_babel_runtime_helpers_esm_createClass_js__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ./node_modules/@babel/runtime/helpers/esm/createClass.js */ 48047);
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! @angular/core */ 3184);
/* harmony import */ var _angular_router__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(/*! @angular/router */ 52816);
/* harmony import */ var _angular_common__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(/*! @angular/common */ 36362);
/* harmony import */ var _home_widget_types_home_campaign_personal_home_campaign_personal_component__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! ../home-widget-types/home-campaign-personal/home-campaign-personal.component */ 90706);
/* harmony import */ var _home_widget_types_home_campaign_city_home_campaign_city_component__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! ../home-widget-types/home-campaign-city/home-campaign-city.component */ 96784);
/* harmony import */ var _home_widget_types_home_campaign_company_home_campaign_company_component__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! ../home-widget-types/home-campaign-company/home-campaign-company.component */ 10881);
/* harmony import */ var _home_widget_types_home_campaign_school_home_campaign_school_component__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! ../home-widget-types/home-campaign-school/home-campaign-school.component */ 37374);










function WidgetComponent_ng_container_1_Template(rf, ctx) {
  if (rf & 1) {
    var _r6 = _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵgetCurrentView"]();

    _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵelementContainerStart"](0);
    _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵelementStart"](1, "app-home-campaign-personal", 3);
    _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵlistener"]("click", function WidgetComponent_ng_container_1_Template_app_home_campaign_personal_click_1_listener() {
      _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵrestoreView"](_r6);
      var ctx_r5 = _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵnextContext"]();
      return ctx_r5.detailCampaign(ctx_r5.campaign);
    });
    _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵelementEnd"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵelementContainerEnd"]();
  }

  if (rf & 2) {
    var ctx_r0 = _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵnextContext"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵadvance"](1);
    _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵproperty"]("header", ctx_r0.header)("campaignContainer", ctx_r0.campaign);
  }
}

function WidgetComponent_ng_container_2_Template(rf, ctx) {
  if (rf & 1) {
    var _r8 = _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵgetCurrentView"]();

    _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵelementContainerStart"](0);
    _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵelementStart"](1, "app-home-campaign-city", 3);
    _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵlistener"]("click", function WidgetComponent_ng_container_2_Template_app_home_campaign_city_click_1_listener() {
      _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵrestoreView"](_r8);
      var ctx_r7 = _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵnextContext"]();
      return ctx_r7.detailCampaign(ctx_r7.campaign);
    });
    _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵelementEnd"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵelementContainerEnd"]();
  }

  if (rf & 2) {
    var ctx_r1 = _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵnextContext"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵadvance"](1);
    _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵproperty"]("header", ctx_r1.header)("campaignContainer", ctx_r1.campaign);
  }
}

function WidgetComponent_ng_container_3_Template(rf, ctx) {
  if (rf & 1) {
    var _r10 = _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵgetCurrentView"]();

    _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵelementContainerStart"](0);
    _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵelementStart"](1, "app-home-campaign-company", 3);
    _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵlistener"]("click", function WidgetComponent_ng_container_3_Template_app_home_campaign_company_click_1_listener() {
      _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵrestoreView"](_r10);
      var ctx_r9 = _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵnextContext"]();
      return ctx_r9.detailCampaign(ctx_r9.campaign);
    });
    _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵelementEnd"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵelementContainerEnd"]();
  }

  if (rf & 2) {
    var ctx_r2 = _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵnextContext"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵadvance"](1);
    _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵproperty"]("header", ctx_r2.header)("campaignContainer", ctx_r2.campaign);
  }
}

function WidgetComponent_ng_container_4_Template(rf, ctx) {
  if (rf & 1) {
    var _r12 = _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵgetCurrentView"]();

    _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵelementContainerStart"](0);
    _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵelementStart"](1, "app-home-campaign-school", 3);
    _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵlistener"]("click", function WidgetComponent_ng_container_4_Template_app_home_campaign_school_click_1_listener() {
      _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵrestoreView"](_r12);
      var ctx_r11 = _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵnextContext"]();
      return ctx_r11.detailCampaign(ctx_r11.campaign);
    });
    _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵelementEnd"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵelementContainerEnd"]();
  }

  if (rf & 2) {
    var ctx_r3 = _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵnextContext"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵadvance"](1);
    _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵproperty"]("header", ctx_r3.header)("campaignContainer", ctx_r3.campaign);
  }
}

function WidgetComponent_ng_container_5_Template(rf, ctx) {
  if (rf & 1) {
    _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵelementContainerStart"](0);
    _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵtext"](1, " default ");
    _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵelementContainerEnd"]();
  }
}

var WidgetComponent = /*#__PURE__*/function () {
  function WidgetComponent(router) {
    (0,_Users_smartcommunitylab_Documents_work_projects_dslab_playgo_mobile_playgo_mobile_node_modules_babel_runtime_helpers_esm_classCallCheck_js__WEBPACK_IMPORTED_MODULE_0__["default"])(this, WidgetComponent);

    this.router = router;
    this.header = false;
  }

  (0,_Users_smartcommunitylab_Documents_work_projects_dslab_playgo_mobile_playgo_mobile_node_modules_babel_runtime_helpers_esm_createClass_js__WEBPACK_IMPORTED_MODULE_1__["default"])(WidgetComponent, [{
    key: "ngOnInit",
    value: function ngOnInit() {}
  }, {
    key: "ngOnDestroy",
    value: function ngOnDestroy() {}
  }, {
    key: "detailCampaign",
    value: function detailCampaign(campaign) {
      this.router.navigateByUrl('/pages/tabs/campaigns/details/' + campaign.campaign.campaignId);
    }
  }]);

  return WidgetComponent;
}();

WidgetComponent.ɵfac = function WidgetComponent_Factory(t) {
  return new (t || WidgetComponent)(_angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵdirectiveInject"](_angular_router__WEBPACK_IMPORTED_MODULE_7__.Router));
};

WidgetComponent.ɵcmp = /*@__PURE__*/_angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵdefineComponent"]({
  type: WidgetComponent,
  selectors: [["app-widget-campaign"]],
  inputs: {
    campaign: "campaign",
    header: "header"
  },
  decls: 6,
  vars: 5,
  consts: [[3, "ngSwitch"], [4, "ngSwitchCase"], [4, "ngSwitchDefault"], [3, "header", "campaignContainer", "click"]],
  template: function WidgetComponent_Template(rf, ctx) {
    if (rf & 1) {
      _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵelementContainerStart"](0, 0);
      _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵtemplate"](1, WidgetComponent_ng_container_1_Template, 2, 2, "ng-container", 1);
      _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵtemplate"](2, WidgetComponent_ng_container_2_Template, 2, 2, "ng-container", 1);
      _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵtemplate"](3, WidgetComponent_ng_container_3_Template, 2, 2, "ng-container", 1);
      _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵtemplate"](4, WidgetComponent_ng_container_4_Template, 2, 2, "ng-container", 1);
      _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵtemplate"](5, WidgetComponent_ng_container_5_Template, 2, 0, "ng-container", 2);
      _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵelementContainerEnd"]();
    }

    if (rf & 2) {
      _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵproperty"]("ngSwitch", ctx.campaign.campaign.type);
      _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵadvance"](1);
      _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵproperty"]("ngSwitchCase", "personal");
      _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵadvance"](1);
      _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵproperty"]("ngSwitchCase", "city");
      _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵadvance"](1);
      _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵproperty"]("ngSwitchCase", "company");
      _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵadvance"](1);
      _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵproperty"]("ngSwitchCase", "school");
    }
  },
  directives: [_angular_common__WEBPACK_IMPORTED_MODULE_8__.NgSwitch, _angular_common__WEBPACK_IMPORTED_MODULE_8__.NgSwitchCase, _home_widget_types_home_campaign_personal_home_campaign_personal_component__WEBPACK_IMPORTED_MODULE_2__.HomeCampaignPersonalComponent, _home_widget_types_home_campaign_city_home_campaign_city_component__WEBPACK_IMPORTED_MODULE_3__.HomeCampaignCityComponent, _home_widget_types_home_campaign_company_home_campaign_company_component__WEBPACK_IMPORTED_MODULE_4__.HomeCampaignCompanyComponent, _home_widget_types_home_campaign_school_home_campaign_school_component__WEBPACK_IMPORTED_MODULE_5__.HomeCampaignSchoolComponent, _angular_common__WEBPACK_IMPORTED_MODULE_8__.NgSwitchDefault],
  styles: ["\n/*# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbXSwibmFtZXMiOltdLCJtYXBwaW5ncyI6IiIsImZpbGUiOiJhcHAtd2lkZ2V0LWNhbXBhaWduLmNvbXBvbmVudC5zY3NzIn0= */"]
});

/***/ }),

/***/ 69723:
/*!**********************************************************************************************!*\
  !*** ./src/app/core/shared/campaigns/challenge-bar-status/challenge-bar-status.component.ts ***!
  \**********************************************************************************************/
/***/ (function(__unused_webpack_module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "ChallengeBarStatusComponent": function() { return /* binding */ ChallengeBarStatusComponent; }
/* harmony export */ });
/* harmony import */ var _Users_smartcommunitylab_Documents_work_projects_dslab_playgo_mobile_playgo_mobile_node_modules_babel_runtime_helpers_esm_classCallCheck_js__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./node_modules/@babel/runtime/helpers/esm/classCallCheck.js */ 78069);
/* harmony import */ var _Users_smartcommunitylab_Documents_work_projects_dslab_playgo_mobile_playgo_mobile_node_modules_babel_runtime_helpers_esm_createClass_js__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ./node_modules/@babel/runtime/helpers/esm/createClass.js */ 48047);
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @angular/core */ 3184);
/* harmony import */ var _angular_common__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @angular/common */ 36362);





function ChallengeBarStatusComponent_div_2_Template(rf, ctx) {
  if (rf & 1) {
    _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵelement"](0, "div", 4);
  }
}

function ChallengeBarStatusComponent_div_3_Template(rf, ctx) {
  if (rf & 1) {
    _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵelement"](0, "div", 5);
  }

  if (rf & 2) {
    var ctx_r1 = _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵnextContext"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵstyleProp"]("width", ctx_r1.getWidth(ctx_r1.otherStatus), "%");
  }
}

var ChallengeBarStatusComponent = /*#__PURE__*/function () {
  // @Input() position?: string;
  function ChallengeBarStatusComponent() {
    (0,_Users_smartcommunitylab_Documents_work_projects_dslab_playgo_mobile_playgo_mobile_node_modules_babel_runtime_helpers_esm_classCallCheck_js__WEBPACK_IMPORTED_MODULE_0__["default"])(this, ChallengeBarStatusComponent);
  }

  (0,_Users_smartcommunitylab_Documents_work_projects_dslab_playgo_mobile_playgo_mobile_node_modules_babel_runtime_helpers_esm_createClass_js__WEBPACK_IMPORTED_MODULE_1__["default"])(ChallengeBarStatusComponent, [{
    key: "ngOnInit",
    value: function ngOnInit() {
      console.log(this.otherStatus);
    }
  }, {
    key: "getWidth",
    value: function getWidth(status) {
      if (this.challengeType === 'groupCompetitiveTime') {
        return status / 2;
      }

      return status;
    }
  }]);

  return ChallengeBarStatusComponent;
}();

ChallengeBarStatusComponent.ɵfac = function ChallengeBarStatusComponent_Factory(t) {
  return new (t || ChallengeBarStatusComponent)();
};

ChallengeBarStatusComponent.ɵcmp = /*@__PURE__*/_angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵdefineComponent"]({
  type: ChallengeBarStatusComponent,
  selectors: [["app-challenge-bar-status"]],
  inputs: {
    status: "status",
    rowStatus: "rowStatus",
    otherStatus: "otherStatus",
    type: "type",
    challengeType: "challengeType"
  },
  decls: 4,
  vars: 4,
  consts: [[1, "progress"], [1, "progress-bar"], ["class", "separator", 4, "ngIf"], ["class", "progress-bar-opposite", 3, "width", 4, "ngIf"], [1, "separator"], [1, "progress-bar-opposite"]],
  template: function ChallengeBarStatusComponent_Template(rf, ctx) {
    if (rf & 1) {
      _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵelementStart"](0, "div", 0);
      _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵelement"](1, "div", 1);
      _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵtemplate"](2, ChallengeBarStatusComponent_div_2_Template, 1, 0, "div", 2);
      _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵtemplate"](3, ChallengeBarStatusComponent_div_3_Template, 1, 2, "div", 3);
      _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵelementEnd"]();
    }

    if (rf & 2) {
      _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵadvance"](1);
      _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵstyleProp"]("width", ctx.getWidth(ctx.status), "%");
      _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵadvance"](1);
      _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵproperty"]("ngIf", ctx.challengeType === "groupCompetitiveTime");
      _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵadvance"](1);
      _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵproperty"]("ngIf", ctx.otherStatus !== null);
    }
  },
  directives: [_angular_common__WEBPACK_IMPORTED_MODULE_3__.NgIf],
  styles: [".progress[_ngcontent-%COMP%] {\n  padding: 2px;\n  width: 100%;\n  border: 1px solid lightgray;\n  height: 30px;\n  position: relative;\n}\n.progress[_ngcontent-%COMP%]   .separator[_ngcontent-%COMP%] {\n  height: inherit;\n  width: 3px;\n  background-color: lightgray;\n  position: absolute;\n  left: 50%;\n  top: 0px;\n}\n.progress[_ngcontent-%COMP%]   .progress-bar[_ngcontent-%COMP%] {\n  height: 100%;\n  background-color: #fdd835;\n  float: left;\n}\n.progress[_ngcontent-%COMP%]   .progress-bar-opposite[_ngcontent-%COMP%] {\n  height: 100%;\n  float: right;\n  background-color: #f29900;\n}\n@keyframes fill-bar {\n  from {\n    width: 0%;\n  }\n  to {\n    width: 100%;\n  }\n}\n/*# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbImNoYWxsZW5nZS1iYXItc3RhdHVzLmNvbXBvbmVudC5zY3NzIl0sIm5hbWVzIjpbXSwibWFwcGluZ3MiOiJBQUFBO0VBRUUsWUFBQTtFQUNBLFdBQUE7RUFFQSwyQkFBQTtFQUNBLFlBQUE7RUFDQSxrQkFBQTtBQURGO0FBS0U7RUFDRSxlQUFBO0VBQ0EsVUFBQTtFQUNBLDJCQUFBO0VBQ0Esa0JBQUE7RUFDQSxTQUFBO0VBQ0EsUUFBQTtBQUhKO0FBS0U7RUFDRSxZQUFBO0VBRUEseUJBQUE7RUFDQSxXQUFBO0FBSko7QUFVRTtFQUVFLFlBQUE7RUFDQSxZQUFBO0VBQ0EseUJBQUE7QUFUSjtBQWFBO0VBQ0U7SUFDRSxTQUFBO0VBVkY7RUFZQTtJQUNFLFdBQUE7RUFWRjtBQUNGIiwiZmlsZSI6ImNoYWxsZW5nZS1iYXItc3RhdHVzLmNvbXBvbmVudC5zY3NzIiwic291cmNlc0NvbnRlbnQiOlsiLnByb2dyZXNzIHtcbiAgLy8gICBtYXJnaW46IDUwcHggYXV0bztcbiAgcGFkZGluZzogMnB4O1xuICB3aWR0aDogMTAwJTtcbiAgLy8gICBtYXgtd2lkdGg6IDUwMHB4O1xuICBib3JkZXI6IDFweCBzb2xpZCBsaWdodGdyYXk7XG4gIGhlaWdodDogMzBweDtcbiAgcG9zaXRpb246IHJlbGF0aXZlO1xuICAvLyAgIGRpc3BsYXk6IGZsZXg7XG4gIC8vICAgLnBsYXllci1wcm9ncmVzcy1jb250YWluZXIge1xuICAvLyAgICAgaGVpZ2h0OiAxMDAlO1xuICAuc2VwYXJhdG9yIHtcbiAgICBoZWlnaHQ6IGluaGVyaXQ7XG4gICAgd2lkdGg6IDNweDtcbiAgICBiYWNrZ3JvdW5kLWNvbG9yOiBsaWdodGdyYXk7XG4gICAgcG9zaXRpb246IGFic29sdXRlO1xuICAgIGxlZnQ6IDUwJTtcbiAgICB0b3A6IDBweDtcbiAgfVxuICAucHJvZ3Jlc3MtYmFyIHtcbiAgICBoZWlnaHQ6IDEwMCU7XG4gICAgLy8gd2lkdGg6IDIwJTtcbiAgICBiYWNrZ3JvdW5kLWNvbG9yOiAjZmRkODM1O1xuICAgIGZsb2F0OiBsZWZ0O1xuICAgIC8vIGFuaW1hdGlvbjogZmlsbC1iYXIgMXMgZm9yd2FyZHM7XG4gICAgLy8gfVxuICB9XG4gIC8vICAgLm9wcG9zaXRlLXBsYXllci1wcm9ncmVzcy1jb250YWluZXIge1xuICAvLyAgICAgaGVpZ2h0OiAxMDAlO1xuICAucHJvZ3Jlc3MtYmFyLW9wcG9zaXRlIHtcbiAgICAvLyAgIHJvdGF0ZTogMTgwZGVnO1xuICAgIGhlaWdodDogMTAwJTtcbiAgICBmbG9hdDogcmlnaHQ7XG4gICAgYmFja2dyb3VuZC1jb2xvcjogI2YyOTkwMDtcbiAgfVxufVxuLy8gfVxuQGtleWZyYW1lcyBmaWxsLWJhciB7XG4gIGZyb20ge1xuICAgIHdpZHRoOiAwJTtcbiAgfVxuICB0byB7XG4gICAgd2lkdGg6IDEwMCU7XG4gIH1cbn1cbiJdfQ== */"]
});

/***/ }),

/***/ 47298:
/*!**************************************************************************************************!*\
  !*** ./src/app/core/shared/campaigns/challenge-users-status/challenge-users-status.component.ts ***!
  \**************************************************************************************************/
/***/ (function(__unused_webpack_module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "ChallengeUsersStatusComponent": function() { return /* binding */ ChallengeUsersStatusComponent; }
/* harmony export */ });
/* harmony import */ var _Users_smartcommunitylab_Documents_work_projects_dslab_playgo_mobile_playgo_mobile_node_modules_babel_runtime_helpers_esm_classCallCheck_js__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./node_modules/@babel/runtime/helpers/esm/classCallCheck.js */ 78069);
/* harmony import */ var _Users_smartcommunitylab_Documents_work_projects_dslab_playgo_mobile_playgo_mobile_node_modules_babel_runtime_helpers_esm_createClass_js__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ./node_modules/@babel/runtime/helpers/esm/createClass.js */ 48047);
/* harmony import */ var rxjs__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! rxjs */ 50635);
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! @angular/core */ 3184);
/* harmony import */ var src_app_core_shared_services_user_service__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! src/app/core/shared/services/user.service */ 50749);
/* harmony import */ var src_app_core_shared_services_error_service__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! src/app/core/shared/services/error.service */ 96204);
/* harmony import */ var _angular_common__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! @angular/common */ 36362);
/* harmony import */ var _ionic_angular__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(/*! @ionic/angular */ 93819);









function ChallengeUsersStatusComponent_div_0_ion_col_3_Template(rf, ctx) {
  if (rf & 1) {
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵelementStart"](0, "ion-col", 8)(1, "ion-avatar");
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵelement"](2, "img", 9);
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵpipe"](3, "async");
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵelementEnd"]()();
  }

  if (rf & 2) {
    var ctx_r1 = _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵnextContext"](2);
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵadvance"](2);
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵproperty"]("src", _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵpipeBind1"](3, 1, ctx_r1.playerAvatarUrl$), _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵsanitizeUrl"]);
  }
}

function ChallengeUsersStatusComponent_div_0_ion_col_7_Template(rf, ctx) {
  if (rf & 1) {
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵelementStart"](0, "ion-col", 10);
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵelement"](1, "div", 11);
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵelementEnd"]();
  }

  if (rf & 2) {
    var ctx_r2 = _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵnextContext"](2);
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵadvance"](1);
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵproperty"]("ngClass", ctx_r2.isWinning(ctx_r2.status, ctx_r2.otherUser == null ? null : ctx_r2.otherUser.status) ? "arrow-up" : "arrow-down");
  }
}

function ChallengeUsersStatusComponent_div_0_ion_row_11_Template(rf, ctx) {
  if (rf & 1) {
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵelementStart"](0, "ion-row", 3)(1, "ion-col");
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵtext"](2);
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵelementEnd"]()();
  }

  if (rf & 2) {
    var ctx_r3 = _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵnextContext"](2);
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵadvance"](2);
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵtextInterpolate1"](" ", ctx_r3.status, "%");
  }
}

function ChallengeUsersStatusComponent_div_0_ion_row_12_Template(rf, ctx) {
  if (rf & 1) {
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵelementStart"](0, "ion-row")(1, "ion-col");
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵtext"](2);
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵelementEnd"]()();
  }

  if (rf & 2) {
    var ctx_r4 = _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵnextContext"](2);
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵadvance"](2);
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵtextInterpolate1"]("", ctx_r4.rowStatus, " Km");
  }
}

function ChallengeUsersStatusComponent_div_0_ion_grid_14_ion_col_4_Template(rf, ctx) {
  if (rf & 1) {
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵelementStart"](0, "ion-col", 10);
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵelement"](1, "div", 11);
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵelementEnd"]();
  }

  if (rf & 2) {
    var ctx_r7 = _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵnextContext"](3);
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵadvance"](1);
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵproperty"]("ngClass", ctx_r7.isWinning(ctx_r7.otherUser == null ? null : ctx_r7.otherUser.status, ctx_r7.status) ? "arrow-up" : "arrow-down");
  }
}

function ChallengeUsersStatusComponent_div_0_ion_grid_14_ion_row_5_Template(rf, ctx) {
  if (rf & 1) {
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵelementStart"](0, "ion-row", 12)(1, "ion-col");
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵtext"](2);
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵelementEnd"]()();
  }

  if (rf & 2) {
    var ctx_r8 = _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵnextContext"](3);
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵadvance"](2);
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵtextInterpolate1"]("", ctx_r8.otherUser.status, "%");
  }
}

function ChallengeUsersStatusComponent_div_0_ion_grid_14_ion_row_6_Template(rf, ctx) {
  if (rf & 1) {
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵelementStart"](0, "ion-row", 13)(1, "ion-col");
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵtext"](2);
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵelementEnd"]()();
  }

  if (rf & 2) {
    var ctx_r9 = _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵnextContext"](3);
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵadvance"](2);
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵtextInterpolate1"]("", ctx_r9.otherUser.row_status, " Km");
  }
}

function ChallengeUsersStatusComponent_div_0_ion_grid_14_Template(rf, ctx) {
  if (rf & 1) {
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵelementStart"](0, "ion-grid", 1)(1, "ion-row", 12)(2, "ion-col", 13);
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵtext"](3);
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵelementEnd"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵtemplate"](4, ChallengeUsersStatusComponent_div_0_ion_grid_14_ion_col_4_Template, 2, 1, "ion-col", 4);
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵelementEnd"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵtemplate"](5, ChallengeUsersStatusComponent_div_0_ion_grid_14_ion_row_5_Template, 3, 1, "ion-row", 14);
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵtemplate"](6, ChallengeUsersStatusComponent_div_0_ion_grid_14_ion_row_6_Template, 3, 1, "ion-row", 15);
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵelementEnd"]();
  }

  if (rf & 2) {
    var ctx_r5 = _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵnextContext"](2);
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵadvance"](3);
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵtextInterpolate1"](" ", ctx_r5.otherUser == null ? null : ctx_r5.otherUser.nickname, "");
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵadvance"](1);
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵproperty"]("ngIf", ctx_r5.isCompetitive());
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵadvance"](1);
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵproperty"]("ngIf", !ctx_r5.isHome());
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵadvance"](1);
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵproperty"]("ngIf", !ctx_r5.isHome());
  }
}

function ChallengeUsersStatusComponent_div_0_ion_col_15_Template(rf, ctx) {
  if (rf & 1) {
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵelementStart"](0, "ion-col", 8)(1, "ion-avatar");
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵelement"](2, "img", 9);
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵelementEnd"]()();
  }

  if (rf & 2) {
    var ctx_r6 = _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵnextContext"](2);
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵadvance"](2);
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵproperty"]("src", ctx_r6.otherUser == null ? null : ctx_r6.otherUser.avatar == null ? null : ctx_r6.otherUser.avatar.url, _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵsanitizeUrl"]);
  }
}

function ChallengeUsersStatusComponent_div_0_Template(rf, ctx) {
  if (rf & 1) {
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵelementStart"](0, "div")(1, "ion-grid", 1)(2, "ion-row", 1);
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵtemplate"](3, ChallengeUsersStatusComponent_div_0_ion_col_3_Template, 4, 3, "ion-col", 2);
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵelementStart"](4, "ion-col")(5, "ion-grid", 1)(6, "ion-row", 3);
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵtemplate"](7, ChallengeUsersStatusComponent_div_0_ion_col_7_Template, 2, 1, "ion-col", 4);
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵelementStart"](8, "ion-col", 5);
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵtext"](9);
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵpipe"](10, "async");
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵelementEnd"]()();
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵtemplate"](11, ChallengeUsersStatusComponent_div_0_ion_row_11_Template, 3, 1, "ion-row", 6);
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵtemplate"](12, ChallengeUsersStatusComponent_div_0_ion_row_12_Template, 3, 1, "ion-row", 0);
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵelementEnd"]()();
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵelementStart"](13, "ion-col");
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵtemplate"](14, ChallengeUsersStatusComponent_div_0_ion_grid_14_Template, 7, 4, "ion-grid", 7);
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵelementEnd"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵtemplate"](15, ChallengeUsersStatusComponent_div_0_ion_col_15_Template, 3, 1, "ion-col", 2);
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵelementEnd"]()()();
  }

  if (rf & 2) {
    var ctx_r0 = _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵnextContext"]();
    var tmp_2_0;
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵadvance"](3);
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵproperty"]("ngIf", !ctx_r0.isHome());
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵadvance"](4);
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵproperty"]("ngIf", ctx_r0.isCompetitive());
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵadvance"](2);
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵtextInterpolate"]((tmp_2_0 = _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵpipeBind1"](10, 7, ctx_r0.profile$)) == null ? null : tmp_2_0.nickname);
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵadvance"](2);
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵproperty"]("ngIf", ctx_r0.status !== null && !ctx_r0.isHome());
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵadvance"](1);
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵproperty"]("ngIf", ctx_r0.rowStatus !== null && !ctx_r0.isHome());
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵadvance"](2);
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵproperty"]("ngIf", ctx_r0.otherUser);
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵadvance"](1);
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵproperty"]("ngIf", ctx_r0.otherUser && !ctx_r0.isHome());
  }
}

var ChallengeUsersStatusComponent = /*#__PURE__*/function () {
  // opponentAvatarUrl$: Observable<IUser['avatar']>;
  function ChallengeUsersStatusComponent(userService, errorService) {
    (0,_Users_smartcommunitylab_Documents_work_projects_dslab_playgo_mobile_playgo_mobile_node_modules_babel_runtime_helpers_esm_classCallCheck_js__WEBPACK_IMPORTED_MODULE_0__["default"])(this, ChallengeUsersStatusComponent);

    this.userService = userService;
    this.errorService = errorService;
    this.playerAvatarUrl$ = this.userService.userProfile$.pipe((0,rxjs__WEBPACK_IMPORTED_MODULE_5__.map)(function (userProfile) {
      return userProfile.avatar.avatarSmallUrl;
    }));
    this.profile$ = this.userService.userProfile$;
  }

  (0,_Users_smartcommunitylab_Documents_work_projects_dslab_playgo_mobile_playgo_mobile_node_modules_babel_runtime_helpers_esm_createClass_js__WEBPACK_IMPORTED_MODULE_1__["default"])(ChallengeUsersStatusComponent, [{
    key: "ngOnInit",
    value: function ngOnInit() {// if (this.otherUser?.playerId) {
      //   this.opponentAvatarUrl$ = this.userService.getOtherPlayerAvatar(
      //     this.otherUser.playerId
      //   );
      // }
    }
  }, {
    key: "ngOnDestroy",
    value: function ngOnDestroy() {}
  }, {
    key: "isWinning",
    value: function isWinning(me, other) {
      if (me > other) {
        return true;
      }

      return false;
    }
  }, {
    key: "isCompetitive",
    value: function isCompetitive() {
      if (this.challengeType === 'groupCompetitiveTime' || this.challengeType === 'groupCompetitivePerformance') {
        return true;
      }

      return false;
    }
  }, {
    key: "isHome",
    value: function isHome() {
      return this.position === 'home';
    }
  }]);

  return ChallengeUsersStatusComponent;
}();

ChallengeUsersStatusComponent.ɵfac = function ChallengeUsersStatusComponent_Factory(t) {
  return new (t || ChallengeUsersStatusComponent)(_angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵdirectiveInject"](src_app_core_shared_services_user_service__WEBPACK_IMPORTED_MODULE_2__.UserService), _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵdirectiveInject"](src_app_core_shared_services_error_service__WEBPACK_IMPORTED_MODULE_3__.ErrorService));
};

ChallengeUsersStatusComponent.ɵcmp = /*@__PURE__*/_angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵdefineComponent"]({
  type: ChallengeUsersStatusComponent,
  selectors: [["app-challenge-users-status"]],
  inputs: {
    status: "status",
    rowStatus: "rowStatus",
    type: "type",
    otherUser: "otherUser",
    position: "position",
    challengeType: "challengeType"
  },
  decls: 1,
  vars: 1,
  consts: [[4, "ngIf"], [1, "ion-no-padding"], ["size", "2", 4, "ngIf"], [1, "ion-align-items-center"], ["size", "1", 4, "ngIf"], [1, "ion-text-start"], ["class", "ion-align-items-center", 4, "ngIf"], ["class", "ion-no-padding", 4, "ngIf"], ["size", "2"], ["alt", "avatar", 3, "src"], ["size", "1"], [3, "ngClass"], [1, "ion-text-end", "ion-align-items-center"], [1, "ion-text-end"], ["class", "ion-text-end ion-align-items-center", 4, "ngIf"], ["class", "ion-text-end", 4, "ngIf"]],
  template: function ChallengeUsersStatusComponent_Template(rf, ctx) {
    if (rf & 1) {
      _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵtemplate"](0, ChallengeUsersStatusComponent_div_0_Template, 16, 9, "div", 0);
    }

    if (rf & 2) {
      _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵproperty"]("ngIf", ctx.type !== "future" || ctx.otherUser);
    }
  },
  directives: [_angular_common__WEBPACK_IMPORTED_MODULE_6__.NgIf, _ionic_angular__WEBPACK_IMPORTED_MODULE_7__.IonGrid, _ionic_angular__WEBPACK_IMPORTED_MODULE_7__.IonRow, _ionic_angular__WEBPACK_IMPORTED_MODULE_7__.IonCol, _ionic_angular__WEBPACK_IMPORTED_MODULE_7__.IonAvatar, _angular_common__WEBPACK_IMPORTED_MODULE_6__.NgClass],
  pipes: [_angular_common__WEBPACK_IMPORTED_MODULE_6__.AsyncPipe],
  styles: ["ion-avatar[_ngcontent-%COMP%] {\n  width: 10vw;\n  height: 10vw;\n  margin: auto;\n  padding: 4px;\n}\nion-avatar[_ngcontent-%COMP%]   img[_ngcontent-%COMP%] {\n  object-fit: contain;\n  border-radius: 50% !important;\n  border: lightgray solid 1px;\n}\n.arrow-up[_ngcontent-%COMP%] {\n  width: 0;\n  height: 0;\n  border-left: 5px solid transparent;\n  border-right: 5px solid transparent;\n  border-bottom: 5px solid green;\n}\n.arrow-down[_ngcontent-%COMP%] {\n  width: 0;\n  height: 0;\n  border-left: 5px solid transparent;\n  border-right: 5px solid transparent;\n  border-top: 5px solid #f00;\n}\n/*# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbImNoYWxsZW5nZS11c2Vycy1zdGF0dXMuY29tcG9uZW50LnNjc3MiXSwibmFtZXMiOltdLCJtYXBwaW5ncyI6IkFBQUE7RUFDRSxXQUFBO0VBQ0EsWUFBQTtFQUNBLFlBQUE7RUFNQSxZQUFBO0FBSkY7QUFERTtFQUNFLG1CQUFBO0VBQ0EsNkJBQUE7RUFDQSwyQkFBQTtBQUdKO0FBQ0E7RUFDRSxRQUFBO0VBQ0EsU0FBQTtFQUNBLGtDQUFBO0VBQ0EsbUNBQUE7RUFFQSw4QkFBQTtBQUNGO0FBQ0E7RUFDRSxRQUFBO0VBQ0EsU0FBQTtFQUNBLGtDQUFBO0VBQ0EsbUNBQUE7RUFDQSwwQkFBQTtBQUVGIiwiZmlsZSI6ImNoYWxsZW5nZS11c2Vycy1zdGF0dXMuY29tcG9uZW50LnNjc3MiLCJzb3VyY2VzQ29udGVudCI6WyJpb24tYXZhdGFyIHtcbiAgd2lkdGg6IDEwdnc7XG4gIGhlaWdodDogMTB2dztcbiAgbWFyZ2luOiBhdXRvO1xuICBpbWcge1xuICAgIG9iamVjdC1maXQ6IGNvbnRhaW47XG4gICAgYm9yZGVyLXJhZGl1czogNTAlICFpbXBvcnRhbnQ7XG4gICAgYm9yZGVyOiBsaWdodGdyYXkgc29saWQgMXB4O1xuICB9XG4gIHBhZGRpbmc6IDRweDtcbn1cbi5hcnJvdy11cCB7XG4gIHdpZHRoOiAwO1xuICBoZWlnaHQ6IDA7XG4gIGJvcmRlci1sZWZ0OiA1cHggc29saWQgdHJhbnNwYXJlbnQ7XG4gIGJvcmRlci1yaWdodDogNXB4IHNvbGlkIHRyYW5zcGFyZW50O1xuXG4gIGJvcmRlci1ib3R0b206IDVweCBzb2xpZCBncmVlbjtcbn1cbi5hcnJvdy1kb3duIHtcbiAgd2lkdGg6IDA7XG4gIGhlaWdodDogMDtcbiAgYm9yZGVyLWxlZnQ6IDVweCBzb2xpZCB0cmFuc3BhcmVudDtcbiAgYm9yZGVyLXJpZ2h0OiA1cHggc29saWQgdHJhbnNwYXJlbnQ7XG4gIGJvcmRlci10b3A6IDVweCBzb2xpZCAjZjAwO1xufVxuIl19 */"]
});

/***/ }),

/***/ 96784:
/*!************************************************************************************************************!*\
  !*** ./src/app/core/shared/campaigns/home-widget-types/home-campaign-city/home-campaign-city.component.ts ***!
  \************************************************************************************************************/
/***/ (function(__unused_webpack_module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "HomeCampaignCityComponent": function() { return /* binding */ HomeCampaignCityComponent; }
/* harmony export */ });
/* harmony import */ var _Users_smartcommunitylab_Documents_work_projects_dslab_playgo_mobile_playgo_mobile_node_modules_babel_runtime_helpers_esm_classCallCheck_js__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./node_modules/@babel/runtime/helpers/esm/classCallCheck.js */ 78069);
/* harmony import */ var _Users_smartcommunitylab_Documents_work_projects_dslab_playgo_mobile_playgo_mobile_node_modules_babel_runtime_helpers_esm_createClass_js__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ./node_modules/@babel/runtime/helpers/esm/createClass.js */ 48047);
/* harmony import */ var luxon__WEBPACK_IMPORTED_MODULE_12__ = __webpack_require__(/*! luxon */ 29527);
/* harmony import */ var _time_utils__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! ../../../time.utils */ 93462);
/* harmony import */ var _utils__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! ../../../utils */ 68647);
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_11__ = __webpack_require__(/*! @angular/core */ 3184);
/* harmony import */ var src_app_core_shared_services_user_service__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! src/app/core/shared/services/user.service */ 50749);
/* harmony import */ var src_app_core_shared_services_report_service__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! src/app/core/shared/services/report.service */ 93981);
/* harmony import */ var _services_error_service__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! ../../../services/error.service */ 96204);
/* harmony import */ var _ionic_angular__WEBPACK_IMPORTED_MODULE_13__ = __webpack_require__(/*! @ionic/angular */ 93819);
/* harmony import */ var _angular_common__WEBPACK_IMPORTED_MODULE_14__ = __webpack_require__(/*! @angular/common */ 36362);
/* harmony import */ var _notification_badge_notification_badge_component__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(/*! ../notification-badge/notification-badge.component */ 36036);
/* harmony import */ var _main_campaign_stat_main_campaign_stat_component__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(/*! ../../main-campaign-stat/main-campaign-stat.component */ 61646);
/* harmony import */ var _app_widget_campaign_app_home_campaign_challenges_app_home_campaign_challenges_component__WEBPACK_IMPORTED_MODULE_9__ = __webpack_require__(/*! ../../app-widget-campaign/app-home-campaign-challenges/app-home-campaign-challenges.component */ 40201);
/* harmony import */ var _pipes_languageMap_pipe__WEBPACK_IMPORTED_MODULE_10__ = __webpack_require__(/*! ../../../pipes/languageMap.pipe */ 73088);
















function HomeCampaignCityComponent_app_notification_badge_1_Template(rf, ctx) {
  if (rf & 1) {
    _angular_core__WEBPACK_IMPORTED_MODULE_11__["ɵɵelement"](0, "app-notification-badge", 6);
  }

  if (rf & 2) {
    var ctx_r0 = _angular_core__WEBPACK_IMPORTED_MODULE_11__["ɵɵnextContext"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_11__["ɵɵproperty"]("type", "campaign")("campaignContainer", ctx_r0.campaignContainer);
  }
}

function HomeCampaignCityComponent_ion_card_header_2_Template(rf, ctx) {
  if (rf & 1) {
    _angular_core__WEBPACK_IMPORTED_MODULE_11__["ɵɵelementStart"](0, "ion-card-header", 7)(1, "div", 8)(2, "ion-avatar");
    _angular_core__WEBPACK_IMPORTED_MODULE_11__["ɵɵelement"](3, "img", 9);
    _angular_core__WEBPACK_IMPORTED_MODULE_11__["ɵɵelementEnd"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_11__["ɵɵelementStart"](4, "strong");
    _angular_core__WEBPACK_IMPORTED_MODULE_11__["ɵɵtext"](5);
    _angular_core__WEBPACK_IMPORTED_MODULE_11__["ɵɵpipe"](6, "languageMap");
    _angular_core__WEBPACK_IMPORTED_MODULE_11__["ɵɵelementEnd"]()()();
  }

  if (rf & 2) {
    var ctx_r1 = _angular_core__WEBPACK_IMPORTED_MODULE_11__["ɵɵnextContext"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_11__["ɵɵadvance"](3);
    _angular_core__WEBPACK_IMPORTED_MODULE_11__["ɵɵproperty"]("src", ctx_r1.imagePath, _angular_core__WEBPACK_IMPORTED_MODULE_11__["ɵɵsanitizeUrl"]);
    _angular_core__WEBPACK_IMPORTED_MODULE_11__["ɵɵadvance"](2);
    _angular_core__WEBPACK_IMPORTED_MODULE_11__["ɵɵtextInterpolate1"](" ", _angular_core__WEBPACK_IMPORTED_MODULE_11__["ɵɵpipeBind1"](6, 2, ctx_r1.campaignContainer.campaign.name), "");
  }
}

function HomeCampaignCityComponent_app_home_campaign_challenges_5_Template(rf, ctx) {
  if (rf & 1) {
    _angular_core__WEBPACK_IMPORTED_MODULE_11__["ɵɵelement"](0, "app-home-campaign-challenges", 10);
  }

  if (rf & 2) {
    var ctx_r2 = _angular_core__WEBPACK_IMPORTED_MODULE_11__["ɵɵnextContext"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_11__["ɵɵproperty"]("campaignContainer", ctx_r2.campaignContainer);
  }
}

var HomeCampaignCityComponent = /*#__PURE__*/function () {
  function HomeCampaignCityComponent(userService, reportService, errorService) {
    (0,_Users_smartcommunitylab_Documents_work_projects_dslab_playgo_mobile_playgo_mobile_node_modules_babel_runtime_helpers_esm_classCallCheck_js__WEBPACK_IMPORTED_MODULE_0__["default"])(this, HomeCampaignCityComponent);

    this.userService = userService;
    this.reportService = reportService;
    this.errorService = errorService;
    this.header = false;
  }

  (0,_Users_smartcommunitylab_Documents_work_projects_dslab_playgo_mobile_playgo_mobile_node_modules_babel_runtime_helpers_esm_createClass_js__WEBPACK_IMPORTED_MODULE_1__["default"])(HomeCampaignCityComponent, [{
    key: "ngOnInit",
    value: function ngOnInit() {
      var _this = this;

      this.imagePath = this.campaignContainer.campaign.logo.url ? this.campaignContainer.campaign.logo.url : 'data:image/jpg;base64,' + this.campaignContainer.campaign.logo.image;
      this.subStat = this.userService.userProfile$.subscribe(function (profile) {
        // this.status = status;
        _this.reportService.getGameStatus(_this.campaignContainer.campaign.campaignId).subscribe(function (campaignStatus) {
          _this.campaignStatus = campaignStatus;
        }, function (error) {
          if ((0,_utils__WEBPACK_IMPORTED_MODULE_3__.isOfflineError)(error)) {
            _this.campaignStatus = null;
          } else {
            _this.campaignStatus = null;

            _this.errorService.handleError(error);
          }
        });

        _this.reportService.getGameStats(_this.campaignContainer.campaign.campaignId, profile.playerId, (0,_time_utils__WEBPACK_IMPORTED_MODULE_2__.toServerDateOnly)(luxon__WEBPACK_IMPORTED_MODULE_12__.DateTime.utc().minus({
          week: 1
        })), (0,_time_utils__WEBPACK_IMPORTED_MODULE_2__.toServerDateOnly)(luxon__WEBPACK_IMPORTED_MODULE_12__.DateTime.utc())).subscribe(function (stats) {
          _this.reportWeekStat = stats;
        }, function (error) {
          if ((0,_utils__WEBPACK_IMPORTED_MODULE_3__.isOfflineError)(error)) {
            _this.reportWeekStat = null;
          } else {
            _this.reportWeekStat = null;

            _this.errorService.handleError(error);
          }
        });

        _this.reportService.getGameStats(_this.campaignContainer.campaign.campaignId, profile.playerId).subscribe(function (stats) {
          _this.reportTotalStat = stats;
        }, function (error) {
          if ((0,_utils__WEBPACK_IMPORTED_MODULE_3__.isOfflineError)(error)) {
            _this.reportTotalStat = null;
          } else {
            _this.reportTotalStat = null;

            _this.errorService.handleError(error);
          }
        });
      });
    }
  }, {
    key: "ngOnDestroy",
    value: function ngOnDestroy() {
      this.subStat.unsubscribe();
    }
  }]);

  return HomeCampaignCityComponent;
}();

HomeCampaignCityComponent.ɵfac = function HomeCampaignCityComponent_Factory(t) {
  return new (t || HomeCampaignCityComponent)(_angular_core__WEBPACK_IMPORTED_MODULE_11__["ɵɵdirectiveInject"](src_app_core_shared_services_user_service__WEBPACK_IMPORTED_MODULE_4__.UserService), _angular_core__WEBPACK_IMPORTED_MODULE_11__["ɵɵdirectiveInject"](src_app_core_shared_services_report_service__WEBPACK_IMPORTED_MODULE_5__.ReportService), _angular_core__WEBPACK_IMPORTED_MODULE_11__["ɵɵdirectiveInject"](_services_error_service__WEBPACK_IMPORTED_MODULE_6__.ErrorService));
};

HomeCampaignCityComponent.ɵcmp = /*@__PURE__*/_angular_core__WEBPACK_IMPORTED_MODULE_11__["ɵɵdefineComponent"]({
  type: HomeCampaignCityComponent,
  selectors: [["app-home-campaign-city"]],
  inputs: {
    campaignContainer: "campaignContainer",
    header: "header"
  },
  decls: 6,
  vars: 7,
  consts: [[1, "home-card-widget"], [3, "type", "campaignContainer", 4, "ngIf"], ["color", "city", 4, "ngIf"], [1, "city-content"], [3, "campaignContainer", "status", "reportWeekStat", "reportTotalStat"], [3, "campaignContainer", 4, "ngIf"], [3, "type", "campaignContainer"], ["color", "city"], ["lines", "none", "color", "city"], ["alt", "Avatar", 3, "src"], [3, "campaignContainer"]],
  template: function HomeCampaignCityComponent_Template(rf, ctx) {
    if (rf & 1) {
      _angular_core__WEBPACK_IMPORTED_MODULE_11__["ɵɵelementStart"](0, "ion-card", 0);
      _angular_core__WEBPACK_IMPORTED_MODULE_11__["ɵɵtemplate"](1, HomeCampaignCityComponent_app_notification_badge_1_Template, 1, 2, "app-notification-badge", 1);
      _angular_core__WEBPACK_IMPORTED_MODULE_11__["ɵɵtemplate"](2, HomeCampaignCityComponent_ion_card_header_2_Template, 7, 4, "ion-card-header", 2);
      _angular_core__WEBPACK_IMPORTED_MODULE_11__["ɵɵelementStart"](3, "ion-card-content", 3);
      _angular_core__WEBPACK_IMPORTED_MODULE_11__["ɵɵelement"](4, "app-main-campaign-stat", 4);
      _angular_core__WEBPACK_IMPORTED_MODULE_11__["ɵɵtemplate"](5, HomeCampaignCityComponent_app_home_campaign_challenges_5_Template, 1, 1, "app-home-campaign-challenges", 5);
      _angular_core__WEBPACK_IMPORTED_MODULE_11__["ɵɵelementEnd"]()();
    }

    if (rf & 2) {
      _angular_core__WEBPACK_IMPORTED_MODULE_11__["ɵɵadvance"](1);
      _angular_core__WEBPACK_IMPORTED_MODULE_11__["ɵɵproperty"]("ngIf", ctx.header);
      _angular_core__WEBPACK_IMPORTED_MODULE_11__["ɵɵadvance"](1);
      _angular_core__WEBPACK_IMPORTED_MODULE_11__["ɵɵproperty"]("ngIf", ctx.header);
      _angular_core__WEBPACK_IMPORTED_MODULE_11__["ɵɵadvance"](2);
      _angular_core__WEBPACK_IMPORTED_MODULE_11__["ɵɵproperty"]("campaignContainer", ctx.campaignContainer)("status", ctx.campaignStatus)("reportWeekStat", ctx.reportWeekStat)("reportTotalStat", ctx.reportTotalStat);
      _angular_core__WEBPACK_IMPORTED_MODULE_11__["ɵɵadvance"](1);
      _angular_core__WEBPACK_IMPORTED_MODULE_11__["ɵɵproperty"]("ngIf", ctx.header);
    }
  },
  directives: [_ionic_angular__WEBPACK_IMPORTED_MODULE_13__.IonCard, _angular_common__WEBPACK_IMPORTED_MODULE_14__.NgIf, _notification_badge_notification_badge_component__WEBPACK_IMPORTED_MODULE_7__.NotificationBadgeComponent, _ionic_angular__WEBPACK_IMPORTED_MODULE_13__.IonCardHeader, _ionic_angular__WEBPACK_IMPORTED_MODULE_13__.IonAvatar, _ionic_angular__WEBPACK_IMPORTED_MODULE_13__.IonCardContent, _main_campaign_stat_main_campaign_stat_component__WEBPACK_IMPORTED_MODULE_8__.MainCampaignStatComponent, _app_widget_campaign_app_home_campaign_challenges_app_home_campaign_challenges_component__WEBPACK_IMPORTED_MODULE_9__.HomeCampaignChallengeComponent],
  pipes: [_pipes_languageMap_pipe__WEBPACK_IMPORTED_MODULE_10__.LanguageMapPipe],
  styles: [".city-content[_ngcontent-%COMP%] {\n  color: black;\n}\n\nion-card[_ngcontent-%COMP%] {\n  overflow: visible;\n}\n\nion-card[_ngcontent-%COMP%]   ion-card-header[_ngcontent-%COMP%] {\n  border-radius: 10px 10px 0px 0px;\n  text-align: left;\n}\n\nion-card[_ngcontent-%COMP%]   ion-card-header[_ngcontent-%COMP%]   div[_ngcontent-%COMP%]   ion-avatar[_ngcontent-%COMP%] {\n  --border-radius: 50%;\n  border: solid 3px var(--ion-color-city);\n  background-color: var(--ion-color-city);\n  position: absolute;\n  z-index: 2;\n  text-align: center;\n  right: 20px;\n}\n/*# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbImhvbWUtY2FtcGFpZ24tY2l0eS5jb21wb25lbnQuc2NzcyJdLCJuYW1lcyI6W10sIm1hcHBpbmdzIjoiQUFBQTtFQUNFLFlBQUE7QUFDRjs7QUFDQTtFQUNFLGlCQUFBO0FBRUY7O0FBREU7RUFDRSxnQ0FBQTtFQUNBLGdCQUFBO0FBR0o7O0FBRkk7RUFDRSxvQkFBQTtFQUNBLHVDQUFBO0VBQ0EsdUNBQUE7RUFDQSxrQkFBQTtFQUNBLFVBQUE7RUFDQSxrQkFBQTtFQUNBLFdBQUE7QUFJTiIsImZpbGUiOiJob21lLWNhbXBhaWduLWNpdHkuY29tcG9uZW50LnNjc3MiLCJzb3VyY2VzQ29udGVudCI6WyIuY2l0eS1jb250ZW50IHtcbiAgY29sb3I6IGJsYWNrO1xufVxuaW9uLWNhcmQge1xuICBvdmVyZmxvdzogdmlzaWJsZTtcbiAgaW9uLWNhcmQtaGVhZGVyIHtcbiAgICBib3JkZXItcmFkaXVzOiAxMHB4IDEwcHggMHB4IDBweDtcbiAgICB0ZXh0LWFsaWduOiBsZWZ0O1xuICAgIGRpdiBpb24tYXZhdGFyIHtcbiAgICAgIC0tYm9yZGVyLXJhZGl1czogNTAlO1xuICAgICAgYm9yZGVyOiBzb2xpZCAzcHggdmFyKC0taW9uLWNvbG9yLWNpdHkpO1xuICAgICAgYmFja2dyb3VuZC1jb2xvcjogdmFyKC0taW9uLWNvbG9yLWNpdHkpO1xuICAgICAgcG9zaXRpb246IGFic29sdXRlO1xuICAgICAgei1pbmRleDogMjtcbiAgICAgIHRleHQtYWxpZ246IGNlbnRlcjtcbiAgICAgIHJpZ2h0OiAyMHB4O1xuICAgIH1cbiAgfVxufVxuIl19 */"]
});

/***/ }),

/***/ 10881:
/*!******************************************************************************************************************!*\
  !*** ./src/app/core/shared/campaigns/home-widget-types/home-campaign-company/home-campaign-company.component.ts ***!
  \******************************************************************************************************************/
/***/ (function(__unused_webpack_module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "HomeCampaignCompanyComponent": function() { return /* binding */ HomeCampaignCompanyComponent; }
/* harmony export */ });
/* harmony import */ var _Users_smartcommunitylab_Documents_work_projects_dslab_playgo_mobile_playgo_mobile_node_modules_babel_runtime_helpers_esm_classCallCheck_js__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./node_modules/@babel/runtime/helpers/esm/classCallCheck.js */ 78069);
/* harmony import */ var _Users_smartcommunitylab_Documents_work_projects_dslab_playgo_mobile_playgo_mobile_node_modules_babel_runtime_helpers_esm_createClass_js__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ./node_modules/@babel/runtime/helpers/esm/createClass.js */ 48047);
/* harmony import */ var luxon__WEBPACK_IMPORTED_MODULE_11__ = __webpack_require__(/*! luxon */ 29527);
/* harmony import */ var _time_utils__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! ../../../time.utils */ 93462);
/* harmony import */ var _utils__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! ../../../utils */ 68647);
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_10__ = __webpack_require__(/*! @angular/core */ 3184);
/* harmony import */ var _services_user_service__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! ../../../services/user.service */ 50749);
/* harmony import */ var _services_report_service__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! ../../../services/report.service */ 93981);
/* harmony import */ var _services_error_service__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! ../../../services/error.service */ 96204);
/* harmony import */ var _ionic_angular__WEBPACK_IMPORTED_MODULE_12__ = __webpack_require__(/*! @ionic/angular */ 93819);
/* harmony import */ var _angular_common__WEBPACK_IMPORTED_MODULE_13__ = __webpack_require__(/*! @angular/common */ 36362);
/* harmony import */ var _notification_badge_notification_badge_component__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(/*! ../notification-badge/notification-badge.component */ 36036);
/* harmony import */ var _main_campaign_stat_main_campaign_stat_component__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(/*! ../../main-campaign-stat/main-campaign-stat.component */ 61646);
/* harmony import */ var _pipes_languageMap_pipe__WEBPACK_IMPORTED_MODULE_9__ = __webpack_require__(/*! ../../../pipes/languageMap.pipe */ 73088);















function HomeCampaignCompanyComponent_app_notification_badge_1_Template(rf, ctx) {
  if (rf & 1) {
    _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵelement"](0, "app-notification-badge", 5);
  }

  if (rf & 2) {
    var ctx_r0 = _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵnextContext"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵproperty"]("type", "campaign")("campaignContainer", ctx_r0.campaignContainer);
  }
}

function HomeCampaignCompanyComponent_ion_card_header_2_Template(rf, ctx) {
  if (rf & 1) {
    _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵelementStart"](0, "ion-card-header", 6)(1, "div", 7)(2, "ion-avatar");
    _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵelement"](3, "img", 8);
    _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵelementEnd"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵelementStart"](4, "strong");
    _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵtext"](5);
    _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵpipe"](6, "languageMap");
    _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵelementEnd"]()()();
  }

  if (rf & 2) {
    var ctx_r1 = _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵnextContext"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵadvance"](3);
    _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵproperty"]("src", ctx_r1.imagePath, _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵsanitizeUrl"]);
    _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵadvance"](2);
    _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵtextInterpolate1"](" ", _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵpipeBind1"](6, 2, ctx_r1.campaignContainer.campaign.name), "");
  }
}

var HomeCampaignCompanyComponent = /*#__PURE__*/function () {
  function HomeCampaignCompanyComponent(userService, reportService, errorService) {
    (0,_Users_smartcommunitylab_Documents_work_projects_dslab_playgo_mobile_playgo_mobile_node_modules_babel_runtime_helpers_esm_classCallCheck_js__WEBPACK_IMPORTED_MODULE_0__["default"])(this, HomeCampaignCompanyComponent);

    this.userService = userService;
    this.reportService = reportService;
    this.errorService = errorService;
    this.header = false;
  }

  (0,_Users_smartcommunitylab_Documents_work_projects_dslab_playgo_mobile_playgo_mobile_node_modules_babel_runtime_helpers_esm_createClass_js__WEBPACK_IMPORTED_MODULE_1__["default"])(HomeCampaignCompanyComponent, [{
    key: "ngOnInit",
    value: function ngOnInit() {
      var _this = this;

      this.imagePath = this.campaignContainer.campaign.logo.url ? this.campaignContainer.campaign.logo.url : 'data:image/jpg;base64,' + this.campaignContainer.campaign.logo.image;
      this.subStat = this.userService.userProfile$.subscribe(function (profile) {
        _this.profile = profile;

        _this.reportService.getBikeStats(_this.campaignContainer.campaign.campaignId, _this.profile.playerId, (0,_time_utils__WEBPACK_IMPORTED_MODULE_2__.toServerDateOnly)(luxon__WEBPACK_IMPORTED_MODULE_11__.DateTime.utc().minus({
          day: 1
        })), (0,_time_utils__WEBPACK_IMPORTED_MODULE_2__.toServerDateOnly)(luxon__WEBPACK_IMPORTED_MODULE_11__.DateTime.utc())).then(function (stats) {
          _this.reportDayStat = stats;
        }).catch(function (error) {
          if ((0,_utils__WEBPACK_IMPORTED_MODULE_3__.isOfflineError)(error)) {
            _this.reportDayStat = null;
          } else {
            _this.reportDayStat = null;

            _this.errorService.handleError(error);
          }
        });

        _this.reportService.getBikeStats(_this.campaignContainer.campaign.campaignId, _this.profile.playerId, (0,_time_utils__WEBPACK_IMPORTED_MODULE_2__.toServerDateOnly)(luxon__WEBPACK_IMPORTED_MODULE_11__.DateTime.utc().minus({
          month: 1
        })), (0,_time_utils__WEBPACK_IMPORTED_MODULE_2__.toServerDateOnly)(luxon__WEBPACK_IMPORTED_MODULE_11__.DateTime.utc())).then(function (stats) {
          _this.reportMonthStat = stats;
        }).catch(function (error) {
          if ((0,_utils__WEBPACK_IMPORTED_MODULE_3__.isOfflineError)(error)) {
            _this.reportMonthStat = null;
          } else {
            _this.reportMonthStat = null;

            _this.errorService.handleError(error);
          }
        });

        _this.reportService.getBikeStats(_this.campaignContainer.campaign.campaignId, _this.profile.playerId).then(function (stats) {
          _this.reportTotalStat = stats;
        }).catch(function (error) {
          if ((0,_utils__WEBPACK_IMPORTED_MODULE_3__.isOfflineError)(error)) {
            _this.reportTotalStat = null;
          } else {
            _this.reportTotalStat = null;

            _this.errorService.handleError(error);
          }
        });
      });
    }
  }, {
    key: "goToChallenge",
    value: function goToChallenge(event) {
      if (event && event.stopPropagation) {
        console.log('goToChallenge - stopPropagation');
        event.stopPropagation();
      }

      console.log('goToChallenge');
    }
  }, {
    key: "ngOnDestroy",
    value: function ngOnDestroy() {
      this.subStat.unsubscribe();
    }
  }]);

  return HomeCampaignCompanyComponent;
}();

HomeCampaignCompanyComponent.ɵfac = function HomeCampaignCompanyComponent_Factory(t) {
  return new (t || HomeCampaignCompanyComponent)(_angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵdirectiveInject"](_services_user_service__WEBPACK_IMPORTED_MODULE_4__.UserService), _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵdirectiveInject"](_services_report_service__WEBPACK_IMPORTED_MODULE_5__.ReportService), _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵdirectiveInject"](_services_error_service__WEBPACK_IMPORTED_MODULE_6__.ErrorService));
};

HomeCampaignCompanyComponent.ɵcmp = /*@__PURE__*/_angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵdefineComponent"]({
  type: HomeCampaignCompanyComponent,
  selectors: [["app-home-campaign-company"]],
  inputs: {
    campaignContainer: "campaignContainer",
    header: "header"
  },
  decls: 5,
  vars: 10,
  consts: [[1, "home-card-widget"], [3, "type", "campaignContainer", 4, "ngIf"], ["color", "company", 4, "ngIf"], [1, "company-content"], [3, "campaignContainer", "reportMonthStat", "showRanking", "reportTotalStat", "limitMonthMax", "limitMonthValue", "limitDayMax", "limitDayValue"], [3, "type", "campaignContainer"], ["color", "company"], ["lines", "none", "color", "company"], ["alt", "Avatar", 3, "src"]],
  template: function HomeCampaignCompanyComponent_Template(rf, ctx) {
    if (rf & 1) {
      _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵelementStart"](0, "ion-card", 0);
      _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵtemplate"](1, HomeCampaignCompanyComponent_app_notification_badge_1_Template, 1, 2, "app-notification-badge", 1);
      _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵtemplate"](2, HomeCampaignCompanyComponent_ion_card_header_2_Template, 7, 4, "ion-card-header", 2);
      _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵelementStart"](3, "ion-card-content", 3);
      _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵelement"](4, "app-main-campaign-stat", 4);
      _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵelementEnd"]()();
    }

    if (rf & 2) {
      _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵadvance"](1);
      _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵproperty"]("ngIf", ctx.header);
      _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵadvance"](1);
      _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵproperty"]("ngIf", ctx.header);
      _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵadvance"](2);
      _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵproperty"]("campaignContainer", ctx.campaignContainer)("reportMonthStat", ctx.reportMonthStat)("showRanking", false)("reportTotalStat", ctx.reportTotalStat)("limitMonthMax", ctx.campaignContainer == null ? null : ctx.campaignContainer.campaign == null ? null : ctx.campaignContainer.campaign.specificData == null ? null : ctx.campaignContainer.campaign.specificData.bike == null ? null : ctx.campaignContainer.campaign.specificData.bike.monthlyLimit)("limitMonthValue", ctx.reportMonthStat)("limitDayMax", ctx.campaignContainer == null ? null : ctx.campaignContainer.campaign == null ? null : ctx.campaignContainer.campaign.specificData == null ? null : ctx.campaignContainer.campaign.specificData.bike == null ? null : ctx.campaignContainer.campaign.specificData.bike.dailyLimit)("limitDayValue", ctx.reportDayStat);
    }
  },
  directives: [_ionic_angular__WEBPACK_IMPORTED_MODULE_12__.IonCard, _angular_common__WEBPACK_IMPORTED_MODULE_13__.NgIf, _notification_badge_notification_badge_component__WEBPACK_IMPORTED_MODULE_7__.NotificationBadgeComponent, _ionic_angular__WEBPACK_IMPORTED_MODULE_12__.IonCardHeader, _ionic_angular__WEBPACK_IMPORTED_MODULE_12__.IonAvatar, _ionic_angular__WEBPACK_IMPORTED_MODULE_12__.IonCardContent, _main_campaign_stat_main_campaign_stat_component__WEBPACK_IMPORTED_MODULE_8__.MainCampaignStatComponent],
  pipes: [_pipes_languageMap_pipe__WEBPACK_IMPORTED_MODULE_9__.LanguageMapPipe],
  styles: [".company-content[_ngcontent-%COMP%] {\n  color: black;\n}\n\nion-card[_ngcontent-%COMP%] {\n  overflow: visible;\n}\n\nion-card[_ngcontent-%COMP%]   #challenge[_ngcontent-%COMP%] {\n  overflow: visible;\n}\n\nion-card[_ngcontent-%COMP%]   ion-card-header[_ngcontent-%COMP%] {\n  border-radius: 10px 10px 0px 0px;\n  text-align: left;\n}\n\nion-card[_ngcontent-%COMP%]   ion-card-header[_ngcontent-%COMP%]   div[_ngcontent-%COMP%]   ion-avatar[_ngcontent-%COMP%] {\n  --border-radius: 50%;\n  border: solid 3px var(--ion-color-company);\n  background-color: var(--ion-color-company);\n  position: absolute;\n  z-index: 2;\n  text-align: center;\n  right: 20px;\n}\n/*# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbImhvbWUtY2FtcGFpZ24tY29tcGFueS5jb21wb25lbnQuc2NzcyJdLCJuYW1lcyI6W10sIm1hcHBpbmdzIjoiQUFBQTtFQUVFLFlBQUE7QUFBRjs7QUFHQTtFQUNFLGlCQUFBO0FBQUY7O0FBQ0U7RUFDRSxpQkFBQTtBQUNKOztBQUNFO0VBQ0UsZ0NBQUE7RUFDQSxnQkFBQTtBQUNKOztBQUFJO0VBQ0Usb0JBQUE7RUFDQSwwQ0FBQTtFQUNBLDBDQUFBO0VBQ0Esa0JBQUE7RUFDQSxVQUFBO0VBQ0Esa0JBQUE7RUFDQSxXQUFBO0FBRU4iLCJmaWxlIjoiaG9tZS1jYW1wYWlnbi1jb21wYW55LmNvbXBvbmVudC5zY3NzIiwic291cmNlc0NvbnRlbnQiOlsiLmNvbXBhbnktY29udGVudCB7XG4gIC8vICAgYmFja2dyb3VuZC1jb2xvcjogdmFyKC0taW9uLWNvbG9yLWNvbXBhbnktc2hhZGUpO1xuICBjb2xvcjogYmxhY2s7XG59XG5cbmlvbi1jYXJkIHtcbiAgb3ZlcmZsb3c6IHZpc2libGU7XG4gICNjaGFsbGVuZ2Uge1xuICAgIG92ZXJmbG93OiB2aXNpYmxlO1xuICB9XG4gIGlvbi1jYXJkLWhlYWRlciB7XG4gICAgYm9yZGVyLXJhZGl1czogMTBweCAxMHB4IDBweCAwcHg7XG4gICAgdGV4dC1hbGlnbjogbGVmdDtcbiAgICBkaXYgaW9uLWF2YXRhciB7XG4gICAgICAtLWJvcmRlci1yYWRpdXM6IDUwJTtcbiAgICAgIGJvcmRlcjogc29saWQgM3B4IHZhcigtLWlvbi1jb2xvci1jb21wYW55KTtcbiAgICAgIGJhY2tncm91bmQtY29sb3I6IHZhcigtLWlvbi1jb2xvci1jb21wYW55KTtcbiAgICAgIHBvc2l0aW9uOiBhYnNvbHV0ZTtcbiAgICAgIHotaW5kZXg6IDI7XG4gICAgICB0ZXh0LWFsaWduOiBjZW50ZXI7XG4gICAgICByaWdodDogMjBweDtcbiAgICB9XG4gIH1cbn1cbiJdfQ== */"]
});

/***/ }),

/***/ 90706:
/*!********************************************************************************************************************!*\
  !*** ./src/app/core/shared/campaigns/home-widget-types/home-campaign-personal/home-campaign-personal.component.ts ***!
  \********************************************************************************************************************/
/***/ (function(__unused_webpack_module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "HomeCampaignPersonalComponent": function() { return /* binding */ HomeCampaignPersonalComponent; }
/* harmony export */ });
/* harmony import */ var _Users_smartcommunitylab_Documents_work_projects_dslab_playgo_mobile_playgo_mobile_node_modules_babel_runtime_helpers_esm_classCallCheck_js__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./node_modules/@babel/runtime/helpers/esm/classCallCheck.js */ 78069);
/* harmony import */ var _Users_smartcommunitylab_Documents_work_projects_dslab_playgo_mobile_playgo_mobile_node_modules_babel_runtime_helpers_esm_createClass_js__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ./node_modules/@babel/runtime/helpers/esm/createClass.js */ 48047);
/* harmony import */ var luxon__WEBPACK_IMPORTED_MODULE_11__ = __webpack_require__(/*! luxon */ 29527);
/* harmony import */ var _time_utils__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! ../../../time.utils */ 93462);
/* harmony import */ var _utils__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! ../../../utils */ 68647);
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_10__ = __webpack_require__(/*! @angular/core */ 3184);
/* harmony import */ var src_app_core_shared_services_user_service__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! src/app/core/shared/services/user.service */ 50749);
/* harmony import */ var src_app_core_shared_services_report_service__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! src/app/core/shared/services/report.service */ 93981);
/* harmony import */ var _services_error_service__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! ../../../services/error.service */ 96204);
/* harmony import */ var _ionic_angular__WEBPACK_IMPORTED_MODULE_12__ = __webpack_require__(/*! @ionic/angular */ 93819);
/* harmony import */ var _angular_common__WEBPACK_IMPORTED_MODULE_13__ = __webpack_require__(/*! @angular/common */ 36362);
/* harmony import */ var _notification_badge_notification_badge_component__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(/*! ../notification-badge/notification-badge.component */ 36036);
/* harmony import */ var _main_campaign_stat_main_campaign_stat_component__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(/*! ../../main-campaign-stat/main-campaign-stat.component */ 61646);
/* harmony import */ var _pipes_languageMap_pipe__WEBPACK_IMPORTED_MODULE_9__ = __webpack_require__(/*! ../../../pipes/languageMap.pipe */ 73088);















function HomeCampaignPersonalComponent_ion_card_header_1_Template(rf, ctx) {
  if (rf & 1) {
    _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵelementStart"](0, "ion-card-header", 4)(1, "div", 5)(2, "ion-avatar");
    _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵelement"](3, "img", 6);
    _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵelementEnd"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵelementStart"](4, "strong");
    _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵtext"](5);
    _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵpipe"](6, "languageMap");
    _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵelementEnd"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵelement"](7, "app-notification-badge", 7);
    _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵelementEnd"]()();
  }

  if (rf & 2) {
    var ctx_r0 = _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵnextContext"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵadvance"](3);
    _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵproperty"]("src", ctx_r0.imagePath, _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵsanitizeUrl"]);
    _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵadvance"](2);
    _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵtextInterpolate1"](" ", _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵpipeBind1"](6, 3, ctx_r0.campaignContainer.campaign.name), "");
    _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵadvance"](2);
    _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵproperty"]("campaignContainer", ctx_r0.campaignContainer);
  }
}

var HomeCampaignPersonalComponent = /*#__PURE__*/function () {
  function HomeCampaignPersonalComponent(userService, reportService, errorService) {
    (0,_Users_smartcommunitylab_Documents_work_projects_dslab_playgo_mobile_playgo_mobile_node_modules_babel_runtime_helpers_esm_classCallCheck_js__WEBPACK_IMPORTED_MODULE_0__["default"])(this, HomeCampaignPersonalComponent);

    this.userService = userService;
    this.reportService = reportService;
    this.errorService = errorService;
    this.header = false;
  }

  (0,_Users_smartcommunitylab_Documents_work_projects_dslab_playgo_mobile_playgo_mobile_node_modules_babel_runtime_helpers_esm_createClass_js__WEBPACK_IMPORTED_MODULE_1__["default"])(HomeCampaignPersonalComponent, [{
    key: "ngOnInit",
    value: function ngOnInit() {
      var _this = this;

      this.imagePath = this.campaignContainer.campaign.logo.url ? this.campaignContainer.campaign.logo.url : 'data:image/jpg;base64,' + this.campaignContainer.campaign.logo.image;
      this.subStat = this.userService.userProfile$.subscribe(function (profile) {
        _this.profile = profile;

        _this.reportService.getCo2Stats(_this.campaignContainer.campaign.campaignId, _this.profile.playerId, (0,_time_utils__WEBPACK_IMPORTED_MODULE_2__.toServerDateOnly)(luxon__WEBPACK_IMPORTED_MODULE_11__.DateTime.utc().minus({
          week: 1
        })), (0,_time_utils__WEBPACK_IMPORTED_MODULE_2__.toServerDateOnly)(luxon__WEBPACK_IMPORTED_MODULE_11__.DateTime.utc())).then(function (stats) {
          _this.reportWeekStat = stats;
        }).catch(function (error) {
          if ((0,_utils__WEBPACK_IMPORTED_MODULE_3__.isOfflineError)(error)) {
            _this.reportWeekStat = null;
          } else {
            _this.reportWeekStat = null;

            _this.errorService.handleError(error);
          }
        });

        _this.reportService.getCo2WeekRecord(_this.campaignContainer.campaign.campaignId, _this.profile.playerId).then(function (record) {
          _this.record = record[0];
        }).catch(function (error) {
          if ((0,_utils__WEBPACK_IMPORTED_MODULE_3__.isOfflineError)(error)) {
            _this.record = null;
          } else {
            _this.record = null;

            _this.errorService.handleError(error);
          }
        });

        _this.reportService.getCo2Stats(_this.campaignContainer.campaign.campaignId, _this.profile.playerId).then(function (stats) {
          _this.reportTotalStat = stats;
        }).catch(function (error) {
          if ((0,_utils__WEBPACK_IMPORTED_MODULE_3__.isOfflineError)(error)) {
            _this.reportTotalStat = null;
          } else {
            _this.reportTotalStat = null;

            _this.errorService.handleError(error);
          }
        });
      });
    }
  }, {
    key: "ngOnDestroy",
    value: function ngOnDestroy() {
      this.subStat.unsubscribe();
    }
  }]);

  return HomeCampaignPersonalComponent;
}();

HomeCampaignPersonalComponent.ɵfac = function HomeCampaignPersonalComponent_Factory(t) {
  return new (t || HomeCampaignPersonalComponent)(_angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵdirectiveInject"](src_app_core_shared_services_user_service__WEBPACK_IMPORTED_MODULE_4__.UserService), _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵdirectiveInject"](src_app_core_shared_services_report_service__WEBPACK_IMPORTED_MODULE_5__.ReportService), _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵdirectiveInject"](_services_error_service__WEBPACK_IMPORTED_MODULE_6__.ErrorService));
};

HomeCampaignPersonalComponent.ɵcmp = /*@__PURE__*/_angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵdefineComponent"]({
  type: HomeCampaignPersonalComponent,
  selectors: [["app-home-campaign-personal"]],
  inputs: {
    campaignContainer: "campaignContainer",
    header: "header"
  },
  decls: 4,
  vars: 5,
  consts: [[1, "home-card-widget"], ["color", "personal", 4, "ngIf"], [1, "personal-content"], [3, "campaignContainer", "reportWeekStat", "record", "reportTotalStat"], ["color", "personal"], ["lines", "none", "color", "personal"], ["alt", "Avatar", 3, "src"], [3, "campaignContainer"]],
  template: function HomeCampaignPersonalComponent_Template(rf, ctx) {
    if (rf & 1) {
      _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵelementStart"](0, "ion-card", 0);
      _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵtemplate"](1, HomeCampaignPersonalComponent_ion_card_header_1_Template, 8, 5, "ion-card-header", 1);
      _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵelementStart"](2, "ion-card-content", 2);
      _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵelement"](3, "app-main-campaign-stat", 3);
      _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵelementEnd"]()();
    }

    if (rf & 2) {
      _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵadvance"](1);
      _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵproperty"]("ngIf", ctx.header);
      _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵadvance"](2);
      _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵproperty"]("campaignContainer", ctx.campaignContainer)("reportWeekStat", ctx.reportWeekStat)("record", ctx.record)("reportTotalStat", ctx.reportTotalStat);
    }
  },
  directives: [_ionic_angular__WEBPACK_IMPORTED_MODULE_12__.IonCard, _angular_common__WEBPACK_IMPORTED_MODULE_13__.NgIf, _ionic_angular__WEBPACK_IMPORTED_MODULE_12__.IonCardHeader, _ionic_angular__WEBPACK_IMPORTED_MODULE_12__.IonAvatar, _notification_badge_notification_badge_component__WEBPACK_IMPORTED_MODULE_7__.NotificationBadgeComponent, _ionic_angular__WEBPACK_IMPORTED_MODULE_12__.IonCardContent, _main_campaign_stat_main_campaign_stat_component__WEBPACK_IMPORTED_MODULE_8__.MainCampaignStatComponent],
  pipes: [_pipes_languageMap_pipe__WEBPACK_IMPORTED_MODULE_9__.LanguageMapPipe],
  styles: ["ion-card-header[_ngcontent-%COMP%] {\n  text-align: left;\n  border-radius: 10px 10px 0px 0px;\n}\nion-card-header[_ngcontent-%COMP%]   div[_ngcontent-%COMP%]   ion-avatar[_ngcontent-%COMP%] {\n  --border-radius: 50%;\n  border: solid 3px var(--ion-color-personal);\n  background-color: var(--ion-color-personal);\n  position: absolute;\n  z-index: 2;\n  text-align: center;\n  right: 20px;\n}\n/*# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbImhvbWUtY2FtcGFpZ24tcGVyc29uYWwuY29tcG9uZW50LnNjc3MiXSwibmFtZXMiOltdLCJtYXBwaW5ncyI6IkFBSUE7RUFDRSxnQkFBQTtFQUNBLGdDQUFBO0FBSEY7QUFJRTtFQUNFLG9CQUFBO0VBQ0EsMkNBQUE7RUFDQSwyQ0FBQTtFQUNBLGtCQUFBO0VBQ0EsVUFBQTtFQUNBLGtCQUFBO0VBQ0EsV0FBQTtBQUZKIiwiZmlsZSI6ImhvbWUtY2FtcGFpZ24tcGVyc29uYWwuY29tcG9uZW50LnNjc3MiLCJzb3VyY2VzQ29udGVudCI6WyIucGVyc29uYWwtY29udGVudCB7XG4gIC8vICAgYmFja2dyb3VuZC1jb2xvcjogdmFyKC0taW9uLWNvbG9yLXBlcnNvbmFsLXNoYWRlKTtcbiAgLy8gICBjb2xvcjogd2hpdGU7XG59XG5pb24tY2FyZC1oZWFkZXIge1xuICB0ZXh0LWFsaWduOiBsZWZ0O1xuICBib3JkZXItcmFkaXVzOiAxMHB4IDEwcHggMHB4IDBweDtcbiAgZGl2IGlvbi1hdmF0YXIge1xuICAgIC0tYm9yZGVyLXJhZGl1czogNTAlO1xuICAgIGJvcmRlcjogc29saWQgM3B4IHZhcigtLWlvbi1jb2xvci1wZXJzb25hbCk7XG4gICAgYmFja2dyb3VuZC1jb2xvcjogdmFyKC0taW9uLWNvbG9yLXBlcnNvbmFsKTtcbiAgICBwb3NpdGlvbjogYWJzb2x1dGU7XG4gICAgei1pbmRleDogMjtcbiAgICB0ZXh0LWFsaWduOiBjZW50ZXI7XG4gICAgcmlnaHQ6IDIwcHg7XG4gIH1cbn1cbiJdfQ== */"]
});

/***/ }),

/***/ 37374:
/*!****************************************************************************************************************!*\
  !*** ./src/app/core/shared/campaigns/home-widget-types/home-campaign-school/home-campaign-school.component.ts ***!
  \****************************************************************************************************************/
/***/ (function(__unused_webpack_module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "HomeCampaignSchoolComponent": function() { return /* binding */ HomeCampaignSchoolComponent; }
/* harmony export */ });
/* harmony import */ var _Users_smartcommunitylab_Documents_work_projects_dslab_playgo_mobile_playgo_mobile_node_modules_babel_runtime_helpers_esm_classCallCheck_js__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./node_modules/@babel/runtime/helpers/esm/classCallCheck.js */ 78069);
/* harmony import */ var _Users_smartcommunitylab_Documents_work_projects_dslab_playgo_mobile_playgo_mobile_node_modules_babel_runtime_helpers_esm_createClass_js__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ./node_modules/@babel/runtime/helpers/esm/createClass.js */ 48047);
/* harmony import */ var luxon__WEBPACK_IMPORTED_MODULE_12__ = __webpack_require__(/*! luxon */ 29527);
/* harmony import */ var _time_utils__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! ../../../time.utils */ 93462);
/* harmony import */ var _utils__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! ../../../utils */ 68647);
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_11__ = __webpack_require__(/*! @angular/core */ 3184);
/* harmony import */ var _services_user_service__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! ../../../services/user.service */ 50749);
/* harmony import */ var _services_report_service__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! ../../../services/report.service */ 93981);
/* harmony import */ var _services_error_service__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! ../../../services/error.service */ 96204);
/* harmony import */ var _ionic_angular__WEBPACK_IMPORTED_MODULE_13__ = __webpack_require__(/*! @ionic/angular */ 93819);
/* harmony import */ var _angular_common__WEBPACK_IMPORTED_MODULE_14__ = __webpack_require__(/*! @angular/common */ 36362);
/* harmony import */ var _notification_badge_notification_badge_component__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(/*! ../notification-badge/notification-badge.component */ 36036);
/* harmony import */ var _main_campaign_stat_main_campaign_stat_component__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(/*! ../../main-campaign-stat/main-campaign-stat.component */ 61646);
/* harmony import */ var _app_widget_campaign_app_home_campaign_challenges_app_home_campaign_challenges_component__WEBPACK_IMPORTED_MODULE_9__ = __webpack_require__(/*! ../../app-widget-campaign/app-home-campaign-challenges/app-home-campaign-challenges.component */ 40201);
/* harmony import */ var _pipes_languageMap_pipe__WEBPACK_IMPORTED_MODULE_10__ = __webpack_require__(/*! ../../../pipes/languageMap.pipe */ 73088);
















function HomeCampaignSchoolComponent_app_notification_badge_1_Template(rf, ctx) {
  if (rf & 1) {
    _angular_core__WEBPACK_IMPORTED_MODULE_11__["ɵɵelement"](0, "app-notification-badge", 6);
  }

  if (rf & 2) {
    var ctx_r0 = _angular_core__WEBPACK_IMPORTED_MODULE_11__["ɵɵnextContext"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_11__["ɵɵproperty"]("type", "campaign")("campaignContainer", ctx_r0.campaignContainer);
  }
}

function HomeCampaignSchoolComponent_ion_card_header_2_Template(rf, ctx) {
  if (rf & 1) {
    _angular_core__WEBPACK_IMPORTED_MODULE_11__["ɵɵelementStart"](0, "ion-card-header", 7)(1, "div", 8)(2, "ion-avatar");
    _angular_core__WEBPACK_IMPORTED_MODULE_11__["ɵɵelement"](3, "img", 9);
    _angular_core__WEBPACK_IMPORTED_MODULE_11__["ɵɵelementEnd"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_11__["ɵɵelementStart"](4, "strong");
    _angular_core__WEBPACK_IMPORTED_MODULE_11__["ɵɵtext"](5);
    _angular_core__WEBPACK_IMPORTED_MODULE_11__["ɵɵpipe"](6, "languageMap");
    _angular_core__WEBPACK_IMPORTED_MODULE_11__["ɵɵelementEnd"]()()();
  }

  if (rf & 2) {
    var ctx_r1 = _angular_core__WEBPACK_IMPORTED_MODULE_11__["ɵɵnextContext"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_11__["ɵɵadvance"](3);
    _angular_core__WEBPACK_IMPORTED_MODULE_11__["ɵɵproperty"]("src", ctx_r1.imagePath, _angular_core__WEBPACK_IMPORTED_MODULE_11__["ɵɵsanitizeUrl"]);
    _angular_core__WEBPACK_IMPORTED_MODULE_11__["ɵɵadvance"](2);
    _angular_core__WEBPACK_IMPORTED_MODULE_11__["ɵɵtextInterpolate1"](" ", _angular_core__WEBPACK_IMPORTED_MODULE_11__["ɵɵpipeBind1"](6, 2, ctx_r1.campaignContainer.campaign.name), "");
  }
}

function HomeCampaignSchoolComponent_app_home_campaign_challenges_5_Template(rf, ctx) {
  if (rf & 1) {
    _angular_core__WEBPACK_IMPORTED_MODULE_11__["ɵɵelement"](0, "app-home-campaign-challenges", 10);
  }

  if (rf & 2) {
    var ctx_r2 = _angular_core__WEBPACK_IMPORTED_MODULE_11__["ɵɵnextContext"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_11__["ɵɵproperty"]("campaignContainer", ctx_r2.campaignContainer);
  }
}

var HomeCampaignSchoolComponent = /*#__PURE__*/function () {
  function HomeCampaignSchoolComponent(userService, reportService, errorService) {
    (0,_Users_smartcommunitylab_Documents_work_projects_dslab_playgo_mobile_playgo_mobile_node_modules_babel_runtime_helpers_esm_classCallCheck_js__WEBPACK_IMPORTED_MODULE_0__["default"])(this, HomeCampaignSchoolComponent);

    this.userService = userService;
    this.reportService = reportService;
    this.errorService = errorService;
    this.header = false;
  }

  (0,_Users_smartcommunitylab_Documents_work_projects_dslab_playgo_mobile_playgo_mobile_node_modules_babel_runtime_helpers_esm_createClass_js__WEBPACK_IMPORTED_MODULE_1__["default"])(HomeCampaignSchoolComponent, [{
    key: "ngOnInit",
    value: function ngOnInit() {
      var _this = this;

      this.imagePath = this.campaignContainer.campaign.logo.url ? this.campaignContainer.campaign.logo.url : 'data:image/jpg;base64,' + this.campaignContainer.campaign.logo.image;
      this.subStat = this.userService.userProfile$.subscribe(function (profile) {
        // this.status = status;
        _this.reportService.getGameStatus(_this.campaignContainer.campaign.campaignId).subscribe(function (campaignStatus) {
          _this.campaignStatus = campaignStatus;
        }, function (error) {
          if ((0,_utils__WEBPACK_IMPORTED_MODULE_3__.isOfflineError)(error)) {
            _this.campaignStatus = null;
          } else {
            _this.campaignStatus = null;

            _this.errorService.handleError(error);
          }
        });

        _this.reportService.getGameStats(_this.campaignContainer.campaign.campaignId, profile.playerId, (0,_time_utils__WEBPACK_IMPORTED_MODULE_2__.toServerDateOnly)(luxon__WEBPACK_IMPORTED_MODULE_12__.DateTime.utc().minus({
          week: 1
        })), (0,_time_utils__WEBPACK_IMPORTED_MODULE_2__.toServerDateOnly)(luxon__WEBPACK_IMPORTED_MODULE_12__.DateTime.utc())).subscribe(function (stats) {
          _this.reportTotalStat = stats;
        }, function (error) {
          if ((0,_utils__WEBPACK_IMPORTED_MODULE_3__.isOfflineError)(error)) {
            _this.reportTotalStat = null;
          } else {
            _this.reportTotalStat = null;

            _this.errorService.handleError(error);
          }
        });

        _this.reportService.getGameStats(_this.campaignContainer.campaign.campaignId, profile.playerId).subscribe(function (stats) {
          _this.reportTotalStat = stats;
        }, function (error) {
          if ((0,_utils__WEBPACK_IMPORTED_MODULE_3__.isOfflineError)(error)) {
            _this.reportTotalStat = null;
          } else {
            _this.reportTotalStat = null;

            _this.errorService.handleError(error);
          }
        });
      });
    }
  }, {
    key: "goToChallenge",
    value: function goToChallenge(event) {
      if (event && event.stopPropagation) {
        console.log('goToChallenge - stopPropagation');
        event.stopPropagation();
      }

      console.log('goToChallenge');
    }
  }, {
    key: "ngOnDestroy",
    value: function ngOnDestroy() {
      this.subStat.unsubscribe();
    }
  }]);

  return HomeCampaignSchoolComponent;
}();

HomeCampaignSchoolComponent.ɵfac = function HomeCampaignSchoolComponent_Factory(t) {
  return new (t || HomeCampaignSchoolComponent)(_angular_core__WEBPACK_IMPORTED_MODULE_11__["ɵɵdirectiveInject"](_services_user_service__WEBPACK_IMPORTED_MODULE_4__.UserService), _angular_core__WEBPACK_IMPORTED_MODULE_11__["ɵɵdirectiveInject"](_services_report_service__WEBPACK_IMPORTED_MODULE_5__.ReportService), _angular_core__WEBPACK_IMPORTED_MODULE_11__["ɵɵdirectiveInject"](_services_error_service__WEBPACK_IMPORTED_MODULE_6__.ErrorService));
};

HomeCampaignSchoolComponent.ɵcmp = /*@__PURE__*/_angular_core__WEBPACK_IMPORTED_MODULE_11__["ɵɵdefineComponent"]({
  type: HomeCampaignSchoolComponent,
  selectors: [["app-home-campaign-school"]],
  inputs: {
    campaignContainer: "campaignContainer",
    header: "header"
  },
  decls: 6,
  vars: 7,
  consts: [[1, "home-card-widget"], [3, "type", "campaignContainer", 4, "ngIf"], ["color", "school", 4, "ngIf"], [1, "school-content"], [3, "campaignContainer", "status", "reportWeekStat", "reportTotalStat"], [3, "campaignContainer", 4, "ngIf"], [3, "type", "campaignContainer"], ["color", "school"], ["lines", "none", "color", "school"], ["alt", "Avatar", 3, "src"], [3, "campaignContainer"]],
  template: function HomeCampaignSchoolComponent_Template(rf, ctx) {
    if (rf & 1) {
      _angular_core__WEBPACK_IMPORTED_MODULE_11__["ɵɵelementStart"](0, "ion-card", 0);
      _angular_core__WEBPACK_IMPORTED_MODULE_11__["ɵɵtemplate"](1, HomeCampaignSchoolComponent_app_notification_badge_1_Template, 1, 2, "app-notification-badge", 1);
      _angular_core__WEBPACK_IMPORTED_MODULE_11__["ɵɵtemplate"](2, HomeCampaignSchoolComponent_ion_card_header_2_Template, 7, 4, "ion-card-header", 2);
      _angular_core__WEBPACK_IMPORTED_MODULE_11__["ɵɵelementStart"](3, "ion-card-content", 3);
      _angular_core__WEBPACK_IMPORTED_MODULE_11__["ɵɵelement"](4, "app-main-campaign-stat", 4);
      _angular_core__WEBPACK_IMPORTED_MODULE_11__["ɵɵtemplate"](5, HomeCampaignSchoolComponent_app_home_campaign_challenges_5_Template, 1, 1, "app-home-campaign-challenges", 5);
      _angular_core__WEBPACK_IMPORTED_MODULE_11__["ɵɵelementEnd"]()();
    }

    if (rf & 2) {
      _angular_core__WEBPACK_IMPORTED_MODULE_11__["ɵɵadvance"](1);
      _angular_core__WEBPACK_IMPORTED_MODULE_11__["ɵɵproperty"]("ngIf", ctx.header);
      _angular_core__WEBPACK_IMPORTED_MODULE_11__["ɵɵadvance"](1);
      _angular_core__WEBPACK_IMPORTED_MODULE_11__["ɵɵproperty"]("ngIf", ctx.header);
      _angular_core__WEBPACK_IMPORTED_MODULE_11__["ɵɵadvance"](2);
      _angular_core__WEBPACK_IMPORTED_MODULE_11__["ɵɵproperty"]("campaignContainer", ctx.campaignContainer)("status", ctx.campaignStatus)("reportWeekStat", ctx.reportWeekStat)("reportTotalStat", ctx.reportTotalStat);
      _angular_core__WEBPACK_IMPORTED_MODULE_11__["ɵɵadvance"](1);
      _angular_core__WEBPACK_IMPORTED_MODULE_11__["ɵɵproperty"]("ngIf", ctx.header);
    }
  },
  directives: [_ionic_angular__WEBPACK_IMPORTED_MODULE_13__.IonCard, _angular_common__WEBPACK_IMPORTED_MODULE_14__.NgIf, _notification_badge_notification_badge_component__WEBPACK_IMPORTED_MODULE_7__.NotificationBadgeComponent, _ionic_angular__WEBPACK_IMPORTED_MODULE_13__.IonCardHeader, _ionic_angular__WEBPACK_IMPORTED_MODULE_13__.IonAvatar, _ionic_angular__WEBPACK_IMPORTED_MODULE_13__.IonCardContent, _main_campaign_stat_main_campaign_stat_component__WEBPACK_IMPORTED_MODULE_8__.MainCampaignStatComponent, _app_widget_campaign_app_home_campaign_challenges_app_home_campaign_challenges_component__WEBPACK_IMPORTED_MODULE_9__.HomeCampaignChallengeComponent],
  pipes: [_pipes_languageMap_pipe__WEBPACK_IMPORTED_MODULE_10__.LanguageMapPipe],
  styles: [".school-content[_ngcontent-%COMP%] {\n  color: black;\n}\n\nion-card[_ngcontent-%COMP%] {\n  overflow: visible;\n}\n\nion-card[_ngcontent-%COMP%]   #challenge[_ngcontent-%COMP%] {\n  overflow: visible;\n}\n\nion-card[_ngcontent-%COMP%]   ion-card-header[_ngcontent-%COMP%] {\n  text-align: left;\n  border-radius: 10px 10px 0px 0px;\n}\n\nion-card[_ngcontent-%COMP%]   ion-card-header[_ngcontent-%COMP%]   div[_ngcontent-%COMP%]   ion-avatar[_ngcontent-%COMP%] {\n  --border-radius: 50%;\n  border: solid 3px var(--ion-color-school);\n  background-color: var(--ion-color-school);\n  position: absolute;\n  z-index: 2;\n  text-align: center;\n  right: 20px;\n}\n/*# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbImhvbWUtY2FtcGFpZ24tc2Nob29sLmNvbXBvbmVudC5zY3NzIl0sIm5hbWVzIjpbXSwibWFwcGluZ3MiOiJBQUFBO0VBRUUsWUFBQTtBQUFGOztBQUVBO0VBQ0UsaUJBQUE7QUFDRjs7QUFBRTtFQUNFLGlCQUFBO0FBRUo7O0FBQUU7RUFDRSxnQkFBQTtFQUNBLGdDQUFBO0FBRUo7O0FBREk7RUFDRSxvQkFBQTtFQUNBLHlDQUFBO0VBQ0EseUNBQUE7RUFDQSxrQkFBQTtFQUNBLFVBQUE7RUFDQSxrQkFBQTtFQUNBLFdBQUE7QUFHTiIsImZpbGUiOiJob21lLWNhbXBhaWduLXNjaG9vbC5jb21wb25lbnQuc2NzcyIsInNvdXJjZXNDb250ZW50IjpbIi5zY2hvb2wtY29udGVudCB7XG4gIC8vICAgYmFja2dyb3VuZC1jb2xvcjogdmFyKC0taW9uLWNvbG9yLXNjaG9vbC10aW50KTtcbiAgY29sb3I6IGJsYWNrO1xufVxuaW9uLWNhcmQge1xuICBvdmVyZmxvdzogdmlzaWJsZTtcbiAgI2NoYWxsZW5nZSB7XG4gICAgb3ZlcmZsb3c6IHZpc2libGU7XG4gIH1cbiAgaW9uLWNhcmQtaGVhZGVyIHtcbiAgICB0ZXh0LWFsaWduOiBsZWZ0O1xuICAgIGJvcmRlci1yYWRpdXM6IDEwcHggMTBweCAwcHggMHB4O1xuICAgIGRpdiBpb24tYXZhdGFyIHtcbiAgICAgIC0tYm9yZGVyLXJhZGl1czogNTAlO1xuICAgICAgYm9yZGVyOiBzb2xpZCAzcHggdmFyKC0taW9uLWNvbG9yLXNjaG9vbCk7XG4gICAgICBiYWNrZ3JvdW5kLWNvbG9yOiB2YXIoLS1pb24tY29sb3Itc2Nob29sKTtcbiAgICAgIHBvc2l0aW9uOiBhYnNvbHV0ZTtcbiAgICAgIHotaW5kZXg6IDI7XG4gICAgICB0ZXh0LWFsaWduOiBjZW50ZXI7XG4gICAgICByaWdodDogMjBweDtcbiAgICB9XG4gIH1cbn1cbiJdfQ== */"]
});

/***/ }),

/***/ 36036:
/*!************************************************************************************************************!*\
  !*** ./src/app/core/shared/campaigns/home-widget-types/notification-badge/notification-badge.component.ts ***!
  \************************************************************************************************************/
/***/ (function(__unused_webpack_module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "NotificationBadgeComponent": function() { return /* binding */ NotificationBadgeComponent; }
/* harmony export */ });
/* harmony import */ var _Users_smartcommunitylab_Documents_work_projects_dslab_playgo_mobile_playgo_mobile_node_modules_babel_runtime_helpers_esm_classCallCheck_js__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./node_modules/@babel/runtime/helpers/esm/classCallCheck.js */ 78069);
/* harmony import */ var _Users_smartcommunitylab_Documents_work_projects_dslab_playgo_mobile_playgo_mobile_node_modules_babel_runtime_helpers_esm_createClass_js__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ./node_modules/@babel/runtime/helpers/esm/createClass.js */ 48047);
/* harmony import */ var rxjs__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! rxjs */ 19337);
/* harmony import */ var rxjs__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! rxjs */ 20591);
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @angular/core */ 3184);
/* harmony import */ var _services_notifications_notifications_service__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! ../../../services/notifications/notifications.service */ 30299);
/* harmony import */ var _angular_common__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! @angular/common */ 36362);
/* harmony import */ var _ionic_angular__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(/*! @ionic/angular */ 93819);








function NotificationBadgeComponent_ion_badge_0_Template(rf, ctx) {
  if (rf & 1) {
    _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵelementStart"](0, "ion-badge", 1);
    _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵelement"](1, "ion-icon", 2);
    _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵelementEnd"]();
  }
}

var NotificationBadgeComponent = /*#__PURE__*/function () {
  function NotificationBadgeComponent(notificationService, cdRef) {
    (0,_Users_smartcommunitylab_Documents_work_projects_dslab_playgo_mobile_playgo_mobile_node_modules_babel_runtime_helpers_esm_classCallCheck_js__WEBPACK_IMPORTED_MODULE_0__["default"])(this, NotificationBadgeComponent);

    this.notificationService = notificationService;
    this.cdRef = cdRef;
    this.numberOfNotification = 0;
  }

  (0,_Users_smartcommunitylab_Documents_work_projects_dslab_playgo_mobile_playgo_mobile_node_modules_babel_runtime_helpers_esm_createClass_js__WEBPACK_IMPORTED_MODULE_1__["default"])(NotificationBadgeComponent, [{
    key: "ngOnInit",
    value: function ngOnInit() {
      var _this = this;

      this.unreadNotification$ = this.getNotifObservable(this.type).pipe((0,rxjs__WEBPACK_IMPORTED_MODULE_4__.tap)(function (notifications) {
        console.log('unread campaign notification', notifications);
        _this.numberOfNotification = notifications.length; // this.cdRef.detectChanges();
      }));
      this.subUnread = this.unreadNotification$.subscribe();
    }
  }, {
    key: "getNotifObservable",
    value: function getNotifObservable(type) {
      switch (type) {
        case 'campaign':
          return this.notificationService.getUnreadCampaignNotifications(this.campaignContainer.campaign.campaignId);

        case 'challenge':
          return this.notificationService.getUnreadCampaignChallengeNotifications(this.campaignContainer.campaign.campaignId);

        default:
          return rxjs__WEBPACK_IMPORTED_MODULE_5__.EMPTY;
      }
    }
  }, {
    key: "ngOnDestroy",
    value: function ngOnDestroy() {
      this.subUnread.unsubscribe();
    }
  }]);

  return NotificationBadgeComponent;
}();

NotificationBadgeComponent.ɵfac = function NotificationBadgeComponent_Factory(t) {
  return new (t || NotificationBadgeComponent)(_angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵdirectiveInject"](_services_notifications_notifications_service__WEBPACK_IMPORTED_MODULE_2__.NotificationService), _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵdirectiveInject"](_angular_core__WEBPACK_IMPORTED_MODULE_3__.ChangeDetectorRef));
};

NotificationBadgeComponent.ɵcmp = /*@__PURE__*/_angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵdefineComponent"]({
  type: NotificationBadgeComponent,
  selectors: [["app-notification-badge"]],
  inputs: {
    campaignContainer: "campaignContainer",
    type: "type"
  },
  decls: 1,
  vars: 1,
  consts: [["color", "danger", 4, "ngIf"], ["color", "danger"], ["name", "alert-outline"]],
  template: function NotificationBadgeComponent_Template(rf, ctx) {
    if (rf & 1) {
      _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵtemplate"](0, NotificationBadgeComponent_ion_badge_0_Template, 2, 0, "ion-badge", 0);
    }

    if (rf & 2) {
      _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵproperty"]("ngIf", ctx.numberOfNotification > 0);
    }
  },
  directives: [_angular_common__WEBPACK_IMPORTED_MODULE_6__.NgIf, _ionic_angular__WEBPACK_IMPORTED_MODULE_7__.IonBadge, _ionic_angular__WEBPACK_IMPORTED_MODULE_7__.IonIcon],
  styles: [".school-content[_ngcontent-%COMP%] {\n  color: black;\n}\n\nion-badge[_ngcontent-%COMP%] {\n  position: absolute;\n  z-index: 99;\n  right: -8px;\n  top: -8px;\n}\n/*# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbIm5vdGlmaWNhdGlvbi1iYWRnZS5jb21wb25lbnQuc2NzcyJdLCJuYW1lcyI6W10sIm1hcHBpbmdzIjoiQUFBQTtFQUVFLFlBQUE7QUFBRjs7QUFFQTtFQUNFLGtCQUFBO0VBQ0EsV0FBQTtFQUNBLFdBQUE7RUFDQSxTQUFBO0FBQ0YiLCJmaWxlIjoibm90aWZpY2F0aW9uLWJhZGdlLmNvbXBvbmVudC5zY3NzIiwic291cmNlc0NvbnRlbnQiOlsiLnNjaG9vbC1jb250ZW50IHtcbiAgLy8gICBiYWNrZ3JvdW5kLWNvbG9yOiB2YXIoLS1pb24tY29sb3Itc2Nob29sLXRpbnQpO1xuICBjb2xvcjogYmxhY2s7XG59XG5pb24tYmFkZ2Uge1xuICBwb3NpdGlvbjogYWJzb2x1dGU7XG4gIHotaW5kZXg6IDk5O1xuICByaWdodDogLThweDtcbiAgdG9wOiAtOHB4O1xufVxuIl19 */"]
});

/***/ }),

/***/ 43471:
/*!***********************************************************************************************!*\
  !*** ./src/app/core/shared/campaigns/main-campaign-stat/game-status/game-status.component.ts ***!
  \***********************************************************************************************/
/***/ (function(__unused_webpack_module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "GameStatusComponent": function() { return /* binding */ GameStatusComponent; }
/* harmony export */ });
/* harmony import */ var _Users_smartcommunitylab_Documents_work_projects_dslab_playgo_mobile_playgo_mobile_node_modules_babel_runtime_helpers_esm_classCallCheck_js__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./node_modules/@babel/runtime/helpers/esm/classCallCheck.js */ 78069);
/* harmony import */ var _Users_smartcommunitylab_Documents_work_projects_dslab_playgo_mobile_playgo_mobile_node_modules_babel_runtime_helpers_esm_createClass_js__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ./node_modules/@babel/runtime/helpers/esm/createClass.js */ 48047);
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @angular/core */ 3184);
/* harmony import */ var _angular_common__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @angular/common */ 36362);
/* harmony import */ var _ionic_angular__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! @ionic/angular */ 93819);
/* harmony import */ var _ngx_translate_core__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! @ngx-translate/core */ 87514);







var _c0 = function _c0(a0) {
  return {
    levelName: a0
  };
};

var _c1 = function _c1(a0) {
  return {
    score: a0
  };
};

function GameStatusComponent_div_0_Template(rf, ctx) {
  if (rf & 1) {
    _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵelementStart"](0, "div", 1);
    _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵelement"](1, "span", 2);
    _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵpipe"](2, "translate");
    _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵelement"](3, "span", 2);
    _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵpipe"](4, "translate");
    _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵelementStart"](5, "div", 3);
    _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵelement"](6, "ion-progress-bar", 4);
    _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵelementEnd"]()();
  }

  if (rf & 2) {
    var ctx_r0 = _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵnextContext"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵadvance"](1);
    _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵproperty"]("innerHtml", _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵpipeBind2"](2, 4, "campaigns.homewidgets.stat.levelName", _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵpureFunction1"](10, _c0, ctx_r0.status == null ? null : ctx_r0.status.levels[0] == null ? null : ctx_r0.status.levels[0].levelValue)), _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵsanitizeHtml"]);
    _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵadvance"](2);
    _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵproperty"]("innerHtml", _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵpipeBind2"](4, 7, "campaigns.homewidgets.stat.score", _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵpureFunction1"](12, _c1, ctx_r0.status == null ? null : ctx_r0.status.score)), _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵsanitizeHtml"]);
    _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵadvance"](3);
    _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵproperty"]("color", ctx_r0.type)("value", ((ctx_r0.status == null ? null : ctx_r0.status.score) - (ctx_r0.status == null ? null : ctx_r0.status.levels[0] == null ? null : ctx_r0.status.levels[0].startLevelScore)) / ((ctx_r0.status == null ? null : ctx_r0.status.levels[0] == null ? null : ctx_r0.status.levels[0].endLevelScore) - (ctx_r0.status == null ? null : ctx_r0.status.levels[0] == null ? null : ctx_r0.status.levels[0].startLevelScore)));
  }
}

var GameStatusComponent = /*#__PURE__*/function () {
  function GameStatusComponent() {
    (0,_Users_smartcommunitylab_Documents_work_projects_dslab_playgo_mobile_playgo_mobile_node_modules_babel_runtime_helpers_esm_classCallCheck_js__WEBPACK_IMPORTED_MODULE_0__["default"])(this, GameStatusComponent);

    this.status = undefined;
  }

  (0,_Users_smartcommunitylab_Documents_work_projects_dslab_playgo_mobile_playgo_mobile_node_modules_babel_runtime_helpers_esm_createClass_js__WEBPACK_IMPORTED_MODULE_1__["default"])(GameStatusComponent, [{
    key: "ngOnInit",
    value: function ngOnInit() {}
  }]);

  return GameStatusComponent;
}();

GameStatusComponent.ɵfac = function GameStatusComponent_Factory(t) {
  return new (t || GameStatusComponent)();
};

GameStatusComponent.ɵcmp = /*@__PURE__*/_angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵdefineComponent"]({
  type: GameStatusComponent,
  selectors: [["app-game-status"]],
  inputs: {
    status: "status",
    type: "type"
  },
  decls: 1,
  vars: 1,
  consts: [["class", "ion-text-left", 4, "ngIf"], [1, "ion-text-left"], [3, "innerHtml"], [1, "progress-bar"], [1, "level-bar", 3, "color", "value"]],
  template: function GameStatusComponent_Template(rf, ctx) {
    if (rf & 1) {
      _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵtemplate"](0, GameStatusComponent_div_0_Template, 7, 14, "div", 0);
    }

    if (rf & 2) {
      _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵproperty"]("ngIf", ctx.status);
    }
  },
  directives: [_angular_common__WEBPACK_IMPORTED_MODULE_3__.NgIf, _ionic_angular__WEBPACK_IMPORTED_MODULE_4__.IonProgressBar],
  pipes: [_ngx_translate_core__WEBPACK_IMPORTED_MODULE_5__.TranslatePipe],
  styles: [".level-bar[_ngcontent-%COMP%] {\n  height: 20px;\n}\n/*# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbImdhbWUtc3RhdHVzLmNvbXBvbmVudC5zY3NzIl0sIm5hbWVzIjpbXSwibWFwcGluZ3MiOiJBQUFBO0VBQ0UsWUFBQTtBQUNGIiwiZmlsZSI6ImdhbWUtc3RhdHVzLmNvbXBvbmVudC5zY3NzIiwic291cmNlc0NvbnRlbnQiOlsiLmxldmVsLWJhciB7XG4gIGhlaWdodDogMjBweDtcbn1cbiJdfQ== */"]
});

/***/ }),

/***/ 78650:
/*!*************************************************************************************************!*\
  !*** ./src/app/core/shared/campaigns/main-campaign-stat/limit-status/limit-status.component.ts ***!
  \*************************************************************************************************/
/***/ (function(__unused_webpack_module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "LimitStatusComponent": function() { return /* binding */ LimitStatusComponent; }
/* harmony export */ });
/* harmony import */ var _Users_smartcommunitylab_Documents_work_projects_dslab_playgo_mobile_playgo_mobile_node_modules_babel_runtime_helpers_esm_classCallCheck_js__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./node_modules/@babel/runtime/helpers/esm/classCallCheck.js */ 78069);
/* harmony import */ var _Users_smartcommunitylab_Documents_work_projects_dslab_playgo_mobile_playgo_mobile_node_modules_babel_runtime_helpers_esm_createClass_js__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ./node_modules/@babel/runtime/helpers/esm/createClass.js */ 48047);
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @angular/core */ 3184);
/* harmony import */ var _angular_common__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! @angular/common */ 36362);
/* harmony import */ var _ionic_angular__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! @ionic/angular */ 93819);
/* harmony import */ var _pipes_localNumber_pipe__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! ../../../pipes/localNumber.pipe */ 89713);
/* harmony import */ var _ngx_translate_core__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! @ngx-translate/core */ 87514);








function LimitStatusComponent_div_0_ion_row_12_Template(rf, ctx) {
  if (rf & 1) {
    _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵelementStart"](0, "ion-row")(1, "ion-col", 7);
    _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵelement"](2, "ion-progress-bar", 8);
    _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵelementEnd"]()();
  }

  if (rf & 2) {
    var ctx_r1 = _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵnextContext"](2);
    _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵadvance"](2);
    _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵproperty"]("color", ctx_r1.type)("value", (ctx_r1.limitValue == null ? null : ctx_r1.limitValue.value) / ctx_r1.limitMax);
  }
}

function LimitStatusComponent_div_0_ng_template_13_Template(rf, ctx) {
  if (rf & 1) {
    _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵelementStart"](0, "ion-row")(1, "ion-col", 7);
    _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵelement"](2, "ion-progress-bar", 8);
    _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵelementEnd"]()();
  }

  if (rf & 2) {
    var ctx_r3 = _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵnextContext"](2);
    _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵadvance"](2);
    _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵproperty"]("color", ctx_r3.type)("value", 0);
  }
}

function LimitStatusComponent_div_0_Template(rf, ctx) {
  if (rf & 1) {
    _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵelementStart"](0, "div", 1)(1, "ion-grid")(2, "ion-row", 2)(3, "ion-col", 3)(4, "b");
    _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵtext"](5);
    _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵpipe"](6, "localNumber");
    _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵpipe"](7, "translate");
    _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵelementEnd"]()();
    _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵelementStart"](8, "ion-col", 4);
    _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵtext"](9);
    _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵpipe"](10, "translate");
    _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵpipe"](11, "translate");
    _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵelementEnd"]()();
    _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵtemplate"](12, LimitStatusComponent_div_0_ion_row_12_Template, 3, 2, "ion-row", 5);
    _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵtemplate"](13, LimitStatusComponent_div_0_ng_template_13_Template, 3, 2, "ng-template", null, 6, _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵtemplateRefExtractor"]);
    _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵelementEnd"]()();
  }

  if (rf & 2) {
    var _r2 = _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵreference"](14);

    var ctx_r0 = _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵnextContext"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵadvance"](5);
    _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵtextInterpolate3"]("", ctx_r0.header, " ", _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵpipeBind1"](6, 8, ctx_r0.limitValue == null ? null : ctx_r0.limitValue.value), "", _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵpipeBind1"](7, 10, "campaigns.homewidgets.stat.km"), "");
    _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵadvance"](4);
    _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵtextInterpolate3"](" ", ctx_r0.limitMax, "", _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵpipeBind1"](10, 12, "campaigns.homewidgets.stat.km"), " ", _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵpipeBind1"](11, 14, "campaigns.homewidgets.stat.max"), " ");
    _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵadvance"](3);
    _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵproperty"]("ngIf", ctx_r0.limitValue == null ? null : ctx_r0.limitValue.value)("ngIfElse", _r2);
  }
}

var LimitStatusComponent = /*#__PURE__*/function () {
  function LimitStatusComponent() {
    (0,_Users_smartcommunitylab_Documents_work_projects_dslab_playgo_mobile_playgo_mobile_node_modules_babel_runtime_helpers_esm_classCallCheck_js__WEBPACK_IMPORTED_MODULE_0__["default"])(this, LimitStatusComponent);

    this.limitMax = undefined;
    this.limitValue = undefined;
  }

  (0,_Users_smartcommunitylab_Documents_work_projects_dslab_playgo_mobile_playgo_mobile_node_modules_babel_runtime_helpers_esm_createClass_js__WEBPACK_IMPORTED_MODULE_1__["default"])(LimitStatusComponent, [{
    key: "ngOnInit",
    value: function ngOnInit() {
      console.log('limitMax' + this.limitMax + 'limitValue' + this.limitValue);
    }
  }]);

  return LimitStatusComponent;
}();

LimitStatusComponent.ɵfac = function LimitStatusComponent_Factory(t) {
  return new (t || LimitStatusComponent)();
};

LimitStatusComponent.ɵcmp = /*@__PURE__*/_angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵdefineComponent"]({
  type: LimitStatusComponent,
  selectors: [["app-limit-status"]],
  inputs: {
    limitMax: "limitMax",
    limitValue: "limitValue",
    type: "type",
    header: "header"
  },
  decls: 1,
  vars: 1,
  consts: [["class", "ion-text-left", 4, "ngIf"], [1, "ion-text-left"], [1, "limit-text"], ["size", "8"], ["size", "4", 1, "ion-text-end"], [4, "ngIf", "ngIfElse"], ["zeroProgress", ""], [1, "progress-bar"], [1, "level-bar", 3, "color", "value"]],
  template: function LimitStatusComponent_Template(rf, ctx) {
    if (rf & 1) {
      _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵtemplate"](0, LimitStatusComponent_div_0_Template, 15, 16, "div", 0);
    }

    if (rf & 2) {
      _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵproperty"]("ngIf", ctx.limitMax);
    }
  },
  directives: [_angular_common__WEBPACK_IMPORTED_MODULE_4__.NgIf, _ionic_angular__WEBPACK_IMPORTED_MODULE_5__.IonGrid, _ionic_angular__WEBPACK_IMPORTED_MODULE_5__.IonRow, _ionic_angular__WEBPACK_IMPORTED_MODULE_5__.IonCol, _ionic_angular__WEBPACK_IMPORTED_MODULE_5__.IonProgressBar],
  pipes: [_pipes_localNumber_pipe__WEBPACK_IMPORTED_MODULE_2__.LocalNumberPipe, _ngx_translate_core__WEBPACK_IMPORTED_MODULE_6__.TranslatePipe],
  styles: [".level-bar[_ngcontent-%COMP%] {\n  height: 20px;\n}\n\n.limit-text[_ngcontent-%COMP%] {\n  font-size: 14px;\n}\n/*# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbImxpbWl0LXN0YXR1cy5jb21wb25lbnQuc2NzcyJdLCJuYW1lcyI6W10sIm1hcHBpbmdzIjoiQUFBQTtFQUNFLFlBQUE7QUFDRjs7QUFDQTtFQUNFLGVBQUE7QUFFRiIsImZpbGUiOiJsaW1pdC1zdGF0dXMuY29tcG9uZW50LnNjc3MiLCJzb3VyY2VzQ29udGVudCI6WyIubGV2ZWwtYmFyIHtcbiAgaGVpZ2h0OiAyMHB4O1xufVxuLmxpbWl0LXRleHQge1xuICBmb250LXNpemU6IDE0cHg7XG59XG4iXX0= */"]
});

/***/ }),

/***/ 61646:
/*!******************************************************************************************!*\
  !*** ./src/app/core/shared/campaigns/main-campaign-stat/main-campaign-stat.component.ts ***!
  \******************************************************************************************/
/***/ (function(__unused_webpack_module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "MainCampaignStatComponent": function() { return /* binding */ MainCampaignStatComponent; }
/* harmony export */ });
/* harmony import */ var _Users_smartcommunitylab_Documents_work_projects_dslab_playgo_mobile_playgo_mobile_node_modules_babel_runtime_helpers_esm_classCallCheck_js__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./node_modules/@babel/runtime/helpers/esm/classCallCheck.js */ 78069);
/* harmony import */ var _Users_smartcommunitylab_Documents_work_projects_dslab_playgo_mobile_playgo_mobile_node_modules_babel_runtime_helpers_esm_createClass_js__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ./node_modules/@babel/runtime/helpers/esm/createClass.js */ 48047);
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(/*! @angular/core */ 3184);
/* harmony import */ var _services_campaign_service__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! ../../services/campaign.service */ 23645);
/* harmony import */ var _ionic_angular__WEBPACK_IMPORTED_MODULE_9__ = __webpack_require__(/*! @ionic/angular */ 93819);
/* harmony import */ var _angular_common__WEBPACK_IMPORTED_MODULE_10__ = __webpack_require__(/*! @angular/common */ 36362);
/* harmony import */ var _ui_icon_icon_component__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! ../../ui/icon/icon.component */ 71888);
/* harmony import */ var _game_status_game_status_component__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! ./game-status/game-status.component */ 43471);
/* harmony import */ var _record_status_record_status_component__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! ./record-status/record-status.component */ 13204);
/* harmony import */ var _limit_status_limit_status_component__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! ./limit-status/limit-status.component */ 78650);
/* harmony import */ var _ngx_translate_core__WEBPACK_IMPORTED_MODULE_11__ = __webpack_require__(/*! @ngx-translate/core */ 87514);
/* harmony import */ var _pipes_localNumber_pipe__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(/*! ../../pipes/localNumber.pipe */ 89713);













var _c0 = function _c0(a0) {
  return {
    position: a0
  };
};

function MainCampaignStatComponent_ion_row_2_ng_container_2_Template(rf, ctx) {
  if (rf & 1) {
    _angular_core__WEBPACK_IMPORTED_MODULE_8__["ɵɵelementContainerStart"](0);
    _angular_core__WEBPACK_IMPORTED_MODULE_8__["ɵɵelementStart"](1, "span", 8);
    _angular_core__WEBPACK_IMPORTED_MODULE_8__["ɵɵtext"](2);
    _angular_core__WEBPACK_IMPORTED_MODULE_8__["ɵɵpipe"](3, "translate");
    _angular_core__WEBPACK_IMPORTED_MODULE_8__["ɵɵelementEnd"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_8__["ɵɵelementContainerEnd"]();
  }

  if (rf & 2) {
    var ctx_r11 = _angular_core__WEBPACK_IMPORTED_MODULE_8__["ɵɵnextContext"](2);
    _angular_core__WEBPACK_IMPORTED_MODULE_8__["ɵɵadvance"](2);
    _angular_core__WEBPACK_IMPORTED_MODULE_8__["ɵɵtextInterpolate1"](" ", _angular_core__WEBPACK_IMPORTED_MODULE_8__["ɵɵpipeBind2"](3, 1, "campaigns.homewidgets.stat.weekposition", _angular_core__WEBPACK_IMPORTED_MODULE_8__["ɵɵpureFunction1"](4, _c0, ctx_r11.reportWeekStat == null ? null : ctx_r11.reportWeekStat.position)), " ");
  }
}

function MainCampaignStatComponent_ion_row_2_ng_container_3_Template(rf, ctx) {
  if (rf & 1) {
    _angular_core__WEBPACK_IMPORTED_MODULE_8__["ɵɵelementContainerStart"](0);
    _angular_core__WEBPACK_IMPORTED_MODULE_8__["ɵɵelementStart"](1, "span", 8);
    _angular_core__WEBPACK_IMPORTED_MODULE_8__["ɵɵtext"](2, "-");
    _angular_core__WEBPACK_IMPORTED_MODULE_8__["ɵɵelementEnd"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_8__["ɵɵelementContainerEnd"]();
  }
}

function MainCampaignStatComponent_ion_row_2_ng_container_4_Template(rf, ctx) {
  if (rf & 1) {
    _angular_core__WEBPACK_IMPORTED_MODULE_8__["ɵɵelementContainerStart"](0, 8);
    _angular_core__WEBPACK_IMPORTED_MODULE_8__["ɵɵelementStart"](1, "span");
    _angular_core__WEBPACK_IMPORTED_MODULE_8__["ɵɵtext"](2);
    _angular_core__WEBPACK_IMPORTED_MODULE_8__["ɵɵpipe"](3, "translate");
    _angular_core__WEBPACK_IMPORTED_MODULE_8__["ɵɵelementEnd"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_8__["ɵɵelementContainerEnd"]();
  }

  if (rf & 2) {
    var ctx_r13 = _angular_core__WEBPACK_IMPORTED_MODULE_8__["ɵɵnextContext"](2);
    _angular_core__WEBPACK_IMPORTED_MODULE_8__["ɵɵadvance"](2);
    _angular_core__WEBPACK_IMPORTED_MODULE_8__["ɵɵtextInterpolate1"](" ", _angular_core__WEBPACK_IMPORTED_MODULE_8__["ɵɵpipeBind2"](3, 1, "campaigns.homewidgets.stat.totalposition", _angular_core__WEBPACK_IMPORTED_MODULE_8__["ɵɵpureFunction1"](4, _c0, ctx_r13.reportTotalStat == null ? null : ctx_r13.reportTotalStat.position)), " ");
  }
}

function MainCampaignStatComponent_ion_row_2_Template(rf, ctx) {
  if (rf & 1) {
    _angular_core__WEBPACK_IMPORTED_MODULE_8__["ɵɵelementStart"](0, "ion-row")(1, "ion-col", 6);
    _angular_core__WEBPACK_IMPORTED_MODULE_8__["ɵɵtemplate"](2, MainCampaignStatComponent_ion_row_2_ng_container_2_Template, 4, 6, "ng-container", 0);
    _angular_core__WEBPACK_IMPORTED_MODULE_8__["ɵɵtemplate"](3, MainCampaignStatComponent_ion_row_2_ng_container_3_Template, 3, 0, "ng-container", 0);
    _angular_core__WEBPACK_IMPORTED_MODULE_8__["ɵɵtemplate"](4, MainCampaignStatComponent_ion_row_2_ng_container_4_Template, 4, 6, "ng-container", 7);
    _angular_core__WEBPACK_IMPORTED_MODULE_8__["ɵɵelementEnd"]()();
  }

  if (rf & 2) {
    var ctx_r0 = _angular_core__WEBPACK_IMPORTED_MODULE_8__["ɵɵnextContext"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_8__["ɵɵadvance"](2);
    _angular_core__WEBPACK_IMPORTED_MODULE_8__["ɵɵproperty"]("ngIf", ctx_r0.reportWeekStat);
    _angular_core__WEBPACK_IMPORTED_MODULE_8__["ɵɵadvance"](1);
    _angular_core__WEBPACK_IMPORTED_MODULE_8__["ɵɵproperty"]("ngIf", ctx_r0.reportWeekStat && ctx_r0.reportTotalStat);
    _angular_core__WEBPACK_IMPORTED_MODULE_8__["ɵɵadvance"](1);
    _angular_core__WEBPACK_IMPORTED_MODULE_8__["ɵɵproperty"]("ngIf", ctx_r0.reportTotalStat);
  }
}

function MainCampaignStatComponent_ion_col_4_Template(rf, ctx) {
  if (rf & 1) {
    _angular_core__WEBPACK_IMPORTED_MODULE_8__["ɵɵelementStart"](0, "ion-col", 9);
    _angular_core__WEBPACK_IMPORTED_MODULE_8__["ɵɵelement"](1, "app-icon", 10);
    _angular_core__WEBPACK_IMPORTED_MODULE_8__["ɵɵelementEnd"]();
  }

  if (rf & 2) {
    var ctx_r1 = _angular_core__WEBPACK_IMPORTED_MODULE_8__["ɵɵnextContext"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_8__["ɵɵadvance"](1);
    _angular_core__WEBPACK_IMPORTED_MODULE_8__["ɵɵproperty"]("name", ctx_r1.campaignService.getCampaignTypeIcon(ctx_r1.campaignContainer == null ? null : ctx_r1.campaignContainer.campaign));
  }
}

var _c1 = function _c1(a0) {
  return {
    value: a0
  };
};

function MainCampaignStatComponent_p_6_Template(rf, ctx) {
  if (rf & 1) {
    _angular_core__WEBPACK_IMPORTED_MODULE_8__["ɵɵelement"](0, "p", 11);
    _angular_core__WEBPACK_IMPORTED_MODULE_8__["ɵɵpipe"](1, "translate");
    _angular_core__WEBPACK_IMPORTED_MODULE_8__["ɵɵpipe"](2, "localNumber");
  }

  if (rf & 2) {
    var ctx_r2 = _angular_core__WEBPACK_IMPORTED_MODULE_8__["ɵɵnextContext"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_8__["ɵɵproperty"]("innerHtml", _angular_core__WEBPACK_IMPORTED_MODULE_8__["ɵɵpipeBind2"](1, 1, "campaigns.homewidgets.stat.weekvalue", _angular_core__WEBPACK_IMPORTED_MODULE_8__["ɵɵpureFunction1"](6, _c1, _angular_core__WEBPACK_IMPORTED_MODULE_8__["ɵɵpipeBind1"](2, 4, ctx_r2.reportWeekStat == null ? null : ctx_r2.reportWeekStat.value))), _angular_core__WEBPACK_IMPORTED_MODULE_8__["ɵɵsanitizeHtml"]);
  }
}

function MainCampaignStatComponent_p_7_Template(rf, ctx) {
  if (rf & 1) {
    _angular_core__WEBPACK_IMPORTED_MODULE_8__["ɵɵelement"](0, "p", 11);
    _angular_core__WEBPACK_IMPORTED_MODULE_8__["ɵɵpipe"](1, "translate");
    _angular_core__WEBPACK_IMPORTED_MODULE_8__["ɵɵpipe"](2, "localNumber");
  }

  if (rf & 2) {
    var ctx_r3 = _angular_core__WEBPACK_IMPORTED_MODULE_8__["ɵɵnextContext"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_8__["ɵɵproperty"]("innerHtml", _angular_core__WEBPACK_IMPORTED_MODULE_8__["ɵɵpipeBind2"](1, 1, "campaigns.homewidgets.stat.totalvalue", _angular_core__WEBPACK_IMPORTED_MODULE_8__["ɵɵpureFunction1"](6, _c1, _angular_core__WEBPACK_IMPORTED_MODULE_8__["ɵɵpipeBind1"](2, 4, ctx_r3.reportTotalStat == null ? null : ctx_r3.reportTotalStat.value))), _angular_core__WEBPACK_IMPORTED_MODULE_8__["ɵɵsanitizeHtml"]);
  }
}

function MainCampaignStatComponent_p_8_Template(rf, ctx) {
  if (rf & 1) {
    _angular_core__WEBPACK_IMPORTED_MODULE_8__["ɵɵelement"](0, "p", 11);
    _angular_core__WEBPACK_IMPORTED_MODULE_8__["ɵɵpipe"](1, "translate");
    _angular_core__WEBPACK_IMPORTED_MODULE_8__["ɵɵpipe"](2, "localNumber");
  }

  if (rf & 2) {
    var ctx_r4 = _angular_core__WEBPACK_IMPORTED_MODULE_8__["ɵɵnextContext"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_8__["ɵɵproperty"]("innerHtml", _angular_core__WEBPACK_IMPORTED_MODULE_8__["ɵɵpipeBind2"](1, 1, "campaigns.homewidgets.stat.monthvalue", _angular_core__WEBPACK_IMPORTED_MODULE_8__["ɵɵpureFunction1"](6, _c1, _angular_core__WEBPACK_IMPORTED_MODULE_8__["ɵɵpipeBind1"](2, 4, ctx_r4.reportMonthStat == null ? null : ctx_r4.reportMonthStat.value))), _angular_core__WEBPACK_IMPORTED_MODULE_8__["ɵɵsanitizeHtml"]);
  }
}

function MainCampaignStatComponent_ion_row_9_Template(rf, ctx) {
  if (rf & 1) {
    _angular_core__WEBPACK_IMPORTED_MODULE_8__["ɵɵelementStart"](0, "ion-row")(1, "ion-col");
    _angular_core__WEBPACK_IMPORTED_MODULE_8__["ɵɵelement"](2, "app-game-status", 12);
    _angular_core__WEBPACK_IMPORTED_MODULE_8__["ɵɵelementEnd"]()();
  }

  if (rf & 2) {
    var ctx_r5 = _angular_core__WEBPACK_IMPORTED_MODULE_8__["ɵɵnextContext"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_8__["ɵɵadvance"](2);
    _angular_core__WEBPACK_IMPORTED_MODULE_8__["ɵɵproperty"]("status", ctx_r5.status)("type", ctx_r5.campaignContainer == null ? null : ctx_r5.campaignContainer.campaign == null ? null : ctx_r5.campaignContainer.campaign.type);
  }
}

function MainCampaignStatComponent_ion_row_10_Template(rf, ctx) {
  if (rf & 1) {
    _angular_core__WEBPACK_IMPORTED_MODULE_8__["ɵɵelementStart"](0, "ion-row")(1, "ion-col");
    _angular_core__WEBPACK_IMPORTED_MODULE_8__["ɵɵelement"](2, "app-record-status", 13);
    _angular_core__WEBPACK_IMPORTED_MODULE_8__["ɵɵelementEnd"]()();
  }

  if (rf & 2) {
    var ctx_r6 = _angular_core__WEBPACK_IMPORTED_MODULE_8__["ɵɵnextContext"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_8__["ɵɵadvance"](2);
    _angular_core__WEBPACK_IMPORTED_MODULE_8__["ɵɵproperty"]("status", ctx_r6.reportWeekStat)("record", ctx_r6.record)("type", ctx_r6.campaignContainer == null ? null : ctx_r6.campaignContainer.campaign == null ? null : ctx_r6.campaignContainer.campaign.type);
  }
}

function MainCampaignStatComponent_ion_row_11_Template(rf, ctx) {
  if (rf & 1) {
    _angular_core__WEBPACK_IMPORTED_MODULE_8__["ɵɵelementStart"](0, "ion-row")(1, "ion-col");
    _angular_core__WEBPACK_IMPORTED_MODULE_8__["ɵɵelement"](2, "app-limit-status", 14);
    _angular_core__WEBPACK_IMPORTED_MODULE_8__["ɵɵpipe"](3, "translate");
    _angular_core__WEBPACK_IMPORTED_MODULE_8__["ɵɵelementEnd"]()();
  }

  if (rf & 2) {
    var ctx_r7 = _angular_core__WEBPACK_IMPORTED_MODULE_8__["ɵɵnextContext"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_8__["ɵɵadvance"](2);
    _angular_core__WEBPACK_IMPORTED_MODULE_8__["ɵɵproperty"]("limitMax", ctx_r7.limitDayMax)("limitValue", ctx_r7.limitDayValue)("type", ctx_r7.campaignContainer == null ? null : ctx_r7.campaignContainer.campaign == null ? null : ctx_r7.campaignContainer.campaign.type)("header", _angular_core__WEBPACK_IMPORTED_MODULE_8__["ɵɵpipeBind1"](3, 4, "campaigns.homewidgets.stat.today"));
  }
}

function MainCampaignStatComponent_ion_row_12_Template(rf, ctx) {
  if (rf & 1) {
    _angular_core__WEBPACK_IMPORTED_MODULE_8__["ɵɵelementStart"](0, "ion-row")(1, "ion-col");
    _angular_core__WEBPACK_IMPORTED_MODULE_8__["ɵɵelement"](2, "app-limit-status", 14);
    _angular_core__WEBPACK_IMPORTED_MODULE_8__["ɵɵpipe"](3, "translate");
    _angular_core__WEBPACK_IMPORTED_MODULE_8__["ɵɵelementEnd"]()();
  }

  if (rf & 2) {
    var ctx_r8 = _angular_core__WEBPACK_IMPORTED_MODULE_8__["ɵɵnextContext"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_8__["ɵɵadvance"](2);
    _angular_core__WEBPACK_IMPORTED_MODULE_8__["ɵɵproperty"]("limitMax", ctx_r8.limitMonthMax)("limitValue", ctx_r8.limitMonthValue)("type", ctx_r8.campaignContainer == null ? null : ctx_r8.campaignContainer.campaign == null ? null : ctx_r8.campaignContainer.campaign.type)("header", _angular_core__WEBPACK_IMPORTED_MODULE_8__["ɵɵpipeBind1"](3, 4, "campaigns.homewidgets.stat.lastmonth"));
  }
}

function MainCampaignStatComponent_ng_template_13_Template(rf, ctx) {
  if (rf & 1) {
    _angular_core__WEBPACK_IMPORTED_MODULE_8__["ɵɵelementStart"](0, "ion-row")(1, "ion-col");
    _angular_core__WEBPACK_IMPORTED_MODULE_8__["ɵɵtext"](2);
    _angular_core__WEBPACK_IMPORTED_MODULE_8__["ɵɵpipe"](3, "translate");
    _angular_core__WEBPACK_IMPORTED_MODULE_8__["ɵɵelementEnd"]()();
  }

  if (rf & 2) {
    _angular_core__WEBPACK_IMPORTED_MODULE_8__["ɵɵadvance"](2);
    _angular_core__WEBPACK_IMPORTED_MODULE_8__["ɵɵtextInterpolate1"](" ", _angular_core__WEBPACK_IMPORTED_MODULE_8__["ɵɵpipeBind1"](3, 1, "campaigns.homewidgets.stat.emptystatus"), "");
  }
}

var MainCampaignStatComponent = /*#__PURE__*/function () {
  function MainCampaignStatComponent(campaignService) {
    (0,_Users_smartcommunitylab_Documents_work_projects_dslab_playgo_mobile_playgo_mobile_node_modules_babel_runtime_helpers_esm_classCallCheck_js__WEBPACK_IMPORTED_MODULE_0__["default"])(this, MainCampaignStatComponent);

    this.campaignService = campaignService;
    this.status = undefined;
    this.record = undefined;
    this.showRanking = true;
  }

  (0,_Users_smartcommunitylab_Documents_work_projects_dslab_playgo_mobile_playgo_mobile_node_modules_babel_runtime_helpers_esm_createClass_js__WEBPACK_IMPORTED_MODULE_1__["default"])(MainCampaignStatComponent, [{
    key: "ngOnInit",
    value: function ngOnInit() {}
  }]);

  return MainCampaignStatComponent;
}();

MainCampaignStatComponent.ɵfac = function MainCampaignStatComponent_Factory(t) {
  return new (t || MainCampaignStatComponent)(_angular_core__WEBPACK_IMPORTED_MODULE_8__["ɵɵdirectiveInject"](_services_campaign_service__WEBPACK_IMPORTED_MODULE_2__.CampaignService));
};

MainCampaignStatComponent.ɵcmp = /*@__PURE__*/_angular_core__WEBPACK_IMPORTED_MODULE_8__["ɵɵdefineComponent"]({
  type: MainCampaignStatComponent,
  selectors: [["app-main-campaign-stat"]],
  inputs: {
    campaignContainer: "campaignContainer",
    status: "status",
    record: "record",
    reportWeekStat: "reportWeekStat",
    reportMonthStat: "reportMonthStat",
    reportTotalStat: "reportTotalStat",
    limitMonthMax: "limitMonthMax",
    limitMonthValue: "limitMonthValue",
    limitDayMax: "limitDayMax",
    limitDayValue: "limitDayValue",
    showRanking: "showRanking"
  },
  decls: 15,
  vars: 10,
  consts: [[4, "ngIf"], ["size", "2", 4, "ngIf"], [1, "report"], ["class", "ion-text-left", 3, "innerHtml", 4, "ngIf"], [4, "ngIf", "ngIfElse"], ["nullStatus", ""], ["size", "10", 1, "ranking"], ["class", "ion-text-left", 4, "ngIf"], [1, "ion-text-left"], ["size", "2"], [3, "name"], [1, "ion-text-left", 3, "innerHtml"], [3, "status", "type"], [3, "status", "record", "type"], [3, "limitMax", "limitValue", "type", "header"]],
  template: function MainCampaignStatComponent_Template(rf, ctx) {
    if (rf & 1) {
      _angular_core__WEBPACK_IMPORTED_MODULE_8__["ɵɵelementStart"](0, "div")(1, "ion-grid");
      _angular_core__WEBPACK_IMPORTED_MODULE_8__["ɵɵtemplate"](2, MainCampaignStatComponent_ion_row_2_Template, 5, 3, "ion-row", 0);
      _angular_core__WEBPACK_IMPORTED_MODULE_8__["ɵɵelementStart"](3, "ion-row");
      _angular_core__WEBPACK_IMPORTED_MODULE_8__["ɵɵtemplate"](4, MainCampaignStatComponent_ion_col_4_Template, 2, 1, "ion-col", 1);
      _angular_core__WEBPACK_IMPORTED_MODULE_8__["ɵɵelementStart"](5, "ion-col", 2);
      _angular_core__WEBPACK_IMPORTED_MODULE_8__["ɵɵtemplate"](6, MainCampaignStatComponent_p_6_Template, 3, 8, "p", 3);
      _angular_core__WEBPACK_IMPORTED_MODULE_8__["ɵɵtemplate"](7, MainCampaignStatComponent_p_7_Template, 3, 8, "p", 3);
      _angular_core__WEBPACK_IMPORTED_MODULE_8__["ɵɵtemplate"](8, MainCampaignStatComponent_p_8_Template, 3, 8, "p", 3);
      _angular_core__WEBPACK_IMPORTED_MODULE_8__["ɵɵelementEnd"]()();
      _angular_core__WEBPACK_IMPORTED_MODULE_8__["ɵɵtemplate"](9, MainCampaignStatComponent_ion_row_9_Template, 3, 2, "ion-row", 4);
      _angular_core__WEBPACK_IMPORTED_MODULE_8__["ɵɵtemplate"](10, MainCampaignStatComponent_ion_row_10_Template, 3, 3, "ion-row", 0);
      _angular_core__WEBPACK_IMPORTED_MODULE_8__["ɵɵtemplate"](11, MainCampaignStatComponent_ion_row_11_Template, 4, 6, "ion-row", 0);
      _angular_core__WEBPACK_IMPORTED_MODULE_8__["ɵɵtemplate"](12, MainCampaignStatComponent_ion_row_12_Template, 4, 6, "ion-row", 0);
      _angular_core__WEBPACK_IMPORTED_MODULE_8__["ɵɵtemplate"](13, MainCampaignStatComponent_ng_template_13_Template, 4, 3, "ng-template", null, 5, _angular_core__WEBPACK_IMPORTED_MODULE_8__["ɵɵtemplateRefExtractor"]);
      _angular_core__WEBPACK_IMPORTED_MODULE_8__["ɵɵelementEnd"]()();
    }

    if (rf & 2) {
      var _r9 = _angular_core__WEBPACK_IMPORTED_MODULE_8__["ɵɵreference"](14);

      _angular_core__WEBPACK_IMPORTED_MODULE_8__["ɵɵadvance"](2);
      _angular_core__WEBPACK_IMPORTED_MODULE_8__["ɵɵproperty"]("ngIf", ctx.showRanking);
      _angular_core__WEBPACK_IMPORTED_MODULE_8__["ɵɵadvance"](2);
      _angular_core__WEBPACK_IMPORTED_MODULE_8__["ɵɵproperty"]("ngIf", ctx.reportWeekStat || ctx.reportMonthStat || ctx.reportTotalStat);
      _angular_core__WEBPACK_IMPORTED_MODULE_8__["ɵɵadvance"](2);
      _angular_core__WEBPACK_IMPORTED_MODULE_8__["ɵɵproperty"]("ngIf", ctx.reportWeekStat);
      _angular_core__WEBPACK_IMPORTED_MODULE_8__["ɵɵadvance"](1);
      _angular_core__WEBPACK_IMPORTED_MODULE_8__["ɵɵproperty"]("ngIf", ctx.reportTotalStat);
      _angular_core__WEBPACK_IMPORTED_MODULE_8__["ɵɵadvance"](1);
      _angular_core__WEBPACK_IMPORTED_MODULE_8__["ɵɵproperty"]("ngIf", ctx.reportMonthStat);
      _angular_core__WEBPACK_IMPORTED_MODULE_8__["ɵɵadvance"](1);
      _angular_core__WEBPACK_IMPORTED_MODULE_8__["ɵɵproperty"]("ngIf", ctx.status !== null)("ngIfElse", _r9);
      _angular_core__WEBPACK_IMPORTED_MODULE_8__["ɵɵadvance"](1);
      _angular_core__WEBPACK_IMPORTED_MODULE_8__["ɵɵproperty"]("ngIf", ctx.record !== null && ctx.status !== null);
      _angular_core__WEBPACK_IMPORTED_MODULE_8__["ɵɵadvance"](1);
      _angular_core__WEBPACK_IMPORTED_MODULE_8__["ɵɵproperty"]("ngIf", ctx.limitDayValue);
      _angular_core__WEBPACK_IMPORTED_MODULE_8__["ɵɵadvance"](1);
      _angular_core__WEBPACK_IMPORTED_MODULE_8__["ɵɵproperty"]("ngIf", ctx.limitMonthValue !== null);
    }
  },
  directives: [_ionic_angular__WEBPACK_IMPORTED_MODULE_9__.IonGrid, _angular_common__WEBPACK_IMPORTED_MODULE_10__.NgIf, _ionic_angular__WEBPACK_IMPORTED_MODULE_9__.IonRow, _ionic_angular__WEBPACK_IMPORTED_MODULE_9__.IonCol, _ui_icon_icon_component__WEBPACK_IMPORTED_MODULE_3__.IconComponent, _game_status_game_status_component__WEBPACK_IMPORTED_MODULE_4__.GameStatusComponent, _record_status_record_status_component__WEBPACK_IMPORTED_MODULE_5__.RecordStatusComponent, _limit_status_limit_status_component__WEBPACK_IMPORTED_MODULE_6__.LimitStatusComponent],
  pipes: [_ngx_translate_core__WEBPACK_IMPORTED_MODULE_11__.TranslatePipe, _pipes_localNumber_pipe__WEBPACK_IMPORTED_MODULE_7__.LocalNumberPipe],
  styles: [".report[_ngcontent-%COMP%] {\n  display: flex;\n  flex-direction: column;\n  justify-content: space-around;\n}\n\n.ranking[_ngcontent-%COMP%] {\n  font-size: 14px;\n  font-weight: bold;\n  text-align: left;\n}\n\napp-icon[_ngcontent-%COMP%] {\n  font-size: 34px;\n}\n\napp-icon[_ngcontent-%COMP%]   ion-icon[_ngcontent-%COMP%] {\n  margin-top: 0px;\n  margin-bottom: 0px;\n}\n/*# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbIm1haW4tY2FtcGFpZ24tc3RhdC5jb21wb25lbnQuc2NzcyJdLCJuYW1lcyI6W10sIm1hcHBpbmdzIjoiQUFBQTtFQUNFLGFBQUE7RUFDQSxzQkFBQTtFQUNBLDZCQUFBO0FBQ0Y7O0FBQ0E7RUFDRSxlQUFBO0VBQ0EsaUJBQUE7RUFDQSxnQkFBQTtBQUVGOztBQUFBO0VBQ0UsZUFBQTtBQUdGOztBQUZFO0VBQ0UsZUFBQTtFQUNBLGtCQUFBO0FBSUoiLCJmaWxlIjoibWFpbi1jYW1wYWlnbi1zdGF0LmNvbXBvbmVudC5zY3NzIiwic291cmNlc0NvbnRlbnQiOlsiLnJlcG9ydCB7XG4gIGRpc3BsYXk6IGZsZXg7XG4gIGZsZXgtZGlyZWN0aW9uOiBjb2x1bW47XG4gIGp1c3RpZnktY29udGVudDogc3BhY2UtYXJvdW5kO1xufVxuLnJhbmtpbmcge1xuICBmb250LXNpemU6IDE0cHg7XG4gIGZvbnQtd2VpZ2h0OiBib2xkO1xuICB0ZXh0LWFsaWduOiBsZWZ0O1xufVxuYXBwLWljb24ge1xuICBmb250LXNpemU6IDM0cHg7XG4gIGlvbi1pY29uIHtcbiAgICBtYXJnaW4tdG9wOiAwcHg7XG4gICAgbWFyZ2luLWJvdHRvbTogMHB4O1xuICB9XG59XG4iXX0= */"]
});

/***/ }),

/***/ 13204:
/*!***************************************************************************************************!*\
  !*** ./src/app/core/shared/campaigns/main-campaign-stat/record-status/record-status.component.ts ***!
  \***************************************************************************************************/
/***/ (function(__unused_webpack_module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "RecordStatusComponent": function() { return /* binding */ RecordStatusComponent; }
/* harmony export */ });
/* harmony import */ var _Users_smartcommunitylab_Documents_work_projects_dslab_playgo_mobile_playgo_mobile_node_modules_babel_runtime_helpers_esm_classCallCheck_js__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./node_modules/@babel/runtime/helpers/esm/classCallCheck.js */ 78069);
/* harmony import */ var _Users_smartcommunitylab_Documents_work_projects_dslab_playgo_mobile_playgo_mobile_node_modules_babel_runtime_helpers_esm_createClass_js__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ./node_modules/@babel/runtime/helpers/esm/createClass.js */ 48047);
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @angular/core */ 3184);
/* harmony import */ var _angular_common__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! @angular/common */ 36362);
/* harmony import */ var _ionic_angular__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! @ionic/angular */ 93819);
/* harmony import */ var _ngx_translate_core__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! @ngx-translate/core */ 87514);
/* harmony import */ var _pipes_localNumber_pipe__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! ../../../pipes/localNumber.pipe */ 89713);








var _c0 = function _c0(a0) {
  return {
    score: a0
  };
};

var _c1 = function _c1(a0) {
  return {
    record: a0
  };
};

function RecordStatusComponent_div_0_Template(rf, ctx) {
  if (rf & 1) {
    _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵelementStart"](0, "div", 1)(1, "ion-grid")(2, "ion-row")(3, "ion-col", 2)(4, "b");
    _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵtext"](5);
    _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵpipe"](6, "translate");
    _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵpipe"](7, "localNumber");
    _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵelementEnd"]()();
    _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵelementStart"](8, "ion-col", 3);
    _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵtext"](9);
    _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵpipe"](10, "translate");
    _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵpipe"](11, "localNumber");
    _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵelementEnd"]()();
    _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵelementStart"](12, "ion-row")(13, "ion-col", 4);
    _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵelement"](14, "ion-progress-bar", 5);
    _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵelementEnd"]()()()();
  }

  if (rf & 2) {
    var ctx_r0 = _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵnextContext"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵadvance"](5);
    _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵtextInterpolate"](_angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵpipeBind2"](6, 4, "campaigns.homewidgets.stat.status", _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵpureFunction1"](14, _c0, _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵpipeBind1"](7, 7, ctx_r0.status.value))));
    _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵadvance"](4);
    _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵtextInterpolate1"](" ", _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵpipeBind2"](10, 9, "campaigns.homewidgets.stat.record", _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵpureFunction1"](16, _c1, _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵpipeBind1"](11, 12, ctx_r0.record.value))), " ");
    _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵadvance"](5);
    _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵproperty"]("color", ctx_r0.type)("value", (ctx_r0.status == null ? null : ctx_r0.status.value) / ctx_r0.record.value);
  }
}

var RecordStatusComponent = /*#__PURE__*/function () {
  function RecordStatusComponent() {
    (0,_Users_smartcommunitylab_Documents_work_projects_dslab_playgo_mobile_playgo_mobile_node_modules_babel_runtime_helpers_esm_classCallCheck_js__WEBPACK_IMPORTED_MODULE_0__["default"])(this, RecordStatusComponent);

    this.status = undefined;
    this.record = undefined;
  }

  (0,_Users_smartcommunitylab_Documents_work_projects_dslab_playgo_mobile_playgo_mobile_node_modules_babel_runtime_helpers_esm_createClass_js__WEBPACK_IMPORTED_MODULE_1__["default"])(RecordStatusComponent, [{
    key: "ngOnInit",
    value: function ngOnInit() {}
  }]);

  return RecordStatusComponent;
}();

RecordStatusComponent.ɵfac = function RecordStatusComponent_Factory(t) {
  return new (t || RecordStatusComponent)();
};

RecordStatusComponent.ɵcmp = /*@__PURE__*/_angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵdefineComponent"]({
  type: RecordStatusComponent,
  selectors: [["app-record-status"]],
  inputs: {
    status: "status",
    record: "record",
    type: "type"
  },
  decls: 1,
  vars: 1,
  consts: [["class", "ion-text-left", 4, "ngIf"], [1, "ion-text-left"], ["size", "6"], ["size", "6", 1, "ion-text-end"], [1, "progress-bar"], [1, "level-bar", 3, "color", "value"]],
  template: function RecordStatusComponent_Template(rf, ctx) {
    if (rf & 1) {
      _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵtemplate"](0, RecordStatusComponent_div_0_Template, 15, 18, "div", 0);
    }

    if (rf & 2) {
      _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵproperty"]("ngIf", ctx.status && ctx.record);
    }
  },
  directives: [_angular_common__WEBPACK_IMPORTED_MODULE_4__.NgIf, _ionic_angular__WEBPACK_IMPORTED_MODULE_5__.IonGrid, _ionic_angular__WEBPACK_IMPORTED_MODULE_5__.IonRow, _ionic_angular__WEBPACK_IMPORTED_MODULE_5__.IonCol, _ionic_angular__WEBPACK_IMPORTED_MODULE_5__.IonProgressBar],
  pipes: [_ngx_translate_core__WEBPACK_IMPORTED_MODULE_6__.TranslatePipe, _pipes_localNumber_pipe__WEBPACK_IMPORTED_MODULE_2__.LocalNumberPipe],
  styles: [".level-bar[_ngcontent-%COMP%] {\n  height: 20px;\n}\n/*# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbInJlY29yZC1zdGF0dXMuY29tcG9uZW50LnNjc3MiXSwibmFtZXMiOltdLCJtYXBwaW5ncyI6IkFBQUE7RUFDRSxZQUFBO0FBQ0YiLCJmaWxlIjoicmVjb3JkLXN0YXR1cy5jb21wb25lbnQuc2NzcyIsInNvdXJjZXNDb250ZW50IjpbIi5sZXZlbC1iYXIge1xuICBoZWlnaHQ6IDIwcHg7XG59XG4iXX0= */"]
});

/***/ }),

/***/ 51790:
/*!**************************************************************************************!*\
  !*** ./src/app/core/shared/campaigns/my-campaign-card/my-campaign-card.component.ts ***!
  \**************************************************************************************/
/***/ (function(__unused_webpack_module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "MyCampaignCardComponent": function() { return /* binding */ MyCampaignCardComponent; }
/* harmony export */ });
/* harmony import */ var _Users_smartcommunitylab_Documents_work_projects_dslab_playgo_mobile_playgo_mobile_node_modules_babel_runtime_helpers_esm_classCallCheck_js__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./node_modules/@babel/runtime/helpers/esm/classCallCheck.js */ 78069);
/* harmony import */ var _Users_smartcommunitylab_Documents_work_projects_dslab_playgo_mobile_playgo_mobile_node_modules_babel_runtime_helpers_esm_createClass_js__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ./node_modules/@babel/runtime/helpers/esm/createClass.js */ 48047);
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! @angular/core */ 3184);
/* harmony import */ var _angular_router__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(/*! @angular/router */ 52816);
/* harmony import */ var _services_user_service__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! ../../services/user.service */ 50749);
/* harmony import */ var _ionic_angular__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(/*! @ionic/angular */ 93819);
/* harmony import */ var _main_campaign_stat_main_campaign_stat_component__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! ../main-campaign-stat/main-campaign-stat.component */ 61646);
/* harmony import */ var _pipes_languageMap_pipe__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! ../../pipes/languageMap.pipe */ 73088);
/* harmony import */ var _ngx_translate_core__WEBPACK_IMPORTED_MODULE_9__ = __webpack_require__(/*! @ngx-translate/core */ 87514);
/* harmony import */ var _pipes_localDate_pipe__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! ../../pipes/localDate.pipe */ 34489);










var MyCampaignCardComponent = /*#__PURE__*/function () {
  function MyCampaignCardComponent(router, userService) {
    (0,_Users_smartcommunitylab_Documents_work_projects_dslab_playgo_mobile_playgo_mobile_node_modules_babel_runtime_helpers_esm_classCallCheck_js__WEBPACK_IMPORTED_MODULE_0__["default"])(this, MyCampaignCardComponent);

    this.router = router;
    this.userService = userService;
  }

  (0,_Users_smartcommunitylab_Documents_work_projects_dslab_playgo_mobile_playgo_mobile_node_modules_babel_runtime_helpers_esm_createClass_js__WEBPACK_IMPORTED_MODULE_1__["default"])(MyCampaignCardComponent, [{
    key: "ngOnInit",
    value: function ngOnInit() {
      var _a, _b, _c, _d, _e, _f, _g, _h, _j;

      this.imagePath = this.containerCampaign.campaign.logo.url ? this.containerCampaign.campaign.logo.url : 'data:image/jpg;base64,' + this.containerCampaign.campaign.logo.image;
      this.bannerPath = ((_c = (_b = (_a = this.containerCampaign) === null || _a === void 0 ? void 0 : _a.campaign) === null || _b === void 0 ? void 0 : _b.banner) === null || _c === void 0 ? void 0 : _c.url) ? (_f = (_e = (_d = this.containerCampaign) === null || _d === void 0 ? void 0 : _d.campaign) === null || _e === void 0 ? void 0 : _e.banner) === null || _f === void 0 ? void 0 : _f.url : 'data:image/jpg;base64,' + ((_j = (_h = (_g = this.containerCampaign) === null || _g === void 0 ? void 0 : _g.campaign) === null || _h === void 0 ? void 0 : _h.banner) === null || _j === void 0 ? void 0 : _j.image);
    }
  }, {
    key: "detailCampaign",
    value: function detailCampaign() {
      this.router.navigateByUrl('/pages/tabs/campaigns/details/' + this.containerCampaign.campaign.campaignId);
    }
  }, {
    key: "joinCamp",
    value: function joinCamp() {
      console.log('joinCampaign');
    }
  }, {
    key: "challenges",
    value: function challenges() {
      console.log('challenges');
    }
  }]);

  return MyCampaignCardComponent;
}();

MyCampaignCardComponent.ɵfac = function MyCampaignCardComponent_Factory(t) {
  return new (t || MyCampaignCardComponent)(_angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵdirectiveInject"](_angular_router__WEBPACK_IMPORTED_MODULE_7__.Router), _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵdirectiveInject"](_services_user_service__WEBPACK_IMPORTED_MODULE_2__.UserService));
};

MyCampaignCardComponent.ɵcmp = /*@__PURE__*/_angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵdefineComponent"]({
  type: MyCampaignCardComponent,
  selectors: [["app-my-campaign-card"]],
  inputs: {
    containerCampaign: "containerCampaign"
  },
  decls: 22,
  vars: 15,
  consts: [[1, "ion-card", 3, "click"], [1, "header"], ["alt", "banner", 1, "banner", 3, "src"], ["lines", "none", 1, "header-title", 3, "color"], ["slot", "end", 2, "margin", "2px"], ["alt", "image", 3, "src"]],
  template: function MyCampaignCardComponent_Template(rf, ctx) {
    if (rf & 1) {
      _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵelementStart"](0, "div")(1, "ion-card", 0);
      _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵlistener"]("click", function MyCampaignCardComponent_Template_ion_card_click_1_listener() {
        return ctx.detailCampaign();
      });
      _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵelementStart"](2, "div", 1);
      _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵelement"](3, "img", 2);
      _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵelementStart"](4, "ion-item", 3)(5, "ion-avatar", 4);
      _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵelement"](6, "img", 5);
      _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵelementEnd"]();
      _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵelementStart"](7, "ion-label")(8, "h3");
      _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵtext"](9);
      _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵpipe"](10, "languageMap");
      _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵelementEnd"]();
      _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵelementStart"](11, "h4");
      _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵtext"](12);
      _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵpipe"](13, "translate");
      _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵelementEnd"]();
      _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵelementStart"](14, "h4");
      _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵtext"](15);
      _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵpipe"](16, "localDate");
      _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵpipe"](17, "localDate");
      _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵelementEnd"]()()()();
      _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵelementStart"](18, "ion-card-content")(19, "div");
      _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵtext"](20, " TODO ");
      _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵelement"](21, "app-main-campaign-stat");
      _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵelementEnd"]()()()();
    }

    if (rf & 2) {
      _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵadvance"](3);
      _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵproperty"]("src", ctx.bannerPath, _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵsanitizeUrl"]);
      _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵadvance"](1);
      _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵproperty"]("color", ctx.containerCampaign.campaign.type);
      _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵadvance"](2);
      _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵproperty"]("src", ctx.imagePath, _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵsanitizeUrl"]);
      _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵadvance"](3);
      _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵtextInterpolate"](_angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵpipeBind1"](10, 7, ctx.containerCampaign.campaign.name));
      _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵadvance"](3);
      _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵtextInterpolate"](_angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵpipeBind1"](13, 9, "campaigns.blabla"));
      _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵadvance"](3);
      _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵtextInterpolate2"](" ", _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵpipeBind1"](16, 11, ctx.containerCampaign.campaign.dateFrom), " - ", _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵpipeBind1"](17, 13, ctx.containerCampaign.campaign.dateTo), " ");
    }
  },
  directives: [_ionic_angular__WEBPACK_IMPORTED_MODULE_8__.IonCard, _ionic_angular__WEBPACK_IMPORTED_MODULE_8__.IonItem, _ionic_angular__WEBPACK_IMPORTED_MODULE_8__.IonAvatar, _ionic_angular__WEBPACK_IMPORTED_MODULE_8__.IonLabel, _ionic_angular__WEBPACK_IMPORTED_MODULE_8__.IonCardContent, _main_campaign_stat_main_campaign_stat_component__WEBPACK_IMPORTED_MODULE_3__.MainCampaignStatComponent],
  pipes: [_pipes_languageMap_pipe__WEBPACK_IMPORTED_MODULE_4__.LanguageMapPipe, _ngx_translate_core__WEBPACK_IMPORTED_MODULE_9__.TranslatePipe, _pipes_localDate_pipe__WEBPACK_IMPORTED_MODULE_5__.LocalDatePipe],
  styles: [".progress-bar[_ngcontent-%COMP%] {\n  height: 24px;\n  width: var(--varwidth, 0%);\n  color: black;\n  background-color: #08a6f0;\n  text-align: center;\n  border-top-left-radius: 10px;\n  border-bottom-left-radius: 10px;\n}\n\n.progress-bar-contourn[_ngcontent-%COMP%] {\n  border: 1px solid black;\n  border-color: black;\n  margin-left: 18px;\n  margin-right: 18px;\n  background-color: lightgrey;\n  border-radius: 10px;\n}\n\n.border-class[_ngcontent-%COMP%] {\n  border: 1px solid #3f3f3f;\n  margin-left: 18px;\n  margin-right: 18px;\n  margin-top: 10px;\n  margin-bottom: 10px;\n}\n\n.border-class-fancy[_ngcontent-%COMP%] {\n  border: 1px solid white;\n  margin-left: 18px;\n  margin-right: 18px;\n  margin-top: 10px;\n  margin-bottom: 10px;\n  border-radius: 4px;\n}\n\n.ion-card[_ngcontent-%COMP%] {\n  color: white;\n  background-color: rgba(0, 0, 0, 0.3);\n  border: 2px solid white;\n}\n\n.header[_ngcontent-%COMP%] {\n  position: relative;\n  opacity: 0.9;\n}\n\n.header[_ngcontent-%COMP%]   .banner[_ngcontent-%COMP%] {\n  max-height: 200px;\n  width: 100%;\n  object-fit: cover;\n  object-position: center;\n}\n\n.header[_ngcontent-%COMP%]   .header-title[_ngcontent-%COMP%] {\n  position: absolute;\n  top: 0px;\n  background: transparent;\n  width: 100%;\n  opacity: 0.85;\n}\n/*# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbIm15LWNhbXBhaWduLWNhcmQuY29tcG9uZW50LnNjc3MiXSwibmFtZXMiOltdLCJtYXBwaW5ncyI6IkFBQUE7RUFDRSxZQUFBO0VBQ0EsMEJBQUE7RUFDQSxZQUFBO0VBQ0EseUJBQUE7RUFDQSxrQkFBQTtFQUNBLDRCQUFBO0VBQ0EsK0JBQUE7QUFDRjs7QUFFQTtFQUNFLHVCQUFBO0VBQ0EsbUJBQUE7RUFDQSxpQkFBQTtFQUNBLGtCQUFBO0VBQ0EsMkJBQUE7RUFDQSxtQkFBQTtBQUNGOztBQUVBO0VBQ0UseUJBQUE7RUFDQSxpQkFBQTtFQUNBLGtCQUFBO0VBQ0EsZ0JBQUE7RUFDQSxtQkFBQTtBQUNGOztBQUVBO0VBQ0UsdUJBQUE7RUFDQSxpQkFBQTtFQUNBLGtCQUFBO0VBQ0EsZ0JBQUE7RUFDQSxtQkFBQTtFQUNBLGtCQUFBO0FBQ0Y7O0FBRUE7RUFDRSxZQUFBO0VBQ0Esb0NBQUE7RUFDQSx1QkFBQTtBQUNGOztBQUNBO0VBQ0Usa0JBQUE7RUFDQSxZQUFBO0FBRUY7O0FBREU7RUFDRSxpQkFBQTtFQUNBLFdBQUE7RUFDQSxpQkFBQTtFQUNBLHVCQUFBO0FBR0o7O0FBREU7RUFDRSxrQkFBQTtFQUNBLFFBQUE7RUFDQSx1QkFBQTtFQUNBLFdBQUE7RUFDQSxhQUFBO0FBR0oiLCJmaWxlIjoibXktY2FtcGFpZ24tY2FyZC5jb21wb25lbnQuc2NzcyIsInNvdXJjZXNDb250ZW50IjpbIi5wcm9ncmVzcy1iYXIge1xuICBoZWlnaHQ6IDI0cHg7XG4gIHdpZHRoOiB2YXIoLS12YXJ3aWR0aCwgMCUpO1xuICBjb2xvcjogYmxhY2s7XG4gIGJhY2tncm91bmQtY29sb3I6IHJnYig4LCAxNjYsIDI0MCk7XG4gIHRleHQtYWxpZ246IGNlbnRlcjtcbiAgYm9yZGVyLXRvcC1sZWZ0LXJhZGl1czogMTBweDtcbiAgYm9yZGVyLWJvdHRvbS1sZWZ0LXJhZGl1czogMTBweDtcbn1cblxuLnByb2dyZXNzLWJhci1jb250b3VybiB7XG4gIGJvcmRlcjogMXB4IHNvbGlkIGJsYWNrO1xuICBib3JkZXItY29sb3I6IGJsYWNrO1xuICBtYXJnaW4tbGVmdDogMThweDtcbiAgbWFyZ2luLXJpZ2h0OiAxOHB4O1xuICBiYWNrZ3JvdW5kLWNvbG9yOiBsaWdodGdyZXk7XG4gIGJvcmRlci1yYWRpdXM6IDEwcHg7XG59XG5cbi5ib3JkZXItY2xhc3Mge1xuICBib3JkZXI6IDFweCBzb2xpZCByZ2IoNjMsIDYzLCA2Myk7XG4gIG1hcmdpbi1sZWZ0OiAxOHB4O1xuICBtYXJnaW4tcmlnaHQ6IDE4cHg7XG4gIG1hcmdpbi10b3A6IDEwcHg7XG4gIG1hcmdpbi1ib3R0b206IDEwcHg7XG59XG5cbi5ib3JkZXItY2xhc3MtZmFuY3kge1xuICBib3JkZXI6IDFweCBzb2xpZCByZ2IoMjU1LCAyNTUsIDI1NSk7XG4gIG1hcmdpbi1sZWZ0OiAxOHB4O1xuICBtYXJnaW4tcmlnaHQ6IDE4cHg7XG4gIG1hcmdpbi10b3A6IDEwcHg7XG4gIG1hcmdpbi1ib3R0b206IDEwcHg7XG4gIGJvcmRlci1yYWRpdXM6IDRweDtcbn1cblxuLmlvbi1jYXJkIHtcbiAgY29sb3I6IHdoaXRlO1xuICBiYWNrZ3JvdW5kLWNvbG9yOiByZ2JhKDAsIDAsIDAsIDAuMyk7XG4gIGJvcmRlcjogMnB4IHNvbGlkIHdoaXRlO1xufVxuLmhlYWRlciB7XG4gIHBvc2l0aW9uOiByZWxhdGl2ZTtcbiAgb3BhY2l0eTogMC45O1xuICAuYmFubmVyIHtcbiAgICBtYXgtaGVpZ2h0OiAyMDBweDtcbiAgICB3aWR0aDogMTAwJTtcbiAgICBvYmplY3QtZml0OiBjb3ZlcjtcbiAgICBvYmplY3QtcG9zaXRpb246IGNlbnRlcjtcbiAgfVxuICAuaGVhZGVyLXRpdGxlIHtcbiAgICBwb3NpdGlvbjogYWJzb2x1dGU7XG4gICAgdG9wOiAwcHg7XG4gICAgYmFja2dyb3VuZDogdHJhbnNwYXJlbnQ7XG4gICAgd2lkdGg6IDEwMCU7XG4gICAgb3BhY2l0eTogMC44NTtcbiAgfVxufVxuIl19 */"]
});

/***/ }),

/***/ 23936:
/*!**********************************************************************************************!*\
  !*** ./src/app/core/shared/campaigns/public-campaign-card/public-campaign-card.component.ts ***!
  \**********************************************************************************************/
/***/ (function(__unused_webpack_module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "PublicCampaignCardComponent": function() { return /* binding */ PublicCampaignCardComponent; }
/* harmony export */ });
/* harmony import */ var _Users_smartcommunitylab_Documents_work_projects_dslab_playgo_mobile_playgo_mobile_node_modules_babel_runtime_helpers_esm_classCallCheck_js__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./node_modules/@babel/runtime/helpers/esm/classCallCheck.js */ 78069);
/* harmony import */ var _Users_smartcommunitylab_Documents_work_projects_dslab_playgo_mobile_playgo_mobile_node_modules_babel_runtime_helpers_esm_createClass_js__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ./node_modules/@babel/runtime/helpers/esm/createClass.js */ 48047);
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! @angular/core */ 3184);
/* harmony import */ var _angular_router__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! @angular/router */ 52816);
/* harmony import */ var _services_user_service__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! ../../services/user.service */ 50749);
/* harmony import */ var _ionic_angular__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(/*! @ionic/angular */ 93819);
/* harmony import */ var _angular_common__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(/*! @angular/common */ 36362);
/* harmony import */ var _pipes_languageMap_pipe__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! ../../pipes/languageMap.pipe */ 73088);
/* harmony import */ var _pipes_localDate_pipe__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! ../../pipes/localDate.pipe */ 34489);
/* harmony import */ var _ngx_translate_core__WEBPACK_IMPORTED_MODULE_9__ = __webpack_require__(/*! @ngx-translate/core */ 87514);











function PublicCampaignCardComponent_ng_container_19_Template(rf, ctx) {
  if (rf & 1) {
    _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵelementContainerStart"](0);
    _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵelement"](1, "ion-card-content", 13);
    _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵpipe"](2, "languageMap");
    _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵelementContainerEnd"]();
  }

  if (rf & 2) {
    var ctx_r0 = _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵnextContext"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵadvance"](1);
    _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵproperty"]("innerHTML", _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵpipeBind1"](2, 1, ctx_r0.campaign.description), _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵsanitizeHtml"]);
  }
}

function PublicCampaignCardComponent_ng_template_21_Template(rf, ctx) {
  if (rf & 1) {
    _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵtext"](0);
    _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵpipe"](1, "translate");
  }

  if (rf & 2) {
    _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵtextInterpolate1"](" ", _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵpipeBind1"](1, 1, "campaigns.noDesc"), " ");
  }
}

var PublicCampaignCardComponent = /*#__PURE__*/function () {
  function PublicCampaignCardComponent(router, userService) {
    (0,_Users_smartcommunitylab_Documents_work_projects_dslab_playgo_mobile_playgo_mobile_node_modules_babel_runtime_helpers_esm_classCallCheck_js__WEBPACK_IMPORTED_MODULE_0__["default"])(this, PublicCampaignCardComponent);

    this.router = router;
    this.userService = userService;
  }

  (0,_Users_smartcommunitylab_Documents_work_projects_dslab_playgo_mobile_playgo_mobile_node_modules_babel_runtime_helpers_esm_createClass_js__WEBPACK_IMPORTED_MODULE_1__["default"])(PublicCampaignCardComponent, [{
    key: "ngOnInit",
    value: function ngOnInit() {
      this.imagePath = this.campaign.logo.url ? this.campaign.logo.url : 'data:image/jpg;base64,' + this.campaign.logo.image;
      this.bannerPath = this.campaign.banner.url ? this.campaign.banner.url : 'data:image/jpg;base64,' + this.campaign.banner.image;
    }
  }, {
    key: "joinCamp",
    value: function joinCamp() {
      this.router.navigateByUrl('/pages/tabs/campaigns/join/' + this.campaign.campaignId);
    }
  }]);

  return PublicCampaignCardComponent;
}();

PublicCampaignCardComponent.ɵfac = function PublicCampaignCardComponent_Factory(t) {
  return new (t || PublicCampaignCardComponent)(_angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵdirectiveInject"](_angular_router__WEBPACK_IMPORTED_MODULE_6__.Router), _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵdirectiveInject"](_services_user_service__WEBPACK_IMPORTED_MODULE_2__.UserService));
};

PublicCampaignCardComponent.ɵcmp = /*@__PURE__*/_angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵdefineComponent"]({
  type: PublicCampaignCardComponent,
  selectors: [["app-public-campaign-card"]],
  inputs: {
    campaign: "campaign"
  },
  decls: 27,
  vars: 20,
  consts: [[1, "ion-card", 3, "ngClass"], [1, "ion-no-padding"], [1, "header"], ["alt", "banner", 1, "banner", 3, "src"], ["lines", "none", 1, "header-title"], ["slot", "end", 2, "margin", "2px"], ["alt", "image", 3, "src"], [1, "ion-align-items-center"], ["size", "12"], [4, "ngIf", "ngIfElse"], ["noDesc", ""], ["size", "12", 1, "ion-text-center"], [2, "margin-left", "18px", "margin-bottom", "6px", 3, "color", "click"], [1, "ellipsis", 3, "innerHTML"]],
  template: function PublicCampaignCardComponent_Template(rf, ctx) {
    if (rf & 1) {
      _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵelementStart"](0, "div")(1, "ion-card", 0)(2, "ion-card-header", 1)(3, "div", 2);
      _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵelement"](4, "img", 3);
      _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵelementStart"](5, "div", 4)(6, "ion-avatar", 5);
      _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵelement"](7, "img", 6);
      _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵelementEnd"]();
      _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵelementStart"](8, "ion-label")(9, "h3");
      _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵtext"](10);
      _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵpipe"](11, "languageMap");
      _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵelementEnd"]();
      _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵelementStart"](12, "h4");
      _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵtext"](13);
      _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵpipe"](14, "localDate");
      _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵpipe"](15, "localDate");
      _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵelementEnd"]()()()()();
      _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵelementStart"](16, "ion-grid")(17, "ion-row", 7)(18, "ion-col", 8);
      _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵtemplate"](19, PublicCampaignCardComponent_ng_container_19_Template, 3, 3, "ng-container", 9);
      _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵpipe"](20, "languageMap");
      _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵtemplate"](21, PublicCampaignCardComponent_ng_template_21_Template, 2, 3, "ng-template", null, 10, _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵtemplateRefExtractor"]);
      _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵelementEnd"]();
      _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵelementStart"](23, "ion-col", 11)(24, "ion-button", 12);
      _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵlistener"]("click", function PublicCampaignCardComponent_Template_ion_button_click_24_listener() {
        return ctx.joinCamp();
      });
      _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵtext"](25);
      _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵpipe"](26, "translate");
      _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵelementEnd"]()()()()()();
    }

    if (rf & 2) {
      var _r1 = _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵreference"](22);

      _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵadvance"](1);
      _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵproperty"]("ngClass", ctx.campaign.type);
      _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵadvance"](3);
      _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵproperty"]("src", ctx.bannerPath, _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵsanitizeUrl"]);
      _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵadvance"](3);
      _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵproperty"]("src", ctx.imagePath, _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵsanitizeUrl"]);
      _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵadvance"](3);
      _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵtextInterpolate"](_angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵpipeBind1"](11, 10, ctx.campaign.name));
      _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵadvance"](3);
      _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵtextInterpolate2"](" ", _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵpipeBind1"](14, 12, ctx.campaign.dateFrom), " - ", _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵpipeBind1"](15, 14, ctx.campaign.dateTo), " ");
      _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵadvance"](6);
      _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵproperty"]("ngIf", _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵpipeBind1"](20, 16, ctx.campaign.description))("ngIfElse", _r1);
      _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵadvance"](5);
      _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵproperty"]("color", ctx.campaign.type);
      _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵadvance"](1);
      _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵtextInterpolate1"]("", _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵpipeBind1"](26, 18, "join"), " ");
    }
  },
  directives: [_ionic_angular__WEBPACK_IMPORTED_MODULE_7__.IonCard, _angular_common__WEBPACK_IMPORTED_MODULE_8__.NgClass, _ionic_angular__WEBPACK_IMPORTED_MODULE_7__.IonCardHeader, _ionic_angular__WEBPACK_IMPORTED_MODULE_7__.IonAvatar, _ionic_angular__WEBPACK_IMPORTED_MODULE_7__.IonLabel, _ionic_angular__WEBPACK_IMPORTED_MODULE_7__.IonGrid, _ionic_angular__WEBPACK_IMPORTED_MODULE_7__.IonRow, _ionic_angular__WEBPACK_IMPORTED_MODULE_7__.IonCol, _angular_common__WEBPACK_IMPORTED_MODULE_8__.NgIf, _ionic_angular__WEBPACK_IMPORTED_MODULE_7__.IonCardContent, _ionic_angular__WEBPACK_IMPORTED_MODULE_7__.IonButton],
  pipes: [_pipes_languageMap_pipe__WEBPACK_IMPORTED_MODULE_3__.LanguageMapPipe, _pipes_localDate_pipe__WEBPACK_IMPORTED_MODULE_4__.LocalDatePipe, _ngx_translate_core__WEBPACK_IMPORTED_MODULE_9__.TranslatePipe],
  styles: [".progress-bar[_ngcontent-%COMP%] {\n  height: 24px;\n  width: var(--varwidth, 0%);\n  color: black;\n  background-color: #08a6f0;\n  text-align: center;\n  border-top-left-radius: 10px;\n  border-bottom-left-radius: 10px;\n}\n\n.progress-bar-contourn[_ngcontent-%COMP%] {\n  border: 1px solid black;\n  border-color: black;\n  margin-left: 18px;\n  margin-right: 18px;\n  background-color: lightgrey;\n  border-radius: 10px;\n}\n\n.border-class[_ngcontent-%COMP%] {\n  border: 1px solid #3f3f3f;\n  margin-left: 18px;\n  margin-right: 18px;\n  margin-top: 10px;\n  margin-bottom: 10px;\n}\n\n.border-class-fancy[_ngcontent-%COMP%] {\n  border: 1px solid white;\n  margin-left: 18px;\n  margin-right: 18px;\n  margin-top: 10px;\n  margin-bottom: 10px;\n  border-radius: 4px;\n}\n\n.ion-card[_ngcontent-%COMP%] {\n  color: black;\n  background-color: white;\n}\n\n.ion-card[_ngcontent-%COMP%]   div[_ngcontent-%COMP%]   ion-avatar[_ngcontent-%COMP%] {\n  --border-radius: 50%;\n  border: solid 3px rgba(0, 0, 0, 0);\n  background-color: rgba(0, 0, 0, 0.5);\n  position: absolute;\n  z-index: 2;\n  text-align: center;\n  right: 20px;\n  top: 40px;\n}\n\n.company[_ngcontent-%COMP%] {\n  border: 3px solid var(--ion-color-company);\n}\n\n.school[_ngcontent-%COMP%] {\n  border: 3px solid var(--ion-color-school);\n}\n\n.city[_ngcontent-%COMP%] {\n  border: 3px solid var(--ion-color-city);\n}\n\n.header[_ngcontent-%COMP%] {\n  position: relative;\n}\n\n.header[_ngcontent-%COMP%]   .banner[_ngcontent-%COMP%] {\n  max-height: 200px;\n  width: 100%;\n  object-fit: cover;\n  object-position: center;\n}\n\n.header[_ngcontent-%COMP%]   .header-title[_ngcontent-%COMP%] {\n  position: absolute;\n  top: 0px;\n  background-color: rgba(0, 0, 0, 0.5);\n  width: 100%;\n  color: white;\n  padding: 8px;\n}\n/*# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbInB1YmxpYy1jYW1wYWlnbi1jYXJkLmNvbXBvbmVudC5zY3NzIl0sIm5hbWVzIjpbXSwibWFwcGluZ3MiOiJBQUFBO0VBQ0UsWUFBQTtFQUNBLDBCQUFBO0VBQ0EsWUFBQTtFQUNBLHlCQUFBO0VBQ0Esa0JBQUE7RUFDQSw0QkFBQTtFQUNBLCtCQUFBO0FBQ0Y7O0FBRUE7RUFDRSx1QkFBQTtFQUNBLG1CQUFBO0VBQ0EsaUJBQUE7RUFDQSxrQkFBQTtFQUNBLDJCQUFBO0VBQ0EsbUJBQUE7QUFDRjs7QUFFQTtFQUNFLHlCQUFBO0VBQ0EsaUJBQUE7RUFDQSxrQkFBQTtFQUNBLGdCQUFBO0VBQ0EsbUJBQUE7QUFDRjs7QUFFQTtFQUNFLHVCQUFBO0VBQ0EsaUJBQUE7RUFDQSxrQkFBQTtFQUNBLGdCQUFBO0VBQ0EsbUJBQUE7RUFDQSxrQkFBQTtBQUNGOztBQUVBO0VBQ0UsWUFBQTtFQUNBLHVCQUFBO0FBQ0Y7O0FBQUU7RUFDRSxvQkFBQTtFQUNBLGtDQUFBO0VBQ0Esb0NBQUE7RUFDQSxrQkFBQTtFQUNBLFVBQUE7RUFDQSxrQkFBQTtFQUNBLFdBQUE7RUFDQSxTQUFBO0FBRUo7O0FBQ0E7RUFDRSwwQ0FBQTtBQUVGOztBQUFBO0VBQ0UseUNBQUE7QUFHRjs7QUFEQTtFQUNFLHVDQUFBO0FBSUY7O0FBRkE7RUFDRSxrQkFBQTtBQUtGOztBQUhFO0VBQ0UsaUJBQUE7RUFDQSxXQUFBO0VBQ0EsaUJBQUE7RUFDQSx1QkFBQTtBQUtKOztBQUhFO0VBQ0Usa0JBQUE7RUFDQSxRQUFBO0VBQ0Esb0NBQUE7RUFDQSxXQUFBO0VBQ0EsWUFBQTtFQUNBLFlBQUE7QUFLSiIsImZpbGUiOiJwdWJsaWMtY2FtcGFpZ24tY2FyZC5jb21wb25lbnQuc2NzcyIsInNvdXJjZXNDb250ZW50IjpbIi5wcm9ncmVzcy1iYXIge1xuICBoZWlnaHQ6IDI0cHg7XG4gIHdpZHRoOiB2YXIoLS12YXJ3aWR0aCwgMCUpO1xuICBjb2xvcjogYmxhY2s7XG4gIGJhY2tncm91bmQtY29sb3I6IHJnYig4LCAxNjYsIDI0MCk7XG4gIHRleHQtYWxpZ246IGNlbnRlcjtcbiAgYm9yZGVyLXRvcC1sZWZ0LXJhZGl1czogMTBweDtcbiAgYm9yZGVyLWJvdHRvbS1sZWZ0LXJhZGl1czogMTBweDtcbn1cblxuLnByb2dyZXNzLWJhci1jb250b3VybiB7XG4gIGJvcmRlcjogMXB4IHNvbGlkIGJsYWNrO1xuICBib3JkZXItY29sb3I6IGJsYWNrO1xuICBtYXJnaW4tbGVmdDogMThweDtcbiAgbWFyZ2luLXJpZ2h0OiAxOHB4O1xuICBiYWNrZ3JvdW5kLWNvbG9yOiBsaWdodGdyZXk7XG4gIGJvcmRlci1yYWRpdXM6IDEwcHg7XG59XG5cbi5ib3JkZXItY2xhc3Mge1xuICBib3JkZXI6IDFweCBzb2xpZCByZ2IoNjMsIDYzLCA2Myk7XG4gIG1hcmdpbi1sZWZ0OiAxOHB4O1xuICBtYXJnaW4tcmlnaHQ6IDE4cHg7XG4gIG1hcmdpbi10b3A6IDEwcHg7XG4gIG1hcmdpbi1ib3R0b206IDEwcHg7XG59XG5cbi5ib3JkZXItY2xhc3MtZmFuY3kge1xuICBib3JkZXI6IDFweCBzb2xpZCByZ2IoMjU1LCAyNTUsIDI1NSk7XG4gIG1hcmdpbi1sZWZ0OiAxOHB4O1xuICBtYXJnaW4tcmlnaHQ6IDE4cHg7XG4gIG1hcmdpbi10b3A6IDEwcHg7XG4gIG1hcmdpbi1ib3R0b206IDEwcHg7XG4gIGJvcmRlci1yYWRpdXM6IDRweDtcbn1cblxuLmlvbi1jYXJkIHtcbiAgY29sb3I6IGJsYWNrO1xuICBiYWNrZ3JvdW5kLWNvbG9yOiB3aGl0ZTtcbiAgZGl2IGlvbi1hdmF0YXIge1xuICAgIC0tYm9yZGVyLXJhZGl1czogNTAlO1xuICAgIGJvcmRlcjogc29saWQgM3B4IHJnYmEoMCwgMCwgMCwgMCk7XG4gICAgYmFja2dyb3VuZC1jb2xvcjogcmdiYSgwLCAwLCAwLCAwLjUpO1xuICAgIHBvc2l0aW9uOiBhYnNvbHV0ZTtcbiAgICB6LWluZGV4OiAyO1xuICAgIHRleHQtYWxpZ246IGNlbnRlcjtcbiAgICByaWdodDogMjBweDtcbiAgICB0b3A6IDQwcHg7XG4gIH1cbn1cbi5jb21wYW55IHtcbiAgYm9yZGVyOiAzcHggc29saWQgdmFyKC0taW9uLWNvbG9yLWNvbXBhbnkpO1xufVxuLnNjaG9vbCB7XG4gIGJvcmRlcjogM3B4IHNvbGlkIHZhcigtLWlvbi1jb2xvci1zY2hvb2wpO1xufVxuLmNpdHkge1xuICBib3JkZXI6IDNweCBzb2xpZCB2YXIoLS1pb24tY29sb3ItY2l0eSk7XG59XG4uaGVhZGVyIHtcbiAgcG9zaXRpb246IHJlbGF0aXZlO1xuXG4gIC5iYW5uZXIge1xuICAgIG1heC1oZWlnaHQ6IDIwMHB4O1xuICAgIHdpZHRoOiAxMDAlO1xuICAgIG9iamVjdC1maXQ6IGNvdmVyO1xuICAgIG9iamVjdC1wb3NpdGlvbjogY2VudGVyO1xuICB9XG4gIC5oZWFkZXItdGl0bGUge1xuICAgIHBvc2l0aW9uOiBhYnNvbHV0ZTtcbiAgICB0b3A6IDBweDtcbiAgICBiYWNrZ3JvdW5kLWNvbG9yOiByZ2JhKDAsIDAsIDAsIDAuNSk7XG4gICAgd2lkdGg6IDEwMCU7XG4gICAgY29sb3I6IHdoaXRlO1xuICAgIHBhZGRpbmc6IDhweDtcbiAgfVxufVxuIl19 */"]
});

/***/ }),

/***/ 41019:
/*!******************************************************************************************************************!*\
  !*** ./src/app/core/shared/detail-notification/detail-notification-badge/detail-notification-badge.component.ts ***!
  \******************************************************************************************************************/
/***/ (function(__unused_webpack_module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "DetailNotificationBadgeComponent": function() { return /* binding */ DetailNotificationBadgeComponent; }
/* harmony export */ });
/* harmony import */ var _Users_smartcommunitylab_Documents_work_projects_dslab_playgo_mobile_playgo_mobile_node_modules_babel_runtime_helpers_esm_classCallCheck_js__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./node_modules/@babel/runtime/helpers/esm/classCallCheck.js */ 78069);
/* harmony import */ var _Users_smartcommunitylab_Documents_work_projects_dslab_playgo_mobile_playgo_mobile_node_modules_babel_runtime_helpers_esm_createClass_js__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ./node_modules/@babel/runtime/helpers/esm/createClass.js */ 48047);
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @angular/core */ 3184);



var DetailNotificationBadgeComponent = /*#__PURE__*/function () {
  function DetailNotificationBadgeComponent() {
    (0,_Users_smartcommunitylab_Documents_work_projects_dslab_playgo_mobile_playgo_mobile_node_modules_babel_runtime_helpers_esm_classCallCheck_js__WEBPACK_IMPORTED_MODULE_0__["default"])(this, DetailNotificationBadgeComponent);
  }

  (0,_Users_smartcommunitylab_Documents_work_projects_dslab_playgo_mobile_playgo_mobile_node_modules_babel_runtime_helpers_esm_createClass_js__WEBPACK_IMPORTED_MODULE_1__["default"])(DetailNotificationBadgeComponent, [{
    key: "ngOnInit",
    value: function ngOnInit() {}
  }]);

  return DetailNotificationBadgeComponent;
}();

DetailNotificationBadgeComponent.ɵfac = function DetailNotificationBadgeComponent_Factory(t) {
  return new (t || DetailNotificationBadgeComponent)();
};

DetailNotificationBadgeComponent.ɵcmp = /*@__PURE__*/_angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵdefineComponent"]({
  type: DetailNotificationBadgeComponent,
  selectors: [["app-detail-notification-badge"]],
  inputs: {
    notification: "notification"
  },
  decls: 2,
  vars: 1,
  template: function DetailNotificationBadgeComponent_Template(rf, ctx) {
    if (rf & 1) {
      _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵelementStart"](0, "p");
      _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵtext"](1);
      _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵelementEnd"]();
    }

    if (rf & 2) {
      _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵadvance"](1);
      _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵtextInterpolate1"](" Congratulazioni, hai vinto un nuovo badge ", ctx.notification.description, "\n");
    }
  },
  styles: ["\n/*# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbXSwibmFtZXMiOltdLCJtYXBwaW5ncyI6IiIsImZpbGUiOiJkZXRhaWwtbm90aWZpY2F0aW9uLWJhZGdlLmNvbXBvbmVudC5zY3NzIn0= */"]
});

/***/ }),

/***/ 52726:
/*!******************************************************************************************************************!*\
  !*** ./src/app/core/shared/detail-notification/detail-notification-level/detail-notification-level.component.ts ***!
  \******************************************************************************************************************/
/***/ (function(__unused_webpack_module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "DetailNotificationLevelComponent": function() { return /* binding */ DetailNotificationLevelComponent; }
/* harmony export */ });
/* harmony import */ var _Users_smartcommunitylab_Documents_work_projects_dslab_playgo_mobile_playgo_mobile_node_modules_babel_runtime_helpers_esm_classCallCheck_js__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./node_modules/@babel/runtime/helpers/esm/classCallCheck.js */ 78069);
/* harmony import */ var _Users_smartcommunitylab_Documents_work_projects_dslab_playgo_mobile_playgo_mobile_node_modules_babel_runtime_helpers_esm_createClass_js__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ./node_modules/@babel/runtime/helpers/esm/createClass.js */ 48047);
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @angular/core */ 3184);



var DetailNotificationLevelComponent = /*#__PURE__*/function () {
  function DetailNotificationLevelComponent() {
    (0,_Users_smartcommunitylab_Documents_work_projects_dslab_playgo_mobile_playgo_mobile_node_modules_babel_runtime_helpers_esm_classCallCheck_js__WEBPACK_IMPORTED_MODULE_0__["default"])(this, DetailNotificationLevelComponent);
  }

  (0,_Users_smartcommunitylab_Documents_work_projects_dslab_playgo_mobile_playgo_mobile_node_modules_babel_runtime_helpers_esm_createClass_js__WEBPACK_IMPORTED_MODULE_1__["default"])(DetailNotificationLevelComponent, [{
    key: "ngOnInit",
    value: function ngOnInit() {}
  }]);

  return DetailNotificationLevelComponent;
}();

DetailNotificationLevelComponent.ɵfac = function DetailNotificationLevelComponent_Factory(t) {
  return new (t || DetailNotificationLevelComponent)();
};

DetailNotificationLevelComponent.ɵcmp = /*@__PURE__*/_angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵdefineComponent"]({
  type: DetailNotificationLevelComponent,
  selectors: [["app-detail-notification-level"]],
  inputs: {
    notification: "notification"
  },
  decls: 2,
  vars: 1,
  template: function DetailNotificationLevelComponent_Template(rf, ctx) {
    if (rf & 1) {
      _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵelementStart"](0, "p");
      _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵtext"](1);
      _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵelementEnd"]();
    }

    if (rf & 2) {
      _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵadvance"](1);
      _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵtextInterpolate1"](" Congratulazioni, sei salito di livello ", ctx.notification.description, "\n");
    }
  },
  styles: ["\n/*# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbXSwibmFtZXMiOltdLCJtYXBwaW5ncyI6IiIsImZpbGUiOiJkZXRhaWwtbm90aWZpY2F0aW9uLWxldmVsLmNvbXBvbmVudC5zY3NzIn0= */"]
});

/***/ }),

/***/ 72526:
/*!******************************************************************************!*\
  !*** ./src/app/core/shared/detail-notification/detail-notification.modal.ts ***!
  \******************************************************************************/
/***/ (function(__unused_webpack_module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "DetailNotificationModalPage": function() { return /* binding */ DetailNotificationModalPage; }
/* harmony export */ });
/* harmony import */ var _Users_smartcommunitylab_Documents_work_projects_dslab_playgo_mobile_playgo_mobile_node_modules_babel_runtime_helpers_esm_classCallCheck_js__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./node_modules/@babel/runtime/helpers/esm/classCallCheck.js */ 78069);
/* harmony import */ var _Users_smartcommunitylab_Documents_work_projects_dslab_playgo_mobile_playgo_mobile_node_modules_babel_runtime_helpers_esm_createClass_js__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ./node_modules/@babel/runtime/helpers/esm/createClass.js */ 48047);
/* harmony import */ var _services_notifications_notifications_service__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! ../services/notifications/notifications.service */ 30299);
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! @angular/core */ 3184);
/* harmony import */ var _ionic_angular__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! @ionic/angular */ 93819);
/* harmony import */ var _angular_common__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(/*! @angular/common */ 36362);
/* harmony import */ var _detail_notification_level_detail_notification_level_component__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! ./detail-notification-level/detail-notification-level.component */ 52726);
/* harmony import */ var _detail_notification_badge_detail_notification_badge_component__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! ./detail-notification-badge/detail-notification-badge.component */ 41019);
/* harmony import */ var _ngx_translate_core__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(/*! @ngx-translate/core */ 87514);










function DetailNotificationModalPage_div_10_Template(rf, ctx) {
  if (rf & 1) {
    _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵelementStart"](0, "div");
    _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵelement"](1, "app-detail-notification-level", 6);
    _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵelementEnd"]();
  }

  if (rf & 2) {
    var ctx_r0 = _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵnextContext"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵadvance"](1);
    _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵproperty"]("notification", ctx_r0.notification);
  }
}

function DetailNotificationModalPage_div_11_Template(rf, ctx) {
  if (rf & 1) {
    _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵelementStart"](0, "div");
    _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵelement"](1, "app-detail-notification-badge", 6);
    _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵelementEnd"]();
  }

  if (rf & 2) {
    var ctx_r1 = _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵnextContext"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵadvance"](1);
    _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵproperty"]("notification", ctx_r1.notification);
  }
}

function DetailNotificationModalPage_div_12_Template(rf, ctx) {
  if (rf & 1) {
    _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵelement"](0, "div", 7);
  }

  if (rf & 2) {
    var ctx_r2 = _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵnextContext"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵproperty"]("innerHTML", ctx_r2.notification == null ? null : ctx_r2.notification.description, _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵsanitizeHtml"]);
  }
}

var DetailNotificationModalPage = /*#__PURE__*/function () {
  function DetailNotificationModalPage(modalController) {
    (0,_Users_smartcommunitylab_Documents_work_projects_dslab_playgo_mobile_playgo_mobile_node_modules_babel_runtime_helpers_esm_classCallCheck_js__WEBPACK_IMPORTED_MODULE_0__["default"])(this, DetailNotificationModalPage);

    this.modalController = modalController;
    this.notificationType = _services_notifications_notifications_service__WEBPACK_IMPORTED_MODULE_2__.NotificationType;
  }

  (0,_Users_smartcommunitylab_Documents_work_projects_dslab_playgo_mobile_playgo_mobile_node_modules_babel_runtime_helpers_esm_createClass_js__WEBPACK_IMPORTED_MODULE_1__["default"])(DetailNotificationModalPage, [{
    key: "ngOnInit",
    value: function ngOnInit() {}
  }, {
    key: "close",
    value: function close() {
      this.modalController.dismiss(false);
    }
  }]);

  return DetailNotificationModalPage;
}();

DetailNotificationModalPage.ɵfac = function DetailNotificationModalPage_Factory(t) {
  return new (t || DetailNotificationModalPage)(_angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵdirectiveInject"](_ionic_angular__WEBPACK_IMPORTED_MODULE_6__.ModalController));
};

DetailNotificationModalPage.ɵcmp = /*@__PURE__*/_angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵdefineComponent"]({
  type: DetailNotificationModalPage,
  selectors: [["app-detail-notification-modal"]],
  decls: 13,
  vars: 7,
  consts: [["color", "playgo"], ["slot", "end"], [3, "click"], [3, "ngSwitch"], [4, "ngSwitchCase"], [3, "innerHTML", 4, "ngSwitchDefault"], [3, "notification"], [3, "innerHTML"]],
  template: function DetailNotificationModalPage_Template(rf, ctx) {
    if (rf & 1) {
      _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵelementStart"](0, "ion-header")(1, "ion-toolbar", 0)(2, "ion-title");
      _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵtext"](3);
      _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵelementEnd"]();
      _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵelementStart"](4, "ion-buttons", 1)(5, "ion-button", 2);
      _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵlistener"]("click", function DetailNotificationModalPage_Template_ion_button_click_5_listener() {
        return ctx.close();
      });
      _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵtext"](6);
      _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵpipe"](7, "translate");
      _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵelementEnd"]()()()();
      _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵelementStart"](8, "ion-content", 0)(9, "div", 3);
      _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵtemplate"](10, DetailNotificationModalPage_div_10_Template, 2, 1, "div", 4);
      _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵtemplate"](11, DetailNotificationModalPage_div_11_Template, 2, 1, "div", 4);
      _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵtemplate"](12, DetailNotificationModalPage_div_12_Template, 1, 1, "div", 5);
      _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵelementEnd"]()();
    }

    if (rf & 2) {
      _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵadvance"](3);
      _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵtextInterpolate"](ctx.notification == null ? null : ctx.notification.title);
      _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵadvance"](3);
      _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵtextInterpolate"](_angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵpipeBind1"](7, 5, "campaigns.joinmodal.close"));
      _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵadvance"](3);
      _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵproperty"]("ngSwitch", ctx.notification == null ? null : ctx.notification.content == null ? null : ctx.notification.content.type);
      _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵadvance"](1);
      _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵproperty"]("ngSwitchCase", ctx.notificationType.level);
      _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵadvance"](1);
      _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵproperty"]("ngSwitchCase", ctx.notificationType.badge);
    }
  },
  directives: [_ionic_angular__WEBPACK_IMPORTED_MODULE_6__.IonHeader, _ionic_angular__WEBPACK_IMPORTED_MODULE_6__.IonToolbar, _ionic_angular__WEBPACK_IMPORTED_MODULE_6__.IonTitle, _ionic_angular__WEBPACK_IMPORTED_MODULE_6__.IonButtons, _ionic_angular__WEBPACK_IMPORTED_MODULE_6__.IonButton, _ionic_angular__WEBPACK_IMPORTED_MODULE_6__.IonContent, _angular_common__WEBPACK_IMPORTED_MODULE_7__.NgSwitch, _angular_common__WEBPACK_IMPORTED_MODULE_7__.NgSwitchCase, _detail_notification_level_detail_notification_level_component__WEBPACK_IMPORTED_MODULE_3__.DetailNotificationLevelComponent, _detail_notification_badge_detail_notification_badge_component__WEBPACK_IMPORTED_MODULE_4__.DetailNotificationBadgeComponent, _angular_common__WEBPACK_IMPORTED_MODULE_7__.NgSwitchDefault],
  pipes: [_ngx_translate_core__WEBPACK_IMPORTED_MODULE_8__.TranslatePipe],
  styles: ["\n/*# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbXSwibmFtZXMiOltdLCJtYXBwaW5ncyI6IiIsImZpbGUiOiJkZXRhaWwtbm90aWZpY2F0aW9uLm1vZGFsLnNjc3MifQ== */"]
});

/***/ }),

/***/ 2773:
/*!*********************************************************************!*\
  !*** ./src/app/core/shared/directives/parallax-header.directive.ts ***!
  \*********************************************************************/
/***/ (function(__unused_webpack_module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "ParallaxDirective": function() { return /* binding */ ParallaxDirective; }
/* harmony export */ });
/* harmony import */ var _Users_smartcommunitylab_Documents_work_projects_dslab_playgo_mobile_playgo_mobile_node_modules_babel_runtime_helpers_esm_classCallCheck_js__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./node_modules/@babel/runtime/helpers/esm/classCallCheck.js */ 78069);
/* harmony import */ var _Users_smartcommunitylab_Documents_work_projects_dslab_playgo_mobile_playgo_mobile_node_modules_babel_runtime_helpers_esm_createClass_js__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ./node_modules/@babel/runtime/helpers/esm/createClass.js */ 48047);
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! tslib */ 34929);
/* harmony import */ var _ionic_angular__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(/*! @ionic/angular */ 93819);
/* harmony import */ var to_px__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! to-px */ 87097);
/* harmony import */ var to_px__WEBPACK_IMPORTED_MODULE_2___default = /*#__PURE__*/__webpack_require__.n(to_px__WEBPACK_IMPORTED_MODULE_2__);
/* harmony import */ var _utils__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! ../utils */ 68647);
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! @angular/core */ 3184);
/* harmony import */ var _layout_header_header_directive__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! ../layout/header/header.directive */ 34161);



function _regeneratorRuntime() { "use strict"; /*! regenerator-runtime -- Copyright (c) 2014-present, Facebook, Inc. -- license (MIT): https://github.com/facebook/regenerator/blob/main/LICENSE */ _regeneratorRuntime = function _regeneratorRuntime() { return exports; }; var exports = {}, Op = Object.prototype, hasOwn = Op.hasOwnProperty, $Symbol = "function" == typeof Symbol ? Symbol : {}, iteratorSymbol = $Symbol.iterator || "@@iterator", asyncIteratorSymbol = $Symbol.asyncIterator || "@@asyncIterator", toStringTagSymbol = $Symbol.toStringTag || "@@toStringTag"; function define(obj, key, value) { return Object.defineProperty(obj, key, { value: value, enumerable: !0, configurable: !0, writable: !0 }), obj[key]; } try { define({}, ""); } catch (err) { define = function define(obj, key, value) { return obj[key] = value; }; } function wrap(innerFn, outerFn, self, tryLocsList) { var protoGenerator = outerFn && outerFn.prototype instanceof Generator ? outerFn : Generator, generator = Object.create(protoGenerator.prototype), context = new Context(tryLocsList || []); return generator._invoke = function (innerFn, self, context) { var state = "suspendedStart"; return function (method, arg) { if ("executing" === state) throw new Error("Generator is already running"); if ("completed" === state) { if ("throw" === method) throw arg; return doneResult(); } for (context.method = method, context.arg = arg;;) { var delegate = context.delegate; if (delegate) { var delegateResult = maybeInvokeDelegate(delegate, context); if (delegateResult) { if (delegateResult === ContinueSentinel) continue; return delegateResult; } } if ("next" === context.method) context.sent = context._sent = context.arg;else if ("throw" === context.method) { if ("suspendedStart" === state) throw state = "completed", context.arg; context.dispatchException(context.arg); } else "return" === context.method && context.abrupt("return", context.arg); state = "executing"; var record = tryCatch(innerFn, self, context); if ("normal" === record.type) { if (state = context.done ? "completed" : "suspendedYield", record.arg === ContinueSentinel) continue; return { value: record.arg, done: context.done }; } "throw" === record.type && (state = "completed", context.method = "throw", context.arg = record.arg); } }; }(innerFn, self, context), generator; } function tryCatch(fn, obj, arg) { try { return { type: "normal", arg: fn.call(obj, arg) }; } catch (err) { return { type: "throw", arg: err }; } } exports.wrap = wrap; var ContinueSentinel = {}; function Generator() {} function GeneratorFunction() {} function GeneratorFunctionPrototype() {} var IteratorPrototype = {}; define(IteratorPrototype, iteratorSymbol, function () { return this; }); var getProto = Object.getPrototypeOf, NativeIteratorPrototype = getProto && getProto(getProto(values([]))); NativeIteratorPrototype && NativeIteratorPrototype !== Op && hasOwn.call(NativeIteratorPrototype, iteratorSymbol) && (IteratorPrototype = NativeIteratorPrototype); var Gp = GeneratorFunctionPrototype.prototype = Generator.prototype = Object.create(IteratorPrototype); function defineIteratorMethods(prototype) { ["next", "throw", "return"].forEach(function (method) { define(prototype, method, function (arg) { return this._invoke(method, arg); }); }); } function AsyncIterator(generator, PromiseImpl) { function invoke(method, arg, resolve, reject) { var record = tryCatch(generator[method], generator, arg); if ("throw" !== record.type) { var result = record.arg, value = result.value; return value && "object" == typeof value && hasOwn.call(value, "__await") ? PromiseImpl.resolve(value.__await).then(function (value) { invoke("next", value, resolve, reject); }, function (err) { invoke("throw", err, resolve, reject); }) : PromiseImpl.resolve(value).then(function (unwrapped) { result.value = unwrapped, resolve(result); }, function (error) { return invoke("throw", error, resolve, reject); }); } reject(record.arg); } var previousPromise; this._invoke = function (method, arg) { function callInvokeWithMethodAndArg() { return new PromiseImpl(function (resolve, reject) { invoke(method, arg, resolve, reject); }); } return previousPromise = previousPromise ? previousPromise.then(callInvokeWithMethodAndArg, callInvokeWithMethodAndArg) : callInvokeWithMethodAndArg(); }; } function maybeInvokeDelegate(delegate, context) { var method = delegate.iterator[context.method]; if (undefined === method) { if (context.delegate = null, "throw" === context.method) { if (delegate.iterator.return && (context.method = "return", context.arg = undefined, maybeInvokeDelegate(delegate, context), "throw" === context.method)) return ContinueSentinel; context.method = "throw", context.arg = new TypeError("The iterator does not provide a 'throw' method"); } return ContinueSentinel; } var record = tryCatch(method, delegate.iterator, context.arg); if ("throw" === record.type) return context.method = "throw", context.arg = record.arg, context.delegate = null, ContinueSentinel; var info = record.arg; return info ? info.done ? (context[delegate.resultName] = info.value, context.next = delegate.nextLoc, "return" !== context.method && (context.method = "next", context.arg = undefined), context.delegate = null, ContinueSentinel) : info : (context.method = "throw", context.arg = new TypeError("iterator result is not an object"), context.delegate = null, ContinueSentinel); } function pushTryEntry(locs) { var entry = { tryLoc: locs[0] }; 1 in locs && (entry.catchLoc = locs[1]), 2 in locs && (entry.finallyLoc = locs[2], entry.afterLoc = locs[3]), this.tryEntries.push(entry); } function resetTryEntry(entry) { var record = entry.completion || {}; record.type = "normal", delete record.arg, entry.completion = record; } function Context(tryLocsList) { this.tryEntries = [{ tryLoc: "root" }], tryLocsList.forEach(pushTryEntry, this), this.reset(!0); } function values(iterable) { if (iterable) { var iteratorMethod = iterable[iteratorSymbol]; if (iteratorMethod) return iteratorMethod.call(iterable); if ("function" == typeof iterable.next) return iterable; if (!isNaN(iterable.length)) { var i = -1, next = function next() { for (; ++i < iterable.length;) { if (hasOwn.call(iterable, i)) return next.value = iterable[i], next.done = !1, next; } return next.value = undefined, next.done = !0, next; }; return next.next = next; } } return { next: doneResult }; } function doneResult() { return { value: undefined, done: !0 }; } return GeneratorFunction.prototype = GeneratorFunctionPrototype, define(Gp, "constructor", GeneratorFunctionPrototype), define(GeneratorFunctionPrototype, "constructor", GeneratorFunction), GeneratorFunction.displayName = define(GeneratorFunctionPrototype, toStringTagSymbol, "GeneratorFunction"), exports.isGeneratorFunction = function (genFun) { var ctor = "function" == typeof genFun && genFun.constructor; return !!ctor && (ctor === GeneratorFunction || "GeneratorFunction" === (ctor.displayName || ctor.name)); }, exports.mark = function (genFun) { return Object.setPrototypeOf ? Object.setPrototypeOf(genFun, GeneratorFunctionPrototype) : (genFun.__proto__ = GeneratorFunctionPrototype, define(genFun, toStringTagSymbol, "GeneratorFunction")), genFun.prototype = Object.create(Gp), genFun; }, exports.awrap = function (arg) { return { __await: arg }; }, defineIteratorMethods(AsyncIterator.prototype), define(AsyncIterator.prototype, asyncIteratorSymbol, function () { return this; }), exports.AsyncIterator = AsyncIterator, exports.async = function (innerFn, outerFn, self, tryLocsList, PromiseImpl) { void 0 === PromiseImpl && (PromiseImpl = Promise); var iter = new AsyncIterator(wrap(innerFn, outerFn, self, tryLocsList), PromiseImpl); return exports.isGeneratorFunction(outerFn) ? iter : iter.next().then(function (result) { return result.done ? result.value : iter.next(); }); }, defineIteratorMethods(Gp), define(Gp, toStringTagSymbol, "Generator"), define(Gp, iteratorSymbol, function () { return this; }), define(Gp, "toString", function () { return "[object Generator]"; }), exports.keys = function (object) { var keys = []; for (var key in object) { keys.push(key); } return keys.reverse(), function next() { for (; keys.length;) { var key = keys.pop(); if (key in object) return next.value = key, next.done = !1, next; } return next.done = !0, next; }; }, exports.values = values, Context.prototype = { constructor: Context, reset: function reset(skipTempReset) { if (this.prev = 0, this.next = 0, this.sent = this._sent = undefined, this.done = !1, this.delegate = null, this.method = "next", this.arg = undefined, this.tryEntries.forEach(resetTryEntry), !skipTempReset) for (var name in this) { "t" === name.charAt(0) && hasOwn.call(this, name) && !isNaN(+name.slice(1)) && (this[name] = undefined); } }, stop: function stop() { this.done = !0; var rootRecord = this.tryEntries[0].completion; if ("throw" === rootRecord.type) throw rootRecord.arg; return this.rval; }, dispatchException: function dispatchException(exception) { if (this.done) throw exception; var context = this; function handle(loc, caught) { return record.type = "throw", record.arg = exception, context.next = loc, caught && (context.method = "next", context.arg = undefined), !!caught; } for (var i = this.tryEntries.length - 1; i >= 0; --i) { var entry = this.tryEntries[i], record = entry.completion; if ("root" === entry.tryLoc) return handle("end"); if (entry.tryLoc <= this.prev) { var hasCatch = hasOwn.call(entry, "catchLoc"), hasFinally = hasOwn.call(entry, "finallyLoc"); if (hasCatch && hasFinally) { if (this.prev < entry.catchLoc) return handle(entry.catchLoc, !0); if (this.prev < entry.finallyLoc) return handle(entry.finallyLoc); } else if (hasCatch) { if (this.prev < entry.catchLoc) return handle(entry.catchLoc, !0); } else { if (!hasFinally) throw new Error("try statement without catch or finally"); if (this.prev < entry.finallyLoc) return handle(entry.finallyLoc); } } } }, abrupt: function abrupt(type, arg) { for (var i = this.tryEntries.length - 1; i >= 0; --i) { var entry = this.tryEntries[i]; if (entry.tryLoc <= this.prev && hasOwn.call(entry, "finallyLoc") && this.prev < entry.finallyLoc) { var finallyEntry = entry; break; } } finallyEntry && ("break" === type || "continue" === type) && finallyEntry.tryLoc <= arg && arg <= finallyEntry.finallyLoc && (finallyEntry = null); var record = finallyEntry ? finallyEntry.completion : {}; return record.type = type, record.arg = arg, finallyEntry ? (this.method = "next", this.next = finallyEntry.finallyLoc, ContinueSentinel) : this.complete(record); }, complete: function complete(record, afterLoc) { if ("throw" === record.type) throw record.arg; return "break" === record.type || "continue" === record.type ? this.next = record.arg : "return" === record.type ? (this.rval = this.arg = record.arg, this.method = "return", this.next = "end") : "normal" === record.type && afterLoc && (this.next = afterLoc), ContinueSentinel; }, finish: function finish(finallyLoc) { for (var i = this.tryEntries.length - 1; i >= 0; --i) { var entry = this.tryEntries[i]; if (entry.finallyLoc === finallyLoc) return this.complete(entry.completion, entry.afterLoc), resetTryEntry(entry), ContinueSentinel; } }, catch: function _catch(tryLoc) { for (var i = this.tryEntries.length - 1; i >= 0; --i) { var entry = this.tryEntries[i]; if (entry.tryLoc === tryLoc) { var record = entry.completion; if ("throw" === record.type) { var thrown = record.arg; resetTryEntry(entry); } return thrown; } } throw new Error("illegal catch attempt"); }, delegateYield: function delegateYield(iterable, resultName, nextLoc) { return this.delegate = { iterator: values(iterable), resultName: resultName, nextLoc: nextLoc }, "next" === this.method && (this.arg = undefined), ContinueSentinel; } }, exports; }







var ParallaxDirective = /*#__PURE__*/function () {
  function ParallaxDirective(headerRef, renderer, headerDirective) {
    (0,_Users_smartcommunitylab_Documents_work_projects_dslab_playgo_mobile_playgo_mobile_node_modules_babel_runtime_helpers_esm_classCallCheck_js__WEBPACK_IMPORTED_MODULE_0__["default"])(this, ParallaxDirective);

    this.headerRef = headerRef;
    this.renderer = renderer;
    this.headerDirective = headerDirective;
    this.height = 300;
    this.bgPosition = 'top';
    this.originalToolbarHeight = 0;
    this.ticking = false;
  }

  (0,_Users_smartcommunitylab_Documents_work_projects_dslab_playgo_mobile_playgo_mobile_node_modules_babel_runtime_helpers_esm_createClass_js__WEBPACK_IMPORTED_MODULE_1__["default"])(ParallaxDirective, [{
    key: "ngAfterContentInit",
    value: function ngAfterContentInit() {
      this.init();
    }
  }, {
    key: "init",
    value: function init() {
      var numOfTry = arguments.length > 0 && arguments[0] !== undefined ? arguments[0] : 0;
      return (0,tslib__WEBPACK_IMPORTED_MODULE_5__.__awaiter)(this, void 0, void 0, /*#__PURE__*/_regeneratorRuntime().mark(function _callee() {
        return _regeneratorRuntime().wrap(function _callee$(_context) {
          while (1) {
            switch (_context.prev = _context.next) {
              case 0:
                _context.prev = 0;

                if (this.initElements()) {
                  this.setupContentPadding();
                  this.setupImageOverlay();
                  this.setupPointerEventsForButtons();
                  this.setupEvents();
                  this.updateProgress();
                }

                _context.next = 14;
                break;

              case 4:
                _context.prev = 4;
                _context.t0 = _context["catch"](0);

                if (!(numOfTry > 5)) {
                  _context.next = 10;
                  break;
                }

                console.log('parallax error', _context.t0);
                _context.next = 14;
                break;

              case 10:
                _context.next = 12;
                return (0,_utils__WEBPACK_IMPORTED_MODULE_3__.waitMs)(100);

              case 12:
                _context.next = 14;
                return this.init(numOfTry + 1);

              case 14:
              case "end":
                return _context.stop();
            }
          }
        }, _callee, this, [[0, 4]]);
      }));
    }
  }, {
    key: "header",
    get: function get() {
      return this.headerRef.nativeElement;
    }
    /**
     * Return the value of the input parameter `height` as a string with units.
     * If no units were provided, it will default to 'px'.
     */

  }, {
    key: "getMaxHeightWithUnits",
    value: function getMaxHeightWithUnits() {
      return !isNaN(+this.height) || typeof this.height === 'number' ? this.height + 'px' : this.height;
    }
  }, {
    key: "getMaxHeightInPx",
    value: function getMaxHeightInPx() {
      return to_px__WEBPACK_IMPORTED_MODULE_2___default()(this.getMaxHeightWithUnits());
    }
  }, {
    key: "initElements",
    value: function initElements() {
      if (this.headerDirective) {
        // If we are using [appHeader] directive, than @ContentChild will not resolve elements
        // so we need to get them from the HeaderContentComponent via @ViewChild
        var headerContentComponent = this.headerDirective.headerContentComponent.instance;
        this.ionToolbar = headerContentComponent.ionToolbar;
        this.ionTitle = headerContentComponent.ionTitle;
        this.ionButtons = headerContentComponent.ionButtons;
      }

      if (!this.ionToolbar) {
        console.error('A <ion-toolbar> element is needed inside <ion-header> or using the [appHeader] directive on the <ion-header>');
        return false;
      }

      var parentElement = this.header.parentElement;
      var ionContent = parentElement.querySelector('ion-content');

      if (!ionContent) {
        console.error('A <ion-content> element is needed');
        return false;
      }

      this.innerScroll = ionContent.shadowRoot.querySelector('.inner-scroll');
      this.originalToolbarHeight = this.ionToolbar.el.offsetHeight;
      console.log('this.originalToolbarHeight', this.originalToolbarHeight);
      console.log('this.ionToolbar.el.clientHeight', this.ionToolbar.el.clientHeight);
      this.toolbarContainer = this.ionToolbar.el.shadowRoot.querySelector('.toolbar-container');
      this.toolbarBackground = this.ionToolbar.el.shadowRoot.querySelector('.toolbar-background');
      this.color = this.color || window.getComputedStyle(this.toolbarBackground).backgroundColor;
      this.renderer.setStyle(this.toolbarContainer, 'align-items', 'baseline');
      return true;
    }
  }, {
    key: "setupPointerEventsForButtons",
    value: function setupPointerEventsForButtons() {
      var _this = this;

      this.renderer.setStyle(this.header, 'pointer-events', 'none');
      this.ionToolbar.el.querySelectorAll('ion-buttons').forEach(function (item) {
        return _this.renderer.setStyle(item, 'pointer-events', 'all');
      });
    }
  }, {
    key: "setupContentPadding",
    value: function setupContentPadding() {
      var parentElement = this.header.parentElement;
      var ionContent = parentElement.querySelector('ion-content');
      var mainContent = ionContent.shadowRoot.querySelector('main');

      var _window$getComputedSt = window.getComputedStyle(mainContent),
          paddingTop = _window$getComputedSt.paddingTop;

      var contentPaddingPx = to_px__WEBPACK_IMPORTED_MODULE_2___default()(paddingTop);
      var coverHeightPx = this.getMaxHeightInPx();
      this.renderer.setStyle(this.header, 'position', 'absolute');
      this.renderer.setStyle(this.innerScroll, 'padding-top', "".concat(contentPaddingPx + coverHeightPx, "px"));
    }
  }, {
    key: "setupImageOverlay",
    value: function setupImageOverlay() {
      this.imageOverlay = this.renderer.createElement('div');
      this.renderer.addClass(this.imageOverlay, 'image-overlay');
      this.renderer.setStyle(this.imageOverlay, 'background-color', this.color);
      this.renderer.setStyle(this.imageOverlay, 'background-image', "url(".concat(this.imageUrl || '', ")"));
      this.renderer.setStyle(this.imageOverlay, 'height', "100%");
      this.renderer.setStyle(this.imageOverlay, 'width', '100%');
      this.renderer.setStyle(this.imageOverlay, 'background-size', 'cover');
      this.renderer.setStyle(this.imageOverlay, 'background-position', this.bgPosition);
      this.toolbarBackground.appendChild(this.imageOverlay);
    }
  }, {
    key: "setupEvents",
    value: function setupEvents() {
      var _this2 = this;

      this.innerScroll.addEventListener('scroll', function (_event) {
        if (!_this2.ticking) {
          window.requestAnimationFrame(function () {
            _this2.updateProgress();

            _this2.ticking = false;
          });
        }

        _this2.ticking = true;
      });
    }
    /** Update the parallax effect as per the current scroll of the ion-content */

  }, {
    key: "updateProgress",
    value: function updateProgress() {
      var h = this.getMaxHeightInPx();
      var progress = this.calcProgress(this.innerScroll, h);
      this.progressLayerHeight(progress);
      this.progressLayerOpacity(progress);
    }
  }, {
    key: "progressLayerHeight",
    value: function progressLayerHeight(progress) {
      console.log('progress', progress);
      var h = Math.max(this.getMaxHeightInPx() * (1 - progress), this.originalToolbarHeight);
      console.log('this.getMaxHeightInPx() * (1 - progress)', this.getMaxHeightInPx() * (1 - progress));
      console.log('originalToolbarHeight', this.originalToolbarHeight);
      this.renderer.setStyle(this.toolbarContainer, 'height', "".concat(h, "px"));
      this.renderer.setStyle(this.imageOverlay, 'height', "100%");
    }
  }, {
    key: "progressLayerOpacity",
    value: function progressLayerOpacity(progress) {
      var op = 1 - progress;
      this.renderer.setStyle(this.imageOverlay, 'opacity', op); // this.renderer.setStyle(this.toolbarContainer, 'opacity', progress);
    }
  }, {
    key: "calcProgress",
    value: function calcProgress(scrollingElement, maxHeight) {
      var scroll = +scrollingElement.scrollTop;
      var progress = Math.min(1, Math.max(0, scroll / maxHeight));
      return progress;
    }
  }]);

  return ParallaxDirective;
}();

ParallaxDirective.ɵfac = function ParallaxDirective_Factory(t) {
  return new (t || ParallaxDirective)(_angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵdirectiveInject"](_angular_core__WEBPACK_IMPORTED_MODULE_6__.ElementRef), _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵdirectiveInject"](_angular_core__WEBPACK_IMPORTED_MODULE_6__.Renderer2), _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵdirectiveInject"](_layout_header_header_directive__WEBPACK_IMPORTED_MODULE_4__.HeaderDirective, 8));
};

ParallaxDirective.ɵdir = /*@__PURE__*/_angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵdefineDirective"]({
  type: ParallaxDirective,
  selectors: [["ion-header", "parallax", ""]],
  contentQueries: function ParallaxDirective_ContentQueries(rf, ctx, dirIndex) {
    if (rf & 1) {
      _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵcontentQuery"](dirIndex, _ionic_angular__WEBPACK_IMPORTED_MODULE_7__.IonTitle, 5);
      _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵcontentQuery"](dirIndex, _ionic_angular__WEBPACK_IMPORTED_MODULE_7__.IonToolbar, 5);
      _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵcontentQuery"](dirIndex, _ionic_angular__WEBPACK_IMPORTED_MODULE_7__.IonButtons, 4);
    }

    if (rf & 2) {
      var _t;

      _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵqueryRefresh"](_t = _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵloadQuery"]()) && (ctx.ionTitle = _t.first);
      _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵqueryRefresh"](_t = _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵloadQuery"]()) && (ctx.ionToolbar = _t.first);
      _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵqueryRefresh"](_t = _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵloadQuery"]()) && (ctx.ionButtons = _t);
    }
  },
  inputs: {
    imageUrl: "imageUrl",
    color: "color",
    height: "height",
    bgPosition: "bgPosition"
  }
});

/***/ }),

/***/ 56032:
/*!**************************************************************************************!*\
  !*** ./src/app/core/shared/globalization/ordinal-number/ordinal-number.component.ts ***!
  \**************************************************************************************/
/***/ (function(__unused_webpack_module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "OrdinalNumberComponent": function() { return /* binding */ OrdinalNumberComponent; }
/* harmony export */ });
/* harmony import */ var _Users_smartcommunitylab_Documents_work_projects_dslab_playgo_mobile_playgo_mobile_node_modules_babel_runtime_helpers_esm_classCallCheck_js__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./node_modules/@babel/runtime/helpers/esm/classCallCheck.js */ 78069);
/* harmony import */ var _Users_smartcommunitylab_Documents_work_projects_dslab_playgo_mobile_playgo_mobile_node_modules_babel_runtime_helpers_esm_createClass_js__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ./node_modules/@babel/runtime/helpers/esm/createClass.js */ 48047);
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @angular/core */ 3184);
/* harmony import */ var _services_user_service__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! ../../services/user.service */ 50749);
/* harmony import */ var _angular_common__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! @angular/common */ 36362);
/* harmony import */ var _ngx_translate_core__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! @ngx-translate/core */ 87514);







var _c0 = function _c0(a0) {
  return {
    ordinal: a0
  };
};

function OrdinalNumberComponent_ng_container_0_Template(rf, ctx) {
  if (rf & 1) {
    _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵelementContainerStart"](0);
    _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵtext"](1);
    _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵpipe"](2, "translate");
    _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵelementContainerEnd"]();
  }

  if (rf & 2) {
    var ctx_r0 = _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵnextContext"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵadvance"](1);
    _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵtextInterpolate1"](" ", _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵpipeBind2"](2, 1, "number.ordinal." + ctx_r0.ordinalPluralRules.select(ctx_r0.value), _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵpureFunction1"](4, _c0, ctx_r0.value)), " ");
  }
}

var OrdinalNumberComponent = /*#__PURE__*/function () {
  function OrdinalNumberComponent(userService) {
    (0,_Users_smartcommunitylab_Documents_work_projects_dslab_playgo_mobile_playgo_mobile_node_modules_babel_runtime_helpers_esm_classCallCheck_js__WEBPACK_IMPORTED_MODULE_0__["default"])(this, OrdinalNumberComponent);

    this.userService = userService;
    this.ordinalPluralRules = new Intl.PluralRules(this.userService.getLocale(), {
      type: 'ordinal'
    });
  }

  (0,_Users_smartcommunitylab_Documents_work_projects_dslab_playgo_mobile_playgo_mobile_node_modules_babel_runtime_helpers_esm_createClass_js__WEBPACK_IMPORTED_MODULE_1__["default"])(OrdinalNumberComponent, [{
    key: "ngOnInit",
    value: function ngOnInit() {}
  }]);

  return OrdinalNumberComponent;
}();

OrdinalNumberComponent.ɵfac = function OrdinalNumberComponent_Factory(t) {
  return new (t || OrdinalNumberComponent)(_angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵdirectiveInject"](_services_user_service__WEBPACK_IMPORTED_MODULE_2__.UserService));
};

OrdinalNumberComponent.ɵcmp = /*@__PURE__*/_angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵdefineComponent"]({
  type: OrdinalNumberComponent,
  selectors: [["app-ordinal-number"]],
  inputs: {
    value: "value"
  },
  decls: 1,
  vars: 1,
  consts: [[4, "ngIf"]],
  template: function OrdinalNumberComponent_Template(rf, ctx) {
    if (rf & 1) {
      _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵtemplate"](0, OrdinalNumberComponent_ng_container_0_Template, 3, 6, "ng-container", 0);
    }

    if (rf & 2) {
      _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵproperty"]("ngIf", ctx.value !== undefined);
    }
  },
  directives: [_angular_common__WEBPACK_IMPORTED_MODULE_4__.NgIf],
  pipes: [_ngx_translate_core__WEBPACK_IMPORTED_MODULE_5__.TranslatePipe],
  encapsulation: 2
});

/***/ }),

/***/ 3299:
/*!**************************************************************************!*\
  !*** ./src/app/core/shared/infinite-scroll/infinite-scroll.component.ts ***!
  \**************************************************************************/
/***/ (function(__unused_webpack_module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "InfiniteScrollComponent": function() { return /* binding */ InfiniteScrollComponent; },
/* harmony export */   "InfiniteScrollContentDirective": function() { return /* binding */ InfiniteScrollContentDirective; },
/* harmony export */   "isPageableErrorResponse": function() { return /* binding */ isPageableErrorResponse; },
/* harmony export */   "isPageableSuccessResponse": function() { return /* binding */ isPageableSuccessResponse; }
/* harmony export */ });
/* harmony import */ var _Users_smartcommunitylab_Documents_work_projects_dslab_playgo_mobile_playgo_mobile_node_modules_babel_runtime_helpers_esm_toConsumableArray_js__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./node_modules/@babel/runtime/helpers/esm/toConsumableArray.js */ 58277);
/* harmony import */ var _Users_smartcommunitylab_Documents_work_projects_dslab_playgo_mobile_playgo_mobile_node_modules_babel_runtime_helpers_esm_slicedToArray_js__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ./node_modules/@babel/runtime/helpers/esm/slicedToArray.js */ 10507);
/* harmony import */ var _Users_smartcommunitylab_Documents_work_projects_dslab_playgo_mobile_playgo_mobile_node_modules_babel_runtime_helpers_esm_createClass_js__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! ./node_modules/@babel/runtime/helpers/esm/createClass.js */ 48047);
/* harmony import */ var _Users_smartcommunitylab_Documents_work_projects_dslab_playgo_mobile_playgo_mobile_node_modules_babel_runtime_helpers_esm_classCallCheck_js__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! ./node_modules/@babel/runtime/helpers/esm/classCallCheck.js */ 78069);
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_11__ = __webpack_require__(/*! tslib */ 34929);
/* harmony import */ var _ionic_angular__WEBPACK_IMPORTED_MODULE_19__ = __webpack_require__(/*! @ionic/angular */ 93819);
/* harmony import */ var lodash_es__WEBPACK_IMPORTED_MODULE_16__ = __webpack_require__(/*! lodash-es */ 24304);
/* harmony import */ var lodash_es__WEBPACK_IMPORTED_MODULE_17__ = __webpack_require__(/*! lodash-es */ 55421);
/* harmony import */ var rxjs__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! rxjs */ 80228);
/* harmony import */ var rxjs__WEBPACK_IMPORTED_MODULE_9__ = __webpack_require__(/*! rxjs */ 20591);
/* harmony import */ var rxjs__WEBPACK_IMPORTED_MODULE_12__ = __webpack_require__(/*! rxjs */ 36646);
/* harmony import */ var rxjs_operators__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(/*! rxjs/operators */ 60116);
/* harmony import */ var rxjs_operators__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(/*! rxjs/operators */ 32673);
/* harmony import */ var rxjs_operators__WEBPACK_IMPORTED_MODULE_10__ = __webpack_require__(/*! rxjs/operators */ 80155);
/* harmony import */ var rxjs_operators__WEBPACK_IMPORTED_MODULE_13__ = __webpack_require__(/*! rxjs/operators */ 10538);
/* harmony import */ var rxjs_operators__WEBPACK_IMPORTED_MODULE_14__ = __webpack_require__(/*! rxjs/operators */ 50635);
/* harmony import */ var rxjs_operators__WEBPACK_IMPORTED_MODULE_15__ = __webpack_require__(/*! rxjs/operators */ 44874);
/* harmony import */ var rxjs_operators__WEBPACK_IMPORTED_MODULE_18__ = __webpack_require__(/*! rxjs/operators */ 24503);
/* harmony import */ var _utils__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! ../utils */ 68647);
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! @angular/core */ 3184);
/* harmony import */ var _angular_common__WEBPACK_IMPORTED_MODULE_20__ = __webpack_require__(/*! @angular/common */ 36362);





function _regeneratorRuntime() { "use strict"; /*! regenerator-runtime -- Copyright (c) 2014-present, Facebook, Inc. -- license (MIT): https://github.com/facebook/regenerator/blob/main/LICENSE */ _regeneratorRuntime = function _regeneratorRuntime() { return exports; }; var exports = {}, Op = Object.prototype, hasOwn = Op.hasOwnProperty, $Symbol = "function" == typeof Symbol ? Symbol : {}, iteratorSymbol = $Symbol.iterator || "@@iterator", asyncIteratorSymbol = $Symbol.asyncIterator || "@@asyncIterator", toStringTagSymbol = $Symbol.toStringTag || "@@toStringTag"; function define(obj, key, value) { return Object.defineProperty(obj, key, { value: value, enumerable: !0, configurable: !0, writable: !0 }), obj[key]; } try { define({}, ""); } catch (err) { define = function define(obj, key, value) { return obj[key] = value; }; } function wrap(innerFn, outerFn, self, tryLocsList) { var protoGenerator = outerFn && outerFn.prototype instanceof Generator ? outerFn : Generator, generator = Object.create(protoGenerator.prototype), context = new Context(tryLocsList || []); return generator._invoke = function (innerFn, self, context) { var state = "suspendedStart"; return function (method, arg) { if ("executing" === state) throw new Error("Generator is already running"); if ("completed" === state) { if ("throw" === method) throw arg; return doneResult(); } for (context.method = method, context.arg = arg;;) { var delegate = context.delegate; if (delegate) { var delegateResult = maybeInvokeDelegate(delegate, context); if (delegateResult) { if (delegateResult === ContinueSentinel) continue; return delegateResult; } } if ("next" === context.method) context.sent = context._sent = context.arg;else if ("throw" === context.method) { if ("suspendedStart" === state) throw state = "completed", context.arg; context.dispatchException(context.arg); } else "return" === context.method && context.abrupt("return", context.arg); state = "executing"; var record = tryCatch(innerFn, self, context); if ("normal" === record.type) { if (state = context.done ? "completed" : "suspendedYield", record.arg === ContinueSentinel) continue; return { value: record.arg, done: context.done }; } "throw" === record.type && (state = "completed", context.method = "throw", context.arg = record.arg); } }; }(innerFn, self, context), generator; } function tryCatch(fn, obj, arg) { try { return { type: "normal", arg: fn.call(obj, arg) }; } catch (err) { return { type: "throw", arg: err }; } } exports.wrap = wrap; var ContinueSentinel = {}; function Generator() {} function GeneratorFunction() {} function GeneratorFunctionPrototype() {} var IteratorPrototype = {}; define(IteratorPrototype, iteratorSymbol, function () { return this; }); var getProto = Object.getPrototypeOf, NativeIteratorPrototype = getProto && getProto(getProto(values([]))); NativeIteratorPrototype && NativeIteratorPrototype !== Op && hasOwn.call(NativeIteratorPrototype, iteratorSymbol) && (IteratorPrototype = NativeIteratorPrototype); var Gp = GeneratorFunctionPrototype.prototype = Generator.prototype = Object.create(IteratorPrototype); function defineIteratorMethods(prototype) { ["next", "throw", "return"].forEach(function (method) { define(prototype, method, function (arg) { return this._invoke(method, arg); }); }); } function AsyncIterator(generator, PromiseImpl) { function invoke(method, arg, resolve, reject) { var record = tryCatch(generator[method], generator, arg); if ("throw" !== record.type) { var result = record.arg, value = result.value; return value && "object" == typeof value && hasOwn.call(value, "__await") ? PromiseImpl.resolve(value.__await).then(function (value) { invoke("next", value, resolve, reject); }, function (err) { invoke("throw", err, resolve, reject); }) : PromiseImpl.resolve(value).then(function (unwrapped) { result.value = unwrapped, resolve(result); }, function (error) { return invoke("throw", error, resolve, reject); }); } reject(record.arg); } var previousPromise; this._invoke = function (method, arg) { function callInvokeWithMethodAndArg() { return new PromiseImpl(function (resolve, reject) { invoke(method, arg, resolve, reject); }); } return previousPromise = previousPromise ? previousPromise.then(callInvokeWithMethodAndArg, callInvokeWithMethodAndArg) : callInvokeWithMethodAndArg(); }; } function maybeInvokeDelegate(delegate, context) { var method = delegate.iterator[context.method]; if (undefined === method) { if (context.delegate = null, "throw" === context.method) { if (delegate.iterator.return && (context.method = "return", context.arg = undefined, maybeInvokeDelegate(delegate, context), "throw" === context.method)) return ContinueSentinel; context.method = "throw", context.arg = new TypeError("The iterator does not provide a 'throw' method"); } return ContinueSentinel; } var record = tryCatch(method, delegate.iterator, context.arg); if ("throw" === record.type) return context.method = "throw", context.arg = record.arg, context.delegate = null, ContinueSentinel; var info = record.arg; return info ? info.done ? (context[delegate.resultName] = info.value, context.next = delegate.nextLoc, "return" !== context.method && (context.method = "next", context.arg = undefined), context.delegate = null, ContinueSentinel) : info : (context.method = "throw", context.arg = new TypeError("iterator result is not an object"), context.delegate = null, ContinueSentinel); } function pushTryEntry(locs) { var entry = { tryLoc: locs[0] }; 1 in locs && (entry.catchLoc = locs[1]), 2 in locs && (entry.finallyLoc = locs[2], entry.afterLoc = locs[3]), this.tryEntries.push(entry); } function resetTryEntry(entry) { var record = entry.completion || {}; record.type = "normal", delete record.arg, entry.completion = record; } function Context(tryLocsList) { this.tryEntries = [{ tryLoc: "root" }], tryLocsList.forEach(pushTryEntry, this), this.reset(!0); } function values(iterable) { if (iterable) { var iteratorMethod = iterable[iteratorSymbol]; if (iteratorMethod) return iteratorMethod.call(iterable); if ("function" == typeof iterable.next) return iterable; if (!isNaN(iterable.length)) { var i = -1, next = function next() { for (; ++i < iterable.length;) { if (hasOwn.call(iterable, i)) return next.value = iterable[i], next.done = !1, next; } return next.value = undefined, next.done = !0, next; }; return next.next = next; } } return { next: doneResult }; } function doneResult() { return { value: undefined, done: !0 }; } return GeneratorFunction.prototype = GeneratorFunctionPrototype, define(Gp, "constructor", GeneratorFunctionPrototype), define(GeneratorFunctionPrototype, "constructor", GeneratorFunction), GeneratorFunction.displayName = define(GeneratorFunctionPrototype, toStringTagSymbol, "GeneratorFunction"), exports.isGeneratorFunction = function (genFun) { var ctor = "function" == typeof genFun && genFun.constructor; return !!ctor && (ctor === GeneratorFunction || "GeneratorFunction" === (ctor.displayName || ctor.name)); }, exports.mark = function (genFun) { return Object.setPrototypeOf ? Object.setPrototypeOf(genFun, GeneratorFunctionPrototype) : (genFun.__proto__ = GeneratorFunctionPrototype, define(genFun, toStringTagSymbol, "GeneratorFunction")), genFun.prototype = Object.create(Gp), genFun; }, exports.awrap = function (arg) { return { __await: arg }; }, defineIteratorMethods(AsyncIterator.prototype), define(AsyncIterator.prototype, asyncIteratorSymbol, function () { return this; }), exports.AsyncIterator = AsyncIterator, exports.async = function (innerFn, outerFn, self, tryLocsList, PromiseImpl) { void 0 === PromiseImpl && (PromiseImpl = Promise); var iter = new AsyncIterator(wrap(innerFn, outerFn, self, tryLocsList), PromiseImpl); return exports.isGeneratorFunction(outerFn) ? iter : iter.next().then(function (result) { return result.done ? result.value : iter.next(); }); }, defineIteratorMethods(Gp), define(Gp, toStringTagSymbol, "Generator"), define(Gp, iteratorSymbol, function () { return this; }), define(Gp, "toString", function () { return "[object Generator]"; }), exports.keys = function (object) { var keys = []; for (var key in object) { keys.push(key); } return keys.reverse(), function next() { for (; keys.length;) { var key = keys.pop(); if (key in object) return next.value = key, next.done = !1, next; } return next.done = !0, next; }; }, exports.values = values, Context.prototype = { constructor: Context, reset: function reset(skipTempReset) { if (this.prev = 0, this.next = 0, this.sent = this._sent = undefined, this.done = !1, this.delegate = null, this.method = "next", this.arg = undefined, this.tryEntries.forEach(resetTryEntry), !skipTempReset) for (var name in this) { "t" === name.charAt(0) && hasOwn.call(this, name) && !isNaN(+name.slice(1)) && (this[name] = undefined); } }, stop: function stop() { this.done = !0; var rootRecord = this.tryEntries[0].completion; if ("throw" === rootRecord.type) throw rootRecord.arg; return this.rval; }, dispatchException: function dispatchException(exception) { if (this.done) throw exception; var context = this; function handle(loc, caught) { return record.type = "throw", record.arg = exception, context.next = loc, caught && (context.method = "next", context.arg = undefined), !!caught; } for (var i = this.tryEntries.length - 1; i >= 0; --i) { var entry = this.tryEntries[i], record = entry.completion; if ("root" === entry.tryLoc) return handle("end"); if (entry.tryLoc <= this.prev) { var hasCatch = hasOwn.call(entry, "catchLoc"), hasFinally = hasOwn.call(entry, "finallyLoc"); if (hasCatch && hasFinally) { if (this.prev < entry.catchLoc) return handle(entry.catchLoc, !0); if (this.prev < entry.finallyLoc) return handle(entry.finallyLoc); } else if (hasCatch) { if (this.prev < entry.catchLoc) return handle(entry.catchLoc, !0); } else { if (!hasFinally) throw new Error("try statement without catch or finally"); if (this.prev < entry.finallyLoc) return handle(entry.finallyLoc); } } } }, abrupt: function abrupt(type, arg) { for (var i = this.tryEntries.length - 1; i >= 0; --i) { var entry = this.tryEntries[i]; if (entry.tryLoc <= this.prev && hasOwn.call(entry, "finallyLoc") && this.prev < entry.finallyLoc) { var finallyEntry = entry; break; } } finallyEntry && ("break" === type || "continue" === type) && finallyEntry.tryLoc <= arg && arg <= finallyEntry.finallyLoc && (finallyEntry = null); var record = finallyEntry ? finallyEntry.completion : {}; return record.type = type, record.arg = arg, finallyEntry ? (this.method = "next", this.next = finallyEntry.finallyLoc, ContinueSentinel) : this.complete(record); }, complete: function complete(record, afterLoc) { if ("throw" === record.type) throw record.arg; return "break" === record.type || "continue" === record.type ? this.next = record.arg : "return" === record.type ? (this.rval = this.arg = record.arg, this.method = "return", this.next = "end") : "normal" === record.type && afterLoc && (this.next = afterLoc), ContinueSentinel; }, finish: function finish(finallyLoc) { for (var i = this.tryEntries.length - 1; i >= 0; --i) { var entry = this.tryEntries[i]; if (entry.finallyLoc === finallyLoc) return this.complete(entry.completion, entry.afterLoc), resetTryEntry(entry), ContinueSentinel; } }, catch: function _catch(tryLoc) { for (var i = this.tryEntries.length - 1; i >= 0; --i) { var entry = this.tryEntries[i]; if (entry.tryLoc === tryLoc) { var record = entry.completion; if ("throw" === record.type) { var thrown = record.arg; resetTryEntry(entry); } return thrown; } } throw new Error("illegal catch attempt"); }, delegateYield: function delegateYield(iterable, resultName, nextLoc) { return this.delegate = { iterator: values(iterable), resultName: resultName, nextLoc: nextLoc }, "next" === this.method && (this.arg = undefined), ContinueSentinel; } }, exports; }










var _c0 = ["infiniteScroll"];

var _c1 = function _c1(a0) {
  return {
    item: a0
  };
};

function InfiniteScrollComponent_ng_container_2_ng_container_1_Template(rf, ctx) {
  if (rf & 1) {
    _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵelementContainerStart"](0);
    _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵelementContainer"](1, 6);
    _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵelementContainerEnd"]();
  }

  if (rf & 2) {
    var item_r4 = ctx.$implicit;
    var ctx_r3 = _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵnextContext"](2);
    _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵadvance"](1);
    _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵproperty"]("ngTemplateOutlet", ctx_r3.content.templateRef)("ngTemplateOutletContext", _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵpureFunction1"](2, _c1, item_r4));
  }
}

function InfiniteScrollComponent_ng_container_2_Template(rf, ctx) {
  if (rf & 1) {
    _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵelementContainerStart"](0);
    _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵtemplate"](1, InfiniteScrollComponent_ng_container_2_ng_container_1_Template, 2, 4, "ng-container", 5);
    _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵpipe"](2, "async");
    _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵelementContainerEnd"]();
  }

  if (rf & 2) {
    var ctx_r0 = _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵnextContext"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵadvance"](1);
    _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵproperty"]("ngForOf", _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵpipeBind1"](2, 1, ctx_r0.items$));
  }
}

var _c2 = function _c2(a0) {
  return {
    items: a0
  };
};

function InfiniteScrollComponent_ng_container_3_Template(rf, ctx) {
  if (rf & 1) {
    _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵelementContainerStart"](0);
    _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵelementContainer"](1, 6);
    _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵpipe"](2, "async");
    _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵelementContainerEnd"]();
  }

  if (rf & 2) {
    var ctx_r1 = _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵnextContext"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵadvance"](1);
    _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵproperty"]("ngTemplateOutlet", ctx_r1.content.templateRef)("ngTemplateOutletContext", _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵpureFunction1"](4, _c2, _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵpipeBind1"](2, 2, ctx_r1.items$)));
  }
}

var _c3 = ["*"];
var InfiniteScrollContentDirective = /*#__PURE__*/(0,_Users_smartcommunitylab_Documents_work_projects_dslab_playgo_mobile_playgo_mobile_node_modules_babel_runtime_helpers_esm_createClass_js__WEBPACK_IMPORTED_MODULE_2__["default"])(function InfiniteScrollContentDirective(templateRef) {
  (0,_Users_smartcommunitylab_Documents_work_projects_dslab_playgo_mobile_playgo_mobile_node_modules_babel_runtime_helpers_esm_classCallCheck_js__WEBPACK_IMPORTED_MODULE_3__["default"])(this, InfiniteScrollContentDirective);

  this.templateRef = templateRef;
});

InfiniteScrollContentDirective.ɵfac = function InfiniteScrollContentDirective_Factory(t) {
  return new (t || InfiniteScrollContentDirective)(_angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵdirectiveInject"](_angular_core__WEBPACK_IMPORTED_MODULE_5__.TemplateRef));
};

InfiniteScrollContentDirective.ɵdir = /*@__PURE__*/_angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵdefineDirective"]({
  type: InfiniteScrollContentDirective,
  selectors: [["", "appInfiniteScrollContent", ""]]
});
var InfiniteScrollComponent = /*#__PURE__*/function () {
  function InfiniteScrollComponent(ionContentElement) {
    var _this = this;

    (0,_Users_smartcommunitylab_Documents_work_projects_dslab_playgo_mobile_playgo_mobile_node_modules_babel_runtime_helpers_esm_classCallCheck_js__WEBPACK_IMPORTED_MODULE_3__["default"])(this, InfiniteScrollComponent);

    this.ionContentElement = ionContentElement;
    this.allItemsInTemplate = false;
    this.response$ = new rxjs__WEBPACK_IMPORTED_MODULE_6__.Subject();
    this.successResponse$ = this.response$.pipe((0,rxjs_operators__WEBPACK_IMPORTED_MODULE_7__.filter)(isPageableSuccessResponse));
    this.resetItems$ = new rxjs__WEBPACK_IMPORTED_MODULE_6__.Subject();
    this.loadDataEvents$ = new rxjs__WEBPACK_IMPORTED_MODULE_6__.Subject();
    this.afterViewChecked = new rxjs__WEBPACK_IMPORTED_MODULE_6__.Subject();
    this.manualLoadWithNoScroll$ = this.response$.pipe((0,rxjs_operators__WEBPACK_IMPORTED_MODULE_8__.switchMap)(function (response) {
      if (!response || isPageableErrorResponse(response)) {
        return rxjs__WEBPACK_IMPORTED_MODULE_9__.EMPTY;
      }

      var page = response.number + 1;
      var notAllDataIsLoaded = page < response.totalPages;
      return _this.afterViewChecked.pipe((0,rxjs_operators__WEBPACK_IMPORTED_MODULE_10__.first)(), (0,_utils__WEBPACK_IMPORTED_MODULE_4__.asyncFilter)(function () {
        return (0,tslib__WEBPACK_IMPORTED_MODULE_11__.__awaiter)(_this, void 0, void 0, /*#__PURE__*/_regeneratorRuntime().mark(function _callee() {
          var noScroll, shouldForceLoad;
          return _regeneratorRuntime().wrap(function _callee$(_context) {
            while (1) {
              switch (_context.prev = _context.next) {
                case 0:
                  _context.next = 2;
                  return this.hasScroll();

                case 2:
                  _context.t0 = _context.sent;
                  noScroll = _context.t0 === false;
                  shouldForceLoad = notAllDataIsLoaded && noScroll;
                  return _context.abrupt("return", shouldForceLoad);

                case 6:
                case "end":
                  return _context.stop();
              }
            }
          }, _callee, this);
        }));
      }));
    }), (0,_utils__WEBPACK_IMPORTED_MODULE_4__.tapLog)('Manually forced load of next page, because there is no scroll to trigger it'));
    this.request = (0,rxjs__WEBPACK_IMPORTED_MODULE_12__.merge)(this.loadDataEvents$, this.manualLoadWithNoScroll$).pipe((0,rxjs_operators__WEBPACK_IMPORTED_MODULE_13__.withLatestFrom)(this.successResponse$), (0,rxjs_operators__WEBPACK_IMPORTED_MODULE_14__.map)(function (_ref) {
      var _ref2 = (0,_Users_smartcommunitylab_Documents_work_projects_dslab_playgo_mobile_playgo_mobile_node_modules_babel_runtime_helpers_esm_slicedToArray_js__WEBPACK_IMPORTED_MODULE_1__["default"])(_ref, 2),
          response = _ref2[1];

      var page = response.number + 1;
      var size = response.size;

      if (page >= response.totalPages) {
        _this.infiniteScrollComponent.disabled = true;
        return null;
      }

      _this.infiniteScrollComponent.disabled = false;
      return {
        page: page,
        size: size
      };
    }), (0,rxjs_operators__WEBPACK_IMPORTED_MODULE_7__.filter)(function (request) {
      return request !== null;
    }));
    this.items$ = this.resetItems$.pipe((0,rxjs_operators__WEBPACK_IMPORTED_MODULE_15__.startWith)(undefined), (0,rxjs_operators__WEBPACK_IMPORTED_MODULE_8__.switchMap)(function () {
      return _this.successResponse$.pipe((0,rxjs_operators__WEBPACK_IMPORTED_MODULE_7__.filter)((0,lodash_es__WEBPACK_IMPORTED_MODULE_16__["default"])(lodash_es__WEBPACK_IMPORTED_MODULE_17__["default"])), (0,rxjs_operators__WEBPACK_IMPORTED_MODULE_14__.map)(function (response) {
        return response.content;
      }), (0,rxjs_operators__WEBPACK_IMPORTED_MODULE_18__.scan)(function (acc, curr) {
        return [].concat((0,_Users_smartcommunitylab_Documents_work_projects_dslab_playgo_mobile_playgo_mobile_node_modules_babel_runtime_helpers_esm_toConsumableArray_js__WEBPACK_IMPORTED_MODULE_0__["default"])(acc), (0,_Users_smartcommunitylab_Documents_work_projects_dslab_playgo_mobile_playgo_mobile_node_modules_babel_runtime_helpers_esm_toConsumableArray_js__WEBPACK_IMPORTED_MODULE_0__["default"])(curr));
      }, []), (0,rxjs_operators__WEBPACK_IMPORTED_MODULE_15__.startWith)([]));
    }));
    /** For manual rendering */

    this.items = this.items$;
  }

  (0,_Users_smartcommunitylab_Documents_work_projects_dslab_playgo_mobile_playgo_mobile_node_modules_babel_runtime_helpers_esm_createClass_js__WEBPACK_IMPORTED_MODULE_2__["default"])(InfiniteScrollComponent, [{
    key: "response",
    set: function set(response) {
      if (!(0,lodash_es__WEBPACK_IMPORTED_MODULE_17__["default"])(response)) {
        this.response$.next(response);
      }

      if (this.infiniteScrollComponent) {
        this.infiniteScrollComponent.complete();
      }
    }
  }, {
    key: "resetItems",
    set: function set(resetItems) {
      this.resetItems$.next();
    }
  }, {
    key: "loadData",
    value: function loadData(event) {
      this.loadDataEvents$.next();
    }
  }, {
    key: "ngOnInit",
    value: function ngOnInit() {}
  }, {
    key: "ngAfterViewChecked",
    value: function ngAfterViewChecked() {
      this.afterViewChecked.next();
    }
  }, {
    key: "hasScroll",
    value: function hasScroll() {
      return (0,tslib__WEBPACK_IMPORTED_MODULE_11__.__awaiter)(this, void 0, void 0, /*#__PURE__*/_regeneratorRuntime().mark(function _callee2() {
        var scrollElement;
        return _regeneratorRuntime().wrap(function _callee2$(_context2) {
          while (1) {
            switch (_context2.prev = _context2.next) {
              case 0:
                if (this.ionContentElement) {
                  _context2.next = 2;
                  break;
                }

                return _context2.abrupt("return", null);

              case 2:
                _context2.next = 4;
                return this.ionContentElement.getScrollElement();

              case 4:
                scrollElement = _context2.sent;

                if (scrollElement) {
                  _context2.next = 7;
                  break;
                }

                return _context2.abrupt("return", null);

              case 7:
                return _context2.abrupt("return", scrollElement.scrollHeight > scrollElement.clientHeight);

              case 8:
              case "end":
                return _context2.stop();
            }
          }
        }, _callee2, this);
      }));
    }
  }]);

  return InfiniteScrollComponent;
}();

InfiniteScrollComponent.ɵfac = function InfiniteScrollComponent_Factory(t) {
  return new (t || InfiniteScrollComponent)(_angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵdirectiveInject"](_ionic_angular__WEBPACK_IMPORTED_MODULE_19__.IonContent, 8));
};

InfiniteScrollComponent.ɵcmp = /*@__PURE__*/_angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵdefineComponent"]({
  type: InfiniteScrollComponent,
  selectors: [["app-infinite-scroll"]],
  contentQueries: function InfiniteScrollComponent_ContentQueries(rf, ctx, dirIndex) {
    if (rf & 1) {
      _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵcontentQuery"](dirIndex, InfiniteScrollContentDirective, 5);
    }

    if (rf & 2) {
      var _t;

      _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵqueryRefresh"](_t = _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵloadQuery"]()) && (ctx.content = _t.first);
    }
  },
  viewQuery: function InfiniteScrollComponent_Query(rf, ctx) {
    if (rf & 1) {
      _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵviewQuery"](_c0, 5);
    }

    if (rf & 2) {
      var _t;

      _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵqueryRefresh"](_t = _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵloadQuery"]()) && (ctx.infiniteScrollComponent = _t.first);
    }
  },
  inputs: {
    allItemsInTemplate: "allItemsInTemplate",
    response: "response",
    resetItems: "resetItems"
  },
  outputs: {
    request: "request",
    items: "items"
  },
  ngContentSelectors: _c3,
  decls: 7,
  vars: 2,
  consts: [["color", "light"], [4, "ngIf"], ["threshold", "100px", 3, "ionInfinite"], ["infiniteScroll", ""], ["loadingSpinner", "bubbles", "loadingText", "Loading more data..."], [4, "ngFor", "ngForOf"], [3, "ngTemplateOutlet", "ngTemplateOutletContext"]],
  template: function InfiniteScrollComponent_Template(rf, ctx) {
    if (rf & 1) {
      _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵprojectionDef"]();
      _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵelementStart"](0, "div", 0);
      _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵprojection"](1);
      _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵtemplate"](2, InfiniteScrollComponent_ng_container_2_Template, 3, 3, "ng-container", 1);
      _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵtemplate"](3, InfiniteScrollComponent_ng_container_3_Template, 3, 6, "ng-container", 1);
      _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵelementStart"](4, "ion-infinite-scroll", 2, 3);
      _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵlistener"]("ionInfinite", function InfiniteScrollComponent_Template_ion_infinite_scroll_ionInfinite_4_listener($event) {
        return ctx.loadData($event);
      });
      _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵelement"](6, "ion-infinite-scroll-content", 4);
      _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵelementEnd"]()();
    }

    if (rf & 2) {
      _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵadvance"](2);
      _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵproperty"]("ngIf", ctx.allItemsInTemplate === false);
      _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵadvance"](1);
      _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵproperty"]("ngIf", ctx.allItemsInTemplate === true);
    }
  },
  directives: [_angular_common__WEBPACK_IMPORTED_MODULE_20__.NgIf, _angular_common__WEBPACK_IMPORTED_MODULE_20__.NgForOf, _angular_common__WEBPACK_IMPORTED_MODULE_20__.NgTemplateOutlet, _ionic_angular__WEBPACK_IMPORTED_MODULE_19__.IonInfiniteScroll, _ionic_angular__WEBPACK_IMPORTED_MODULE_19__.IonInfiniteScrollContent],
  pipes: [_angular_common__WEBPACK_IMPORTED_MODULE_20__.AsyncPipe],
  styles: ["\n/*# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbXSwibmFtZXMiOltdLCJtYXBwaW5ncyI6IiIsImZpbGUiOiJpbmZpbml0ZS1zY3JvbGwuY29tcG9uZW50LnNjc3MifQ== */"]
});
function isPageableErrorResponse(response) {
  return response.error !== undefined;
}
function isPageableSuccessResponse(response) {
  return !isPageableErrorResponse(response);
}

/***/ }),

/***/ 322:
/*!***********************************************************************!*\
  !*** ./src/app/core/shared/layout/header/header-content.component.ts ***!
  \***********************************************************************/
/***/ (function(__unused_webpack_module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "HeaderContentComponent": function() { return /* binding */ HeaderContentComponent; }
/* harmony export */ });
/* harmony import */ var _Users_smartcommunitylab_Documents_work_projects_dslab_playgo_mobile_playgo_mobile_node_modules_babel_runtime_helpers_esm_classCallCheck_js__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./node_modules/@babel/runtime/helpers/esm/classCallCheck.js */ 78069);
/* harmony import */ var _Users_smartcommunitylab_Documents_work_projects_dslab_playgo_mobile_playgo_mobile_node_modules_babel_runtime_helpers_esm_createClass_js__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ./node_modules/@babel/runtime/helpers/esm/createClass.js */ 48047);
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(/*! tslib */ 34929);
/* harmony import */ var _ionic_angular__WEBPACK_IMPORTED_MODULE_10__ = __webpack_require__(/*! @ionic/angular */ 93819);
/* harmony import */ var rxjs__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(/*! rxjs */ 19337);
/* harmony import */ var rxjs__WEBPACK_IMPORTED_MODULE_9__ = __webpack_require__(/*! rxjs */ 54363);
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! @angular/core */ 3184);
/* harmony import */ var _services_app_status_service__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! ../../services/app-status.service */ 93656);
/* harmony import */ var _angular_router__WEBPACK_IMPORTED_MODULE_11__ = __webpack_require__(/*! @angular/router */ 52816);
/* harmony import */ var _services_notifications_notifications_service__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! ../../services/notifications/notifications.service */ 30299);
/* harmony import */ var _services_page_settings_service__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! ../../services/page-settings.service */ 85294);
/* harmony import */ var _angular_common__WEBPACK_IMPORTED_MODULE_12__ = __webpack_require__(/*! @angular/common */ 36362);
/* harmony import */ var _ui_icon_icon_component__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! ../../ui/icon/icon.component */ 71888);
/* harmony import */ var _ngx_translate_core__WEBPACK_IMPORTED_MODULE_13__ = __webpack_require__(/*! @ngx-translate/core */ 87514);



function _regeneratorRuntime() { "use strict"; /*! regenerator-runtime -- Copyright (c) 2014-present, Facebook, Inc. -- license (MIT): https://github.com/facebook/regenerator/blob/main/LICENSE */ _regeneratorRuntime = function _regeneratorRuntime() { return exports; }; var exports = {}, Op = Object.prototype, hasOwn = Op.hasOwnProperty, $Symbol = "function" == typeof Symbol ? Symbol : {}, iteratorSymbol = $Symbol.iterator || "@@iterator", asyncIteratorSymbol = $Symbol.asyncIterator || "@@asyncIterator", toStringTagSymbol = $Symbol.toStringTag || "@@toStringTag"; function define(obj, key, value) { return Object.defineProperty(obj, key, { value: value, enumerable: !0, configurable: !0, writable: !0 }), obj[key]; } try { define({}, ""); } catch (err) { define = function define(obj, key, value) { return obj[key] = value; }; } function wrap(innerFn, outerFn, self, tryLocsList) { var protoGenerator = outerFn && outerFn.prototype instanceof Generator ? outerFn : Generator, generator = Object.create(protoGenerator.prototype), context = new Context(tryLocsList || []); return generator._invoke = function (innerFn, self, context) { var state = "suspendedStart"; return function (method, arg) { if ("executing" === state) throw new Error("Generator is already running"); if ("completed" === state) { if ("throw" === method) throw arg; return doneResult(); } for (context.method = method, context.arg = arg;;) { var delegate = context.delegate; if (delegate) { var delegateResult = maybeInvokeDelegate(delegate, context); if (delegateResult) { if (delegateResult === ContinueSentinel) continue; return delegateResult; } } if ("next" === context.method) context.sent = context._sent = context.arg;else if ("throw" === context.method) { if ("suspendedStart" === state) throw state = "completed", context.arg; context.dispatchException(context.arg); } else "return" === context.method && context.abrupt("return", context.arg); state = "executing"; var record = tryCatch(innerFn, self, context); if ("normal" === record.type) { if (state = context.done ? "completed" : "suspendedYield", record.arg === ContinueSentinel) continue; return { value: record.arg, done: context.done }; } "throw" === record.type && (state = "completed", context.method = "throw", context.arg = record.arg); } }; }(innerFn, self, context), generator; } function tryCatch(fn, obj, arg) { try { return { type: "normal", arg: fn.call(obj, arg) }; } catch (err) { return { type: "throw", arg: err }; } } exports.wrap = wrap; var ContinueSentinel = {}; function Generator() {} function GeneratorFunction() {} function GeneratorFunctionPrototype() {} var IteratorPrototype = {}; define(IteratorPrototype, iteratorSymbol, function () { return this; }); var getProto = Object.getPrototypeOf, NativeIteratorPrototype = getProto && getProto(getProto(values([]))); NativeIteratorPrototype && NativeIteratorPrototype !== Op && hasOwn.call(NativeIteratorPrototype, iteratorSymbol) && (IteratorPrototype = NativeIteratorPrototype); var Gp = GeneratorFunctionPrototype.prototype = Generator.prototype = Object.create(IteratorPrototype); function defineIteratorMethods(prototype) { ["next", "throw", "return"].forEach(function (method) { define(prototype, method, function (arg) { return this._invoke(method, arg); }); }); } function AsyncIterator(generator, PromiseImpl) { function invoke(method, arg, resolve, reject) { var record = tryCatch(generator[method], generator, arg); if ("throw" !== record.type) { var result = record.arg, value = result.value; return value && "object" == typeof value && hasOwn.call(value, "__await") ? PromiseImpl.resolve(value.__await).then(function (value) { invoke("next", value, resolve, reject); }, function (err) { invoke("throw", err, resolve, reject); }) : PromiseImpl.resolve(value).then(function (unwrapped) { result.value = unwrapped, resolve(result); }, function (error) { return invoke("throw", error, resolve, reject); }); } reject(record.arg); } var previousPromise; this._invoke = function (method, arg) { function callInvokeWithMethodAndArg() { return new PromiseImpl(function (resolve, reject) { invoke(method, arg, resolve, reject); }); } return previousPromise = previousPromise ? previousPromise.then(callInvokeWithMethodAndArg, callInvokeWithMethodAndArg) : callInvokeWithMethodAndArg(); }; } function maybeInvokeDelegate(delegate, context) { var method = delegate.iterator[context.method]; if (undefined === method) { if (context.delegate = null, "throw" === context.method) { if (delegate.iterator.return && (context.method = "return", context.arg = undefined, maybeInvokeDelegate(delegate, context), "throw" === context.method)) return ContinueSentinel; context.method = "throw", context.arg = new TypeError("The iterator does not provide a 'throw' method"); } return ContinueSentinel; } var record = tryCatch(method, delegate.iterator, context.arg); if ("throw" === record.type) return context.method = "throw", context.arg = record.arg, context.delegate = null, ContinueSentinel; var info = record.arg; return info ? info.done ? (context[delegate.resultName] = info.value, context.next = delegate.nextLoc, "return" !== context.method && (context.method = "next", context.arg = undefined), context.delegate = null, ContinueSentinel) : info : (context.method = "throw", context.arg = new TypeError("iterator result is not an object"), context.delegate = null, ContinueSentinel); } function pushTryEntry(locs) { var entry = { tryLoc: locs[0] }; 1 in locs && (entry.catchLoc = locs[1]), 2 in locs && (entry.finallyLoc = locs[2], entry.afterLoc = locs[3]), this.tryEntries.push(entry); } function resetTryEntry(entry) { var record = entry.completion || {}; record.type = "normal", delete record.arg, entry.completion = record; } function Context(tryLocsList) { this.tryEntries = [{ tryLoc: "root" }], tryLocsList.forEach(pushTryEntry, this), this.reset(!0); } function values(iterable) { if (iterable) { var iteratorMethod = iterable[iteratorSymbol]; if (iteratorMethod) return iteratorMethod.call(iterable); if ("function" == typeof iterable.next) return iterable; if (!isNaN(iterable.length)) { var i = -1, next = function next() { for (; ++i < iterable.length;) { if (hasOwn.call(iterable, i)) return next.value = iterable[i], next.done = !1, next; } return next.value = undefined, next.done = !0, next; }; return next.next = next; } } return { next: doneResult }; } function doneResult() { return { value: undefined, done: !0 }; } return GeneratorFunction.prototype = GeneratorFunctionPrototype, define(Gp, "constructor", GeneratorFunctionPrototype), define(GeneratorFunctionPrototype, "constructor", GeneratorFunction), GeneratorFunction.displayName = define(GeneratorFunctionPrototype, toStringTagSymbol, "GeneratorFunction"), exports.isGeneratorFunction = function (genFun) { var ctor = "function" == typeof genFun && genFun.constructor; return !!ctor && (ctor === GeneratorFunction || "GeneratorFunction" === (ctor.displayName || ctor.name)); }, exports.mark = function (genFun) { return Object.setPrototypeOf ? Object.setPrototypeOf(genFun, GeneratorFunctionPrototype) : (genFun.__proto__ = GeneratorFunctionPrototype, define(genFun, toStringTagSymbol, "GeneratorFunction")), genFun.prototype = Object.create(Gp), genFun; }, exports.awrap = function (arg) { return { __await: arg }; }, defineIteratorMethods(AsyncIterator.prototype), define(AsyncIterator.prototype, asyncIteratorSymbol, function () { return this; }), exports.AsyncIterator = AsyncIterator, exports.async = function (innerFn, outerFn, self, tryLocsList, PromiseImpl) { void 0 === PromiseImpl && (PromiseImpl = Promise); var iter = new AsyncIterator(wrap(innerFn, outerFn, self, tryLocsList), PromiseImpl); return exports.isGeneratorFunction(outerFn) ? iter : iter.next().then(function (result) { return result.done ? result.value : iter.next(); }); }, defineIteratorMethods(Gp), define(Gp, toStringTagSymbol, "Generator"), define(Gp, iteratorSymbol, function () { return this; }), define(Gp, "toString", function () { return "[object Generator]"; }), exports.keys = function (object) { var keys = []; for (var key in object) { keys.push(key); } return keys.reverse(), function next() { for (; keys.length;) { var key = keys.pop(); if (key in object) return next.value = key, next.done = !1, next; } return next.done = !0, next; }; }, exports.values = values, Context.prototype = { constructor: Context, reset: function reset(skipTempReset) { if (this.prev = 0, this.next = 0, this.sent = this._sent = undefined, this.done = !1, this.delegate = null, this.method = "next", this.arg = undefined, this.tryEntries.forEach(resetTryEntry), !skipTempReset) for (var name in this) { "t" === name.charAt(0) && hasOwn.call(this, name) && !isNaN(+name.slice(1)) && (this[name] = undefined); } }, stop: function stop() { this.done = !0; var rootRecord = this.tryEntries[0].completion; if ("throw" === rootRecord.type) throw rootRecord.arg; return this.rval; }, dispatchException: function dispatchException(exception) { if (this.done) throw exception; var context = this; function handle(loc, caught) { return record.type = "throw", record.arg = exception, context.next = loc, caught && (context.method = "next", context.arg = undefined), !!caught; } for (var i = this.tryEntries.length - 1; i >= 0; --i) { var entry = this.tryEntries[i], record = entry.completion; if ("root" === entry.tryLoc) return handle("end"); if (entry.tryLoc <= this.prev) { var hasCatch = hasOwn.call(entry, "catchLoc"), hasFinally = hasOwn.call(entry, "finallyLoc"); if (hasCatch && hasFinally) { if (this.prev < entry.catchLoc) return handle(entry.catchLoc, !0); if (this.prev < entry.finallyLoc) return handle(entry.finallyLoc); } else if (hasCatch) { if (this.prev < entry.catchLoc) return handle(entry.catchLoc, !0); } else { if (!hasFinally) throw new Error("try statement without catch or finally"); if (this.prev < entry.finallyLoc) return handle(entry.finallyLoc); } } } }, abrupt: function abrupt(type, arg) { for (var i = this.tryEntries.length - 1; i >= 0; --i) { var entry = this.tryEntries[i]; if (entry.tryLoc <= this.prev && hasOwn.call(entry, "finallyLoc") && this.prev < entry.finallyLoc) { var finallyEntry = entry; break; } } finallyEntry && ("break" === type || "continue" === type) && finallyEntry.tryLoc <= arg && arg <= finallyEntry.finallyLoc && (finallyEntry = null); var record = finallyEntry ? finallyEntry.completion : {}; return record.type = type, record.arg = arg, finallyEntry ? (this.method = "next", this.next = finallyEntry.finallyLoc, ContinueSentinel) : this.complete(record); }, complete: function complete(record, afterLoc) { if ("throw" === record.type) throw record.arg; return "break" === record.type || "continue" === record.type ? this.next = record.arg : "return" === record.type ? (this.rval = this.arg = record.arg, this.method = "return", this.next = "end") : "normal" === record.type && afterLoc && (this.next = afterLoc), ContinueSentinel; }, finish: function finish(finallyLoc) { for (var i = this.tryEntries.length - 1; i >= 0; --i) { var entry = this.tryEntries[i]; if (entry.finallyLoc === finallyLoc) return this.complete(entry.completion, entry.afterLoc), resetTryEntry(entry), ContinueSentinel; } }, catch: function _catch(tryLoc) { for (var i = this.tryEntries.length - 1; i >= 0; --i) { var entry = this.tryEntries[i]; if (entry.tryLoc === tryLoc) { var record = entry.completion; if ("throw" === record.type) { var thrown = record.arg; resetTryEntry(entry); } return thrown; } } throw new Error("illegal catch attempt"); }, delegateYield: function delegateYield(iterable, resultName, nextLoc) { return this.delegate = { iterator: values(iterable), resultName: resultName, nextLoc: nextLoc }, "next" === this.method && (this.arg = undefined), ContinueSentinel; } }, exports; }














function HeaderContentComponent_ng_container_0_ion_buttons_2_Template(rf, ctx) {
  if (rf & 1) {
    var _r7 = _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵgetCurrentView"]();

    _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵelementStart"](0, "ion-buttons", 5)(1, "ion-back-button", 6);
    _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵlistener"]("click", function HeaderContentComponent_ng_container_0_ion_buttons_2_Template_ion_back_button_click_1_listener() {
      _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵrestoreView"](_r7);
      var ctx_r6 = _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵnextContext"](2);
      return ctx_r6.back();
    });
    _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵelementEnd"]()();
  }

  if (rf & 2) {
    var settings_r1 = _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵnextContext"]().ngIf;
    _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵadvance"](1);
    _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵproperty"]("defaultHref", settings_r1.defaultHref);
  }
}

function HeaderContentComponent_ng_container_0_span_4_Template(rf, ctx) {
  if (rf & 1) {
    _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵelementStart"](0, "span");
    _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵtext"](1);
    _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵpipe"](2, "translate");
    _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵelementEnd"]();
  }

  if (rf & 2) {
    var settings_r1 = _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵnextContext"]().ngIf;
    _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵadvance"](1);
    _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵtextInterpolate"](_angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵpipeBind1"](2, 1, settings_r1.title));
  }
}

function HeaderContentComponent_ng_container_0_ion_buttons_5_ion_badge_3_Template(rf, ctx) {
  if (rf & 1) {
    _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵelementStart"](0, "ion-badge", 11);
    _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵtext"](1);
    _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵelementEnd"]();
  }

  if (rf & 2) {
    var ctx_r10 = _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵnextContext"](3);
    _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵadvance"](1);
    _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵtextInterpolate"](ctx_r10.numberOfNotification);
  }
}

function HeaderContentComponent_ng_container_0_ion_buttons_5_Template(rf, ctx) {
  if (rf & 1) {
    var _r12 = _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵgetCurrentView"]();

    _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵelementStart"](0, "ion-buttons", 7)(1, "ion-button", 8);
    _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵlistener"]("click", function HeaderContentComponent_ng_container_0_ion_buttons_5_Template_ion_button_click_1_listener() {
      _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵrestoreView"](_r12);
      var ctx_r11 = _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵnextContext"](2);
      return ctx_r11.navigateToNotification();
    });
    _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵelement"](2, "ion-icon", 9);
    _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵtemplate"](3, HeaderContentComponent_ng_container_0_ion_buttons_5_ion_badge_3_Template, 2, 1, "ion-badge", 10);
    _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵelementEnd"]()();
  }

  if (rf & 2) {
    var ctx_r4 = _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵnextContext"](2);
    _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵadvance"](3);
    _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵproperty"]("ngIf", ctx_r4.numberOfNotification > 0);
  }
}

function HeaderContentComponent_ng_container_0_ion_toolbar_6_Template(rf, ctx) {
  if (rf & 1) {
    _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵelementStart"](0, "ion-toolbar", 12)(1, "ion-grid")(2, "ion-row", 13)(3, "ion-col", 14);
    _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵelement"](4, "app-icon", 15);
    _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵelementEnd"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵelementStart"](5, "ion-col", 16)(6, "b");
    _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵtext"](7);
    _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵpipe"](8, "translate");
    _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵelementEnd"]()();
    _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵelementStart"](9, "ion-col", 17);
    _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵtext"](10);
    _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵpipe"](11, "translate");
    _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵelementEnd"]()()()();
  }

  if (rf & 2) {
    _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵadvance"](7);
    _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵtextInterpolate"](_angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵpipeBind1"](8, 2, "offline.title"));
    _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵadvance"](3);
    _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵtextInterpolate1"](" ", _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵpipeBind1"](11, 4, "offline.header"), " ");
  }
}

function HeaderContentComponent_ng_container_0_Template(rf, ctx) {
  if (rf & 1) {
    _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵelementContainerStart"](0);
    _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵelementStart"](1, "ion-toolbar", 1);
    _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵtemplate"](2, HeaderContentComponent_ng_container_0_ion_buttons_2_Template, 2, 1, "ion-buttons", 2);
    _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵelementStart"](3, "ion-title");
    _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵtemplate"](4, HeaderContentComponent_ng_container_0_span_4_Template, 3, 3, "span", 0);
    _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵelementEnd"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵtemplate"](5, HeaderContentComponent_ng_container_0_ion_buttons_5_Template, 4, 1, "ion-buttons", 3);
    _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵelementEnd"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵtemplate"](6, HeaderContentComponent_ng_container_0_ion_toolbar_6_Template, 12, 6, "ion-toolbar", 4);
    _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵpipe"](7, "async");
    _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵelementContainerEnd"]();
  }

  if (rf & 2) {
    var settings_r1 = ctx.ngIf;
    var ctx_r0 = _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵnextContext"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵadvance"](1);
    _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵproperty"]("color", settings_r1.color);
    _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵadvance"](1);
    _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵproperty"]("ngIf", settings_r1.backButton);
    _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵadvance"](2);
    _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵproperty"]("ngIf", settings_r1.title);
    _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵadvance"](1);
    _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵproperty"]("ngIf", settings_r1.showNotifications);
    _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵadvance"](1);
    _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵproperty"]("ngIf", _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵpipeBind1"](7, 5, ctx_r0.isOnline$) === false);
  }
}

var HeaderContentComponent = /*#__PURE__*/function () {
  function HeaderContentComponent(navCtrl, appStatusService, router, cdRef, notificationService, pageSettingsService) {
    var _this = this;

    (0,_Users_smartcommunitylab_Documents_work_projects_dslab_playgo_mobile_playgo_mobile_node_modules_babel_runtime_helpers_esm_classCallCheck_js__WEBPACK_IMPORTED_MODULE_0__["default"])(this, HeaderContentComponent);

    this.navCtrl = navCtrl;
    this.appStatusService = appStatusService;
    this.router = router;
    this.cdRef = cdRef;
    this.notificationService = notificationService;
    this.pageSettingsService = pageSettingsService;
    this.isOnline$ = this.appStatusService.isOnline$;
    this.numberOfNotification = 0;
    this.unreadNotification$ = this.notificationService.unreadAnnouncementNotifications$.pipe((0,rxjs__WEBPACK_IMPORTED_MODULE_7__.tap)(function (notifications) {
      _this.numberOfNotification = notifications.length;

      _this.cdRef.detectChanges();
    }));
  }

  (0,_Users_smartcommunitylab_Documents_work_projects_dslab_playgo_mobile_playgo_mobile_node_modules_babel_runtime_helpers_esm_createClass_js__WEBPACK_IMPORTED_MODULE_1__["default"])(HeaderContentComponent, [{
    key: "ngOnDestroy",
    value: function ngOnDestroy() {
      this.subunread.unsubscribe();
    }
  }, {
    key: "ngOnInit",
    value: function ngOnInit() {
      return (0,tslib__WEBPACK_IMPORTED_MODULE_8__.__awaiter)(this, void 0, void 0, /*#__PURE__*/_regeneratorRuntime().mark(function _callee() {
        return _regeneratorRuntime().wrap(function _callee$(_context) {
          while (1) {
            switch (_context.prev = _context.next) {
              case 0:
                this.subunread = this.unreadNotification$.subscribe();

              case 1:
              case "end":
                return _context.stop();
            }
          }
        }, _callee, this);
      }));
    }
  }, {
    key: "navigateToNotification",
    value: function navigateToNotification() {
      this.router.navigateByUrl('/pages/notifications');
    }
  }, {
    key: "back",
    value: function back() {
      return (0,tslib__WEBPACK_IMPORTED_MODULE_8__.__awaiter)(this, void 0, void 0, /*#__PURE__*/_regeneratorRuntime().mark(function _callee2() {
        var defaultHref;
        return _regeneratorRuntime().wrap(function _callee2$(_context2) {
          while (1) {
            switch (_context2.prev = _context2.next) {
              case 0:
                _context2.next = 2;
                return this.getCurrentSettings();

              case 2:
                defaultHref = _context2.sent.defaultHref;

                if (!defaultHref) {
                  _context2.next = 5;
                  break;
                }

                return _context2.abrupt("return", this.navCtrl.navigateRoot(defaultHref));

              case 5:
                return _context2.abrupt("return", this.navCtrl.back());

              case 6:
              case "end":
                return _context2.stop();
            }
          }
        }, _callee2, this);
      }));
    }
  }, {
    key: "getCurrentSettings",
    value: function getCurrentSettings() {
      return (0,tslib__WEBPACK_IMPORTED_MODULE_8__.__awaiter)(this, void 0, void 0, /*#__PURE__*/_regeneratorRuntime().mark(function _callee3() {
        return _regeneratorRuntime().wrap(function _callee3$(_context3) {
          while (1) {
            switch (_context3.prev = _context3.next) {
              case 0:
                _context3.next = 2;
                return (0,rxjs__WEBPACK_IMPORTED_MODULE_9__.firstValueFrom)(this.pageSettingsService.pageSettings$);

              case 2:
                return _context3.abrupt("return", _context3.sent);

              case 3:
              case "end":
                return _context3.stop();
            }
          }
        }, _callee3, this);
      }));
    }
  }]);

  return HeaderContentComponent;
}();

HeaderContentComponent.ɵfac = function HeaderContentComponent_Factory(t) {
  return new (t || HeaderContentComponent)(_angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵdirectiveInject"](_ionic_angular__WEBPACK_IMPORTED_MODULE_10__.NavController), _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵdirectiveInject"](_services_app_status_service__WEBPACK_IMPORTED_MODULE_2__.AppStatusService), _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵdirectiveInject"](_angular_router__WEBPACK_IMPORTED_MODULE_11__.Router), _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵdirectiveInject"](_angular_core__WEBPACK_IMPORTED_MODULE_6__.ChangeDetectorRef), _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵdirectiveInject"](_services_notifications_notifications_service__WEBPACK_IMPORTED_MODULE_3__.NotificationService), _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵdirectiveInject"](_services_page_settings_service__WEBPACK_IMPORTED_MODULE_4__.PageSettingsService));
};

HeaderContentComponent.ɵcmp = /*@__PURE__*/_angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵdefineComponent"]({
  type: HeaderContentComponent,
  selectors: [["app-header-content"]],
  viewQuery: function HeaderContentComponent_Query(rf, ctx) {
    if (rf & 1) {
      _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵviewQuery"](_ionic_angular__WEBPACK_IMPORTED_MODULE_10__.IonTitle, 5);
      _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵviewQuery"](_ionic_angular__WEBPACK_IMPORTED_MODULE_10__.IonToolbar, 5);
      _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵviewQuery"](_ionic_angular__WEBPACK_IMPORTED_MODULE_10__.IonButtons, 5);
    }

    if (rf & 2) {
      var _t;

      _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵqueryRefresh"](_t = _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵloadQuery"]()) && (ctx.ionTitle = _t.first);
      _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵqueryRefresh"](_t = _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵloadQuery"]()) && (ctx.ionToolbar = _t.first);
      _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵqueryRefresh"](_t = _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵloadQuery"]()) && (ctx.ionButtons = _t);
    }
  },
  decls: 2,
  vars: 3,
  consts: [[4, "ngIf"], [3, "color"], ["slot", "start", 4, "ngIf"], ["slot", "secondary", 4, "ngIf"], ["color", "warning", 4, "ngIf"], ["slot", "start"], [3, "defaultHref", "click"], ["slot", "secondary"], ["id", "notificationButton", 3, "click"], ["name", "notifications"], ["id", "notifications-badge", "color", "danger", 4, "ngIf"], ["id", "notifications-badge", "color", "danger"], ["color", "warning"], [1, "ion-align-items-center"], ["size", "2"], ["name", "offline", 2, "font-size", "200%"], ["size", "3", 1, "ion-text-uppercase"], ["size", "7"]],
  template: function HeaderContentComponent_Template(rf, ctx) {
    if (rf & 1) {
      _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵtemplate"](0, HeaderContentComponent_ng_container_0_Template, 8, 7, "ng-container", 0);
      _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵpipe"](1, "async");
    }

    if (rf & 2) {
      _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵproperty"]("ngIf", _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵpipeBind1"](1, 1, ctx.pageSettingsService.pageSettings$));
    }
  },
  directives: [_angular_common__WEBPACK_IMPORTED_MODULE_12__.NgIf, _ionic_angular__WEBPACK_IMPORTED_MODULE_10__.IonToolbar, _ionic_angular__WEBPACK_IMPORTED_MODULE_10__.IonButtons, _ionic_angular__WEBPACK_IMPORTED_MODULE_10__.IonBackButton, _ionic_angular__WEBPACK_IMPORTED_MODULE_10__.IonBackButtonDelegate, _ionic_angular__WEBPACK_IMPORTED_MODULE_10__.IonTitle, _ionic_angular__WEBPACK_IMPORTED_MODULE_10__.IonButton, _ionic_angular__WEBPACK_IMPORTED_MODULE_10__.IonIcon, _ionic_angular__WEBPACK_IMPORTED_MODULE_10__.IonBadge, _ionic_angular__WEBPACK_IMPORTED_MODULE_10__.IonGrid, _ionic_angular__WEBPACK_IMPORTED_MODULE_10__.IonRow, _ionic_angular__WEBPACK_IMPORTED_MODULE_10__.IonCol, _ui_icon_icon_component__WEBPACK_IMPORTED_MODULE_5__.IconComponent],
  pipes: [_angular_common__WEBPACK_IMPORTED_MODULE_12__.AsyncPipe, _ngx_translate_core__WEBPACK_IMPORTED_MODULE_13__.TranslatePipe],
  styles: ["ion-badge[_ngcontent-%COMP%] {\n  position: absolute;\n  top: -1px;\n  right: -1px;\n  border-radius: 100%;\n  min-width: 20px;\n  min-height: 20px;\n}\n\n#notificationButton[_ngcontent-%COMP%] {\n  position: relative;\n  width: 42px;\n  top: 1px;\n  right: 1px;\n  overflow: visible !important;\n  font-size: 20px;\n}\n/*# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbImhlYWRlci1jb250ZW50LmNvbXBvbmVudC5zY3NzIl0sIm5hbWVzIjpbXSwibWFwcGluZ3MiOiJBQUFBO0VBQ0Usa0JBQUE7RUFDQSxTQUFBO0VBQ0EsV0FBQTtFQUNBLG1CQUFBO0VBQ0EsZUFBQTtFQUNBLGdCQUFBO0FBQ0Y7O0FBRUE7RUFDRSxrQkFBQTtFQUNBLFdBQUE7RUFDQSxRQUFBO0VBQ0EsVUFBQTtFQUNBLDRCQUFBO0VBQ0EsZUFBQTtBQUNGIiwiZmlsZSI6ImhlYWRlci1jb250ZW50LmNvbXBvbmVudC5zY3NzIiwic291cmNlc0NvbnRlbnQiOlsiaW9uLWJhZGdlIHtcbiAgcG9zaXRpb246IGFic29sdXRlO1xuICB0b3A6IC0xcHg7XG4gIHJpZ2h0OiAtMXB4O1xuICBib3JkZXItcmFkaXVzOiAxMDAlO1xuICBtaW4td2lkdGg6IDIwcHg7XG4gIG1pbi1oZWlnaHQ6IDIwcHg7XG59XG5cbiNub3RpZmljYXRpb25CdXR0b24ge1xuICBwb3NpdGlvbjogcmVsYXRpdmU7XG4gIHdpZHRoOiA0MnB4O1xuICB0b3A6IDFweDtcbiAgcmlnaHQ6IDFweDtcbiAgb3ZlcmZsb3c6IHZpc2libGUgIWltcG9ydGFudDtcbiAgZm9udC1zaXplOiAyMHB4O1xufVxuIl19 */"],
  changeDetection: 0
});

/***/ }),

/***/ 34161:
/*!***************************************************************!*\
  !*** ./src/app/core/shared/layout/header/header.directive.ts ***!
  \***************************************************************/
/***/ (function(__unused_webpack_module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "HeaderDirective": function() { return /* binding */ HeaderDirective; }
/* harmony export */ });
/* harmony import */ var _Users_smartcommunitylab_Documents_work_projects_dslab_playgo_mobile_playgo_mobile_node_modules_babel_runtime_helpers_esm_classCallCheck_js__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./node_modules/@babel/runtime/helpers/esm/classCallCheck.js */ 78069);
/* harmony import */ var _Users_smartcommunitylab_Documents_work_projects_dslab_playgo_mobile_playgo_mobile_node_modules_babel_runtime_helpers_esm_createClass_js__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ./node_modules/@babel/runtime/helpers/esm/createClass.js */ 48047);
/* harmony import */ var _header_content_component__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! ./header-content.component */ 322);
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @angular/core */ 3184);




var HeaderDirective = /*#__PURE__*/function () {
  function HeaderDirective(element, viewContainerRef) {
    (0,_Users_smartcommunitylab_Documents_work_projects_dslab_playgo_mobile_playgo_mobile_node_modules_babel_runtime_helpers_esm_classCallCheck_js__WEBPACK_IMPORTED_MODULE_0__["default"])(this, HeaderDirective);

    this.element = element;
    this.viewContainerRef = viewContainerRef;
  }

  (0,_Users_smartcommunitylab_Documents_work_projects_dslab_playgo_mobile_playgo_mobile_node_modules_babel_runtime_helpers_esm_createClass_js__WEBPACK_IMPORTED_MODULE_1__["default"])(HeaderDirective, [{
    key: "ngOnInit",
    value: function ngOnInit() {
      this.headerContentComponent = this.viewContainerRef.createComponent(_header_content_component__WEBPACK_IMPORTED_MODULE_2__.HeaderContentComponent);
      var host = this.element.nativeElement;
      host.insertBefore(this.headerContentComponent.location.nativeElement, host.firstChild);
    }
  }]);

  return HeaderDirective;
}();

HeaderDirective.ɵfac = function HeaderDirective_Factory(t) {
  return new (t || HeaderDirective)(_angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵdirectiveInject"](_angular_core__WEBPACK_IMPORTED_MODULE_3__.ElementRef), _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵdirectiveInject"](_angular_core__WEBPACK_IMPORTED_MODULE_3__.ViewContainerRef));
};

HeaderDirective.ɵdir = /*@__PURE__*/_angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵdefineDirective"]({
  type: HeaderDirective,
  selectors: [["", "appHeader", ""]]
});

/***/ }),

/***/ 19736:
/*!**********************************************************************!*\
  !*** ./src/app/core/shared/notification-modal/notification.modal.ts ***!
  \**********************************************************************/
/***/ (function(__unused_webpack_module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "NotificationModalPage": function() { return /* binding */ NotificationModalPage; }
/* harmony export */ });
/* harmony import */ var _Users_smartcommunitylab_Documents_work_projects_dslab_playgo_mobile_playgo_mobile_node_modules_babel_runtime_helpers_esm_classCallCheck_js__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./node_modules/@babel/runtime/helpers/esm/classCallCheck.js */ 78069);
/* harmony import */ var _Users_smartcommunitylab_Documents_work_projects_dslab_playgo_mobile_playgo_mobile_node_modules_babel_runtime_helpers_esm_createClass_js__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ./node_modules/@babel/runtime/helpers/esm/createClass.js */ 48047);
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @angular/core */ 3184);
/* harmony import */ var _ionic_angular__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @ionic/angular */ 93819);
/* harmony import */ var _ngx_translate_core__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! @ngx-translate/core */ 87514);





var _c0 = ["class", "modal"];
var NotificationModalPage = /*#__PURE__*/function () {
  function NotificationModalPage(modalController) {
    (0,_Users_smartcommunitylab_Documents_work_projects_dslab_playgo_mobile_playgo_mobile_node_modules_babel_runtime_helpers_esm_classCallCheck_js__WEBPACK_IMPORTED_MODULE_0__["default"])(this, NotificationModalPage);

    this.modalController = modalController;
  }

  (0,_Users_smartcommunitylab_Documents_work_projects_dslab_playgo_mobile_playgo_mobile_node_modules_babel_runtime_helpers_esm_createClass_js__WEBPACK_IMPORTED_MODULE_1__["default"])(NotificationModalPage, [{
    key: "ngOnInit",
    value: function ngOnInit() {}
  }, {
    key: "close",
    value: function close() {
      this.modalController.dismiss(false);
    }
  }]);

  return NotificationModalPage;
}();

NotificationModalPage.ɵfac = function NotificationModalPage_Factory(t) {
  return new (t || NotificationModalPage)(_angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵdirectiveInject"](_ionic_angular__WEBPACK_IMPORTED_MODULE_3__.ModalController));
};

NotificationModalPage.ɵcmp = /*@__PURE__*/_angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵdefineComponent"]({
  type: NotificationModalPage,
  selectors: [["app-notification", 8, "modal"]],
  attrs: _c0,
  decls: 17,
  vars: 5,
  consts: [["color", "playgo"], [1, "ion-text-center"], ["slot", "end"], [3, "click"], ["color", "light", "expand", "block", 3, "click"]],
  template: function NotificationModalPage_Template(rf, ctx) {
    if (rf & 1) {
      _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵelementStart"](0, "ion-header")(1, "ion-toolbar", 0)(2, "ion-title", 1);
      _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵtext"](3);
      _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵelementEnd"]();
      _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵelementStart"](4, "ion-buttons", 2)(5, "ion-button", 3);
      _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵlistener"]("click", function NotificationModalPage_Template_ion_button_click_5_listener() {
        return ctx.close();
      });
      _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵtext"](6, "X");
      _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵelementEnd"]()()()();
      _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵelementStart"](7, "ion-content", 0)(8, "ion-grid")(9, "ion-row")(10, "ion-col")(11, "p");
      _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵtext"](12);
      _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵelementEnd"]()()()()();
      _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵelementStart"](13, "ion-footer")(14, "ion-button", 4);
      _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵlistener"]("click", function NotificationModalPage_Template_ion_button_click_14_listener() {
        return ctx.close();
      });
      _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵtext"](15);
      _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵpipe"](16, "translate");
      _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵelementEnd"]()();
    }

    if (rf & 2) {
      _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵadvance"](3);
      _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵtextInterpolate1"](" ", ctx.notification.data.title, " ");
      _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵadvance"](9);
      _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵtextInterpolate"](ctx.notification.data.body);
      _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵadvance"](3);
      _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵtextInterpolate"](_angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵpipeBind1"](16, 3, "notifications.close"));
    }
  },
  directives: [_ionic_angular__WEBPACK_IMPORTED_MODULE_3__.IonHeader, _ionic_angular__WEBPACK_IMPORTED_MODULE_3__.IonToolbar, _ionic_angular__WEBPACK_IMPORTED_MODULE_3__.IonTitle, _ionic_angular__WEBPACK_IMPORTED_MODULE_3__.IonButtons, _ionic_angular__WEBPACK_IMPORTED_MODULE_3__.IonButton, _ionic_angular__WEBPACK_IMPORTED_MODULE_3__.IonContent, _ionic_angular__WEBPACK_IMPORTED_MODULE_3__.IonGrid, _ionic_angular__WEBPACK_IMPORTED_MODULE_3__.IonRow, _ionic_angular__WEBPACK_IMPORTED_MODULE_3__.IonCol, _ionic_angular__WEBPACK_IMPORTED_MODULE_3__.IonFooter],
  pipes: [_ngx_translate_core__WEBPACK_IMPORTED_MODULE_4__.TranslatePipe],
  styles: [".external[_ngcontent-%COMP%]   .title[_ngcontent-%COMP%] {\n  text-align: center;\n  font-weight: bold;\n  padding: 8px;\n}\n.external[_ngcontent-%COMP%]   .internal[_ngcontent-%COMP%]   .body[_ngcontent-%COMP%] {\n  text-align: justify;\n  padding: 8px;\n}\n/*# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbIm5vdGlmaWNhdGlvbi5tb2RhbC5zY3NzIl0sIm5hbWVzIjpbXSwibWFwcGluZ3MiOiJBQUNFO0VBQ0Usa0JBQUE7RUFDQSxpQkFBQTtFQUNBLFlBQUE7QUFBSjtBQUdJO0VBQ0UsbUJBQUE7RUFDQSxZQUFBO0FBRE4iLCJmaWxlIjoibm90aWZpY2F0aW9uLm1vZGFsLnNjc3MiLCJzb3VyY2VzQ29udGVudCI6WyIuZXh0ZXJuYWwge1xuICAudGl0bGUge1xuICAgIHRleHQtYWxpZ246IGNlbnRlcjtcbiAgICBmb250LXdlaWdodDogYm9sZDtcbiAgICBwYWRkaW5nOiA4cHg7XG4gIH1cbiAgLmludGVybmFsIHtcbiAgICAuYm9keSB7XG4gICAgICB0ZXh0LWFsaWduOiBqdXN0aWZ5O1xuICAgICAgcGFkZGluZzogOHB4O1xuICAgIH1cbiAgfVxufVxuIl19 */"]
});

/***/ }),

/***/ 39107:
/*!****************************************************!*\
  !*** ./src/app/core/shared/pipes/SafeHtml.pipe.ts ***!
  \****************************************************/
/***/ (function(__unused_webpack_module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "SafeHtmlPipe": function() { return /* binding */ SafeHtmlPipe; }
/* harmony export */ });
/* harmony import */ var _Users_smartcommunitylab_Documents_work_projects_dslab_playgo_mobile_playgo_mobile_node_modules_babel_runtime_helpers_esm_classCallCheck_js__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./node_modules/@babel/runtime/helpers/esm/classCallCheck.js */ 78069);
/* harmony import */ var _Users_smartcommunitylab_Documents_work_projects_dslab_playgo_mobile_playgo_mobile_node_modules_babel_runtime_helpers_esm_createClass_js__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ./node_modules/@babel/runtime/helpers/esm/createClass.js */ 48047);
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @angular/core */ 3184);
/* harmony import */ var _angular_platform_browser__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @angular/platform-browser */ 50318);




var SafeHtmlPipe = /*#__PURE__*/function () {
  function SafeHtmlPipe(sanitized) {
    (0,_Users_smartcommunitylab_Documents_work_projects_dslab_playgo_mobile_playgo_mobile_node_modules_babel_runtime_helpers_esm_classCallCheck_js__WEBPACK_IMPORTED_MODULE_0__["default"])(this, SafeHtmlPipe);

    this.sanitized = sanitized;
  }

  (0,_Users_smartcommunitylab_Documents_work_projects_dslab_playgo_mobile_playgo_mobile_node_modules_babel_runtime_helpers_esm_createClass_js__WEBPACK_IMPORTED_MODULE_1__["default"])(SafeHtmlPipe, [{
    key: "transform",
    value: function transform(value) {
      return this.sanitized.bypassSecurityTrustHtml(value);
    }
  }]);

  return SafeHtmlPipe;
}();

SafeHtmlPipe.ɵfac = function SafeHtmlPipe_Factory(t) {
  return new (t || SafeHtmlPipe)(_angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵdirectiveInject"](_angular_platform_browser__WEBPACK_IMPORTED_MODULE_3__.DomSanitizer, 16));
};

SafeHtmlPipe.ɵpipe = /*@__PURE__*/_angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵdefinePipe"]({
  name: "safeHtml",
  type: SafeHtmlPipe,
  pure: true
});

/***/ }),

/***/ 12341:
/*!*************************************************************!*\
  !*** ./src/app/core/shared/pipes/abstractObservablePipe.ts ***!
  \*************************************************************/
/***/ (function(__unused_webpack_module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "AbstractObservablePipe": function() { return /* binding */ AbstractObservablePipe; }
/* harmony export */ });
/* harmony import */ var _Users_smartcommunitylab_Documents_work_projects_dslab_playgo_mobile_playgo_mobile_node_modules_babel_runtime_helpers_esm_classCallCheck_js__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./node_modules/@babel/runtime/helpers/esm/classCallCheck.js */ 78069);
/* harmony import */ var _Users_smartcommunitylab_Documents_work_projects_dslab_playgo_mobile_playgo_mobile_node_modules_babel_runtime_helpers_esm_createClass_js__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ./node_modules/@babel/runtime/helpers/esm/createClass.js */ 48047);
/* harmony import */ var rxjs__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! rxjs */ 80228);
/* harmony import */ var rxjs__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! rxjs */ 98977);
/* harmony import */ var rxjs__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! rxjs */ 32673);
/* harmony import */ var rxjs__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! rxjs */ 53158);
/* harmony import */ var rxjs__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(/*! rxjs */ 20591);
/* harmony import */ var rxjs__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(/*! rxjs */ 68951);
/* harmony import */ var lodash_es__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! lodash-es */ 63247);




/**
 * Abstract class used to help creating efficient "push" pipes.
 *
 * Basically we would like to have a pipe that behaves like onPush component.
 * Being evaluated every time the input changes, but with ability to explicitly trigger a new value based
 * on observable.
 *
 * Sadly this is no possible right now, so this is a workaround. When using this class, you need to:
 * - implement `transformToObservable` method.
 * - use `super.doTransform` in `transform` method.
 * - use `super.destroy` in `ngOnDestroy` method.
 * - annotate your pipe with `@Pipe({ pure: false })`
 *
 */

var AbstractObservablePipe = /*#__PURE__*/function () {
  function AbstractObservablePipe(ref) {
    var _this = this;

    (0,_Users_smartcommunitylab_Documents_work_projects_dslab_playgo_mobile_playgo_mobile_node_modules_babel_runtime_helpers_esm_classCallCheck_js__WEBPACK_IMPORTED_MODULE_0__["default"])(this, AbstractObservablePipe);

    this.pipeIsDestroyed$ = new rxjs__WEBPACK_IMPORTED_MODULE_2__.Subject();
    this.requestsToTransformSubject = new rxjs__WEBPACK_IMPORTED_MODULE_2__.Subject();
    this.formattedValue$ = this.requestsToTransformSubject.pipe((0,rxjs__WEBPACK_IMPORTED_MODULE_3__.distinctUntilChanged)(lodash_es__WEBPACK_IMPORTED_MODULE_4__["default"]), (0,rxjs__WEBPACK_IMPORTED_MODULE_5__.switchMap)(function (request) {
      return _this.transformToObservable(request).pipe((0,rxjs__WEBPACK_IMPORTED_MODULE_6__.catchError)(function (e) {
        console.error(e);
        return rxjs__WEBPACK_IMPORTED_MODULE_7__.EMPTY;
      }));
    }), (0,rxjs__WEBPACK_IMPORTED_MODULE_8__.takeUntil)(this.pipeIsDestroyed$));
    this.formattedValue = null;
    this.formattedValue$.subscribe(function (formattedValue) {
      _this.formattedValue = formattedValue; // We actually do not have any means to output asynchronously value from the pipe,
      // so we force the change detection, and pipe will be re-evaluated. At this point we have
      // this.formattedValue set, and we will output it in the pipe. To avoid infinite loop, we use
      // distinctUntilChanged operator.

      ref.markForCheck();
    });
  }

  (0,_Users_smartcommunitylab_Documents_work_projects_dslab_playgo_mobile_playgo_mobile_node_modules_babel_runtime_helpers_esm_createClass_js__WEBPACK_IMPORTED_MODULE_1__["default"])(AbstractObservablePipe, [{
    key: "doTransform",
    value: function doTransform(input) {
      this.requestsToTransformSubject.next(input);
      return this.formattedValue;
    }
  }, {
    key: "destroy",
    value: function destroy() {
      this.pipeIsDestroyed$.next();
      this.pipeIsDestroyed$.complete();
    }
  }]);

  return AbstractObservablePipe;
}();

/***/ }),

/***/ 73088:
/*!*******************************************************!*\
  !*** ./src/app/core/shared/pipes/languageMap.pipe.ts ***!
  \*******************************************************/
/***/ (function(__unused_webpack_module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "LanguageMapPipe": function() { return /* binding */ LanguageMapPipe; }
/* harmony export */ });
/* harmony import */ var _Users_smartcommunitylab_Documents_work_projects_dslab_playgo_mobile_playgo_mobile_node_modules_babel_runtime_helpers_esm_classCallCheck_js__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./node_modules/@babel/runtime/helpers/esm/classCallCheck.js */ 78069);
/* harmony import */ var _Users_smartcommunitylab_Documents_work_projects_dslab_playgo_mobile_playgo_mobile_node_modules_babel_runtime_helpers_esm_createClass_js__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ./node_modules/@babel/runtime/helpers/esm/createClass.js */ 48047);
/* harmony import */ var _Users_smartcommunitylab_Documents_work_projects_dslab_playgo_mobile_playgo_mobile_node_modules_babel_runtime_helpers_esm_get_js__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! ./node_modules/@babel/runtime/helpers/esm/get.js */ 64756);
/* harmony import */ var _Users_smartcommunitylab_Documents_work_projects_dslab_playgo_mobile_playgo_mobile_node_modules_babel_runtime_helpers_esm_getPrototypeOf_js__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! ./node_modules/@babel/runtime/helpers/esm/getPrototypeOf.js */ 20265);
/* harmony import */ var _Users_smartcommunitylab_Documents_work_projects_dslab_playgo_mobile_playgo_mobile_node_modules_babel_runtime_helpers_esm_inherits_js__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! ./node_modules/@babel/runtime/helpers/esm/inherits.js */ 24582);
/* harmony import */ var _Users_smartcommunitylab_Documents_work_projects_dslab_playgo_mobile_playgo_mobile_node_modules_babel_runtime_helpers_esm_createSuper_js__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! ./node_modules/@babel/runtime/helpers/esm/createSuper.js */ 2496);
/* harmony import */ var _abstractObservablePipe__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! ./abstractObservablePipe */ 12341);
/* harmony import */ var rxjs__WEBPACK_IMPORTED_MODULE_9__ = __webpack_require__(/*! rxjs */ 50635);
/* harmony import */ var lodash_es__WEBPACK_IMPORTED_MODULE_10__ = __webpack_require__(/*! lodash-es */ 92941);
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_11__ = __webpack_require__(/*! @angular/core */ 3184);
/* harmony import */ var _services_user_service__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(/*! ../services/user.service */ 50749);
/* harmony import */ var _services_error_service__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(/*! ../services/error.service */ 96204);












var LanguageMapPipe = /*#__PURE__*/function (_AbstractObservablePi) {
  (0,_Users_smartcommunitylab_Documents_work_projects_dslab_playgo_mobile_playgo_mobile_node_modules_babel_runtime_helpers_esm_inherits_js__WEBPACK_IMPORTED_MODULE_4__["default"])(LanguageMapPipe, _AbstractObservablePi);

  var _super = (0,_Users_smartcommunitylab_Documents_work_projects_dslab_playgo_mobile_playgo_mobile_node_modules_babel_runtime_helpers_esm_createSuper_js__WEBPACK_IMPORTED_MODULE_5__["default"])(LanguageMapPipe);

  function LanguageMapPipe(userService, errorService, ref) {
    var _this;

    (0,_Users_smartcommunitylab_Documents_work_projects_dslab_playgo_mobile_playgo_mobile_node_modules_babel_runtime_helpers_esm_classCallCheck_js__WEBPACK_IMPORTED_MODULE_0__["default"])(this, LanguageMapPipe);

    _this = _super.call(this, ref);
    _this.userService = userService;
    _this.errorService = errorService;
    _this.ref = ref;
    return _this;
  }

  (0,_Users_smartcommunitylab_Documents_work_projects_dslab_playgo_mobile_playgo_mobile_node_modules_babel_runtime_helpers_esm_createClass_js__WEBPACK_IMPORTED_MODULE_1__["default"])(LanguageMapPipe, [{
    key: "ngOnDestroy",
    value: function ngOnDestroy() {
      (0,_Users_smartcommunitylab_Documents_work_projects_dslab_playgo_mobile_playgo_mobile_node_modules_babel_runtime_helpers_esm_get_js__WEBPACK_IMPORTED_MODULE_2__["default"])((0,_Users_smartcommunitylab_Documents_work_projects_dslab_playgo_mobile_playgo_mobile_node_modules_babel_runtime_helpers_esm_getPrototypeOf_js__WEBPACK_IMPORTED_MODULE_3__["default"])(LanguageMapPipe.prototype), "destroy", this).call(this);
    }
  }, {
    key: "transform",
    value: function transform(value) {
      return this.doTransform(value);
    }
  }, {
    key: "transformToObservable",
    value: function transformToObservable(input) {
      var _this2 = this;

      return this.userService.userLanguage$.pipe((0,rxjs__WEBPACK_IMPORTED_MODULE_9__.map)(function (language) {
        try {
          return _this2.format(input, language);
        } catch (e) {
          _this2.errorService.handleError(e, 'silent');

          return null;
        }
      }));
    }
  }, {
    key: "format",
    value: function format(value, language) {
      var languagesToTry = [language, 'en', 'it'];
      var applicableLanguage = languagesToTry.find(function (eachLanguage) {
        return (0,lodash_es__WEBPACK_IMPORTED_MODULE_10__["default"])(value, eachLanguage);
      });
      return applicableLanguage ? value[applicableLanguage] : null;
    }
  }]);

  return LanguageMapPipe;
}(_abstractObservablePipe__WEBPACK_IMPORTED_MODULE_6__.AbstractObservablePipe);

LanguageMapPipe.ɵfac = function LanguageMapPipe_Factory(t) {
  return new (t || LanguageMapPipe)(_angular_core__WEBPACK_IMPORTED_MODULE_11__["ɵɵdirectiveInject"](_services_user_service__WEBPACK_IMPORTED_MODULE_7__.UserService, 16), _angular_core__WEBPACK_IMPORTED_MODULE_11__["ɵɵdirectiveInject"](_services_error_service__WEBPACK_IMPORTED_MODULE_8__.ErrorService, 16), _angular_core__WEBPACK_IMPORTED_MODULE_11__["ɵɵdirectiveInject"](_angular_core__WEBPACK_IMPORTED_MODULE_11__.ChangeDetectorRef, 16));
};

LanguageMapPipe.ɵpipe = /*@__PURE__*/_angular_core__WEBPACK_IMPORTED_MODULE_11__["ɵɵdefinePipe"]({
  name: "languageMap",
  type: LanguageMapPipe,
  pure: false
});

/***/ }),

/***/ 34489:
/*!*****************************************************!*\
  !*** ./src/app/core/shared/pipes/localDate.pipe.ts ***!
  \*****************************************************/
/***/ (function(__unused_webpack_module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "LocalDatePipe": function() { return /* binding */ LocalDatePipe; }
/* harmony export */ });
/* harmony import */ var _Users_smartcommunitylab_Documents_work_projects_dslab_playgo_mobile_playgo_mobile_node_modules_babel_runtime_helpers_esm_classCallCheck_js__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./node_modules/@babel/runtime/helpers/esm/classCallCheck.js */ 78069);
/* harmony import */ var _Users_smartcommunitylab_Documents_work_projects_dslab_playgo_mobile_playgo_mobile_node_modules_babel_runtime_helpers_esm_createClass_js__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ./node_modules/@babel/runtime/helpers/esm/createClass.js */ 48047);
/* harmony import */ var _Users_smartcommunitylab_Documents_work_projects_dslab_playgo_mobile_playgo_mobile_node_modules_babel_runtime_helpers_esm_get_js__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! ./node_modules/@babel/runtime/helpers/esm/get.js */ 64756);
/* harmony import */ var _Users_smartcommunitylab_Documents_work_projects_dslab_playgo_mobile_playgo_mobile_node_modules_babel_runtime_helpers_esm_getPrototypeOf_js__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! ./node_modules/@babel/runtime/helpers/esm/getPrototypeOf.js */ 20265);
/* harmony import */ var _Users_smartcommunitylab_Documents_work_projects_dslab_playgo_mobile_playgo_mobile_node_modules_babel_runtime_helpers_esm_inherits_js__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! ./node_modules/@babel/runtime/helpers/esm/inherits.js */ 24582);
/* harmony import */ var _Users_smartcommunitylab_Documents_work_projects_dslab_playgo_mobile_playgo_mobile_node_modules_babel_runtime_helpers_esm_createSuper_js__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! ./node_modules/@babel/runtime/helpers/esm/createSuper.js */ 2496);
/* harmony import */ var _angular_common__WEBPACK_IMPORTED_MODULE_10__ = __webpack_require__(/*! @angular/common */ 36362);
/* harmony import */ var rxjs__WEBPACK_IMPORTED_MODULE_9__ = __webpack_require__(/*! rxjs */ 50635);
/* harmony import */ var _abstractObservablePipe__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! ./abstractObservablePipe */ 12341);
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_11__ = __webpack_require__(/*! @angular/core */ 3184);
/* harmony import */ var _services_user_service__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(/*! ../services/user.service */ 50749);
/* harmony import */ var _services_error_service__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(/*! ../services/error.service */ 96204);












var LocalDatePipe = /*#__PURE__*/function (_AbstractObservablePi) {
  (0,_Users_smartcommunitylab_Documents_work_projects_dslab_playgo_mobile_playgo_mobile_node_modules_babel_runtime_helpers_esm_inherits_js__WEBPACK_IMPORTED_MODULE_4__["default"])(LocalDatePipe, _AbstractObservablePi);

  var _super = (0,_Users_smartcommunitylab_Documents_work_projects_dslab_playgo_mobile_playgo_mobile_node_modules_babel_runtime_helpers_esm_createSuper_js__WEBPACK_IMPORTED_MODULE_5__["default"])(LocalDatePipe);

  function LocalDatePipe(userService, ref, errorService) {
    var _this;

    (0,_Users_smartcommunitylab_Documents_work_projects_dslab_playgo_mobile_playgo_mobile_node_modules_babel_runtime_helpers_esm_classCallCheck_js__WEBPACK_IMPORTED_MODULE_0__["default"])(this, LocalDatePipe);

    _this = _super.call(this, ref);
    _this.userService = userService;
    _this.ref = ref;
    _this.errorService = errorService;
    return _this;
  }

  (0,_Users_smartcommunitylab_Documents_work_projects_dslab_playgo_mobile_playgo_mobile_node_modules_babel_runtime_helpers_esm_createClass_js__WEBPACK_IMPORTED_MODULE_1__["default"])(LocalDatePipe, [{
    key: "transform",
    value: function transform(value, format) {
      return this.doTransform({
        value: value,
        format: format
      });
    }
    /**
     * @override
     */

  }, {
    key: "transformToObservable",
    value: function transformToObservable(input) {
      var _this2 = this;

      return this.userService.userLocale$.pipe((0,rxjs__WEBPACK_IMPORTED_MODULE_9__.map)(function (locale) {
        try {
          return _this2.format(input.value, input.format, locale);
        } catch (e) {
          _this2.errorService.handleError(e, 'silent');

          return '';
        }
      }));
    }
  }, {
    key: "format",
    value: function format(value, _format, locale) {
      if (!value) {
        return '';
      }

      if (!_format) {
        _format = 'shortDate';
      }

      if (typeof _format !== 'string') {
        try {
          return Intl.DateTimeFormat(locale, _format).format(value);
        } catch (e) {
          // fallback if there is some problem with Intl
          return (0,_angular_common__WEBPACK_IMPORTED_MODULE_10__.formatDate)(value, 'shortDate', locale);
        }
      } // basic string format


      return (0,_angular_common__WEBPACK_IMPORTED_MODULE_10__.formatDate)(value, _format, locale);
    }
  }, {
    key: "ngOnDestroy",
    value: function ngOnDestroy() {
      (0,_Users_smartcommunitylab_Documents_work_projects_dslab_playgo_mobile_playgo_mobile_node_modules_babel_runtime_helpers_esm_get_js__WEBPACK_IMPORTED_MODULE_2__["default"])((0,_Users_smartcommunitylab_Documents_work_projects_dslab_playgo_mobile_playgo_mobile_node_modules_babel_runtime_helpers_esm_getPrototypeOf_js__WEBPACK_IMPORTED_MODULE_3__["default"])(LocalDatePipe.prototype), "destroy", this).call(this);
    }
  }]);

  return LocalDatePipe;
}(_abstractObservablePipe__WEBPACK_IMPORTED_MODULE_6__.AbstractObservablePipe);

LocalDatePipe.ɵfac = function LocalDatePipe_Factory(t) {
  return new (t || LocalDatePipe)(_angular_core__WEBPACK_IMPORTED_MODULE_11__["ɵɵdirectiveInject"](_services_user_service__WEBPACK_IMPORTED_MODULE_7__.UserService, 16), _angular_core__WEBPACK_IMPORTED_MODULE_11__["ɵɵdirectiveInject"](_angular_core__WEBPACK_IMPORTED_MODULE_11__.ChangeDetectorRef, 16), _angular_core__WEBPACK_IMPORTED_MODULE_11__["ɵɵdirectiveInject"](_services_error_service__WEBPACK_IMPORTED_MODULE_8__.ErrorService, 16));
};

LocalDatePipe.ɵpipe = /*@__PURE__*/_angular_core__WEBPACK_IMPORTED_MODULE_11__["ɵɵdefinePipe"]({
  name: "localDate",
  type: LocalDatePipe,
  pure: false
});

/***/ }),

/***/ 89713:
/*!*******************************************************!*\
  !*** ./src/app/core/shared/pipes/localNumber.pipe.ts ***!
  \*******************************************************/
/***/ (function(__unused_webpack_module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "LocalNumberPipe": function() { return /* binding */ LocalNumberPipe; }
/* harmony export */ });
/* harmony import */ var _Users_smartcommunitylab_Documents_work_projects_dslab_playgo_mobile_playgo_mobile_node_modules_babel_runtime_helpers_esm_classCallCheck_js__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./node_modules/@babel/runtime/helpers/esm/classCallCheck.js */ 78069);
/* harmony import */ var _Users_smartcommunitylab_Documents_work_projects_dslab_playgo_mobile_playgo_mobile_node_modules_babel_runtime_helpers_esm_createClass_js__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ./node_modules/@babel/runtime/helpers/esm/createClass.js */ 48047);
/* harmony import */ var _Users_smartcommunitylab_Documents_work_projects_dslab_playgo_mobile_playgo_mobile_node_modules_babel_runtime_helpers_esm_inherits_js__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! ./node_modules/@babel/runtime/helpers/esm/inherits.js */ 24582);
/* harmony import */ var _Users_smartcommunitylab_Documents_work_projects_dslab_playgo_mobile_playgo_mobile_node_modules_babel_runtime_helpers_esm_createSuper_js__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! ./node_modules/@babel/runtime/helpers/esm/createSuper.js */ 2496);
/* harmony import */ var _angular_common__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(/*! @angular/common */ 36362);
/* harmony import */ var _abstractObservablePipe__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! ./abstractObservablePipe */ 12341);
/* harmony import */ var rxjs__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(/*! rxjs */ 50635);
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_9__ = __webpack_require__(/*! @angular/core */ 3184);
/* harmony import */ var _services_user_service__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! ../services/user.service */ 50749);
/* harmony import */ var _services_error_service__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! ../services/error.service */ 96204);










var LocalNumberPipe = /*#__PURE__*/function (_AbstractObservablePi) {
  (0,_Users_smartcommunitylab_Documents_work_projects_dslab_playgo_mobile_playgo_mobile_node_modules_babel_runtime_helpers_esm_inherits_js__WEBPACK_IMPORTED_MODULE_2__["default"])(LocalNumberPipe, _AbstractObservablePi);

  var _super = (0,_Users_smartcommunitylab_Documents_work_projects_dslab_playgo_mobile_playgo_mobile_node_modules_babel_runtime_helpers_esm_createSuper_js__WEBPACK_IMPORTED_MODULE_3__["default"])(LocalNumberPipe);

  function LocalNumberPipe(userService, errorService, ref) {
    var _this;

    (0,_Users_smartcommunitylab_Documents_work_projects_dslab_playgo_mobile_playgo_mobile_node_modules_babel_runtime_helpers_esm_classCallCheck_js__WEBPACK_IMPORTED_MODULE_0__["default"])(this, LocalNumberPipe);

    _this = _super.call(this, ref);
    _this.userService = userService;
    _this.errorService = errorService;
    _this.ref = ref;
    return _this;
  }

  (0,_Users_smartcommunitylab_Documents_work_projects_dslab_playgo_mobile_playgo_mobile_node_modules_babel_runtime_helpers_esm_createClass_js__WEBPACK_IMPORTED_MODULE_1__["default"])(LocalNumberPipe, [{
    key: "transform",
    value: function transform(value, format) {
      return this.doTransform({
        value: value,
        format: format
      });
    }
  }, {
    key: "transformToObservable",
    value: function transformToObservable(input) {
      var _this2 = this;

      return this.userService.userLocale$.pipe((0,rxjs__WEBPACK_IMPORTED_MODULE_7__.map)(function (locale) {
        try {
          return _this2.format(input.value, input.format, locale);
        } catch (e) {
          _this2.errorService.handleError(e, 'silent');

          return '';
        }
      }));
    }
  }, {
    key: "format",
    value: function format(value, _format, locale) {
      if (value == null) {
        return '';
      }

      if (!_format) {
        _format = '.2-2';
      }

      return (0,_angular_common__WEBPACK_IMPORTED_MODULE_8__.formatNumber)(value, locale, _format);
    }
  }]);

  return LocalNumberPipe;
}(_abstractObservablePipe__WEBPACK_IMPORTED_MODULE_4__.AbstractObservablePipe);

LocalNumberPipe.ɵfac = function LocalNumberPipe_Factory(t) {
  return new (t || LocalNumberPipe)(_angular_core__WEBPACK_IMPORTED_MODULE_9__["ɵɵdirectiveInject"](_services_user_service__WEBPACK_IMPORTED_MODULE_5__.UserService, 16), _angular_core__WEBPACK_IMPORTED_MODULE_9__["ɵɵdirectiveInject"](_services_error_service__WEBPACK_IMPORTED_MODULE_6__.ErrorService, 16), _angular_core__WEBPACK_IMPORTED_MODULE_9__["ɵɵdirectiveInject"](_angular_core__WEBPACK_IMPORTED_MODULE_9__.ChangeDetectorRef, 16));
};

LocalNumberPipe.ɵpipe = /*@__PURE__*/_angular_core__WEBPACK_IMPORTED_MODULE_9__["ɵɵdefinePipe"]({
  name: "localNumber",
  type: LocalNumberPipe,
  pure: false
});

/***/ }),

/***/ 81386:
/*!***********************************************************!*\
  !*** ./src/app/core/shared/plugin-mocks/AppPluginMock.ts ***!
  \***********************************************************/
/***/ (function(__unused_webpack_module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "AppPluginMock": function() { return /* binding */ AppPluginMock; }
/* harmony export */ });
/* harmony import */ var _Users_smartcommunitylab_Documents_work_projects_dslab_playgo_mobile_playgo_mobile_node_modules_babel_runtime_helpers_esm_classCallCheck_js__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./node_modules/@babel/runtime/helpers/esm/classCallCheck.js */ 78069);
/* harmony import */ var _Users_smartcommunitylab_Documents_work_projects_dslab_playgo_mobile_playgo_mobile_node_modules_babel_runtime_helpers_esm_createClass_js__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ./node_modules/@babel/runtime/helpers/esm/createClass.js */ 48047);
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! tslib */ 34929);
/* harmony import */ var _mock_utils__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! ./mock-utils */ 67650);



function _regeneratorRuntime() { "use strict"; /*! regenerator-runtime -- Copyright (c) 2014-present, Facebook, Inc. -- license (MIT): https://github.com/facebook/regenerator/blob/main/LICENSE */ _regeneratorRuntime = function _regeneratorRuntime() { return exports; }; var exports = {}, Op = Object.prototype, hasOwn = Op.hasOwnProperty, $Symbol = "function" == typeof Symbol ? Symbol : {}, iteratorSymbol = $Symbol.iterator || "@@iterator", asyncIteratorSymbol = $Symbol.asyncIterator || "@@asyncIterator", toStringTagSymbol = $Symbol.toStringTag || "@@toStringTag"; function define(obj, key, value) { return Object.defineProperty(obj, key, { value: value, enumerable: !0, configurable: !0, writable: !0 }), obj[key]; } try { define({}, ""); } catch (err) { define = function define(obj, key, value) { return obj[key] = value; }; } function wrap(innerFn, outerFn, self, tryLocsList) { var protoGenerator = outerFn && outerFn.prototype instanceof Generator ? outerFn : Generator, generator = Object.create(protoGenerator.prototype), context = new Context(tryLocsList || []); return generator._invoke = function (innerFn, self, context) { var state = "suspendedStart"; return function (method, arg) { if ("executing" === state) throw new Error("Generator is already running"); if ("completed" === state) { if ("throw" === method) throw arg; return doneResult(); } for (context.method = method, context.arg = arg;;) { var delegate = context.delegate; if (delegate) { var delegateResult = maybeInvokeDelegate(delegate, context); if (delegateResult) { if (delegateResult === ContinueSentinel) continue; return delegateResult; } } if ("next" === context.method) context.sent = context._sent = context.arg;else if ("throw" === context.method) { if ("suspendedStart" === state) throw state = "completed", context.arg; context.dispatchException(context.arg); } else "return" === context.method && context.abrupt("return", context.arg); state = "executing"; var record = tryCatch(innerFn, self, context); if ("normal" === record.type) { if (state = context.done ? "completed" : "suspendedYield", record.arg === ContinueSentinel) continue; return { value: record.arg, done: context.done }; } "throw" === record.type && (state = "completed", context.method = "throw", context.arg = record.arg); } }; }(innerFn, self, context), generator; } function tryCatch(fn, obj, arg) { try { return { type: "normal", arg: fn.call(obj, arg) }; } catch (err) { return { type: "throw", arg: err }; } } exports.wrap = wrap; var ContinueSentinel = {}; function Generator() {} function GeneratorFunction() {} function GeneratorFunctionPrototype() {} var IteratorPrototype = {}; define(IteratorPrototype, iteratorSymbol, function () { return this; }); var getProto = Object.getPrototypeOf, NativeIteratorPrototype = getProto && getProto(getProto(values([]))); NativeIteratorPrototype && NativeIteratorPrototype !== Op && hasOwn.call(NativeIteratorPrototype, iteratorSymbol) && (IteratorPrototype = NativeIteratorPrototype); var Gp = GeneratorFunctionPrototype.prototype = Generator.prototype = Object.create(IteratorPrototype); function defineIteratorMethods(prototype) { ["next", "throw", "return"].forEach(function (method) { define(prototype, method, function (arg) { return this._invoke(method, arg); }); }); } function AsyncIterator(generator, PromiseImpl) { function invoke(method, arg, resolve, reject) { var record = tryCatch(generator[method], generator, arg); if ("throw" !== record.type) { var result = record.arg, value = result.value; return value && "object" == typeof value && hasOwn.call(value, "__await") ? PromiseImpl.resolve(value.__await).then(function (value) { invoke("next", value, resolve, reject); }, function (err) { invoke("throw", err, resolve, reject); }) : PromiseImpl.resolve(value).then(function (unwrapped) { result.value = unwrapped, resolve(result); }, function (error) { return invoke("throw", error, resolve, reject); }); } reject(record.arg); } var previousPromise; this._invoke = function (method, arg) { function callInvokeWithMethodAndArg() { return new PromiseImpl(function (resolve, reject) { invoke(method, arg, resolve, reject); }); } return previousPromise = previousPromise ? previousPromise.then(callInvokeWithMethodAndArg, callInvokeWithMethodAndArg) : callInvokeWithMethodAndArg(); }; } function maybeInvokeDelegate(delegate, context) { var method = delegate.iterator[context.method]; if (undefined === method) { if (context.delegate = null, "throw" === context.method) { if (delegate.iterator.return && (context.method = "return", context.arg = undefined, maybeInvokeDelegate(delegate, context), "throw" === context.method)) return ContinueSentinel; context.method = "throw", context.arg = new TypeError("The iterator does not provide a 'throw' method"); } return ContinueSentinel; } var record = tryCatch(method, delegate.iterator, context.arg); if ("throw" === record.type) return context.method = "throw", context.arg = record.arg, context.delegate = null, ContinueSentinel; var info = record.arg; return info ? info.done ? (context[delegate.resultName] = info.value, context.next = delegate.nextLoc, "return" !== context.method && (context.method = "next", context.arg = undefined), context.delegate = null, ContinueSentinel) : info : (context.method = "throw", context.arg = new TypeError("iterator result is not an object"), context.delegate = null, ContinueSentinel); } function pushTryEntry(locs) { var entry = { tryLoc: locs[0] }; 1 in locs && (entry.catchLoc = locs[1]), 2 in locs && (entry.finallyLoc = locs[2], entry.afterLoc = locs[3]), this.tryEntries.push(entry); } function resetTryEntry(entry) { var record = entry.completion || {}; record.type = "normal", delete record.arg, entry.completion = record; } function Context(tryLocsList) { this.tryEntries = [{ tryLoc: "root" }], tryLocsList.forEach(pushTryEntry, this), this.reset(!0); } function values(iterable) { if (iterable) { var iteratorMethod = iterable[iteratorSymbol]; if (iteratorMethod) return iteratorMethod.call(iterable); if ("function" == typeof iterable.next) return iterable; if (!isNaN(iterable.length)) { var i = -1, next = function next() { for (; ++i < iterable.length;) { if (hasOwn.call(iterable, i)) return next.value = iterable[i], next.done = !1, next; } return next.value = undefined, next.done = !0, next; }; return next.next = next; } } return { next: doneResult }; } function doneResult() { return { value: undefined, done: !0 }; } return GeneratorFunction.prototype = GeneratorFunctionPrototype, define(Gp, "constructor", GeneratorFunctionPrototype), define(GeneratorFunctionPrototype, "constructor", GeneratorFunction), GeneratorFunction.displayName = define(GeneratorFunctionPrototype, toStringTagSymbol, "GeneratorFunction"), exports.isGeneratorFunction = function (genFun) { var ctor = "function" == typeof genFun && genFun.constructor; return !!ctor && (ctor === GeneratorFunction || "GeneratorFunction" === (ctor.displayName || ctor.name)); }, exports.mark = function (genFun) { return Object.setPrototypeOf ? Object.setPrototypeOf(genFun, GeneratorFunctionPrototype) : (genFun.__proto__ = GeneratorFunctionPrototype, define(genFun, toStringTagSymbol, "GeneratorFunction")), genFun.prototype = Object.create(Gp), genFun; }, exports.awrap = function (arg) { return { __await: arg }; }, defineIteratorMethods(AsyncIterator.prototype), define(AsyncIterator.prototype, asyncIteratorSymbol, function () { return this; }), exports.AsyncIterator = AsyncIterator, exports.async = function (innerFn, outerFn, self, tryLocsList, PromiseImpl) { void 0 === PromiseImpl && (PromiseImpl = Promise); var iter = new AsyncIterator(wrap(innerFn, outerFn, self, tryLocsList), PromiseImpl); return exports.isGeneratorFunction(outerFn) ? iter : iter.next().then(function (result) { return result.done ? result.value : iter.next(); }); }, defineIteratorMethods(Gp), define(Gp, toStringTagSymbol, "Generator"), define(Gp, iteratorSymbol, function () { return this; }), define(Gp, "toString", function () { return "[object Generator]"; }), exports.keys = function (object) { var keys = []; for (var key in object) { keys.push(key); } return keys.reverse(), function next() { for (; keys.length;) { var key = keys.pop(); if (key in object) return next.value = key, next.done = !1, next; } return next.done = !0, next; }; }, exports.values = values, Context.prototype = { constructor: Context, reset: function reset(skipTempReset) { if (this.prev = 0, this.next = 0, this.sent = this._sent = undefined, this.done = !1, this.delegate = null, this.method = "next", this.arg = undefined, this.tryEntries.forEach(resetTryEntry), !skipTempReset) for (var name in this) { "t" === name.charAt(0) && hasOwn.call(this, name) && !isNaN(+name.slice(1)) && (this[name] = undefined); } }, stop: function stop() { this.done = !0; var rootRecord = this.tryEntries[0].completion; if ("throw" === rootRecord.type) throw rootRecord.arg; return this.rval; }, dispatchException: function dispatchException(exception) { if (this.done) throw exception; var context = this; function handle(loc, caught) { return record.type = "throw", record.arg = exception, context.next = loc, caught && (context.method = "next", context.arg = undefined), !!caught; } for (var i = this.tryEntries.length - 1; i >= 0; --i) { var entry = this.tryEntries[i], record = entry.completion; if ("root" === entry.tryLoc) return handle("end"); if (entry.tryLoc <= this.prev) { var hasCatch = hasOwn.call(entry, "catchLoc"), hasFinally = hasOwn.call(entry, "finallyLoc"); if (hasCatch && hasFinally) { if (this.prev < entry.catchLoc) return handle(entry.catchLoc, !0); if (this.prev < entry.finallyLoc) return handle(entry.finallyLoc); } else if (hasCatch) { if (this.prev < entry.catchLoc) return handle(entry.catchLoc, !0); } else { if (!hasFinally) throw new Error("try statement without catch or finally"); if (this.prev < entry.finallyLoc) return handle(entry.finallyLoc); } } } }, abrupt: function abrupt(type, arg) { for (var i = this.tryEntries.length - 1; i >= 0; --i) { var entry = this.tryEntries[i]; if (entry.tryLoc <= this.prev && hasOwn.call(entry, "finallyLoc") && this.prev < entry.finallyLoc) { var finallyEntry = entry; break; } } finallyEntry && ("break" === type || "continue" === type) && finallyEntry.tryLoc <= arg && arg <= finallyEntry.finallyLoc && (finallyEntry = null); var record = finallyEntry ? finallyEntry.completion : {}; return record.type = type, record.arg = arg, finallyEntry ? (this.method = "next", this.next = finallyEntry.finallyLoc, ContinueSentinel) : this.complete(record); }, complete: function complete(record, afterLoc) { if ("throw" === record.type) throw record.arg; return "break" === record.type || "continue" === record.type ? this.next = record.arg : "return" === record.type ? (this.rval = this.arg = record.arg, this.method = "return", this.next = "end") : "normal" === record.type && afterLoc && (this.next = afterLoc), ContinueSentinel; }, finish: function finish(finallyLoc) { for (var i = this.tryEntries.length - 1; i >= 0; --i) { var entry = this.tryEntries[i]; if (entry.finallyLoc === finallyLoc) return this.complete(entry.completion, entry.afterLoc), resetTryEntry(entry), ContinueSentinel; } }, catch: function _catch(tryLoc) { for (var i = this.tryEntries.length - 1; i >= 0; --i) { var entry = this.tryEntries[i]; if (entry.tryLoc === tryLoc) { var record = entry.completion; if ("throw" === record.type) { var thrown = record.arg; resetTryEntry(entry); } return thrown; } } throw new Error("illegal catch attempt"); }, delegateYield: function delegateYield(iterable, resultName, nextLoc) { return this.delegate = { iterator: values(iterable), resultName: resultName, nextLoc: nextLoc }, "next" === this.method && (this.arg = undefined), ContinueSentinel; } }, exports; }



var mockMethod = (0,_mock_utils__WEBPACK_IMPORTED_MODULE_2__.getMockMethodAnnotation)({
  doLog: false,
  logPrefix: 'AppPluginMock'
});
var AppPluginMock = /*#__PURE__*/function () {
  function AppPluginMock() {
    (0,_Users_smartcommunitylab_Documents_work_projects_dslab_playgo_mobile_playgo_mobile_node_modules_babel_runtime_helpers_esm_classCallCheck_js__WEBPACK_IMPORTED_MODULE_0__["default"])(this, AppPluginMock);

    throw new Error('static mock');
  }

  (0,_Users_smartcommunitylab_Documents_work_projects_dslab_playgo_mobile_playgo_mobile_node_modules_babel_runtime_helpers_esm_createClass_js__WEBPACK_IMPORTED_MODULE_1__["default"])(AppPluginMock, null, [{
    key: "getInfo",
    value: function getInfo() {
      return (0,tslib__WEBPACK_IMPORTED_MODULE_3__.__awaiter)(this, void 0, void 0, /*#__PURE__*/_regeneratorRuntime().mark(function _callee() {
        return _regeneratorRuntime().wrap(function _callee$(_context) {
          while (1) {
            switch (_context.prev = _context.next) {
              case 0:
                return _context.abrupt("return", {
                  version: 'dev'
                });

              case 1:
              case "end":
                return _context.stop();
            }
          }
        }, _callee);
      }));
    }
  }]);

  return AppPluginMock;
}();

(0,tslib__WEBPACK_IMPORTED_MODULE_3__.__decorate)([mockMethod({
  async: true
})], AppPluginMock, "getInfo", null);

/***/ }),

/***/ 91157:
/*!***********************************************************************!*\
  !*** ./src/app/core/shared/plugin-mocks/BackgroundGeolocationMock.ts ***!
  \***********************************************************************/
/***/ (function(__unused_webpack_module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "BackgroundGeolocationMock": function() { return /* binding */ BackgroundGeolocationMock; }
/* harmony export */ });
/* harmony import */ var _Users_smartcommunitylab_Documents_work_projects_dslab_playgo_mobile_playgo_mobile_node_modules_babel_runtime_helpers_esm_toConsumableArray_js__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./node_modules/@babel/runtime/helpers/esm/toConsumableArray.js */ 58277);
/* harmony import */ var _Users_smartcommunitylab_Documents_work_projects_dslab_playgo_mobile_playgo_mobile_node_modules_babel_runtime_helpers_esm_classCallCheck_js__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ./node_modules/@babel/runtime/helpers/esm/classCallCheck.js */ 78069);
/* harmony import */ var _Users_smartcommunitylab_Documents_work_projects_dslab_playgo_mobile_playgo_mobile_node_modules_babel_runtime_helpers_esm_createClass_js__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! ./node_modules/@babel/runtime/helpers/esm/createClass.js */ 48047);
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! tslib */ 34929);
/* harmony import */ var lodash_es__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! lodash-es */ 10757);
/* harmony import */ var lodash_es__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! lodash-es */ 5482);
/* harmony import */ var lodash_es__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(/*! lodash-es */ 3680);
/* harmony import */ var _mock_utils__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! ./mock-utils */ 67650);




function _regeneratorRuntime() { "use strict"; /*! regenerator-runtime -- Copyright (c) 2014-present, Facebook, Inc. -- license (MIT): https://github.com/facebook/regenerator/blob/main/LICENSE */ _regeneratorRuntime = function _regeneratorRuntime() { return exports; }; var exports = {}, Op = Object.prototype, hasOwn = Op.hasOwnProperty, $Symbol = "function" == typeof Symbol ? Symbol : {}, iteratorSymbol = $Symbol.iterator || "@@iterator", asyncIteratorSymbol = $Symbol.asyncIterator || "@@asyncIterator", toStringTagSymbol = $Symbol.toStringTag || "@@toStringTag"; function define(obj, key, value) { return Object.defineProperty(obj, key, { value: value, enumerable: !0, configurable: !0, writable: !0 }), obj[key]; } try { define({}, ""); } catch (err) { define = function define(obj, key, value) { return obj[key] = value; }; } function wrap(innerFn, outerFn, self, tryLocsList) { var protoGenerator = outerFn && outerFn.prototype instanceof Generator ? outerFn : Generator, generator = Object.create(protoGenerator.prototype), context = new Context(tryLocsList || []); return generator._invoke = function (innerFn, self, context) { var state = "suspendedStart"; return function (method, arg) { if ("executing" === state) throw new Error("Generator is already running"); if ("completed" === state) { if ("throw" === method) throw arg; return doneResult(); } for (context.method = method, context.arg = arg;;) { var delegate = context.delegate; if (delegate) { var delegateResult = maybeInvokeDelegate(delegate, context); if (delegateResult) { if (delegateResult === ContinueSentinel) continue; return delegateResult; } } if ("next" === context.method) context.sent = context._sent = context.arg;else if ("throw" === context.method) { if ("suspendedStart" === state) throw state = "completed", context.arg; context.dispatchException(context.arg); } else "return" === context.method && context.abrupt("return", context.arg); state = "executing"; var record = tryCatch(innerFn, self, context); if ("normal" === record.type) { if (state = context.done ? "completed" : "suspendedYield", record.arg === ContinueSentinel) continue; return { value: record.arg, done: context.done }; } "throw" === record.type && (state = "completed", context.method = "throw", context.arg = record.arg); } }; }(innerFn, self, context), generator; } function tryCatch(fn, obj, arg) { try { return { type: "normal", arg: fn.call(obj, arg) }; } catch (err) { return { type: "throw", arg: err }; } } exports.wrap = wrap; var ContinueSentinel = {}; function Generator() {} function GeneratorFunction() {} function GeneratorFunctionPrototype() {} var IteratorPrototype = {}; define(IteratorPrototype, iteratorSymbol, function () { return this; }); var getProto = Object.getPrototypeOf, NativeIteratorPrototype = getProto && getProto(getProto(values([]))); NativeIteratorPrototype && NativeIteratorPrototype !== Op && hasOwn.call(NativeIteratorPrototype, iteratorSymbol) && (IteratorPrototype = NativeIteratorPrototype); var Gp = GeneratorFunctionPrototype.prototype = Generator.prototype = Object.create(IteratorPrototype); function defineIteratorMethods(prototype) { ["next", "throw", "return"].forEach(function (method) { define(prototype, method, function (arg) { return this._invoke(method, arg); }); }); } function AsyncIterator(generator, PromiseImpl) { function invoke(method, arg, resolve, reject) { var record = tryCatch(generator[method], generator, arg); if ("throw" !== record.type) { var result = record.arg, value = result.value; return value && "object" == typeof value && hasOwn.call(value, "__await") ? PromiseImpl.resolve(value.__await).then(function (value) { invoke("next", value, resolve, reject); }, function (err) { invoke("throw", err, resolve, reject); }) : PromiseImpl.resolve(value).then(function (unwrapped) { result.value = unwrapped, resolve(result); }, function (error) { return invoke("throw", error, resolve, reject); }); } reject(record.arg); } var previousPromise; this._invoke = function (method, arg) { function callInvokeWithMethodAndArg() { return new PromiseImpl(function (resolve, reject) { invoke(method, arg, resolve, reject); }); } return previousPromise = previousPromise ? previousPromise.then(callInvokeWithMethodAndArg, callInvokeWithMethodAndArg) : callInvokeWithMethodAndArg(); }; } function maybeInvokeDelegate(delegate, context) { var method = delegate.iterator[context.method]; if (undefined === method) { if (context.delegate = null, "throw" === context.method) { if (delegate.iterator.return && (context.method = "return", context.arg = undefined, maybeInvokeDelegate(delegate, context), "throw" === context.method)) return ContinueSentinel; context.method = "throw", context.arg = new TypeError("The iterator does not provide a 'throw' method"); } return ContinueSentinel; } var record = tryCatch(method, delegate.iterator, context.arg); if ("throw" === record.type) return context.method = "throw", context.arg = record.arg, context.delegate = null, ContinueSentinel; var info = record.arg; return info ? info.done ? (context[delegate.resultName] = info.value, context.next = delegate.nextLoc, "return" !== context.method && (context.method = "next", context.arg = undefined), context.delegate = null, ContinueSentinel) : info : (context.method = "throw", context.arg = new TypeError("iterator result is not an object"), context.delegate = null, ContinueSentinel); } function pushTryEntry(locs) { var entry = { tryLoc: locs[0] }; 1 in locs && (entry.catchLoc = locs[1]), 2 in locs && (entry.finallyLoc = locs[2], entry.afterLoc = locs[3]), this.tryEntries.push(entry); } function resetTryEntry(entry) { var record = entry.completion || {}; record.type = "normal", delete record.arg, entry.completion = record; } function Context(tryLocsList) { this.tryEntries = [{ tryLoc: "root" }], tryLocsList.forEach(pushTryEntry, this), this.reset(!0); } function values(iterable) { if (iterable) { var iteratorMethod = iterable[iteratorSymbol]; if (iteratorMethod) return iteratorMethod.call(iterable); if ("function" == typeof iterable.next) return iterable; if (!isNaN(iterable.length)) { var i = -1, next = function next() { for (; ++i < iterable.length;) { if (hasOwn.call(iterable, i)) return next.value = iterable[i], next.done = !1, next; } return next.value = undefined, next.done = !0, next; }; return next.next = next; } } return { next: doneResult }; } function doneResult() { return { value: undefined, done: !0 }; } return GeneratorFunction.prototype = GeneratorFunctionPrototype, define(Gp, "constructor", GeneratorFunctionPrototype), define(GeneratorFunctionPrototype, "constructor", GeneratorFunction), GeneratorFunction.displayName = define(GeneratorFunctionPrototype, toStringTagSymbol, "GeneratorFunction"), exports.isGeneratorFunction = function (genFun) { var ctor = "function" == typeof genFun && genFun.constructor; return !!ctor && (ctor === GeneratorFunction || "GeneratorFunction" === (ctor.displayName || ctor.name)); }, exports.mark = function (genFun) { return Object.setPrototypeOf ? Object.setPrototypeOf(genFun, GeneratorFunctionPrototype) : (genFun.__proto__ = GeneratorFunctionPrototype, define(genFun, toStringTagSymbol, "GeneratorFunction")), genFun.prototype = Object.create(Gp), genFun; }, exports.awrap = function (arg) { return { __await: arg }; }, defineIteratorMethods(AsyncIterator.prototype), define(AsyncIterator.prototype, asyncIteratorSymbol, function () { return this; }), exports.AsyncIterator = AsyncIterator, exports.async = function (innerFn, outerFn, self, tryLocsList, PromiseImpl) { void 0 === PromiseImpl && (PromiseImpl = Promise); var iter = new AsyncIterator(wrap(innerFn, outerFn, self, tryLocsList), PromiseImpl); return exports.isGeneratorFunction(outerFn) ? iter : iter.next().then(function (result) { return result.done ? result.value : iter.next(); }); }, defineIteratorMethods(Gp), define(Gp, toStringTagSymbol, "Generator"), define(Gp, iteratorSymbol, function () { return this; }), define(Gp, "toString", function () { return "[object Generator]"; }), exports.keys = function (object) { var keys = []; for (var key in object) { keys.push(key); } return keys.reverse(), function next() { for (; keys.length;) { var key = keys.pop(); if (key in object) return next.value = key, next.done = !1, next; } return next.done = !0, next; }; }, exports.values = values, Context.prototype = { constructor: Context, reset: function reset(skipTempReset) { if (this.prev = 0, this.next = 0, this.sent = this._sent = undefined, this.done = !1, this.delegate = null, this.method = "next", this.arg = undefined, this.tryEntries.forEach(resetTryEntry), !skipTempReset) for (var name in this) { "t" === name.charAt(0) && hasOwn.call(this, name) && !isNaN(+name.slice(1)) && (this[name] = undefined); } }, stop: function stop() { this.done = !0; var rootRecord = this.tryEntries[0].completion; if ("throw" === rootRecord.type) throw rootRecord.arg; return this.rval; }, dispatchException: function dispatchException(exception) { if (this.done) throw exception; var context = this; function handle(loc, caught) { return record.type = "throw", record.arg = exception, context.next = loc, caught && (context.method = "next", context.arg = undefined), !!caught; } for (var i = this.tryEntries.length - 1; i >= 0; --i) { var entry = this.tryEntries[i], record = entry.completion; if ("root" === entry.tryLoc) return handle("end"); if (entry.tryLoc <= this.prev) { var hasCatch = hasOwn.call(entry, "catchLoc"), hasFinally = hasOwn.call(entry, "finallyLoc"); if (hasCatch && hasFinally) { if (this.prev < entry.catchLoc) return handle(entry.catchLoc, !0); if (this.prev < entry.finallyLoc) return handle(entry.finallyLoc); } else if (hasCatch) { if (this.prev < entry.catchLoc) return handle(entry.catchLoc, !0); } else { if (!hasFinally) throw new Error("try statement without catch or finally"); if (this.prev < entry.finallyLoc) return handle(entry.finallyLoc); } } } }, abrupt: function abrupt(type, arg) { for (var i = this.tryEntries.length - 1; i >= 0; --i) { var entry = this.tryEntries[i]; if (entry.tryLoc <= this.prev && hasOwn.call(entry, "finallyLoc") && this.prev < entry.finallyLoc) { var finallyEntry = entry; break; } } finallyEntry && ("break" === type || "continue" === type) && finallyEntry.tryLoc <= arg && arg <= finallyEntry.finallyLoc && (finallyEntry = null); var record = finallyEntry ? finallyEntry.completion : {}; return record.type = type, record.arg = arg, finallyEntry ? (this.method = "next", this.next = finallyEntry.finallyLoc, ContinueSentinel) : this.complete(record); }, complete: function complete(record, afterLoc) { if ("throw" === record.type) throw record.arg; return "break" === record.type || "continue" === record.type ? this.next = record.arg : "return" === record.type ? (this.rval = this.arg = record.arg, this.method = "return", this.next = "end") : "normal" === record.type && afterLoc && (this.next = afterLoc), ContinueSentinel; }, finish: function finish(finallyLoc) { for (var i = this.tryEntries.length - 1; i >= 0; --i) { var entry = this.tryEntries[i]; if (entry.finallyLoc === finallyLoc) return this.complete(entry.completion, entry.afterLoc), resetTryEntry(entry), ContinueSentinel; } }, catch: function _catch(tryLoc) { for (var i = this.tryEntries.length - 1; i >= 0; --i) { var entry = this.tryEntries[i]; if (entry.tryLoc === tryLoc) { var record = entry.completion; if ("throw" === record.type) { var thrown = record.arg; resetTryEntry(entry); } return thrown; } } throw new Error("illegal catch attempt"); }, delegateYield: function delegateYield(iterable, resultName, nextLoc) { return this.delegate = { iterator: values(iterable), resultName: resultName, nextLoc: nextLoc }, "next" === this.method && (this.arg = undefined), ContinueSentinel; } }, exports; }




var mockMethod = (0,_mock_utils__WEBPACK_IMPORTED_MODULE_3__.getMockMethodAnnotation)({
  doLog: false,
  logPrefix: 'BackgroundGeolocationMock'
});
var BackgroundGeolocationMock = /*#__PURE__*/function () {
  function BackgroundGeolocationMock() {
    (0,_Users_smartcommunitylab_Documents_work_projects_dslab_playgo_mobile_playgo_mobile_node_modules_babel_runtime_helpers_esm_classCallCheck_js__WEBPACK_IMPORTED_MODULE_1__["default"])(this, BackgroundGeolocationMock);

    throw new Error('static mock');
  }

  (0,_Users_smartcommunitylab_Documents_work_projects_dslab_playgo_mobile_playgo_mobile_node_modules_babel_runtime_helpers_esm_createClass_js__WEBPACK_IMPORTED_MODULE_2__["default"])(BackgroundGeolocationMock, null, [{
    key: "findOrCreateTransistorAuthorizationToken",
    value: function findOrCreateTransistorAuthorizationToken() {
      return 'TOKEN_MOCK';
    }
  }, {
    key: "ready",
    value: function ready(config) {
      return (0,tslib__WEBPACK_IMPORTED_MODULE_4__.__awaiter)(this, void 0, void 0, /*#__PURE__*/_regeneratorRuntime().mark(function _callee() {
        return _regeneratorRuntime().wrap(function _callee$(_context) {
          while (1) {
            switch (_context.prev = _context.next) {
              case 0:
                return _context.abrupt("return", {
                  enabled: true
                });

              case 1:
              case "end":
                return _context.stop();
            }
          }
        }, _callee);
      }));
    }
  }, {
    key: "setConfig",
    value: function setConfig(config) {
      return (0,tslib__WEBPACK_IMPORTED_MODULE_4__.__awaiter)(this, void 0, void 0, /*#__PURE__*/_regeneratorRuntime().mark(function _callee2() {
        return _regeneratorRuntime().wrap(function _callee2$(_context2) {
          while (1) {
            switch (_context2.prev = _context2.next) {
              case 0:
                BackgroundGeolocationMock.config = config;

              case 1:
              case "end":
                return _context2.stop();
            }
          }
        }, _callee2);
      }));
    }
  }, {
    key: "getCurrentPosition",
    value: function getCurrentPosition(request) {
      return (0,tslib__WEBPACK_IMPORTED_MODULE_4__.__awaiter)(this, void 0, void 0, /*#__PURE__*/_regeneratorRuntime().mark(function _callee3() {
        var location;
        return _regeneratorRuntime().wrap(function _callee3$(_context3) {
          while (1) {
            switch (_context3.prev = _context3.next) {
              case 0:
                location = BackgroundGeolocationMock.getRandomLocation(request.extras);

                if ((request === null || request === void 0 ? void 0 : request.persist) !== false) {
                  BackgroundGeolocationMock.locations.push(location);
                }

                return _context3.abrupt("return", location);

              case 3:
              case "end":
                return _context3.stop();
            }
          }
        }, _callee3);
      }));
    }
  }, {
    key: "start",
    value: function start() {
      return (0,tslib__WEBPACK_IMPORTED_MODULE_4__.__awaiter)(this, void 0, void 0, /*#__PURE__*/_regeneratorRuntime().mark(function _callee4() {
        return _regeneratorRuntime().wrap(function _callee4$(_context4) {
          while (1) {
            switch (_context4.prev = _context4.next) {
              case 0:
                BackgroundGeolocationMock.isTracking = true;

              case 1:
              case "end":
                return _context4.stop();
            }
          }
        }, _callee4);
      }));
    }
  }, {
    key: "stop",
    value: function stop() {
      return (0,tslib__WEBPACK_IMPORTED_MODULE_4__.__awaiter)(this, void 0, void 0, /*#__PURE__*/_regeneratorRuntime().mark(function _callee5() {
        return _regeneratorRuntime().wrap(function _callee5$(_context5) {
          while (1) {
            switch (_context5.prev = _context5.next) {
              case 0:
                BackgroundGeolocationMock.isTracking = false;

              case 1:
              case "end":
                return _context5.stop();
            }
          }
        }, _callee5);
      }));
    }
  }, {
    key: "sync",
    value: function sync() {
      return (0,tslib__WEBPACK_IMPORTED_MODULE_4__.__awaiter)(this, void 0, void 0, /*#__PURE__*/_regeneratorRuntime().mark(function _callee6() {
        var locations;
        return _regeneratorRuntime().wrap(function _callee6$(_context6) {
          while (1) {
            switch (_context6.prev = _context6.next) {
              case 0:
                locations = BackgroundGeolocationMock.locations;
                BackgroundGeolocationMock.locations = [];
                return _context6.abrupt("return", locations);

              case 3:
              case "end":
                return _context6.stop();
            }
          }
        }, _callee6);
      }));
    }
  }, {
    key: "getLocations",
    value: function getLocations() {
      return (0,tslib__WEBPACK_IMPORTED_MODULE_4__.__awaiter)(this, void 0, void 0, /*#__PURE__*/_regeneratorRuntime().mark(function _callee7() {
        return _regeneratorRuntime().wrap(function _callee7$(_context7) {
          while (1) {
            switch (_context7.prev = _context7.next) {
              case 0:
                return _context7.abrupt("return", (0,_Users_smartcommunitylab_Documents_work_projects_dslab_playgo_mobile_playgo_mobile_node_modules_babel_runtime_helpers_esm_toConsumableArray_js__WEBPACK_IMPORTED_MODULE_0__["default"])(BackgroundGeolocationMock.locations));

              case 1:
              case "end":
                return _context7.stop();
            }
          }
        }, _callee7);
      }));
    }
  }, {
    key: "onLocation",
    value: function onLocation(handler) {
      BackgroundGeolocationMock.handlers.add(handler);
      return {
        remove: function remove() {
          BackgroundGeolocationMock.handlers.delete(handler);
          console.log('BackgroundGeolocationMock: onLocation subscription removed!');
        }
      };
    }
  }, {
    key: "onPowerSaveChange",
    value: function onPowerSaveChange(handler) {
      return {
        remove: function remove() {}
      };
    }
  }, {
    key: "isPowerSaveMode",
    value: function isPowerSaveMode() {
      return (0,tslib__WEBPACK_IMPORTED_MODULE_4__.__awaiter)(this, void 0, void 0, /*#__PURE__*/_regeneratorRuntime().mark(function _callee8() {
        return _regeneratorRuntime().wrap(function _callee8$(_context8) {
          while (1) {
            switch (_context8.prev = _context8.next) {
              case 0:
                return _context8.abrupt("return", false);

              case 1:
              case "end":
                return _context8.stop();
            }
          }
        }, _callee8);
      }));
    }
  }, {
    key: "getRandomLocation",
    value: function getRandomLocation() {
      var extras = arguments.length > 0 && arguments[0] !== undefined ? arguments[0] : {};

      var _a;

      var lastCoords = ((_a = (0,lodash_es__WEBPACK_IMPORTED_MODULE_5__["default"])(BackgroundGeolocationMock.locations)) === null || _a === void 0 ? void 0 : _a.coords) || {
        latitude: 46.06787,
        longitude: 11.12108
      };
      var newCoords = (0,lodash_es__WEBPACK_IMPORTED_MODULE_6__["default"])(lastCoords, function (coord) {
        return coord + (0,lodash_es__WEBPACK_IMPORTED_MODULE_7__["default"])(-0.001, 0.001);
      });
      return {
        coords: Object.assign(Object.assign({}, newCoords), {
          accuracy: 10 + Math.random() * 20
        }),
        timestamp: new Date().toISOString(),
        extras: Object.assign(Object.assign({}, BackgroundGeolocationMock.config.extras), extras)
      };
    }
  }, {
    key: "initMockTracking",
    value: function initMockTracking() {
      setInterval(function () {
        if (BackgroundGeolocationMock.isTracking) {
          var location = BackgroundGeolocationMock.getRandomLocation();
          BackgroundGeolocationMock.locations.push(location);
          BackgroundGeolocationMock.handlers.forEach(function (handler) {
            return handler(location);
          });
        }
      }, 5000);
    }
  }]);

  return BackgroundGeolocationMock;
}();
BackgroundGeolocationMock.locations = [];
BackgroundGeolocationMock.config = {
  extras: {}
};
BackgroundGeolocationMock.isTracking = false;
BackgroundGeolocationMock.handlers = new Set();

(function () {
  BackgroundGeolocationMock.initMockTracking();
})();

(0,tslib__WEBPACK_IMPORTED_MODULE_4__.__decorate)([mockMethod()], BackgroundGeolocationMock, "findOrCreateTransistorAuthorizationToken", null);

(0,tslib__WEBPACK_IMPORTED_MODULE_4__.__decorate)([mockMethod({
  async: true
})], BackgroundGeolocationMock, "ready", null);

(0,tslib__WEBPACK_IMPORTED_MODULE_4__.__decorate)([mockMethod({
  async: true
})], BackgroundGeolocationMock, "setConfig", null);

(0,tslib__WEBPACK_IMPORTED_MODULE_4__.__decorate)([mockMethod({
  async: true,
  wait: 1000
})], BackgroundGeolocationMock, "getCurrentPosition", null);

(0,tslib__WEBPACK_IMPORTED_MODULE_4__.__decorate)([mockMethod({
  async: true
})], BackgroundGeolocationMock, "start", null);

(0,tslib__WEBPACK_IMPORTED_MODULE_4__.__decorate)([mockMethod({
  async: true
})], BackgroundGeolocationMock, "stop", null);

(0,tslib__WEBPACK_IMPORTED_MODULE_4__.__decorate)([mockMethod({
  async: true
})], BackgroundGeolocationMock, "sync", null);

(0,tslib__WEBPACK_IMPORTED_MODULE_4__.__decorate)([mockMethod({
  async: true
})], BackgroundGeolocationMock, "getLocations", null);

(0,tslib__WEBPACK_IMPORTED_MODULE_4__.__decorate)([mockMethod()], BackgroundGeolocationMock, "onLocation", null);

(0,tslib__WEBPACK_IMPORTED_MODULE_4__.__decorate)([mockMethod()], BackgroundGeolocationMock, "onPowerSaveChange", null);

(0,tslib__WEBPACK_IMPORTED_MODULE_4__.__decorate)([mockMethod({
  async: true
})], BackgroundGeolocationMock, "isPowerSaveMode", null);

/***/ }),

/***/ 87833:
/*!****************************************************************!*\
  !*** ./src/app/core/shared/plugin-mocks/CodePushPluginMock.ts ***!
  \****************************************************************/
/***/ (function(__unused_webpack_module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "CodePushPluginMock": function() { return /* binding */ CodePushPluginMock; }
/* harmony export */ });
/* harmony import */ var _Users_smartcommunitylab_Documents_work_projects_dslab_playgo_mobile_playgo_mobile_node_modules_babel_runtime_helpers_esm_classCallCheck_js__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./node_modules/@babel/runtime/helpers/esm/classCallCheck.js */ 78069);
/* harmony import */ var _Users_smartcommunitylab_Documents_work_projects_dslab_playgo_mobile_playgo_mobile_node_modules_babel_runtime_helpers_esm_createClass_js__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ./node_modules/@babel/runtime/helpers/esm/createClass.js */ 48047);
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! tslib */ 34929);
/* harmony import */ var _mock_utils__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! ./mock-utils */ 67650);



function _regeneratorRuntime() { "use strict"; /*! regenerator-runtime -- Copyright (c) 2014-present, Facebook, Inc. -- license (MIT): https://github.com/facebook/regenerator/blob/main/LICENSE */ _regeneratorRuntime = function _regeneratorRuntime() { return exports; }; var exports = {}, Op = Object.prototype, hasOwn = Op.hasOwnProperty, $Symbol = "function" == typeof Symbol ? Symbol : {}, iteratorSymbol = $Symbol.iterator || "@@iterator", asyncIteratorSymbol = $Symbol.asyncIterator || "@@asyncIterator", toStringTagSymbol = $Symbol.toStringTag || "@@toStringTag"; function define(obj, key, value) { return Object.defineProperty(obj, key, { value: value, enumerable: !0, configurable: !0, writable: !0 }), obj[key]; } try { define({}, ""); } catch (err) { define = function define(obj, key, value) { return obj[key] = value; }; } function wrap(innerFn, outerFn, self, tryLocsList) { var protoGenerator = outerFn && outerFn.prototype instanceof Generator ? outerFn : Generator, generator = Object.create(protoGenerator.prototype), context = new Context(tryLocsList || []); return generator._invoke = function (innerFn, self, context) { var state = "suspendedStart"; return function (method, arg) { if ("executing" === state) throw new Error("Generator is already running"); if ("completed" === state) { if ("throw" === method) throw arg; return doneResult(); } for (context.method = method, context.arg = arg;;) { var delegate = context.delegate; if (delegate) { var delegateResult = maybeInvokeDelegate(delegate, context); if (delegateResult) { if (delegateResult === ContinueSentinel) continue; return delegateResult; } } if ("next" === context.method) context.sent = context._sent = context.arg;else if ("throw" === context.method) { if ("suspendedStart" === state) throw state = "completed", context.arg; context.dispatchException(context.arg); } else "return" === context.method && context.abrupt("return", context.arg); state = "executing"; var record = tryCatch(innerFn, self, context); if ("normal" === record.type) { if (state = context.done ? "completed" : "suspendedYield", record.arg === ContinueSentinel) continue; return { value: record.arg, done: context.done }; } "throw" === record.type && (state = "completed", context.method = "throw", context.arg = record.arg); } }; }(innerFn, self, context), generator; } function tryCatch(fn, obj, arg) { try { return { type: "normal", arg: fn.call(obj, arg) }; } catch (err) { return { type: "throw", arg: err }; } } exports.wrap = wrap; var ContinueSentinel = {}; function Generator() {} function GeneratorFunction() {} function GeneratorFunctionPrototype() {} var IteratorPrototype = {}; define(IteratorPrototype, iteratorSymbol, function () { return this; }); var getProto = Object.getPrototypeOf, NativeIteratorPrototype = getProto && getProto(getProto(values([]))); NativeIteratorPrototype && NativeIteratorPrototype !== Op && hasOwn.call(NativeIteratorPrototype, iteratorSymbol) && (IteratorPrototype = NativeIteratorPrototype); var Gp = GeneratorFunctionPrototype.prototype = Generator.prototype = Object.create(IteratorPrototype); function defineIteratorMethods(prototype) { ["next", "throw", "return"].forEach(function (method) { define(prototype, method, function (arg) { return this._invoke(method, arg); }); }); } function AsyncIterator(generator, PromiseImpl) { function invoke(method, arg, resolve, reject) { var record = tryCatch(generator[method], generator, arg); if ("throw" !== record.type) { var result = record.arg, value = result.value; return value && "object" == typeof value && hasOwn.call(value, "__await") ? PromiseImpl.resolve(value.__await).then(function (value) { invoke("next", value, resolve, reject); }, function (err) { invoke("throw", err, resolve, reject); }) : PromiseImpl.resolve(value).then(function (unwrapped) { result.value = unwrapped, resolve(result); }, function (error) { return invoke("throw", error, resolve, reject); }); } reject(record.arg); } var previousPromise; this._invoke = function (method, arg) { function callInvokeWithMethodAndArg() { return new PromiseImpl(function (resolve, reject) { invoke(method, arg, resolve, reject); }); } return previousPromise = previousPromise ? previousPromise.then(callInvokeWithMethodAndArg, callInvokeWithMethodAndArg) : callInvokeWithMethodAndArg(); }; } function maybeInvokeDelegate(delegate, context) { var method = delegate.iterator[context.method]; if (undefined === method) { if (context.delegate = null, "throw" === context.method) { if (delegate.iterator.return && (context.method = "return", context.arg = undefined, maybeInvokeDelegate(delegate, context), "throw" === context.method)) return ContinueSentinel; context.method = "throw", context.arg = new TypeError("The iterator does not provide a 'throw' method"); } return ContinueSentinel; } var record = tryCatch(method, delegate.iterator, context.arg); if ("throw" === record.type) return context.method = "throw", context.arg = record.arg, context.delegate = null, ContinueSentinel; var info = record.arg; return info ? info.done ? (context[delegate.resultName] = info.value, context.next = delegate.nextLoc, "return" !== context.method && (context.method = "next", context.arg = undefined), context.delegate = null, ContinueSentinel) : info : (context.method = "throw", context.arg = new TypeError("iterator result is not an object"), context.delegate = null, ContinueSentinel); } function pushTryEntry(locs) { var entry = { tryLoc: locs[0] }; 1 in locs && (entry.catchLoc = locs[1]), 2 in locs && (entry.finallyLoc = locs[2], entry.afterLoc = locs[3]), this.tryEntries.push(entry); } function resetTryEntry(entry) { var record = entry.completion || {}; record.type = "normal", delete record.arg, entry.completion = record; } function Context(tryLocsList) { this.tryEntries = [{ tryLoc: "root" }], tryLocsList.forEach(pushTryEntry, this), this.reset(!0); } function values(iterable) { if (iterable) { var iteratorMethod = iterable[iteratorSymbol]; if (iteratorMethod) return iteratorMethod.call(iterable); if ("function" == typeof iterable.next) return iterable; if (!isNaN(iterable.length)) { var i = -1, next = function next() { for (; ++i < iterable.length;) { if (hasOwn.call(iterable, i)) return next.value = iterable[i], next.done = !1, next; } return next.value = undefined, next.done = !0, next; }; return next.next = next; } } return { next: doneResult }; } function doneResult() { return { value: undefined, done: !0 }; } return GeneratorFunction.prototype = GeneratorFunctionPrototype, define(Gp, "constructor", GeneratorFunctionPrototype), define(GeneratorFunctionPrototype, "constructor", GeneratorFunction), GeneratorFunction.displayName = define(GeneratorFunctionPrototype, toStringTagSymbol, "GeneratorFunction"), exports.isGeneratorFunction = function (genFun) { var ctor = "function" == typeof genFun && genFun.constructor; return !!ctor && (ctor === GeneratorFunction || "GeneratorFunction" === (ctor.displayName || ctor.name)); }, exports.mark = function (genFun) { return Object.setPrototypeOf ? Object.setPrototypeOf(genFun, GeneratorFunctionPrototype) : (genFun.__proto__ = GeneratorFunctionPrototype, define(genFun, toStringTagSymbol, "GeneratorFunction")), genFun.prototype = Object.create(Gp), genFun; }, exports.awrap = function (arg) { return { __await: arg }; }, defineIteratorMethods(AsyncIterator.prototype), define(AsyncIterator.prototype, asyncIteratorSymbol, function () { return this; }), exports.AsyncIterator = AsyncIterator, exports.async = function (innerFn, outerFn, self, tryLocsList, PromiseImpl) { void 0 === PromiseImpl && (PromiseImpl = Promise); var iter = new AsyncIterator(wrap(innerFn, outerFn, self, tryLocsList), PromiseImpl); return exports.isGeneratorFunction(outerFn) ? iter : iter.next().then(function (result) { return result.done ? result.value : iter.next(); }); }, defineIteratorMethods(Gp), define(Gp, toStringTagSymbol, "Generator"), define(Gp, iteratorSymbol, function () { return this; }), define(Gp, "toString", function () { return "[object Generator]"; }), exports.keys = function (object) { var keys = []; for (var key in object) { keys.push(key); } return keys.reverse(), function next() { for (; keys.length;) { var key = keys.pop(); if (key in object) return next.value = key, next.done = !1, next; } return next.done = !0, next; }; }, exports.values = values, Context.prototype = { constructor: Context, reset: function reset(skipTempReset) { if (this.prev = 0, this.next = 0, this.sent = this._sent = undefined, this.done = !1, this.delegate = null, this.method = "next", this.arg = undefined, this.tryEntries.forEach(resetTryEntry), !skipTempReset) for (var name in this) { "t" === name.charAt(0) && hasOwn.call(this, name) && !isNaN(+name.slice(1)) && (this[name] = undefined); } }, stop: function stop() { this.done = !0; var rootRecord = this.tryEntries[0].completion; if ("throw" === rootRecord.type) throw rootRecord.arg; return this.rval; }, dispatchException: function dispatchException(exception) { if (this.done) throw exception; var context = this; function handle(loc, caught) { return record.type = "throw", record.arg = exception, context.next = loc, caught && (context.method = "next", context.arg = undefined), !!caught; } for (var i = this.tryEntries.length - 1; i >= 0; --i) { var entry = this.tryEntries[i], record = entry.completion; if ("root" === entry.tryLoc) return handle("end"); if (entry.tryLoc <= this.prev) { var hasCatch = hasOwn.call(entry, "catchLoc"), hasFinally = hasOwn.call(entry, "finallyLoc"); if (hasCatch && hasFinally) { if (this.prev < entry.catchLoc) return handle(entry.catchLoc, !0); if (this.prev < entry.finallyLoc) return handle(entry.finallyLoc); } else if (hasCatch) { if (this.prev < entry.catchLoc) return handle(entry.catchLoc, !0); } else { if (!hasFinally) throw new Error("try statement without catch or finally"); if (this.prev < entry.finallyLoc) return handle(entry.finallyLoc); } } } }, abrupt: function abrupt(type, arg) { for (var i = this.tryEntries.length - 1; i >= 0; --i) { var entry = this.tryEntries[i]; if (entry.tryLoc <= this.prev && hasOwn.call(entry, "finallyLoc") && this.prev < entry.finallyLoc) { var finallyEntry = entry; break; } } finallyEntry && ("break" === type || "continue" === type) && finallyEntry.tryLoc <= arg && arg <= finallyEntry.finallyLoc && (finallyEntry = null); var record = finallyEntry ? finallyEntry.completion : {}; return record.type = type, record.arg = arg, finallyEntry ? (this.method = "next", this.next = finallyEntry.finallyLoc, ContinueSentinel) : this.complete(record); }, complete: function complete(record, afterLoc) { if ("throw" === record.type) throw record.arg; return "break" === record.type || "continue" === record.type ? this.next = record.arg : "return" === record.type ? (this.rval = this.arg = record.arg, this.method = "return", this.next = "end") : "normal" === record.type && afterLoc && (this.next = afterLoc), ContinueSentinel; }, finish: function finish(finallyLoc) { for (var i = this.tryEntries.length - 1; i >= 0; --i) { var entry = this.tryEntries[i]; if (entry.finallyLoc === finallyLoc) return this.complete(entry.completion, entry.afterLoc), resetTryEntry(entry), ContinueSentinel; } }, catch: function _catch(tryLoc) { for (var i = this.tryEntries.length - 1; i >= 0; --i) { var entry = this.tryEntries[i]; if (entry.tryLoc === tryLoc) { var record = entry.completion; if ("throw" === record.type) { var thrown = record.arg; resetTryEntry(entry); } return thrown; } } throw new Error("illegal catch attempt"); }, delegateYield: function delegateYield(iterable, resultName, nextLoc) { return this.delegate = { iterator: values(iterable), resultName: resultName, nextLoc: nextLoc }, "next" === this.method && (this.arg = undefined), ContinueSentinel; } }, exports; }



var mockMethod = (0,_mock_utils__WEBPACK_IMPORTED_MODULE_2__.getMockMethodAnnotation)({
  doLog: false,
  logPrefix: 'CodePushPluginMock'
});
var CodePushPluginMock = /*#__PURE__*/function () {
  function CodePushPluginMock() {
    (0,_Users_smartcommunitylab_Documents_work_projects_dslab_playgo_mobile_playgo_mobile_node_modules_babel_runtime_helpers_esm_classCallCheck_js__WEBPACK_IMPORTED_MODULE_0__["default"])(this, CodePushPluginMock);

    throw new Error('static mock');
  }

  (0,_Users_smartcommunitylab_Documents_work_projects_dslab_playgo_mobile_playgo_mobile_node_modules_babel_runtime_helpers_esm_createClass_js__WEBPACK_IMPORTED_MODULE_1__["default"])(CodePushPluginMock, null, [{
    key: "sync",
    value: function sync(config) {
      return (0,tslib__WEBPACK_IMPORTED_MODULE_3__.__awaiter)(this, void 0, void 0, /*#__PURE__*/_regeneratorRuntime().mark(function _callee() {
        return _regeneratorRuntime().wrap(function _callee$(_context) {
          while (1) {
            switch (_context.prev = _context.next) {
              case 0:
                return _context.abrupt("return", 'sync_mocked');

              case 1:
              case "end":
                return _context.stop();
            }
          }
        }, _callee);
      }));
    }
  }, {
    key: "getCurrentPackage",
    value: function getCurrentPackage() {
      return (0,tslib__WEBPACK_IMPORTED_MODULE_3__.__awaiter)(this, void 0, void 0, /*#__PURE__*/_regeneratorRuntime().mark(function _callee2() {
        return _regeneratorRuntime().wrap(function _callee2$(_context2) {
          while (1) {
            switch (_context2.prev = _context2.next) {
              case 0:
                return _context2.abrupt("return", {
                  label: '-'
                });

              case 1:
              case "end":
                return _context2.stop();
            }
          }
        }, _callee2);
      }));
    }
  }, {
    key: "getPendingPackage",
    value: function getPendingPackage() {
      return (0,tslib__WEBPACK_IMPORTED_MODULE_3__.__awaiter)(this, void 0, void 0, /*#__PURE__*/_regeneratorRuntime().mark(function _callee3() {
        return _regeneratorRuntime().wrap(function _callee3$(_context3) {
          while (1) {
            switch (_context3.prev = _context3.next) {
              case 0:
                return _context3.abrupt("return", null);

              case 1:
              case "end":
                return _context3.stop();
            }
          }
        }, _callee3);
      }));
    }
  }]);

  return CodePushPluginMock;
}();

(0,tslib__WEBPACK_IMPORTED_MODULE_3__.__decorate)([mockMethod({
  async: true
})], CodePushPluginMock, "sync", null);

(0,tslib__WEBPACK_IMPORTED_MODULE_3__.__decorate)([mockMethod({
  async: true
})], CodePushPluginMock, "getCurrentPackage", null);

(0,tslib__WEBPACK_IMPORTED_MODULE_3__.__decorate)([mockMethod({
  async: true
})], CodePushPluginMock, "getPendingPackage", null);

/***/ }),

/***/ 45536:
/*!**************************************************************!*\
  !*** ./src/app/core/shared/plugin-mocks/DevicePluginMock.ts ***!
  \**************************************************************/
/***/ (function(__unused_webpack_module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "DevicePluginMock": function() { return /* binding */ DevicePluginMock; }
/* harmony export */ });
/* harmony import */ var _Users_smartcommunitylab_Documents_work_projects_dslab_playgo_mobile_playgo_mobile_node_modules_babel_runtime_helpers_esm_classCallCheck_js__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./node_modules/@babel/runtime/helpers/esm/classCallCheck.js */ 78069);
/* harmony import */ var _Users_smartcommunitylab_Documents_work_projects_dslab_playgo_mobile_playgo_mobile_node_modules_babel_runtime_helpers_esm_createClass_js__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ./node_modules/@babel/runtime/helpers/esm/createClass.js */ 48047);
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! tslib */ 34929);
/* harmony import */ var _mock_utils__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! ./mock-utils */ 67650);



function _regeneratorRuntime() { "use strict"; /*! regenerator-runtime -- Copyright (c) 2014-present, Facebook, Inc. -- license (MIT): https://github.com/facebook/regenerator/blob/main/LICENSE */ _regeneratorRuntime = function _regeneratorRuntime() { return exports; }; var exports = {}, Op = Object.prototype, hasOwn = Op.hasOwnProperty, $Symbol = "function" == typeof Symbol ? Symbol : {}, iteratorSymbol = $Symbol.iterator || "@@iterator", asyncIteratorSymbol = $Symbol.asyncIterator || "@@asyncIterator", toStringTagSymbol = $Symbol.toStringTag || "@@toStringTag"; function define(obj, key, value) { return Object.defineProperty(obj, key, { value: value, enumerable: !0, configurable: !0, writable: !0 }), obj[key]; } try { define({}, ""); } catch (err) { define = function define(obj, key, value) { return obj[key] = value; }; } function wrap(innerFn, outerFn, self, tryLocsList) { var protoGenerator = outerFn && outerFn.prototype instanceof Generator ? outerFn : Generator, generator = Object.create(protoGenerator.prototype), context = new Context(tryLocsList || []); return generator._invoke = function (innerFn, self, context) { var state = "suspendedStart"; return function (method, arg) { if ("executing" === state) throw new Error("Generator is already running"); if ("completed" === state) { if ("throw" === method) throw arg; return doneResult(); } for (context.method = method, context.arg = arg;;) { var delegate = context.delegate; if (delegate) { var delegateResult = maybeInvokeDelegate(delegate, context); if (delegateResult) { if (delegateResult === ContinueSentinel) continue; return delegateResult; } } if ("next" === context.method) context.sent = context._sent = context.arg;else if ("throw" === context.method) { if ("suspendedStart" === state) throw state = "completed", context.arg; context.dispatchException(context.arg); } else "return" === context.method && context.abrupt("return", context.arg); state = "executing"; var record = tryCatch(innerFn, self, context); if ("normal" === record.type) { if (state = context.done ? "completed" : "suspendedYield", record.arg === ContinueSentinel) continue; return { value: record.arg, done: context.done }; } "throw" === record.type && (state = "completed", context.method = "throw", context.arg = record.arg); } }; }(innerFn, self, context), generator; } function tryCatch(fn, obj, arg) { try { return { type: "normal", arg: fn.call(obj, arg) }; } catch (err) { return { type: "throw", arg: err }; } } exports.wrap = wrap; var ContinueSentinel = {}; function Generator() {} function GeneratorFunction() {} function GeneratorFunctionPrototype() {} var IteratorPrototype = {}; define(IteratorPrototype, iteratorSymbol, function () { return this; }); var getProto = Object.getPrototypeOf, NativeIteratorPrototype = getProto && getProto(getProto(values([]))); NativeIteratorPrototype && NativeIteratorPrototype !== Op && hasOwn.call(NativeIteratorPrototype, iteratorSymbol) && (IteratorPrototype = NativeIteratorPrototype); var Gp = GeneratorFunctionPrototype.prototype = Generator.prototype = Object.create(IteratorPrototype); function defineIteratorMethods(prototype) { ["next", "throw", "return"].forEach(function (method) { define(prototype, method, function (arg) { return this._invoke(method, arg); }); }); } function AsyncIterator(generator, PromiseImpl) { function invoke(method, arg, resolve, reject) { var record = tryCatch(generator[method], generator, arg); if ("throw" !== record.type) { var result = record.arg, value = result.value; return value && "object" == typeof value && hasOwn.call(value, "__await") ? PromiseImpl.resolve(value.__await).then(function (value) { invoke("next", value, resolve, reject); }, function (err) { invoke("throw", err, resolve, reject); }) : PromiseImpl.resolve(value).then(function (unwrapped) { result.value = unwrapped, resolve(result); }, function (error) { return invoke("throw", error, resolve, reject); }); } reject(record.arg); } var previousPromise; this._invoke = function (method, arg) { function callInvokeWithMethodAndArg() { return new PromiseImpl(function (resolve, reject) { invoke(method, arg, resolve, reject); }); } return previousPromise = previousPromise ? previousPromise.then(callInvokeWithMethodAndArg, callInvokeWithMethodAndArg) : callInvokeWithMethodAndArg(); }; } function maybeInvokeDelegate(delegate, context) { var method = delegate.iterator[context.method]; if (undefined === method) { if (context.delegate = null, "throw" === context.method) { if (delegate.iterator.return && (context.method = "return", context.arg = undefined, maybeInvokeDelegate(delegate, context), "throw" === context.method)) return ContinueSentinel; context.method = "throw", context.arg = new TypeError("The iterator does not provide a 'throw' method"); } return ContinueSentinel; } var record = tryCatch(method, delegate.iterator, context.arg); if ("throw" === record.type) return context.method = "throw", context.arg = record.arg, context.delegate = null, ContinueSentinel; var info = record.arg; return info ? info.done ? (context[delegate.resultName] = info.value, context.next = delegate.nextLoc, "return" !== context.method && (context.method = "next", context.arg = undefined), context.delegate = null, ContinueSentinel) : info : (context.method = "throw", context.arg = new TypeError("iterator result is not an object"), context.delegate = null, ContinueSentinel); } function pushTryEntry(locs) { var entry = { tryLoc: locs[0] }; 1 in locs && (entry.catchLoc = locs[1]), 2 in locs && (entry.finallyLoc = locs[2], entry.afterLoc = locs[3]), this.tryEntries.push(entry); } function resetTryEntry(entry) { var record = entry.completion || {}; record.type = "normal", delete record.arg, entry.completion = record; } function Context(tryLocsList) { this.tryEntries = [{ tryLoc: "root" }], tryLocsList.forEach(pushTryEntry, this), this.reset(!0); } function values(iterable) { if (iterable) { var iteratorMethod = iterable[iteratorSymbol]; if (iteratorMethod) return iteratorMethod.call(iterable); if ("function" == typeof iterable.next) return iterable; if (!isNaN(iterable.length)) { var i = -1, next = function next() { for (; ++i < iterable.length;) { if (hasOwn.call(iterable, i)) return next.value = iterable[i], next.done = !1, next; } return next.value = undefined, next.done = !0, next; }; return next.next = next; } } return { next: doneResult }; } function doneResult() { return { value: undefined, done: !0 }; } return GeneratorFunction.prototype = GeneratorFunctionPrototype, define(Gp, "constructor", GeneratorFunctionPrototype), define(GeneratorFunctionPrototype, "constructor", GeneratorFunction), GeneratorFunction.displayName = define(GeneratorFunctionPrototype, toStringTagSymbol, "GeneratorFunction"), exports.isGeneratorFunction = function (genFun) { var ctor = "function" == typeof genFun && genFun.constructor; return !!ctor && (ctor === GeneratorFunction || "GeneratorFunction" === (ctor.displayName || ctor.name)); }, exports.mark = function (genFun) { return Object.setPrototypeOf ? Object.setPrototypeOf(genFun, GeneratorFunctionPrototype) : (genFun.__proto__ = GeneratorFunctionPrototype, define(genFun, toStringTagSymbol, "GeneratorFunction")), genFun.prototype = Object.create(Gp), genFun; }, exports.awrap = function (arg) { return { __await: arg }; }, defineIteratorMethods(AsyncIterator.prototype), define(AsyncIterator.prototype, asyncIteratorSymbol, function () { return this; }), exports.AsyncIterator = AsyncIterator, exports.async = function (innerFn, outerFn, self, tryLocsList, PromiseImpl) { void 0 === PromiseImpl && (PromiseImpl = Promise); var iter = new AsyncIterator(wrap(innerFn, outerFn, self, tryLocsList), PromiseImpl); return exports.isGeneratorFunction(outerFn) ? iter : iter.next().then(function (result) { return result.done ? result.value : iter.next(); }); }, defineIteratorMethods(Gp), define(Gp, toStringTagSymbol, "Generator"), define(Gp, iteratorSymbol, function () { return this; }), define(Gp, "toString", function () { return "[object Generator]"; }), exports.keys = function (object) { var keys = []; for (var key in object) { keys.push(key); } return keys.reverse(), function next() { for (; keys.length;) { var key = keys.pop(); if (key in object) return next.value = key, next.done = !1, next; } return next.done = !0, next; }; }, exports.values = values, Context.prototype = { constructor: Context, reset: function reset(skipTempReset) { if (this.prev = 0, this.next = 0, this.sent = this._sent = undefined, this.done = !1, this.delegate = null, this.method = "next", this.arg = undefined, this.tryEntries.forEach(resetTryEntry), !skipTempReset) for (var name in this) { "t" === name.charAt(0) && hasOwn.call(this, name) && !isNaN(+name.slice(1)) && (this[name] = undefined); } }, stop: function stop() { this.done = !0; var rootRecord = this.tryEntries[0].completion; if ("throw" === rootRecord.type) throw rootRecord.arg; return this.rval; }, dispatchException: function dispatchException(exception) { if (this.done) throw exception; var context = this; function handle(loc, caught) { return record.type = "throw", record.arg = exception, context.next = loc, caught && (context.method = "next", context.arg = undefined), !!caught; } for (var i = this.tryEntries.length - 1; i >= 0; --i) { var entry = this.tryEntries[i], record = entry.completion; if ("root" === entry.tryLoc) return handle("end"); if (entry.tryLoc <= this.prev) { var hasCatch = hasOwn.call(entry, "catchLoc"), hasFinally = hasOwn.call(entry, "finallyLoc"); if (hasCatch && hasFinally) { if (this.prev < entry.catchLoc) return handle(entry.catchLoc, !0); if (this.prev < entry.finallyLoc) return handle(entry.finallyLoc); } else if (hasCatch) { if (this.prev < entry.catchLoc) return handle(entry.catchLoc, !0); } else { if (!hasFinally) throw new Error("try statement without catch or finally"); if (this.prev < entry.finallyLoc) return handle(entry.finallyLoc); } } } }, abrupt: function abrupt(type, arg) { for (var i = this.tryEntries.length - 1; i >= 0; --i) { var entry = this.tryEntries[i]; if (entry.tryLoc <= this.prev && hasOwn.call(entry, "finallyLoc") && this.prev < entry.finallyLoc) { var finallyEntry = entry; break; } } finallyEntry && ("break" === type || "continue" === type) && finallyEntry.tryLoc <= arg && arg <= finallyEntry.finallyLoc && (finallyEntry = null); var record = finallyEntry ? finallyEntry.completion : {}; return record.type = type, record.arg = arg, finallyEntry ? (this.method = "next", this.next = finallyEntry.finallyLoc, ContinueSentinel) : this.complete(record); }, complete: function complete(record, afterLoc) { if ("throw" === record.type) throw record.arg; return "break" === record.type || "continue" === record.type ? this.next = record.arg : "return" === record.type ? (this.rval = this.arg = record.arg, this.method = "return", this.next = "end") : "normal" === record.type && afterLoc && (this.next = afterLoc), ContinueSentinel; }, finish: function finish(finallyLoc) { for (var i = this.tryEntries.length - 1; i >= 0; --i) { var entry = this.tryEntries[i]; if (entry.finallyLoc === finallyLoc) return this.complete(entry.completion, entry.afterLoc), resetTryEntry(entry), ContinueSentinel; } }, catch: function _catch(tryLoc) { for (var i = this.tryEntries.length - 1; i >= 0; --i) { var entry = this.tryEntries[i]; if (entry.tryLoc === tryLoc) { var record = entry.completion; if ("throw" === record.type) { var thrown = record.arg; resetTryEntry(entry); } return thrown; } } throw new Error("illegal catch attempt"); }, delegateYield: function delegateYield(iterable, resultName, nextLoc) { return this.delegate = { iterator: values(iterable), resultName: resultName, nextLoc: nextLoc }, "next" === this.method && (this.arg = undefined), ContinueSentinel; } }, exports; }



var mockMethod = (0,_mock_utils__WEBPACK_IMPORTED_MODULE_2__.getMockMethodAnnotation)({
  doLog: false,
  logPrefix: 'DevicePluginMock'
});
var DevicePluginMock = /*#__PURE__*/function () {
  function DevicePluginMock() {
    (0,_Users_smartcommunitylab_Documents_work_projects_dslab_playgo_mobile_playgo_mobile_node_modules_babel_runtime_helpers_esm_classCallCheck_js__WEBPACK_IMPORTED_MODULE_0__["default"])(this, DevicePluginMock);

    throw new Error('static mock');
  }

  (0,_Users_smartcommunitylab_Documents_work_projects_dslab_playgo_mobile_playgo_mobile_node_modules_babel_runtime_helpers_esm_createClass_js__WEBPACK_IMPORTED_MODULE_1__["default"])(DevicePluginMock, null, [{
    key: "getInfo",
    value: function getInfo() {
      return (0,tslib__WEBPACK_IMPORTED_MODULE_3__.__awaiter)(this, void 0, void 0, /*#__PURE__*/_regeneratorRuntime().mark(function _callee() {
        return _regeneratorRuntime().wrap(function _callee$(_context) {
          while (1) {
            switch (_context.prev = _context.next) {
              case 0:
                return _context.abrupt("return", {
                  platform: 'web',
                  name: 'mocked device info'
                });

              case 1:
              case "end":
                return _context.stop();
            }
          }
        }, _callee);
      }));
    }
  }]);

  return DevicePluginMock;
}();

(0,tslib__WEBPACK_IMPORTED_MODULE_3__.__decorate)([mockMethod({
  async: true
})], DevicePluginMock, "getInfo", null);

/***/ }),

/***/ 67650:
/*!********************************************************!*\
  !*** ./src/app/core/shared/plugin-mocks/mock-utils.ts ***!
  \********************************************************/
/***/ (function(__unused_webpack_module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "getMockMethodAnnotation": function() { return /* binding */ getMockMethodAnnotation; }
/* harmony export */ });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! tslib */ 34929);
function _regeneratorRuntime() { "use strict"; /*! regenerator-runtime -- Copyright (c) 2014-present, Facebook, Inc. -- license (MIT): https://github.com/facebook/regenerator/blob/main/LICENSE */ _regeneratorRuntime = function _regeneratorRuntime() { return exports; }; var exports = {}, Op = Object.prototype, hasOwn = Op.hasOwnProperty, $Symbol = "function" == typeof Symbol ? Symbol : {}, iteratorSymbol = $Symbol.iterator || "@@iterator", asyncIteratorSymbol = $Symbol.asyncIterator || "@@asyncIterator", toStringTagSymbol = $Symbol.toStringTag || "@@toStringTag"; function define(obj, key, value) { return Object.defineProperty(obj, key, { value: value, enumerable: !0, configurable: !0, writable: !0 }), obj[key]; } try { define({}, ""); } catch (err) { define = function define(obj, key, value) { return obj[key] = value; }; } function wrap(innerFn, outerFn, self, tryLocsList) { var protoGenerator = outerFn && outerFn.prototype instanceof Generator ? outerFn : Generator, generator = Object.create(protoGenerator.prototype), context = new Context(tryLocsList || []); return generator._invoke = function (innerFn, self, context) { var state = "suspendedStart"; return function (method, arg) { if ("executing" === state) throw new Error("Generator is already running"); if ("completed" === state) { if ("throw" === method) throw arg; return doneResult(); } for (context.method = method, context.arg = arg;;) { var delegate = context.delegate; if (delegate) { var delegateResult = maybeInvokeDelegate(delegate, context); if (delegateResult) { if (delegateResult === ContinueSentinel) continue; return delegateResult; } } if ("next" === context.method) context.sent = context._sent = context.arg;else if ("throw" === context.method) { if ("suspendedStart" === state) throw state = "completed", context.arg; context.dispatchException(context.arg); } else "return" === context.method && context.abrupt("return", context.arg); state = "executing"; var record = tryCatch(innerFn, self, context); if ("normal" === record.type) { if (state = context.done ? "completed" : "suspendedYield", record.arg === ContinueSentinel) continue; return { value: record.arg, done: context.done }; } "throw" === record.type && (state = "completed", context.method = "throw", context.arg = record.arg); } }; }(innerFn, self, context), generator; } function tryCatch(fn, obj, arg) { try { return { type: "normal", arg: fn.call(obj, arg) }; } catch (err) { return { type: "throw", arg: err }; } } exports.wrap = wrap; var ContinueSentinel = {}; function Generator() {} function GeneratorFunction() {} function GeneratorFunctionPrototype() {} var IteratorPrototype = {}; define(IteratorPrototype, iteratorSymbol, function () { return this; }); var getProto = Object.getPrototypeOf, NativeIteratorPrototype = getProto && getProto(getProto(values([]))); NativeIteratorPrototype && NativeIteratorPrototype !== Op && hasOwn.call(NativeIteratorPrototype, iteratorSymbol) && (IteratorPrototype = NativeIteratorPrototype); var Gp = GeneratorFunctionPrototype.prototype = Generator.prototype = Object.create(IteratorPrototype); function defineIteratorMethods(prototype) { ["next", "throw", "return"].forEach(function (method) { define(prototype, method, function (arg) { return this._invoke(method, arg); }); }); } function AsyncIterator(generator, PromiseImpl) { function invoke(method, arg, resolve, reject) { var record = tryCatch(generator[method], generator, arg); if ("throw" !== record.type) { var result = record.arg, value = result.value; return value && "object" == typeof value && hasOwn.call(value, "__await") ? PromiseImpl.resolve(value.__await).then(function (value) { invoke("next", value, resolve, reject); }, function (err) { invoke("throw", err, resolve, reject); }) : PromiseImpl.resolve(value).then(function (unwrapped) { result.value = unwrapped, resolve(result); }, function (error) { return invoke("throw", error, resolve, reject); }); } reject(record.arg); } var previousPromise; this._invoke = function (method, arg) { function callInvokeWithMethodAndArg() { return new PromiseImpl(function (resolve, reject) { invoke(method, arg, resolve, reject); }); } return previousPromise = previousPromise ? previousPromise.then(callInvokeWithMethodAndArg, callInvokeWithMethodAndArg) : callInvokeWithMethodAndArg(); }; } function maybeInvokeDelegate(delegate, context) { var method = delegate.iterator[context.method]; if (undefined === method) { if (context.delegate = null, "throw" === context.method) { if (delegate.iterator.return && (context.method = "return", context.arg = undefined, maybeInvokeDelegate(delegate, context), "throw" === context.method)) return ContinueSentinel; context.method = "throw", context.arg = new TypeError("The iterator does not provide a 'throw' method"); } return ContinueSentinel; } var record = tryCatch(method, delegate.iterator, context.arg); if ("throw" === record.type) return context.method = "throw", context.arg = record.arg, context.delegate = null, ContinueSentinel; var info = record.arg; return info ? info.done ? (context[delegate.resultName] = info.value, context.next = delegate.nextLoc, "return" !== context.method && (context.method = "next", context.arg = undefined), context.delegate = null, ContinueSentinel) : info : (context.method = "throw", context.arg = new TypeError("iterator result is not an object"), context.delegate = null, ContinueSentinel); } function pushTryEntry(locs) { var entry = { tryLoc: locs[0] }; 1 in locs && (entry.catchLoc = locs[1]), 2 in locs && (entry.finallyLoc = locs[2], entry.afterLoc = locs[3]), this.tryEntries.push(entry); } function resetTryEntry(entry) { var record = entry.completion || {}; record.type = "normal", delete record.arg, entry.completion = record; } function Context(tryLocsList) { this.tryEntries = [{ tryLoc: "root" }], tryLocsList.forEach(pushTryEntry, this), this.reset(!0); } function values(iterable) { if (iterable) { var iteratorMethod = iterable[iteratorSymbol]; if (iteratorMethod) return iteratorMethod.call(iterable); if ("function" == typeof iterable.next) return iterable; if (!isNaN(iterable.length)) { var i = -1, next = function next() { for (; ++i < iterable.length;) { if (hasOwn.call(iterable, i)) return next.value = iterable[i], next.done = !1, next; } return next.value = undefined, next.done = !0, next; }; return next.next = next; } } return { next: doneResult }; } function doneResult() { return { value: undefined, done: !0 }; } return GeneratorFunction.prototype = GeneratorFunctionPrototype, define(Gp, "constructor", GeneratorFunctionPrototype), define(GeneratorFunctionPrototype, "constructor", GeneratorFunction), GeneratorFunction.displayName = define(GeneratorFunctionPrototype, toStringTagSymbol, "GeneratorFunction"), exports.isGeneratorFunction = function (genFun) { var ctor = "function" == typeof genFun && genFun.constructor; return !!ctor && (ctor === GeneratorFunction || "GeneratorFunction" === (ctor.displayName || ctor.name)); }, exports.mark = function (genFun) { return Object.setPrototypeOf ? Object.setPrototypeOf(genFun, GeneratorFunctionPrototype) : (genFun.__proto__ = GeneratorFunctionPrototype, define(genFun, toStringTagSymbol, "GeneratorFunction")), genFun.prototype = Object.create(Gp), genFun; }, exports.awrap = function (arg) { return { __await: arg }; }, defineIteratorMethods(AsyncIterator.prototype), define(AsyncIterator.prototype, asyncIteratorSymbol, function () { return this; }), exports.AsyncIterator = AsyncIterator, exports.async = function (innerFn, outerFn, self, tryLocsList, PromiseImpl) { void 0 === PromiseImpl && (PromiseImpl = Promise); var iter = new AsyncIterator(wrap(innerFn, outerFn, self, tryLocsList), PromiseImpl); return exports.isGeneratorFunction(outerFn) ? iter : iter.next().then(function (result) { return result.done ? result.value : iter.next(); }); }, defineIteratorMethods(Gp), define(Gp, toStringTagSymbol, "Generator"), define(Gp, iteratorSymbol, function () { return this; }), define(Gp, "toString", function () { return "[object Generator]"; }), exports.keys = function (object) { var keys = []; for (var key in object) { keys.push(key); } return keys.reverse(), function next() { for (; keys.length;) { var key = keys.pop(); if (key in object) return next.value = key, next.done = !1, next; } return next.done = !0, next; }; }, exports.values = values, Context.prototype = { constructor: Context, reset: function reset(skipTempReset) { if (this.prev = 0, this.next = 0, this.sent = this._sent = undefined, this.done = !1, this.delegate = null, this.method = "next", this.arg = undefined, this.tryEntries.forEach(resetTryEntry), !skipTempReset) for (var name in this) { "t" === name.charAt(0) && hasOwn.call(this, name) && !isNaN(+name.slice(1)) && (this[name] = undefined); } }, stop: function stop() { this.done = !0; var rootRecord = this.tryEntries[0].completion; if ("throw" === rootRecord.type) throw rootRecord.arg; return this.rval; }, dispatchException: function dispatchException(exception) { if (this.done) throw exception; var context = this; function handle(loc, caught) { return record.type = "throw", record.arg = exception, context.next = loc, caught && (context.method = "next", context.arg = undefined), !!caught; } for (var i = this.tryEntries.length - 1; i >= 0; --i) { var entry = this.tryEntries[i], record = entry.completion; if ("root" === entry.tryLoc) return handle("end"); if (entry.tryLoc <= this.prev) { var hasCatch = hasOwn.call(entry, "catchLoc"), hasFinally = hasOwn.call(entry, "finallyLoc"); if (hasCatch && hasFinally) { if (this.prev < entry.catchLoc) return handle(entry.catchLoc, !0); if (this.prev < entry.finallyLoc) return handle(entry.finallyLoc); } else if (hasCatch) { if (this.prev < entry.catchLoc) return handle(entry.catchLoc, !0); } else { if (!hasFinally) throw new Error("try statement without catch or finally"); if (this.prev < entry.finallyLoc) return handle(entry.finallyLoc); } } } }, abrupt: function abrupt(type, arg) { for (var i = this.tryEntries.length - 1; i >= 0; --i) { var entry = this.tryEntries[i]; if (entry.tryLoc <= this.prev && hasOwn.call(entry, "finallyLoc") && this.prev < entry.finallyLoc) { var finallyEntry = entry; break; } } finallyEntry && ("break" === type || "continue" === type) && finallyEntry.tryLoc <= arg && arg <= finallyEntry.finallyLoc && (finallyEntry = null); var record = finallyEntry ? finallyEntry.completion : {}; return record.type = type, record.arg = arg, finallyEntry ? (this.method = "next", this.next = finallyEntry.finallyLoc, ContinueSentinel) : this.complete(record); }, complete: function complete(record, afterLoc) { if ("throw" === record.type) throw record.arg; return "break" === record.type || "continue" === record.type ? this.next = record.arg : "return" === record.type ? (this.rval = this.arg = record.arg, this.method = "return", this.next = "end") : "normal" === record.type && afterLoc && (this.next = afterLoc), ContinueSentinel; }, finish: function finish(finallyLoc) { for (var i = this.tryEntries.length - 1; i >= 0; --i) { var entry = this.tryEntries[i]; if (entry.finallyLoc === finallyLoc) return this.complete(entry.completion, entry.afterLoc), resetTryEntry(entry), ContinueSentinel; } }, catch: function _catch(tryLoc) { for (var i = this.tryEntries.length - 1; i >= 0; --i) { var entry = this.tryEntries[i]; if (entry.tryLoc === tryLoc) { var record = entry.completion; if ("throw" === record.type) { var thrown = record.arg; resetTryEntry(entry); } return thrown; } } throw new Error("illegal catch attempt"); }, delegateYield: function delegateYield(iterable, resultName, nextLoc) { return this.delegate = { iterator: values(iterable), resultName: resultName, nextLoc: nextLoc }, "next" === this.method && (this.arg = undefined), ContinueSentinel; } }, exports; }


/* eslint-disable prefer-arrow/prefer-arrow-functions */

function getMockMethodAnnotation(_ref) {
  var doLog = _ref.doLog,
      logPrefix = _ref.logPrefix;
  return function mockMethod() {
    var opts = arguments.length > 0 && arguments[0] !== undefined ? arguments[0] : {};
    opts = Object.assign({
      async: false,
      wait: 200
    }, opts);
    return function (target, propertyKey, descriptor) {
      var targetMethod = descriptor.value;

      descriptor.value = function () {
        var _this = this;

        for (var _len = arguments.length, args = new Array(_len), _key = 0; _key < _len; _key++) {
          args[_key] = arguments[_key];
        }

        if (doLog) {
          var _console;

          (_console = console).log.apply(_console, ["".concat(logPrefix, ".").concat(propertyKey, " called:")].concat(args));
        }

        var res = targetMethod.apply(this, args);

        if (opts.async) {
          return function () {
            return (0,tslib__WEBPACK_IMPORTED_MODULE_0__.__awaiter)(_this, void 0, void 0, /*#__PURE__*/_regeneratorRuntime().mark(function _callee() {
              var promiseRes;
              return _regeneratorRuntime().wrap(function _callee$(_context) {
                while (1) {
                  switch (_context.prev = _context.next) {
                    case 0:
                      _context.next = 2;
                      return res;

                    case 2:
                      promiseRes = _context.sent;
                      _context.next = 5;
                      return time(opts.wait);

                    case 5:
                      if (doLog) {
                        console.log("".concat(logPrefix, ".").concat(propertyKey, " finished:"), promiseRes);
                      }

                      return _context.abrupt("return", promiseRes);

                    case 7:
                    case "end":
                      return _context.stop();
                  }
                }
              }, _callee);
            }));
          }();
        } else {
          if (doLog) {
            console.log("".concat(logPrefix, ".").concat(propertyKey, " result"), res);
          }
        }
      };

      return descriptor;
    };
  };
}

function time(ms) {
  return (0,tslib__WEBPACK_IMPORTED_MODULE_0__.__awaiter)(this, void 0, void 0, /*#__PURE__*/_regeneratorRuntime().mark(function _callee2() {
    return _regeneratorRuntime().wrap(function _callee2$(_context2) {
      while (1) {
        switch (_context2.prev = _context2.next) {
          case 0:
            return _context2.abrupt("return", new Promise(function (resolve, reject) {
              setTimeout(resolve, ms);
            }));

          case 1:
          case "end":
            return _context2.stop();
        }
      }
    }, _callee2);
  }));
}

/***/ }),

/***/ 7054:
/*!***************************************************************************************!*\
  !*** ./src/app/core/shared/profile-components/profile-component/profile.component.ts ***!
  \***************************************************************************************/
/***/ (function(__unused_webpack_module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "ProfileComponent": function() { return /* binding */ ProfileComponent; }
/* harmony export */ });
/* harmony import */ var _Users_smartcommunitylab_Documents_work_projects_dslab_playgo_mobile_playgo_mobile_node_modules_babel_runtime_helpers_esm_classCallCheck_js__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./node_modules/@babel/runtime/helpers/esm/classCallCheck.js */ 78069);
/* harmony import */ var _Users_smartcommunitylab_Documents_work_projects_dslab_playgo_mobile_playgo_mobile_node_modules_babel_runtime_helpers_esm_createClass_js__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ./node_modules/@babel/runtime/helpers/esm/createClass.js */ 48047);
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_10__ = __webpack_require__(/*! tslib */ 34929);
/* harmony import */ var _capacitor_camera__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @capacitor/camera */ 4241);
/* harmony import */ var _utils__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! ../../utils */ 68647);
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_9__ = __webpack_require__(/*! @angular/core */ 3184);
/* harmony import */ var src_app_core_shared_services_user_service__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! src/app/core/shared/services/user.service */ 50749);
/* harmony import */ var _services_campaign_service__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! ../../services/campaign.service */ 23645);
/* harmony import */ var _ionic_angular__WEBPACK_IMPORTED_MODULE_11__ = __webpack_require__(/*! @ionic/angular */ 93819);
/* harmony import */ var _services_error_service__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! ../../services/error.service */ 96204);
/* harmony import */ var _angular_common__WEBPACK_IMPORTED_MODULE_12__ = __webpack_require__(/*! @angular/common */ 36362);
/* harmony import */ var _ngx_translate_core__WEBPACK_IMPORTED_MODULE_13__ = __webpack_require__(/*! @ngx-translate/core */ 87514);
/* harmony import */ var _pipes_localDate_pipe__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(/*! ../../pipes/localDate.pipe */ 34489);
/* harmony import */ var _pipes_languageMap_pipe__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(/*! ../../pipes/languageMap.pipe */ 73088);



function _regeneratorRuntime() { "use strict"; /*! regenerator-runtime -- Copyright (c) 2014-present, Facebook, Inc. -- license (MIT): https://github.com/facebook/regenerator/blob/main/LICENSE */ _regeneratorRuntime = function _regeneratorRuntime() { return exports; }; var exports = {}, Op = Object.prototype, hasOwn = Op.hasOwnProperty, $Symbol = "function" == typeof Symbol ? Symbol : {}, iteratorSymbol = $Symbol.iterator || "@@iterator", asyncIteratorSymbol = $Symbol.asyncIterator || "@@asyncIterator", toStringTagSymbol = $Symbol.toStringTag || "@@toStringTag"; function define(obj, key, value) { return Object.defineProperty(obj, key, { value: value, enumerable: !0, configurable: !0, writable: !0 }), obj[key]; } try { define({}, ""); } catch (err) { define = function define(obj, key, value) { return obj[key] = value; }; } function wrap(innerFn, outerFn, self, tryLocsList) { var protoGenerator = outerFn && outerFn.prototype instanceof Generator ? outerFn : Generator, generator = Object.create(protoGenerator.prototype), context = new Context(tryLocsList || []); return generator._invoke = function (innerFn, self, context) { var state = "suspendedStart"; return function (method, arg) { if ("executing" === state) throw new Error("Generator is already running"); if ("completed" === state) { if ("throw" === method) throw arg; return doneResult(); } for (context.method = method, context.arg = arg;;) { var delegate = context.delegate; if (delegate) { var delegateResult = maybeInvokeDelegate(delegate, context); if (delegateResult) { if (delegateResult === ContinueSentinel) continue; return delegateResult; } } if ("next" === context.method) context.sent = context._sent = context.arg;else if ("throw" === context.method) { if ("suspendedStart" === state) throw state = "completed", context.arg; context.dispatchException(context.arg); } else "return" === context.method && context.abrupt("return", context.arg); state = "executing"; var record = tryCatch(innerFn, self, context); if ("normal" === record.type) { if (state = context.done ? "completed" : "suspendedYield", record.arg === ContinueSentinel) continue; return { value: record.arg, done: context.done }; } "throw" === record.type && (state = "completed", context.method = "throw", context.arg = record.arg); } }; }(innerFn, self, context), generator; } function tryCatch(fn, obj, arg) { try { return { type: "normal", arg: fn.call(obj, arg) }; } catch (err) { return { type: "throw", arg: err }; } } exports.wrap = wrap; var ContinueSentinel = {}; function Generator() {} function GeneratorFunction() {} function GeneratorFunctionPrototype() {} var IteratorPrototype = {}; define(IteratorPrototype, iteratorSymbol, function () { return this; }); var getProto = Object.getPrototypeOf, NativeIteratorPrototype = getProto && getProto(getProto(values([]))); NativeIteratorPrototype && NativeIteratorPrototype !== Op && hasOwn.call(NativeIteratorPrototype, iteratorSymbol) && (IteratorPrototype = NativeIteratorPrototype); var Gp = GeneratorFunctionPrototype.prototype = Generator.prototype = Object.create(IteratorPrototype); function defineIteratorMethods(prototype) { ["next", "throw", "return"].forEach(function (method) { define(prototype, method, function (arg) { return this._invoke(method, arg); }); }); } function AsyncIterator(generator, PromiseImpl) { function invoke(method, arg, resolve, reject) { var record = tryCatch(generator[method], generator, arg); if ("throw" !== record.type) { var result = record.arg, value = result.value; return value && "object" == typeof value && hasOwn.call(value, "__await") ? PromiseImpl.resolve(value.__await).then(function (value) { invoke("next", value, resolve, reject); }, function (err) { invoke("throw", err, resolve, reject); }) : PromiseImpl.resolve(value).then(function (unwrapped) { result.value = unwrapped, resolve(result); }, function (error) { return invoke("throw", error, resolve, reject); }); } reject(record.arg); } var previousPromise; this._invoke = function (method, arg) { function callInvokeWithMethodAndArg() { return new PromiseImpl(function (resolve, reject) { invoke(method, arg, resolve, reject); }); } return previousPromise = previousPromise ? previousPromise.then(callInvokeWithMethodAndArg, callInvokeWithMethodAndArg) : callInvokeWithMethodAndArg(); }; } function maybeInvokeDelegate(delegate, context) { var method = delegate.iterator[context.method]; if (undefined === method) { if (context.delegate = null, "throw" === context.method) { if (delegate.iterator.return && (context.method = "return", context.arg = undefined, maybeInvokeDelegate(delegate, context), "throw" === context.method)) return ContinueSentinel; context.method = "throw", context.arg = new TypeError("The iterator does not provide a 'throw' method"); } return ContinueSentinel; } var record = tryCatch(method, delegate.iterator, context.arg); if ("throw" === record.type) return context.method = "throw", context.arg = record.arg, context.delegate = null, ContinueSentinel; var info = record.arg; return info ? info.done ? (context[delegate.resultName] = info.value, context.next = delegate.nextLoc, "return" !== context.method && (context.method = "next", context.arg = undefined), context.delegate = null, ContinueSentinel) : info : (context.method = "throw", context.arg = new TypeError("iterator result is not an object"), context.delegate = null, ContinueSentinel); } function pushTryEntry(locs) { var entry = { tryLoc: locs[0] }; 1 in locs && (entry.catchLoc = locs[1]), 2 in locs && (entry.finallyLoc = locs[2], entry.afterLoc = locs[3]), this.tryEntries.push(entry); } function resetTryEntry(entry) { var record = entry.completion || {}; record.type = "normal", delete record.arg, entry.completion = record; } function Context(tryLocsList) { this.tryEntries = [{ tryLoc: "root" }], tryLocsList.forEach(pushTryEntry, this), this.reset(!0); } function values(iterable) { if (iterable) { var iteratorMethod = iterable[iteratorSymbol]; if (iteratorMethod) return iteratorMethod.call(iterable); if ("function" == typeof iterable.next) return iterable; if (!isNaN(iterable.length)) { var i = -1, next = function next() { for (; ++i < iterable.length;) { if (hasOwn.call(iterable, i)) return next.value = iterable[i], next.done = !1, next; } return next.value = undefined, next.done = !0, next; }; return next.next = next; } } return { next: doneResult }; } function doneResult() { return { value: undefined, done: !0 }; } return GeneratorFunction.prototype = GeneratorFunctionPrototype, define(Gp, "constructor", GeneratorFunctionPrototype), define(GeneratorFunctionPrototype, "constructor", GeneratorFunction), GeneratorFunction.displayName = define(GeneratorFunctionPrototype, toStringTagSymbol, "GeneratorFunction"), exports.isGeneratorFunction = function (genFun) { var ctor = "function" == typeof genFun && genFun.constructor; return !!ctor && (ctor === GeneratorFunction || "GeneratorFunction" === (ctor.displayName || ctor.name)); }, exports.mark = function (genFun) { return Object.setPrototypeOf ? Object.setPrototypeOf(genFun, GeneratorFunctionPrototype) : (genFun.__proto__ = GeneratorFunctionPrototype, define(genFun, toStringTagSymbol, "GeneratorFunction")), genFun.prototype = Object.create(Gp), genFun; }, exports.awrap = function (arg) { return { __await: arg }; }, defineIteratorMethods(AsyncIterator.prototype), define(AsyncIterator.prototype, asyncIteratorSymbol, function () { return this; }), exports.AsyncIterator = AsyncIterator, exports.async = function (innerFn, outerFn, self, tryLocsList, PromiseImpl) { void 0 === PromiseImpl && (PromiseImpl = Promise); var iter = new AsyncIterator(wrap(innerFn, outerFn, self, tryLocsList), PromiseImpl); return exports.isGeneratorFunction(outerFn) ? iter : iter.next().then(function (result) { return result.done ? result.value : iter.next(); }); }, defineIteratorMethods(Gp), define(Gp, toStringTagSymbol, "Generator"), define(Gp, iteratorSymbol, function () { return this; }), define(Gp, "toString", function () { return "[object Generator]"; }), exports.keys = function (object) { var keys = []; for (var key in object) { keys.push(key); } return keys.reverse(), function next() { for (; keys.length;) { var key = keys.pop(); if (key in object) return next.value = key, next.done = !1, next; } return next.done = !0, next; }; }, exports.values = values, Context.prototype = { constructor: Context, reset: function reset(skipTempReset) { if (this.prev = 0, this.next = 0, this.sent = this._sent = undefined, this.done = !1, this.delegate = null, this.method = "next", this.arg = undefined, this.tryEntries.forEach(resetTryEntry), !skipTempReset) for (var name in this) { "t" === name.charAt(0) && hasOwn.call(this, name) && !isNaN(+name.slice(1)) && (this[name] = undefined); } }, stop: function stop() { this.done = !0; var rootRecord = this.tryEntries[0].completion; if ("throw" === rootRecord.type) throw rootRecord.arg; return this.rval; }, dispatchException: function dispatchException(exception) { if (this.done) throw exception; var context = this; function handle(loc, caught) { return record.type = "throw", record.arg = exception, context.next = loc, caught && (context.method = "next", context.arg = undefined), !!caught; } for (var i = this.tryEntries.length - 1; i >= 0; --i) { var entry = this.tryEntries[i], record = entry.completion; if ("root" === entry.tryLoc) return handle("end"); if (entry.tryLoc <= this.prev) { var hasCatch = hasOwn.call(entry, "catchLoc"), hasFinally = hasOwn.call(entry, "finallyLoc"); if (hasCatch && hasFinally) { if (this.prev < entry.catchLoc) return handle(entry.catchLoc, !0); if (this.prev < entry.finallyLoc) return handle(entry.finallyLoc); } else if (hasCatch) { if (this.prev < entry.catchLoc) return handle(entry.catchLoc, !0); } else { if (!hasFinally) throw new Error("try statement without catch or finally"); if (this.prev < entry.finallyLoc) return handle(entry.finallyLoc); } } } }, abrupt: function abrupt(type, arg) { for (var i = this.tryEntries.length - 1; i >= 0; --i) { var entry = this.tryEntries[i]; if (entry.tryLoc <= this.prev && hasOwn.call(entry, "finallyLoc") && this.prev < entry.finallyLoc) { var finallyEntry = entry; break; } } finallyEntry && ("break" === type || "continue" === type) && finallyEntry.tryLoc <= arg && arg <= finallyEntry.finallyLoc && (finallyEntry = null); var record = finallyEntry ? finallyEntry.completion : {}; return record.type = type, record.arg = arg, finallyEntry ? (this.method = "next", this.next = finallyEntry.finallyLoc, ContinueSentinel) : this.complete(record); }, complete: function complete(record, afterLoc) { if ("throw" === record.type) throw record.arg; return "break" === record.type || "continue" === record.type ? this.next = record.arg : "return" === record.type ? (this.rval = this.arg = record.arg, this.method = "return", this.next = "end") : "normal" === record.type && afterLoc && (this.next = afterLoc), ContinueSentinel; }, finish: function finish(finallyLoc) { for (var i = this.tryEntries.length - 1; i >= 0; --i) { var entry = this.tryEntries[i]; if (entry.finallyLoc === finallyLoc) return this.complete(entry.completion, entry.afterLoc), resetTryEntry(entry), ContinueSentinel; } }, catch: function _catch(tryLoc) { for (var i = this.tryEntries.length - 1; i >= 0; --i) { var entry = this.tryEntries[i]; if (entry.tryLoc === tryLoc) { var record = entry.completion; if ("throw" === record.type) { var thrown = record.arg; resetTryEntry(entry); } return thrown; } } throw new Error("illegal catch attempt"); }, delegateYield: function delegateYield(iterable, resultName, nextLoc) { return this.delegate = { iterator: values(iterable), resultName: resultName, nextLoc: nextLoc }, "next" === this.method && (this.arg = undefined), ContinueSentinel; } }, exports; }














function ProfileComponent_div_0_div_1_Template(rf, ctx) {
  if (rf & 1) {
    _angular_core__WEBPACK_IMPORTED_MODULE_9__["ɵɵelement"](0, "div");
  }
}

function ProfileComponent_div_0_ng_template_2_Template(rf, ctx) {
  if (rf & 1) {
    _angular_core__WEBPACK_IMPORTED_MODULE_9__["ɵɵelement"](0, "ion-icon", 5);
    _angular_core__WEBPACK_IMPORTED_MODULE_9__["ɵɵelementStart"](1, "ion-item", 6)(2, "ion-avatar", 7);
    _angular_core__WEBPACK_IMPORTED_MODULE_9__["ɵɵelement"](3, "img", 8);
    _angular_core__WEBPACK_IMPORTED_MODULE_9__["ɵɵpipe"](4, "translate");
    _angular_core__WEBPACK_IMPORTED_MODULE_9__["ɵɵelementEnd"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_9__["ɵɵelementStart"](5, "ion-label")(6, "div", 9)(7, "span", 10);
    _angular_core__WEBPACK_IMPORTED_MODULE_9__["ɵɵtext"](8);
    _angular_core__WEBPACK_IMPORTED_MODULE_9__["ɵɵelementEnd"]()()()();
  }

  if (rf & 2) {
    var ctx_r3 = _angular_core__WEBPACK_IMPORTED_MODULE_9__["ɵɵnextContext"](2);
    _angular_core__WEBPACK_IMPORTED_MODULE_9__["ɵɵadvance"](3);
    _angular_core__WEBPACK_IMPORTED_MODULE_9__["ɵɵpropertyInterpolate"]("title", _angular_core__WEBPACK_IMPORTED_MODULE_9__["ɵɵpipeBind1"](4, 3, "registration.avatar.title"));
    _angular_core__WEBPACK_IMPORTED_MODULE_9__["ɵɵproperty"]("src", ctx_r3.profile.avatar.avatarUrl, _angular_core__WEBPACK_IMPORTED_MODULE_9__["ɵɵsanitizeUrl"]);
    _angular_core__WEBPACK_IMPORTED_MODULE_9__["ɵɵadvance"](5);
    _angular_core__WEBPACK_IMPORTED_MODULE_9__["ɵɵtextInterpolate"](ctx_r3.profile.nickname);
  }
}

function ProfileComponent_div_0_ng_template_4_ion_label_6_Template(rf, ctx) {
  if (rf & 1) {
    _angular_core__WEBPACK_IMPORTED_MODULE_9__["ɵɵelementStart"](0, "ion-label", 6)(1, "div", 9)(2, "b");
    _angular_core__WEBPACK_IMPORTED_MODULE_9__["ɵɵtext"](3);
    _angular_core__WEBPACK_IMPORTED_MODULE_9__["ɵɵelementEnd"]()();
    _angular_core__WEBPACK_IMPORTED_MODULE_9__["ɵɵelementStart"](4, "div");
    _angular_core__WEBPACK_IMPORTED_MODULE_9__["ɵɵtext"](5);
    _angular_core__WEBPACK_IMPORTED_MODULE_9__["ɵɵpipe"](6, "translate");
    _angular_core__WEBPACK_IMPORTED_MODULE_9__["ɵɵelementStart"](7, "b");
    _angular_core__WEBPACK_IMPORTED_MODULE_9__["ɵɵtext"](8);
    _angular_core__WEBPACK_IMPORTED_MODULE_9__["ɵɵelementEnd"]()()();
  }

  if (rf & 2) {
    var ctx_r6 = _angular_core__WEBPACK_IMPORTED_MODULE_9__["ɵɵnextContext"](3);
    _angular_core__WEBPACK_IMPORTED_MODULE_9__["ɵɵadvance"](3);
    _angular_core__WEBPACK_IMPORTED_MODULE_9__["ɵɵtextInterpolate"](ctx_r6.profile.nickname);
    _angular_core__WEBPACK_IMPORTED_MODULE_9__["ɵɵadvance"](2);
    _angular_core__WEBPACK_IMPORTED_MODULE_9__["ɵɵtextInterpolate1"](" ", _angular_core__WEBPACK_IMPORTED_MODULE_9__["ɵɵpipeBind1"](6, 3, "profile.mail"), "");
    _angular_core__WEBPACK_IMPORTED_MODULE_9__["ɵɵadvance"](3);
    _angular_core__WEBPACK_IMPORTED_MODULE_9__["ɵɵtextInterpolate"](ctx_r6.profile.mail);
  }
}

function ProfileComponent_div_0_ng_template_4_ion_item_7_Template(rf, ctx) {
  if (rf & 1) {
    _angular_core__WEBPACK_IMPORTED_MODULE_9__["ɵɵelementStart"](0, "ion-item", 6)(1, "ion-label")(2, "div");
    _angular_core__WEBPACK_IMPORTED_MODULE_9__["ɵɵtext"](3);
    _angular_core__WEBPACK_IMPORTED_MODULE_9__["ɵɵpipe"](4, "translate");
    _angular_core__WEBPACK_IMPORTED_MODULE_9__["ɵɵelementStart"](5, "b");
    _angular_core__WEBPACK_IMPORTED_MODULE_9__["ɵɵtext"](6);
    _angular_core__WEBPACK_IMPORTED_MODULE_9__["ɵɵpipe"](7, "localDate");
    _angular_core__WEBPACK_IMPORTED_MODULE_9__["ɵɵelementEnd"]()()()();
  }

  if (rf & 2) {
    var ctx_r7 = _angular_core__WEBPACK_IMPORTED_MODULE_9__["ɵɵnextContext"](3);
    _angular_core__WEBPACK_IMPORTED_MODULE_9__["ɵɵadvance"](3);
    _angular_core__WEBPACK_IMPORTED_MODULE_9__["ɵɵtextInterpolate1"](" ", _angular_core__WEBPACK_IMPORTED_MODULE_9__["ɵɵpipeBind1"](4, 2, "profile.activeFrom"), "");
    _angular_core__WEBPACK_IMPORTED_MODULE_9__["ɵɵadvance"](3);
    _angular_core__WEBPACK_IMPORTED_MODULE_9__["ɵɵtextInterpolate"](_angular_core__WEBPACK_IMPORTED_MODULE_9__["ɵɵpipeBind2"](7, 4, ctx_r7.activeFrom, "shortDate"));
  }
}

function ProfileComponent_div_0_ng_template_4_ion_item_8_Template(rf, ctx) {
  if (rf & 1) {
    _angular_core__WEBPACK_IMPORTED_MODULE_9__["ɵɵelementStart"](0, "ion-item", 6)(1, "ion-label")(2, "div");
    _angular_core__WEBPACK_IMPORTED_MODULE_9__["ɵɵtext"](3);
    _angular_core__WEBPACK_IMPORTED_MODULE_9__["ɵɵpipe"](4, "translate");
    _angular_core__WEBPACK_IMPORTED_MODULE_9__["ɵɵelementStart"](5, "b");
    _angular_core__WEBPACK_IMPORTED_MODULE_9__["ɵɵtext"](6);
    _angular_core__WEBPACK_IMPORTED_MODULE_9__["ɵɵpipe"](7, "languageMap");
    _angular_core__WEBPACK_IMPORTED_MODULE_9__["ɵɵelementEnd"]()()()();
  }

  if (rf & 2) {
    var ctx_r8 = _angular_core__WEBPACK_IMPORTED_MODULE_9__["ɵɵnextContext"](3);
    _angular_core__WEBPACK_IMPORTED_MODULE_9__["ɵɵadvance"](3);
    _angular_core__WEBPACK_IMPORTED_MODULE_9__["ɵɵtextInterpolate1"](" ", _angular_core__WEBPACK_IMPORTED_MODULE_9__["ɵɵpipeBind1"](4, 2, "profile.territory"), "");
    _angular_core__WEBPACK_IMPORTED_MODULE_9__["ɵɵadvance"](3);
    _angular_core__WEBPACK_IMPORTED_MODULE_9__["ɵɵtextInterpolate"](_angular_core__WEBPACK_IMPORTED_MODULE_9__["ɵɵpipeBind1"](7, 4, ctx_r8.territory.name));
  }
}

var _c0 = function _c0(a0) {
  return {
    myCampaigns: a0
  };
};

function ProfileComponent_div_0_ng_template_4_Template(rf, ctx) {
  if (rf & 1) {
    var _r10 = _angular_core__WEBPACK_IMPORTED_MODULE_9__["ɵɵgetCurrentView"]();

    _angular_core__WEBPACK_IMPORTED_MODULE_9__["ɵɵelementStart"](0, "ion-item", 6)(1, "div", 11)(2, "ion-avatar", 12);
    _angular_core__WEBPACK_IMPORTED_MODULE_9__["ɵɵelement"](3, "img", 8);
    _angular_core__WEBPACK_IMPORTED_MODULE_9__["ɵɵpipe"](4, "translate");
    _angular_core__WEBPACK_IMPORTED_MODULE_9__["ɵɵelementEnd"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_9__["ɵɵelementStart"](5, "ion-icon", 13);
    _angular_core__WEBPACK_IMPORTED_MODULE_9__["ɵɵlistener"]("click", function ProfileComponent_div_0_ng_template_4_Template_ion_icon_click_5_listener() {
      _angular_core__WEBPACK_IMPORTED_MODULE_9__["ɵɵrestoreView"](_r10);
      var ctx_r9 = _angular_core__WEBPACK_IMPORTED_MODULE_9__["ɵɵnextContext"](2);
      return ctx_r9.changeAvatar();
    });
    _angular_core__WEBPACK_IMPORTED_MODULE_9__["ɵɵelementEnd"]()();
    _angular_core__WEBPACK_IMPORTED_MODULE_9__["ɵɵtemplate"](6, ProfileComponent_div_0_ng_template_4_ion_label_6_Template, 9, 5, "ion-label", 14);
    _angular_core__WEBPACK_IMPORTED_MODULE_9__["ɵɵelementEnd"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_9__["ɵɵtemplate"](7, ProfileComponent_div_0_ng_template_4_ion_item_7_Template, 8, 7, "ion-item", 14);
    _angular_core__WEBPACK_IMPORTED_MODULE_9__["ɵɵtemplate"](8, ProfileComponent_div_0_ng_template_4_ion_item_8_Template, 8, 6, "ion-item", 14);
    _angular_core__WEBPACK_IMPORTED_MODULE_9__["ɵɵelementStart"](9, "ion-item", 6)(10, "ion-label")(11, "div");
    _angular_core__WEBPACK_IMPORTED_MODULE_9__["ɵɵtext"](12);
    _angular_core__WEBPACK_IMPORTED_MODULE_9__["ɵɵpipe"](13, "translate");
    _angular_core__WEBPACK_IMPORTED_MODULE_9__["ɵɵelementEnd"]()()();
  }

  if (rf & 2) {
    var ctx_r5 = _angular_core__WEBPACK_IMPORTED_MODULE_9__["ɵɵnextContext"](2);
    _angular_core__WEBPACK_IMPORTED_MODULE_9__["ɵɵadvance"](3);
    _angular_core__WEBPACK_IMPORTED_MODULE_9__["ɵɵpropertyInterpolate"]("title", _angular_core__WEBPACK_IMPORTED_MODULE_9__["ɵɵpipeBind1"](4, 6, "registration.avatar.title"));
    _angular_core__WEBPACK_IMPORTED_MODULE_9__["ɵɵproperty"]("src", ctx_r5.getLinkPicture(), _angular_core__WEBPACK_IMPORTED_MODULE_9__["ɵɵsanitizeUrl"]);
    _angular_core__WEBPACK_IMPORTED_MODULE_9__["ɵɵadvance"](3);
    _angular_core__WEBPACK_IMPORTED_MODULE_9__["ɵɵproperty"]("ngIf", ctx_r5.profile == null ? null : ctx_r5.profile.mail);
    _angular_core__WEBPACK_IMPORTED_MODULE_9__["ɵɵadvance"](1);
    _angular_core__WEBPACK_IMPORTED_MODULE_9__["ɵɵproperty"]("ngIf", ctx_r5.activeFrom);
    _angular_core__WEBPACK_IMPORTED_MODULE_9__["ɵɵadvance"](1);
    _angular_core__WEBPACK_IMPORTED_MODULE_9__["ɵɵproperty"]("ngIf", ctx_r5.territory == null ? null : ctx_r5.territory.name);
    _angular_core__WEBPACK_IMPORTED_MODULE_9__["ɵɵadvance"](4);
    _angular_core__WEBPACK_IMPORTED_MODULE_9__["ɵɵtextInterpolate1"](" ", _angular_core__WEBPACK_IMPORTED_MODULE_9__["ɵɵpipeBind2"](13, 8, "profile.status.myCampaigns", _angular_core__WEBPACK_IMPORTED_MODULE_9__["ɵɵpureFunction1"](11, _c0, ctx_r5.numMyCampaigns)), " ");
  }
}

function ProfileComponent_div_0_Template(rf, ctx) {
  if (rf & 1) {
    var _r12 = _angular_core__WEBPACK_IMPORTED_MODULE_9__["ɵɵgetCurrentView"]();

    _angular_core__WEBPACK_IMPORTED_MODULE_9__["ɵɵelementStart"](0, "div", 1);
    _angular_core__WEBPACK_IMPORTED_MODULE_9__["ɵɵlistener"]("click", function ProfileComponent_div_0_Template_div_click_0_listener() {
      _angular_core__WEBPACK_IMPORTED_MODULE_9__["ɵɵrestoreView"](_r12);
      var ctx_r11 = _angular_core__WEBPACK_IMPORTED_MODULE_9__["ɵɵnextContext"]();
      return ctx_r11.goToProfile();
    });
    _angular_core__WEBPACK_IMPORTED_MODULE_9__["ɵɵtemplate"](1, ProfileComponent_div_0_div_1_Template, 1, 0, "div", 2);
    _angular_core__WEBPACK_IMPORTED_MODULE_9__["ɵɵtemplate"](2, ProfileComponent_div_0_ng_template_2_Template, 9, 5, "ng-template", null, 3, _angular_core__WEBPACK_IMPORTED_MODULE_9__["ɵɵtemplateRefExtractor"]);
    _angular_core__WEBPACK_IMPORTED_MODULE_9__["ɵɵtemplate"](4, ProfileComponent_div_0_ng_template_4_Template, 14, 13, "ng-template", null, 4, _angular_core__WEBPACK_IMPORTED_MODULE_9__["ɵɵtemplateRefExtractor"]);
    _angular_core__WEBPACK_IMPORTED_MODULE_9__["ɵɵelementEnd"]();
  }

  if (rf & 2) {
    var _r2 = _angular_core__WEBPACK_IMPORTED_MODULE_9__["ɵɵreference"](3);

    var _r4 = _angular_core__WEBPACK_IMPORTED_MODULE_9__["ɵɵreference"](5);

    var ctx_r0 = _angular_core__WEBPACK_IMPORTED_MODULE_9__["ɵɵnextContext"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_9__["ɵɵadvance"](1);
    _angular_core__WEBPACK_IMPORTED_MODULE_9__["ɵɵproperty"]("ngIf", !ctx_r0.editable)("ngIfThen", _r2)("ngIfElse", _r4);
  }
}

var ProfileComponent = /*#__PURE__*/function () {
  function ProfileComponent(userService, campaignService, navCtrl, errorService, cdr) {
    (0,_Users_smartcommunitylab_Documents_work_projects_dslab_playgo_mobile_playgo_mobile_node_modules_babel_runtime_helpers_esm_classCallCheck_js__WEBPACK_IMPORTED_MODULE_0__["default"])(this, ProfileComponent);

    this.userService = userService;
    this.campaignService = campaignService;
    this.navCtrl = navCtrl;
    this.errorService = errorService;
    this.cdr = cdr;
    this.editable = false;
  }

  (0,_Users_smartcommunitylab_Documents_work_projects_dslab_playgo_mobile_playgo_mobile_node_modules_babel_runtime_helpers_esm_createClass_js__WEBPACK_IMPORTED_MODULE_1__["default"])(ProfileComponent, [{
    key: "ngOnInit",
    value: function ngOnInit() {
      var _this = this;

      this.subProf = this.userService.userProfile$.subscribe(function (profile) {
        _this.profile = profile;

        _this.setLinkPicture(_this.profile.avatar.avatarUrl);
      });
      this.subTerritory = this.userService.userProfileTerritory$.subscribe(function (territory) {
        _this.territory = territory;
      });
      this.subCamp = this.campaignService.myCampaigns$.subscribe(function (myCampaigns) {
        var _a;

        _this.numMyCampaigns = myCampaigns === null || myCampaigns === void 0 ? void 0 : myCampaigns.length;
        _this.activeFrom = (_a = myCampaigns.find(function (camp) {
          var _a;

          return ((_a = camp.campaign) === null || _a === void 0 ? void 0 : _a.type) === 'personal';
        }).subscription) === null || _a === void 0 ? void 0 : _a.registrationDate;
      });
    }
  }, {
    key: "ngOnDestroy",
    value: function ngOnDestroy() {
      this.subProf.unsubscribe();
      this.subCamp.unsubscribe();
    }
  }, {
    key: "changeAvatar",
    value: function changeAvatar() {
      return (0,tslib__WEBPACK_IMPORTED_MODULE_10__.__awaiter)(this, void 0, void 0, /*#__PURE__*/_regeneratorRuntime().mark(function _callee() {
        var avatarData;
        return _regeneratorRuntime().wrap(function _callee$(_context) {
          while (1) {
            switch (_context.prev = _context.next) {
              case 0:
                _context.next = 2;
                return _capacitor_camera__WEBPACK_IMPORTED_MODULE_2__.Camera.getPhoto({
                  quality: 90,
                  allowEditing: false,
                  resultType: _capacitor_camera__WEBPACK_IMPORTED_MODULE_2__.CameraResultType.Uri
                });

              case 2:
                this.image = _context.sent;
                _context.t0 = this.userService;
                _context.next = 6;
                return (0,_utils__WEBPACK_IMPORTED_MODULE_3__.readAsBase64)(this.image);

              case 6:
                _context.t1 = _context.sent;
                _context.next = 9;
                return _context.t0.uploadAvatar.call(_context.t0, _context.t1);

              case 9:
                avatarData = _context.sent;

                if (avatarData) {
                  this.userService.updateImages(avatarData); //TODO update doesn't work

                  this.profile.avatar = avatarData;
                  this.setLinkPicture(this.profile.avatar.avatarUrl);
                }

              case 11:
              case "end":
                return _context.stop();
            }
          }
        }, _callee, this);
      }));
    }
  }, {
    key: "getLinkPicture",
    value: function getLinkPicture() {
      if (this.timeStamp) {
        return this.linkPicture + '?' + this.timeStamp;
      }

      return this.linkPicture;
    }
  }, {
    key: "setLinkPicture",
    value: function setLinkPicture(url) {
      this.linkPicture = url;
      this.timeStamp = new Date().getTime();
    }
  }, {
    key: "goToProfile",
    value: function goToProfile() {
      this.navCtrl.navigateRoot('/pages/tabs/home/profile');
    }
  }]);

  return ProfileComponent;
}();

ProfileComponent.ɵfac = function ProfileComponent_Factory(t) {
  return new (t || ProfileComponent)(_angular_core__WEBPACK_IMPORTED_MODULE_9__["ɵɵdirectiveInject"](src_app_core_shared_services_user_service__WEBPACK_IMPORTED_MODULE_4__.UserService), _angular_core__WEBPACK_IMPORTED_MODULE_9__["ɵɵdirectiveInject"](_services_campaign_service__WEBPACK_IMPORTED_MODULE_5__.CampaignService), _angular_core__WEBPACK_IMPORTED_MODULE_9__["ɵɵdirectiveInject"](_ionic_angular__WEBPACK_IMPORTED_MODULE_11__.NavController), _angular_core__WEBPACK_IMPORTED_MODULE_9__["ɵɵdirectiveInject"](_services_error_service__WEBPACK_IMPORTED_MODULE_6__.ErrorService), _angular_core__WEBPACK_IMPORTED_MODULE_9__["ɵɵdirectiveInject"](_angular_core__WEBPACK_IMPORTED_MODULE_9__.ChangeDetectorRef));
};

ProfileComponent.ɵcmp = /*@__PURE__*/_angular_core__WEBPACK_IMPORTED_MODULE_9__["ɵɵdefineComponent"]({
  type: ProfileComponent,
  selectors: [["app-profile-component"]],
  inputs: {
    editable: "editable"
  },
  decls: 1,
  vars: 1,
  consts: [[3, "click", 4, "ngIf"], [3, "click"], [4, "ngIf", "ngIfThen", "ngIfElse"], ["homeProfile", ""], ["editingProfile", ""], ["name", "cog", "color", "playgo", 1, "home-cog"], ["lines", "none"], ["slot", "start", 1, "avatar"], [3, "src", "title"], [1, "ion-text-center"], [1, "nickname"], [1, "avatar-container"], [1, "avatar"], ["name", "camera-outline", 1, "avatar-cange", 3, "click"], ["lines", "none", 4, "ngIf"]],
  template: function ProfileComponent_Template(rf, ctx) {
    if (rf & 1) {
      _angular_core__WEBPACK_IMPORTED_MODULE_9__["ɵɵtemplate"](0, ProfileComponent_div_0_Template, 6, 3, "div", 0);
    }

    if (rf & 2) {
      _angular_core__WEBPACK_IMPORTED_MODULE_9__["ɵɵproperty"]("ngIf", ctx.profile);
    }
  },
  directives: [_angular_common__WEBPACK_IMPORTED_MODULE_12__.NgIf, _ionic_angular__WEBPACK_IMPORTED_MODULE_11__.IonIcon, _ionic_angular__WEBPACK_IMPORTED_MODULE_11__.IonItem, _ionic_angular__WEBPACK_IMPORTED_MODULE_11__.IonAvatar, _ionic_angular__WEBPACK_IMPORTED_MODULE_11__.IonLabel],
  pipes: [_ngx_translate_core__WEBPACK_IMPORTED_MODULE_13__.TranslatePipe, _pipes_localDate_pipe__WEBPACK_IMPORTED_MODULE_7__.LocalDatePipe, _pipes_languageMap_pipe__WEBPACK_IMPORTED_MODULE_8__.LanguageMapPipe],
  styles: [".avatar[_ngcontent-%COMP%] {\n  background-color: white;\n  margin: auto;\n  height: 61px;\n  width: 61px;\n}\n.avatar-container[_ngcontent-%COMP%] {\n  margin: 33px;\n  position: relative;\n}\n.avatar-cange[_ngcontent-%COMP%] {\n  background-color: var(--ion-color-playgo);\n  color: white;\n  border-radius: 16px;\n  padding: 8px;\n  position: absolute;\n  bottom: -10%;\n  left: 80%;\n}\n.nickname[_ngcontent-%COMP%] {\n  font-size: 18px;\n  font-weight: bold;\n}\n.home-cog[_ngcontent-%COMP%] {\n  position: absolute;\n  bottom: 2px;\n  right: 2px;\n  font-size: 40px;\n  z-index: 99;\n}\n/*# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbInByb2ZpbGUuY29tcG9uZW50LmNzcyJdLCJuYW1lcyI6W10sIm1hcHBpbmdzIjoiQUFBQTtFQUNFLHVCQUF1QjtFQUN2QixZQUFZO0VBQ1osWUFBWTtFQUNaLFdBQVc7QUFDYjtBQUNBO0VBQ0UsWUFBWTtFQUNaLGtCQUFrQjtBQUNwQjtBQUNBO0VBQ0UseUNBQXlDO0VBQ3pDLFlBQVk7RUFDWixtQkFBbUI7RUFDbkIsWUFBWTtFQUNaLGtCQUFrQjtFQUNsQixZQUFZO0VBQ1osU0FBUztBQUNYO0FBQ0E7RUFDRSxlQUFlO0VBQ2YsaUJBQWlCO0FBQ25CO0FBQ0E7RUFDRSxrQkFBa0I7RUFDbEIsV0FBVztFQUNYLFVBQVU7RUFDVixlQUFlO0VBQ2YsV0FBVztBQUNiIiwiZmlsZSI6InByb2ZpbGUuY29tcG9uZW50LmNzcyIsInNvdXJjZXNDb250ZW50IjpbIi5hdmF0YXIge1xuICBiYWNrZ3JvdW5kLWNvbG9yOiB3aGl0ZTtcbiAgbWFyZ2luOiBhdXRvO1xuICBoZWlnaHQ6IDYxcHg7XG4gIHdpZHRoOiA2MXB4O1xufVxuLmF2YXRhci1jb250YWluZXIge1xuICBtYXJnaW46IDMzcHg7XG4gIHBvc2l0aW9uOiByZWxhdGl2ZTtcbn1cbi5hdmF0YXItY2FuZ2Uge1xuICBiYWNrZ3JvdW5kLWNvbG9yOiB2YXIoLS1pb24tY29sb3ItcGxheWdvKTtcbiAgY29sb3I6IHdoaXRlO1xuICBib3JkZXItcmFkaXVzOiAxNnB4O1xuICBwYWRkaW5nOiA4cHg7XG4gIHBvc2l0aW9uOiBhYnNvbHV0ZTtcbiAgYm90dG9tOiAtMTAlO1xuICBsZWZ0OiA4MCU7XG59XG4ubmlja25hbWUge1xuICBmb250LXNpemU6IDE4cHg7XG4gIGZvbnQtd2VpZ2h0OiBib2xkO1xufVxuLmhvbWUtY29nIHtcbiAgcG9zaXRpb246IGFic29sdXRlO1xuICBib3R0b206IDJweDtcbiAgcmlnaHQ6IDJweDtcbiAgZm9udC1zaXplOiA0MHB4O1xuICB6LWluZGV4OiA5OTtcbn1cbiJdfQ== */"]
});

/***/ }),

/***/ 46407:
/*!*******************************************************!*\
  !*** ./src/app/core/shared/services/alert.service.ts ***!
  \*******************************************************/
/***/ (function(__unused_webpack_module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "AlertService": function() { return /* binding */ AlertService; },
/* harmony export */   "normalizeTranslateKey": function() { return /* binding */ normalizeTranslateKey; }
/* harmony export */ });
/* harmony import */ var _Users_smartcommunitylab_Documents_work_projects_dslab_playgo_mobile_playgo_mobile_node_modules_babel_runtime_helpers_esm_toConsumableArray_js__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./node_modules/@babel/runtime/helpers/esm/toConsumableArray.js */ 58277);
/* harmony import */ var _Users_smartcommunitylab_Documents_work_projects_dslab_playgo_mobile_playgo_mobile_node_modules_babel_runtime_helpers_esm_classCallCheck_js__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ./node_modules/@babel/runtime/helpers/esm/classCallCheck.js */ 78069);
/* harmony import */ var _Users_smartcommunitylab_Documents_work_projects_dslab_playgo_mobile_playgo_mobile_node_modules_babel_runtime_helpers_esm_createClass_js__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! ./node_modules/@babel/runtime/helpers/esm/createClass.js */ 48047);
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! tslib */ 34929);
/* harmony import */ var lodash_es__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(/*! lodash-es */ 7190);
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! @angular/core */ 3184);
/* harmony import */ var _ionic_angular__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! @ionic/angular */ 93819);
/* harmony import */ var _ngx_translate_core__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! @ngx-translate/core */ 87514);




function _regeneratorRuntime() { "use strict"; /*! regenerator-runtime -- Copyright (c) 2014-present, Facebook, Inc. -- license (MIT): https://github.com/facebook/regenerator/blob/main/LICENSE */ _regeneratorRuntime = function _regeneratorRuntime() { return exports; }; var exports = {}, Op = Object.prototype, hasOwn = Op.hasOwnProperty, $Symbol = "function" == typeof Symbol ? Symbol : {}, iteratorSymbol = $Symbol.iterator || "@@iterator", asyncIteratorSymbol = $Symbol.asyncIterator || "@@asyncIterator", toStringTagSymbol = $Symbol.toStringTag || "@@toStringTag"; function define(obj, key, value) { return Object.defineProperty(obj, key, { value: value, enumerable: !0, configurable: !0, writable: !0 }), obj[key]; } try { define({}, ""); } catch (err) { define = function define(obj, key, value) { return obj[key] = value; }; } function wrap(innerFn, outerFn, self, tryLocsList) { var protoGenerator = outerFn && outerFn.prototype instanceof Generator ? outerFn : Generator, generator = Object.create(protoGenerator.prototype), context = new Context(tryLocsList || []); return generator._invoke = function (innerFn, self, context) { var state = "suspendedStart"; return function (method, arg) { if ("executing" === state) throw new Error("Generator is already running"); if ("completed" === state) { if ("throw" === method) throw arg; return doneResult(); } for (context.method = method, context.arg = arg;;) { var delegate = context.delegate; if (delegate) { var delegateResult = maybeInvokeDelegate(delegate, context); if (delegateResult) { if (delegateResult === ContinueSentinel) continue; return delegateResult; } } if ("next" === context.method) context.sent = context._sent = context.arg;else if ("throw" === context.method) { if ("suspendedStart" === state) throw state = "completed", context.arg; context.dispatchException(context.arg); } else "return" === context.method && context.abrupt("return", context.arg); state = "executing"; var record = tryCatch(innerFn, self, context); if ("normal" === record.type) { if (state = context.done ? "completed" : "suspendedYield", record.arg === ContinueSentinel) continue; return { value: record.arg, done: context.done }; } "throw" === record.type && (state = "completed", context.method = "throw", context.arg = record.arg); } }; }(innerFn, self, context), generator; } function tryCatch(fn, obj, arg) { try { return { type: "normal", arg: fn.call(obj, arg) }; } catch (err) { return { type: "throw", arg: err }; } } exports.wrap = wrap; var ContinueSentinel = {}; function Generator() {} function GeneratorFunction() {} function GeneratorFunctionPrototype() {} var IteratorPrototype = {}; define(IteratorPrototype, iteratorSymbol, function () { return this; }); var getProto = Object.getPrototypeOf, NativeIteratorPrototype = getProto && getProto(getProto(values([]))); NativeIteratorPrototype && NativeIteratorPrototype !== Op && hasOwn.call(NativeIteratorPrototype, iteratorSymbol) && (IteratorPrototype = NativeIteratorPrototype); var Gp = GeneratorFunctionPrototype.prototype = Generator.prototype = Object.create(IteratorPrototype); function defineIteratorMethods(prototype) { ["next", "throw", "return"].forEach(function (method) { define(prototype, method, function (arg) { return this._invoke(method, arg); }); }); } function AsyncIterator(generator, PromiseImpl) { function invoke(method, arg, resolve, reject) { var record = tryCatch(generator[method], generator, arg); if ("throw" !== record.type) { var result = record.arg, value = result.value; return value && "object" == typeof value && hasOwn.call(value, "__await") ? PromiseImpl.resolve(value.__await).then(function (value) { invoke("next", value, resolve, reject); }, function (err) { invoke("throw", err, resolve, reject); }) : PromiseImpl.resolve(value).then(function (unwrapped) { result.value = unwrapped, resolve(result); }, function (error) { return invoke("throw", error, resolve, reject); }); } reject(record.arg); } var previousPromise; this._invoke = function (method, arg) { function callInvokeWithMethodAndArg() { return new PromiseImpl(function (resolve, reject) { invoke(method, arg, resolve, reject); }); } return previousPromise = previousPromise ? previousPromise.then(callInvokeWithMethodAndArg, callInvokeWithMethodAndArg) : callInvokeWithMethodAndArg(); }; } function maybeInvokeDelegate(delegate, context) { var method = delegate.iterator[context.method]; if (undefined === method) { if (context.delegate = null, "throw" === context.method) { if (delegate.iterator.return && (context.method = "return", context.arg = undefined, maybeInvokeDelegate(delegate, context), "throw" === context.method)) return ContinueSentinel; context.method = "throw", context.arg = new TypeError("The iterator does not provide a 'throw' method"); } return ContinueSentinel; } var record = tryCatch(method, delegate.iterator, context.arg); if ("throw" === record.type) return context.method = "throw", context.arg = record.arg, context.delegate = null, ContinueSentinel; var info = record.arg; return info ? info.done ? (context[delegate.resultName] = info.value, context.next = delegate.nextLoc, "return" !== context.method && (context.method = "next", context.arg = undefined), context.delegate = null, ContinueSentinel) : info : (context.method = "throw", context.arg = new TypeError("iterator result is not an object"), context.delegate = null, ContinueSentinel); } function pushTryEntry(locs) { var entry = { tryLoc: locs[0] }; 1 in locs && (entry.catchLoc = locs[1]), 2 in locs && (entry.finallyLoc = locs[2], entry.afterLoc = locs[3]), this.tryEntries.push(entry); } function resetTryEntry(entry) { var record = entry.completion || {}; record.type = "normal", delete record.arg, entry.completion = record; } function Context(tryLocsList) { this.tryEntries = [{ tryLoc: "root" }], tryLocsList.forEach(pushTryEntry, this), this.reset(!0); } function values(iterable) { if (iterable) { var iteratorMethod = iterable[iteratorSymbol]; if (iteratorMethod) return iteratorMethod.call(iterable); if ("function" == typeof iterable.next) return iterable; if (!isNaN(iterable.length)) { var i = -1, next = function next() { for (; ++i < iterable.length;) { if (hasOwn.call(iterable, i)) return next.value = iterable[i], next.done = !1, next; } return next.value = undefined, next.done = !0, next; }; return next.next = next; } } return { next: doneResult }; } function doneResult() { return { value: undefined, done: !0 }; } return GeneratorFunction.prototype = GeneratorFunctionPrototype, define(Gp, "constructor", GeneratorFunctionPrototype), define(GeneratorFunctionPrototype, "constructor", GeneratorFunction), GeneratorFunction.displayName = define(GeneratorFunctionPrototype, toStringTagSymbol, "GeneratorFunction"), exports.isGeneratorFunction = function (genFun) { var ctor = "function" == typeof genFun && genFun.constructor; return !!ctor && (ctor === GeneratorFunction || "GeneratorFunction" === (ctor.displayName || ctor.name)); }, exports.mark = function (genFun) { return Object.setPrototypeOf ? Object.setPrototypeOf(genFun, GeneratorFunctionPrototype) : (genFun.__proto__ = GeneratorFunctionPrototype, define(genFun, toStringTagSymbol, "GeneratorFunction")), genFun.prototype = Object.create(Gp), genFun; }, exports.awrap = function (arg) { return { __await: arg }; }, defineIteratorMethods(AsyncIterator.prototype), define(AsyncIterator.prototype, asyncIteratorSymbol, function () { return this; }), exports.AsyncIterator = AsyncIterator, exports.async = function (innerFn, outerFn, self, tryLocsList, PromiseImpl) { void 0 === PromiseImpl && (PromiseImpl = Promise); var iter = new AsyncIterator(wrap(innerFn, outerFn, self, tryLocsList), PromiseImpl); return exports.isGeneratorFunction(outerFn) ? iter : iter.next().then(function (result) { return result.done ? result.value : iter.next(); }); }, defineIteratorMethods(Gp), define(Gp, toStringTagSymbol, "Generator"), define(Gp, iteratorSymbol, function () { return this; }), define(Gp, "toString", function () { return "[object Generator]"; }), exports.keys = function (object) { var keys = []; for (var key in object) { keys.push(key); } return keys.reverse(), function next() { for (; keys.length;) { var key = keys.pop(); if (key in object) return next.value = key, next.done = !1, next; } return next.done = !0, next; }; }, exports.values = values, Context.prototype = { constructor: Context, reset: function reset(skipTempReset) { if (this.prev = 0, this.next = 0, this.sent = this._sent = undefined, this.done = !1, this.delegate = null, this.method = "next", this.arg = undefined, this.tryEntries.forEach(resetTryEntry), !skipTempReset) for (var name in this) { "t" === name.charAt(0) && hasOwn.call(this, name) && !isNaN(+name.slice(1)) && (this[name] = undefined); } }, stop: function stop() { this.done = !0; var rootRecord = this.tryEntries[0].completion; if ("throw" === rootRecord.type) throw rootRecord.arg; return this.rval; }, dispatchException: function dispatchException(exception) { if (this.done) throw exception; var context = this; function handle(loc, caught) { return record.type = "throw", record.arg = exception, context.next = loc, caught && (context.method = "next", context.arg = undefined), !!caught; } for (var i = this.tryEntries.length - 1; i >= 0; --i) { var entry = this.tryEntries[i], record = entry.completion; if ("root" === entry.tryLoc) return handle("end"); if (entry.tryLoc <= this.prev) { var hasCatch = hasOwn.call(entry, "catchLoc"), hasFinally = hasOwn.call(entry, "finallyLoc"); if (hasCatch && hasFinally) { if (this.prev < entry.catchLoc) return handle(entry.catchLoc, !0); if (this.prev < entry.finallyLoc) return handle(entry.finallyLoc); } else if (hasCatch) { if (this.prev < entry.catchLoc) return handle(entry.catchLoc, !0); } else { if (!hasFinally) throw new Error("try statement without catch or finally"); if (this.prev < entry.finallyLoc) return handle(entry.finallyLoc); } } } }, abrupt: function abrupt(type, arg) { for (var i = this.tryEntries.length - 1; i >= 0; --i) { var entry = this.tryEntries[i]; if (entry.tryLoc <= this.prev && hasOwn.call(entry, "finallyLoc") && this.prev < entry.finallyLoc) { var finallyEntry = entry; break; } } finallyEntry && ("break" === type || "continue" === type) && finallyEntry.tryLoc <= arg && arg <= finallyEntry.finallyLoc && (finallyEntry = null); var record = finallyEntry ? finallyEntry.completion : {}; return record.type = type, record.arg = arg, finallyEntry ? (this.method = "next", this.next = finallyEntry.finallyLoc, ContinueSentinel) : this.complete(record); }, complete: function complete(record, afterLoc) { if ("throw" === record.type) throw record.arg; return "break" === record.type || "continue" === record.type ? this.next = record.arg : "return" === record.type ? (this.rval = this.arg = record.arg, this.method = "return", this.next = "end") : "normal" === record.type && afterLoc && (this.next = afterLoc), ContinueSentinel; }, finish: function finish(finallyLoc) { for (var i = this.tryEntries.length - 1; i >= 0; --i) { var entry = this.tryEntries[i]; if (entry.finallyLoc === finallyLoc) return this.complete(entry.completion, entry.afterLoc), resetTryEntry(entry), ContinueSentinel; } }, catch: function _catch(tryLoc) { for (var i = this.tryEntries.length - 1; i >= 0; --i) { var entry = this.tryEntries[i]; if (entry.tryLoc === tryLoc) { var record = entry.completion; if ("throw" === record.type) { var thrown = record.arg; resetTryEntry(entry); } return thrown; } } throw new Error("illegal catch attempt"); }, delegateYield: function delegateYield(iterable, resultName, nextLoc) { return this.delegate = { iterator: values(iterable), resultName: resultName, nextLoc: nextLoc }, "next" === this.method && (this.arg = undefined), ContinueSentinel; } }, exports; }






var AlertService = /*#__PURE__*/function () {
  function AlertService(toastController, loadingController, alertController, translateService) {
    (0,_Users_smartcommunitylab_Documents_work_projects_dslab_playgo_mobile_playgo_mobile_node_modules_babel_runtime_helpers_esm_classCallCheck_js__WEBPACK_IMPORTED_MODULE_1__["default"])(this, AlertService);

    this.toastController = toastController;
    this.loadingController = loadingController;
    this.alertController = alertController;
    this.translateService = translateService; // HACK: fix toast not presented when offline, due to lazy loading the toast controller.
    // Can be removed once #17450 is resolved: https://github.com/ionic-team/ionic/issues/17450

    this.toastController.create({
      animated: false
    }).then(function (t) {
      t.present();
      t.dismiss();
    });
  }

  (0,_Users_smartcommunitylab_Documents_work_projects_dslab_playgo_mobile_playgo_mobile_node_modules_babel_runtime_helpers_esm_createClass_js__WEBPACK_IMPORTED_MODULE_2__["default"])(AlertService, [{
    key: "showToast",
    value: function showToast(args) {
      return (0,tslib__WEBPACK_IMPORTED_MODULE_3__.__awaiter)(this, void 0, void 0, /*#__PURE__*/_regeneratorRuntime().mark(function _callee() {
        var message;
        return _regeneratorRuntime().wrap(function _callee$(_context) {
          while (1) {
            switch (_context.prev = _context.next) {
              case 0:
                message = '';

                if (!args.messageTranslateKey) {
                  _context.next = 7;
                  break;
                }

                _context.next = 4;
                return this.translate(args.messageTranslateKey);

              case 4:
                message = _context.sent;
                _context.next = 8;
                break;

              case 7:
                if (args.messageString) {
                  message = args.messageString;
                }

              case 8:
                _context.prev = 8;
                _context.next = 11;
                return this.toastController.create({
                  message: message,
                  duration: 3000,
                  position: 'bottom'
                });

              case 11:
                this.toast = _context.sent;
                _context.next = 14;
                return this.toast.present();

              case 14:
                _context.next = 20;
                break;

              case 16:
                _context.prev = 16;
                _context.t0 = _context["catch"](8);
                //..but the fail is somehow so severe, that it will be not caught, here :(
                console.error('Showing toast failed', _context.t0);
                alert(message);

              case 20:
              case "end":
                return _context.stop();
            }
          }
        }, _callee, this, [[8, 16]]);
      }));
    }
  }, {
    key: "presentAlert",
    value: function presentAlert(args) {
      return (0,tslib__WEBPACK_IMPORTED_MODULE_3__.__awaiter)(this, void 0, void 0, /*#__PURE__*/_regeneratorRuntime().mark(function _callee3() {
        var _this = this;

        var header, message, ok;
        return _regeneratorRuntime().wrap(function _callee3$(_context3) {
          while (1) {
            switch (_context3.prev = _context3.next) {
              case 0:
                _context3.next = 2;
                return this.translate(args.headerTranslateKey);

              case 2:
                header = _context3.sent;
                message = '';

                if (!args.messageTranslateKey) {
                  _context3.next = 10;
                  break;
                }

                _context3.next = 7;
                return this.translate(args.messageTranslateKey);

              case 7:
                message = _context3.sent;
                _context3.next = 11;
                break;

              case 10:
                if (args.messageString) {
                  message = args.messageString;
                }

              case 11:
                _context3.next = 13;
                return this.translate('modal.ok');

              case 13:
                ok = _context3.sent;
                return _context3.abrupt("return", new Promise(function (resolve) {
                  return (0,tslib__WEBPACK_IMPORTED_MODULE_3__.__awaiter)(_this, void 0, void 0, /*#__PURE__*/_regeneratorRuntime().mark(function _callee2() {
                    var alert;
                    return _regeneratorRuntime().wrap(function _callee2$(_context2) {
                      while (1) {
                        switch (_context2.prev = _context2.next) {
                          case 0:
                            _context2.next = 2;
                            return this.alertController.create({
                              cssClass: args.cssClass,
                              header: header,
                              message: message,
                              buttons: [{
                                text: ok,
                                id: 'confirm-button',
                                handler: function handler() {
                                  resolve();
                                }
                              }]
                            });

                          case 2:
                            alert = _context2.sent;
                            _context2.next = 5;
                            return alert.present();

                          case 5:
                          case "end":
                            return _context2.stop();
                        }
                      }
                    }, _callee2, this);
                  }));
                }));

              case 15:
              case "end":
                return _context3.stop();
            }
          }
        }, _callee3, this);
      }));
    }
  }, {
    key: "confirmAlert",
    value: function confirmAlert(headerTranslateKey, messageTranslateKey, cssClass) {
      return (0,tslib__WEBPACK_IMPORTED_MODULE_3__.__awaiter)(this, void 0, void 0, /*#__PURE__*/_regeneratorRuntime().mark(function _callee5() {
        var _this2 = this;

        var header, message, cancel, ok;
        return _regeneratorRuntime().wrap(function _callee5$(_context5) {
          while (1) {
            switch (_context5.prev = _context5.next) {
              case 0:
                _context5.next = 2;
                return this.translate(headerTranslateKey);

              case 2:
                header = _context5.sent;
                _context5.next = 5;
                return this.translate(messageTranslateKey);

              case 5:
                message = _context5.sent;
                _context5.next = 8;
                return this.translate('modal.cancel');

              case 8:
                cancel = _context5.sent;
                _context5.next = 11;
                return this.translate('modal.ok');

              case 11:
                ok = _context5.sent;
                return _context5.abrupt("return", new Promise(function (resolve, reject) {
                  return (0,tslib__WEBPACK_IMPORTED_MODULE_3__.__awaiter)(_this2, void 0, void 0, /*#__PURE__*/_regeneratorRuntime().mark(function _callee4() {
                    var alert;
                    return _regeneratorRuntime().wrap(function _callee4$(_context4) {
                      while (1) {
                        switch (_context4.prev = _context4.next) {
                          case 0:
                            _context4.next = 2;
                            return this.alertController.create({
                              cssClass: cssClass,
                              header: header,
                              message: message,
                              buttons: [{
                                text: cancel,
                                role: 'cancel',
                                cssClass: 'secondary',
                                id: 'cancel-button',
                                handler: function handler() {
                                  resolve(false);
                                }
                              }, {
                                text: ok,
                                id: 'confirm-button',
                                handler: function handler() {
                                  resolve(true);
                                }
                              }]
                            });

                          case 2:
                            alert = _context4.sent;
                            _context4.next = 5;
                            return alert.present();

                          case 5:
                          case "end":
                            return _context4.stop();
                        }
                      }
                    }, _callee4, this);
                  }));
                }));

              case 13:
              case "end":
                return _context5.stop();
            }
          }
        }, _callee5, this);
      }));
    }
  }, {
    key: "showLoading",
    value: function showLoading(message) {
      return (0,tslib__WEBPACK_IMPORTED_MODULE_3__.__awaiter)(this, void 0, void 0, /*#__PURE__*/_regeneratorRuntime().mark(function _callee6() {
        return _regeneratorRuntime().wrap(function _callee6$(_context6) {
          while (1) {
            switch (_context6.prev = _context6.next) {
              case 0:
                _context6.next = 2;
                return this.loadingController.create({
                  message: message,
                  duration: 3000
                });

              case 2:
                this.loading = _context6.sent;
                _context6.next = 5;
                return this.loading.present();

              case 5:
              case "end":
                return _context6.stop();
            }
          }
        }, _callee6, this);
      }));
    }
  }, {
    key: "dismissLoading",
    value: function dismissLoading() {
      return (0,tslib__WEBPACK_IMPORTED_MODULE_3__.__awaiter)(this, void 0, void 0, /*#__PURE__*/_regeneratorRuntime().mark(function _callee7() {
        return _regeneratorRuntime().wrap(function _callee7$(_context7) {
          while (1) {
            switch (_context7.prev = _context7.next) {
              case 0:
              case "end":
                return _context7.stop();
            }
          }
        }, _callee7);
      }));
    }
  }, {
    key: "translate",
    value: function translate(key) {
      return (0,tslib__WEBPACK_IMPORTED_MODULE_3__.__awaiter)(this, void 0, void 0, /*#__PURE__*/_regeneratorRuntime().mark(function _callee8() {
        var _this$translateServic;

        var translated;
        return _regeneratorRuntime().wrap(function _callee8$(_context8) {
          while (1) {
            switch (_context8.prev = _context8.next) {
              case 0:
                if (key) {
                  _context8.next = 2;
                  break;
                }

                return _context8.abrupt("return", '');

              case 2:
                _context8.next = 4;
                return (_this$translateServic = this.translateService).get.apply(_this$translateServic, (0,_Users_smartcommunitylab_Documents_work_projects_dslab_playgo_mobile_playgo_mobile_node_modules_babel_runtime_helpers_esm_toConsumableArray_js__WEBPACK_IMPORTED_MODULE_0__["default"])(normalizeTranslateKey(key))).toPromise();

              case 4:
                translated = _context8.sent;
                return _context8.abrupt("return", String(translated));

              case 6:
              case "end":
                return _context8.stop();
            }
          }
        }, _callee8, this);
      }));
    }
  }]);

  return AlertService;
}();

AlertService.ɵfac = function AlertService_Factory(t) {
  return new (t || AlertService)(_angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵinject"](_ionic_angular__WEBPACK_IMPORTED_MODULE_5__.ToastController), _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵinject"](_ionic_angular__WEBPACK_IMPORTED_MODULE_5__.LoadingController), _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵinject"](_ionic_angular__WEBPACK_IMPORTED_MODULE_5__.AlertController), _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵinject"](_ngx_translate_core__WEBPACK_IMPORTED_MODULE_6__.TranslateService));
};

AlertService.ɵprov = /*@__PURE__*/_angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵdefineInjectable"]({
  token: AlertService,
  factory: AlertService.ɵfac,
  providedIn: 'root'
});
function normalizeTranslateKey(key) {
  return (0,lodash_es__WEBPACK_IMPORTED_MODULE_7__["default"])(key) ? [key, null] : [key.key, key.interpolateParams];
}

/***/ }),

/***/ 93656:
/*!************************************************************!*\
  !*** ./src/app/core/shared/services/app-status.service.ts ***!
  \************************************************************/
/***/ (function(__unused_webpack_module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "AppStatusService": function() { return /* binding */ AppStatusService; }
/* harmony export */ });
/* harmony import */ var _Users_smartcommunitylab_Documents_work_projects_dslab_playgo_mobile_playgo_mobile_node_modules_babel_runtime_helpers_esm_slicedToArray_js__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./node_modules/@babel/runtime/helpers/esm/slicedToArray.js */ 10507);
/* harmony import */ var _Users_smartcommunitylab_Documents_work_projects_dslab_playgo_mobile_playgo_mobile_node_modules_babel_runtime_helpers_esm_classCallCheck_js__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ./node_modules/@babel/runtime/helpers/esm/classCallCheck.js */ 78069);
/* harmony import */ var _Users_smartcommunitylab_Documents_work_projects_dslab_playgo_mobile_playgo_mobile_node_modules_babel_runtime_helpers_esm_createClass_js__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! ./node_modules/@babel/runtime/helpers/esm/createClass.js */ 48047);
/* harmony import */ var _capacitor_app__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @capacitor/app */ 93253);
/* harmony import */ var rxjs__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! rxjs */ 36646);
/* harmony import */ var rxjs__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! rxjs */ 10745);
/* harmony import */ var rxjs__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(/*! rxjs */ 23280);
/* harmony import */ var rxjs__WEBPACK_IMPORTED_MODULE_9__ = __webpack_require__(/*! rxjs */ 89196);
/* harmony import */ var rxjs__WEBPACK_IMPORTED_MODULE_10__ = __webpack_require__(/*! rxjs */ 59346);
/* harmony import */ var rxjs__WEBPACK_IMPORTED_MODULE_11__ = __webpack_require__(/*! rxjs */ 26067);
/* harmony import */ var rxjs__WEBPACK_IMPORTED_MODULE_13__ = __webpack_require__(/*! rxjs */ 26562);
/* harmony import */ var rxjs_operators__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(/*! rxjs/operators */ 50635);
/* harmony import */ var rxjs_operators__WEBPACK_IMPORTED_MODULE_12__ = __webpack_require__(/*! rxjs/operators */ 32673);
/* harmony import */ var src_environments_environment__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! src/environments/environment */ 92340);
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_14__ = __webpack_require__(/*! @angular/core */ 3184);








var AppStatusService = /*#__PURE__*/function () {
  function AppStatusService(appPlugin, devicePlugin, codePushPlugin) {
    var _this = this;

    (0,_Users_smartcommunitylab_Documents_work_projects_dslab_playgo_mobile_playgo_mobile_node_modules_babel_runtime_helpers_esm_classCallCheck_js__WEBPACK_IMPORTED_MODULE_1__["default"])(this, AppStatusService);

    this.appPlugin = appPlugin;
    this.devicePlugin = devicePlugin;
    this.codePushPlugin = codePushPlugin;
    this.isOnline$ = (0,rxjs__WEBPACK_IMPORTED_MODULE_5__.merge)((0,rxjs__WEBPACK_IMPORTED_MODULE_6__.of)(navigator === null || navigator === void 0 ? void 0 : navigator.onLine), (0,rxjs__WEBPACK_IMPORTED_MODULE_7__.fromEvent)(window, 'online').pipe((0,rxjs_operators__WEBPACK_IMPORTED_MODULE_8__.map)(function () {
      return true;
    })), (0,rxjs__WEBPACK_IMPORTED_MODULE_7__.fromEvent)(window, 'offline').pipe((0,rxjs_operators__WEBPACK_IMPORTED_MODULE_8__.map)(function () {
      return false;
    }))).pipe((0,rxjs__WEBPACK_IMPORTED_MODULE_9__.shareReplay)(1));
    this.deviceInfo$ = (0,rxjs__WEBPACK_IMPORTED_MODULE_10__.from)(this.devicePlugin.getInfo()).pipe((0,rxjs__WEBPACK_IMPORTED_MODULE_9__.shareReplay)(1));
    this.appInfo$ = (0,rxjs__WEBPACK_IMPORTED_MODULE_10__.from)(this.appPlugin.getInfo()).pipe((0,rxjs__WEBPACK_IMPORTED_MODULE_9__.shareReplay)(1));
    this.version$ = this.appInfo$.pipe((0,rxjs_operators__WEBPACK_IMPORTED_MODULE_8__.map)(function (info) {
      return info.version;
    }));
    this.syncFinished$ = new rxjs__WEBPACK_IMPORTED_MODULE_11__.ReplaySubject(1);
    this.codePushLabel$ = this.syncFinished$.pipe((0,rxjs_operators__WEBPACK_IMPORTED_MODULE_12__.switchMap)(function () {
      return (0,rxjs__WEBPACK_IMPORTED_MODULE_13__.combineLatest)([_this.codePushPlugin.getCurrentPackage(), _this.codePushPlugin.getPendingPackage()]);
    }), (0,rxjs_operators__WEBPACK_IMPORTED_MODULE_8__.map)(function (_ref) {
      var _ref2 = (0,_Users_smartcommunitylab_Documents_work_projects_dslab_playgo_mobile_playgo_mobile_node_modules_babel_runtime_helpers_esm_slicedToArray_js__WEBPACK_IMPORTED_MODULE_0__["default"])(_ref, 2),
          currentPackage = _ref2[0],
          pendingPackage = _ref2[1];

      var hotCodePushLabel = '';

      if (!src_environments_environment__WEBPACK_IMPORTED_MODULE_4__.environment.useCodePush) {
        hotCodePushLabel = '(code push disabled)';
      } else {
        hotCodePushLabel = (currentPackage === null || currentPackage === void 0 ? void 0 : currentPackage.label) || '-';
      }

      var pendingPackageLabel = pendingPackage ? " (pending: ".concat(pendingPackage.label, ")") : '';
      return hotCodePushLabel + pendingPackageLabel;
    }));
  }

  (0,_Users_smartcommunitylab_Documents_work_projects_dslab_playgo_mobile_playgo_mobile_node_modules_babel_runtime_helpers_esm_createClass_js__WEBPACK_IMPORTED_MODULE_2__["default"])(AppStatusService, [{
    key: "codePushSyncFinished",
    value: function codePushSyncFinished() {
      this.syncFinished$.next();
    }
  }]);

  return AppStatusService;
}();

AppStatusService.ɵfac = function AppStatusService_Factory(t) {
  return new (t || AppStatusService)(_angular_core__WEBPACK_IMPORTED_MODULE_14__["ɵɵinject"]('AppPlugin'), _angular_core__WEBPACK_IMPORTED_MODULE_14__["ɵɵinject"]('DevicePlugin'), _angular_core__WEBPACK_IMPORTED_MODULE_14__["ɵɵinject"]('CodePushPlugin'));
};

AppStatusService.ɵprov = /*@__PURE__*/_angular_core__WEBPACK_IMPORTED_MODULE_14__["ɵɵdefineInjectable"]({
  token: AppStatusService,
  factory: AppStatusService.ɵfac,
  providedIn: 'root'
});

/***/ }),

/***/ 70891:
/*!*******************************************************!*\
  !*** ./src/app/core/shared/services/badge.service.ts ***!
  \*******************************************************/
/***/ (function(__unused_webpack_module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "BadgeService": function() { return /* binding */ BadgeService; }
/* harmony export */ });
/* harmony import */ var _Users_smartcommunitylab_Documents_work_projects_dslab_playgo_mobile_playgo_mobile_node_modules_babel_runtime_helpers_esm_classCallCheck_js__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./node_modules/@babel/runtime/helpers/esm/classCallCheck.js */ 78069);
/* harmony import */ var _Users_smartcommunitylab_Documents_work_projects_dslab_playgo_mobile_playgo_mobile_node_modules_babel_runtime_helpers_esm_createClass_js__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ./node_modules/@babel/runtime/helpers/esm/createClass.js */ 48047);
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_9__ = __webpack_require__(/*! tslib */ 34929);
/* harmony import */ var rxjs__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! rxjs */ 32673);
/* harmony import */ var rxjs__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(/*! rxjs */ 19337);
/* harmony import */ var rxjs__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(/*! rxjs */ 89196);
/* harmony import */ var rxjs__WEBPACK_IMPORTED_MODULE_10__ = __webpack_require__(/*! rxjs */ 54363);
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_11__ = __webpack_require__(/*! @angular/core */ 3184);
/* harmony import */ var _local_storage_service__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! ./local-storage.service */ 49397);
/* harmony import */ var _auth_auth_service__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! ../../auth/auth.service */ 88951);
/* harmony import */ var _api_generated_controllers_gameController_service__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! ../../api/generated/controllers/gameController.service */ 89903);
/* harmony import */ var _error_service__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! ./error.service */ 96204);



function _regeneratorRuntime() { "use strict"; /*! regenerator-runtime -- Copyright (c) 2014-present, Facebook, Inc. -- license (MIT): https://github.com/facebook/regenerator/blob/main/LICENSE */ _regeneratorRuntime = function _regeneratorRuntime() { return exports; }; var exports = {}, Op = Object.prototype, hasOwn = Op.hasOwnProperty, $Symbol = "function" == typeof Symbol ? Symbol : {}, iteratorSymbol = $Symbol.iterator || "@@iterator", asyncIteratorSymbol = $Symbol.asyncIterator || "@@asyncIterator", toStringTagSymbol = $Symbol.toStringTag || "@@toStringTag"; function define(obj, key, value) { return Object.defineProperty(obj, key, { value: value, enumerable: !0, configurable: !0, writable: !0 }), obj[key]; } try { define({}, ""); } catch (err) { define = function define(obj, key, value) { return obj[key] = value; }; } function wrap(innerFn, outerFn, self, tryLocsList) { var protoGenerator = outerFn && outerFn.prototype instanceof Generator ? outerFn : Generator, generator = Object.create(protoGenerator.prototype), context = new Context(tryLocsList || []); return generator._invoke = function (innerFn, self, context) { var state = "suspendedStart"; return function (method, arg) { if ("executing" === state) throw new Error("Generator is already running"); if ("completed" === state) { if ("throw" === method) throw arg; return doneResult(); } for (context.method = method, context.arg = arg;;) { var delegate = context.delegate; if (delegate) { var delegateResult = maybeInvokeDelegate(delegate, context); if (delegateResult) { if (delegateResult === ContinueSentinel) continue; return delegateResult; } } if ("next" === context.method) context.sent = context._sent = context.arg;else if ("throw" === context.method) { if ("suspendedStart" === state) throw state = "completed", context.arg; context.dispatchException(context.arg); } else "return" === context.method && context.abrupt("return", context.arg); state = "executing"; var record = tryCatch(innerFn, self, context); if ("normal" === record.type) { if (state = context.done ? "completed" : "suspendedYield", record.arg === ContinueSentinel) continue; return { value: record.arg, done: context.done }; } "throw" === record.type && (state = "completed", context.method = "throw", context.arg = record.arg); } }; }(innerFn, self, context), generator; } function tryCatch(fn, obj, arg) { try { return { type: "normal", arg: fn.call(obj, arg) }; } catch (err) { return { type: "throw", arg: err }; } } exports.wrap = wrap; var ContinueSentinel = {}; function Generator() {} function GeneratorFunction() {} function GeneratorFunctionPrototype() {} var IteratorPrototype = {}; define(IteratorPrototype, iteratorSymbol, function () { return this; }); var getProto = Object.getPrototypeOf, NativeIteratorPrototype = getProto && getProto(getProto(values([]))); NativeIteratorPrototype && NativeIteratorPrototype !== Op && hasOwn.call(NativeIteratorPrototype, iteratorSymbol) && (IteratorPrototype = NativeIteratorPrototype); var Gp = GeneratorFunctionPrototype.prototype = Generator.prototype = Object.create(IteratorPrototype); function defineIteratorMethods(prototype) { ["next", "throw", "return"].forEach(function (method) { define(prototype, method, function (arg) { return this._invoke(method, arg); }); }); } function AsyncIterator(generator, PromiseImpl) { function invoke(method, arg, resolve, reject) { var record = tryCatch(generator[method], generator, arg); if ("throw" !== record.type) { var result = record.arg, value = result.value; return value && "object" == typeof value && hasOwn.call(value, "__await") ? PromiseImpl.resolve(value.__await).then(function (value) { invoke("next", value, resolve, reject); }, function (err) { invoke("throw", err, resolve, reject); }) : PromiseImpl.resolve(value).then(function (unwrapped) { result.value = unwrapped, resolve(result); }, function (error) { return invoke("throw", error, resolve, reject); }); } reject(record.arg); } var previousPromise; this._invoke = function (method, arg) { function callInvokeWithMethodAndArg() { return new PromiseImpl(function (resolve, reject) { invoke(method, arg, resolve, reject); }); } return previousPromise = previousPromise ? previousPromise.then(callInvokeWithMethodAndArg, callInvokeWithMethodAndArg) : callInvokeWithMethodAndArg(); }; } function maybeInvokeDelegate(delegate, context) { var method = delegate.iterator[context.method]; if (undefined === method) { if (context.delegate = null, "throw" === context.method) { if (delegate.iterator.return && (context.method = "return", context.arg = undefined, maybeInvokeDelegate(delegate, context), "throw" === context.method)) return ContinueSentinel; context.method = "throw", context.arg = new TypeError("The iterator does not provide a 'throw' method"); } return ContinueSentinel; } var record = tryCatch(method, delegate.iterator, context.arg); if ("throw" === record.type) return context.method = "throw", context.arg = record.arg, context.delegate = null, ContinueSentinel; var info = record.arg; return info ? info.done ? (context[delegate.resultName] = info.value, context.next = delegate.nextLoc, "return" !== context.method && (context.method = "next", context.arg = undefined), context.delegate = null, ContinueSentinel) : info : (context.method = "throw", context.arg = new TypeError("iterator result is not an object"), context.delegate = null, ContinueSentinel); } function pushTryEntry(locs) { var entry = { tryLoc: locs[0] }; 1 in locs && (entry.catchLoc = locs[1]), 2 in locs && (entry.finallyLoc = locs[2], entry.afterLoc = locs[3]), this.tryEntries.push(entry); } function resetTryEntry(entry) { var record = entry.completion || {}; record.type = "normal", delete record.arg, entry.completion = record; } function Context(tryLocsList) { this.tryEntries = [{ tryLoc: "root" }], tryLocsList.forEach(pushTryEntry, this), this.reset(!0); } function values(iterable) { if (iterable) { var iteratorMethod = iterable[iteratorSymbol]; if (iteratorMethod) return iteratorMethod.call(iterable); if ("function" == typeof iterable.next) return iterable; if (!isNaN(iterable.length)) { var i = -1, next = function next() { for (; ++i < iterable.length;) { if (hasOwn.call(iterable, i)) return next.value = iterable[i], next.done = !1, next; } return next.value = undefined, next.done = !0, next; }; return next.next = next; } } return { next: doneResult }; } function doneResult() { return { value: undefined, done: !0 }; } return GeneratorFunction.prototype = GeneratorFunctionPrototype, define(Gp, "constructor", GeneratorFunctionPrototype), define(GeneratorFunctionPrototype, "constructor", GeneratorFunction), GeneratorFunction.displayName = define(GeneratorFunctionPrototype, toStringTagSymbol, "GeneratorFunction"), exports.isGeneratorFunction = function (genFun) { var ctor = "function" == typeof genFun && genFun.constructor; return !!ctor && (ctor === GeneratorFunction || "GeneratorFunction" === (ctor.displayName || ctor.name)); }, exports.mark = function (genFun) { return Object.setPrototypeOf ? Object.setPrototypeOf(genFun, GeneratorFunctionPrototype) : (genFun.__proto__ = GeneratorFunctionPrototype, define(genFun, toStringTagSymbol, "GeneratorFunction")), genFun.prototype = Object.create(Gp), genFun; }, exports.awrap = function (arg) { return { __await: arg }; }, defineIteratorMethods(AsyncIterator.prototype), define(AsyncIterator.prototype, asyncIteratorSymbol, function () { return this; }), exports.AsyncIterator = AsyncIterator, exports.async = function (innerFn, outerFn, self, tryLocsList, PromiseImpl) { void 0 === PromiseImpl && (PromiseImpl = Promise); var iter = new AsyncIterator(wrap(innerFn, outerFn, self, tryLocsList), PromiseImpl); return exports.isGeneratorFunction(outerFn) ? iter : iter.next().then(function (result) { return result.done ? result.value : iter.next(); }); }, defineIteratorMethods(Gp), define(Gp, toStringTagSymbol, "Generator"), define(Gp, iteratorSymbol, function () { return this; }), define(Gp, "toString", function () { return "[object Generator]"; }), exports.keys = function (object) { var keys = []; for (var key in object) { keys.push(key); } return keys.reverse(), function next() { for (; keys.length;) { var key = keys.pop(); if (key in object) return next.value = key, next.done = !1, next; } return next.done = !0, next; }; }, exports.values = values, Context.prototype = { constructor: Context, reset: function reset(skipTempReset) { if (this.prev = 0, this.next = 0, this.sent = this._sent = undefined, this.done = !1, this.delegate = null, this.method = "next", this.arg = undefined, this.tryEntries.forEach(resetTryEntry), !skipTempReset) for (var name in this) { "t" === name.charAt(0) && hasOwn.call(this, name) && !isNaN(+name.slice(1)) && (this[name] = undefined); } }, stop: function stop() { this.done = !0; var rootRecord = this.tryEntries[0].completion; if ("throw" === rootRecord.type) throw rootRecord.arg; return this.rval; }, dispatchException: function dispatchException(exception) { if (this.done) throw exception; var context = this; function handle(loc, caught) { return record.type = "throw", record.arg = exception, context.next = loc, caught && (context.method = "next", context.arg = undefined), !!caught; } for (var i = this.tryEntries.length - 1; i >= 0; --i) { var entry = this.tryEntries[i], record = entry.completion; if ("root" === entry.tryLoc) return handle("end"); if (entry.tryLoc <= this.prev) { var hasCatch = hasOwn.call(entry, "catchLoc"), hasFinally = hasOwn.call(entry, "finallyLoc"); if (hasCatch && hasFinally) { if (this.prev < entry.catchLoc) return handle(entry.catchLoc, !0); if (this.prev < entry.finallyLoc) return handle(entry.finallyLoc); } else if (hasCatch) { if (this.prev < entry.catchLoc) return handle(entry.catchLoc, !0); } else { if (!hasFinally) throw new Error("try statement without catch or finally"); if (this.prev < entry.finallyLoc) return handle(entry.finallyLoc); } } } }, abrupt: function abrupt(type, arg) { for (var i = this.tryEntries.length - 1; i >= 0; --i) { var entry = this.tryEntries[i]; if (entry.tryLoc <= this.prev && hasOwn.call(entry, "finallyLoc") && this.prev < entry.finallyLoc) { var finallyEntry = entry; break; } } finallyEntry && ("break" === type || "continue" === type) && finallyEntry.tryLoc <= arg && arg <= finallyEntry.finallyLoc && (finallyEntry = null); var record = finallyEntry ? finallyEntry.completion : {}; return record.type = type, record.arg = arg, finallyEntry ? (this.method = "next", this.next = finallyEntry.finallyLoc, ContinueSentinel) : this.complete(record); }, complete: function complete(record, afterLoc) { if ("throw" === record.type) throw record.arg; return "break" === record.type || "continue" === record.type ? this.next = record.arg : "return" === record.type ? (this.rval = this.arg = record.arg, this.method = "return", this.next = "end") : "normal" === record.type && afterLoc && (this.next = afterLoc), ContinueSentinel; }, finish: function finish(finallyLoc) { for (var i = this.tryEntries.length - 1; i >= 0; --i) { var entry = this.tryEntries[i]; if (entry.finallyLoc === finallyLoc) return this.complete(entry.completion, entry.afterLoc), resetTryEntry(entry), ContinueSentinel; } }, catch: function _catch(tryLoc) { for (var i = this.tryEntries.length - 1; i >= 0; --i) { var entry = this.tryEntries[i]; if (entry.tryLoc === tryLoc) { var record = entry.completion; if ("throw" === record.type) { var thrown = record.arg; resetTryEntry(entry); } return thrown; } } throw new Error("illegal catch attempt"); }, delegateYield: function delegateYield(iterable, resultName, nextLoc) { return this.delegate = { iterator: values(iterable), resultName: resultName, nextLoc: nextLoc }, "next" === this.method && (this.arg = undefined), ContinueSentinel; } }, exports; }








var BadgeService = /*#__PURE__*/function () {
  function BadgeService(localStorageService, authService, gameControllerService, errorService) {
    var _this = this;

    (0,_Users_smartcommunitylab_Documents_work_projects_dslab_playgo_mobile_playgo_mobile_node_modules_babel_runtime_helpers_esm_classCallCheck_js__WEBPACK_IMPORTED_MODULE_0__["default"])(this, BadgeService);

    this.localStorageService = localStorageService;
    this.authService = authService;
    this.gameControllerService = gameControllerService;
    this.errorService = errorService;
    this.allBadgesStorage = this.localStorageService.getStorageOf('allBadges');
    this.allBadges$ = this.authService.isReadyForApi$.pipe((0,rxjs__WEBPACK_IMPORTED_MODULE_6__.switchMap)(function () {
      return _this.allBadgesStorage.getMeta();
    }), (0,rxjs__WEBPACK_IMPORTED_MODULE_6__.switchMap)(function (_ref) {
      var lastUpdated = _ref.lastUpdated;
      return _this.checkIfStoredBadgesAreUpToDate(lastUpdated) ? _this.allBadgesStorage.get() : _this.gameControllerService.getAllBadgesUsingGET().pipe((0,rxjs__WEBPACK_IMPORTED_MODULE_7__.tap)(function (badges) {
        return _this.allBadgesStorage.set(badges);
      }), _this.errorService.getErrorHandler('silent'));
    }), (0,rxjs__WEBPACK_IMPORTED_MODULE_8__.shareReplay)(1));
  }

  (0,_Users_smartcommunitylab_Documents_work_projects_dslab_playgo_mobile_playgo_mobile_node_modules_babel_runtime_helpers_esm_createClass_js__WEBPACK_IMPORTED_MODULE_1__["default"])(BadgeService, [{
    key: "init",
    value: function init() {
      // run api call as soon as possible
      this.allBadges$.subscribe();
    } // call api only once per week

  }, {
    key: "checkIfStoredBadgesAreUpToDate",
    value: function checkIfStoredBadgesAreUpToDate(lastUpdated) {
      var oneWeek = 1000 * 60 * 60 * 24 * 7;
      return lastUpdated + oneWeek > new Date().getTime();
    }
  }, {
    key: "getBadgeByKey",
    value: function getBadgeByKey(key) {
      return (0,tslib__WEBPACK_IMPORTED_MODULE_9__.__awaiter)(this, void 0, void 0, /*#__PURE__*/_regeneratorRuntime().mark(function _callee() {
        var allBadges;
        return _regeneratorRuntime().wrap(function _callee$(_context) {
          while (1) {
            switch (_context.prev = _context.next) {
              case 0:
                _context.next = 2;
                return (0,rxjs__WEBPACK_IMPORTED_MODULE_10__.firstValueFrom)(this.allBadges$);

              case 2:
                allBadges = _context.sent;
                return _context.abrupt("return", allBadges[key]);

              case 4:
              case "end":
                return _context.stop();
            }
          }
        }, _callee, this);
      }));
    }
  }]);

  return BadgeService;
}();

BadgeService.ɵfac = function BadgeService_Factory(t) {
  return new (t || BadgeService)(_angular_core__WEBPACK_IMPORTED_MODULE_11__["ɵɵinject"](_local_storage_service__WEBPACK_IMPORTED_MODULE_2__.LocalStorageService), _angular_core__WEBPACK_IMPORTED_MODULE_11__["ɵɵinject"](_auth_auth_service__WEBPACK_IMPORTED_MODULE_3__.AuthService), _angular_core__WEBPACK_IMPORTED_MODULE_11__["ɵɵinject"](_api_generated_controllers_gameController_service__WEBPACK_IMPORTED_MODULE_4__.GameControllerService), _angular_core__WEBPACK_IMPORTED_MODULE_11__["ɵɵinject"](_error_service__WEBPACK_IMPORTED_MODULE_5__.ErrorService));
};

BadgeService.ɵprov = /*@__PURE__*/_angular_core__WEBPACK_IMPORTED_MODULE_11__["ɵɵdefineInjectable"]({
  token: BadgeService,
  factory: BadgeService.ɵfac,
  providedIn: 'root'
});

/***/ }),

/***/ 23645:
/*!**********************************************************!*\
  !*** ./src/app/core/shared/services/campaign.service.ts ***!
  \**********************************************************/
/***/ (function(__unused_webpack_module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "CampaignService": function() { return /* binding */ CampaignService; }
/* harmony export */ });
/* harmony import */ var _Users_smartcommunitylab_Documents_work_projects_dslab_playgo_mobile_playgo_mobile_node_modules_babel_runtime_helpers_esm_classCallCheck_js__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./node_modules/@babel/runtime/helpers/esm/classCallCheck.js */ 78069);
/* harmony import */ var _Users_smartcommunitylab_Documents_work_projects_dslab_playgo_mobile_playgo_mobile_node_modules_babel_runtime_helpers_esm_createClass_js__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ./node_modules/@babel/runtime/helpers/esm/createClass.js */ 48047);
/* harmony import */ var lodash_es__WEBPACK_IMPORTED_MODULE_18__ = __webpack_require__(/*! lodash-es */ 63247);
/* harmony import */ var rxjs__WEBPACK_IMPORTED_MODULE_12__ = __webpack_require__(/*! rxjs */ 26067);
/* harmony import */ var rxjs__WEBPACK_IMPORTED_MODULE_13__ = __webpack_require__(/*! rxjs */ 36646);
/* harmony import */ var rxjs__WEBPACK_IMPORTED_MODULE_16__ = __webpack_require__(/*! rxjs */ 10745);
/* harmony import */ var rxjs__WEBPACK_IMPORTED_MODULE_20__ = __webpack_require__(/*! rxjs */ 80228);
/* harmony import */ var rxjs_operators__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(/*! rxjs/operators */ 60116);
/* harmony import */ var rxjs_operators__WEBPACK_IMPORTED_MODULE_9__ = __webpack_require__(/*! rxjs/operators */ 80155);
/* harmony import */ var rxjs_operators__WEBPACK_IMPORTED_MODULE_10__ = __webpack_require__(/*! rxjs/operators */ 32673);
/* harmony import */ var rxjs_operators__WEBPACK_IMPORTED_MODULE_11__ = __webpack_require__(/*! rxjs/operators */ 89196);
/* harmony import */ var rxjs_operators__WEBPACK_IMPORTED_MODULE_14__ = __webpack_require__(/*! rxjs/operators */ 44874);
/* harmony import */ var rxjs_operators__WEBPACK_IMPORTED_MODULE_15__ = __webpack_require__(/*! rxjs/operators */ 53158);
/* harmony import */ var rxjs_operators__WEBPACK_IMPORTED_MODULE_17__ = __webpack_require__(/*! rxjs/operators */ 98977);
/* harmony import */ var rxjs_operators__WEBPACK_IMPORTED_MODULE_19__ = __webpack_require__(/*! rxjs/operators */ 19337);
/* harmony import */ var rxjs_operators__WEBPACK_IMPORTED_MODULE_21__ = __webpack_require__(/*! rxjs/operators */ 50635);
/* harmony import */ var src_environments_environment__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! src/environments/environment */ 92340);
/* harmony import */ var _utils__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! ../utils */ 68647);
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_22__ = __webpack_require__(/*! @angular/core */ 3184);
/* harmony import */ var _user_service__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! ./user.service */ 50749);
/* harmony import */ var _api_generated_controllers_campaignController_service__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! ../../api/generated/controllers/campaignController.service */ 66846);
/* harmony import */ var _local_storage_service__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! ./local-storage.service */ 49397);
/* harmony import */ var _angular_common_http__WEBPACK_IMPORTED_MODULE_23__ = __webpack_require__(/*! @angular/common/http */ 28784);
/* harmony import */ var _error_service__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(/*! ./error.service */ 96204);













var CampaignService = /*#__PURE__*/function () {
  function CampaignService(userService, campaignControllerService, localStorageService, http, errorService) {
    var _this = this;

    (0,_Users_smartcommunitylab_Documents_work_projects_dslab_playgo_mobile_playgo_mobile_node_modules_babel_runtime_helpers_esm_classCallCheck_js__WEBPACK_IMPORTED_MODULE_0__["default"])(this, CampaignService);

    this.userService = userService;
    this.campaignControllerService = campaignControllerService;
    this.localStorageService = localStorageService;
    this.http = http;
    this.errorService = errorService;
    this.initialUserProfile$ = this.userService.userProfile$.pipe((0,rxjs_operators__WEBPACK_IMPORTED_MODULE_8__.filter)(function (profile) {
      return profile !== null;
    }), (0,rxjs_operators__WEBPACK_IMPORTED_MODULE_9__.first)());
    this.allCampaigns$ = this.initialUserProfile$.pipe((0,rxjs_operators__WEBPACK_IMPORTED_MODULE_10__.switchMap)(function (_ref) {
      var territoryId = _ref.territoryId;
      return _this.campaignControllerService.getCampaignsUsingGET({
        territoryId: territoryId
      });
    }), (0,rxjs_operators__WEBPACK_IMPORTED_MODULE_11__.shareReplay)(1));
    this.playerCampaignUnSubscribed$ = new rxjs__WEBPACK_IMPORTED_MODULE_12__.ReplaySubject(1);
    this.playerCampaignSubscribed$ = new rxjs__WEBPACK_IMPORTED_MODULE_12__.ReplaySubject(1);
    this.playerCampaignsRefresher$ = new rxjs__WEBPACK_IMPORTED_MODULE_12__.ReplaySubject(1);
    this.campaignsCouldBeChanged$ = (0,rxjs__WEBPACK_IMPORTED_MODULE_13__.merge)(this.initialUserProfile$, this.playerCampaignSubscribed$, this.playerCampaignUnSubscribed$, this.playerCampaignsRefresher$).pipe((0,rxjs_operators__WEBPACK_IMPORTED_MODULE_14__.startWith)(null));
    this.myCampaignsStorage = this.localStorageService.getStorageOf('myCampaigns');
    this.myCampaigns$ = this.campaignsCouldBeChanged$.pipe((0,rxjs_operators__WEBPACK_IMPORTED_MODULE_10__.switchMap)(function () {
      return _this.campaignControllerService.getMyCampaignsUsingGET().pipe((0,_utils__WEBPACK_IMPORTED_MODULE_3__.ifOfflineUseStored)(_this.myCampaignsStorage), // this is not recoverable, app is bricked...
      // for example new campaign subscription could be added successfully, but
      // server could not return the list of my campaigns, data integrity is broken,
      // but problem when new user, in that case error is 500
      (0,rxjs_operators__WEBPACK_IMPORTED_MODULE_15__.catchError)(function (error) {
        var isErrorExpected = true; // TODO:

        _this.errorService.handleError(error, isErrorExpected ? 'silent' : 'blocking');

        return (0,rxjs__WEBPACK_IMPORTED_MODULE_16__.of)([]);
      }));
    }), (0,rxjs_operators__WEBPACK_IMPORTED_MODULE_17__.distinctUntilChanged)(lodash_es__WEBPACK_IMPORTED_MODULE_18__["default"]), (0,rxjs_operators__WEBPACK_IMPORTED_MODULE_19__.tap)(function (myCampaigns) {
      return _this.myCampaignsStorage.set(myCampaigns);
    }), (0,rxjs_operators__WEBPACK_IMPORTED_MODULE_11__.shareReplay)(1));
    this.mapFunctionalities = {
      personal: {
        challenge: {
          present: false
        },
        prizes: {
          present: false
        },
        leaderboard: {
          present: true
        },
        blacklist: {
          present: false
        },
        stats: {
          present: true
        },
        badges: {
          present: false
        }
      },
      school: {
        challenge: {
          present: false
        },
        prizes: {
          present: true
        },
        leaderboard: {
          present: true,
          api: 'https://hscdev.playngo.it/playandgo-hsc/publicapi'
        },
        blacklist: {
          present: true
        },
        stats: {
          present: true
        },
        badges: {
          present: true
        }
      },
      company: {
        challenge: {
          present: false
        },
        prizes: {
          present: true
        },
        leaderboard: {
          present: false
        },
        blacklist: {
          present: false
        },
        stats: {
          present: true
        },
        badges: {
          present: false
        }
      },
      city: {
        challenge: {
          present: true
        },
        prizes: {
          present: true
        },
        leaderboard: {
          present: true
        },
        blacklist: {
          present: true
        },
        stats: {
          present: true
        },
        badges: {
          present: true
        }
      }
    };
    this.subscribeCampaignAction$ = new rxjs__WEBPACK_IMPORTED_MODULE_20__.Subject();
    this.unsubscribeCampaignAction$ = new rxjs__WEBPACK_IMPORTED_MODULE_20__.Subject();
  }

  (0,_Users_smartcommunitylab_Documents_work_projects_dslab_playgo_mobile_playgo_mobile_node_modules_babel_runtime_helpers_esm_createClass_js__WEBPACK_IMPORTED_MODULE_1__["default"])(CampaignService, [{
    key: "subscribeToCampaign",
    value: function subscribeToCampaign(id, body) {
      var _this2 = this;

      //update my campaign list
      return this.campaignControllerService.subscribeCampaignUsingPOST({
        campaignId: id,
        body: body
      }).pipe((0,rxjs_operators__WEBPACK_IMPORTED_MODULE_21__.map)(function (res) {
        _this2.subscribeCampaignAction$.next(id);

        _this2.playerCampaignSubscribed$.next(null);

        return res;
      }));
    }
  }, {
    key: "unsubscribeCampaign",
    value: function unsubscribeCampaign(id) {
      var _this3 = this;

      //update my campaign list
      return this.campaignControllerService.unsubscribeCampaignUsingPUT(id).pipe((0,rxjs_operators__WEBPACK_IMPORTED_MODULE_21__.map)(function (res) {
        _this3.unsubscribeCampaignAction$.next(id);

        _this3.playerCampaignUnSubscribed$.next(null);

        return res;
      }));
    }
  }, {
    key: "getCampaignDetailsById",
    value: function getCampaignDetailsById(id) {
      return this.campaignControllerService.getCampaignUsingGET(id);
    }
  }, {
    key: "getCampaignByPlayerId",
    value: function getCampaignByPlayerId(id) {
      return this.campaignControllerService.getCampaignsByPlayerUsingGET(id);
    }
  }, {
    key: "getCompaniesForSubscription",
    value: function getCompaniesForSubscription(campaignId) {
      return this.http.request('get', src_environments_environment__WEBPACK_IMPORTED_MODULE_2__.environment.serverUrl.pgaziendeUrl + "/campaigns/".concat(encodeURIComponent(String(campaignId)), "/companies"), {});
    }
  }, {
    key: "getPersonalCampaign",
    value: function getPersonalCampaign() {
      return this.myCampaigns$.pipe((0,rxjs_operators__WEBPACK_IMPORTED_MODULE_21__.map)(function (campaigns) {
        return campaigns.find(function (campaign) {
          var _a;

          return ((_a = campaign === null || campaign === void 0 ? void 0 : campaign.campaign) === null || _a === void 0 ? void 0 : _a.type) === 'personal';
        });
      }), (0,rxjs_operators__WEBPACK_IMPORTED_MODULE_11__.shareReplay)(1));
    }
    /** returns ionic "color". For example "danger" */

  }, {
    key: "getCampaignColor",
    value: function getCampaignColor(campaign) {
      if (!campaign) {
        return null;
      }

      return campaign.type;
    }
    /** returns app icon name. For example "leaf" */

  }, {
    key: "getCampaignTypeIcon",
    value: function getCampaignTypeIcon(campaign) {
      if (!campaign) {
        return null;
      }

      if (campaign.type === 'city') {
        return 'flower';
      }

      if (campaign.type === 'company') {
        return 'pedal_bike';
      }

      if (campaign.type === 'school') {
        return 'shield';
      }

      if (campaign.type === 'personal') {
        return 'co2';
      }
    }
    /** returns app-icon name. For example "flower" */

  }, {
    key: "getCampaignScoreIcon",
    value: function getCampaignScoreIcon(campaign) {
      if (!campaign) {
        return null;
      }

      if (campaign.type === 'city') {
        return 'flower';
      }

      if (campaign.type === 'school') {
        return 'shield';
      }

      return null;
    }
  }, {
    key: "getCampaignScoreLabel",
    value: function getCampaignScoreLabel(campaign) {
      if (!campaign) {
        return null;
      }

      if (campaign.type === 'city') {
        return 'campaigns.score_label.flower';
      }

      if (campaign.type === 'school') {
        return 'campaigns.score_label.shield';
      }

      return null;
    }
  }, {
    key: "getFunctionalityByType",
    value: function getFunctionalityByType(what, type) {
      var _a;

      if (!what || !type) {
        return null;
      }

      return (_a = this.mapFunctionalities[type]) === null || _a === void 0 ? void 0 : _a[what];
    }
  }]);

  return CampaignService;
}();

CampaignService.ɵfac = function CampaignService_Factory(t) {
  return new (t || CampaignService)(_angular_core__WEBPACK_IMPORTED_MODULE_22__["ɵɵinject"](_user_service__WEBPACK_IMPORTED_MODULE_4__.UserService), _angular_core__WEBPACK_IMPORTED_MODULE_22__["ɵɵinject"](_api_generated_controllers_campaignController_service__WEBPACK_IMPORTED_MODULE_5__.CampaignControllerService), _angular_core__WEBPACK_IMPORTED_MODULE_22__["ɵɵinject"](_local_storage_service__WEBPACK_IMPORTED_MODULE_6__.LocalStorageService), _angular_core__WEBPACK_IMPORTED_MODULE_22__["ɵɵinject"](_angular_common_http__WEBPACK_IMPORTED_MODULE_23__.HttpClient), _angular_core__WEBPACK_IMPORTED_MODULE_22__["ɵɵinject"](_error_service__WEBPACK_IMPORTED_MODULE_7__.ErrorService));
};

CampaignService.ɵprov = /*@__PURE__*/_angular_core__WEBPACK_IMPORTED_MODULE_22__["ɵɵdefineInjectable"]({
  token: CampaignService,
  factory: CampaignService.ɵfac,
  providedIn: 'root'
});

/***/ }),

/***/ 66324:
/*!***********************************************************!*\
  !*** ./src/app/core/shared/services/challenge.service.ts ***!
  \***********************************************************/
/***/ (function(__unused_webpack_module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "ChallengeService": function() { return /* binding */ ChallengeService; }
/* harmony export */ });
/* harmony import */ var _Users_smartcommunitylab_Documents_work_projects_dslab_playgo_mobile_playgo_mobile_node_modules_babel_runtime_helpers_esm_slicedToArray_js__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./node_modules/@babel/runtime/helpers/esm/slicedToArray.js */ 10507);
/* harmony import */ var _Users_smartcommunitylab_Documents_work_projects_dslab_playgo_mobile_playgo_mobile_node_modules_babel_runtime_helpers_esm_classCallCheck_js__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ./node_modules/@babel/runtime/helpers/esm/classCallCheck.js */ 78069);
/* harmony import */ var _Users_smartcommunitylab_Documents_work_projects_dslab_playgo_mobile_playgo_mobile_node_modules_babel_runtime_helpers_esm_createClass_js__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! ./node_modules/@babel/runtime/helpers/esm/createClass.js */ 48047);
/* harmony import */ var lodash_es__WEBPACK_IMPORTED_MODULE_13__ = __webpack_require__(/*! lodash-es */ 22109);
/* harmony import */ var rxjs__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! rxjs */ 50635);
/* harmony import */ var rxjs__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(/*! rxjs */ 89196);
/* harmony import */ var rxjs__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(/*! rxjs */ 26067);
/* harmony import */ var rxjs__WEBPACK_IMPORTED_MODULE_9__ = __webpack_require__(/*! rxjs */ 36646);
/* harmony import */ var rxjs__WEBPACK_IMPORTED_MODULE_10__ = __webpack_require__(/*! rxjs */ 10538);
/* harmony import */ var rxjs__WEBPACK_IMPORTED_MODULE_11__ = __webpack_require__(/*! rxjs */ 32673);
/* harmony import */ var rxjs__WEBPACK_IMPORTED_MODULE_12__ = __webpack_require__(/*! rxjs */ 91640);
/* harmony import */ var rxjs__WEBPACK_IMPORTED_MODULE_14__ = __webpack_require__(/*! rxjs */ 53158);
/* harmony import */ var rxjs__WEBPACK_IMPORTED_MODULE_15__ = __webpack_require__(/*! rxjs */ 10745);
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_16__ = __webpack_require__(/*! @angular/core */ 3184);
/* harmony import */ var _campaign_service__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! ./campaign.service */ 23645);
/* harmony import */ var _api_generated_controllers_challengeController_service__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! ../../api/generated/controllers/challengeController.service */ 74458);
/* harmony import */ var _error_service__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! ./error.service */ 96204);









var ChallengeService = /*#__PURE__*/function () {
  function ChallengeService(campaignService, challengeControllerService, errorService) {
    var _this = this;

    (0,_Users_smartcommunitylab_Documents_work_projects_dslab_playgo_mobile_playgo_mobile_node_modules_babel_runtime_helpers_esm_classCallCheck_js__WEBPACK_IMPORTED_MODULE_1__["default"])(this, ChallengeService);

    this.campaignService = campaignService;
    this.challengeControllerService = challengeControllerService;
    this.errorService = errorService;
    this.campaignsWithChallenges$ = this.campaignService.myCampaigns$.pipe((0,rxjs__WEBPACK_IMPORTED_MODULE_6__.map)(function (campaigns) {
      return (// TODO: ask if the condition is correct
        campaigns.filter(function (campaign) {
          return campaign.campaign.type === 'city' || campaign.campaign.type === 'school';
        })
      );
    }), (0,rxjs__WEBPACK_IMPORTED_MODULE_7__.shareReplay)(1));
    this.challengesRefresher$ = new rxjs__WEBPACK_IMPORTED_MODULE_8__.ReplaySubject(1);
    this.challengesCouldBeChanged$ = (0,rxjs__WEBPACK_IMPORTED_MODULE_9__.merge)(this.campaignsWithChallenges$, this.challengesRefresher$).pipe((0,rxjs__WEBPACK_IMPORTED_MODULE_10__.withLatestFrom)(this.campaignsWithChallenges$));
    this.canInvite$ = this.campaignsWithChallenges$.pipe((0,rxjs__WEBPACK_IMPORTED_MODULE_11__.switchMap)(function (campaigns) {
      return (0,rxjs__WEBPACK_IMPORTED_MODULE_12__.forkJoin)(campaigns.map(function (campaign) {
        return _this.challengeControllerService.getChallengesUsingGET({
          campaignId: campaign.campaign.campaignId
        }).pipe(_this.errorService.getErrorHandler('silent'), (0,rxjs__WEBPACK_IMPORTED_MODULE_6__.map)(function (response) {
          return _this.processResponseForCanInvite(response, campaign);
        }));
      })).pipe((0,rxjs__WEBPACK_IMPORTED_MODULE_6__.map)(function (challengesPerCampaign) {
        return (0,lodash_es__WEBPACK_IMPORTED_MODULE_13__["default"])(challengesPerCampaign);
      }));
    })).pipe((0,rxjs__WEBPACK_IMPORTED_MODULE_7__.shareReplay)(1));
    this.allChallenges$ = this.challengesCouldBeChanged$.pipe((0,rxjs__WEBPACK_IMPORTED_MODULE_11__.switchMap)(function (_ref) {
      var _ref2 = (0,_Users_smartcommunitylab_Documents_work_projects_dslab_playgo_mobile_playgo_mobile_node_modules_babel_runtime_helpers_esm_slicedToArray_js__WEBPACK_IMPORTED_MODULE_0__["default"])(_ref, 2),
          refresh = _ref2[0],
          campaigns = _ref2[1];

      return (0,rxjs__WEBPACK_IMPORTED_MODULE_12__.forkJoin)(campaigns.map(function (campaign) {
        console.log(campaign);

        if (campaign === null || campaign === void 0 ? void 0 : campaign.campaign) {
          return _this.challengeControllerService.getChallengesUsingGET({
            campaignId: campaign.campaign.campaignId
          }).pipe((0,rxjs__WEBPACK_IMPORTED_MODULE_14__.catchError)(function (error) {
            _this.errorService.handleError(error, 'silent');

            return (0,rxjs__WEBPACK_IMPORTED_MODULE_15__.of)(null);
          }), (0,rxjs__WEBPACK_IMPORTED_MODULE_6__.map)(function (response) {
            return _this.processResponseForOneCampaign(response, campaign);
          }));
        } else {
          return (0,rxjs__WEBPACK_IMPORTED_MODULE_15__.of)(null);
        }
      })).pipe((0,rxjs__WEBPACK_IMPORTED_MODULE_6__.map)(function (challengesPerCampaign) {
        return (0,lodash_es__WEBPACK_IMPORTED_MODULE_13__["default"])(challengesPerCampaign);
      }));
    })).pipe((0,rxjs__WEBPACK_IMPORTED_MODULE_7__.shareReplay)(1)); // public allChallenges$: Observable<Challenge[]> = this.campaignsWithChallenges$
    //   .pipe(
    //     switchMap((campaigns) =>
    //       forkJoin(
    //         campaigns.map((campaign) =>
    //           this.challengeControllerService
    //             .getChallengesUsingGET({
    //               campaignId: campaign.campaign.campaignId,
    //             })
    //             .pipe(
    //               this.errorService.getErrorHandler(),
    //               map((response) =>
    //                 this.processResponseForOneCampaign(response, campaign)
    //               )
    //             )
    //         )
    //       ).pipe(map((challengesPerCampaign) => flatten(challengesPerCampaign)))
    //     )
    //   )
    //   .pipe(shareReplay(1));

    this.activeChallenges$ = this.allChallenges$.pipe((0,rxjs__WEBPACK_IMPORTED_MODULE_6__.map)(function (challenges) {
      return challenges.filter(function (challenge) {
        return challenge.challengeType === 'ACTIVE';
      });
    }), (0,rxjs__WEBPACK_IMPORTED_MODULE_7__.shareReplay)(1));
    this.pastChallenges$ = this.allChallenges$.pipe((0,rxjs__WEBPACK_IMPORTED_MODULE_6__.map)(function (challenges) {
      return challenges.filter(function (challenge) {
        return challenge.challengeType === 'OLD';
      });
    }), (0,rxjs__WEBPACK_IMPORTED_MODULE_7__.shareReplay)(1));
    this.futureChallenges$ = this.allChallenges$.pipe((0,rxjs__WEBPACK_IMPORTED_MODULE_6__.map)(function (challenges) {
      return challenges.filter(function (challenge) {
        return challenge.challengeType === 'FUTURE' || challenge.challengeType === 'PROPOSED';
      });
    }, (0,rxjs__WEBPACK_IMPORTED_MODULE_7__.shareReplay)(1)));
  }

  (0,_Users_smartcommunitylab_Documents_work_projects_dslab_playgo_mobile_playgo_mobile_node_modules_babel_runtime_helpers_esm_createClass_js__WEBPACK_IMPORTED_MODULE_2__["default"])(ChallengeService, [{
    key: "processResponseForOneCampaign",
    value: function processResponseForOneCampaign(response, campaign) {
      if (response) {
        var challengesOfAllTypesPerOneCampaign = Object.entries(response.challengeData).flatMap(function (_ref3) {
          var _ref4 = (0,_Users_smartcommunitylab_Documents_work_projects_dslab_playgo_mobile_playgo_mobile_node_modules_babel_runtime_helpers_esm_slicedToArray_js__WEBPACK_IMPORTED_MODULE_0__["default"])(_ref3, 2),
              challengeType = _ref4[0],
              challenges = _ref4[1];

          return challenges.map(function (challenge) {
            return Object.assign(Object.assign({}, challenge), {
              challengeType: challengeType,
              campaign: campaign.campaign
            });
          });
        });
        return challengesOfAllTypesPerOneCampaign;
      } else {
        return [];
      }
    }
  }, {
    key: "processResponseForCanInvite",
    value: function processResponseForCanInvite(response, campaign) {
      return {
        canInvite: response.canInvite,
        campaign: campaign.campaign
      };
    }
  }, {
    key: "getChallengeStats",
    value: function getChallengeStats(arg0) {
      return this.challengeControllerService.getChallengeStatsUsingGET(arg0);
    }
  }, {
    key: "getAllChallengesByCampaign",
    value: function getAllChallengesByCampaign(campaignId) {
      return this.allChallenges$.pipe((0,rxjs__WEBPACK_IMPORTED_MODULE_6__.map)(function (challenges) {
        return challenges.filter(function (challenge) {
          var _a;

          return ((_a = challenge === null || challenge === void 0 ? void 0 : challenge.campaign) === null || _a === void 0 ? void 0 : _a.campaignId) === campaignId;
        });
      }), (0,rxjs__WEBPACK_IMPORTED_MODULE_7__.shareReplay)(1));
    }
  }, {
    key: "getBlacklistByCampaign",
    value: function getBlacklistByCampaign(campaignId) {
      return this.challengeControllerService.getBlackListUsingGET(campaignId);
    }
  }, {
    key: "getActiveChallengesByCampaign",
    value: function getActiveChallengesByCampaign(campaignId) {
      return this.activeChallenges$.pipe((0,rxjs__WEBPACK_IMPORTED_MODULE_6__.map)(function (challenges) {
        return challenges.filter(function (challenge) {
          var _a;

          return ((_a = challenge === null || challenge === void 0 ? void 0 : challenge.campaign) === null || _a === void 0 ? void 0 : _a.campaignId) === campaignId;
        });
      }), (0,rxjs__WEBPACK_IMPORTED_MODULE_7__.shareReplay)(1));
    }
  }, {
    key: "getPastChallengesByCampaign",
    value: function getPastChallengesByCampaign(campaignId) {
      return this.pastChallenges$.pipe((0,rxjs__WEBPACK_IMPORTED_MODULE_6__.map)(function (challenges) {
        return challenges.filter(function (challenge) {
          var _a;

          return ((_a = challenge === null || challenge === void 0 ? void 0 : challenge.campaign) === null || _a === void 0 ? void 0 : _a.campaignId) === campaignId;
        });
      }), (0,rxjs__WEBPACK_IMPORTED_MODULE_7__.shareReplay)(1));
    }
  }, {
    key: "getFutureChallengesByCampaign",
    value: function getFutureChallengesByCampaign(campaignId) {
      return this.futureChallenges$.pipe((0,rxjs__WEBPACK_IMPORTED_MODULE_6__.map)(function (challenges) {
        return challenges.filter(function (challenge) {
          var _a;

          return ((_a = challenge === null || challenge === void 0 ? void 0 : challenge.campaign) === null || _a === void 0 ? void 0 : _a.campaignId) === campaignId;
        });
      }), (0,rxjs__WEBPACK_IMPORTED_MODULE_7__.shareReplay)(1));
    }
  }, {
    key: "removeBlacklist",
    value: function removeBlacklist(campaignId, playerId) {
      return this.challengeControllerService.deleteFromBlackListUsingDELETE({
        campaignId: campaignId,
        blockedPlayerId: playerId
      }).toPromise();
    }
  }, {
    key: "addBlacklist",
    value: function addBlacklist(campaignId, playerId) {
      return this.challengeControllerService.addToBlackListUsingPOST({
        campaignId: campaignId,
        blockedPlayerId: playerId
      }).toPromise();
    }
  }, {
    key: "acceptChallenge",
    value: function acceptChallenge(campaign, challenge) {
      this.challengeControllerService.changeInvitationStatusUsingPOST({
        campaignId: campaign.campaign.campaignId,
        challengeName: challenge.challId,
        status: 'accept'
      }).toPromise();
    }
  }, {
    key: "rejectChallenge",
    value: function rejectChallenge(campaign, challenge) {
      this.challengeControllerService.changeInvitationStatusUsingPOST({
        campaignId: campaign.campaign.campaignId,
        challengeName: challenge.challId,
        status: 'refuse'
      }).toPromise();
    }
  }, {
    key: "cancelChallenge",
    value: function cancelChallenge(campaign, challenge) {
      this.challengeControllerService.changeInvitationStatusUsingPOST({
        campaignId: campaign.campaign.campaignId,
        challengeName: challenge.challId,
        status: 'cancel'
      }).toPromise();
    }
  }]);

  return ChallengeService;
}();

ChallengeService.ɵfac = function ChallengeService_Factory(t) {
  return new (t || ChallengeService)(_angular_core__WEBPACK_IMPORTED_MODULE_16__["ɵɵinject"](_campaign_service__WEBPACK_IMPORTED_MODULE_3__.CampaignService), _angular_core__WEBPACK_IMPORTED_MODULE_16__["ɵɵinject"](_api_generated_controllers_challengeController_service__WEBPACK_IMPORTED_MODULE_4__.ChallengeControllerService), _angular_core__WEBPACK_IMPORTED_MODULE_16__["ɵɵinject"](_error_service__WEBPACK_IMPORTED_MODULE_5__.ErrorService));
};

ChallengeService.ɵprov = /*@__PURE__*/_angular_core__WEBPACK_IMPORTED_MODULE_16__["ɵɵdefineInjectable"]({
  token: ChallengeService,
  factory: ChallengeService.ɵfac,
  providedIn: 'root'
});

/***/ }),

/***/ 96204:
/*!*******************************************************!*\
  !*** ./src/app/core/shared/services/error.service.ts ***!
  \*******************************************************/
/***/ (function(__unused_webpack_module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "ErrorService": function() { return /* binding */ ErrorService; }
/* harmony export */ });
/* harmony import */ var _Users_smartcommunitylab_Documents_work_projects_dslab_playgo_mobile_playgo_mobile_node_modules_babel_runtime_helpers_esm_classCallCheck_js__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./node_modules/@babel/runtime/helpers/esm/classCallCheck.js */ 78069);
/* harmony import */ var _Users_smartcommunitylab_Documents_work_projects_dslab_playgo_mobile_playgo_mobile_node_modules_babel_runtime_helpers_esm_createClass_js__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ./node_modules/@babel/runtime/helpers/esm/createClass.js */ 48047);
/* harmony import */ var rxjs__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! rxjs */ 53158);
/* harmony import */ var rxjs__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! rxjs */ 20591);
/* harmony import */ var _constants_error_constants__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! ../../constants/error.constants */ 95750);
/* harmony import */ var _utils__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! ../utils */ 68647);
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(/*! @angular/core */ 3184);
/* harmony import */ var _alert_service__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! ./alert.service */ 46407);
/* harmony import */ var _ngx_translate_core__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(/*! @ngx-translate/core */ 87514);








var ErrorService = /*#__PURE__*/function () {
  function ErrorService(alertService, translateService) {
    (0,_Users_smartcommunitylab_Documents_work_projects_dslab_playgo_mobile_playgo_mobile_node_modules_babel_runtime_helpers_esm_classCallCheck_js__WEBPACK_IMPORTED_MODULE_0__["default"])(this, ErrorService);

    this.alertService = alertService;
    this.translateService = translateService;
    this.definedErrors = _constants_error_constants__WEBPACK_IMPORTED_MODULE_2__.ERRORS;
  }

  (0,_Users_smartcommunitylab_Documents_work_projects_dslab_playgo_mobile_playgo_mobile_node_modules_babel_runtime_helpers_esm_createClass_js__WEBPACK_IMPORTED_MODULE_1__["default"])(ErrorService, [{
    key: "getErrorHandler",
    value: function getErrorHandler() {
      var _this = this;

      var context = arguments.length > 0 && arguments[0] !== undefined ? arguments[0] : 'normal';
      //capture the stack trace, rxjs stacks are not helpful
      var originalStack = (0,_utils__WEBPACK_IMPORTED_MODULE_3__.getDebugStack)();
      return function (source) {
        return source.pipe((0,rxjs__WEBPACK_IMPORTED_MODULE_5__.catchError)(function (error) {
          _this.handleErrorInternal(error, context, originalStack); // return observable used for downstream subscription


          return rxjs__WEBPACK_IMPORTED_MODULE_6__.EMPTY;
        }));
      };
    }
    /**
     *
     * Universal error handler. Display toast/popup/logs based on severity and actual error.
     *
     * @param error error
     * @param context @see {@link ErrorContextSeverity}
     */

  }, {
    key: "handleError",
    value: function handleError(error) {
      var context = arguments.length > 1 && arguments[1] !== undefined ? arguments[1] : 'normal';
      this.handleErrorInternal(error, context);
    }
  }, {
    key: "handleErrorInternal",
    value: function handleErrorInternal(error) {
      var contextSeverity = arguments.length > 1 && arguments[1] !== undefined ? arguments[1] : 'normal';
      var stack = arguments.length > 2 ? arguments[2] : undefined;
      // first let's check if error is "expected"
      var knownApplicationError = this.definedErrors.find(function (definedError) {
        var _a;

        return definedError.msg === ((_a = error === null || error === void 0 ? void 0 : error.error) === null || _a === void 0 ? void 0 : _a.ex);
      }); // if we want to handle offline error differently, than it should be done before
      // handleError was called.

      var isOffline = (0,_utils__WEBPACK_IMPORTED_MODULE_3__.isOfflineError)(error);
      var isExpectedError = knownApplicationError || isOffline;
      var messageTranslateKey = 'errors.defaultErr';

      if (isExpectedError) {
        if (knownApplicationError) {
          messageTranslateKey = knownApplicationError.errorString;
        }

        if (isOffline) {
          messageTranslateKey = 'errors.offline';
        }
      } // if we want to, we can change severity based on error itself.


      var realSeverity = contextSeverity;

      if (realSeverity === 'silent') {
        console.warn('Error handled silently\n', error, stack);
      }

      if (realSeverity === 'normal') {
        console.error('Error handled by toast\n', error, stack);
        this.alertService.showToast({
          messageTranslateKey: messageTranslateKey
        });
      }

      if (realSeverity === 'blocking') {
        console.error('ERROR HANDLED BY FULL PAGE RELOAD!\n', error, stack);
        this.alertService.confirmAlert('errors.error_header', 'errors.not_recoverable').then(function (shouldReload) {
          if (shouldReload) {
            window.location.reload();
          }
        });
      }
    }
  }]);

  return ErrorService;
}();

ErrorService.ɵfac = function ErrorService_Factory(t) {
  return new (t || ErrorService)(_angular_core__WEBPACK_IMPORTED_MODULE_7__["ɵɵinject"](_alert_service__WEBPACK_IMPORTED_MODULE_4__.AlertService), _angular_core__WEBPACK_IMPORTED_MODULE_7__["ɵɵinject"](_ngx_translate_core__WEBPACK_IMPORTED_MODULE_8__.TranslateService));
};

ErrorService.ɵprov = /*@__PURE__*/_angular_core__WEBPACK_IMPORTED_MODULE_7__["ɵɵdefineInjectable"]({
  token: ErrorService,
  factory: ErrorService.ɵfac,
  providedIn: 'root'
});

/***/ }),

/***/ 69961:
/*!**************************************************************!*\
  !*** ./src/app/core/shared/services/global-error-handler.ts ***!
  \**************************************************************/
/***/ (function(__unused_webpack_module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "GlobalErrorHandler": function() { return /* binding */ GlobalErrorHandler; }
/* harmony export */ });
/* harmony import */ var _Users_smartcommunitylab_Documents_work_projects_dslab_playgo_mobile_playgo_mobile_node_modules_babel_runtime_helpers_esm_classCallCheck_js__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./node_modules/@babel/runtime/helpers/esm/classCallCheck.js */ 78069);
/* harmony import */ var _Users_smartcommunitylab_Documents_work_projects_dslab_playgo_mobile_playgo_mobile_node_modules_babel_runtime_helpers_esm_createClass_js__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ./node_modules/@babel/runtime/helpers/esm/createClass.js */ 48047);
/* harmony import */ var _angular_common_http__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! @angular/common/http */ 28784);
/* harmony import */ var src_environments_environment__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! src/environments/environment */ 92340);
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! @angular/core */ 3184);
/* harmony import */ var _error_service__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! ./error.service */ 96204);






var GlobalErrorHandler = /*#__PURE__*/function () {
  function GlobalErrorHandler(errorService) {
    (0,_Users_smartcommunitylab_Documents_work_projects_dslab_playgo_mobile_playgo_mobile_node_modules_babel_runtime_helpers_esm_classCallCheck_js__WEBPACK_IMPORTED_MODULE_0__["default"])(this, GlobalErrorHandler);

    this.errorService = errorService;
  }
  /**
   * We should never get here!
   *
   * There are two possibilities of what could went wrong:
   * 1. There is a javascript bug in the code, which needs to be fixed.
   * 2. There is a server error, which was not properly handled (by ErrorService).
   */


  (0,_Users_smartcommunitylab_Documents_work_projects_dslab_playgo_mobile_playgo_mobile_node_modules_babel_runtime_helpers_esm_createClass_js__WEBPACK_IMPORTED_MODULE_1__["default"])(GlobalErrorHandler, [{
    key: "handleError",
    value: function handleError(error) {
      var originalError = findOriginalError(error); // we can only guess what is correct here. We don't have any context. So let's be conservative.

      if (originalError instanceof _angular_common_http__WEBPACK_IMPORTED_MODULE_4__.HttpErrorResponse) {
        if (!src_environments_environment__WEBPACK_IMPORTED_MODULE_2__.environment.production) {
          console.error('UNHANDLED HTTP ERROR!!\n' + 'You should never get here!!\n' + 'Catch server errors in service or in the component using ErrorService\n\n', error, '\n\nOriginal error:\n', originalError);
        } // it is hard to decide, if we want it to be silent or not.


        this.errorService.handleError(error, 'normal');
      } else {
        if (!src_environments_environment__WEBPACK_IMPORTED_MODULE_2__.environment.production) {
          console.error('UNHANDLED ERROR!! (probably a javascript bug)\n\n', error, '\n\nOriginal error:\n', originalError);
        }

        this.errorService.handleError(error, 'silent');
      }
    }
  }]);

  return GlobalErrorHandler;
}();

GlobalErrorHandler.ɵfac = function GlobalErrorHandler_Factory(t) {
  return new (t || GlobalErrorHandler)(_angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵinject"](_error_service__WEBPACK_IMPORTED_MODULE_3__.ErrorService));
};

GlobalErrorHandler.ɵprov = /*@__PURE__*/_angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵdefineInjectable"]({
  token: GlobalErrorHandler,
  factory: GlobalErrorHandler.ɵfac
});
/** from angular source code.. */

function findOriginalError(error) {
  var e = error;

  if (error === null || error === void 0 ? void 0 : error.rejection) {
    e = error.rejection;
  }

  while (getOriginalError(e)) {
    e = getOriginalError(e);
  }

  return e;
}
/** from angular source code.. */


function getOriginalError(error) {
  return error === null || error === void 0 ? void 0 : error.ngOriginalError;
}

/***/ }),

/***/ 49397:
/*!***************************************************************!*\
  !*** ./src/app/core/shared/services/local-storage.service.ts ***!
  \***************************************************************/
/***/ (function(__unused_webpack_module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "LocalStorageService": function() { return /* binding */ LocalStorageService; }
/* harmony export */ });
/* harmony import */ var _Users_smartcommunitylab_Documents_work_projects_dslab_playgo_mobile_playgo_mobile_node_modules_babel_runtime_helpers_esm_classCallCheck_js__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./node_modules/@babel/runtime/helpers/esm/classCallCheck.js */ 78069);
/* harmony import */ var _Users_smartcommunitylab_Documents_work_projects_dslab_playgo_mobile_playgo_mobile_node_modules_babel_runtime_helpers_esm_createClass_js__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ./node_modules/@babel/runtime/helpers/esm/createClass.js */ 48047);
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! tslib */ 34929);
/* harmony import */ var localforage_cordovasqlitedriver__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! localforage-cordovasqlitedriver */ 7878);
/* harmony import */ var localforage_cordovasqlitedriver__WEBPACK_IMPORTED_MODULE_2___default = /*#__PURE__*/__webpack_require__.n(localforage_cordovasqlitedriver__WEBPACK_IMPORTED_MODULE_2__);
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! @angular/core */ 3184);
/* harmony import */ var _ionic_storage_angular__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! @ionic/storage-angular */ 80190);



function _regeneratorRuntime() { "use strict"; /*! regenerator-runtime -- Copyright (c) 2014-present, Facebook, Inc. -- license (MIT): https://github.com/facebook/regenerator/blob/main/LICENSE */ _regeneratorRuntime = function _regeneratorRuntime() { return exports; }; var exports = {}, Op = Object.prototype, hasOwn = Op.hasOwnProperty, $Symbol = "function" == typeof Symbol ? Symbol : {}, iteratorSymbol = $Symbol.iterator || "@@iterator", asyncIteratorSymbol = $Symbol.asyncIterator || "@@asyncIterator", toStringTagSymbol = $Symbol.toStringTag || "@@toStringTag"; function define(obj, key, value) { return Object.defineProperty(obj, key, { value: value, enumerable: !0, configurable: !0, writable: !0 }), obj[key]; } try { define({}, ""); } catch (err) { define = function define(obj, key, value) { return obj[key] = value; }; } function wrap(innerFn, outerFn, self, tryLocsList) { var protoGenerator = outerFn && outerFn.prototype instanceof Generator ? outerFn : Generator, generator = Object.create(protoGenerator.prototype), context = new Context(tryLocsList || []); return generator._invoke = function (innerFn, self, context) { var state = "suspendedStart"; return function (method, arg) { if ("executing" === state) throw new Error("Generator is already running"); if ("completed" === state) { if ("throw" === method) throw arg; return doneResult(); } for (context.method = method, context.arg = arg;;) { var delegate = context.delegate; if (delegate) { var delegateResult = maybeInvokeDelegate(delegate, context); if (delegateResult) { if (delegateResult === ContinueSentinel) continue; return delegateResult; } } if ("next" === context.method) context.sent = context._sent = context.arg;else if ("throw" === context.method) { if ("suspendedStart" === state) throw state = "completed", context.arg; context.dispatchException(context.arg); } else "return" === context.method && context.abrupt("return", context.arg); state = "executing"; var record = tryCatch(innerFn, self, context); if ("normal" === record.type) { if (state = context.done ? "completed" : "suspendedYield", record.arg === ContinueSentinel) continue; return { value: record.arg, done: context.done }; } "throw" === record.type && (state = "completed", context.method = "throw", context.arg = record.arg); } }; }(innerFn, self, context), generator; } function tryCatch(fn, obj, arg) { try { return { type: "normal", arg: fn.call(obj, arg) }; } catch (err) { return { type: "throw", arg: err }; } } exports.wrap = wrap; var ContinueSentinel = {}; function Generator() {} function GeneratorFunction() {} function GeneratorFunctionPrototype() {} var IteratorPrototype = {}; define(IteratorPrototype, iteratorSymbol, function () { return this; }); var getProto = Object.getPrototypeOf, NativeIteratorPrototype = getProto && getProto(getProto(values([]))); NativeIteratorPrototype && NativeIteratorPrototype !== Op && hasOwn.call(NativeIteratorPrototype, iteratorSymbol) && (IteratorPrototype = NativeIteratorPrototype); var Gp = GeneratorFunctionPrototype.prototype = Generator.prototype = Object.create(IteratorPrototype); function defineIteratorMethods(prototype) { ["next", "throw", "return"].forEach(function (method) { define(prototype, method, function (arg) { return this._invoke(method, arg); }); }); } function AsyncIterator(generator, PromiseImpl) { function invoke(method, arg, resolve, reject) { var record = tryCatch(generator[method], generator, arg); if ("throw" !== record.type) { var result = record.arg, value = result.value; return value && "object" == typeof value && hasOwn.call(value, "__await") ? PromiseImpl.resolve(value.__await).then(function (value) { invoke("next", value, resolve, reject); }, function (err) { invoke("throw", err, resolve, reject); }) : PromiseImpl.resolve(value).then(function (unwrapped) { result.value = unwrapped, resolve(result); }, function (error) { return invoke("throw", error, resolve, reject); }); } reject(record.arg); } var previousPromise; this._invoke = function (method, arg) { function callInvokeWithMethodAndArg() { return new PromiseImpl(function (resolve, reject) { invoke(method, arg, resolve, reject); }); } return previousPromise = previousPromise ? previousPromise.then(callInvokeWithMethodAndArg, callInvokeWithMethodAndArg) : callInvokeWithMethodAndArg(); }; } function maybeInvokeDelegate(delegate, context) { var method = delegate.iterator[context.method]; if (undefined === method) { if (context.delegate = null, "throw" === context.method) { if (delegate.iterator.return && (context.method = "return", context.arg = undefined, maybeInvokeDelegate(delegate, context), "throw" === context.method)) return ContinueSentinel; context.method = "throw", context.arg = new TypeError("The iterator does not provide a 'throw' method"); } return ContinueSentinel; } var record = tryCatch(method, delegate.iterator, context.arg); if ("throw" === record.type) return context.method = "throw", context.arg = record.arg, context.delegate = null, ContinueSentinel; var info = record.arg; return info ? info.done ? (context[delegate.resultName] = info.value, context.next = delegate.nextLoc, "return" !== context.method && (context.method = "next", context.arg = undefined), context.delegate = null, ContinueSentinel) : info : (context.method = "throw", context.arg = new TypeError("iterator result is not an object"), context.delegate = null, ContinueSentinel); } function pushTryEntry(locs) { var entry = { tryLoc: locs[0] }; 1 in locs && (entry.catchLoc = locs[1]), 2 in locs && (entry.finallyLoc = locs[2], entry.afterLoc = locs[3]), this.tryEntries.push(entry); } function resetTryEntry(entry) { var record = entry.completion || {}; record.type = "normal", delete record.arg, entry.completion = record; } function Context(tryLocsList) { this.tryEntries = [{ tryLoc: "root" }], tryLocsList.forEach(pushTryEntry, this), this.reset(!0); } function values(iterable) { if (iterable) { var iteratorMethod = iterable[iteratorSymbol]; if (iteratorMethod) return iteratorMethod.call(iterable); if ("function" == typeof iterable.next) return iterable; if (!isNaN(iterable.length)) { var i = -1, next = function next() { for (; ++i < iterable.length;) { if (hasOwn.call(iterable, i)) return next.value = iterable[i], next.done = !1, next; } return next.value = undefined, next.done = !0, next; }; return next.next = next; } } return { next: doneResult }; } function doneResult() { return { value: undefined, done: !0 }; } return GeneratorFunction.prototype = GeneratorFunctionPrototype, define(Gp, "constructor", GeneratorFunctionPrototype), define(GeneratorFunctionPrototype, "constructor", GeneratorFunction), GeneratorFunction.displayName = define(GeneratorFunctionPrototype, toStringTagSymbol, "GeneratorFunction"), exports.isGeneratorFunction = function (genFun) { var ctor = "function" == typeof genFun && genFun.constructor; return !!ctor && (ctor === GeneratorFunction || "GeneratorFunction" === (ctor.displayName || ctor.name)); }, exports.mark = function (genFun) { return Object.setPrototypeOf ? Object.setPrototypeOf(genFun, GeneratorFunctionPrototype) : (genFun.__proto__ = GeneratorFunctionPrototype, define(genFun, toStringTagSymbol, "GeneratorFunction")), genFun.prototype = Object.create(Gp), genFun; }, exports.awrap = function (arg) { return { __await: arg }; }, defineIteratorMethods(AsyncIterator.prototype), define(AsyncIterator.prototype, asyncIteratorSymbol, function () { return this; }), exports.AsyncIterator = AsyncIterator, exports.async = function (innerFn, outerFn, self, tryLocsList, PromiseImpl) { void 0 === PromiseImpl && (PromiseImpl = Promise); var iter = new AsyncIterator(wrap(innerFn, outerFn, self, tryLocsList), PromiseImpl); return exports.isGeneratorFunction(outerFn) ? iter : iter.next().then(function (result) { return result.done ? result.value : iter.next(); }); }, defineIteratorMethods(Gp), define(Gp, toStringTagSymbol, "Generator"), define(Gp, iteratorSymbol, function () { return this; }), define(Gp, "toString", function () { return "[object Generator]"; }), exports.keys = function (object) { var keys = []; for (var key in object) { keys.push(key); } return keys.reverse(), function next() { for (; keys.length;) { var key = keys.pop(); if (key in object) return next.value = key, next.done = !1, next; } return next.done = !0, next; }; }, exports.values = values, Context.prototype = { constructor: Context, reset: function reset(skipTempReset) { if (this.prev = 0, this.next = 0, this.sent = this._sent = undefined, this.done = !1, this.delegate = null, this.method = "next", this.arg = undefined, this.tryEntries.forEach(resetTryEntry), !skipTempReset) for (var name in this) { "t" === name.charAt(0) && hasOwn.call(this, name) && !isNaN(+name.slice(1)) && (this[name] = undefined); } }, stop: function stop() { this.done = !0; var rootRecord = this.tryEntries[0].completion; if ("throw" === rootRecord.type) throw rootRecord.arg; return this.rval; }, dispatchException: function dispatchException(exception) { if (this.done) throw exception; var context = this; function handle(loc, caught) { return record.type = "throw", record.arg = exception, context.next = loc, caught && (context.method = "next", context.arg = undefined), !!caught; } for (var i = this.tryEntries.length - 1; i >= 0; --i) { var entry = this.tryEntries[i], record = entry.completion; if ("root" === entry.tryLoc) return handle("end"); if (entry.tryLoc <= this.prev) { var hasCatch = hasOwn.call(entry, "catchLoc"), hasFinally = hasOwn.call(entry, "finallyLoc"); if (hasCatch && hasFinally) { if (this.prev < entry.catchLoc) return handle(entry.catchLoc, !0); if (this.prev < entry.finallyLoc) return handle(entry.finallyLoc); } else if (hasCatch) { if (this.prev < entry.catchLoc) return handle(entry.catchLoc, !0); } else { if (!hasFinally) throw new Error("try statement without catch or finally"); if (this.prev < entry.finallyLoc) return handle(entry.finallyLoc); } } } }, abrupt: function abrupt(type, arg) { for (var i = this.tryEntries.length - 1; i >= 0; --i) { var entry = this.tryEntries[i]; if (entry.tryLoc <= this.prev && hasOwn.call(entry, "finallyLoc") && this.prev < entry.finallyLoc) { var finallyEntry = entry; break; } } finallyEntry && ("break" === type || "continue" === type) && finallyEntry.tryLoc <= arg && arg <= finallyEntry.finallyLoc && (finallyEntry = null); var record = finallyEntry ? finallyEntry.completion : {}; return record.type = type, record.arg = arg, finallyEntry ? (this.method = "next", this.next = finallyEntry.finallyLoc, ContinueSentinel) : this.complete(record); }, complete: function complete(record, afterLoc) { if ("throw" === record.type) throw record.arg; return "break" === record.type || "continue" === record.type ? this.next = record.arg : "return" === record.type ? (this.rval = this.arg = record.arg, this.method = "return", this.next = "end") : "normal" === record.type && afterLoc && (this.next = afterLoc), ContinueSentinel; }, finish: function finish(finallyLoc) { for (var i = this.tryEntries.length - 1; i >= 0; --i) { var entry = this.tryEntries[i]; if (entry.finallyLoc === finallyLoc) return this.complete(entry.completion, entry.afterLoc), resetTryEntry(entry), ContinueSentinel; } }, catch: function _catch(tryLoc) { for (var i = this.tryEntries.length - 1; i >= 0; --i) { var entry = this.tryEntries[i]; if (entry.tryLoc === tryLoc) { var record = entry.completion; if ("throw" === record.type) { var thrown = record.arg; resetTryEntry(entry); } return thrown; } } throw new Error("illegal catch attempt"); }, delegateYield: function delegateYield(iterable, resultName, nextLoc) { return this.delegate = { iterator: values(iterable), resultName: resultName, nextLoc: nextLoc }, "next" === this.method && (this.arg = undefined), ContinueSentinel; } }, exports; }





var LocalStorageService = /*#__PURE__*/function () {
  function LocalStorageService(storageFactory) {
    (0,_Users_smartcommunitylab_Documents_work_projects_dslab_playgo_mobile_playgo_mobile_node_modules_babel_runtime_helpers_esm_classCallCheck_js__WEBPACK_IMPORTED_MODULE_0__["default"])(this, LocalStorageService);

    this.storageFactory = storageFactory;
    this.storageInstancePromise = this.getStorageImplementation(); // TODO:clear local storage automatically, after new app version (or code push version)
    // for consistency.
  }

  (0,_Users_smartcommunitylab_Documents_work_projects_dslab_playgo_mobile_playgo_mobile_node_modules_babel_runtime_helpers_esm_createClass_js__WEBPACK_IMPORTED_MODULE_1__["default"])(LocalStorageService, [{
    key: "getStorageImplementation",
    value: function getStorageImplementation() {
      return (0,tslib__WEBPACK_IMPORTED_MODULE_3__.__awaiter)(this, void 0, void 0, /*#__PURE__*/_regeneratorRuntime().mark(function _callee() {
        var storageInstance;
        return _regeneratorRuntime().wrap(function _callee$(_context) {
          while (1) {
            switch (_context.prev = _context.next) {
              case 0:
                _context.next = 2;
                return this.storageFactory.defineDriver(localforage_cordovasqlitedriver__WEBPACK_IMPORTED_MODULE_2__);

              case 2:
                _context.next = 4;
                return this.storageFactory.create();

              case 4:
                storageInstance = _context.sent;
                return _context.abrupt("return", storageInstance);

              case 6:
              case "end":
                return _context.stop();
            }
          }
        }, _callee, this);
      }));
    }
  }, {
    key: "getStorageOf",
    value: function getStorageOf(localStorageKey) {
      return new LocalStorage(localStorageKey, this.storageInstancePromise);
    }
  }, {
    key: "clearAll",
    value: function clearAll() {
      return (0,tslib__WEBPACK_IMPORTED_MODULE_3__.__awaiter)(this, void 0, void 0, /*#__PURE__*/_regeneratorRuntime().mark(function _callee2() {
        var storage;
        return _regeneratorRuntime().wrap(function _callee2$(_context2) {
          while (1) {
            switch (_context2.prev = _context2.next) {
              case 0:
                _context2.next = 2;
                return this.storageInstancePromise;

              case 2:
                storage = _context2.sent;
                storage.clear();

              case 4:
              case "end":
                return _context2.stop();
            }
          }
        }, _callee2, this);
      }));
    }
  }]);

  return LocalStorageService;
}();

LocalStorageService.ɵfac = function LocalStorageService_Factory(t) {
  return new (t || LocalStorageService)(_angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵinject"](_ionic_storage_angular__WEBPACK_IMPORTED_MODULE_5__.Storage));
};

LocalStorageService.ɵprov = /*@__PURE__*/_angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵdefineInjectable"]({
  token: LocalStorageService,
  factory: LocalStorageService.ɵfac,
  providedIn: 'root'
});

var LocalStorage = /*#__PURE__*/function () {
  function LocalStorage(storageKey, storageInstancePromise) {
    (0,_Users_smartcommunitylab_Documents_work_projects_dslab_playgo_mobile_playgo_mobile_node_modules_babel_runtime_helpers_esm_classCallCheck_js__WEBPACK_IMPORTED_MODULE_0__["default"])(this, LocalStorage);

    this.storageInstancePromise = storageInstancePromise;
    this.storageKey = 'playgo-storage-' + storageKey;
    this.storageMetaKey = 'playgo-storage-meta-' + storageKey;
  }

  (0,_Users_smartcommunitylab_Documents_work_projects_dslab_playgo_mobile_playgo_mobile_node_modules_babel_runtime_helpers_esm_createClass_js__WEBPACK_IMPORTED_MODULE_1__["default"])(LocalStorage, [{
    key: "set",
    value: function set(data) {
      return (0,tslib__WEBPACK_IMPORTED_MODULE_3__.__awaiter)(this, void 0, void 0, /*#__PURE__*/_regeneratorRuntime().mark(function _callee3() {
        var storage, metaInformation;
        return _regeneratorRuntime().wrap(function _callee3$(_context3) {
          while (1) {
            switch (_context3.prev = _context3.next) {
              case 0:
                _context3.next = 2;
                return this.storageInstancePromise;

              case 2:
                storage = _context3.sent;
                _context3.next = 5;
                return storage.set(this.storageKey, JSON.stringify(data || null));

              case 5:
                metaInformation = {
                  lastUpdated: new Date().getTime()
                };
                _context3.next = 8;
                return storage.set(this.storageMetaKey, JSON.stringify(metaInformation));

              case 8:
              case "end":
                return _context3.stop();
            }
          }
        }, _callee3, this);
      }));
    }
  }, {
    key: "get",
    value: function get() {
      return (0,tslib__WEBPACK_IMPORTED_MODULE_3__.__awaiter)(this, void 0, void 0, /*#__PURE__*/_regeneratorRuntime().mark(function _callee4() {
        return _regeneratorRuntime().wrap(function _callee4$(_context4) {
          while (1) {
            switch (_context4.prev = _context4.next) {
              case 0:
                _context4.next = 2;
                return this.getFromStorage(this.storageKey);

              case 2:
                return _context4.abrupt("return", _context4.sent);

              case 3:
              case "end":
                return _context4.stop();
            }
          }
        }, _callee4, this);
      }));
    }
  }, {
    key: "getMeta",
    value: function getMeta() {
      return (0,tslib__WEBPACK_IMPORTED_MODULE_3__.__awaiter)(this, void 0, void 0, /*#__PURE__*/_regeneratorRuntime().mark(function _callee5() {
        var meta, defaultMeta;
        return _regeneratorRuntime().wrap(function _callee5$(_context5) {
          while (1) {
            switch (_context5.prev = _context5.next) {
              case 0:
                _context5.next = 2;
                return this.getFromStorage(this.storageMetaKey);

              case 2:
                meta = _context5.sent;
                defaultMeta = {
                  lastUpdated: 0
                };
                return _context5.abrupt("return", meta !== null && meta !== void 0 ? meta : defaultMeta);

              case 5:
              case "end":
                return _context5.stop();
            }
          }
        }, _callee5, this);
      }));
    }
  }, {
    key: "getFromStorage",
    value: function getFromStorage(key) {
      return (0,tslib__WEBPACK_IMPORTED_MODULE_3__.__awaiter)(this, void 0, void 0, /*#__PURE__*/_regeneratorRuntime().mark(function _callee6() {
        var storage, stringVal;
        return _regeneratorRuntime().wrap(function _callee6$(_context6) {
          while (1) {
            switch (_context6.prev = _context6.next) {
              case 0:
                _context6.next = 2;
                return this.storageInstancePromise;

              case 2:
                storage = _context6.sent;
                _context6.next = 5;
                return storage.get(key);

              case 5:
                stringVal = _context6.sent;
                return _context6.abrupt("return", JSON.parse(stringVal));

              case 7:
              case "end":
                return _context6.stop();
            }
          }
        }, _callee6, this);
      }));
    }
  }, {
    key: "clear",
    value: function clear() {
      return (0,tslib__WEBPACK_IMPORTED_MODULE_3__.__awaiter)(this, void 0, void 0, /*#__PURE__*/_regeneratorRuntime().mark(function _callee7() {
        var storage;
        return _regeneratorRuntime().wrap(function _callee7$(_context7) {
          while (1) {
            switch (_context7.prev = _context7.next) {
              case 0:
                _context7.next = 2;
                return this.storageInstancePromise;

              case 2:
                storage = _context7.sent;
                _context7.next = 5;
                return storage.remove(this.storageKey);

              case 5:
                _context7.next = 7;
                return storage.remove(this.storageMetaKey);

              case 7:
              case "end":
                return _context7.stop();
            }
          }
        }, _callee7, this);
      }));
    }
  }]);

  return LocalStorage;
}();

/***/ }),

/***/ 30299:
/*!*****************************************************************************!*\
  !*** ./src/app/core/shared/services/notifications/notifications.service.ts ***!
  \*****************************************************************************/
/***/ (function(__unused_webpack_module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "MAX_NOTIFICATIONS": function() { return /* binding */ MAX_NOTIFICATIONS; },
/* harmony export */   "NOTIFICATION_TYPE_ACTIONS": function() { return /* binding */ NOTIFICATION_TYPE_ACTIONS; },
/* harmony export */   "NotificationService": function() { return /* binding */ NotificationService; },
/* harmony export */   "NotificationType": function() { return /* binding */ NotificationType; }
/* harmony export */ });
/* harmony import */ var _Users_smartcommunitylab_Documents_work_projects_dslab_playgo_mobile_playgo_mobile_node_modules_babel_runtime_helpers_esm_createForOfIteratorHelper_js__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./node_modules/@babel/runtime/helpers/esm/createForOfIteratorHelper.js */ 95106);
/* harmony import */ var _Users_smartcommunitylab_Documents_work_projects_dslab_playgo_mobile_playgo_mobile_node_modules_babel_runtime_helpers_esm_toConsumableArray_js__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ./node_modules/@babel/runtime/helpers/esm/toConsumableArray.js */ 58277);
/* harmony import */ var _Users_smartcommunitylab_Documents_work_projects_dslab_playgo_mobile_playgo_mobile_node_modules_babel_runtime_helpers_esm_classCallCheck_js__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! ./node_modules/@babel/runtime/helpers/esm/classCallCheck.js */ 78069);
/* harmony import */ var _Users_smartcommunitylab_Documents_work_projects_dslab_playgo_mobile_playgo_mobile_node_modules_babel_runtime_helpers_esm_createClass_js__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! ./node_modules/@babel/runtime/helpers/esm/createClass.js */ 48047);
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_15__ = __webpack_require__(/*! tslib */ 34929);
/* harmony import */ var rxjs__WEBPACK_IMPORTED_MODULE_10__ = __webpack_require__(/*! rxjs */ 15971);
/* harmony import */ var rxjs__WEBPACK_IMPORTED_MODULE_11__ = __webpack_require__(/*! rxjs */ 80228);
/* harmony import */ var rxjs__WEBPACK_IMPORTED_MODULE_12__ = __webpack_require__(/*! rxjs */ 36646);
/* harmony import */ var rxjs__WEBPACK_IMPORTED_MODULE_13__ = __webpack_require__(/*! rxjs */ 35004);
/* harmony import */ var rxjs__WEBPACK_IMPORTED_MODULE_14__ = __webpack_require__(/*! rxjs */ 32673);
/* harmony import */ var rxjs__WEBPACK_IMPORTED_MODULE_17__ = __webpack_require__(/*! rxjs */ 50635);
/* harmony import */ var rxjs__WEBPACK_IMPORTED_MODULE_18__ = __webpack_require__(/*! rxjs */ 19337);
/* harmony import */ var rxjs__WEBPACK_IMPORTED_MODULE_19__ = __webpack_require__(/*! rxjs */ 89196);
/* harmony import */ var _utils__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! ../../utils */ 68647);
/* harmony import */ var luxon__WEBPACK_IMPORTED_MODULE_16__ = __webpack_require__(/*! luxon */ 29527);
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_20__ = __webpack_require__(/*! @angular/core */ 3184);
/* harmony import */ var _local_storage_service__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! ../local-storage.service */ 49397);
/* harmony import */ var _error_service__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! ../error.service */ 96204);
/* harmony import */ var src_app_core_auth_auth_service__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(/*! src/app/core/auth/auth.service */ 88951);
/* harmony import */ var src_app_core_api_generated_controllers_communicationAccountController_service__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(/*! src/app/core/api/generated/controllers/communicationAccountController.service */ 94078);
/* harmony import */ var _pushNotification_service__WEBPACK_IMPORTED_MODULE_9__ = __webpack_require__(/*! ./pushNotification.service */ 61540);





function _regeneratorRuntime() { "use strict"; /*! regenerator-runtime -- Copyright (c) 2014-present, Facebook, Inc. -- license (MIT): https://github.com/facebook/regenerator/blob/main/LICENSE */ _regeneratorRuntime = function _regeneratorRuntime() { return exports; }; var exports = {}, Op = Object.prototype, hasOwn = Op.hasOwnProperty, $Symbol = "function" == typeof Symbol ? Symbol : {}, iteratorSymbol = $Symbol.iterator || "@@iterator", asyncIteratorSymbol = $Symbol.asyncIterator || "@@asyncIterator", toStringTagSymbol = $Symbol.toStringTag || "@@toStringTag"; function define(obj, key, value) { return Object.defineProperty(obj, key, { value: value, enumerable: !0, configurable: !0, writable: !0 }), obj[key]; } try { define({}, ""); } catch (err) { define = function define(obj, key, value) { return obj[key] = value; }; } function wrap(innerFn, outerFn, self, tryLocsList) { var protoGenerator = outerFn && outerFn.prototype instanceof Generator ? outerFn : Generator, generator = Object.create(protoGenerator.prototype), context = new Context(tryLocsList || []); return generator._invoke = function (innerFn, self, context) { var state = "suspendedStart"; return function (method, arg) { if ("executing" === state) throw new Error("Generator is already running"); if ("completed" === state) { if ("throw" === method) throw arg; return doneResult(); } for (context.method = method, context.arg = arg;;) { var delegate = context.delegate; if (delegate) { var delegateResult = maybeInvokeDelegate(delegate, context); if (delegateResult) { if (delegateResult === ContinueSentinel) continue; return delegateResult; } } if ("next" === context.method) context.sent = context._sent = context.arg;else if ("throw" === context.method) { if ("suspendedStart" === state) throw state = "completed", context.arg; context.dispatchException(context.arg); } else "return" === context.method && context.abrupt("return", context.arg); state = "executing"; var record = tryCatch(innerFn, self, context); if ("normal" === record.type) { if (state = context.done ? "completed" : "suspendedYield", record.arg === ContinueSentinel) continue; return { value: record.arg, done: context.done }; } "throw" === record.type && (state = "completed", context.method = "throw", context.arg = record.arg); } }; }(innerFn, self, context), generator; } function tryCatch(fn, obj, arg) { try { return { type: "normal", arg: fn.call(obj, arg) }; } catch (err) { return { type: "throw", arg: err }; } } exports.wrap = wrap; var ContinueSentinel = {}; function Generator() {} function GeneratorFunction() {} function GeneratorFunctionPrototype() {} var IteratorPrototype = {}; define(IteratorPrototype, iteratorSymbol, function () { return this; }); var getProto = Object.getPrototypeOf, NativeIteratorPrototype = getProto && getProto(getProto(values([]))); NativeIteratorPrototype && NativeIteratorPrototype !== Op && hasOwn.call(NativeIteratorPrototype, iteratorSymbol) && (IteratorPrototype = NativeIteratorPrototype); var Gp = GeneratorFunctionPrototype.prototype = Generator.prototype = Object.create(IteratorPrototype); function defineIteratorMethods(prototype) { ["next", "throw", "return"].forEach(function (method) { define(prototype, method, function (arg) { return this._invoke(method, arg); }); }); } function AsyncIterator(generator, PromiseImpl) { function invoke(method, arg, resolve, reject) { var record = tryCatch(generator[method], generator, arg); if ("throw" !== record.type) { var result = record.arg, value = result.value; return value && "object" == typeof value && hasOwn.call(value, "__await") ? PromiseImpl.resolve(value.__await).then(function (value) { invoke("next", value, resolve, reject); }, function (err) { invoke("throw", err, resolve, reject); }) : PromiseImpl.resolve(value).then(function (unwrapped) { result.value = unwrapped, resolve(result); }, function (error) { return invoke("throw", error, resolve, reject); }); } reject(record.arg); } var previousPromise; this._invoke = function (method, arg) { function callInvokeWithMethodAndArg() { return new PromiseImpl(function (resolve, reject) { invoke(method, arg, resolve, reject); }); } return previousPromise = previousPromise ? previousPromise.then(callInvokeWithMethodAndArg, callInvokeWithMethodAndArg) : callInvokeWithMethodAndArg(); }; } function maybeInvokeDelegate(delegate, context) { var method = delegate.iterator[context.method]; if (undefined === method) { if (context.delegate = null, "throw" === context.method) { if (delegate.iterator.return && (context.method = "return", context.arg = undefined, maybeInvokeDelegate(delegate, context), "throw" === context.method)) return ContinueSentinel; context.method = "throw", context.arg = new TypeError("The iterator does not provide a 'throw' method"); } return ContinueSentinel; } var record = tryCatch(method, delegate.iterator, context.arg); if ("throw" === record.type) return context.method = "throw", context.arg = record.arg, context.delegate = null, ContinueSentinel; var info = record.arg; return info ? info.done ? (context[delegate.resultName] = info.value, context.next = delegate.nextLoc, "return" !== context.method && (context.method = "next", context.arg = undefined), context.delegate = null, ContinueSentinel) : info : (context.method = "throw", context.arg = new TypeError("iterator result is not an object"), context.delegate = null, ContinueSentinel); } function pushTryEntry(locs) { var entry = { tryLoc: locs[0] }; 1 in locs && (entry.catchLoc = locs[1]), 2 in locs && (entry.finallyLoc = locs[2], entry.afterLoc = locs[3]), this.tryEntries.push(entry); } function resetTryEntry(entry) { var record = entry.completion || {}; record.type = "normal", delete record.arg, entry.completion = record; } function Context(tryLocsList) { this.tryEntries = [{ tryLoc: "root" }], tryLocsList.forEach(pushTryEntry, this), this.reset(!0); } function values(iterable) { if (iterable) { var iteratorMethod = iterable[iteratorSymbol]; if (iteratorMethod) return iteratorMethod.call(iterable); if ("function" == typeof iterable.next) return iterable; if (!isNaN(iterable.length)) { var i = -1, next = function next() { for (; ++i < iterable.length;) { if (hasOwn.call(iterable, i)) return next.value = iterable[i], next.done = !1, next; } return next.value = undefined, next.done = !0, next; }; return next.next = next; } } return { next: doneResult }; } function doneResult() { return { value: undefined, done: !0 }; } return GeneratorFunction.prototype = GeneratorFunctionPrototype, define(Gp, "constructor", GeneratorFunctionPrototype), define(GeneratorFunctionPrototype, "constructor", GeneratorFunction), GeneratorFunction.displayName = define(GeneratorFunctionPrototype, toStringTagSymbol, "GeneratorFunction"), exports.isGeneratorFunction = function (genFun) { var ctor = "function" == typeof genFun && genFun.constructor; return !!ctor && (ctor === GeneratorFunction || "GeneratorFunction" === (ctor.displayName || ctor.name)); }, exports.mark = function (genFun) { return Object.setPrototypeOf ? Object.setPrototypeOf(genFun, GeneratorFunctionPrototype) : (genFun.__proto__ = GeneratorFunctionPrototype, define(genFun, toStringTagSymbol, "GeneratorFunction")), genFun.prototype = Object.create(Gp), genFun; }, exports.awrap = function (arg) { return { __await: arg }; }, defineIteratorMethods(AsyncIterator.prototype), define(AsyncIterator.prototype, asyncIteratorSymbol, function () { return this; }), exports.AsyncIterator = AsyncIterator, exports.async = function (innerFn, outerFn, self, tryLocsList, PromiseImpl) { void 0 === PromiseImpl && (PromiseImpl = Promise); var iter = new AsyncIterator(wrap(innerFn, outerFn, self, tryLocsList), PromiseImpl); return exports.isGeneratorFunction(outerFn) ? iter : iter.next().then(function (result) { return result.done ? result.value : iter.next(); }); }, defineIteratorMethods(Gp), define(Gp, toStringTagSymbol, "Generator"), define(Gp, iteratorSymbol, function () { return this; }), define(Gp, "toString", function () { return "[object Generator]"; }), exports.keys = function (object) { var keys = []; for (var key in object) { keys.push(key); } return keys.reverse(), function next() { for (; keys.length;) { var key = keys.pop(); if (key in object) return next.value = key, next.done = !1, next; } return next.done = !0, next; }; }, exports.values = values, Context.prototype = { constructor: Context, reset: function reset(skipTempReset) { if (this.prev = 0, this.next = 0, this.sent = this._sent = undefined, this.done = !1, this.delegate = null, this.method = "next", this.arg = undefined, this.tryEntries.forEach(resetTryEntry), !skipTempReset) for (var name in this) { "t" === name.charAt(0) && hasOwn.call(this, name) && !isNaN(+name.slice(1)) && (this[name] = undefined); } }, stop: function stop() { this.done = !0; var rootRecord = this.tryEntries[0].completion; if ("throw" === rootRecord.type) throw rootRecord.arg; return this.rval; }, dispatchException: function dispatchException(exception) { if (this.done) throw exception; var context = this; function handle(loc, caught) { return record.type = "throw", record.arg = exception, context.next = loc, caught && (context.method = "next", context.arg = undefined), !!caught; } for (var i = this.tryEntries.length - 1; i >= 0; --i) { var entry = this.tryEntries[i], record = entry.completion; if ("root" === entry.tryLoc) return handle("end"); if (entry.tryLoc <= this.prev) { var hasCatch = hasOwn.call(entry, "catchLoc"), hasFinally = hasOwn.call(entry, "finallyLoc"); if (hasCatch && hasFinally) { if (this.prev < entry.catchLoc) return handle(entry.catchLoc, !0); if (this.prev < entry.finallyLoc) return handle(entry.finallyLoc); } else if (hasCatch) { if (this.prev < entry.catchLoc) return handle(entry.catchLoc, !0); } else { if (!hasFinally) throw new Error("try statement without catch or finally"); if (this.prev < entry.finallyLoc) return handle(entry.finallyLoc); } } } }, abrupt: function abrupt(type, arg) { for (var i = this.tryEntries.length - 1; i >= 0; --i) { var entry = this.tryEntries[i]; if (entry.tryLoc <= this.prev && hasOwn.call(entry, "finallyLoc") && this.prev < entry.finallyLoc) { var finallyEntry = entry; break; } } finallyEntry && ("break" === type || "continue" === type) && finallyEntry.tryLoc <= arg && arg <= finallyEntry.finallyLoc && (finallyEntry = null); var record = finallyEntry ? finallyEntry.completion : {}; return record.type = type, record.arg = arg, finallyEntry ? (this.method = "next", this.next = finallyEntry.finallyLoc, ContinueSentinel) : this.complete(record); }, complete: function complete(record, afterLoc) { if ("throw" === record.type) throw record.arg; return "break" === record.type || "continue" === record.type ? this.next = record.arg : "return" === record.type ? (this.rval = this.arg = record.arg, this.method = "return", this.next = "end") : "normal" === record.type && afterLoc && (this.next = afterLoc), ContinueSentinel; }, finish: function finish(finallyLoc) { for (var i = this.tryEntries.length - 1; i >= 0; --i) { var entry = this.tryEntries[i]; if (entry.finallyLoc === finallyLoc) return this.complete(entry.completion, entry.afterLoc), resetTryEntry(entry), ContinueSentinel; } }, catch: function _catch(tryLoc) { for (var i = this.tryEntries.length - 1; i >= 0; --i) { var entry = this.tryEntries[i]; if (entry.tryLoc === tryLoc) { var record = entry.completion; if ("throw" === record.type) { var thrown = record.arg; resetTryEntry(entry); } return thrown; } } throw new Error("illegal catch attempt"); }, delegateYield: function delegateYield(iterable, resultName, nextLoc) { return this.delegate = { iterator: values(iterable), resultName: resultName, nextLoc: nextLoc }, "next" === this.method && (this.arg = undefined), ContinueSentinel; } }, exports; }











var NotificationService = /*#__PURE__*/function () {
  function NotificationService(localStorageService, errorService, authService, communicationAccountController, pushNotificationService) {
    var _this = this;

    (0,_Users_smartcommunitylab_Documents_work_projects_dslab_playgo_mobile_playgo_mobile_node_modules_babel_runtime_helpers_esm_classCallCheck_js__WEBPACK_IMPORTED_MODULE_2__["default"])(this, NotificationService);

    this.localStorageService = localStorageService;
    this.errorService = errorService;
    this.authService = authService;
    this.communicationAccountController = communicationAccountController;
    this.pushNotificationService = pushNotificationService;
    this.notificationSinceStorage = this.localStorageService.getStorageOf('notificationSince');
    this.since = null;
    this.notificationStorage = this.localStorageService.getStorageOf('notifications');
    this.appResumed$ = rxjs__WEBPACK_IMPORTED_MODULE_10__.NEVER;
    this.networkStatusChanged$ = rxjs__WEBPACK_IMPORTED_MODULE_10__.NEVER;
    this.notificationRead$ = new rxjs__WEBPACK_IMPORTED_MODULE_11__.Subject();
    this.pushNotification$ = this.pushNotificationService.notifications$;
    this.trigger$ = (0,rxjs__WEBPACK_IMPORTED_MODULE_12__.merge)( // this.afterSyncTimer$,
    this.authService.isReadyForApi$, this.appResumed$, this.networkStatusChanged$, this.pushNotification$, this.notificationRead$).pipe((0,rxjs__WEBPACK_IMPORTED_MODULE_13__.throttleTime)(500));
    this.allNotifications$ = this.trigger$.pipe( // warning!! side effects!!!
    (0,rxjs__WEBPACK_IMPORTED_MODULE_14__.switchMap)(function () {
      return (0,tslib__WEBPACK_IMPORTED_MODULE_15__.__awaiter)(_this, void 0, void 0, /*#__PURE__*/_regeneratorRuntime().mark(function _callee() {
        return _regeneratorRuntime().wrap(function _callee$(_context) {
          while (1) {
            switch (_context.prev = _context.next) {
              case 0:
                if (!(this.since === null)) {
                  _context.next = 7;
                  break;
                }

                _context.next = 3;
                return this.notificationSinceStorage.get();

              case 3:
                _context.t0 = _context.sent;

                if (_context.t0) {
                  _context.next = 6;
                  break;
                }

                _context.t0 = 0;

              case 6:
                this.since = _context.t0;

              case 7:
                return _context.abrupt("return", this.since);

              case 8:
              case "end":
                return _context.stop();
            }
          }
        }, _callee, this);
      }));
    }), (0,rxjs__WEBPACK_IMPORTED_MODULE_14__.switchMap)(function (since) {
      return _this.communicationAccountController.getPlayerNotificationsUsingGET({
        since: since
      }).pipe(_this.errorService.getErrorHandler('silent'));
    }), // warning!! side effects!!!
    (0,rxjs__WEBPACK_IMPORTED_MODULE_14__.switchMap)(function (serverNotifications) {
      return (0,tslib__WEBPACK_IMPORTED_MODULE_15__.__awaiter)(_this, void 0, void 0, /*#__PURE__*/_regeneratorRuntime().mark(function _callee2() {
        return _regeneratorRuntime().wrap(function _callee2$(_context2) {
          while (1) {
            switch (_context2.prev = _context2.next) {
              case 0:
                if (!(serverNotifications.length > 0)) {
                  _context2.next = 5;
                  break;
                }

                this.since = serverNotifications[0].timestamp - luxon__WEBPACK_IMPORTED_MODULE_16__.DateTime.local().minus({
                  hour: 1
                }).valueOf();

                if (this.since < 0) {
                  this.since = 0;
                }

                _context2.next = 5;
                return this.notificationSinceStorage.set(this.since);

              case 5:
                return _context2.abrupt("return", serverNotifications);

              case 6:
              case "end":
                return _context2.stop();
            }
          }
        }, _callee2, this);
      }));
    }), (0,rxjs__WEBPACK_IMPORTED_MODULE_14__.switchMap)(function (serverNotifications) {
      return (0,tslib__WEBPACK_IMPORTED_MODULE_15__.__awaiter)(_this, void 0, void 0, /*#__PURE__*/_regeneratorRuntime().mark(function _callee3() {
        return _regeneratorRuntime().wrap(function _callee3$(_context3) {
          while (1) {
            switch (_context3.prev = _context3.next) {
              case 0:
                _context3.t0 = [];
                _context3.t1 = _Users_smartcommunitylab_Documents_work_projects_dslab_playgo_mobile_playgo_mobile_node_modules_babel_runtime_helpers_esm_toConsumableArray_js__WEBPACK_IMPORTED_MODULE_1__["default"];
                _context3.next = 4;
                return this.notificationStorage.get();

              case 4:
                _context3.t2 = _context3.sent;

                if (_context3.t2) {
                  _context3.next = 7;
                  break;
                }

                _context3.t2 = [];

              case 7:
                _context3.t3 = _context3.t2;
                _context3.t4 = (0, _context3.t1)(_context3.t3);
                _context3.t5 = (0,_Users_smartcommunitylab_Documents_work_projects_dslab_playgo_mobile_playgo_mobile_node_modules_babel_runtime_helpers_esm_toConsumableArray_js__WEBPACK_IMPORTED_MODULE_1__["default"])(serverNotifications);
                return _context3.abrupt("return", _context3.t0.concat.call(_context3.t0, _context3.t4, _context3.t5));

              case 11:
              case "end":
                return _context3.stop();
            }
          }
        }, _callee3, this);
      }));
    }), (0,rxjs__WEBPACK_IMPORTED_MODULE_17__.map)(function (allNotifications) {
      return allNotifications.filter(function (value, index, self) {
        return index === self.findIndex(function (t) {
          return t.id === value.id;
        });
      });
    }), (0,rxjs__WEBPACK_IMPORTED_MODULE_18__.tap)(function (allNotificationsWithoutDuplicates) {
      return _this.notificationStorage.set(allNotificationsWithoutDuplicates.filter(function (notification) {
        return notification.timestamp > luxon__WEBPACK_IMPORTED_MODULE_16__.DateTime.local().minus({
          month: 1
        }).valueOf();
      }).slice(0, MAX_NOTIFICATIONS));
    }), (0,rxjs__WEBPACK_IMPORTED_MODULE_19__.shareReplay)(1));
    this.unreadNotifications$ = this.allNotifications$.pipe((0,rxjs__WEBPACK_IMPORTED_MODULE_17__.map)(function (notifications) {
      return notifications.filter(function (not) {
        return not.readed === false;
      });
    }), (0,rxjs__WEBPACK_IMPORTED_MODULE_19__.shareReplay)(1));
    this.readNotifications$ = this.allNotifications$.pipe((0,rxjs__WEBPACK_IMPORTED_MODULE_17__.map)(function (notifications) {
      return notifications.filter(function (not) {
        return not.readed === true;
      });
    }), (0,rxjs__WEBPACK_IMPORTED_MODULE_19__.shareReplay)(1));
    this.unreadAnnouncementNotifications$ = this.allNotifications$.pipe((0,rxjs__WEBPACK_IMPORTED_MODULE_17__.map)(function (notifications) {
      return notifications.filter(function (not) {
        return not.readed === false;
      });
    }), (0,rxjs__WEBPACK_IMPORTED_MODULE_17__.map)(function (notifications) {
      return notifications.filter(function (notification) {
        return !!notification.content && notification.content.type === NotificationType.announcement;
      });
    }), (0,_utils__WEBPACK_IMPORTED_MODULE_4__.tapLog)('unreadAnnouncements'), (0,rxjs__WEBPACK_IMPORTED_MODULE_19__.shareReplay)(1));
    this.readedAnnouncementNotifications$ = this.allNotifications$.pipe((0,rxjs__WEBPACK_IMPORTED_MODULE_17__.map)(function (notifications) {
      return notifications.filter(function (not) {
        return not.readed === true;
      });
    }), (0,rxjs__WEBPACK_IMPORTED_MODULE_17__.map)(function (notifications) {
      return notifications.filter(function (notification) {
        return !!notification.content && notification.content.type === NotificationType.announcement;
      });
    }), (0,rxjs__WEBPACK_IMPORTED_MODULE_19__.shareReplay)(1));
    this.authService.isReadyForApi$.subscribe(function () {
      _this.allNotifications$.subscribe(function (notifications) {
        if (notifications === null) {
          _this.notificationStorage.set([]);
        }
      });
    });
  }

  (0,_Users_smartcommunitylab_Documents_work_projects_dslab_playgo_mobile_playgo_mobile_node_modules_babel_runtime_helpers_esm_createClass_js__WEBPACK_IMPORTED_MODULE_3__["default"])(NotificationService, [{
    key: "initPush",
    value: function initPush() {
      this.pushNotificationService.initPush();
    }
  }, {
    key: "getCampaignNotifications",
    value: function getCampaignNotifications(campaignId) {
      return this.allNotifications$.pipe((0,rxjs__WEBPACK_IMPORTED_MODULE_17__.map)(function (notifications) {
        return notifications.filter(function (notification) {
          return notification.campaignId === campaignId && !!notification.content && NOTIFICATION_TYPE_ACTIONS.campaignWidgetBadge.types.includes(notification.content.type);
        });
      }));
    }
  }, {
    key: "getUnreadCampaignChallengeNotifications",
    value: function getUnreadCampaignChallengeNotifications(campaignId) {
      return this.unreadNotifications$.pipe((0,rxjs__WEBPACK_IMPORTED_MODULE_17__.map)(function (notifications) {
        return notifications.filter(function (notification) {
          return notification.campaignId === campaignId && !!notification.content && NOTIFICATION_TYPE_ACTIONS.campaignWidgetChallengeBadge.types.includes(notification.content.type);
        });
      }));
    }
  }, {
    key: "getUnreadChallengeNotifications",
    value: function getUnreadChallengeNotifications() {
      return this.unreadNotifications$.pipe((0,rxjs__WEBPACK_IMPORTED_MODULE_17__.map)(function (notifications) {
        return notifications.filter(function (notification) {
          return !!notification.content && NOTIFICATION_TYPE_ACTIONS.challengeTabBadge.types.includes(notification.content.type);
        });
      }));
    }
  }, {
    key: "getUnreadCampaignNotifications",
    value: function getUnreadCampaignNotifications(campaignId) {
      return this.unreadNotifications$.pipe((0,rxjs__WEBPACK_IMPORTED_MODULE_17__.map)(function (notifications) {
        return notifications.filter(function (notification) {
          return notification.campaignId === campaignId && !!notification.content && NOTIFICATION_TYPE_ACTIONS.campaignWidgetBadge.types.includes(notification.content.type);
        });
      }));
    }
  }, {
    key: "getAnnouncementNotifications",
    value: function getAnnouncementNotifications() {
      return this.allNotifications$.pipe((0,rxjs__WEBPACK_IMPORTED_MODULE_17__.map)(function (notifications) {
        return notifications.filter(function (notification) {
          return !!notification.content && NOTIFICATION_TYPE_ACTIONS.notificationBadge.types.includes(notification.content.type);
        });
      }));
    }
  }, {
    key: "markAnnouncementAsRead",
    value: function markAnnouncementAsRead() {
      return (0,tslib__WEBPACK_IMPORTED_MODULE_15__.__awaiter)(this, void 0, void 0, /*#__PURE__*/_regeneratorRuntime().mark(function _callee4() {
        var _this2 = this;

        var storedNotifications;
        return _regeneratorRuntime().wrap(function _callee4$(_context4) {
          while (1) {
            switch (_context4.prev = _context4.next) {
              case 0:
                _context4.next = 2;
                return this.notificationStorage.get();

              case 2:
                storedNotifications = _context4.sent;
                storedNotifications.forEach(function (notification) {
                  if (!!notification.content && notification.content.type === NotificationType.announcement) {
                    _this2.markSingleNotificationAsRead(storedNotifications, notification);
                  }
                });
                this.notificationStorage.set(storedNotifications); //notify the new list of notifications

                this.notificationRead$.next();

              case 6:
              case "end":
                return _context4.stop();
            }
          }
        }, _callee4, this);
      }));
    }
  }, {
    key: "markCommonChallengeNotificationAsRead",
    value: function markCommonChallengeNotificationAsRead() {
      return (0,tslib__WEBPACK_IMPORTED_MODULE_15__.__awaiter)(this, void 0, void 0, /*#__PURE__*/_regeneratorRuntime().mark(function _callee5() {
        var _this3 = this;

        var storedNotifications;
        return _regeneratorRuntime().wrap(function _callee5$(_context5) {
          while (1) {
            switch (_context5.prev = _context5.next) {
              case 0:
                _context5.next = 2;
                return this.notificationStorage.get();

              case 2:
                storedNotifications = _context5.sent;
                storedNotifications.forEach(function (notification) {
                  if (!!notification.content && (notification.content.type === NotificationType.challengeAssigned || notification.content.type === NotificationType.challengeComplete || notification.content.type === NotificationType.challengeFailed)) {
                    _this3.markSingleNotificationAsRead(storedNotifications, notification);
                  }
                });
                this.notificationStorage.set(storedNotifications); //notify the new list of notifications

                this.notificationRead$.next();

              case 6:
              case "end":
                return _context5.stop();
            }
          }
        }, _callee5, this);
      }));
    }
  }, {
    key: "markListOfNotificationAsRead",
    value: function markListOfNotificationAsRead(notifications) {
      return (0,tslib__WEBPACK_IMPORTED_MODULE_15__.__awaiter)(this, void 0, void 0, /*#__PURE__*/_regeneratorRuntime().mark(function _callee6() {
        var _this4 = this;

        var storedNotifications;
        return _regeneratorRuntime().wrap(function _callee6$(_context6) {
          while (1) {
            switch (_context6.prev = _context6.next) {
              case 0:
                _context6.next = 2;
                return this.notificationStorage.get();

              case 2:
                storedNotifications = _context6.sent;
                notifications.forEach(function (notification) {
                  _this4.markSingleNotificationAsRead(storedNotifications, notification);
                });
                this.notificationStorage.set(storedNotifications); //notify the new list of notifications

                this.notificationRead$.next();

              case 6:
              case "end":
                return _context6.stop();
            }
          }
        }, _callee6, this);
      }));
    }
  }, {
    key: "markSingleNotificationAsRead",
    value: function markSingleNotificationAsRead(storedNotifications, notification) {
      var _iterator = (0,_Users_smartcommunitylab_Documents_work_projects_dslab_playgo_mobile_playgo_mobile_node_modules_babel_runtime_helpers_esm_createForOfIteratorHelper_js__WEBPACK_IMPORTED_MODULE_0__["default"])(storedNotifications),
          _step;

      try {
        for (_iterator.s(); !(_step = _iterator.n()).done;) {
          var not = _step.value;

          if (not.id === notification.id) {
            not.readed = true;
            break;
          }
        }
      } catch (err) {
        _iterator.e(err);
      } finally {
        _iterator.f();
      }
    }
  }]);

  return NotificationService;
}();

NotificationService.ɵfac = function NotificationService_Factory(t) {
  return new (t || NotificationService)(_angular_core__WEBPACK_IMPORTED_MODULE_20__["ɵɵinject"](_local_storage_service__WEBPACK_IMPORTED_MODULE_5__.LocalStorageService), _angular_core__WEBPACK_IMPORTED_MODULE_20__["ɵɵinject"](_error_service__WEBPACK_IMPORTED_MODULE_6__.ErrorService), _angular_core__WEBPACK_IMPORTED_MODULE_20__["ɵɵinject"](src_app_core_auth_auth_service__WEBPACK_IMPORTED_MODULE_7__.AuthService), _angular_core__WEBPACK_IMPORTED_MODULE_20__["ɵɵinject"](src_app_core_api_generated_controllers_communicationAccountController_service__WEBPACK_IMPORTED_MODULE_8__.CommunicationAccountControllerService), _angular_core__WEBPACK_IMPORTED_MODULE_20__["ɵɵinject"](_pushNotification_service__WEBPACK_IMPORTED_MODULE_9__.PushNotificationService));
};

NotificationService.ɵprov = /*@__PURE__*/_angular_core__WEBPACK_IMPORTED_MODULE_20__["ɵɵdefineInjectable"]({
  token: NotificationService,
  factory: NotificationService.ɵfac,
  providedIn: 'root'
});
var MAX_NOTIFICATIONS = 500;
var NotificationType;

(function (NotificationType) {
  NotificationType["level"] = "level";
  NotificationType["badge"] = "badge";
  NotificationType["programChallenge"] = "program_challenge";
  NotificationType["newInvite"] = "new_invite";
  NotificationType["replyAccepted"] = "reply_accepted";
  NotificationType["replyDenied"] = "reply_denied";
  NotificationType["challengeCancel"] = "challenge_cancel";
  NotificationType["challengeAssigned"] = "challenge_assigned";
  NotificationType["challengeComplete"] = "challenge_complete";
  NotificationType["challengeFailed"] = "challenge_failed";
  NotificationType["announcement"] = "announcement";
})(NotificationType || (NotificationType = {}));

var NOTIFICATION_TYPE_ACTIONS = {
  campaignWidgetBadge: {
    types: [NotificationType.level]
  },
  challengeTabBadge: {
    types: [NotificationType.programChallenge, NotificationType.newInvite, NotificationType.replyAccepted, NotificationType.replyDenied, NotificationType.challengeCancel, NotificationType.challengeAssigned, NotificationType.challengeComplete, NotificationType.challengeFailed]
  },
  campaignWidgetChallengeBadge: {
    types: [NotificationType.programChallenge, NotificationType.newInvite, NotificationType.replyAccepted, NotificationType.replyDenied, NotificationType.challengeCancel, NotificationType.challengeAssigned, NotificationType.challengeComplete, NotificationType.challengeFailed]
  },
  notificationBadge: {
    types: [NotificationType.announcement]
  }
};

/***/ }),

/***/ 61540:
/*!********************************************************************************!*\
  !*** ./src/app/core/shared/services/notifications/pushNotification.service.ts ***!
  \********************************************************************************/
/***/ (function(__unused_webpack_module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "PushNotificationService": function() { return /* binding */ PushNotificationService; }
/* harmony export */ });
/* harmony import */ var _Users_smartcommunitylab_Documents_work_projects_dslab_playgo_mobile_playgo_mobile_node_modules_babel_runtime_helpers_esm_slicedToArray_js__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./node_modules/@babel/runtime/helpers/esm/slicedToArray.js */ 10507);
/* harmony import */ var _Users_smartcommunitylab_Documents_work_projects_dslab_playgo_mobile_playgo_mobile_node_modules_babel_runtime_helpers_esm_classCallCheck_js__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ./node_modules/@babel/runtime/helpers/esm/classCallCheck.js */ 78069);
/* harmony import */ var _Users_smartcommunitylab_Documents_work_projects_dslab_playgo_mobile_playgo_mobile_node_modules_babel_runtime_helpers_esm_createClass_js__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! ./node_modules/@babel/runtime/helpers/esm/createClass.js */ 48047);
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_12__ = __webpack_require__(/*! tslib */ 34929);
/* harmony import */ var _capacitor_core__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @capacitor/core */ 26549);
/* harmony import */ var _capacitor_push_notifications__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! @capacitor/push-notifications */ 71704);
/* harmony import */ var _capacitor_community_fcm__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! @capacitor-community/fcm */ 68116);
/* harmony import */ var _utils__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! ../../utils */ 68647);
/* harmony import */ var rxjs__WEBPACK_IMPORTED_MODULE_11__ = __webpack_require__(/*! rxjs */ 26067);
/* harmony import */ var rxjs__WEBPACK_IMPORTED_MODULE_13__ = __webpack_require__(/*! rxjs */ 26562);
/* harmony import */ var rxjs__WEBPACK_IMPORTED_MODULE_14__ = __webpack_require__(/*! rxjs */ 80155);
/* harmony import */ var rxjs__WEBPACK_IMPORTED_MODULE_15__ = __webpack_require__(/*! rxjs */ 32673);
/* harmony import */ var rxjs__WEBPACK_IMPORTED_MODULE_16__ = __webpack_require__(/*! rxjs */ 36646);
/* harmony import */ var rxjs__WEBPACK_IMPORTED_MODULE_17__ = __webpack_require__(/*! rxjs */ 59346);
/* harmony import */ var rxjs__WEBPACK_IMPORTED_MODULE_18__ = __webpack_require__(/*! rxjs */ 51353);
/* harmony import */ var rxjs__WEBPACK_IMPORTED_MODULE_19__ = __webpack_require__(/*! rxjs */ 54107);
/* harmony import */ var rxjs__WEBPACK_IMPORTED_MODULE_20__ = __webpack_require__(/*! rxjs */ 53158);
/* harmony import */ var _notification_modal_notification_modal__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(/*! ../../notification-modal/notification.modal */ 19736);
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_21__ = __webpack_require__(/*! @angular/core */ 3184);
/* harmony import */ var _campaign_service__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(/*! ../campaign.service */ 23645);
/* harmony import */ var _api_generated_controllers_communicationAccountController_service__WEBPACK_IMPORTED_MODULE_9__ = __webpack_require__(/*! ../../../api/generated/controllers/communicationAccountController.service */ 94078);
/* harmony import */ var _user_service__WEBPACK_IMPORTED_MODULE_10__ = __webpack_require__(/*! ../user.service */ 50749);
/* harmony import */ var _ionic_angular__WEBPACK_IMPORTED_MODULE_22__ = __webpack_require__(/*! @ionic/angular */ 93819);




function _regeneratorRuntime() { "use strict"; /*! regenerator-runtime -- Copyright (c) 2014-present, Facebook, Inc. -- license (MIT): https://github.com/facebook/regenerator/blob/main/LICENSE */ _regeneratorRuntime = function _regeneratorRuntime() { return exports; }; var exports = {}, Op = Object.prototype, hasOwn = Op.hasOwnProperty, $Symbol = "function" == typeof Symbol ? Symbol : {}, iteratorSymbol = $Symbol.iterator || "@@iterator", asyncIteratorSymbol = $Symbol.asyncIterator || "@@asyncIterator", toStringTagSymbol = $Symbol.toStringTag || "@@toStringTag"; function define(obj, key, value) { return Object.defineProperty(obj, key, { value: value, enumerable: !0, configurable: !0, writable: !0 }), obj[key]; } try { define({}, ""); } catch (err) { define = function define(obj, key, value) { return obj[key] = value; }; } function wrap(innerFn, outerFn, self, tryLocsList) { var protoGenerator = outerFn && outerFn.prototype instanceof Generator ? outerFn : Generator, generator = Object.create(protoGenerator.prototype), context = new Context(tryLocsList || []); return generator._invoke = function (innerFn, self, context) { var state = "suspendedStart"; return function (method, arg) { if ("executing" === state) throw new Error("Generator is already running"); if ("completed" === state) { if ("throw" === method) throw arg; return doneResult(); } for (context.method = method, context.arg = arg;;) { var delegate = context.delegate; if (delegate) { var delegateResult = maybeInvokeDelegate(delegate, context); if (delegateResult) { if (delegateResult === ContinueSentinel) continue; return delegateResult; } } if ("next" === context.method) context.sent = context._sent = context.arg;else if ("throw" === context.method) { if ("suspendedStart" === state) throw state = "completed", context.arg; context.dispatchException(context.arg); } else "return" === context.method && context.abrupt("return", context.arg); state = "executing"; var record = tryCatch(innerFn, self, context); if ("normal" === record.type) { if (state = context.done ? "completed" : "suspendedYield", record.arg === ContinueSentinel) continue; return { value: record.arg, done: context.done }; } "throw" === record.type && (state = "completed", context.method = "throw", context.arg = record.arg); } }; }(innerFn, self, context), generator; } function tryCatch(fn, obj, arg) { try { return { type: "normal", arg: fn.call(obj, arg) }; } catch (err) { return { type: "throw", arg: err }; } } exports.wrap = wrap; var ContinueSentinel = {}; function Generator() {} function GeneratorFunction() {} function GeneratorFunctionPrototype() {} var IteratorPrototype = {}; define(IteratorPrototype, iteratorSymbol, function () { return this; }); var getProto = Object.getPrototypeOf, NativeIteratorPrototype = getProto && getProto(getProto(values([]))); NativeIteratorPrototype && NativeIteratorPrototype !== Op && hasOwn.call(NativeIteratorPrototype, iteratorSymbol) && (IteratorPrototype = NativeIteratorPrototype); var Gp = GeneratorFunctionPrototype.prototype = Generator.prototype = Object.create(IteratorPrototype); function defineIteratorMethods(prototype) { ["next", "throw", "return"].forEach(function (method) { define(prototype, method, function (arg) { return this._invoke(method, arg); }); }); } function AsyncIterator(generator, PromiseImpl) { function invoke(method, arg, resolve, reject) { var record = tryCatch(generator[method], generator, arg); if ("throw" !== record.type) { var result = record.arg, value = result.value; return value && "object" == typeof value && hasOwn.call(value, "__await") ? PromiseImpl.resolve(value.__await).then(function (value) { invoke("next", value, resolve, reject); }, function (err) { invoke("throw", err, resolve, reject); }) : PromiseImpl.resolve(value).then(function (unwrapped) { result.value = unwrapped, resolve(result); }, function (error) { return invoke("throw", error, resolve, reject); }); } reject(record.arg); } var previousPromise; this._invoke = function (method, arg) { function callInvokeWithMethodAndArg() { return new PromiseImpl(function (resolve, reject) { invoke(method, arg, resolve, reject); }); } return previousPromise = previousPromise ? previousPromise.then(callInvokeWithMethodAndArg, callInvokeWithMethodAndArg) : callInvokeWithMethodAndArg(); }; } function maybeInvokeDelegate(delegate, context) { var method = delegate.iterator[context.method]; if (undefined === method) { if (context.delegate = null, "throw" === context.method) { if (delegate.iterator.return && (context.method = "return", context.arg = undefined, maybeInvokeDelegate(delegate, context), "throw" === context.method)) return ContinueSentinel; context.method = "throw", context.arg = new TypeError("The iterator does not provide a 'throw' method"); } return ContinueSentinel; } var record = tryCatch(method, delegate.iterator, context.arg); if ("throw" === record.type) return context.method = "throw", context.arg = record.arg, context.delegate = null, ContinueSentinel; var info = record.arg; return info ? info.done ? (context[delegate.resultName] = info.value, context.next = delegate.nextLoc, "return" !== context.method && (context.method = "next", context.arg = undefined), context.delegate = null, ContinueSentinel) : info : (context.method = "throw", context.arg = new TypeError("iterator result is not an object"), context.delegate = null, ContinueSentinel); } function pushTryEntry(locs) { var entry = { tryLoc: locs[0] }; 1 in locs && (entry.catchLoc = locs[1]), 2 in locs && (entry.finallyLoc = locs[2], entry.afterLoc = locs[3]), this.tryEntries.push(entry); } function resetTryEntry(entry) { var record = entry.completion || {}; record.type = "normal", delete record.arg, entry.completion = record; } function Context(tryLocsList) { this.tryEntries = [{ tryLoc: "root" }], tryLocsList.forEach(pushTryEntry, this), this.reset(!0); } function values(iterable) { if (iterable) { var iteratorMethod = iterable[iteratorSymbol]; if (iteratorMethod) return iteratorMethod.call(iterable); if ("function" == typeof iterable.next) return iterable; if (!isNaN(iterable.length)) { var i = -1, next = function next() { for (; ++i < iterable.length;) { if (hasOwn.call(iterable, i)) return next.value = iterable[i], next.done = !1, next; } return next.value = undefined, next.done = !0, next; }; return next.next = next; } } return { next: doneResult }; } function doneResult() { return { value: undefined, done: !0 }; } return GeneratorFunction.prototype = GeneratorFunctionPrototype, define(Gp, "constructor", GeneratorFunctionPrototype), define(GeneratorFunctionPrototype, "constructor", GeneratorFunction), GeneratorFunction.displayName = define(GeneratorFunctionPrototype, toStringTagSymbol, "GeneratorFunction"), exports.isGeneratorFunction = function (genFun) { var ctor = "function" == typeof genFun && genFun.constructor; return !!ctor && (ctor === GeneratorFunction || "GeneratorFunction" === (ctor.displayName || ctor.name)); }, exports.mark = function (genFun) { return Object.setPrototypeOf ? Object.setPrototypeOf(genFun, GeneratorFunctionPrototype) : (genFun.__proto__ = GeneratorFunctionPrototype, define(genFun, toStringTagSymbol, "GeneratorFunction")), genFun.prototype = Object.create(Gp), genFun; }, exports.awrap = function (arg) { return { __await: arg }; }, defineIteratorMethods(AsyncIterator.prototype), define(AsyncIterator.prototype, asyncIteratorSymbol, function () { return this; }), exports.AsyncIterator = AsyncIterator, exports.async = function (innerFn, outerFn, self, tryLocsList, PromiseImpl) { void 0 === PromiseImpl && (PromiseImpl = Promise); var iter = new AsyncIterator(wrap(innerFn, outerFn, self, tryLocsList), PromiseImpl); return exports.isGeneratorFunction(outerFn) ? iter : iter.next().then(function (result) { return result.done ? result.value : iter.next(); }); }, defineIteratorMethods(Gp), define(Gp, toStringTagSymbol, "Generator"), define(Gp, iteratorSymbol, function () { return this; }), define(Gp, "toString", function () { return "[object Generator]"; }), exports.keys = function (object) { var keys = []; for (var key in object) { keys.push(key); } return keys.reverse(), function next() { for (; keys.length;) { var key = keys.pop(); if (key in object) return next.value = key, next.done = !1, next; } return next.done = !0, next; }; }, exports.values = values, Context.prototype = { constructor: Context, reset: function reset(skipTempReset) { if (this.prev = 0, this.next = 0, this.sent = this._sent = undefined, this.done = !1, this.delegate = null, this.method = "next", this.arg = undefined, this.tryEntries.forEach(resetTryEntry), !skipTempReset) for (var name in this) { "t" === name.charAt(0) && hasOwn.call(this, name) && !isNaN(+name.slice(1)) && (this[name] = undefined); } }, stop: function stop() { this.done = !0; var rootRecord = this.tryEntries[0].completion; if ("throw" === rootRecord.type) throw rootRecord.arg; return this.rval; }, dispatchException: function dispatchException(exception) { if (this.done) throw exception; var context = this; function handle(loc, caught) { return record.type = "throw", record.arg = exception, context.next = loc, caught && (context.method = "next", context.arg = undefined), !!caught; } for (var i = this.tryEntries.length - 1; i >= 0; --i) { var entry = this.tryEntries[i], record = entry.completion; if ("root" === entry.tryLoc) return handle("end"); if (entry.tryLoc <= this.prev) { var hasCatch = hasOwn.call(entry, "catchLoc"), hasFinally = hasOwn.call(entry, "finallyLoc"); if (hasCatch && hasFinally) { if (this.prev < entry.catchLoc) return handle(entry.catchLoc, !0); if (this.prev < entry.finallyLoc) return handle(entry.finallyLoc); } else if (hasCatch) { if (this.prev < entry.catchLoc) return handle(entry.catchLoc, !0); } else { if (!hasFinally) throw new Error("try statement without catch or finally"); if (this.prev < entry.finallyLoc) return handle(entry.finallyLoc); } } } }, abrupt: function abrupt(type, arg) { for (var i = this.tryEntries.length - 1; i >= 0; --i) { var entry = this.tryEntries[i]; if (entry.tryLoc <= this.prev && hasOwn.call(entry, "finallyLoc") && this.prev < entry.finallyLoc) { var finallyEntry = entry; break; } } finallyEntry && ("break" === type || "continue" === type) && finallyEntry.tryLoc <= arg && arg <= finallyEntry.finallyLoc && (finallyEntry = null); var record = finallyEntry ? finallyEntry.completion : {}; return record.type = type, record.arg = arg, finallyEntry ? (this.method = "next", this.next = finallyEntry.finallyLoc, ContinueSentinel) : this.complete(record); }, complete: function complete(record, afterLoc) { if ("throw" === record.type) throw record.arg; return "break" === record.type || "continue" === record.type ? this.next = record.arg : "return" === record.type ? (this.rval = this.arg = record.arg, this.method = "return", this.next = "end") : "normal" === record.type && afterLoc && (this.next = afterLoc), ContinueSentinel; }, finish: function finish(finallyLoc) { for (var i = this.tryEntries.length - 1; i >= 0; --i) { var entry = this.tryEntries[i]; if (entry.finallyLoc === finallyLoc) return this.complete(entry.completion, entry.afterLoc), resetTryEntry(entry), ContinueSentinel; } }, catch: function _catch(tryLoc) { for (var i = this.tryEntries.length - 1; i >= 0; --i) { var entry = this.tryEntries[i]; if (entry.tryLoc === tryLoc) { var record = entry.completion; if ("throw" === record.type) { var thrown = record.arg; resetTryEntry(entry); } return thrown; } } throw new Error("illegal catch attempt"); }, delegateYield: function delegateYield(iterable, resultName, nextLoc) { return this.delegate = { iterator: values(iterable), resultName: resultName, nextLoc: nextLoc }, "next" === this.method && (this.arg = undefined), ContinueSentinel; } }, exports; }













var PushNotificationService = /*#__PURE__*/function () {
  function PushNotificationService(zone, campaignService, communicationAccountControllerservice, userService, modalController) {
    (0,_Users_smartcommunitylab_Documents_work_projects_dslab_playgo_mobile_playgo_mobile_node_modules_babel_runtime_helpers_esm_classCallCheck_js__WEBPACK_IMPORTED_MODULE_1__["default"])(this, PushNotificationService);

    this.zone = zone;
    this.campaignService = campaignService;
    this.communicationAccountControllerservice = communicationAccountControllerservice;
    this.userService = userService;
    this.modalController = modalController;
    this.notifications = [];
    this.notificationsSubject = new rxjs__WEBPACK_IMPORTED_MODULE_11__.ReplaySubject(1);
    this.notifications$ = this.notificationsSubject.asObservable();
  }

  (0,_Users_smartcommunitylab_Documents_work_projects_dslab_playgo_mobile_playgo_mobile_node_modules_babel_runtime_helpers_esm_createClass_js__WEBPACK_IMPORTED_MODULE_2__["default"])(PushNotificationService, [{
    key: "initPush",
    value: function initPush() {
      if (_capacitor_core__WEBPACK_IMPORTED_MODULE_3__.Capacitor.getPlatform() !== 'web') {
        this.registerPush();
      }
    }
  }, {
    key: "registerPush",
    value: function registerPush() {
      return (0,tslib__WEBPACK_IMPORTED_MODULE_12__.__awaiter)(this, void 0, void 0, /*#__PURE__*/_regeneratorRuntime().mark(function _callee() {
        var _this = this;

        var permStatus;
        return _regeneratorRuntime().wrap(function _callee$(_context) {
          while (1) {
            switch (_context.prev = _context.next) {
              case 0:
                _context.next = 2;
                return _capacitor_push_notifications__WEBPACK_IMPORTED_MODULE_4__.PushNotifications.checkPermissions();

              case 2:
                permStatus = _context.sent;

                if (!(permStatus.receive === 'prompt')) {
                  _context.next = 7;
                  break;
                }

                _context.next = 6;
                return _capacitor_push_notifications__WEBPACK_IMPORTED_MODULE_4__.PushNotifications.requestPermissions();

              case 6:
                permStatus = _context.sent;

              case 7:
                if (!(permStatus.receive !== 'granted')) {
                  _context.next = 9;
                  break;
                }

                throw new Error('User denied permissions!');

              case 9:
                _context.next = 11;
                return _capacitor_push_notifications__WEBPACK_IMPORTED_MODULE_4__.PushNotifications.register();

              case 11:
                // On success, we should be able to receive notifications
                _capacitor_push_notifications__WEBPACK_IMPORTED_MODULE_4__.PushNotifications.addListener('registration', function (token) {
                  _this.zone.run(function () {
                    _capacitor_community_fcm__WEBPACK_IMPORTED_MODULE_5__.FCM.getToken().then(function (fcmtoken) {
                      if (_capacitor_core__WEBPACK_IMPORTED_MODULE_3__.Capacitor.getPlatform() === 'ios') {
                        console.log('fcmtoken', fcmtoken);

                        _this.registerToServer(fcmtoken.token);
                      } else {
                        _this.registerToServer(token.value);
                      } // subscribe to territory and all campaign I have


                      _this.registerToTopics();
                    });
                  });
                }); // Some issue with our setup and push will not work

                _capacitor_push_notifications__WEBPACK_IMPORTED_MODULE_4__.PushNotifications.addListener('registrationError', function (error) {
                  _this.zone.run(function () {
                    console.log('Error on registration: ' + JSON.stringify(error));
                  });
                }); // Show us the notification payload if the app is open on our device

                _capacitor_push_notifications__WEBPACK_IMPORTED_MODULE_4__.PushNotifications.addListener('pushNotificationReceived', function (notification) {
                  _this.zone.run(function () {
                    _this.notificationsSubject.next();

                    console.log('Push received: ' + JSON.stringify(notification));

                    _this.notifications.push(notification);

                    _this.showLastNotification(notification);
                  });
                }); // Method called when tapping on a notification

                _capacitor_push_notifications__WEBPACK_IMPORTED_MODULE_4__.PushNotifications.addListener('pushNotificationActionPerformed', function (notification) {
                  _this.zone.run(function () {
                    console.log('Push action performed: ' + JSON.stringify(notification));
                    console.log('Push received: ' + JSON.stringify(notification));

                    _this.notifications.push(notification.notification);

                    _this.showLastNotification(notification.notification);
                  });
                });

              case 15:
              case "end":
                return _context.stop();
            }
          }
        }, _callee);
      }));
    }
  }, {
    key: "showLastNotification",
    value: function showLastNotification(notification) {
      return (0,tslib__WEBPACK_IMPORTED_MODULE_12__.__awaiter)(this, void 0, void 0, /*#__PURE__*/_regeneratorRuntime().mark(function _callee2() {
        var modal, _yield$modal$onWillDi, data;

        return _regeneratorRuntime().wrap(function _callee2$(_context2) {
          while (1) {
            switch (_context2.prev = _context2.next) {
              case 0:
                _context2.next = 2;
                return this.modalController.create({
                  component: _notification_modal_notification_modal__WEBPACK_IMPORTED_MODULE_7__.NotificationModalPage,
                  cssClass: 'modal-challenge',
                  componentProps: {
                    notification: notification
                  },
                  swipeToClose: true
                });

              case 2:
                modal = _context2.sent;
                _context2.next = 5;
                return modal.present();

              case 5:
                _context2.next = 7;
                return modal.onWillDismiss();

              case 7:
                _yield$modal$onWillDi = _context2.sent;
                data = _yield$modal$onWillDi.data;

              case 9:
              case "end":
                return _context2.stop();
            }
          }
        }, _callee2, this);
      }));
    }
  }, {
    key: "registerToServer",
    value: function registerToServer(token) {
      return (0,tslib__WEBPACK_IMPORTED_MODULE_12__.__awaiter)(this, void 0, void 0, /*#__PURE__*/_regeneratorRuntime().mark(function _callee3() {
        return _regeneratorRuntime().wrap(function _callee3$(_context3) {
          while (1) {
            switch (_context3.prev = _context3.next) {
              case 0:
                console.log('registerToServer', token);
                _context3.next = 3;
                return this.communicationAccountControllerservice.registerUserToPushUsingPOST({
                  platform: _capacitor_core__WEBPACK_IMPORTED_MODULE_3__.Capacitor.getPlatform(),
                  registrationId: token
                }).toPromise();

              case 3:
              case "end":
                return _context3.stop();
            }
          }
        }, _callee3, this);
      }));
    }
  }, {
    key: "registerToTopics",
    value: function registerToTopics() {
      var _this2 = this;

      console.log('registerToTopics');
      this.sub = (0,rxjs__WEBPACK_IMPORTED_MODULE_13__.combineLatest)([this.campaignService.myCampaigns$, this.userService.userProfileTerritory$]).pipe((0,rxjs__WEBPACK_IMPORTED_MODULE_14__.first)(), (0,rxjs__WEBPACK_IMPORTED_MODULE_15__.switchMap)(function (_ref) {
        var _ref2 = (0,_Users_smartcommunitylab_Documents_work_projects_dslab_playgo_mobile_playgo_mobile_node_modules_babel_runtime_helpers_esm_slicedToArray_js__WEBPACK_IMPORTED_MODULE_0__["default"])(_ref, 2),
            campaigns = _ref2[0],
            profile = _ref2[1];

        return (0,rxjs__WEBPACK_IMPORTED_MODULE_16__.merge)((0,rxjs__WEBPACK_IMPORTED_MODULE_17__.from)(campaigns).pipe((0,_utils__WEBPACK_IMPORTED_MODULE_6__.tapLog)('campaigns'), (0,rxjs__WEBPACK_IMPORTED_MODULE_18__.mergeMap)(function (val) {
          var _a;

          console.log(val);
          return _capacitor_community_fcm__WEBPACK_IMPORTED_MODULE_5__.FCM.subscribeTo({
            topic: "".concat(profile.territoryId, "-").concat((_a = val === null || val === void 0 ? void 0 : val.campaign) === null || _a === void 0 ? void 0 : _a.campaignId)
          });
        }), (0,rxjs__WEBPACK_IMPORTED_MODULE_19__.toArray)()), (0,rxjs__WEBPACK_IMPORTED_MODULE_17__.from)(_capacitor_community_fcm__WEBPACK_IMPORTED_MODULE_5__.FCM.subscribeTo({
          topic: profile === null || profile === void 0 ? void 0 : profile.territoryId
        })));
      }), (0,rxjs__WEBPACK_IMPORTED_MODULE_20__.catchError)(function (err) {
        throw err;
      })).subscribe();
      this.campaignService.subscribeCampaignAction$.subscribe(function (topicName) {
        _this2.userService.userProfileTerritory$.pipe((0,rxjs__WEBPACK_IMPORTED_MODULE_14__.first)(), (0,_utils__WEBPACK_IMPORTED_MODULE_6__.tapLog)('userProfileTerritory$')).subscribe(function (profile) {
          _capacitor_community_fcm__WEBPACK_IMPORTED_MODULE_5__.FCM.subscribeTo({
            topic: "".concat(profile.territoryId, "-").concat(topicName)
          });
        });
      });
      this.campaignService.unsubscribeCampaignAction$.subscribe(function (topicName) {
        _this2.userService.userProfileTerritory$.pipe((0,rxjs__WEBPACK_IMPORTED_MODULE_14__.first)(), (0,_utils__WEBPACK_IMPORTED_MODULE_6__.tapLog)('userProfileTerritory$')).subscribe(function (profile) {
          _capacitor_community_fcm__WEBPACK_IMPORTED_MODULE_5__.FCM.unsubscribeFrom({
            topic: "".concat(profile.territoryId, "-").concat(topicName)
          });
        });
      });
    }
  }]);

  return PushNotificationService;
}();

PushNotificationService.ɵfac = function PushNotificationService_Factory(t) {
  return new (t || PushNotificationService)(_angular_core__WEBPACK_IMPORTED_MODULE_21__["ɵɵinject"](_angular_core__WEBPACK_IMPORTED_MODULE_21__.NgZone), _angular_core__WEBPACK_IMPORTED_MODULE_21__["ɵɵinject"](_campaign_service__WEBPACK_IMPORTED_MODULE_8__.CampaignService), _angular_core__WEBPACK_IMPORTED_MODULE_21__["ɵɵinject"](_api_generated_controllers_communicationAccountController_service__WEBPACK_IMPORTED_MODULE_9__.CommunicationAccountControllerService), _angular_core__WEBPACK_IMPORTED_MODULE_21__["ɵɵinject"](_user_service__WEBPACK_IMPORTED_MODULE_10__.UserService), _angular_core__WEBPACK_IMPORTED_MODULE_21__["ɵɵinject"](_ionic_angular__WEBPACK_IMPORTED_MODULE_22__.ModalController));
};

PushNotificationService.ɵprov = /*@__PURE__*/_angular_core__WEBPACK_IMPORTED_MODULE_21__["ɵɵdefineInjectable"]({
  token: PushNotificationService,
  factory: PushNotificationService.ɵfac,
  providedIn: 'root'
});

/***/ }),

/***/ 69509:
/*!*******************************************************!*\
  !*** ./src/app/core/shared/services/offline.guard.ts ***!
  \*******************************************************/
/***/ (function(__unused_webpack_module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "OfflineGuard": function() { return /* binding */ OfflineGuard; }
/* harmony export */ });
/* harmony import */ var _Users_smartcommunitylab_Documents_work_projects_dslab_playgo_mobile_playgo_mobile_node_modules_babel_runtime_helpers_esm_classCallCheck_js__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./node_modules/@babel/runtime/helpers/esm/classCallCheck.js */ 78069);
/* harmony import */ var _Users_smartcommunitylab_Documents_work_projects_dslab_playgo_mobile_playgo_mobile_node_modules_babel_runtime_helpers_esm_createClass_js__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ./node_modules/@babel/runtime/helpers/esm/createClass.js */ 48047);
/* harmony import */ var _utils__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! ../utils */ 68647);
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @angular/core */ 3184);
/* harmony import */ var _angular_router__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! @angular/router */ 52816);





var OfflineGuard = /*#__PURE__*/function () {
  function OfflineGuard(router) {
    (0,_Users_smartcommunitylab_Documents_work_projects_dslab_playgo_mobile_playgo_mobile_node_modules_babel_runtime_helpers_esm_classCallCheck_js__WEBPACK_IMPORTED_MODULE_0__["default"])(this, OfflineGuard);

    this.router = router;
  }

  (0,_Users_smartcommunitylab_Documents_work_projects_dslab_playgo_mobile_playgo_mobile_node_modules_babel_runtime_helpers_esm_createClass_js__WEBPACK_IMPORTED_MODULE_1__["default"])(OfflineGuard, [{
    key: "canActivateChild",
    value: function canActivateChild(childRoute, state) {
      return this.navigateToOfflinePageIfNeeded(childRoute);
    }
  }, {
    key: "canActivate",
    value: function canActivate(route, state) {
      return this.navigateToOfflinePageIfNeeded(route);
    }
  }, {
    key: "navigateToOfflinePageIfNeeded",
    value: function navigateToOfflinePageIfNeeded(route) {
      if (!route.component) {
        return true;
      }

      if (route.data.isOfflinePage === true) {
        return true;
      }

      if ((0,_utils__WEBPACK_IMPORTED_MODULE_2__.isOffline)()) {
        return this.router.parseUrl('/pages/tabs/offline');
      }

      return true;
    }
  }]);

  return OfflineGuard;
}();

OfflineGuard.ɵfac = function OfflineGuard_Factory(t) {
  return new (t || OfflineGuard)(_angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵinject"](_angular_router__WEBPACK_IMPORTED_MODULE_4__.Router));
};

OfflineGuard.ɵprov = /*@__PURE__*/_angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵdefineInjectable"]({
  token: OfflineGuard,
  factory: OfflineGuard.ɵfac,
  providedIn: 'root'
});

/***/ }),

/***/ 85294:
/*!***************************************************************!*\
  !*** ./src/app/core/shared/services/page-settings.service.ts ***!
  \***************************************************************/
/***/ (function(__unused_webpack_module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "PageSettingsService": function() { return /* binding */ PageSettingsService; }
/* harmony export */ });
/* harmony import */ var _Users_smartcommunitylab_Documents_work_projects_dslab_playgo_mobile_playgo_mobile_node_modules_babel_runtime_helpers_esm_classCallCheck_js__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./node_modules/@babel/runtime/helpers/esm/classCallCheck.js */ 78069);
/* harmony import */ var _Users_smartcommunitylab_Documents_work_projects_dslab_playgo_mobile_playgo_mobile_node_modules_babel_runtime_helpers_esm_createClass_js__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ./node_modules/@babel/runtime/helpers/esm/createClass.js */ 48047);
/* harmony import */ var _angular_router__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! @angular/router */ 52816);
/* harmony import */ var rxjs__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! rxjs */ 36646);
/* harmony import */ var rxjs__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! rxjs */ 60116);
/* harmony import */ var rxjs__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! rxjs */ 50635);
/* harmony import */ var rxjs__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(/*! rxjs */ 43453);
/* harmony import */ var rxjs__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(/*! rxjs */ 80228);
/* harmony import */ var rxjs__WEBPACK_IMPORTED_MODULE_9__ = __webpack_require__(/*! rxjs */ 32673);
/* harmony import */ var rxjs__WEBPACK_IMPORTED_MODULE_10__ = __webpack_require__(/*! rxjs */ 54240);
/* harmony import */ var rxjs__WEBPACK_IMPORTED_MODULE_11__ = __webpack_require__(/*! rxjs */ 10745);
/* harmony import */ var rxjs__WEBPACK_IMPORTED_MODULE_12__ = __webpack_require__(/*! rxjs */ 24503);
/* harmony import */ var rxjs__WEBPACK_IMPORTED_MODULE_13__ = __webpack_require__(/*! rxjs */ 98977);
/* harmony import */ var rxjs__WEBPACK_IMPORTED_MODULE_15__ = __webpack_require__(/*! rxjs */ 89196);
/* harmony import */ var lodash_es__WEBPACK_IMPORTED_MODULE_14__ = __webpack_require__(/*! lodash-es */ 63247);
/* harmony import */ var _utils__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! ../utils */ 68647);
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_16__ = __webpack_require__(/*! @angular/core */ 3184);
/* harmony import */ var _angular_platform_browser__WEBPACK_IMPORTED_MODULE_17__ = __webpack_require__(/*! @angular/platform-browser */ 50318);
/* harmony import */ var _ngx_translate_core__WEBPACK_IMPORTED_MODULE_18__ = __webpack_require__(/*! @ngx-translate/core */ 87514);










var PageSettingsService = /*#__PURE__*/function () {
  function PageSettingsService(router, activatedRoute, titleService, translateService) {
    var _this = this;

    (0,_Users_smartcommunitylab_Documents_work_projects_dslab_playgo_mobile_playgo_mobile_node_modules_babel_runtime_helpers_esm_classCallCheck_js__WEBPACK_IMPORTED_MODULE_0__["default"])(this, PageSettingsService);

    this.router = router;
    this.activatedRoute = activatedRoute;
    this.titleService = titleService;
    this.translateService = translateService;
    this.defaultPageSettings = {
      title: '',
      backButton: true,
      color: 'playgo',
      defaultHref: '/',
      isOfflinePage: false,
      customHeader: false,
      showNotifications: false,
      showPlayButton: false
    };
    this.routerPageSettings$ = (0,rxjs__WEBPACK_IMPORTED_MODULE_3__.merge)(this.router.events.pipe((0,rxjs__WEBPACK_IMPORTED_MODULE_4__.filter)((0,_utils__WEBPACK_IMPORTED_MODULE_2__.isInstanceOf)(_angular_router__WEBPACK_IMPORTED_MODULE_5__.RoutesRecognized)), (0,rxjs__WEBPACK_IMPORTED_MODULE_6__.map)(function (event) {
      return {
        id: event.id,
        settings: getRouterDataFromActivatedRouteSnapshot(event.state.root)
      };
    })), this.router.events.pipe((0,rxjs__WEBPACK_IMPORTED_MODULE_4__.filter)((0,_utils__WEBPACK_IMPORTED_MODULE_2__.isInstanceOf)(_angular_router__WEBPACK_IMPORTED_MODULE_5__.NavigationEnd)), (0,rxjs__WEBPACK_IMPORTED_MODULE_6__.map)(function (event) {
      return {
        id: event.id,
        settings: getRouterDataFromActivatedRoute(_this.activatedRoute)
      };
    }))).pipe((0,rxjs__WEBPACK_IMPORTED_MODULE_7__.distinctUntilKeyChanged)('id'), (0,rxjs__WEBPACK_IMPORTED_MODULE_6__.map)(function (_ref) {
      var settings = _ref.settings;
      return settings;
    }));
    this.manualPageSettingsSubject = new rxjs__WEBPACK_IMPORTED_MODULE_8__.Subject();
    this.pageSettings$ = this.routerPageSettings$.pipe( // for every page we start from scratch
    (0,rxjs__WEBPACK_IMPORTED_MODULE_9__.switchMap)(function (routerPageSettings) {
      return (0,rxjs__WEBPACK_IMPORTED_MODULE_10__.concat)((0,rxjs__WEBPACK_IMPORTED_MODULE_11__.of)({}), _this.manualPageSettingsSubject).pipe( // apply all manual overrides for the current page
      (0,rxjs__WEBPACK_IMPORTED_MODULE_12__.scan)(function (settings, manualPageSettings) {
        return Object.assign(Object.assign({}, settings), manualPageSettings);
      }, routerPageSettings), // set defaults
      (0,rxjs__WEBPACK_IMPORTED_MODULE_6__.map)(function (settings) {
        return Object.assign(Object.assign({}, _this.defaultPageSettings), settings);
      }), (0,rxjs__WEBPACK_IMPORTED_MODULE_13__.distinctUntilChanged)(lodash_es__WEBPACK_IMPORTED_MODULE_14__["default"]));
    }), (0,rxjs__WEBPACK_IMPORTED_MODULE_15__.shareReplay)());
    this.title$ = this.pageSettings$.pipe((0,rxjs__WEBPACK_IMPORTED_MODULE_6__.map)(function (settings) {
      return settings.title || 'home';
    }));
    this.title$.subscribe(function (title) {
      _this.titleService.setTitle(_this.translateService.instant(title));
    });
  }

  (0,_Users_smartcommunitylab_Documents_work_projects_dslab_playgo_mobile_playgo_mobile_node_modules_babel_runtime_helpers_esm_createClass_js__WEBPACK_IMPORTED_MODULE_1__["default"])(PageSettingsService, [{
    key: "set",
    value: function set(pageSettings) {
      this.manualPageSettingsSubject.next(pageSettings);
    }
  }]);

  return PageSettingsService;
}();

PageSettingsService.ɵfac = function PageSettingsService_Factory(t) {
  return new (t || PageSettingsService)(_angular_core__WEBPACK_IMPORTED_MODULE_16__["ɵɵinject"](_angular_router__WEBPACK_IMPORTED_MODULE_5__.Router), _angular_core__WEBPACK_IMPORTED_MODULE_16__["ɵɵinject"](_angular_router__WEBPACK_IMPORTED_MODULE_5__.ActivatedRoute), _angular_core__WEBPACK_IMPORTED_MODULE_16__["ɵɵinject"](_angular_platform_browser__WEBPACK_IMPORTED_MODULE_17__.Title), _angular_core__WEBPACK_IMPORTED_MODULE_16__["ɵɵinject"](_ngx_translate_core__WEBPACK_IMPORTED_MODULE_18__.TranslateService));
};

PageSettingsService.ɵprov = /*@__PURE__*/_angular_core__WEBPACK_IMPORTED_MODULE_16__["ɵɵdefineInjectable"]({
  token: PageSettingsService,
  factory: PageSettingsService.ɵfac,
  providedIn: 'root'
});

function getRouterDataFromActivatedRouteSnapshot(activatedRouteSnapshot) {
  var child = activatedRouteSnapshot.firstChild;

  while (child) {
    if (child.firstChild) {
      child = child.firstChild;
    } else if (child.data) {
      return child.data;
    } else {
      return {};
    }
  }

  return {};
}

function getRouterDataFromActivatedRoute(activatedRoute) {
  var child = activatedRoute.firstChild;

  while (child) {
    if (child.firstChild) {
      child = child.firstChild;
    } else if (child.snapshot.data) {
      return child.snapshot.data;
    } else {
      return {};
    }
  }

  return {};
}

/***/ }),

/***/ 93981:
/*!********************************************************!*\
  !*** ./src/app/core/shared/services/report.service.ts ***!
  \********************************************************/
/***/ (function(__unused_webpack_module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "ReportService": function() { return /* binding */ ReportService; }
/* harmony export */ });
/* harmony import */ var _Users_smartcommunitylab_Documents_work_projects_dslab_playgo_mobile_playgo_mobile_node_modules_babel_runtime_helpers_esm_classCallCheck_js__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./node_modules/@babel/runtime/helpers/esm/classCallCheck.js */ 78069);
/* harmony import */ var _Users_smartcommunitylab_Documents_work_projects_dslab_playgo_mobile_playgo_mobile_node_modules_babel_runtime_helpers_esm_createClass_js__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ./node_modules/@babel/runtime/helpers/esm/createClass.js */ 48047);
/* harmony import */ var rxjs__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! rxjs */ 89196);
/* harmony import */ var rxjs__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! rxjs */ 50635);
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! @angular/core */ 3184);
/* harmony import */ var _api_generated_controllers_reportController_service__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! ../../api/generated/controllers/reportController.service */ 59730);
/* harmony import */ var _api_generated_controllers_gameController_service__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! ../../api/generated/controllers/gameController.service */ 89903);






var ReportService = /*#__PURE__*/function () {
  function ReportService(reportControllerService, gameController) {
    (0,_Users_smartcommunitylab_Documents_work_projects_dslab_playgo_mobile_playgo_mobile_node_modules_babel_runtime_helpers_esm_classCallCheck_js__WEBPACK_IMPORTED_MODULE_0__["default"])(this, ReportService);

    this.reportControllerService = reportControllerService;
    this.gameController = gameController;
  }

  (0,_Users_smartcommunitylab_Documents_work_projects_dslab_playgo_mobile_playgo_mobile_node_modules_babel_runtime_helpers_esm_createClass_js__WEBPACK_IMPORTED_MODULE_1__["default"])(ReportService, [{
    key: "getCo2Stats",
    value: function getCo2Stats(campaignId, playerId, dateFrom, dateTo) {
      return this.reportControllerService.getPlayerCampaingPlacingByTransportModeUsingGET({
        campaignId: campaignId,
        playerId: playerId,
        metric: 'co2',
        mean: null,
        dateFrom: dateFrom,
        dateTo: dateTo
      }).toPromise();
    }
  }, {
    key: "getBikeStats",
    value: function getBikeStats(campaignId, playerId, dateFrom, dateTo) {
      return this.reportControllerService.getPlayerCampaingPlacingByTransportModeUsingGET({
        campaignId: campaignId,
        playerId: playerId,
        metric: 'km',
        mean: 'bike',
        dateFrom: dateFrom,
        dateTo: dateTo
      }).toPromise();
    }
  }, {
    key: "getCo2WeekRecord",
    value: function getCo2WeekRecord(campaignId, playerId) {
      return this.reportControllerService.getPlayerTransportRecordUsingGET({
        campaignId: campaignId,
        playerId: playerId,
        metric: 'co2',
        mean: null,
        groupMode: 'week'
      }).toPromise();
    }
  }, {
    key: "getGameStatus",
    value: function getGameStatus(campaignId) {
      return this.gameController.getCampaignGameStatusUsingGET(campaignId).pipe((0,rxjs__WEBPACK_IMPORTED_MODULE_4__.shareReplay)(1));
    }
  }, {
    key: "getCurrentLevel",
    value: function getCurrentLevel(campaignId) {
      return this.gameController.getCampaignGameStatusUsingGET(campaignId).pipe((0,rxjs__WEBPACK_IMPORTED_MODULE_5__.map)(function (status) {
        var _a;

        return ((_a = status === null || status === void 0 ? void 0 : status.levels) === null || _a === void 0 ? void 0 : _a.length) || 0;
      }), (0,rxjs__WEBPACK_IMPORTED_MODULE_4__.shareReplay)());
    }
  }, {
    key: "getGameStats",
    value: function getGameStats(campaignId, playerId, dateFrom, dateTo) {
      return this.reportControllerService.getPlayerCampaingPlacingByGameUsingGET({
        campaignId: campaignId,
        playerId: playerId,
        dateFrom: dateFrom,
        dateTo: dateTo
      });
    }
  }, {
    key: "getTransportStatsByMeans",
    value: function getTransportStatsByMeans(campaignId, playerId, metric, groupMode, mean, dateFrom, dateTo) {
      return this.reportControllerService.getPlayerTransportStatsUsingGET({
        campaignId: campaignId,
        playerId: playerId,
        metric: metric,
        groupMode: groupMode,
        mean: mean,
        dateFrom: dateFrom,
        dateTo: dateTo
      });
    }
  }, {
    key: "getStatus",
    value: function getStatus() {
      return this.reportControllerService.getPlayerStatusUsingGET().toPromise();
    }
  }]);

  return ReportService;
}();

ReportService.ɵfac = function ReportService_Factory(t) {
  return new (t || ReportService)(_angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵinject"](_api_generated_controllers_reportController_service__WEBPACK_IMPORTED_MODULE_2__.ReportControllerService), _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵinject"](_api_generated_controllers_gameController_service__WEBPACK_IMPORTED_MODULE_3__.GameControllerService));
};

ReportService.ɵprov = /*@__PURE__*/_angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵdefineInjectable"]({
  token: ReportService,
  factory: ReportService.ɵfac,
  providedIn: 'root'
});

/***/ }),

/***/ 75309:
/*!*********************************************************!*\
  !*** ./src/app/core/shared/services/spinner.service.ts ***!
  \*********************************************************/
/***/ (function(__unused_webpack_module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "SpinnerService": function() { return /* binding */ SpinnerService; }
/* harmony export */ });
/* harmony import */ var _Users_smartcommunitylab_Documents_work_projects_dslab_playgo_mobile_playgo_mobile_node_modules_babel_runtime_helpers_esm_classCallCheck_js__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./node_modules/@babel/runtime/helpers/esm/classCallCheck.js */ 78069);
/* harmony import */ var _Users_smartcommunitylab_Documents_work_projects_dslab_playgo_mobile_playgo_mobile_node_modules_babel_runtime_helpers_esm_createClass_js__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ./node_modules/@babel/runtime/helpers/esm/createClass.js */ 48047);
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! tslib */ 34929);
/* harmony import */ var rxjs__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! rxjs */ 80228);
/* harmony import */ var rxjs_operators__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! rxjs/operators */ 71989);
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! @angular/core */ 3184);
/* harmony import */ var _ionic_angular__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! @ionic/angular */ 93819);



function _regeneratorRuntime() { "use strict"; /*! regenerator-runtime -- Copyright (c) 2014-present, Facebook, Inc. -- license (MIT): https://github.com/facebook/regenerator/blob/main/LICENSE */ _regeneratorRuntime = function _regeneratorRuntime() { return exports; }; var exports = {}, Op = Object.prototype, hasOwn = Op.hasOwnProperty, $Symbol = "function" == typeof Symbol ? Symbol : {}, iteratorSymbol = $Symbol.iterator || "@@iterator", asyncIteratorSymbol = $Symbol.asyncIterator || "@@asyncIterator", toStringTagSymbol = $Symbol.toStringTag || "@@toStringTag"; function define(obj, key, value) { return Object.defineProperty(obj, key, { value: value, enumerable: !0, configurable: !0, writable: !0 }), obj[key]; } try { define({}, ""); } catch (err) { define = function define(obj, key, value) { return obj[key] = value; }; } function wrap(innerFn, outerFn, self, tryLocsList) { var protoGenerator = outerFn && outerFn.prototype instanceof Generator ? outerFn : Generator, generator = Object.create(protoGenerator.prototype), context = new Context(tryLocsList || []); return generator._invoke = function (innerFn, self, context) { var state = "suspendedStart"; return function (method, arg) { if ("executing" === state) throw new Error("Generator is already running"); if ("completed" === state) { if ("throw" === method) throw arg; return doneResult(); } for (context.method = method, context.arg = arg;;) { var delegate = context.delegate; if (delegate) { var delegateResult = maybeInvokeDelegate(delegate, context); if (delegateResult) { if (delegateResult === ContinueSentinel) continue; return delegateResult; } } if ("next" === context.method) context.sent = context._sent = context.arg;else if ("throw" === context.method) { if ("suspendedStart" === state) throw state = "completed", context.arg; context.dispatchException(context.arg); } else "return" === context.method && context.abrupt("return", context.arg); state = "executing"; var record = tryCatch(innerFn, self, context); if ("normal" === record.type) { if (state = context.done ? "completed" : "suspendedYield", record.arg === ContinueSentinel) continue; return { value: record.arg, done: context.done }; } "throw" === record.type && (state = "completed", context.method = "throw", context.arg = record.arg); } }; }(innerFn, self, context), generator; } function tryCatch(fn, obj, arg) { try { return { type: "normal", arg: fn.call(obj, arg) }; } catch (err) { return { type: "throw", arg: err }; } } exports.wrap = wrap; var ContinueSentinel = {}; function Generator() {} function GeneratorFunction() {} function GeneratorFunctionPrototype() {} var IteratorPrototype = {}; define(IteratorPrototype, iteratorSymbol, function () { return this; }); var getProto = Object.getPrototypeOf, NativeIteratorPrototype = getProto && getProto(getProto(values([]))); NativeIteratorPrototype && NativeIteratorPrototype !== Op && hasOwn.call(NativeIteratorPrototype, iteratorSymbol) && (IteratorPrototype = NativeIteratorPrototype); var Gp = GeneratorFunctionPrototype.prototype = Generator.prototype = Object.create(IteratorPrototype); function defineIteratorMethods(prototype) { ["next", "throw", "return"].forEach(function (method) { define(prototype, method, function (arg) { return this._invoke(method, arg); }); }); } function AsyncIterator(generator, PromiseImpl) { function invoke(method, arg, resolve, reject) { var record = tryCatch(generator[method], generator, arg); if ("throw" !== record.type) { var result = record.arg, value = result.value; return value && "object" == typeof value && hasOwn.call(value, "__await") ? PromiseImpl.resolve(value.__await).then(function (value) { invoke("next", value, resolve, reject); }, function (err) { invoke("throw", err, resolve, reject); }) : PromiseImpl.resolve(value).then(function (unwrapped) { result.value = unwrapped, resolve(result); }, function (error) { return invoke("throw", error, resolve, reject); }); } reject(record.arg); } var previousPromise; this._invoke = function (method, arg) { function callInvokeWithMethodAndArg() { return new PromiseImpl(function (resolve, reject) { invoke(method, arg, resolve, reject); }); } return previousPromise = previousPromise ? previousPromise.then(callInvokeWithMethodAndArg, callInvokeWithMethodAndArg) : callInvokeWithMethodAndArg(); }; } function maybeInvokeDelegate(delegate, context) { var method = delegate.iterator[context.method]; if (undefined === method) { if (context.delegate = null, "throw" === context.method) { if (delegate.iterator.return && (context.method = "return", context.arg = undefined, maybeInvokeDelegate(delegate, context), "throw" === context.method)) return ContinueSentinel; context.method = "throw", context.arg = new TypeError("The iterator does not provide a 'throw' method"); } return ContinueSentinel; } var record = tryCatch(method, delegate.iterator, context.arg); if ("throw" === record.type) return context.method = "throw", context.arg = record.arg, context.delegate = null, ContinueSentinel; var info = record.arg; return info ? info.done ? (context[delegate.resultName] = info.value, context.next = delegate.nextLoc, "return" !== context.method && (context.method = "next", context.arg = undefined), context.delegate = null, ContinueSentinel) : info : (context.method = "throw", context.arg = new TypeError("iterator result is not an object"), context.delegate = null, ContinueSentinel); } function pushTryEntry(locs) { var entry = { tryLoc: locs[0] }; 1 in locs && (entry.catchLoc = locs[1]), 2 in locs && (entry.finallyLoc = locs[2], entry.afterLoc = locs[3]), this.tryEntries.push(entry); } function resetTryEntry(entry) { var record = entry.completion || {}; record.type = "normal", delete record.arg, entry.completion = record; } function Context(tryLocsList) { this.tryEntries = [{ tryLoc: "root" }], tryLocsList.forEach(pushTryEntry, this), this.reset(!0); } function values(iterable) { if (iterable) { var iteratorMethod = iterable[iteratorSymbol]; if (iteratorMethod) return iteratorMethod.call(iterable); if ("function" == typeof iterable.next) return iterable; if (!isNaN(iterable.length)) { var i = -1, next = function next() { for (; ++i < iterable.length;) { if (hasOwn.call(iterable, i)) return next.value = iterable[i], next.done = !1, next; } return next.value = undefined, next.done = !0, next; }; return next.next = next; } } return { next: doneResult }; } function doneResult() { return { value: undefined, done: !0 }; } return GeneratorFunction.prototype = GeneratorFunctionPrototype, define(Gp, "constructor", GeneratorFunctionPrototype), define(GeneratorFunctionPrototype, "constructor", GeneratorFunction), GeneratorFunction.displayName = define(GeneratorFunctionPrototype, toStringTagSymbol, "GeneratorFunction"), exports.isGeneratorFunction = function (genFun) { var ctor = "function" == typeof genFun && genFun.constructor; return !!ctor && (ctor === GeneratorFunction || "GeneratorFunction" === (ctor.displayName || ctor.name)); }, exports.mark = function (genFun) { return Object.setPrototypeOf ? Object.setPrototypeOf(genFun, GeneratorFunctionPrototype) : (genFun.__proto__ = GeneratorFunctionPrototype, define(genFun, toStringTagSymbol, "GeneratorFunction")), genFun.prototype = Object.create(Gp), genFun; }, exports.awrap = function (arg) { return { __await: arg }; }, defineIteratorMethods(AsyncIterator.prototype), define(AsyncIterator.prototype, asyncIteratorSymbol, function () { return this; }), exports.AsyncIterator = AsyncIterator, exports.async = function (innerFn, outerFn, self, tryLocsList, PromiseImpl) { void 0 === PromiseImpl && (PromiseImpl = Promise); var iter = new AsyncIterator(wrap(innerFn, outerFn, self, tryLocsList), PromiseImpl); return exports.isGeneratorFunction(outerFn) ? iter : iter.next().then(function (result) { return result.done ? result.value : iter.next(); }); }, defineIteratorMethods(Gp), define(Gp, toStringTagSymbol, "Generator"), define(Gp, iteratorSymbol, function () { return this; }), define(Gp, "toString", function () { return "[object Generator]"; }), exports.keys = function (object) { var keys = []; for (var key in object) { keys.push(key); } return keys.reverse(), function next() { for (; keys.length;) { var key = keys.pop(); if (key in object) return next.value = key, next.done = !1, next; } return next.done = !0, next; }; }, exports.values = values, Context.prototype = { constructor: Context, reset: function reset(skipTempReset) { if (this.prev = 0, this.next = 0, this.sent = this._sent = undefined, this.done = !1, this.delegate = null, this.method = "next", this.arg = undefined, this.tryEntries.forEach(resetTryEntry), !skipTempReset) for (var name in this) { "t" === name.charAt(0) && hasOwn.call(this, name) && !isNaN(+name.slice(1)) && (this[name] = undefined); } }, stop: function stop() { this.done = !0; var rootRecord = this.tryEntries[0].completion; if ("throw" === rootRecord.type) throw rootRecord.arg; return this.rval; }, dispatchException: function dispatchException(exception) { if (this.done) throw exception; var context = this; function handle(loc, caught) { return record.type = "throw", record.arg = exception, context.next = loc, caught && (context.method = "next", context.arg = undefined), !!caught; } for (var i = this.tryEntries.length - 1; i >= 0; --i) { var entry = this.tryEntries[i], record = entry.completion; if ("root" === entry.tryLoc) return handle("end"); if (entry.tryLoc <= this.prev) { var hasCatch = hasOwn.call(entry, "catchLoc"), hasFinally = hasOwn.call(entry, "finallyLoc"); if (hasCatch && hasFinally) { if (this.prev < entry.catchLoc) return handle(entry.catchLoc, !0); if (this.prev < entry.finallyLoc) return handle(entry.finallyLoc); } else if (hasCatch) { if (this.prev < entry.catchLoc) return handle(entry.catchLoc, !0); } else { if (!hasFinally) throw new Error("try statement without catch or finally"); if (this.prev < entry.finallyLoc) return handle(entry.finallyLoc); } } } }, abrupt: function abrupt(type, arg) { for (var i = this.tryEntries.length - 1; i >= 0; --i) { var entry = this.tryEntries[i]; if (entry.tryLoc <= this.prev && hasOwn.call(entry, "finallyLoc") && this.prev < entry.finallyLoc) { var finallyEntry = entry; break; } } finallyEntry && ("break" === type || "continue" === type) && finallyEntry.tryLoc <= arg && arg <= finallyEntry.finallyLoc && (finallyEntry = null); var record = finallyEntry ? finallyEntry.completion : {}; return record.type = type, record.arg = arg, finallyEntry ? (this.method = "next", this.next = finallyEntry.finallyLoc, ContinueSentinel) : this.complete(record); }, complete: function complete(record, afterLoc) { if ("throw" === record.type) throw record.arg; return "break" === record.type || "continue" === record.type ? this.next = record.arg : "return" === record.type ? (this.rval = this.arg = record.arg, this.method = "return", this.next = "end") : "normal" === record.type && afterLoc && (this.next = afterLoc), ContinueSentinel; }, finish: function finish(finallyLoc) { for (var i = this.tryEntries.length - 1; i >= 0; --i) { var entry = this.tryEntries[i]; if (entry.finallyLoc === finallyLoc) return this.complete(entry.completion, entry.afterLoc), resetTryEntry(entry), ContinueSentinel; } }, catch: function _catch(tryLoc) { for (var i = this.tryEntries.length - 1; i >= 0; --i) { var entry = this.tryEntries[i]; if (entry.tryLoc === tryLoc) { var record = entry.completion; if ("throw" === record.type) { var thrown = record.arg; resetTryEntry(entry); } return thrown; } } throw new Error("illegal catch attempt"); }, delegateYield: function delegateYield(iterable, resultName, nextLoc) { return this.delegate = { iterator: values(iterable), resultName: resultName, nextLoc: nextLoc }, "next" === this.method && (this.arg = undefined), ContinueSentinel; } }, exports; }






var SpinnerService = /*#__PURE__*/function () {
  function SpinnerService(loadingController) {
    var _this = this;

    (0,_Users_smartcommunitylab_Documents_work_projects_dslab_playgo_mobile_playgo_mobile_node_modules_babel_runtime_helpers_esm_classCallCheck_js__WEBPACK_IMPORTED_MODULE_0__["default"])(this, SpinnerService);

    this.loadingController = loadingController;
    this.counter = 0;
    this.isShowingLoader = false;
    this.delay = 200;
    this.isLoading = new rxjs__WEBPACK_IMPORTED_MODULE_2__.Subject();
    this.isLoading.pipe((0,rxjs_operators__WEBPACK_IMPORTED_MODULE_3__.debounceTime)(this.delay)).subscribe(function (value) {
      if (value) {
        _this.counter++;

        if (!_this.isShowingLoader) {
          _this.showLoader();
        }
      } else if (_this.counter > 0) {
        _this.counter--;

        if (_this.isShowingLoader && _this.counter === 0) {
          _this.hideLoader();
        }
      }
    });
  }

  (0,_Users_smartcommunitylab_Documents_work_projects_dslab_playgo_mobile_playgo_mobile_node_modules_babel_runtime_helpers_esm_createClass_js__WEBPACK_IMPORTED_MODULE_1__["default"])(SpinnerService, [{
    key: "hideLoader",
    value: function hideLoader() {
      return (0,tslib__WEBPACK_IMPORTED_MODULE_4__.__awaiter)(this, void 0, void 0, /*#__PURE__*/_regeneratorRuntime().mark(function _callee() {
        return _regeneratorRuntime().wrap(function _callee$(_context) {
          while (1) {
            switch (_context.prev = _context.next) {
              case 0:
                if (this.loader) {
                  this.loader.dismiss();
                  this.loader = null;
                  this.isShowingLoader = false;
                }

              case 1:
              case "end":
                return _context.stop();
            }
          }
        }, _callee, this);
      }));
    }
  }, {
    key: "showLoader",
    value: function showLoader() {
      return (0,tslib__WEBPACK_IMPORTED_MODULE_4__.__awaiter)(this, void 0, void 0, /*#__PURE__*/_regeneratorRuntime().mark(function _callee2() {
        return _regeneratorRuntime().wrap(function _callee2$(_context2) {
          while (1) {
            switch (_context2.prev = _context2.next) {
              case 0:
                this.isShowingLoader = true;
                _context2.next = 3;
                return this.loadingController.create({
                  duration: 10000
                });

              case 3:
                this.loader = _context2.sent;
                _context2.next = 6;
                return this.loader.present();

              case 6:
                return _context2.abrupt("return", _context2.sent);

              case 7:
              case "end":
                return _context2.stop();
            }
          }
        }, _callee2, this);
      }));
    }
  }, {
    key: "show",
    value: function show() {
      this.isLoading.next(true);
    }
  }, {
    key: "hide",
    value: function hide() {
      this.isLoading.next(false);
    }
  }]);

  return SpinnerService;
}();

SpinnerService.ɵfac = function SpinnerService_Factory(t) {
  return new (t || SpinnerService)(_angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵinject"](_ionic_angular__WEBPACK_IMPORTED_MODULE_6__.LoadingController));
};

SpinnerService.ɵprov = /*@__PURE__*/_angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵdefineInjectable"]({
  token: SpinnerService,
  factory: SpinnerService.ɵfac,
  providedIn: 'root'
});

/***/ }),

/***/ 16327:
/*!***********************************************************!*\
  !*** ./src/app/core/shared/services/territory.service.ts ***!
  \***********************************************************/
/***/ (function(__unused_webpack_module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "TerritoryService": function() { return /* binding */ TerritoryService; }
/* harmony export */ });
/* harmony import */ var _Users_smartcommunitylab_Documents_work_projects_dslab_playgo_mobile_playgo_mobile_node_modules_babel_runtime_helpers_esm_classCallCheck_js__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./node_modules/@babel/runtime/helpers/esm/classCallCheck.js */ 78069);
/* harmony import */ var _Users_smartcommunitylab_Documents_work_projects_dslab_playgo_mobile_playgo_mobile_node_modules_babel_runtime_helpers_esm_createClass_js__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ./node_modules/@babel/runtime/helpers/esm/createClass.js */ 48047);
/* harmony import */ var lodash_es__WEBPACK_IMPORTED_MODULE_10__ = __webpack_require__(/*! lodash-es */ 63247);
/* harmony import */ var rxjs__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! rxjs */ 28653);
/* harmony import */ var rxjs_operators__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(/*! rxjs/operators */ 44874);
/* harmony import */ var rxjs_operators__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(/*! rxjs/operators */ 32673);
/* harmony import */ var rxjs_operators__WEBPACK_IMPORTED_MODULE_9__ = __webpack_require__(/*! rxjs/operators */ 98977);
/* harmony import */ var rxjs_operators__WEBPACK_IMPORTED_MODULE_12__ = __webpack_require__(/*! rxjs/operators */ 89196);
/* harmony import */ var rxjs_operators__WEBPACK_IMPORTED_MODULE_11__ = __webpack_require__(/*! rxjs/operators */ 19337);
/* harmony import */ var _utils__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! ../utils */ 68647);
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_13__ = __webpack_require__(/*! @angular/core */ 3184);
/* harmony import */ var _api_generated_controllers_territoryController_service__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! ../../api/generated/controllers/territoryController.service */ 21236);
/* harmony import */ var _local_storage_service__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! ./local-storage.service */ 49397);
/* harmony import */ var _error_service__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! ./error.service */ 96204);











var TerritoryService = /*#__PURE__*/function () {
  function TerritoryService(territoryControllerService, localStorageService, errorService) {
    var _this = this;

    (0,_Users_smartcommunitylab_Documents_work_projects_dslab_playgo_mobile_playgo_mobile_node_modules_babel_runtime_helpers_esm_classCallCheck_js__WEBPACK_IMPORTED_MODULE_0__["default"])(this, TerritoryService);

    this.territoryControllerService = territoryControllerService;
    this.localStorageService = localStorageService;
    this.errorService = errorService;
    this.territoriesStorage = this.localStorageService.getStorageOf('territories');
    this.territoryStorage = this.localStorageService.getStorageOf('territory');
    this.trigger$ = (0,rxjs__WEBPACK_IMPORTED_MODULE_6__.interval)(600000);
    this.territories$ = this.trigger$.pipe((0,rxjs_operators__WEBPACK_IMPORTED_MODULE_7__.startWith)(0), (0,rxjs_operators__WEBPACK_IMPORTED_MODULE_8__.switchMap)(function (triggerId) {
      var isFirstCall = triggerId === 0;
      return _this.territoryControllerService.getTerritoriesUsingGET().pipe((0,_utils__WEBPACK_IMPORTED_MODULE_2__.ifOfflineUseStored)(_this.territoriesStorage), _this.errorService.getErrorHandler(isFirstCall ? 'blocking' : 'silent'));
    }), (0,rxjs_operators__WEBPACK_IMPORTED_MODULE_9__.distinctUntilChanged)(lodash_es__WEBPACK_IMPORTED_MODULE_10__["default"]), (0,rxjs_operators__WEBPACK_IMPORTED_MODULE_11__.tap)(function (territory) {
      return _this.territoriesStorage.set(territory);
    }), (0,rxjs_operators__WEBPACK_IMPORTED_MODULE_12__.shareReplay)(1));
  }
  /**
   * Gets the territory by id. Works also offline.
   *
   * @throws http error
   */


  (0,_Users_smartcommunitylab_Documents_work_projects_dslab_playgo_mobile_playgo_mobile_node_modules_babel_runtime_helpers_esm_createClass_js__WEBPACK_IMPORTED_MODULE_1__["default"])(TerritoryService, [{
    key: "getTerritory",
    value: function getTerritory(territoryId) {
      var _this2 = this;

      return this.territoryControllerService.getTerritoryUsingGET(territoryId).pipe((0,_utils__WEBPACK_IMPORTED_MODULE_2__.ifOfflineUseStored)(this.territoryStorage, function (storedTerritory) {
        return storedTerritory.territoryId === territoryId;
      }), (0,rxjs_operators__WEBPACK_IMPORTED_MODULE_11__.tap)(function (territory) {
        return _this2.territoryStorage.set(territory);
      }));
    }
  }]);

  return TerritoryService;
}();

TerritoryService.ɵfac = function TerritoryService_Factory(t) {
  return new (t || TerritoryService)(_angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵinject"](_api_generated_controllers_territoryController_service__WEBPACK_IMPORTED_MODULE_3__.TerritoryControllerService), _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵinject"](_local_storage_service__WEBPACK_IMPORTED_MODULE_4__.LocalStorageService), _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵinject"](_error_service__WEBPACK_IMPORTED_MODULE_5__.ErrorService));
};

TerritoryService.ɵprov = /*@__PURE__*/_angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵdefineInjectable"]({
  token: TerritoryService,
  factory: TerritoryService.ɵfac,
  providedIn: 'root'
});

/***/ }),

/***/ 50749:
/*!******************************************************!*\
  !*** ./src/app/core/shared/services/user.service.ts ***!
  \******************************************************/
/***/ (function(__unused_webpack_module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "UserService": function() { return /* binding */ UserService; }
/* harmony export */ });
/* harmony import */ var _Users_smartcommunitylab_Documents_work_projects_dslab_playgo_mobile_playgo_mobile_node_modules_babel_runtime_helpers_esm_slicedToArray_js__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./node_modules/@babel/runtime/helpers/esm/slicedToArray.js */ 10507);
/* harmony import */ var _Users_smartcommunitylab_Documents_work_projects_dslab_playgo_mobile_playgo_mobile_node_modules_babel_runtime_helpers_esm_classCallCheck_js__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ./node_modules/@babel/runtime/helpers/esm/classCallCheck.js */ 78069);
/* harmony import */ var _Users_smartcommunitylab_Documents_work_projects_dslab_playgo_mobile_playgo_mobile_node_modules_babel_runtime_helpers_esm_createClass_js__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! ./node_modules/@babel/runtime/helpers/esm/createClass.js */ 48047);
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_19__ = __webpack_require__(/*! tslib */ 34929);
/* harmony import */ var rxjs__WEBPACK_IMPORTED_MODULE_11__ = __webpack_require__(/*! rxjs */ 76317);
/* harmony import */ var rxjs__WEBPACK_IMPORTED_MODULE_16__ = __webpack_require__(/*! rxjs */ 26067);
/* harmony import */ var rxjs__WEBPACK_IMPORTED_MODULE_17__ = __webpack_require__(/*! rxjs */ 36646);
/* harmony import */ var rxjs__WEBPACK_IMPORTED_MODULE_20__ = __webpack_require__(/*! rxjs */ 20591);
/* harmony import */ var rxjs__WEBPACK_IMPORTED_MODULE_22__ = __webpack_require__(/*! rxjs */ 26562);
/* harmony import */ var rxjs__WEBPACK_IMPORTED_MODULE_25__ = __webpack_require__(/*! rxjs */ 10745);
/* harmony import */ var src_environments_environment__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! src/environments/environment */ 92340);
/* harmony import */ var _angular_common_http__WEBPACK_IMPORTED_MODULE_24__ = __webpack_require__(/*! @angular/common/http */ 28784);
/* harmony import */ var rxjs_operators__WEBPACK_IMPORTED_MODULE_12__ = __webpack_require__(/*! rxjs/operators */ 98977);
/* harmony import */ var rxjs_operators__WEBPACK_IMPORTED_MODULE_13__ = __webpack_require__(/*! rxjs/operators */ 89196);
/* harmony import */ var rxjs_operators__WEBPACK_IMPORTED_MODULE_14__ = __webpack_require__(/*! rxjs/operators */ 60116);
/* harmony import */ var rxjs_operators__WEBPACK_IMPORTED_MODULE_15__ = __webpack_require__(/*! rxjs/operators */ 50635);
/* harmony import */ var rxjs_operators__WEBPACK_IMPORTED_MODULE_18__ = __webpack_require__(/*! rxjs/operators */ 32673);
/* harmony import */ var rxjs_operators__WEBPACK_IMPORTED_MODULE_23__ = __webpack_require__(/*! rxjs/operators */ 53158);
/* harmony import */ var lodash_es__WEBPACK_IMPORTED_MODULE_21__ = __webpack_require__(/*! lodash-es */ 63247);
/* harmony import */ var _utils__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! ../utils */ 68647);
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_26__ = __webpack_require__(/*! @angular/core */ 3184);
/* harmony import */ var _ngx_translate_core__WEBPACK_IMPORTED_MODULE_27__ = __webpack_require__(/*! @ngx-translate/core */ 87514);
/* harmony import */ var _territory_service__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! ./territory.service */ 16327);
/* harmony import */ var _local_storage_service__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! ./local-storage.service */ 49397);
/* harmony import */ var _ionic_angular__WEBPACK_IMPORTED_MODULE_28__ = __webpack_require__(/*! @ionic/angular */ 93819);
/* harmony import */ var _auth_auth_service__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(/*! ../../auth/auth.service */ 88951);
/* harmony import */ var _api_generated_controllers_playerController_service__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(/*! ../../api/generated/controllers/playerController.service */ 60148);
/* harmony import */ var _alert_service__WEBPACK_IMPORTED_MODULE_9__ = __webpack_require__(/*! ./alert.service */ 46407);
/* harmony import */ var _error_service__WEBPACK_IMPORTED_MODULE_10__ = __webpack_require__(/*! ./error.service */ 96204);




function _regeneratorRuntime() { "use strict"; /*! regenerator-runtime -- Copyright (c) 2014-present, Facebook, Inc. -- license (MIT): https://github.com/facebook/regenerator/blob/main/LICENSE */ _regeneratorRuntime = function _regeneratorRuntime() { return exports; }; var exports = {}, Op = Object.prototype, hasOwn = Op.hasOwnProperty, $Symbol = "function" == typeof Symbol ? Symbol : {}, iteratorSymbol = $Symbol.iterator || "@@iterator", asyncIteratorSymbol = $Symbol.asyncIterator || "@@asyncIterator", toStringTagSymbol = $Symbol.toStringTag || "@@toStringTag"; function define(obj, key, value) { return Object.defineProperty(obj, key, { value: value, enumerable: !0, configurable: !0, writable: !0 }), obj[key]; } try { define({}, ""); } catch (err) { define = function define(obj, key, value) { return obj[key] = value; }; } function wrap(innerFn, outerFn, self, tryLocsList) { var protoGenerator = outerFn && outerFn.prototype instanceof Generator ? outerFn : Generator, generator = Object.create(protoGenerator.prototype), context = new Context(tryLocsList || []); return generator._invoke = function (innerFn, self, context) { var state = "suspendedStart"; return function (method, arg) { if ("executing" === state) throw new Error("Generator is already running"); if ("completed" === state) { if ("throw" === method) throw arg; return doneResult(); } for (context.method = method, context.arg = arg;;) { var delegate = context.delegate; if (delegate) { var delegateResult = maybeInvokeDelegate(delegate, context); if (delegateResult) { if (delegateResult === ContinueSentinel) continue; return delegateResult; } } if ("next" === context.method) context.sent = context._sent = context.arg;else if ("throw" === context.method) { if ("suspendedStart" === state) throw state = "completed", context.arg; context.dispatchException(context.arg); } else "return" === context.method && context.abrupt("return", context.arg); state = "executing"; var record = tryCatch(innerFn, self, context); if ("normal" === record.type) { if (state = context.done ? "completed" : "suspendedYield", record.arg === ContinueSentinel) continue; return { value: record.arg, done: context.done }; } "throw" === record.type && (state = "completed", context.method = "throw", context.arg = record.arg); } }; }(innerFn, self, context), generator; } function tryCatch(fn, obj, arg) { try { return { type: "normal", arg: fn.call(obj, arg) }; } catch (err) { return { type: "throw", arg: err }; } } exports.wrap = wrap; var ContinueSentinel = {}; function Generator() {} function GeneratorFunction() {} function GeneratorFunctionPrototype() {} var IteratorPrototype = {}; define(IteratorPrototype, iteratorSymbol, function () { return this; }); var getProto = Object.getPrototypeOf, NativeIteratorPrototype = getProto && getProto(getProto(values([]))); NativeIteratorPrototype && NativeIteratorPrototype !== Op && hasOwn.call(NativeIteratorPrototype, iteratorSymbol) && (IteratorPrototype = NativeIteratorPrototype); var Gp = GeneratorFunctionPrototype.prototype = Generator.prototype = Object.create(IteratorPrototype); function defineIteratorMethods(prototype) { ["next", "throw", "return"].forEach(function (method) { define(prototype, method, function (arg) { return this._invoke(method, arg); }); }); } function AsyncIterator(generator, PromiseImpl) { function invoke(method, arg, resolve, reject) { var record = tryCatch(generator[method], generator, arg); if ("throw" !== record.type) { var result = record.arg, value = result.value; return value && "object" == typeof value && hasOwn.call(value, "__await") ? PromiseImpl.resolve(value.__await).then(function (value) { invoke("next", value, resolve, reject); }, function (err) { invoke("throw", err, resolve, reject); }) : PromiseImpl.resolve(value).then(function (unwrapped) { result.value = unwrapped, resolve(result); }, function (error) { return invoke("throw", error, resolve, reject); }); } reject(record.arg); } var previousPromise; this._invoke = function (method, arg) { function callInvokeWithMethodAndArg() { return new PromiseImpl(function (resolve, reject) { invoke(method, arg, resolve, reject); }); } return previousPromise = previousPromise ? previousPromise.then(callInvokeWithMethodAndArg, callInvokeWithMethodAndArg) : callInvokeWithMethodAndArg(); }; } function maybeInvokeDelegate(delegate, context) { var method = delegate.iterator[context.method]; if (undefined === method) { if (context.delegate = null, "throw" === context.method) { if (delegate.iterator.return && (context.method = "return", context.arg = undefined, maybeInvokeDelegate(delegate, context), "throw" === context.method)) return ContinueSentinel; context.method = "throw", context.arg = new TypeError("The iterator does not provide a 'throw' method"); } return ContinueSentinel; } var record = tryCatch(method, delegate.iterator, context.arg); if ("throw" === record.type) return context.method = "throw", context.arg = record.arg, context.delegate = null, ContinueSentinel; var info = record.arg; return info ? info.done ? (context[delegate.resultName] = info.value, context.next = delegate.nextLoc, "return" !== context.method && (context.method = "next", context.arg = undefined), context.delegate = null, ContinueSentinel) : info : (context.method = "throw", context.arg = new TypeError("iterator result is not an object"), context.delegate = null, ContinueSentinel); } function pushTryEntry(locs) { var entry = { tryLoc: locs[0] }; 1 in locs && (entry.catchLoc = locs[1]), 2 in locs && (entry.finallyLoc = locs[2], entry.afterLoc = locs[3]), this.tryEntries.push(entry); } function resetTryEntry(entry) { var record = entry.completion || {}; record.type = "normal", delete record.arg, entry.completion = record; } function Context(tryLocsList) { this.tryEntries = [{ tryLoc: "root" }], tryLocsList.forEach(pushTryEntry, this), this.reset(!0); } function values(iterable) { if (iterable) { var iteratorMethod = iterable[iteratorSymbol]; if (iteratorMethod) return iteratorMethod.call(iterable); if ("function" == typeof iterable.next) return iterable; if (!isNaN(iterable.length)) { var i = -1, next = function next() { for (; ++i < iterable.length;) { if (hasOwn.call(iterable, i)) return next.value = iterable[i], next.done = !1, next; } return next.value = undefined, next.done = !0, next; }; return next.next = next; } } return { next: doneResult }; } function doneResult() { return { value: undefined, done: !0 }; } return GeneratorFunction.prototype = GeneratorFunctionPrototype, define(Gp, "constructor", GeneratorFunctionPrototype), define(GeneratorFunctionPrototype, "constructor", GeneratorFunction), GeneratorFunction.displayName = define(GeneratorFunctionPrototype, toStringTagSymbol, "GeneratorFunction"), exports.isGeneratorFunction = function (genFun) { var ctor = "function" == typeof genFun && genFun.constructor; return !!ctor && (ctor === GeneratorFunction || "GeneratorFunction" === (ctor.displayName || ctor.name)); }, exports.mark = function (genFun) { return Object.setPrototypeOf ? Object.setPrototypeOf(genFun, GeneratorFunctionPrototype) : (genFun.__proto__ = GeneratorFunctionPrototype, define(genFun, toStringTagSymbol, "GeneratorFunction")), genFun.prototype = Object.create(Gp), genFun; }, exports.awrap = function (arg) { return { __await: arg }; }, defineIteratorMethods(AsyncIterator.prototype), define(AsyncIterator.prototype, asyncIteratorSymbol, function () { return this; }), exports.AsyncIterator = AsyncIterator, exports.async = function (innerFn, outerFn, self, tryLocsList, PromiseImpl) { void 0 === PromiseImpl && (PromiseImpl = Promise); var iter = new AsyncIterator(wrap(innerFn, outerFn, self, tryLocsList), PromiseImpl); return exports.isGeneratorFunction(outerFn) ? iter : iter.next().then(function (result) { return result.done ? result.value : iter.next(); }); }, defineIteratorMethods(Gp), define(Gp, toStringTagSymbol, "Generator"), define(Gp, iteratorSymbol, function () { return this; }), define(Gp, "toString", function () { return "[object Generator]"; }), exports.keys = function (object) { var keys = []; for (var key in object) { keys.push(key); } return keys.reverse(), function next() { for (; keys.length;) { var key = keys.pop(); if (key in object) return next.value = key, next.done = !1, next; } return next.done = !0, next; }; }, exports.values = values, Context.prototype = { constructor: Context, reset: function reset(skipTempReset) { if (this.prev = 0, this.next = 0, this.sent = this._sent = undefined, this.done = !1, this.delegate = null, this.method = "next", this.arg = undefined, this.tryEntries.forEach(resetTryEntry), !skipTempReset) for (var name in this) { "t" === name.charAt(0) && hasOwn.call(this, name) && !isNaN(+name.slice(1)) && (this[name] = undefined); } }, stop: function stop() { this.done = !0; var rootRecord = this.tryEntries[0].completion; if ("throw" === rootRecord.type) throw rootRecord.arg; return this.rval; }, dispatchException: function dispatchException(exception) { if (this.done) throw exception; var context = this; function handle(loc, caught) { return record.type = "throw", record.arg = exception, context.next = loc, caught && (context.method = "next", context.arg = undefined), !!caught; } for (var i = this.tryEntries.length - 1; i >= 0; --i) { var entry = this.tryEntries[i], record = entry.completion; if ("root" === entry.tryLoc) return handle("end"); if (entry.tryLoc <= this.prev) { var hasCatch = hasOwn.call(entry, "catchLoc"), hasFinally = hasOwn.call(entry, "finallyLoc"); if (hasCatch && hasFinally) { if (this.prev < entry.catchLoc) return handle(entry.catchLoc, !0); if (this.prev < entry.finallyLoc) return handle(entry.finallyLoc); } else if (hasCatch) { if (this.prev < entry.catchLoc) return handle(entry.catchLoc, !0); } else { if (!hasFinally) throw new Error("try statement without catch or finally"); if (this.prev < entry.finallyLoc) return handle(entry.finallyLoc); } } } }, abrupt: function abrupt(type, arg) { for (var i = this.tryEntries.length - 1; i >= 0; --i) { var entry = this.tryEntries[i]; if (entry.tryLoc <= this.prev && hasOwn.call(entry, "finallyLoc") && this.prev < entry.finallyLoc) { var finallyEntry = entry; break; } } finallyEntry && ("break" === type || "continue" === type) && finallyEntry.tryLoc <= arg && arg <= finallyEntry.finallyLoc && (finallyEntry = null); var record = finallyEntry ? finallyEntry.completion : {}; return record.type = type, record.arg = arg, finallyEntry ? (this.method = "next", this.next = finallyEntry.finallyLoc, ContinueSentinel) : this.complete(record); }, complete: function complete(record, afterLoc) { if ("throw" === record.type) throw record.arg; return "break" === record.type || "continue" === record.type ? this.next = record.arg : "return" === record.type ? (this.rval = this.arg = record.arg, this.method = "return", this.next = "end") : "normal" === record.type && afterLoc && (this.next = afterLoc), ContinueSentinel; }, finish: function finish(finallyLoc) { for (var i = this.tryEntries.length - 1; i >= 0; --i) { var entry = this.tryEntries[i]; if (entry.finallyLoc === finallyLoc) return this.complete(entry.completion, entry.afterLoc), resetTryEntry(entry), ContinueSentinel; } }, catch: function _catch(tryLoc) { for (var i = this.tryEntries.length - 1; i >= 0; --i) { var entry = this.tryEntries[i]; if (entry.tryLoc === tryLoc) { var record = entry.completion; if ("throw" === record.type) { var thrown = record.arg; resetTryEntry(entry); } return thrown; } } throw new Error("illegal catch attempt"); }, delegateYield: function delegateYield(iterable, resultName, nextLoc) { return this.delegate = { iterator: values(iterable), resultName: resultName, nextLoc: nextLoc }, "next" === this.method && (this.arg = undefined), ContinueSentinel; } }, exports; }


















var UserService = /*#__PURE__*/function () {
  function UserService(translateService, territoryService, localStorageService, navCtrl, authService, http, playerControllerService, alertService, errorService) {
    var _this = this;

    (0,_Users_smartcommunitylab_Documents_work_projects_dslab_playgo_mobile_playgo_mobile_node_modules_babel_runtime_helpers_esm_classCallCheck_js__WEBPACK_IMPORTED_MODULE_1__["default"])(this, UserService);

    this.translateService = translateService;
    this.territoryService = territoryService;
    this.localStorageService = localStorageService;
    this.navCtrl = navCtrl;
    this.authService = authService;
    this.http = http;
    this.playerControllerService = playerControllerService;
    this.alertService = alertService;
    this.errorService = errorService;
    this.userLanguageSubject = new rxjs__WEBPACK_IMPORTED_MODULE_11__.BehaviorSubject('it');
    this.userLanguage$ = this.userLanguageSubject.pipe((0,rxjs_operators__WEBPACK_IMPORTED_MODULE_12__.distinctUntilChanged)(), (0,rxjs_operators__WEBPACK_IMPORTED_MODULE_13__.shareReplay)(1));
    this.userLocaleSubject = new rxjs__WEBPACK_IMPORTED_MODULE_11__.BehaviorSubject(null);
    this.userLocale$ = this.userLocaleSubject.pipe((0,rxjs_operators__WEBPACK_IMPORTED_MODULE_12__.distinctUntilChanged)(), (0,rxjs_operators__WEBPACK_IMPORTED_MODULE_14__.filter)(function (locale) {
      return locale !== null;
    }), (0,rxjs_operators__WEBPACK_IMPORTED_MODULE_13__.shareReplay)(1));
    this.pluralRules$ = this.userLocale$.pipe((0,rxjs_operators__WEBPACK_IMPORTED_MODULE_15__.map)(function (locale) {
      return new Intl.PluralRules(locale);
    }), (0,rxjs_operators__WEBPACK_IMPORTED_MODULE_13__.shareReplay)(1));
    this.userProfile = null;
    this.userProfileRefresher$ = new rxjs__WEBPACK_IMPORTED_MODULE_16__.ReplaySubject(1);
    this.userProfileCouldBeChanged$ = (0,rxjs__WEBPACK_IMPORTED_MODULE_17__.merge)(this.authService.isReadyForApi$.pipe((0,rxjs_operators__WEBPACK_IMPORTED_MODULE_15__.map)(function () {
      return {
        isFirst: true
      };
    })), this.userProfileRefresher$.pipe((0,rxjs_operators__WEBPACK_IMPORTED_MODULE_15__.map)(function () {
      return {
        isFirst: false
      };
    })));
    this.userProfile$ = this.userProfileCouldBeChanged$.pipe((0,rxjs_operators__WEBPACK_IMPORTED_MODULE_18__.switchMap)(function (trigger) {
      return (0,tslib__WEBPACK_IMPORTED_MODULE_19__.__awaiter)(_this, void 0, void 0, /*#__PURE__*/_regeneratorRuntime().mark(function _callee() {
        return _regeneratorRuntime().wrap(function _callee$(_context) {
          while (1) {
            switch (_context.prev = _context.next) {
              case 0:
                _context.prev = 0;
                _context.next = 3;
                return this.getUserProfile();

              case 3:
                return _context.abrupt("return", _context.sent);

              case 6:
                _context.prev = 6;
                _context.t0 = _context["catch"](0);
                this.errorService.handleError(_context.t0, trigger.isFirst ? 'blocking' : 'normal');
                return _context.abrupt("return", rxjs__WEBPACK_IMPORTED_MODULE_20__.EMPTY);

              case 10:
              case "end":
                return _context.stop();
            }
          }
        }, _callee, this, [[0, 6]]);
      }));
    }), (0,rxjs_operators__WEBPACK_IMPORTED_MODULE_14__.filter)(Boolean), (0,rxjs_operators__WEBPACK_IMPORTED_MODULE_12__.distinctUntilChanged)(lodash_es__WEBPACK_IMPORTED_MODULE_21__["default"]), (0,rxjs_operators__WEBPACK_IMPORTED_MODULE_13__.shareReplay)(1));
    this.userStorage = this.localStorageService.getStorageOf('user');
    this.userProfileTerritory$ = (0,rxjs__WEBPACK_IMPORTED_MODULE_22__.combineLatest)([this.userProfile$, this.territoryService.territories$]).pipe((0,rxjs_operators__WEBPACK_IMPORTED_MODULE_15__.map)(function (_ref) {
      var _ref2 = (0,_Users_smartcommunitylab_Documents_work_projects_dslab_playgo_mobile_playgo_mobile_node_modules_babel_runtime_helpers_esm_slicedToArray_js__WEBPACK_IMPORTED_MODULE_0__["default"])(_ref, 2),
          userProfile = _ref2[0],
          territories = _ref2[1];

      return territories.find(function (territory) {
        return territory.territoryId === userProfile.territoryId;
      });
    }));
    this.userProfileMeans$ = (0,rxjs__WEBPACK_IMPORTED_MODULE_22__.combineLatest)([this.userProfile$, this.territoryService.territories$]).pipe((0,rxjs_operators__WEBPACK_IMPORTED_MODULE_15__.map)(function (_ref3) {
      var _ref4 = (0,_Users_smartcommunitylab_Documents_work_projects_dslab_playgo_mobile_playgo_mobile_node_modules_babel_runtime_helpers_esm_slicedToArray_js__WEBPACK_IMPORTED_MODULE_0__["default"])(_ref3, 2),
          userProfile = _ref4[0],
          territories = _ref4[1];

      return territories.find(function (territory) {
        return territory.territoryId === userProfile.territoryId;
      }).territoryData.means;
    }));
  }
  /**
   * User language
   *
   * Format: 'it' / 'en'
   * Returned from server.
   * */


  (0,_Users_smartcommunitylab_Documents_work_projects_dslab_playgo_mobile_playgo_mobile_node_modules_babel_runtime_helpers_esm_createClass_js__WEBPACK_IMPORTED_MODULE_2__["default"])(UserService, [{
    key: "getLanguage",
    value: function getLanguage() {
      return this.userLanguageSubject.value;
    }
    /**
     * User locale.
     *
     * Format is Unicode Locale Identifier. For example: 'it-IT' or 'en-US'.
     * Right now derived from the user language.
     * */

  }, {
    key: "getLocale",
    value: function getLocale() {
      return this.userLocaleSubject.value;
    }
    /**
     * @throws http error
     */

  }, {
    key: "uploadAvatar",
    value: function uploadAvatar(file) {
      var formData = new FormData();
      formData.append('data', file);
      return this.playerControllerService.uploadPlayerAvatarUsingPOST(formData).toPromise();
    }
    /**
     * do not throw http error
     */

  }, {
    key: "getAvatar",
    value: function getAvatar(user) {
      var _this2 = this;

      var avatarDefaults = {
        avatarSmallUrl: 'assets/images/registration/generic_user.png',
        avatarUrl: 'assets/images/registration/generic_user.png'
      };
      return this.playerControllerService.getPlayerAvatarUsingGET(user === null || user === void 0 ? void 0 : user.playerId).pipe((0,rxjs_operators__WEBPACK_IMPORTED_MODULE_23__.catchError)(function (error) {
        var _a;

        if (error instanceof _angular_common_http__WEBPACK_IMPORTED_MODULE_24__.HttpErrorResponse && (error.status === 404 || error.status === 400) && ((_a = error.error) === null || _a === void 0 ? void 0 : _a.ex) === 'avatar not found') {
          return (0,rxjs__WEBPACK_IMPORTED_MODULE_25__.of)(avatarDefaults);
        } // we do not want to block app completely.


        _this2.errorService.handleError(error, 'normal');

        return (0,rxjs__WEBPACK_IMPORTED_MODULE_25__.of)(avatarDefaults);
      }), (0,rxjs_operators__WEBPACK_IMPORTED_MODULE_15__.map)(function (avatar) {
        return Object.assign(Object.assign({}, avatarDefaults), avatar);
      })).toPromise();
    }
    /**
     * do not throw http error
     */

  }, {
    key: "getOtherPlayerAvatar",
    value: function getOtherPlayerAvatar(playerId) {
      var _this3 = this;

      var avatarDefaults = {
        avatarSmallUrl: 'assets/images/registration/generic_user.png',
        avatarUrl: 'assets/images/registration/generic_user.png'
      };
      return this.playerControllerService.getPlayerAvatarUsingGET(playerId).pipe((0,rxjs_operators__WEBPACK_IMPORTED_MODULE_23__.catchError)(function (error) {
        var _a;

        if (error instanceof _angular_common_http__WEBPACK_IMPORTED_MODULE_24__.HttpErrorResponse && (error.status === 404 || error.status === 400) && ((_a = error.error) === null || _a === void 0 ? void 0 : _a.ex) === 'avatar not found') {
          return (0,rxjs__WEBPACK_IMPORTED_MODULE_25__.of)(avatarDefaults);
        } // we do not want to block app completely.


        _this3.errorService.handleError(error, 'normal');

        return (0,rxjs__WEBPACK_IMPORTED_MODULE_25__.of)(avatarDefaults);
      }), (0,rxjs_operators__WEBPACK_IMPORTED_MODULE_15__.map)(function (avatar) {
        return Object.assign(Object.assign({}, avatarDefaults), avatar);
      }));
    }
    /**
     * @throws http error
     */

  }, {
    key: "getAACUserInfo",
    value: function getAACUserInfo() {
      return this.http.request('GET', src_environments_environment__WEBPACK_IMPORTED_MODULE_3__.environment.authConfig.server_host + '/userinfo').toPromise();
    }
    /**
     * does not throw http error
     */

  }, {
    key: "changeLanguage",
    value: function changeLanguage(language) {
      if (!language) {
        return;
      }

      this.translateService.use(language);
      this.userLanguageSubject.next(language);

      switch (language) {
        case 'it':
          {
            this.userLocaleSubject.next('it-IT');
            break;
          }

        case 'en':
          {
            this.userLocaleSubject.next('en-US');
            break;
          }
      }
    }
    /**
     * @throws http error
     */

  }, {
    key: "getUserProfile",
    value: function getUserProfile() {
      return (0,tslib__WEBPACK_IMPORTED_MODULE_19__.__awaiter)(this, void 0, void 0, /*#__PURE__*/_regeneratorRuntime().mark(function _callee2() {
        var user;
        return _regeneratorRuntime().wrap(function _callee2$(_context2) {
          while (1) {
            switch (_context2.prev = _context2.next) {
              case 0:
                _context2.prev = 0;
                _context2.next = 3;
                return this.getProfile();

              case 3:
                user = _context2.sent;
                _context2.next = 6;
                return this.getAvatar(user);

              case 6:
                user.avatar = _context2.sent;
                _context2.next = 18;
                break;

              case 9:
                _context2.prev = 9;
                _context2.t0 = _context2["catch"](0);

                if (!(0,_utils__WEBPACK_IMPORTED_MODULE_4__.isOfflineError)(_context2.t0)) {
                  _context2.next = 17;
                  break;
                }

                _context2.next = 14;
                return this.userStorage.get();

              case 14:
                user = _context2.sent;
                _context2.next = 18;
                break;

              case 17:
                throw _context2.t0;

              case 18:
                if (user) {
                  _context2.next = 21;
                  break;
                }

                this.navCtrl.navigateRoot('/pages/registration');
                return _context2.abrupt("return");

              case 21:
                this.userProfile = user;
                _context2.next = 24;
                return this.processUser(user);

              case 24:
                _context2.next = 26;
                return this.storeUserInLocalStorage(user);

              case 26:
                return _context2.abrupt("return", user);

              case 27:
              case "end":
                return _context2.stop();
            }
          }
        }, _callee2, this, [[0, 9]]);
      }));
    }
  }, {
    key: "storeUserInLocalStorage",
    value: function storeUserInLocalStorage(userWithAvatar) {
      return (0,tslib__WEBPACK_IMPORTED_MODULE_19__.__awaiter)(this, void 0, void 0, /*#__PURE__*/_regeneratorRuntime().mark(function _callee3() {
        var lastStoredUser;
        return _regeneratorRuntime().wrap(function _callee3$(_context3) {
          while (1) {
            switch (_context3.prev = _context3.next) {
              case 0:
                _context3.next = 2;
                return this.userStorage.get();

              case 2:
                lastStoredUser = _context3.sent;

                if (lastStoredUser && lastStoredUser.playerId !== userWithAvatar.playerId) {
                  this.localStorageService.clearAll();
                }

                this.userStorage.set(userWithAvatar);

              case 5:
              case "end":
                return _context3.stop();
            }
          }
        }, _callee3, this);
      }));
    }
    /**
     * @throws http error
     */

  }, {
    key: "handleAfterUserRegistered",
    value: function handleAfterUserRegistered() {
      return (0,tslib__WEBPACK_IMPORTED_MODULE_19__.__awaiter)(this, void 0, void 0, /*#__PURE__*/_regeneratorRuntime().mark(function _callee4() {
        return _regeneratorRuntime().wrap(function _callee4$(_context4) {
          while (1) {
            switch (_context4.prev = _context4.next) {
              case 0:
                _context4.next = 2;
                return this.getUserProfile();

              case 2:
              case "end":
                return _context4.stop();
            }
          }
        }, _callee4, this);
      }));
    }
  }, {
    key: "updateImages",
    value: function updateImages(avatar) {
      return (0,tslib__WEBPACK_IMPORTED_MODULE_19__.__awaiter)(this, void 0, void 0, /*#__PURE__*/_regeneratorRuntime().mark(function _callee5() {
        return _regeneratorRuntime().wrap(function _callee5$(_context5) {
          while (1) {
            switch (_context5.prev = _context5.next) {
              case 0:
                this.userProfile.avatar = avatar;

              case 1:
              case "end":
                return _context5.stop();
            }
          }
        }, _callee5, this);
      }));
    }
    /**
     *
     * @param user
     * @throws http error
     */

  }, {
    key: "processUser",
    value: function processUser(user) {
      return (0,tslib__WEBPACK_IMPORTED_MODULE_19__.__awaiter)(this, void 0, void 0, /*#__PURE__*/_regeneratorRuntime().mark(function _callee6() {
        return _regeneratorRuntime().wrap(function _callee6$(_context6) {
          while (1) {
            switch (_context6.prev = _context6.next) {
              case 0:
                _context6.next = 2;
                return this.setUserProfileMeans(user.territoryId);

              case 2:
                this.changeLanguage(user.language);

              case 3:
              case "end":
                return _context6.stop();
            }
          }
        }, _callee6, this);
      }));
    }
    /**
     *
     * @param territoryId
     * @returns list of means
     * @throws http error
     */

  }, {
    key: "setUserProfileMeans",
    value: function setUserProfileMeans(territoryId) {
      return (0,tslib__WEBPACK_IMPORTED_MODULE_19__.__awaiter)(this, void 0, void 0, /*#__PURE__*/_regeneratorRuntime().mark(function _callee7() {
        var userTerritory;
        return _regeneratorRuntime().wrap(function _callee7$(_context7) {
          while (1) {
            switch (_context7.prev = _context7.next) {
              case 0:
                _context7.next = 2;
                return this.territoryService.getTerritory(territoryId).toPromise();

              case 2:
                userTerritory = _context7.sent;
                return _context7.abrupt("return", userTerritory.territoryData.means);

              case 4:
              case "end":
                return _context7.stop();
            }
          }
        }, _callee7, this);
      }));
    }
    /**
     *
     * @param user
     * @returns
     * @throws http error
     */

  }, {
    key: "registerPlayer",
    value: function registerPlayer(user) {
      //TODO update local profile
      return this.playerControllerService.registerPlayerUsingPOST(user).toPromise();
    }
    /**
     * Call api to test if user is registered
     *
     * @returns true / false / null = not known
     *
     * does not throw http error
     */

  }, {
    key: "isUserRegistered",
    value: function isUserRegistered() {
      return (0,tslib__WEBPACK_IMPORTED_MODULE_19__.__awaiter)(this, void 0, void 0, /*#__PURE__*/_regeneratorRuntime().mark(function _callee8() {
        var user;
        return _regeneratorRuntime().wrap(function _callee8$(_context8) {
          while (1) {
            switch (_context8.prev = _context8.next) {
              case 0:
                _context8.prev = 0;
                _context8.next = 3;
                return this.playerControllerService.getProfileUsingGET().toPromise();

              case 3:
                user = _context8.sent;

                if (!user) {
                  _context8.next = 8;
                  break;
                }

                return _context8.abrupt("return", true);

              case 8:
                return _context8.abrupt("return", false);

              case 9:
                _context8.next = 15;
                break;

              case 11:
                _context8.prev = 11;
                _context8.t0 = _context8["catch"](0);
                // toto check local storage
                console.warn(_context8.t0);
                return _context8.abrupt("return", null);

              case 15:
              case "end":
                return _context8.stop();
            }
          }
        }, _callee8, this, [[0, 11]]);
      }));
    }
    /**
     *
     * @returns player profile
     * @throws http error
     */

  }, {
    key: "getProfile",
    value: function getProfile() {
      return this.playerControllerService.getProfileUsingGET().toPromise();
    }
    /**
     *
     * @param user player profile
     * @returns updated player profile
     * @throws http error
     */

  }, {
    key: "updatePlayer",
    value: function updatePlayer(user) {
      return (0,tslib__WEBPACK_IMPORTED_MODULE_19__.__awaiter)(this, void 0, void 0, /*#__PURE__*/_regeneratorRuntime().mark(function _callee9() {
        var player;
        return _regeneratorRuntime().wrap(function _callee9$(_context9) {
          while (1) {
            switch (_context9.prev = _context9.next) {
              case 0:
                _context9.next = 2;
                return this.playerControllerService.updateProfileUsingPUT(user).toPromise();

              case 2:
                player = _context9.sent;
                this.processUser(user);
                return _context9.abrupt("return", player);

              case 5:
              case "end":
                return _context9.stop();
            }
          }
        }, _callee9, this);
      }));
    }
  }]);

  return UserService;
}();

UserService.ɵfac = function UserService_Factory(t) {
  return new (t || UserService)(_angular_core__WEBPACK_IMPORTED_MODULE_26__["ɵɵinject"](_ngx_translate_core__WEBPACK_IMPORTED_MODULE_27__.TranslateService), _angular_core__WEBPACK_IMPORTED_MODULE_26__["ɵɵinject"](_territory_service__WEBPACK_IMPORTED_MODULE_5__.TerritoryService), _angular_core__WEBPACK_IMPORTED_MODULE_26__["ɵɵinject"](_local_storage_service__WEBPACK_IMPORTED_MODULE_6__.LocalStorageService), _angular_core__WEBPACK_IMPORTED_MODULE_26__["ɵɵinject"](_ionic_angular__WEBPACK_IMPORTED_MODULE_28__.NavController), _angular_core__WEBPACK_IMPORTED_MODULE_26__["ɵɵinject"](_auth_auth_service__WEBPACK_IMPORTED_MODULE_7__.AuthService), _angular_core__WEBPACK_IMPORTED_MODULE_26__["ɵɵinject"](_angular_common_http__WEBPACK_IMPORTED_MODULE_24__.HttpClient), _angular_core__WEBPACK_IMPORTED_MODULE_26__["ɵɵinject"](_api_generated_controllers_playerController_service__WEBPACK_IMPORTED_MODULE_8__.PlayerControllerService), _angular_core__WEBPACK_IMPORTED_MODULE_26__["ɵɵinject"](_alert_service__WEBPACK_IMPORTED_MODULE_9__.AlertService), _angular_core__WEBPACK_IMPORTED_MODULE_26__["ɵɵinject"](_error_service__WEBPACK_IMPORTED_MODULE_10__.ErrorService));
};

UserService.ɵprov = /*@__PURE__*/_angular_core__WEBPACK_IMPORTED_MODULE_26__["ɵɵdefineInjectable"]({
  token: UserService,
  factory: UserService.ɵfac,
  providedIn: 'root'
});

/***/ }),

/***/ 36980:
/*!***************************************************!*\
  !*** ./src/app/core/shared/shared-libs.module.ts ***!
  \***************************************************/
/***/ (function(__unused_webpack_module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "PlayGoSharedLibsModule": function() { return /* binding */ PlayGoSharedLibsModule; }
/* harmony export */ });
/* harmony import */ var _Users_smartcommunitylab_Documents_work_projects_dslab_playgo_mobile_playgo_mobile_node_modules_babel_runtime_helpers_esm_createClass_js__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./node_modules/@babel/runtime/helpers/esm/createClass.js */ 48047);
/* harmony import */ var _Users_smartcommunitylab_Documents_work_projects_dslab_playgo_mobile_playgo_mobile_node_modules_babel_runtime_helpers_esm_classCallCheck_js__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ./node_modules/@babel/runtime/helpers/esm/classCallCheck.js */ 78069);
/* harmony import */ var _angular_common__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! @angular/common */ 36362);
/* harmony import */ var _angular_forms__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! @angular/forms */ 90587);
/* harmony import */ var _ionic_angular__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! @ionic/angular */ 93819);
/* harmony import */ var _ngx_translate_core__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @ngx-translate/core */ 87514);
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @angular/core */ 3184);







var PlayGoSharedLibsModule = /*#__PURE__*/(0,_Users_smartcommunitylab_Documents_work_projects_dslab_playgo_mobile_playgo_mobile_node_modules_babel_runtime_helpers_esm_createClass_js__WEBPACK_IMPORTED_MODULE_0__["default"])(function PlayGoSharedLibsModule() {
  (0,_Users_smartcommunitylab_Documents_work_projects_dslab_playgo_mobile_playgo_mobile_node_modules_babel_runtime_helpers_esm_classCallCheck_js__WEBPACK_IMPORTED_MODULE_1__["default"])(this, PlayGoSharedLibsModule);
});

PlayGoSharedLibsModule.ɵfac = function PlayGoSharedLibsModule_Factory(t) {
  return new (t || PlayGoSharedLibsModule)();
};

PlayGoSharedLibsModule.ɵmod = /*@__PURE__*/_angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵdefineNgModule"]({
  type: PlayGoSharedLibsModule
});
PlayGoSharedLibsModule.ɵinj = /*@__PURE__*/_angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵdefineInjector"]({
  imports: [[_ngx_translate_core__WEBPACK_IMPORTED_MODULE_3__.TranslateModule], _angular_forms__WEBPACK_IMPORTED_MODULE_4__.FormsModule, _angular_common__WEBPACK_IMPORTED_MODULE_5__.CommonModule, _ionic_angular__WEBPACK_IMPORTED_MODULE_6__.IonicModule, _angular_forms__WEBPACK_IMPORTED_MODULE_4__.ReactiveFormsModule, _ngx_translate_core__WEBPACK_IMPORTED_MODULE_3__.TranslateModule]
});

(function () {
  (typeof ngJitMode === "undefined" || ngJitMode) && _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵsetNgModuleScope"](PlayGoSharedLibsModule, {
    imports: [_ngx_translate_core__WEBPACK_IMPORTED_MODULE_3__.TranslateModule],
    exports: [_angular_forms__WEBPACK_IMPORTED_MODULE_4__.FormsModule, _angular_common__WEBPACK_IMPORTED_MODULE_5__.CommonModule, _ionic_angular__WEBPACK_IMPORTED_MODULE_6__.IonicModule, _angular_forms__WEBPACK_IMPORTED_MODULE_4__.ReactiveFormsModule, _ngx_translate_core__WEBPACK_IMPORTED_MODULE_3__.TranslateModule]
  });
})();

/***/ }),

/***/ 97205:
/*!**********************************************!*\
  !*** ./src/app/core/shared/shared.module.ts ***!
  \**********************************************/
/***/ (function(__unused_webpack_module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "PlayGoSharedModule": function() { return /* binding */ PlayGoSharedModule; }
/* harmony export */ });
/* harmony import */ var _Users_smartcommunitylab_Documents_work_projects_dslab_playgo_mobile_playgo_mobile_node_modules_babel_runtime_helpers_esm_createClass_js__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./node_modules/@babel/runtime/helpers/esm/createClass.js */ 48047);
/* harmony import */ var _Users_smartcommunitylab_Documents_work_projects_dslab_playgo_mobile_playgo_mobile_node_modules_babel_runtime_helpers_esm_classCallCheck_js__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ./node_modules/@babel/runtime/helpers/esm/classCallCheck.js */ 78069);
/* harmony import */ var _campaigns_my_campaign_card_my_campaign_card_component__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! ./campaigns/my-campaign-card/my-campaign-card.component */ 51790);
/* harmony import */ var _campaigns_public_campaign_card_public_campaign_card_component__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! ./campaigns/public-campaign-card/public-campaign-card.component */ 23936);
/* harmony import */ var _pipes_localDate_pipe__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! ./pipes/localDate.pipe */ 34489);
/* harmony import */ var _pipes_localNumber_pipe__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! ./pipes/localNumber.pipe */ 89713);
/* harmony import */ var _profile_components_profile_component_profile_component__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! ./profile-components/profile-component/profile.component */ 7054);
/* harmony import */ var _services_alert_service__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(/*! ./services/alert.service */ 46407);
/* harmony import */ var _shared_libs_module__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(/*! ./shared-libs.module */ 36980);
/* harmony import */ var _infinite_scroll_infinite_scroll_component__WEBPACK_IMPORTED_MODULE_9__ = __webpack_require__(/*! ./infinite-scroll/infinite-scroll.component */ 3299);
/* harmony import */ var _layout_header_header_content_component__WEBPACK_IMPORTED_MODULE_10__ = __webpack_require__(/*! ./layout/header/header-content.component */ 322);
/* harmony import */ var _globalization_ordinal_number_ordinal_number_component__WEBPACK_IMPORTED_MODULE_11__ = __webpack_require__(/*! ./globalization/ordinal-number/ordinal-number.component */ 56032);
/* harmony import */ var _campaigns_main_campaign_stat_main_campaign_stat_component__WEBPACK_IMPORTED_MODULE_12__ = __webpack_require__(/*! ./campaigns/main-campaign-stat/main-campaign-stat.component */ 61646);
/* harmony import */ var src_app_pages_home_profile_privacy_modal_privacyModal_component__WEBPACK_IMPORTED_MODULE_13__ = __webpack_require__(/*! src/app/pages/home/profile/privacy-modal/privacyModal.component */ 73081);
/* harmony import */ var _directives_parallax_header_directive__WEBPACK_IMPORTED_MODULE_14__ = __webpack_require__(/*! ./directives/parallax-header.directive */ 2773);
/* harmony import */ var _campaigns_home_widget_types_home_campaign_city_home_campaign_city_component__WEBPACK_IMPORTED_MODULE_15__ = __webpack_require__(/*! ./campaigns/home-widget-types/home-campaign-city/home-campaign-city.component */ 96784);
/* harmony import */ var _campaigns_home_widget_types_home_campaign_school_home_campaign_school_component__WEBPACK_IMPORTED_MODULE_16__ = __webpack_require__(/*! ./campaigns/home-widget-types/home-campaign-school/home-campaign-school.component */ 37374);
/* harmony import */ var _campaigns_home_widget_types_home_campaign_company_home_campaign_company_component__WEBPACK_IMPORTED_MODULE_17__ = __webpack_require__(/*! ./campaigns/home-widget-types/home-campaign-company/home-campaign-company.component */ 10881);
/* harmony import */ var _campaigns_home_widget_types_home_campaign_personal_home_campaign_personal_component__WEBPACK_IMPORTED_MODULE_18__ = __webpack_require__(/*! ./campaigns/home-widget-types/home-campaign-personal/home-campaign-personal.component */ 90706);
/* harmony import */ var _campaigns_app_widget_campaign_app_widget_campaign_component__WEBPACK_IMPORTED_MODULE_19__ = __webpack_require__(/*! ./campaigns/app-widget-campaign/app-widget-campaign.component */ 519);
/* harmony import */ var _ui_icon_icon_component__WEBPACK_IMPORTED_MODULE_20__ = __webpack_require__(/*! ./ui/icon/icon.component */ 71888);
/* harmony import */ var _campaigns_main_campaign_stat_game_status_game_status_component__WEBPACK_IMPORTED_MODULE_21__ = __webpack_require__(/*! ./campaigns/main-campaign-stat/game-status/game-status.component */ 43471);
/* harmony import */ var _campaigns_main_campaign_stat_record_status_record_status_component__WEBPACK_IMPORTED_MODULE_22__ = __webpack_require__(/*! ./campaigns/main-campaign-stat/record-status/record-status.component */ 13204);
/* harmony import */ var _pipes_languageMap_pipe__WEBPACK_IMPORTED_MODULE_23__ = __webpack_require__(/*! ./pipes/languageMap.pipe */ 73088);
/* harmony import */ var _detail_notification_detail_notification_modal__WEBPACK_IMPORTED_MODULE_24__ = __webpack_require__(/*! ./detail-notification/detail-notification.modal */ 72526);
/* harmony import */ var _detail_notification_detail_notification_level_detail_notification_level_component__WEBPACK_IMPORTED_MODULE_25__ = __webpack_require__(/*! ./detail-notification/detail-notification-level/detail-notification-level.component */ 52726);
/* harmony import */ var _detail_notification_detail_notification_badge_detail_notification_badge_component__WEBPACK_IMPORTED_MODULE_26__ = __webpack_require__(/*! ./detail-notification/detail-notification-badge/detail-notification-badge.component */ 41019);
/* harmony import */ var _campaigns_home_widget_types_notification_badge_notification_badge_component__WEBPACK_IMPORTED_MODULE_27__ = __webpack_require__(/*! ./campaigns/home-widget-types/notification-badge/notification-badge.component */ 36036);
/* harmony import */ var _pipes_SafeHtml_pipe__WEBPACK_IMPORTED_MODULE_28__ = __webpack_require__(/*! ./pipes/SafeHtml.pipe */ 39107);
/* harmony import */ var _campaigns_app_widget_campaign_app_home_campaign_challenges_app_home_campaign_challenges_component__WEBPACK_IMPORTED_MODULE_29__ = __webpack_require__(/*! ./campaigns/app-widget-campaign/app-home-campaign-challenges/app-home-campaign-challenges.component */ 40201);
/* harmony import */ var _layout_header_header_directive__WEBPACK_IMPORTED_MODULE_30__ = __webpack_require__(/*! ./layout/header/header.directive */ 34161);
/* harmony import */ var _campaigns_app_widget_campaign_active_challenge_active_challenge_component__WEBPACK_IMPORTED_MODULE_31__ = __webpack_require__(/*! ./campaigns/app-widget-campaign/active-challenge/active-challenge.component */ 4765);
/* harmony import */ var _campaigns_challenge_users_status_challenge_users_status_component__WEBPACK_IMPORTED_MODULE_32__ = __webpack_require__(/*! ./campaigns/challenge-users-status/challenge-users-status.component */ 47298);
/* harmony import */ var _campaigns_challenge_bar_status_challenge_bar_status_component__WEBPACK_IMPORTED_MODULE_33__ = __webpack_require__(/*! ./campaigns/challenge-bar-status/challenge-bar-status.component */ 69723);
/* harmony import */ var _campaigns_main_campaign_stat_limit_status_limit_status_component__WEBPACK_IMPORTED_MODULE_34__ = __webpack_require__(/*! ./campaigns/main-campaign-stat/limit-status/limit-status.component */ 78650);
/* harmony import */ var _notification_modal_notification_modal__WEBPACK_IMPORTED_MODULE_35__ = __webpack_require__(/*! ./notification-modal/notification.modal */ 19736);
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_36__ = __webpack_require__(/*! @angular/core */ 3184);





































var PlayGoSharedModule = /*#__PURE__*/(0,_Users_smartcommunitylab_Documents_work_projects_dslab_playgo_mobile_playgo_mobile_node_modules_babel_runtime_helpers_esm_createClass_js__WEBPACK_IMPORTED_MODULE_0__["default"])(function PlayGoSharedModule() {
  (0,_Users_smartcommunitylab_Documents_work_projects_dslab_playgo_mobile_playgo_mobile_node_modules_babel_runtime_helpers_esm_classCallCheck_js__WEBPACK_IMPORTED_MODULE_1__["default"])(this, PlayGoSharedModule);
});

PlayGoSharedModule.ɵfac = function PlayGoSharedModule_Factory(t) {
  return new (t || PlayGoSharedModule)();
};

PlayGoSharedModule.ɵmod = /*@__PURE__*/_angular_core__WEBPACK_IMPORTED_MODULE_36__["ɵɵdefineNgModule"]({
  type: PlayGoSharedModule
});
PlayGoSharedModule.ɵinj = /*@__PURE__*/_angular_core__WEBPACK_IMPORTED_MODULE_36__["ɵɵdefineInjector"]({
  providers: [_services_alert_service__WEBPACK_IMPORTED_MODULE_7__.AlertService],
  imports: [[_shared_libs_module__WEBPACK_IMPORTED_MODULE_8__.PlayGoSharedLibsModule], _shared_libs_module__WEBPACK_IMPORTED_MODULE_8__.PlayGoSharedLibsModule]
});

(function () {
  (typeof ngJitMode === "undefined" || ngJitMode) && _angular_core__WEBPACK_IMPORTED_MODULE_36__["ɵɵsetNgModuleScope"](PlayGoSharedModule, {
    declarations: [_campaigns_my_campaign_card_my_campaign_card_component__WEBPACK_IMPORTED_MODULE_2__.MyCampaignCardComponent, _campaigns_main_campaign_stat_main_campaign_stat_component__WEBPACK_IMPORTED_MODULE_12__.MainCampaignStatComponent, _campaigns_public_campaign_card_public_campaign_card_component__WEBPACK_IMPORTED_MODULE_3__.PublicCampaignCardComponent, _layout_header_header_content_component__WEBPACK_IMPORTED_MODULE_10__.HeaderContentComponent, _layout_header_header_directive__WEBPACK_IMPORTED_MODULE_30__.HeaderDirective, _profile_components_profile_component_profile_component__WEBPACK_IMPORTED_MODULE_6__.ProfileComponent, src_app_pages_home_profile_privacy_modal_privacyModal_component__WEBPACK_IMPORTED_MODULE_13__.PrivacyModalPage, _detail_notification_detail_notification_modal__WEBPACK_IMPORTED_MODULE_24__.DetailNotificationModalPage, _pipes_localDate_pipe__WEBPACK_IMPORTED_MODULE_4__.LocalDatePipe, _pipes_localNumber_pipe__WEBPACK_IMPORTED_MODULE_5__.LocalNumberPipe, _pipes_SafeHtml_pipe__WEBPACK_IMPORTED_MODULE_28__.SafeHtmlPipe, _pipes_languageMap_pipe__WEBPACK_IMPORTED_MODULE_23__.LanguageMapPipe, _infinite_scroll_infinite_scroll_component__WEBPACK_IMPORTED_MODULE_9__.InfiniteScrollComponent, _infinite_scroll_infinite_scroll_component__WEBPACK_IMPORTED_MODULE_9__.InfiniteScrollContentDirective, _directives_parallax_header_directive__WEBPACK_IMPORTED_MODULE_14__.ParallaxDirective, _globalization_ordinal_number_ordinal_number_component__WEBPACK_IMPORTED_MODULE_11__.OrdinalNumberComponent, _campaigns_home_widget_types_home_campaign_city_home_campaign_city_component__WEBPACK_IMPORTED_MODULE_15__.HomeCampaignCityComponent, _campaigns_home_widget_types_home_campaign_school_home_campaign_school_component__WEBPACK_IMPORTED_MODULE_16__.HomeCampaignSchoolComponent, _campaigns_home_widget_types_home_campaign_company_home_campaign_company_component__WEBPACK_IMPORTED_MODULE_17__.HomeCampaignCompanyComponent, _campaigns_home_widget_types_home_campaign_personal_home_campaign_personal_component__WEBPACK_IMPORTED_MODULE_18__.HomeCampaignPersonalComponent, _campaigns_home_widget_types_notification_badge_notification_badge_component__WEBPACK_IMPORTED_MODULE_27__.NotificationBadgeComponent, _campaigns_main_campaign_stat_record_status_record_status_component__WEBPACK_IMPORTED_MODULE_22__.RecordStatusComponent, _campaigns_main_campaign_stat_game_status_game_status_component__WEBPACK_IMPORTED_MODULE_21__.GameStatusComponent, _campaigns_app_widget_campaign_app_widget_campaign_component__WEBPACK_IMPORTED_MODULE_19__.WidgetComponent, _ui_icon_icon_component__WEBPACK_IMPORTED_MODULE_20__.IconComponent, _campaigns_app_widget_campaign_app_home_campaign_challenges_app_home_campaign_challenges_component__WEBPACK_IMPORTED_MODULE_29__.HomeCampaignChallengeComponent, _campaigns_app_widget_campaign_active_challenge_active_challenge_component__WEBPACK_IMPORTED_MODULE_31__.ActiveChallengeComponent, _campaigns_challenge_users_status_challenge_users_status_component__WEBPACK_IMPORTED_MODULE_32__.ChallengeUsersStatusComponent, _campaigns_challenge_bar_status_challenge_bar_status_component__WEBPACK_IMPORTED_MODULE_33__.ChallengeBarStatusComponent, _detail_notification_detail_notification_level_detail_notification_level_component__WEBPACK_IMPORTED_MODULE_25__.DetailNotificationLevelComponent, _detail_notification_detail_notification_badge_detail_notification_badge_component__WEBPACK_IMPORTED_MODULE_26__.DetailNotificationBadgeComponent, _campaigns_main_campaign_stat_limit_status_limit_status_component__WEBPACK_IMPORTED_MODULE_34__.LimitStatusComponent, _notification_modal_notification_modal__WEBPACK_IMPORTED_MODULE_35__.NotificationModalPage],
    imports: [_shared_libs_module__WEBPACK_IMPORTED_MODULE_8__.PlayGoSharedLibsModule],
    exports: [_shared_libs_module__WEBPACK_IMPORTED_MODULE_8__.PlayGoSharedLibsModule, _campaigns_my_campaign_card_my_campaign_card_component__WEBPACK_IMPORTED_MODULE_2__.MyCampaignCardComponent, _campaigns_main_campaign_stat_main_campaign_stat_component__WEBPACK_IMPORTED_MODULE_12__.MainCampaignStatComponent, _campaigns_public_campaign_card_public_campaign_card_component__WEBPACK_IMPORTED_MODULE_3__.PublicCampaignCardComponent, _profile_components_profile_component_profile_component__WEBPACK_IMPORTED_MODULE_6__.ProfileComponent, src_app_pages_home_profile_privacy_modal_privacyModal_component__WEBPACK_IMPORTED_MODULE_13__.PrivacyModalPage, _detail_notification_detail_notification_modal__WEBPACK_IMPORTED_MODULE_24__.DetailNotificationModalPage, _pipes_localDate_pipe__WEBPACK_IMPORTED_MODULE_4__.LocalDatePipe, _pipes_languageMap_pipe__WEBPACK_IMPORTED_MODULE_23__.LanguageMapPipe, _layout_header_header_content_component__WEBPACK_IMPORTED_MODULE_10__.HeaderContentComponent, _layout_header_header_directive__WEBPACK_IMPORTED_MODULE_30__.HeaderDirective, _pipes_localNumber_pipe__WEBPACK_IMPORTED_MODULE_5__.LocalNumberPipe, _pipes_SafeHtml_pipe__WEBPACK_IMPORTED_MODULE_28__.SafeHtmlPipe, _infinite_scroll_infinite_scroll_component__WEBPACK_IMPORTED_MODULE_9__.InfiniteScrollComponent, _infinite_scroll_infinite_scroll_component__WEBPACK_IMPORTED_MODULE_9__.InfiniteScrollContentDirective, _directives_parallax_header_directive__WEBPACK_IMPORTED_MODULE_14__.ParallaxDirective, _globalization_ordinal_number_ordinal_number_component__WEBPACK_IMPORTED_MODULE_11__.OrdinalNumberComponent, _campaigns_home_widget_types_home_campaign_city_home_campaign_city_component__WEBPACK_IMPORTED_MODULE_15__.HomeCampaignCityComponent, _campaigns_home_widget_types_home_campaign_school_home_campaign_school_component__WEBPACK_IMPORTED_MODULE_16__.HomeCampaignSchoolComponent, _campaigns_home_widget_types_home_campaign_company_home_campaign_company_component__WEBPACK_IMPORTED_MODULE_17__.HomeCampaignCompanyComponent, _campaigns_home_widget_types_home_campaign_personal_home_campaign_personal_component__WEBPACK_IMPORTED_MODULE_18__.HomeCampaignPersonalComponent, _campaigns_home_widget_types_notification_badge_notification_badge_component__WEBPACK_IMPORTED_MODULE_27__.NotificationBadgeComponent, _campaigns_main_campaign_stat_game_status_game_status_component__WEBPACK_IMPORTED_MODULE_21__.GameStatusComponent, _campaigns_main_campaign_stat_record_status_record_status_component__WEBPACK_IMPORTED_MODULE_22__.RecordStatusComponent, _campaigns_app_widget_campaign_app_widget_campaign_component__WEBPACK_IMPORTED_MODULE_19__.WidgetComponent, _ui_icon_icon_component__WEBPACK_IMPORTED_MODULE_20__.IconComponent, _campaigns_app_widget_campaign_app_home_campaign_challenges_app_home_campaign_challenges_component__WEBPACK_IMPORTED_MODULE_29__.HomeCampaignChallengeComponent, _campaigns_app_widget_campaign_active_challenge_active_challenge_component__WEBPACK_IMPORTED_MODULE_31__.ActiveChallengeComponent, _campaigns_challenge_users_status_challenge_users_status_component__WEBPACK_IMPORTED_MODULE_32__.ChallengeUsersStatusComponent, _campaigns_challenge_bar_status_challenge_bar_status_component__WEBPACK_IMPORTED_MODULE_33__.ChallengeBarStatusComponent, _detail_notification_detail_notification_level_detail_notification_level_component__WEBPACK_IMPORTED_MODULE_25__.DetailNotificationLevelComponent, _detail_notification_detail_notification_badge_detail_notification_badge_component__WEBPACK_IMPORTED_MODULE_26__.DetailNotificationBadgeComponent, _campaigns_main_campaign_stat_limit_status_limit_status_component__WEBPACK_IMPORTED_MODULE_34__.LimitStatusComponent, _notification_modal_notification_modal__WEBPACK_IMPORTED_MODULE_35__.NotificationModalPage]
  });
})();

/***/ }),

/***/ 93462:
/*!*******************************************!*\
  !*** ./src/app/core/shared/time.utils.ts ***!
  \*******************************************/
/***/ (function(__unused_webpack_module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "fromServerDate": function() { return /* binding */ fromServerDate; },
/* harmony export */   "getServerTimeZone": function() { return /* binding */ getServerTimeZone; },
/* harmony export */   "toServerDateOnly": function() { return /* binding */ toServerDateOnly; },
/* harmony export */   "toServerDateTime": function() { return /* binding */ toServerDateTime; }
/* harmony export */ });
/* harmony import */ var lodash_es__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! lodash-es */ 55421);
/* harmony import */ var luxon__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! luxon */ 29527);
/**
 * All time based operation should be done with this utils.
 * If needed, we can create a service for it. (For example if timezone is not fixed)
 */


/**
 * Some information about time should be interpreted as "territory" or
 * "central" time, and not using client timezone. For example dates.
 *
 * For that occasions we need to use this timezone.
 */

function getServerTimeZone() {
  return 'Europe/Rome';
}
/**
 * Used for sending time instant to server. It is always UTC.
 *
 * Even if this function is quite trivial, using this function enables us to
 * change how time is sent to server for whole app.
 *
 * @param dateTime
 * @returns UTC dateTime milliseconds.
 */

function toServerDateTime(dateTime) {
  if ((0,lodash_es__WEBPACK_IMPORTED_MODULE_0__["default"])(dateTime)) {
    return null;
  }

  if (!dateTime.isValid) {
    console.error('Invalid dateTime', dateTime, dateTime.invalidReason, dateTime.invalidExplanation);
    throw new Error('Invalid dateTime');
  }

  return dateTime.toMillis();
}
/**
 *
 * Converts DateTime to string, but only date part.
 * It uses server timezone! (see getServerTimeZone)
 * Should be used as little as possible. Mainly for sending time information that are
 * not instances in time, but more information about "human" constructions.
 *
 * @param dateTime
 * @returns yyyy-MM-dd string in server timezone.
 */

function toServerDateOnly(dateTime) {
  if ((0,lodash_es__WEBPACK_IMPORTED_MODULE_0__["default"])(dateTime)) {
    return '';
  }

  if (!dateTime.isValid) {
    console.error('Invalid dateTime', dateTime, dateTime.invalidReason, dateTime.invalidExplanation);
    throw new Error('Invalid dateTime');
  }

  return dateTime.setZone(getServerTimeZone()).toFormat('yyyy-MM-dd');
}
/**
 * Converts server milliseconds to DateTime. Keeps null as null.
 * Only problem is that generated models has Date fields, but in runtime, they are
 * numbers.
 */

function fromServerDate(dateTime) {
  if (!dateTime) {
    return null;
  }

  return luxon__WEBPACK_IMPORTED_MODULE_1__.DateTime.fromJSDate(new Date(dateTime));
}

/***/ }),

/***/ 29872:
/*!*********************************************************************!*\
  !*** ./src/app/core/shared/tracking/background-tracking.service.ts ***!
  \*********************************************************************/
/***/ (function(__unused_webpack_module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "BackgroundTrackingService": function() { return /* binding */ BackgroundTrackingService; },
/* harmony export */   "TripLocation": function() { return /* binding */ TripLocation; }
/* harmony export */ });
/* harmony import */ var _Users_smartcommunitylab_Documents_work_projects_dslab_playgo_mobile_playgo_mobile_node_modules_babel_runtime_helpers_esm_slicedToArray_js__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./node_modules/@babel/runtime/helpers/esm/slicedToArray.js */ 10507);
/* harmony import */ var _Users_smartcommunitylab_Documents_work_projects_dslab_playgo_mobile_playgo_mobile_node_modules_babel_runtime_helpers_esm_classCallCheck_js__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ./node_modules/@babel/runtime/helpers/esm/classCallCheck.js */ 78069);
/* harmony import */ var _Users_smartcommunitylab_Documents_work_projects_dslab_playgo_mobile_playgo_mobile_node_modules_babel_runtime_helpers_esm_createClass_js__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! ./node_modules/@babel/runtime/helpers/esm/createClass.js */ 48047);
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_28__ = __webpack_require__(/*! tslib */ 34929);
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_12__ = __webpack_require__(/*! @angular/core */ 3184);
/* harmony import */ var _transistorsoft_capacitor_background_geolocation__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @transistorsoft/capacitor-background-geolocation */ 61505);
/* harmony import */ var lodash_es__WEBPACK_IMPORTED_MODULE_22__ = __webpack_require__(/*! lodash-es */ 63247);
/* harmony import */ var lodash_es__WEBPACK_IMPORTED_MODULE_23__ = __webpack_require__(/*! lodash-es */ 80946);
/* harmony import */ var lodash_es__WEBPACK_IMPORTED_MODULE_25__ = __webpack_require__(/*! lodash-es */ 10757);
/* harmony import */ var rxjs__WEBPACK_IMPORTED_MODULE_16__ = __webpack_require__(/*! rxjs */ 54240);
/* harmony import */ var rxjs__WEBPACK_IMPORTED_MODULE_18__ = __webpack_require__(/*! rxjs */ 26562);
/* harmony import */ var rxjs__WEBPACK_IMPORTED_MODULE_19__ = __webpack_require__(/*! rxjs */ 26067);
/* harmony import */ var rxjs__WEBPACK_IMPORTED_MODULE_20__ = __webpack_require__(/*! rxjs */ 36646);
/* harmony import */ var rxjs__WEBPACK_IMPORTED_MODULE_27__ = __webpack_require__(/*! rxjs */ 78947);
/* harmony import */ var rxjs__WEBPACK_IMPORTED_MODULE_29__ = __webpack_require__(/*! rxjs */ 54363);
/* harmony import */ var rxjs_operators__WEBPACK_IMPORTED_MODULE_11__ = __webpack_require__(/*! rxjs/operators */ 19337);
/* harmony import */ var rxjs_operators__WEBPACK_IMPORTED_MODULE_13__ = __webpack_require__(/*! rxjs/operators */ 89196);
/* harmony import */ var rxjs_operators__WEBPACK_IMPORTED_MODULE_14__ = __webpack_require__(/*! rxjs/operators */ 50635);
/* harmony import */ var rxjs_operators__WEBPACK_IMPORTED_MODULE_15__ = __webpack_require__(/*! rxjs/operators */ 98977);
/* harmony import */ var rxjs_operators__WEBPACK_IMPORTED_MODULE_17__ = __webpack_require__(/*! rxjs/operators */ 44874);
/* harmony import */ var rxjs_operators__WEBPACK_IMPORTED_MODULE_21__ = __webpack_require__(/*! rxjs/operators */ 32673);
/* harmony import */ var rxjs_operators__WEBPACK_IMPORTED_MODULE_24__ = __webpack_require__(/*! rxjs/operators */ 80155);
/* harmony import */ var rxjs_operators__WEBPACK_IMPORTED_MODULE_26__ = __webpack_require__(/*! rxjs/operators */ 68951);
/* harmony import */ var rxjs_operators__WEBPACK_IMPORTED_MODULE_30__ = __webpack_require__(/*! rxjs/operators */ 32313);
/* harmony import */ var _trip_model__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! ./trip.model */ 49110);
/* harmony import */ var _utils__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! ../utils */ 68647);
/* harmony import */ var src_environments_environment__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! src/environments/environment */ 92340);
/* harmony import */ var src_app_core_shared_services_alert_service__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(/*! src/app/core/shared/services/alert.service */ 46407);
/* harmony import */ var _auth_auth_service__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(/*! ../../auth/auth.service */ 88951);
/* harmony import */ var _api_generated_controllers_playerController_service__WEBPACK_IMPORTED_MODULE_9__ = __webpack_require__(/*! ../../api/generated/controllers/playerController.service */ 60148);
/* harmony import */ var _services_app_status_service__WEBPACK_IMPORTED_MODULE_10__ = __webpack_require__(/*! ../services/app-status.service */ 93656);




function _regeneratorRuntime() { "use strict"; /*! regenerator-runtime -- Copyright (c) 2014-present, Facebook, Inc. -- license (MIT): https://github.com/facebook/regenerator/blob/main/LICENSE */ _regeneratorRuntime = function _regeneratorRuntime() { return exports; }; var exports = {}, Op = Object.prototype, hasOwn = Op.hasOwnProperty, $Symbol = "function" == typeof Symbol ? Symbol : {}, iteratorSymbol = $Symbol.iterator || "@@iterator", asyncIteratorSymbol = $Symbol.asyncIterator || "@@asyncIterator", toStringTagSymbol = $Symbol.toStringTag || "@@toStringTag"; function define(obj, key, value) { return Object.defineProperty(obj, key, { value: value, enumerable: !0, configurable: !0, writable: !0 }), obj[key]; } try { define({}, ""); } catch (err) { define = function define(obj, key, value) { return obj[key] = value; }; } function wrap(innerFn, outerFn, self, tryLocsList) { var protoGenerator = outerFn && outerFn.prototype instanceof Generator ? outerFn : Generator, generator = Object.create(protoGenerator.prototype), context = new Context(tryLocsList || []); return generator._invoke = function (innerFn, self, context) { var state = "suspendedStart"; return function (method, arg) { if ("executing" === state) throw new Error("Generator is already running"); if ("completed" === state) { if ("throw" === method) throw arg; return doneResult(); } for (context.method = method, context.arg = arg;;) { var delegate = context.delegate; if (delegate) { var delegateResult = maybeInvokeDelegate(delegate, context); if (delegateResult) { if (delegateResult === ContinueSentinel) continue; return delegateResult; } } if ("next" === context.method) context.sent = context._sent = context.arg;else if ("throw" === context.method) { if ("suspendedStart" === state) throw state = "completed", context.arg; context.dispatchException(context.arg); } else "return" === context.method && context.abrupt("return", context.arg); state = "executing"; var record = tryCatch(innerFn, self, context); if ("normal" === record.type) { if (state = context.done ? "completed" : "suspendedYield", record.arg === ContinueSentinel) continue; return { value: record.arg, done: context.done }; } "throw" === record.type && (state = "completed", context.method = "throw", context.arg = record.arg); } }; }(innerFn, self, context), generator; } function tryCatch(fn, obj, arg) { try { return { type: "normal", arg: fn.call(obj, arg) }; } catch (err) { return { type: "throw", arg: err }; } } exports.wrap = wrap; var ContinueSentinel = {}; function Generator() {} function GeneratorFunction() {} function GeneratorFunctionPrototype() {} var IteratorPrototype = {}; define(IteratorPrototype, iteratorSymbol, function () { return this; }); var getProto = Object.getPrototypeOf, NativeIteratorPrototype = getProto && getProto(getProto(values([]))); NativeIteratorPrototype && NativeIteratorPrototype !== Op && hasOwn.call(NativeIteratorPrototype, iteratorSymbol) && (IteratorPrototype = NativeIteratorPrototype); var Gp = GeneratorFunctionPrototype.prototype = Generator.prototype = Object.create(IteratorPrototype); function defineIteratorMethods(prototype) { ["next", "throw", "return"].forEach(function (method) { define(prototype, method, function (arg) { return this._invoke(method, arg); }); }); } function AsyncIterator(generator, PromiseImpl) { function invoke(method, arg, resolve, reject) { var record = tryCatch(generator[method], generator, arg); if ("throw" !== record.type) { var result = record.arg, value = result.value; return value && "object" == typeof value && hasOwn.call(value, "__await") ? PromiseImpl.resolve(value.__await).then(function (value) { invoke("next", value, resolve, reject); }, function (err) { invoke("throw", err, resolve, reject); }) : PromiseImpl.resolve(value).then(function (unwrapped) { result.value = unwrapped, resolve(result); }, function (error) { return invoke("throw", error, resolve, reject); }); } reject(record.arg); } var previousPromise; this._invoke = function (method, arg) { function callInvokeWithMethodAndArg() { return new PromiseImpl(function (resolve, reject) { invoke(method, arg, resolve, reject); }); } return previousPromise = previousPromise ? previousPromise.then(callInvokeWithMethodAndArg, callInvokeWithMethodAndArg) : callInvokeWithMethodAndArg(); }; } function maybeInvokeDelegate(delegate, context) { var method = delegate.iterator[context.method]; if (undefined === method) { if (context.delegate = null, "throw" === context.method) { if (delegate.iterator.return && (context.method = "return", context.arg = undefined, maybeInvokeDelegate(delegate, context), "throw" === context.method)) return ContinueSentinel; context.method = "throw", context.arg = new TypeError("The iterator does not provide a 'throw' method"); } return ContinueSentinel; } var record = tryCatch(method, delegate.iterator, context.arg); if ("throw" === record.type) return context.method = "throw", context.arg = record.arg, context.delegate = null, ContinueSentinel; var info = record.arg; return info ? info.done ? (context[delegate.resultName] = info.value, context.next = delegate.nextLoc, "return" !== context.method && (context.method = "next", context.arg = undefined), context.delegate = null, ContinueSentinel) : info : (context.method = "throw", context.arg = new TypeError("iterator result is not an object"), context.delegate = null, ContinueSentinel); } function pushTryEntry(locs) { var entry = { tryLoc: locs[0] }; 1 in locs && (entry.catchLoc = locs[1]), 2 in locs && (entry.finallyLoc = locs[2], entry.afterLoc = locs[3]), this.tryEntries.push(entry); } function resetTryEntry(entry) { var record = entry.completion || {}; record.type = "normal", delete record.arg, entry.completion = record; } function Context(tryLocsList) { this.tryEntries = [{ tryLoc: "root" }], tryLocsList.forEach(pushTryEntry, this), this.reset(!0); } function values(iterable) { if (iterable) { var iteratorMethod = iterable[iteratorSymbol]; if (iteratorMethod) return iteratorMethod.call(iterable); if ("function" == typeof iterable.next) return iterable; if (!isNaN(iterable.length)) { var i = -1, next = function next() { for (; ++i < iterable.length;) { if (hasOwn.call(iterable, i)) return next.value = iterable[i], next.done = !1, next; } return next.value = undefined, next.done = !0, next; }; return next.next = next; } } return { next: doneResult }; } function doneResult() { return { value: undefined, done: !0 }; } return GeneratorFunction.prototype = GeneratorFunctionPrototype, define(Gp, "constructor", GeneratorFunctionPrototype), define(GeneratorFunctionPrototype, "constructor", GeneratorFunction), GeneratorFunction.displayName = define(GeneratorFunctionPrototype, toStringTagSymbol, "GeneratorFunction"), exports.isGeneratorFunction = function (genFun) { var ctor = "function" == typeof genFun && genFun.constructor; return !!ctor && (ctor === GeneratorFunction || "GeneratorFunction" === (ctor.displayName || ctor.name)); }, exports.mark = function (genFun) { return Object.setPrototypeOf ? Object.setPrototypeOf(genFun, GeneratorFunctionPrototype) : (genFun.__proto__ = GeneratorFunctionPrototype, define(genFun, toStringTagSymbol, "GeneratorFunction")), genFun.prototype = Object.create(Gp), genFun; }, exports.awrap = function (arg) { return { __await: arg }; }, defineIteratorMethods(AsyncIterator.prototype), define(AsyncIterator.prototype, asyncIteratorSymbol, function () { return this; }), exports.AsyncIterator = AsyncIterator, exports.async = function (innerFn, outerFn, self, tryLocsList, PromiseImpl) { void 0 === PromiseImpl && (PromiseImpl = Promise); var iter = new AsyncIterator(wrap(innerFn, outerFn, self, tryLocsList), PromiseImpl); return exports.isGeneratorFunction(outerFn) ? iter : iter.next().then(function (result) { return result.done ? result.value : iter.next(); }); }, defineIteratorMethods(Gp), define(Gp, toStringTagSymbol, "Generator"), define(Gp, iteratorSymbol, function () { return this; }), define(Gp, "toString", function () { return "[object Generator]"; }), exports.keys = function (object) { var keys = []; for (var key in object) { keys.push(key); } return keys.reverse(), function next() { for (; keys.length;) { var key = keys.pop(); if (key in object) return next.value = key, next.done = !1, next; } return next.done = !0, next; }; }, exports.values = values, Context.prototype = { constructor: Context, reset: function reset(skipTempReset) { if (this.prev = 0, this.next = 0, this.sent = this._sent = undefined, this.done = !1, this.delegate = null, this.method = "next", this.arg = undefined, this.tryEntries.forEach(resetTryEntry), !skipTempReset) for (var name in this) { "t" === name.charAt(0) && hasOwn.call(this, name) && !isNaN(+name.slice(1)) && (this[name] = undefined); } }, stop: function stop() { this.done = !0; var rootRecord = this.tryEntries[0].completion; if ("throw" === rootRecord.type) throw rootRecord.arg; return this.rval; }, dispatchException: function dispatchException(exception) { if (this.done) throw exception; var context = this; function handle(loc, caught) { return record.type = "throw", record.arg = exception, context.next = loc, caught && (context.method = "next", context.arg = undefined), !!caught; } for (var i = this.tryEntries.length - 1; i >= 0; --i) { var entry = this.tryEntries[i], record = entry.completion; if ("root" === entry.tryLoc) return handle("end"); if (entry.tryLoc <= this.prev) { var hasCatch = hasOwn.call(entry, "catchLoc"), hasFinally = hasOwn.call(entry, "finallyLoc"); if (hasCatch && hasFinally) { if (this.prev < entry.catchLoc) return handle(entry.catchLoc, !0); if (this.prev < entry.finallyLoc) return handle(entry.finallyLoc); } else if (hasCatch) { if (this.prev < entry.catchLoc) return handle(entry.catchLoc, !0); } else { if (!hasFinally) throw new Error("try statement without catch or finally"); if (this.prev < entry.finallyLoc) return handle(entry.finallyLoc); } } } }, abrupt: function abrupt(type, arg) { for (var i = this.tryEntries.length - 1; i >= 0; --i) { var entry = this.tryEntries[i]; if (entry.tryLoc <= this.prev && hasOwn.call(entry, "finallyLoc") && this.prev < entry.finallyLoc) { var finallyEntry = entry; break; } } finallyEntry && ("break" === type || "continue" === type) && finallyEntry.tryLoc <= arg && arg <= finallyEntry.finallyLoc && (finallyEntry = null); var record = finallyEntry ? finallyEntry.completion : {}; return record.type = type, record.arg = arg, finallyEntry ? (this.method = "next", this.next = finallyEntry.finallyLoc, ContinueSentinel) : this.complete(record); }, complete: function complete(record, afterLoc) { if ("throw" === record.type) throw record.arg; return "break" === record.type || "continue" === record.type ? this.next = record.arg : "return" === record.type ? (this.rval = this.arg = record.arg, this.method = "return", this.next = "end") : "normal" === record.type && afterLoc && (this.next = afterLoc), ContinueSentinel; }, finish: function finish(finallyLoc) { for (var i = this.tryEntries.length - 1; i >= 0; --i) { var entry = this.tryEntries[i]; if (entry.finallyLoc === finallyLoc) return this.complete(entry.completion, entry.afterLoc), resetTryEntry(entry), ContinueSentinel; } }, catch: function _catch(tryLoc) { for (var i = this.tryEntries.length - 1; i >= 0; --i) { var entry = this.tryEntries[i]; if (entry.tryLoc === tryLoc) { var record = entry.completion; if ("throw" === record.type) { var thrown = record.arg; resetTryEntry(entry); } return thrown; } } throw new Error("illegal catch attempt"); }, delegateYield: function delegateYield(iterable, resultName, nextLoc) { return this.delegate = { iterator: values(iterable), resultName: resultName, nextLoc: nextLoc }, "next" === this.method && (this.arg = undefined), ContinueSentinel; } }, exports; }















var BackgroundTrackingService = /*#__PURE__*/function () {
  function BackgroundTrackingService(backgroundGeolocationPlugin, alertService, authService, playerControllerService, appStatusService, zone) {
    var _this = this;

    (0,_Users_smartcommunitylab_Documents_work_projects_dslab_playgo_mobile_playgo_mobile_node_modules_babel_runtime_helpers_esm_classCallCheck_js__WEBPACK_IMPORTED_MODULE_1__["default"])(this, BackgroundTrackingService);

    this.backgroundGeolocationPlugin = backgroundGeolocationPlugin;
    this.alertService = alertService;
    this.authService = authService;
    this.playerControllerService = playerControllerService;
    this.appStatusService = appStatusService;
    this.zone = zone;
    this.isReady = new Promise(function (resolve, reject) {
      _this.markAsReady = resolve;
    });
    this.appConfig = {
      tracking: {
        maximalAccuracy: 30
      }
    };
    this.pluginLocation$ = this.getPluginObservable(this.backgroundGeolocationPlugin.onLocation).pipe((0,rxjs_operators__WEBPACK_IMPORTED_MODULE_11__.tap)(_angular_core__WEBPACK_IMPORTED_MODULE_12__.NgZone.assertInAngularZone), (0,rxjs_operators__WEBPACK_IMPORTED_MODULE_13__.shareReplay)(1));
    this.accuracy$ = this.pluginLocation$.pipe((0,rxjs_operators__WEBPACK_IMPORTED_MODULE_14__.map)(function (loc) {
      return loc.coords.accuracy;
    }), (0,rxjs_operators__WEBPACK_IMPORTED_MODULE_13__.shareReplay)(1));
    this.lowAccuracy$ = this.accuracy$.pipe((0,rxjs_operators__WEBPACK_IMPORTED_MODULE_14__.map)(function (accuracy) {
      return accuracy > _this.appConfig.tracking.maximalAccuracy;
    }), (0,rxjs_operators__WEBPACK_IMPORTED_MODULE_15__.distinctUntilChanged)(), (0,rxjs_operators__WEBPACK_IMPORTED_MODULE_13__.shareReplay)(1));
    this.currentLocation$ = this.pluginLocation$.pipe((0,rxjs_operators__WEBPACK_IMPORTED_MODULE_14__.map)(TripLocation.fromLocation), (0,rxjs_operators__WEBPACK_IMPORTED_MODULE_13__.shareReplay)(1));
    this.isPowerSaveMode$ = (0,rxjs__WEBPACK_IMPORTED_MODULE_16__.concat)(this.isReady.then(function () {
      return _this.backgroundGeolocationPlugin.isPowerSaveMode();
    }), this.getPluginObservable(this.backgroundGeolocationPlugin.onPowerSaveChange)).pipe((0,rxjs_operators__WEBPACK_IMPORTED_MODULE_17__.startWith)(false), (0,rxjs_operators__WEBPACK_IMPORTED_MODULE_15__.distinctUntilChanged)(), (0,rxjs_operators__WEBPACK_IMPORTED_MODULE_11__.tap)(_angular_core__WEBPACK_IMPORTED_MODULE_12__.NgZone.assertInAngularZone), (0,rxjs_operators__WEBPACK_IMPORTED_MODULE_13__.shareReplay)(1));
    this.appAndDeviceInfo$ = (0,rxjs__WEBPACK_IMPORTED_MODULE_18__.combineLatest)([this.appStatusService.appInfo$, this.appStatusService.deviceInfo$, this.appStatusService.codePushLabel$]).pipe((0,rxjs_operators__WEBPACK_IMPORTED_MODULE_14__.map)(function (_ref) {
      var _ref2 = (0,_Users_smartcommunitylab_Documents_work_projects_dslab_playgo_mobile_playgo_mobile_node_modules_babel_runtime_helpers_esm_slicedToArray_js__WEBPACK_IMPORTED_MODULE_0__["default"])(_ref, 3),
          appInfo = _ref2[0],
          deviceInfo = _ref2[1],
          codePushLabel = _ref2[2];

      return {
        isVirtual: deviceInfo.isVirtual,
        platform: deviceInfo.platform,
        version: appInfo.version,
        codePushLabel: codePushLabel,
        osVersion: deviceInfo.osVersion,
        model: deviceInfo.model
      };
    }), (0,rxjs_operators__WEBPACK_IMPORTED_MODULE_13__.shareReplay)(1));
    this.possibleLocationsChangeSubject = new rxjs__WEBPACK_IMPORTED_MODULE_19__.ReplaySubject();
    this.currentExtrasSubject = new rxjs__WEBPACK_IMPORTED_MODULE_19__.ReplaySubject();
    this.notSynchronizedLocations$ = (0,rxjs__WEBPACK_IMPORTED_MODULE_20__.merge)(this.currentLocation$, this.possibleLocationsChangeSubject.pipe()).pipe((0,rxjs_operators__WEBPACK_IMPORTED_MODULE_17__.startWith)('initial getLocation request'), (0,rxjs_operators__WEBPACK_IMPORTED_MODULE_21__.switchMap)(function () {
      return _this.backgroundGeolocationPlugin.getLocations();
    }), (0,rxjs_operators__WEBPACK_IMPORTED_MODULE_14__.map)(function (rawLocations) {
      return rawLocations.map(TripLocation.fromLocation);
    }), (0,rxjs_operators__WEBPACK_IMPORTED_MODULE_15__.distinctUntilChanged)(lodash_es__WEBPACK_IMPORTED_MODULE_22__["default"]), // tapLog('trip locations'),
    (0,rxjs_operators__WEBPACK_IMPORTED_MODULE_13__.shareReplay)(1));
    this.currentTripLocations$ = (0,rxjs__WEBPACK_IMPORTED_MODULE_18__.combineLatest)([this.notSynchronizedLocations$, this.currentExtrasSubject //FIXME: better!
    ]).pipe((0,rxjs_operators__WEBPACK_IMPORTED_MODULE_14__.map)(function (_ref3) {
      var _ref4 = (0,_Users_smartcommunitylab_Documents_work_projects_dslab_playgo_mobile_playgo_mobile_node_modules_babel_runtime_helpers_esm_slicedToArray_js__WEBPACK_IMPORTED_MODULE_0__["default"])(_ref3, 2),
          notSynchronizedLocations = _ref4[0],
          currentExtras = _ref4[1];

      return (0,lodash_es__WEBPACK_IMPORTED_MODULE_23__["default"])(notSynchronizedLocations, {
        multimodalId: currentExtras.multimodalId
      });
    }), (0,rxjs_operators__WEBPACK_IMPORTED_MODULE_13__.shareReplay)(1));
    /**  watch all onLocation events, but also take last location from database */

    this.lastLocation$ = (0,rxjs__WEBPACK_IMPORTED_MODULE_16__.concat)(this.notSynchronizedLocations$.pipe((0,rxjs_operators__WEBPACK_IMPORTED_MODULE_24__.first)(), (0,rxjs_operators__WEBPACK_IMPORTED_MODULE_14__.map)(function (x) {
      return (0,lodash_es__WEBPACK_IMPORTED_MODULE_25__["default"])(x);
    }), (0,rxjs_operators__WEBPACK_IMPORTED_MODULE_26__.takeUntil)(this.currentLocation$)), this.currentLocation$).pipe((0,rxjs_operators__WEBPACK_IMPORTED_MODULE_15__.distinctUntilChanged)(lodash_es__WEBPACK_IMPORTED_MODULE_22__["default"]), (0,rxjs_operators__WEBPACK_IMPORTED_MODULE_13__.shareReplay)(1));
    this.synchronizedLocationsSubject = new rxjs__WEBPACK_IMPORTED_MODULE_19__.ReplaySubject(1);
    this.synchronizedLocations$ = this.synchronizedLocationsSubject.asObservable();
    /** manually get locations without starting the tracking */

    this.coldForegroundLocation$ = (0,rxjs__WEBPACK_IMPORTED_MODULE_27__.timer)(0, 10000).pipe((0,rxjs_operators__WEBPACK_IMPORTED_MODULE_21__.switchMap)(function () {
      return _this.backgroundGeolocationPlugin.getCurrentPosition({
        timeout: 1000,
        persist: false
      });
    })); // FIXME: debug only

    window.backgroundGeolocationPlugin = this.backgroundGeolocationPlugin; // start observing plugin events

    this.pluginLocation$.subscribe();
    this.isPowerSaveMode$.subscribe();
  }

  (0,_Users_smartcommunitylab_Documents_work_projects_dslab_playgo_mobile_playgo_mobile_node_modules_babel_runtime_helpers_esm_createClass_js__WEBPACK_IMPORTED_MODULE_2__["default"])(BackgroundTrackingService, [{
    key: "start",
    value: function start() {
      return (0,tslib__WEBPACK_IMPORTED_MODULE_28__.__awaiter)(this, void 0, void 0, /*#__PURE__*/_regeneratorRuntime().mark(function _callee() {
        var appAndDeviceInfo, config, state;
        return _regeneratorRuntime().wrap(function _callee$(_context) {
          while (1) {
            switch (_context.prev = _context.next) {
              case 0:
                _context.prev = 0;
                _context.next = 3;
                return (0,rxjs__WEBPACK_IMPORTED_MODULE_29__.firstValueFrom)(this.appAndDeviceInfo$);

              case 3:
                appAndDeviceInfo = _context.sent;
                config = {
                  url: src_environments_environment__WEBPACK_IMPORTED_MODULE_6__.environment.serverUrl.api + src_environments_environment__WEBPACK_IMPORTED_MODULE_6__.environment.serverUrl.apiPath + '/track/player/geolocations',
                  distanceFilter: 10,
                  stopOnTerminate: false,
                  startOnBoot: false,
                  autoSync: false,
                  batchSync: true,
                  authorization: null,
                  params: {
                    device: appAndDeviceInfo
                  }
                };
                console.log('starting BackgroundGeolocation', config);
                _context.next = 8;
                return this.backgroundGeolocationPlugin.ready(config);

              case 8:
                state = _context.sent;
                console.log('BackgroundGeolocation ready', state);
                _context.next = 15;
                break;

              case 12:
                _context.prev = 12;
                _context.t0 = _context["catch"](0);
                console.error(_context.t0);

              case 15:
                this.markAsReady(true);

              case 16:
              case "end":
                return _context.stop();
            }
          }
        }, _callee, this, [[0, 12]]);
      }));
    }
  }, {
    key: "syncInitialLocations",
    value: function syncInitialLocations() {
      return (0,tslib__WEBPACK_IMPORTED_MODULE_28__.__awaiter)(this, void 0, void 0, /*#__PURE__*/_regeneratorRuntime().mark(function _callee2() {
        return _regeneratorRuntime().wrap(function _callee2$(_context2) {
          while (1) {
            switch (_context2.prev = _context2.next) {
              case 0:
                _context2.next = 2;
                return this.isReady;

              case 2:
                _context2.next = 4;
                return this.sync();

              case 4:
                _context2.next = 6;
                return this.backgroundGeolocationPlugin.stop();

              case 6:
                this.possibleLocationsChangeSubject.next();

              case 7:
              case "end":
                return _context2.stop();
            }
          }
        }, _callee2, this);
      }));
    }
  }, {
    key: "startTracking",
    value: function startTracking(tripPart, doChecks) {
      return (0,tslib__WEBPACK_IMPORTED_MODULE_28__.__awaiter)(this, void 0, void 0, /*#__PURE__*/_regeneratorRuntime().mark(function _callee3() {
        var location, accuracy, userAcceptsLowAccuracy, isPowerSaveMode;
        return _regeneratorRuntime().wrap(function _callee3$(_context3) {
          while (1) {
            switch (_context3.prev = _context3.next) {
              case 0:
                _context3.next = 2;
                return this.setExtrasAndForceLocation(tripPart);

              case 2:
                location = _context3.sent;
                accuracy = location.coords.accuracy;

                if (!doChecks) {
                  _context3.next = 16;
                  break;
                }

                if (!(accuracy > this.appConfig.tracking.maximalAccuracy)) {
                  _context3.next = 11;
                  break;
                }

                _context3.next = 8;
                return this.showLowAccuracyWarning();

              case 8:
                userAcceptsLowAccuracy = _context3.sent;

                if (userAcceptsLowAccuracy) {
                  _context3.next = 11;
                  break;
                }

                throw _trip_model__WEBPACK_IMPORTED_MODULE_4__.LOW_ACCURACY;

              case 11:
                _context3.next = 13;
                return this.backgroundGeolocationPlugin.isPowerSaveMode();

              case 13:
                isPowerSaveMode = _context3.sent;

                if (!isPowerSaveMode) {
                  _context3.next = 16;
                  break;
                }

                throw _trip_model__WEBPACK_IMPORTED_MODULE_4__.POWER_SAVE_MODE;

              case 16:
                _context3.next = 18;
                return this.backgroundGeolocationPlugin.start();

              case 18:
                this.possibleLocationsChangeSubject.next();

              case 19:
              case "end":
                return _context3.stop();
            }
          }
        }, _callee3, this);
      }));
    }
  }, {
    key: "showLowAccuracyWarning",
    value: function showLowAccuracyWarning() {
      return (0,tslib__WEBPACK_IMPORTED_MODULE_28__.__awaiter)(this, void 0, void 0, /*#__PURE__*/_regeneratorRuntime().mark(function _callee4() {
        return _regeneratorRuntime().wrap(function _callee4$(_context4) {
          while (1) {
            switch (_context4.prev = _context4.next) {
              case 0:
                _context4.next = 2;
                return this.alertService.confirmAlert('modal.alert_title', 'tracking.continue_low_accuracy_prompt');

              case 2:
                return _context4.abrupt("return", _context4.sent);

              case 3:
              case "end":
                return _context4.stop();
            }
          }
        }, _callee4, this);
      }));
    }
  }, {
    key: "clearPluginData",
    value: function clearPluginData() {
      return (0,tslib__WEBPACK_IMPORTED_MODULE_28__.__awaiter)(this, void 0, void 0, /*#__PURE__*/_regeneratorRuntime().mark(function _callee5() {
        return _regeneratorRuntime().wrap(function _callee5$(_context5) {
          while (1) {
            switch (_context5.prev = _context5.next) {
              case 0:
                _context5.next = 2;
                return this.isReady;

              case 2:
                _context5.next = 4;
                return this.backgroundGeolocationPlugin.setConfig({});

              case 4:
                this.currentExtrasSubject.next({});
                _context5.next = 7;
                return this.backgroundGeolocationPlugin.stop();

              case 7:
                this.backgroundGeolocationPlugin.destroyLocations();

              case 8:
              case "end":
                return _context5.stop();
            }
          }
        }, _callee5, this);
      }));
    }
  }, {
    key: "stopTracking",
    value: function stopTracking() {
      return (0,tslib__WEBPACK_IMPORTED_MODULE_28__.__awaiter)(this, void 0, void 0, /*#__PURE__*/_regeneratorRuntime().mark(function _callee6() {
        return _regeneratorRuntime().wrap(function _callee6$(_context6) {
          while (1) {
            switch (_context6.prev = _context6.next) {
              case 0:
                _context6.next = 2;
                return this.setExtrasAndForceLocation(null);

              case 2:
                _context6.next = 4;
                return this.backgroundGeolocationPlugin.stop();

              case 4:
                _context6.next = 6;
                return this.sync();

              case 6:
                this.possibleLocationsChangeSubject.next();

              case 7:
              case "end":
                return _context6.stop();
            }
          }
        }, _callee6, this);
      }));
    }
  }, {
    key: "sync",
    value: function sync() {
      return (0,tslib__WEBPACK_IMPORTED_MODULE_28__.__awaiter)(this, void 0, void 0, /*#__PURE__*/_regeneratorRuntime().mark(function _callee7() {
        return _regeneratorRuntime().wrap(function _callee7$(_context7) {
          while (1) {
            switch (_context7.prev = _context7.next) {
              case 0:
                _context7.prev = 0;
                _context7.prev = 1;
                _context7.next = 4;
                return this.trySync();

              case 4:
                _context7.next = 13;
                break;

              case 6:
                _context7.prev = 6;
                _context7.t0 = _context7["catch"](1);
                console.log('Sync failed, trying to get new token'); // maybe sync failed because the token is expired. Let's try to call some
                // api to refresh the token and try again.

                _context7.next = 11;
                return this.playerControllerService.getProfileUsingGET().toPromise();

              case 11:
                _context7.next = 13;
                return this.trySync();

              case 13:
                _context7.next = 18;
                break;

              case 15:
                _context7.prev = 15;
                _context7.t1 = _context7["catch"](0);
                console.warn('Sync failed, we will try to sync next time', _context7.t1);

              case 18:
                this.possibleLocationsChangeSubject.next();

              case 19:
              case "end":
                return _context7.stop();
            }
          }
        }, _callee7, this, [[0, 15], [1, 6]]);
      }));
    }
  }, {
    key: "trySync",
    value: function trySync() {
      return (0,tslib__WEBPACK_IMPORTED_MODULE_28__.__awaiter)(this, void 0, void 0, /*#__PURE__*/_regeneratorRuntime().mark(function _callee8() {
        var token, locationSentToServer;
        return _regeneratorRuntime().wrap(function _callee8$(_context8) {
          while (1) {
            switch (_context8.prev = _context8.next) {
              case 0:
                _context8.next = 2;
                return this.authService.getToken();

              case 2:
                token = _context8.sent;
                console.log('sync using token', token);
                _context8.next = 6;
                return this.backgroundGeolocationPlugin.setConfig({
                  authorization: {
                    strategy: 'jwt',
                    accessToken: token.accessToken
                  }
                });

              case 6:
                _context8.next = 8;
                return this.backgroundGeolocationPlugin.getLocations();

              case 8:
                locationSentToServer = _context8.sent;
                _context8.next = 11;
                return this.backgroundGeolocationPlugin.sync();

              case 11:
                this.synchronizedLocationsSubject.next(locationSentToServer.map(TripLocation.fromLocation));
                this.possibleLocationsChangeSubject.next();

              case 13:
              case "end":
                return _context8.stop();
            }
          }
        }, _callee8, this);
      }));
    }
  }, {
    key: "setExtrasAndForceLocation",
    value: function setExtrasAndForceLocation(tripPart) {
      return (0,tslib__WEBPACK_IMPORTED_MODULE_28__.__awaiter)(this, void 0, void 0, /*#__PURE__*/_regeneratorRuntime().mark(function _callee9() {
        var extras, currentLocation;
        return _regeneratorRuntime().wrap(function _callee9$(_context9) {
          while (1) {
            switch (_context9.prev = _context9.next) {
              case 0:
                _context9.next = 2;
                return this.isReady;

              case 2:
                extras = this.getExtras(tripPart);
                _context9.next = 5;
                return this.backgroundGeolocationPlugin.setConfig({
                  extras: extras
                });

              case 5:
                this.currentExtrasSubject.next(extras);
                _context9.prev = 6;
                _context9.next = 9;
                return this.backgroundGeolocationPlugin.getCurrentPosition({
                  // TODO: this does not work...
                  extras: Object.assign(Object.assign({}, extras), {
                    forced: true
                  })
                });

              case 9:
                currentLocation = _context9.sent;
                _context9.next = 16;
                break;

              case 12:
                _context9.prev = 12;
                _context9.t0 = _context9["catch"](6);
                console.error(_context9.t0);
                throw _trip_model__WEBPACK_IMPORTED_MODULE_4__.UNABLE_TO_GET_POSITION;

              case 16:
                this.possibleLocationsChangeSubject.next();
                return _context9.abrupt("return", currentLocation);

              case 18:
              case "end":
                return _context9.stop();
            }
          }
        }, _callee9, this, [[6, 12]]);
      }));
    }
  }, {
    key: "getExtras",
    value: function getExtras(tripPart) {
      return {
        idTrip: tripPart === null || tripPart === void 0 ? void 0 : tripPart.idTrip,
        multimodalId: tripPart === null || tripPart === void 0 ? void 0 : tripPart.multimodalId,
        start: tripPart === null || tripPart === void 0 ? void 0 : tripPart.start,
        transportType: tripPart === null || tripPart === void 0 ? void 0 : tripPart.transportType,
        sharedTravelId: tripPart === null || tripPart === void 0 ? void 0 : tripPart.sharedTravelId
      };
    }
  }, {
    key: "getPluginObservable",
    value: function getPluginObservable(createPluginSubscriptionFn) {
      var subject = new rxjs__WEBPACK_IMPORTED_MODULE_19__.ReplaySubject();
      var pluginSubscription = createPluginSubscriptionFn(function (event) {
        subject.next(event);
      });
      return subject.pipe((0,_utils__WEBPACK_IMPORTED_MODULE_5__.runInZone)(this.zone), (0,rxjs_operators__WEBPACK_IMPORTED_MODULE_30__.finalize)(function () {
        pluginSubscription.remove();
      }));
    }
  }]);

  return BackgroundTrackingService;
}();

BackgroundTrackingService.ɵfac = function BackgroundTrackingService_Factory(t) {
  return new (t || BackgroundTrackingService)(_angular_core__WEBPACK_IMPORTED_MODULE_12__["ɵɵinject"]('BackgroundGeolocationPlugin'), _angular_core__WEBPACK_IMPORTED_MODULE_12__["ɵɵinject"](src_app_core_shared_services_alert_service__WEBPACK_IMPORTED_MODULE_7__.AlertService), _angular_core__WEBPACK_IMPORTED_MODULE_12__["ɵɵinject"](_auth_auth_service__WEBPACK_IMPORTED_MODULE_8__.AuthService), _angular_core__WEBPACK_IMPORTED_MODULE_12__["ɵɵinject"](_api_generated_controllers_playerController_service__WEBPACK_IMPORTED_MODULE_9__.PlayerControllerService), _angular_core__WEBPACK_IMPORTED_MODULE_12__["ɵɵinject"](_services_app_status_service__WEBPACK_IMPORTED_MODULE_10__.AppStatusService), _angular_core__WEBPACK_IMPORTED_MODULE_12__["ɵɵinject"](_angular_core__WEBPACK_IMPORTED_MODULE_12__.NgZone));
};

BackgroundTrackingService.ɵprov = /*@__PURE__*/_angular_core__WEBPACK_IMPORTED_MODULE_12__["ɵɵdefineInjectable"]({
  token: BackgroundTrackingService,
  factory: BackgroundTrackingService.ɵfac,
  providedIn: 'root'
});
var TripLocation = /*#__PURE__*/function () {
  function TripLocation(data) {
    (0,_Users_smartcommunitylab_Documents_work_projects_dslab_playgo_mobile_playgo_mobile_node_modules_babel_runtime_helpers_esm_classCallCheck_js__WEBPACK_IMPORTED_MODULE_1__["default"])(this, TripLocation);

    Object.assign(this, data || {});
  }

  (0,_Users_smartcommunitylab_Documents_work_projects_dslab_playgo_mobile_playgo_mobile_node_modules_babel_runtime_helpers_esm_createClass_js__WEBPACK_IMPORTED_MODULE_2__["default"])(TripLocation, null, [{
    key: "fromLocation",
    value: function fromLocation(location) {
      var extras = location.extras || {};
      return new TripLocation({
        date: new Date(location.timestamp).getTime(),
        latitude: location.coords.latitude,
        longitude: location.coords.longitude,
        multimodalId: extras.multimodalId,
        idTrip: extras.idTrip,
        transportType: extras.transportType
      });
    }
  }]);

  return TripLocation;
}();

/***/ }),

/***/ 49110:
/*!****************************************************!*\
  !*** ./src/app/core/shared/tracking/trip.model.ts ***!
  \****************************************************/
/***/ (function(__unused_webpack_module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "LOW_ACCURACY": function() { return /* binding */ LOW_ACCURACY; },
/* harmony export */   "NO_TRIP_STARTED": function() { return /* binding */ NO_TRIP_STARTED; },
/* harmony export */   "POWER_SAVE_MODE": function() { return /* binding */ POWER_SAVE_MODE; },
/* harmony export */   "TRIP_END": function() { return /* binding */ TRIP_END; },
/* harmony export */   "Trip": function() { return /* binding */ Trip; },
/* harmony export */   "TripPart": function() { return /* binding */ TripPart; },
/* harmony export */   "UNABLE_TO_GET_POSITION": function() { return /* binding */ UNABLE_TO_GET_POSITION; },
/* harmony export */   "getTransportTypeColor": function() { return /* binding */ getTransportTypeColor; },
/* harmony export */   "getTransportTypeIcon": function() { return /* binding */ getTransportTypeIcon; },
/* harmony export */   "getTransportTypeLabel": function() { return /* binding */ getTransportTypeLabel; },
/* harmony export */   "isTransportType": function() { return /* binding */ isTransportType; },
/* harmony export */   "transportTypeColors": function() { return /* binding */ transportTypeColors; },
/* harmony export */   "transportTypeIcons": function() { return /* binding */ transportTypeIcons; },
/* harmony export */   "transportTypeLabels": function() { return /* binding */ transportTypeLabels; },
/* harmony export */   "transportTypes": function() { return /* binding */ transportTypes; }
/* harmony export */ });
/* harmony import */ var _Users_smartcommunitylab_Documents_work_projects_dslab_playgo_mobile_playgo_mobile_node_modules_babel_runtime_helpers_esm_classCallCheck_js__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./node_modules/@babel/runtime/helpers/esm/classCallCheck.js */ 78069);
/* harmony import */ var _Users_smartcommunitylab_Documents_work_projects_dslab_playgo_mobile_playgo_mobile_node_modules_babel_runtime_helpers_esm_createClass_js__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ./node_modules/@babel/runtime/helpers/esm/createClass.js */ 48047);


var Trip = /*#__PURE__*/function () {
  function Trip(data) {
    (0,_Users_smartcommunitylab_Documents_work_projects_dslab_playgo_mobile_playgo_mobile_node_modules_babel_runtime_helpers_esm_classCallCheck_js__WEBPACK_IMPORTED_MODULE_0__["default"])(this, Trip);

    Object.assign(this, data || {});
  }

  (0,_Users_smartcommunitylab_Documents_work_projects_dslab_playgo_mobile_playgo_mobile_node_modules_babel_runtime_helpers_esm_createClass_js__WEBPACK_IMPORTED_MODULE_1__["default"])(Trip, null, [{
    key: "fromFirstPart",
    value: function fromFirstPart(firstPart) {
      return new Trip({
        multimodalId: firstPart.multimodalId
      });
    }
  }]);

  return Trip;
}();
var TripPart = /*#__PURE__*/function () {
  function TripPart(data) {
    (0,_Users_smartcommunitylab_Documents_work_projects_dslab_playgo_mobile_playgo_mobile_node_modules_babel_runtime_helpers_esm_classCallCheck_js__WEBPACK_IMPORTED_MODULE_0__["default"])(this, TripPart);

    Object.assign(this, data || {});
  }

  (0,_Users_smartcommunitylab_Documents_work_projects_dslab_playgo_mobile_playgo_mobile_node_modules_babel_runtime_helpers_esm_createClass_js__WEBPACK_IMPORTED_MODULE_1__["default"])(TripPart, null, [{
    key: "fromTransportType",
    value: function fromTransportType(transportType) {
      var start = new Date().getTime();
      var idTrip = "".concat(transportType, "_").concat(start);
      return new TripPart({
        start: start,
        transportType: transportType,
        idTrip: idTrip,
        sharedTravelId: null,
        multimodalId: null,
        isInitial: false
      });
    }
  }]);

  return TripPart;
}();
var TRIP_END = 'TRIP_END';
var NO_TRIP_STARTED = 'NO_TRIP_STARTED';
var LOW_ACCURACY = 'LOW_ACCURACY';
var POWER_SAVE_MODE = 'POWER_SAVE_MODE'; // probably location services are disabled by user.

var UNABLE_TO_GET_POSITION = 'UNABLE_TO_GET_POSITION';
var transportTypes = ['walk', 'bike', 'bus', 'train', 'car', 'boat'];
var transportTypeColors = {
  bike: 'red',
  bus: 'green',
  car: 'yellow',
  train: 'blue',
  walk: 'brown',
  boat: 'blue'
};
var transportTypeIcons = {
  bike: 'pedal_bike',
  bus: 'directions_bus',
  car: 'custom_carpooling',
  train: 'directions_train',
  walk: 'directions_walk',
  boat: 'directions_boat'
};
var transportTypeLabels = {
  bike: 'trip_detail.mean.bike',
  bus: 'trip_detail.mean.bus',
  car: 'trip_detail.mean.car',
  train: 'trip_detail.mean.train',
  walk: 'trip_detail.mean.walk',
  boat: 'trip_detail.mean.boat'
};
function isTransportType(transportType) {
  return transportTypes.includes(transportType);
}
function getTransportTypeIcon(transportType) {
  if (!isTransportType(transportType)) {
    console.error("Unknown transport type: ".concat(transportType));
    return null;
  }

  return transportTypeIcons[transportType];
}
function getTransportTypeLabel(transportType) {
  if (!isTransportType(transportType)) {
    console.error("Unknown transport type: ".concat(transportType));
    return null;
  }

  return transportTypeLabels[transportType];
}
function getTransportTypeColor(transportType) {
  if (!isTransportType(transportType)) {
    console.error("Unknown transport type: ".concat(transportType));
    return null;
  }

  return transportTypeColors[transportType];
}

/***/ }),

/***/ 71888:
/*!*******************************************************!*\
  !*** ./src/app/core/shared/ui/icon/icon.component.ts ***!
  \*******************************************************/
/***/ (function(__unused_webpack_module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "IconComponent": function() { return /* binding */ IconComponent; }
/* harmony export */ });
/* harmony import */ var _Users_smartcommunitylab_Documents_work_projects_dslab_playgo_mobile_playgo_mobile_node_modules_babel_runtime_helpers_esm_classCallCheck_js__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./node_modules/@babel/runtime/helpers/esm/classCallCheck.js */ 78069);
/* harmony import */ var _Users_smartcommunitylab_Documents_work_projects_dslab_playgo_mobile_playgo_mobile_node_modules_babel_runtime_helpers_esm_createClass_js__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ./node_modules/@babel/runtime/helpers/esm/createClass.js */ 48047);
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @angular/core */ 3184);
/* harmony import */ var _icon_service__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! ./icon.service */ 34610);
/* harmony import */ var _angular_common__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! @angular/common */ 36362);
/* harmony import */ var _ionic_angular__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! @ionic/angular */ 93819);







function IconComponent_ion_text_0_Template(rf, ctx) {
  if (rf & 1) {
    _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵelementStart"](0, "ion-text", 2)(1, "i", 3);
    _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵtext"](2);
    _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵelementEnd"]()();
  }

  if (rf & 2) {
    var ctx_r0 = _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵnextContext"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵproperty"]("color", ctx_r0.color);
    _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵadvance"](2);
    _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵtextInterpolate"](ctx_r0.name);
  }
}

function IconComponent_ion_icon_1_Template(rf, ctx) {
  if (rf & 1) {
    _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵelement"](0, "ion-icon", 4);
  }

  if (rf & 2) {
    var ctx_r1 = _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵnextContext"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵproperty"]("src", ctx_r1.src)("color", ctx_r1.color);
  }
}

var IconComponent = /*#__PURE__*/function () {
  function IconComponent(iconService) {
    (0,_Users_smartcommunitylab_Documents_work_projects_dslab_playgo_mobile_playgo_mobile_node_modules_babel_runtime_helpers_esm_classCallCheck_js__WEBPACK_IMPORTED_MODULE_0__["default"])(this, IconComponent);

    this.iconService = iconService;
  }

  (0,_Users_smartcommunitylab_Documents_work_projects_dslab_playgo_mobile_playgo_mobile_node_modules_babel_runtime_helpers_esm_createClass_js__WEBPACK_IMPORTED_MODULE_1__["default"])(IconComponent, [{
    key: "ngOnChanges",
    value: function ngOnChanges() {
      this.isSvg = this.iconService.isIconSvg(this.name);

      if (this.isSvg) {
        this.src = this.iconService.getSvgSrc(this.name);
      } else {
        this.src = null;
      }
    }
  }, {
    key: "ngOnInit",
    value: function ngOnInit() {}
  }]);

  return IconComponent;
}();

IconComponent.ɵfac = function IconComponent_Factory(t) {
  return new (t || IconComponent)(_angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵdirectiveInject"](_icon_service__WEBPACK_IMPORTED_MODULE_2__.IconService));
};

IconComponent.ɵcmp = /*@__PURE__*/_angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵdefineComponent"]({
  type: IconComponent,
  selectors: [["app-icon"]],
  inputs: {
    name: "name",
    color: "color"
  },
  features: [_angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵNgOnChangesFeature"]],
  decls: 2,
  vars: 2,
  consts: [[3, "color", 4, "ngIf"], ["class", "svg-icon", 3, "src", "color", 4, "ngIf"], [3, "color"], [1, "material-icons"], [1, "svg-icon", 3, "src", "color"]],
  template: function IconComponent_Template(rf, ctx) {
    if (rf & 1) {
      _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵtemplate"](0, IconComponent_ion_text_0_Template, 3, 2, "ion-text", 0);
      _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵtemplate"](1, IconComponent_ion_icon_1_Template, 1, 2, "ion-icon", 1);
    }

    if (rf & 2) {
      _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵproperty"]("ngIf", !ctx.isSvg);
      _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵadvance"](1);
      _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵproperty"]("ngIf", ctx.isSvg);
    }
  },
  directives: [_angular_common__WEBPACK_IMPORTED_MODULE_4__.NgIf, _ionic_angular__WEBPACK_IMPORTED_MODULE_5__.IonText, _ionic_angular__WEBPACK_IMPORTED_MODULE_5__.IonIcon],
  styles: [".material-icons[_ngcontent-%COMP%] {\n  font-size: inherit;\n}\n\n.svg-icon[_ngcontent-%COMP%] {\n  fill: currentcolor !important;\n  transform-origin: center center;\n  font-size: inherit;\n  margin-top: 0.2727272727em;\n  margin-bottom: 0.0909090909em;\n}\n\nion-text[_ngcontent-%COMP%] {\n  display: flex;\n  flex-direction: column;\n  align-items: center;\n}\n/*# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbImljb24uY29tcG9uZW50LnNjc3MiXSwibmFtZXMiOltdLCJtYXBwaW5ncyI6IkFBR0E7RUFDRSxrQkFBQTtBQUZGOztBQUtBO0VBQ0UsNkJBQUE7RUFDQSwrQkFBQTtFQUNBLGtCQUFBO0VBQ0EsMEJBQUE7RUFDQSw2QkFBQTtBQUZGOztBQUlBO0VBQ0UsYUFBQTtFQUNBLHNCQUFBO0VBQ0EsbUJBQUE7QUFERiIsImZpbGUiOiJpY29uLmNvbXBvbmVudC5zY3NzIiwic291cmNlc0NvbnRlbnQiOlsiLy8gaW9uLWljb24ge1xuLy8gICB3aWR0aDogMTAwJTtcbi8vIH1cbi5tYXRlcmlhbC1pY29ucyB7XG4gIGZvbnQtc2l6ZTogaW5oZXJpdDtcbn1cblxuLnN2Zy1pY29uIHtcbiAgZmlsbDogY3VycmVudGNvbG9yICFpbXBvcnRhbnQ7XG4gIHRyYW5zZm9ybS1vcmlnaW46IGNlbnRlciBjZW50ZXI7XG4gIGZvbnQtc2l6ZTogaW5oZXJpdDtcbiAgbWFyZ2luLXRvcDogY2FsYyg2ZW0gLyAyMik7XG4gIG1hcmdpbi1ib3R0b206IGNhbGMoMmVtIC8gMjIpO1xufVxuaW9uLXRleHQge1xuICBkaXNwbGF5OiBmbGV4O1xuICBmbGV4LWRpcmVjdGlvbjogY29sdW1uO1xuICBhbGlnbi1pdGVtczogY2VudGVyO1xufVxuIl19 */"]
});

/***/ }),

/***/ 34610:
/*!*****************************************************!*\
  !*** ./src/app/core/shared/ui/icon/icon.service.ts ***!
  \*****************************************************/
/***/ (function(__unused_webpack_module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "IconService": function() { return /* binding */ IconService; }
/* harmony export */ });
/* harmony import */ var _Users_smartcommunitylab_Documents_work_projects_dslab_playgo_mobile_playgo_mobile_node_modules_babel_runtime_helpers_esm_classCallCheck_js__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./node_modules/@babel/runtime/helpers/esm/classCallCheck.js */ 78069);
/* harmony import */ var _Users_smartcommunitylab_Documents_work_projects_dslab_playgo_mobile_playgo_mobile_node_modules_babel_runtime_helpers_esm_createClass_js__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ./node_modules/@babel/runtime/helpers/esm/createClass.js */ 48047);
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @angular/core */ 3184);
/* harmony import */ var _angular_platform_browser__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @angular/platform-browser */ 50318);




var IconService = /*#__PURE__*/function () {
  function IconService(domSanitizer) {
    (0,_Users_smartcommunitylab_Documents_work_projects_dslab_playgo_mobile_playgo_mobile_node_modules_babel_runtime_helpers_esm_classCallCheck_js__WEBPACK_IMPORTED_MODULE_0__["default"])(this, IconService);

    this.domSanitizer = domSanitizer;
    this.svgIcons = {};
  }

  (0,_Users_smartcommunitylab_Documents_work_projects_dslab_playgo_mobile_playgo_mobile_node_modules_babel_runtime_helpers_esm_createClass_js__WEBPACK_IMPORTED_MODULE_1__["default"])(IconService, [{
    key: "registerSvgIcons",
    value: function registerSvgIcons(svgIcons) {
      this.svgIcons = svgIcons;
    }
  }, {
    key: "isIconSvg",
    value: function isIconSvg(iconName) {
      return this.svgIcons[iconName] !== undefined;
    }
  }, {
    key: "getSvgSrc",
    value: function getSvgSrc(iconName) {
      return this.svgIcons[iconName];
    }
  }]);

  return IconService;
}();

IconService.ɵfac = function IconService_Factory(t) {
  return new (t || IconService)(_angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵinject"](_angular_platform_browser__WEBPACK_IMPORTED_MODULE_3__.DomSanitizer));
};

IconService.ɵprov = /*@__PURE__*/_angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵdefineInjectable"]({
  token: IconService,
  factory: IconService.ɵfac,
  providedIn: 'root'
});

/***/ }),

/***/ 68647:
/*!**************************************!*\
  !*** ./src/app/core/shared/utils.ts ***!
  \**************************************/
/***/ (function(__unused_webpack_module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "asyncFilter": function() { return /* binding */ asyncFilter; },
/* harmony export */   "beforeStartUse": function() { return /* binding */ beforeStartUse; },
/* harmony export */   "cartesian": function() { return /* binding */ cartesian; },
/* harmony export */   "castTo": function() { return /* binding */ castTo; },
/* harmony export */   "convertBlobToBase64": function() { return /* binding */ convertBlobToBase64; },
/* harmony export */   "formatDurationToHoursAndMinutes": function() { return /* binding */ formatDurationToHoursAndMinutes; },
/* harmony export */   "getAdjacentPairs": function() { return /* binding */ getAdjacentPairs; },
/* harmony export */   "getDebugStack": function() { return /* binding */ getDebugStack; },
/* harmony export */   "getImgChallenge": function() { return /* binding */ getImgChallenge; },
/* harmony export */   "getPeriods": function() { return /* binding */ getPeriods; },
/* harmony export */   "getTypeStringChallenge": function() { return /* binding */ getTypeStringChallenge; },
/* harmony export */   "groupByConsecutiveValues": function() { return /* binding */ groupByConsecutiveValues; },
/* harmony export */   "ifOfflineUseStored": function() { return /* binding */ ifOfflineUseStored; },
/* harmony export */   "isConstant": function() { return /* binding */ isConstant; },
/* harmony export */   "isInstanceOf": function() { return /* binding */ isInstanceOf; },
/* harmony export */   "isNotConstant": function() { return /* binding */ isNotConstant; },
/* harmony export */   "isOffline": function() { return /* binding */ isOffline; },
/* harmony export */   "isOfflineError": function() { return /* binding */ isOfflineError; },
/* harmony export */   "readAsBase64": function() { return /* binding */ readAsBase64; },
/* harmony export */   "runInContext": function() { return /* binding */ runInContext; },
/* harmony export */   "runInZone": function() { return /* binding */ runInZone; },
/* harmony export */   "runOutsideAngular": function() { return /* binding */ runOutsideAngular; },
/* harmony export */   "startFrom": function() { return /* binding */ startFrom; },
/* harmony export */   "tapLog": function() { return /* binding */ tapLog; },
/* harmony export */   "throwIfNil": function() { return /* binding */ throwIfNil; },
/* harmony export */   "time": function() { return /* binding */ time; },
/* harmony export */   "trackByProperty": function() { return /* binding */ trackByProperty; },
/* harmony export */   "waitMs": function() { return /* binding */ waitMs; }
/* harmony export */ });
/* harmony import */ var _Users_smartcommunitylab_Documents_work_projects_dslab_playgo_mobile_playgo_mobile_node_modules_babel_runtime_helpers_esm_toConsumableArray_js__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./node_modules/@babel/runtime/helpers/esm/toConsumableArray.js */ 58277);
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_16__ = __webpack_require__(/*! tslib */ 34929);
/* harmony import */ var lodash_es__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! lodash-es */ 10757);
/* harmony import */ var lodash_es__WEBPACK_IMPORTED_MODULE_12__ = __webpack_require__(/*! lodash-es */ 24304);
/* harmony import */ var lodash_es__WEBPACK_IMPORTED_MODULE_13__ = __webpack_require__(/*! lodash-es */ 55421);
/* harmony import */ var lodash_es__WEBPACK_IMPORTED_MODULE_17__ = __webpack_require__(/*! lodash-es */ 27885);
/* harmony import */ var lodash_es__WEBPACK_IMPORTED_MODULE_18__ = __webpack_require__(/*! lodash-es */ 83033);
/* harmony import */ var lodash_es__WEBPACK_IMPORTED_MODULE_19__ = __webpack_require__(/*! lodash-es */ 5636);
/* harmony import */ var lodash_es__WEBPACK_IMPORTED_MODULE_20__ = __webpack_require__(/*! lodash-es */ 85768);
/* harmony import */ var luxon__WEBPACK_IMPORTED_MODULE_21__ = __webpack_require__(/*! luxon */ 29527);
/* harmony import */ var rxjs__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! rxjs */ 90833);
/* harmony import */ var rxjs__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! rxjs */ 54240);
/* harmony import */ var rxjs__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! rxjs */ 36646);
/* harmony import */ var rxjs__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(/*! rxjs */ 59346);
/* harmony import */ var rxjs__WEBPACK_IMPORTED_MODULE_14__ = __webpack_require__(/*! rxjs */ 25474);
/* harmony import */ var rxjs_operators__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! rxjs/operators */ 19337);
/* harmony import */ var rxjs_operators__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(/*! rxjs/operators */ 68951);
/* harmony import */ var rxjs_operators__WEBPACK_IMPORTED_MODULE_9__ = __webpack_require__(/*! rxjs/operators */ 50635);
/* harmony import */ var rxjs_operators__WEBPACK_IMPORTED_MODULE_10__ = __webpack_require__(/*! rxjs/operators */ 53158);
/* harmony import */ var rxjs_operators__WEBPACK_IMPORTED_MODULE_11__ = __webpack_require__(/*! rxjs/operators */ 60116);
/* harmony import */ var rxjs_operators__WEBPACK_IMPORTED_MODULE_15__ = __webpack_require__(/*! rxjs/operators */ 63853);
/* harmony import */ var src_environments_environment__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! src/environments/environment */ 92340);


function _regeneratorRuntime() { "use strict"; /*! regenerator-runtime -- Copyright (c) 2014-present, Facebook, Inc. -- license (MIT): https://github.com/facebook/regenerator/blob/main/LICENSE */ _regeneratorRuntime = function _regeneratorRuntime() { return exports; }; var exports = {}, Op = Object.prototype, hasOwn = Op.hasOwnProperty, $Symbol = "function" == typeof Symbol ? Symbol : {}, iteratorSymbol = $Symbol.iterator || "@@iterator", asyncIteratorSymbol = $Symbol.asyncIterator || "@@asyncIterator", toStringTagSymbol = $Symbol.toStringTag || "@@toStringTag"; function define(obj, key, value) { return Object.defineProperty(obj, key, { value: value, enumerable: !0, configurable: !0, writable: !0 }), obj[key]; } try { define({}, ""); } catch (err) { define = function define(obj, key, value) { return obj[key] = value; }; } function wrap(innerFn, outerFn, self, tryLocsList) { var protoGenerator = outerFn && outerFn.prototype instanceof Generator ? outerFn : Generator, generator = Object.create(protoGenerator.prototype), context = new Context(tryLocsList || []); return generator._invoke = function (innerFn, self, context) { var state = "suspendedStart"; return function (method, arg) { if ("executing" === state) throw new Error("Generator is already running"); if ("completed" === state) { if ("throw" === method) throw arg; return doneResult(); } for (context.method = method, context.arg = arg;;) { var delegate = context.delegate; if (delegate) { var delegateResult = maybeInvokeDelegate(delegate, context); if (delegateResult) { if (delegateResult === ContinueSentinel) continue; return delegateResult; } } if ("next" === context.method) context.sent = context._sent = context.arg;else if ("throw" === context.method) { if ("suspendedStart" === state) throw state = "completed", context.arg; context.dispatchException(context.arg); } else "return" === context.method && context.abrupt("return", context.arg); state = "executing"; var record = tryCatch(innerFn, self, context); if ("normal" === record.type) { if (state = context.done ? "completed" : "suspendedYield", record.arg === ContinueSentinel) continue; return { value: record.arg, done: context.done }; } "throw" === record.type && (state = "completed", context.method = "throw", context.arg = record.arg); } }; }(innerFn, self, context), generator; } function tryCatch(fn, obj, arg) { try { return { type: "normal", arg: fn.call(obj, arg) }; } catch (err) { return { type: "throw", arg: err }; } } exports.wrap = wrap; var ContinueSentinel = {}; function Generator() {} function GeneratorFunction() {} function GeneratorFunctionPrototype() {} var IteratorPrototype = {}; define(IteratorPrototype, iteratorSymbol, function () { return this; }); var getProto = Object.getPrototypeOf, NativeIteratorPrototype = getProto && getProto(getProto(values([]))); NativeIteratorPrototype && NativeIteratorPrototype !== Op && hasOwn.call(NativeIteratorPrototype, iteratorSymbol) && (IteratorPrototype = NativeIteratorPrototype); var Gp = GeneratorFunctionPrototype.prototype = Generator.prototype = Object.create(IteratorPrototype); function defineIteratorMethods(prototype) { ["next", "throw", "return"].forEach(function (method) { define(prototype, method, function (arg) { return this._invoke(method, arg); }); }); } function AsyncIterator(generator, PromiseImpl) { function invoke(method, arg, resolve, reject) { var record = tryCatch(generator[method], generator, arg); if ("throw" !== record.type) { var result = record.arg, value = result.value; return value && "object" == typeof value && hasOwn.call(value, "__await") ? PromiseImpl.resolve(value.__await).then(function (value) { invoke("next", value, resolve, reject); }, function (err) { invoke("throw", err, resolve, reject); }) : PromiseImpl.resolve(value).then(function (unwrapped) { result.value = unwrapped, resolve(result); }, function (error) { return invoke("throw", error, resolve, reject); }); } reject(record.arg); } var previousPromise; this._invoke = function (method, arg) { function callInvokeWithMethodAndArg() { return new PromiseImpl(function (resolve, reject) { invoke(method, arg, resolve, reject); }); } return previousPromise = previousPromise ? previousPromise.then(callInvokeWithMethodAndArg, callInvokeWithMethodAndArg) : callInvokeWithMethodAndArg(); }; } function maybeInvokeDelegate(delegate, context) { var method = delegate.iterator[context.method]; if (undefined === method) { if (context.delegate = null, "throw" === context.method) { if (delegate.iterator.return && (context.method = "return", context.arg = undefined, maybeInvokeDelegate(delegate, context), "throw" === context.method)) return ContinueSentinel; context.method = "throw", context.arg = new TypeError("The iterator does not provide a 'throw' method"); } return ContinueSentinel; } var record = tryCatch(method, delegate.iterator, context.arg); if ("throw" === record.type) return context.method = "throw", context.arg = record.arg, context.delegate = null, ContinueSentinel; var info = record.arg; return info ? info.done ? (context[delegate.resultName] = info.value, context.next = delegate.nextLoc, "return" !== context.method && (context.method = "next", context.arg = undefined), context.delegate = null, ContinueSentinel) : info : (context.method = "throw", context.arg = new TypeError("iterator result is not an object"), context.delegate = null, ContinueSentinel); } function pushTryEntry(locs) { var entry = { tryLoc: locs[0] }; 1 in locs && (entry.catchLoc = locs[1]), 2 in locs && (entry.finallyLoc = locs[2], entry.afterLoc = locs[3]), this.tryEntries.push(entry); } function resetTryEntry(entry) { var record = entry.completion || {}; record.type = "normal", delete record.arg, entry.completion = record; } function Context(tryLocsList) { this.tryEntries = [{ tryLoc: "root" }], tryLocsList.forEach(pushTryEntry, this), this.reset(!0); } function values(iterable) { if (iterable) { var iteratorMethod = iterable[iteratorSymbol]; if (iteratorMethod) return iteratorMethod.call(iterable); if ("function" == typeof iterable.next) return iterable; if (!isNaN(iterable.length)) { var i = -1, next = function next() { for (; ++i < iterable.length;) { if (hasOwn.call(iterable, i)) return next.value = iterable[i], next.done = !1, next; } return next.value = undefined, next.done = !0, next; }; return next.next = next; } } return { next: doneResult }; } function doneResult() { return { value: undefined, done: !0 }; } return GeneratorFunction.prototype = GeneratorFunctionPrototype, define(Gp, "constructor", GeneratorFunctionPrototype), define(GeneratorFunctionPrototype, "constructor", GeneratorFunction), GeneratorFunction.displayName = define(GeneratorFunctionPrototype, toStringTagSymbol, "GeneratorFunction"), exports.isGeneratorFunction = function (genFun) { var ctor = "function" == typeof genFun && genFun.constructor; return !!ctor && (ctor === GeneratorFunction || "GeneratorFunction" === (ctor.displayName || ctor.name)); }, exports.mark = function (genFun) { return Object.setPrototypeOf ? Object.setPrototypeOf(genFun, GeneratorFunctionPrototype) : (genFun.__proto__ = GeneratorFunctionPrototype, define(genFun, toStringTagSymbol, "GeneratorFunction")), genFun.prototype = Object.create(Gp), genFun; }, exports.awrap = function (arg) { return { __await: arg }; }, defineIteratorMethods(AsyncIterator.prototype), define(AsyncIterator.prototype, asyncIteratorSymbol, function () { return this; }), exports.AsyncIterator = AsyncIterator, exports.async = function (innerFn, outerFn, self, tryLocsList, PromiseImpl) { void 0 === PromiseImpl && (PromiseImpl = Promise); var iter = new AsyncIterator(wrap(innerFn, outerFn, self, tryLocsList), PromiseImpl); return exports.isGeneratorFunction(outerFn) ? iter : iter.next().then(function (result) { return result.done ? result.value : iter.next(); }); }, defineIteratorMethods(Gp), define(Gp, toStringTagSymbol, "Generator"), define(Gp, iteratorSymbol, function () { return this; }), define(Gp, "toString", function () { return "[object Generator]"; }), exports.keys = function (object) { var keys = []; for (var key in object) { keys.push(key); } return keys.reverse(), function next() { for (; keys.length;) { var key = keys.pop(); if (key in object) return next.value = key, next.done = !1, next; } return next.done = !0, next; }; }, exports.values = values, Context.prototype = { constructor: Context, reset: function reset(skipTempReset) { if (this.prev = 0, this.next = 0, this.sent = this._sent = undefined, this.done = !1, this.delegate = null, this.method = "next", this.arg = undefined, this.tryEntries.forEach(resetTryEntry), !skipTempReset) for (var name in this) { "t" === name.charAt(0) && hasOwn.call(this, name) && !isNaN(+name.slice(1)) && (this[name] = undefined); } }, stop: function stop() { this.done = !0; var rootRecord = this.tryEntries[0].completion; if ("throw" === rootRecord.type) throw rootRecord.arg; return this.rval; }, dispatchException: function dispatchException(exception) { if (this.done) throw exception; var context = this; function handle(loc, caught) { return record.type = "throw", record.arg = exception, context.next = loc, caught && (context.method = "next", context.arg = undefined), !!caught; } for (var i = this.tryEntries.length - 1; i >= 0; --i) { var entry = this.tryEntries[i], record = entry.completion; if ("root" === entry.tryLoc) return handle("end"); if (entry.tryLoc <= this.prev) { var hasCatch = hasOwn.call(entry, "catchLoc"), hasFinally = hasOwn.call(entry, "finallyLoc"); if (hasCatch && hasFinally) { if (this.prev < entry.catchLoc) return handle(entry.catchLoc, !0); if (this.prev < entry.finallyLoc) return handle(entry.finallyLoc); } else if (hasCatch) { if (this.prev < entry.catchLoc) return handle(entry.catchLoc, !0); } else { if (!hasFinally) throw new Error("try statement without catch or finally"); if (this.prev < entry.finallyLoc) return handle(entry.finallyLoc); } } } }, abrupt: function abrupt(type, arg) { for (var i = this.tryEntries.length - 1; i >= 0; --i) { var entry = this.tryEntries[i]; if (entry.tryLoc <= this.prev && hasOwn.call(entry, "finallyLoc") && this.prev < entry.finallyLoc) { var finallyEntry = entry; break; } } finallyEntry && ("break" === type || "continue" === type) && finallyEntry.tryLoc <= arg && arg <= finallyEntry.finallyLoc && (finallyEntry = null); var record = finallyEntry ? finallyEntry.completion : {}; return record.type = type, record.arg = arg, finallyEntry ? (this.method = "next", this.next = finallyEntry.finallyLoc, ContinueSentinel) : this.complete(record); }, complete: function complete(record, afterLoc) { if ("throw" === record.type) throw record.arg; return "break" === record.type || "continue" === record.type ? this.next = record.arg : "return" === record.type ? (this.rval = this.arg = record.arg, this.method = "return", this.next = "end") : "normal" === record.type && afterLoc && (this.next = afterLoc), ContinueSentinel; }, finish: function finish(finallyLoc) { for (var i = this.tryEntries.length - 1; i >= 0; --i) { var entry = this.tryEntries[i]; if (entry.finallyLoc === finallyLoc) return this.complete(entry.completion, entry.afterLoc), resetTryEntry(entry), ContinueSentinel; } }, catch: function _catch(tryLoc) { for (var i = this.tryEntries.length - 1; i >= 0; --i) { var entry = this.tryEntries[i]; if (entry.tryLoc === tryLoc) { var record = entry.completion; if ("throw" === record.type) { var thrown = record.arg; resetTryEntry(entry); } return thrown; } } throw new Error("illegal catch attempt"); }, delegateYield: function delegateYield(iterable, resultName, nextLoc) { return this.delegate = { iterator: values(iterable), resultName: resultName, nextLoc: nextLoc }, "next" === this.method && (this.arg = undefined), ContinueSentinel; } }, exports; }







var isNotConstant = function isNotConstant(constant) {
  return function (arg) {
    return arg !== constant;
  };
};
var isConstant = function isConstant(constant) {
  return function (arg) {
    return arg === constant;
  };
};
var isInstanceOf = function isInstanceOf(type) {
  return function (arg) {
    return arg instanceof type;
  };
};
function groupByConsecutiveValues(array, needle) {
  return array.reduce(function (accumulator, currentValue) {
    var lastGroup = (0,lodash_es__WEBPACK_IMPORTED_MODULE_2__["default"])(accumulator);
    var currentGroupValue = currentValue[needle];

    if (lastGroup && currentGroupValue === lastGroup.group) {
      lastGroup.values.push(currentValue);
    } else {
      accumulator.push({
        group: currentGroupValue,
        values: [currentValue]
      });
    }

    return accumulator;
  }, []);
}
function tapLog() {
  for (var _len = arguments.length, logMsgs = new Array(_len), _key = 0; _key < _len; _key++) {
    logMsgs[_key] = arguments[_key];
  }

  return (0,rxjs_operators__WEBPACK_IMPORTED_MODULE_3__.tap)(function (data) {
    var _console;

    return (_console = console).log.apply(_console, logMsgs.concat([data]));
  });
}
function runInZone(zone) {
  return runInContext(zone.run.bind(zone));
}
function runOutsideAngular(zone) {
  return runInContext(zone.runOutsideAngular.bind(zone));
}
function runInContext(contextFunction) {
  return function (source) {
    return new rxjs__WEBPACK_IMPORTED_MODULE_4__.Observable(function (observer) {
      var onNext = function onNext(value) {
        return contextFunction(function () {
          return observer.next(value);
        });
      };

      var onError = function onError(e) {
        return contextFunction(function () {
          return observer.error(e);
        });
      };

      var onComplete = function onComplete() {
        return contextFunction(function () {
          return observer.complete();
        });
      };

      return source.subscribe(onNext, onError, onComplete);
    });
  };
}
function startFrom(start) {
  return function (source) {
    return (0,rxjs__WEBPACK_IMPORTED_MODULE_5__.concat)(start, source);
  };
}
/** like concat, but don't wait to complete */

function beforeStartUse(start) {
  return function (source) {
    return (0,rxjs__WEBPACK_IMPORTED_MODULE_6__.merge)((0,rxjs__WEBPACK_IMPORTED_MODULE_7__.from)(start).pipe((0,rxjs_operators__WEBPACK_IMPORTED_MODULE_8__.takeUntil)(source)), source);
  };
}
function throwIfNil(errorFn) {
  return function (source) {
    return source.pipe((0,rxjs_operators__WEBPACK_IMPORTED_MODULE_9__.map)(function (value, index) {
      if (value === null || value === undefined) {
        throw errorFn(value, index);
      }

      return value;
    }));
  };
}
function ifOfflineUseStored(storage) {
  var integrityCheck = arguments.length > 1 && arguments[1] !== undefined ? arguments[1] : function () {
    return true;
  };
  return function (source) {
    return source.pipe((0,rxjs_operators__WEBPACK_IMPORTED_MODULE_10__.catchError)(function (error) {
      if (isOfflineError(error)) {
        return (0,rxjs__WEBPACK_IMPORTED_MODULE_7__.from)(storage.get()).pipe((0,rxjs_operators__WEBPACK_IMPORTED_MODULE_11__.filter)((0,lodash_es__WEBPACK_IMPORTED_MODULE_12__["default"])(lodash_es__WEBPACK_IMPORTED_MODULE_13__["default"])), (0,rxjs_operators__WEBPACK_IMPORTED_MODULE_11__.filter)(integrityCheck));
      }

      return (0,rxjs__WEBPACK_IMPORTED_MODULE_14__.throwError)(function () {
        return error;
      });
    }));
  };
}
function isOffline() {
  return navigator.onLine === false || // debug offline from console
  src_environments_environment__WEBPACK_IMPORTED_MODULE_1__.environment.production === false && window.debugOffline === true;
}
function isOfflineError(error) {
  return error.status === 0 && isOffline() || // debug offline from network
  src_environments_environment__WEBPACK_IMPORTED_MODULE_1__.environment.production === false && error.status === 418 && error.error === 'offline';
}
function asyncFilter(predicate) {
  return (0,rxjs_operators__WEBPACK_IMPORTED_MODULE_15__.concatMap)(function (value, index) {
    return (0,rxjs__WEBPACK_IMPORTED_MODULE_7__.from)(predicate(value, index)).pipe((0,rxjs_operators__WEBPACK_IMPORTED_MODULE_11__.filter)(Boolean), (0,rxjs_operators__WEBPACK_IMPORTED_MODULE_9__.map)(function () {
      return value;
    }));
  });
}
function castTo() {
  return function (source) {
    return source;
  };
}
function getDebugStack() {
  return new Error().stack || 'stack not available';
}
function readAsBase64(photo) {
  return (0,tslib__WEBPACK_IMPORTED_MODULE_16__.__awaiter)(this, void 0, void 0, /*#__PURE__*/_regeneratorRuntime().mark(function _callee() {
    var response, blob;
    return _regeneratorRuntime().wrap(function _callee$(_context) {
      while (1) {
        switch (_context.prev = _context.next) {
          case 0:
            _context.next = 2;
            return fetch(photo.webPath);

          case 2:
            response = _context.sent;
            _context.next = 5;
            return response.blob();

          case 5:
            blob = _context.sent;
            return _context.abrupt("return", blob);

          case 7:
          case "end":
            return _context.stop();
        }
      }
    }, _callee);
  }));
}
function convertBlobToBase64(blob) {
  return new Promise(function (resolve, reject) {
    var reader = new FileReader();
    reader.onerror = reject;

    reader.onload = function () {
      resolve(reader.result);
    };

    reader.readAsDataURL(blob);
  });
}
/**
 * [1,2,3,4] -> [[1,2], [2,3], [3,4]]
 */

var getAdjacentPairs = function getAdjacentPairs(a) {
  return (0,lodash_es__WEBPACK_IMPORTED_MODULE_17__["default"])((0,lodash_es__WEBPACK_IMPORTED_MODULE_18__["default"])(a), (0,lodash_es__WEBPACK_IMPORTED_MODULE_19__["default"])(a));
};
/** Create all combinations of input arrays
 * cartesian(['a', 'b'], [1, 2]) => [['a', 1], ['a', 2], ['b', 1], ['b', 2]]
 */

var cartesian = function cartesian() {
  for (var _len2 = arguments.length, arr = new Array(_len2), _key2 = 0; _key2 < _len2; _key2++) {
    arr[_key2] = arguments[_key2];
  }

  return arr.reduce(function (a, b) {
    return (0,lodash_es__WEBPACK_IMPORTED_MODULE_20__["default"])(a, function (c) {
      return b.map(function (d) {
        return [].concat((0,_Users_smartcommunitylab_Documents_work_projects_dslab_playgo_mobile_playgo_mobile_node_modules_babel_runtime_helpers_esm_toConsumableArray_js__WEBPACK_IMPORTED_MODULE_0__["default"])(c), [d]);
      });
    });
  }, [[]]);
};
function time(ms) {
  return (0,tslib__WEBPACK_IMPORTED_MODULE_16__.__awaiter)(this, void 0, void 0, /*#__PURE__*/_regeneratorRuntime().mark(function _callee2() {
    return _regeneratorRuntime().wrap(function _callee2$(_context2) {
      while (1) {
        switch (_context2.prev = _context2.next) {
          case 0:
            _context2.next = 2;
            return new Promise(function (resolve) {
              setTimeout(resolve, ms);
            });

          case 2:
          case "end":
            return _context2.stop();
        }
      }
    }, _callee2);
  }));
}
function formatDurationToHoursAndMinutes(millis) {
  var duration = luxon__WEBPACK_IMPORTED_MODULE_21__.Duration.fromMillis(Math.abs(millis)).shiftTo('hours', 'minutes');
  var hours = duration.hours;
  var minutes = Math.round(duration.minutes);

  if (hours > 0) {
    return "".concat(hours, " h ").concat(minutes, " min");
  } else {
    return "".concat(minutes, " min");
  }
}
function trackByProperty(property) {
  return function (index, item) {
    return item[property];
  };
}
var waitMs = function waitMs(ms) {
  return new Promise(function (resolve) {
    return setTimeout(resolve, ms);
  });
};
function getImgChallenge(challengeType) {
  if (['groupCooperative', 'groupCompetitiveTime', 'groupCompetitivePerformance'].indexOf(challengeType) > -1) {
    return challengeType;
  }

  return 'default';
}
function getTypeStringChallenge(challengeType) {
  if (['groupCooperative', 'groupCompetitiveTime', 'groupCompetitivePerformance', 'survey'].indexOf(challengeType) > -1) {
    return 'challenges.challenge_model.name.' + challengeType;
  }

  return 'challenges.challenge_model.name.default';
}
function getPeriods(referenceDate) {
  return [{
    labelKey: 'campaigns.stats.filter.period.week',
    label: 'dd-MMMM',
    group: 'day',
    format: 'dd-MM',
    add: 'week',
    switchTo: null,
    from: referenceDate.startOf('week'),
    to: referenceDate.endOf('week')
  }, {
    labelKey: 'campaigns.stats.filter.period.month',
    label: 'MMMM',
    group: 'week',
    format: 'dd-MM-yyyy',
    add: 'month',
    switchTo: 'day',
    from: referenceDate.startOf('month'),
    to: referenceDate.endOf('month')
  }, {
    labelKey: 'campaigns.stats.filter.period.year',
    label: 'yyyy',
    group: 'month',
    format: 'MM-yyyy',
    add: 'year',
    switchTo: 'week',
    from: referenceDate.startOf('year'),
    to: referenceDate.endOf('year')
  }];
}

/***/ }),

/***/ 73081:
/*!****************************************************************************!*\
  !*** ./src/app/pages/home/profile/privacy-modal/privacyModal.component.ts ***!
  \****************************************************************************/
/***/ (function(__unused_webpack_module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "PrivacyModalPage": function() { return /* binding */ PrivacyModalPage; }
/* harmony export */ });
/* harmony import */ var _Users_smartcommunitylab_Documents_work_projects_dslab_playgo_mobile_playgo_mobile_node_modules_babel_runtime_helpers_esm_classCallCheck_js__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./node_modules/@babel/runtime/helpers/esm/classCallCheck.js */ 78069);
/* harmony import */ var _Users_smartcommunitylab_Documents_work_projects_dslab_playgo_mobile_playgo_mobile_node_modules_babel_runtime_helpers_esm_createClass_js__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ./node_modules/@babel/runtime/helpers/esm/createClass.js */ 48047);
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @angular/core */ 3184);
/* harmony import */ var _ionic_angular__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @ionic/angular */ 93819);
/* harmony import */ var _ngx_translate_core__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! @ngx-translate/core */ 87514);





var PrivacyModalPage = /*#__PURE__*/function () {
  function PrivacyModalPage(modalController) {
    (0,_Users_smartcommunitylab_Documents_work_projects_dslab_playgo_mobile_playgo_mobile_node_modules_babel_runtime_helpers_esm_classCallCheck_js__WEBPACK_IMPORTED_MODULE_0__["default"])(this, PrivacyModalPage);

    this.modalController = modalController;
  }

  (0,_Users_smartcommunitylab_Documents_work_projects_dslab_playgo_mobile_playgo_mobile_node_modules_babel_runtime_helpers_esm_createClass_js__WEBPACK_IMPORTED_MODULE_1__["default"])(PrivacyModalPage, [{
    key: "ngOnInit",
    value: function ngOnInit() {}
  }, {
    key: "close",
    value: function close() {
      this.modalController.dismiss();
    }
  }]);

  return PrivacyModalPage;
}();

PrivacyModalPage.ɵfac = function PrivacyModalPage_Factory(t) {
  return new (t || PrivacyModalPage)(_angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵdirectiveInject"](_ionic_angular__WEBPACK_IMPORTED_MODULE_3__.ModalController));
};

PrivacyModalPage.ɵcmp = /*@__PURE__*/_angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵdefineComponent"]({
  type: PrivacyModalPage,
  selectors: [["app-privacy-modal"]],
  decls: 10,
  vars: 3,
  consts: [["color", "playgo"], ["slot", "end"], [3, "click"]],
  template: function PrivacyModalPage_Template(rf, ctx) {
    if (rf & 1) {
      _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵelementStart"](0, "ion-header")(1, "ion-toolbar", 0)(2, "ion-title");
      _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵtext"](3);
      _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵpipe"](4, "translate");
      _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵelementEnd"]();
      _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵelementStart"](5, "ion-buttons", 1)(6, "ion-button", 2);
      _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵlistener"]("click", function PrivacyModalPage_Template_ion_button_click_6_listener() {
        return ctx.close();
      });
      _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵtext"](7, "Close");
      _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵelementEnd"]()()()();
      _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵelementStart"](8, "ion-content", 0);
      _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵtext"](9, " privacy lorem ipsum ");
      _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵelementEnd"]();
    }

    if (rf & 2) {
      _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵadvance"](3);
      _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵtextInterpolate"](_angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵpipeBind1"](4, 1, "profile.privacy.modalTitle"));
    }
  },
  directives: [_ionic_angular__WEBPACK_IMPORTED_MODULE_3__.IonHeader, _ionic_angular__WEBPACK_IMPORTED_MODULE_3__.IonToolbar, _ionic_angular__WEBPACK_IMPORTED_MODULE_3__.IonTitle, _ionic_angular__WEBPACK_IMPORTED_MODULE_3__.IonButtons, _ionic_angular__WEBPACK_IMPORTED_MODULE_3__.IonButton, _ionic_angular__WEBPACK_IMPORTED_MODULE_3__.IonContent],
  pipes: [_ngx_translate_core__WEBPACK_IMPORTED_MODULE_4__.TranslatePipe],
  styles: ["\n/*# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbXSwibmFtZXMiOltdLCJtYXBwaW5ncyI6IiIsImZpbGUiOiJwcml2YWN5LW1vZGFsLnBhZ2UuY3NzIn0= */"]
});

/***/ }),

/***/ 92340:
/*!*****************************************!*\
  !*** ./src/environments/environment.ts ***!
  \*****************************************/
/***/ (function(__unused_webpack_module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "environment": function() { return /* binding */ environment; }
/* harmony export */ });
/* harmony import */ var zone_js_dist_zone_error__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! zone.js/dist/zone-error */ 30771);
/* harmony import */ var zone_js_dist_zone_error__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(zone_js_dist_zone_error__WEBPACK_IMPORTED_MODULE_0__);
/* eslint-disable @typescript-eslint/naming-convention */
// This file can be replaced during build by using the `fileReplacements` array.
// `ng build --prod` replaces `environment.ts` with `environment.prod.ts`.
// The list of file replacements can be found in `angular.json`.
var environment = {
  production: false,
  useCodePush: false,
  authConfig: {
    server_host: 'https://aac.platform.smartcommunitylab.it',
    client_id: 'c_5445634c-95d6-4c0e-a1ff-829b951b91b3',
    // client_id: 'x_5445634c-95d6-4c0e-a1ff-829b951b91b3',
    redirect_url: 'it.dslab.playgo://callback',
    end_session_redirect_url: 'it.dslab.playgo://endsession',
    scopes: 'openid email profile offline_access',
    automaticSilentRenew: false,
    extras: {
      prompt: 'consent',
      idp_hint: 'ciao'
    },
    pkce: true
  },
  idp_hint: {
    facebook: 'koi8jw8x',
    google: 'Nqoa1EDO',
    apple: 'owbERvU0'
  },
  serverUrl: {
    api: 'https://backenddev.playngo.it:443',
    apiPath: '/playandgo/api',
    pgaziendeUrl: 'https://pgaziendaledev.platform.smartcommunitylab.it/api/public',
    hscApi: 'https://hscdev.playngo.it/playandgo-hsc/publicapi'
  },
  firebaseConfig: {
    apiKey: 'AIzaSyC4jMIUaDnXVITplF2jIjhw2ElgUMillHE',
    authDomain: 'playgo-mobile.firebaseapp.com',
    projectId: 'playgo-mobile',
    storageBucket: 'playgo-mobile.appspot.com',
    messagingSenderId: '187362305431',
    appId: '1:187362305431:web:6b28040d084512431810d2',
    measurementId: 'G-5QRQJTP30R'
  }
};
/*
 * For easier debugging in development mode, you can import the following file
 * to ignore zone related error stack frames such as `zone.run`, `zoneDelegate.invokeTask`.
 *
 * This import should be commented out in production mode because it will have a negative impact
 * on performance if an error is thrown.
 */

 // Included with Angular CLI.

/***/ }),

/***/ 14431:
/*!*********************!*\
  !*** ./src/main.ts ***!
  \*********************/
/***/ (function(__unused_webpack_module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony import */ var _angular_platform_browser__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @angular/platform-browser */ 50318);
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @angular/core */ 3184);
/* harmony import */ var _app_app_module__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./app/app.module */ 36747);
/* harmony import */ var _environments_environment__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ./environments/environment */ 92340);





if (_environments_environment__WEBPACK_IMPORTED_MODULE_1__.environment.production) {
  (0,_angular_core__WEBPACK_IMPORTED_MODULE_2__.enableProdMode)();
}

_angular_platform_browser__WEBPACK_IMPORTED_MODULE_3__.platformBrowser().bootstrapModule(_app_app_module__WEBPACK_IMPORTED_MODULE_0__.AppModule).catch(function (err) {
  return console.log(err);
});

/***/ }),

/***/ 50863:
/*!******************************************************************************************************************************************!*\
  !*** ./node_modules/@ionic/core/dist/esm/ lazy ^\.\/.*\.entry\.js$ include: \.entry\.js$ exclude: \.system\.entry\.js$ namespace object ***!
  \******************************************************************************************************************************************/
/***/ (function(module, __unused_webpack_exports, __webpack_require__) {

var map = {
	"./ion-accordion_2.entry.js": [
		70079,
		"common",
		"node_modules_ionic_core_dist_esm_ion-accordion_2_entry_js"
	],
	"./ion-action-sheet.entry.js": [
		25593,
		"default-node_modules_ionic_core_dist_esm_theme-7670341c_js",
		"common",
		"node_modules_ionic_core_dist_esm_ion-action-sheet_entry_js"
	],
	"./ion-alert.entry.js": [
		13225,
		"default-node_modules_ionic_core_dist_esm_theme-7670341c_js",
		"common",
		"node_modules_ionic_core_dist_esm_ion-alert_entry_js"
	],
	"./ion-app_8.entry.js": [
		4812,
		"default-node_modules_ionic_core_dist_esm_theme-7670341c_js",
		"default-node_modules_ionic_core_dist_esm_index-8bf9b0cd_js",
		"default-node_modules_ionic_core_dist_esm_framework-delegate-ce4f806c_js",
		"common",
		"node_modules_ionic_core_dist_esm_ion-app_8_entry_js"
	],
	"./ion-avatar_3.entry.js": [
		86655,
		"default-node_modules_ionic_core_dist_esm_theme-7670341c_js",
		"node_modules_ionic_core_dist_esm_ion-avatar_3_entry_js"
	],
	"./ion-back-button.entry.js": [
		44856,
		"default-node_modules_ionic_core_dist_esm_theme-7670341c_js",
		"common",
		"node_modules_ionic_core_dist_esm_ion-back-button_entry_js"
	],
	"./ion-backdrop.entry.js": [
		13059,
		"node_modules_ionic_core_dist_esm_ion-backdrop_entry_js"
	],
	"./ion-breadcrumb_2.entry.js": [
		58648,
		"default-node_modules_ionic_core_dist_esm_theme-7670341c_js",
		"common",
		"node_modules_ionic_core_dist_esm_ion-breadcrumb_2_entry_js"
	],
	"./ion-button_2.entry.js": [
		98308,
		"default-node_modules_ionic_core_dist_esm_theme-7670341c_js",
		"node_modules_ionic_core_dist_esm_ion-button_2_entry_js"
	],
	"./ion-card_5.entry.js": [
		44690,
		"default-node_modules_ionic_core_dist_esm_theme-7670341c_js",
		"node_modules_ionic_core_dist_esm_ion-card_5_entry_js"
	],
	"./ion-checkbox.entry.js": [
		64090,
		"default-node_modules_ionic_core_dist_esm_theme-7670341c_js",
		"node_modules_ionic_core_dist_esm_ion-checkbox_entry_js"
	],
	"./ion-chip.entry.js": [
		36214,
		"default-node_modules_ionic_core_dist_esm_theme-7670341c_js",
		"node_modules_ionic_core_dist_esm_ion-chip_entry_js"
	],
	"./ion-col_3.entry.js": [
		69447,
		"node_modules_ionic_core_dist_esm_ion-col_3_entry_js"
	],
	"./ion-datetime_3.entry.js": [
		79689,
		"default-node_modules_ionic_core_dist_esm_theme-7670341c_js",
		"common",
		"node_modules_ionic_core_dist_esm_ion-datetime_3_entry_js"
	],
	"./ion-fab_3.entry.js": [
		18840,
		"default-node_modules_ionic_core_dist_esm_theme-7670341c_js",
		"common",
		"node_modules_ionic_core_dist_esm_ion-fab_3_entry_js"
	],
	"./ion-img.entry.js": [
		40749,
		"node_modules_ionic_core_dist_esm_ion-img_entry_js"
	],
	"./ion-infinite-scroll_2.entry.js": [
		69667,
		"default-node_modules_ionic_core_dist_esm_index-8bf9b0cd_js",
		"node_modules_ionic_core_dist_esm_ion-infinite-scroll_2_entry_js"
	],
	"./ion-input.entry.js": [
		83288,
		"default-node_modules_ionic_core_dist_esm_theme-7670341c_js",
		"node_modules_ionic_core_dist_esm_ion-input_entry_js"
	],
	"./ion-item-option_3.entry.js": [
		35473,
		"default-node_modules_ionic_core_dist_esm_theme-7670341c_js",
		"default-node_modules_ionic_core_dist_esm_index-8bf9b0cd_js",
		"node_modules_ionic_core_dist_esm_ion-item-option_3_entry_js"
	],
	"./ion-item_8.entry.js": [
		53634,
		"default-node_modules_ionic_core_dist_esm_theme-7670341c_js",
		"common",
		"node_modules_ionic_core_dist_esm_ion-item_8_entry_js"
	],
	"./ion-loading.entry.js": [
		22855,
		"default-node_modules_ionic_core_dist_esm_theme-7670341c_js",
		"node_modules_ionic_core_dist_esm_ion-loading_entry_js"
	],
	"./ion-menu_3.entry.js": [
		495,
		"default-node_modules_ionic_core_dist_esm_theme-7670341c_js",
		"common",
		"node_modules_ionic_core_dist_esm_ion-menu_3_entry_js"
	],
	"./ion-modal.entry.js": [
		58737,
		"default-node_modules_ionic_core_dist_esm_theme-7670341c_js",
		"default-node_modules_ionic_core_dist_esm_index-8bf9b0cd_js",
		"default-node_modules_ionic_core_dist_esm_framework-delegate-ce4f806c_js",
		"common",
		"node_modules_ionic_core_dist_esm_ion-modal_entry_js"
	],
	"./ion-nav_2.entry.js": [
		99632,
		"default-node_modules_ionic_core_dist_esm_framework-delegate-ce4f806c_js",
		"node_modules_ionic_core_dist_esm_ion-nav_2_entry_js"
	],
	"./ion-picker-column-internal.entry.js": [
		54446,
		"default-node_modules_ionic_core_dist_esm_theme-7670341c_js",
		"common",
		"node_modules_ionic_core_dist_esm_ion-picker-column-internal_entry_js"
	],
	"./ion-picker-internal.entry.js": [
		32275,
		"node_modules_ionic_core_dist_esm_ion-picker-internal_entry_js"
	],
	"./ion-popover.entry.js": [
		48050,
		"default-node_modules_ionic_core_dist_esm_theme-7670341c_js",
		"default-node_modules_ionic_core_dist_esm_framework-delegate-ce4f806c_js",
		"node_modules_ionic_core_dist_esm_ion-popover_entry_js"
	],
	"./ion-progress-bar.entry.js": [
		18994,
		"default-node_modules_ionic_core_dist_esm_theme-7670341c_js",
		"node_modules_ionic_core_dist_esm_ion-progress-bar_entry_js"
	],
	"./ion-radio_2.entry.js": [
		23592,
		"default-node_modules_ionic_core_dist_esm_theme-7670341c_js",
		"node_modules_ionic_core_dist_esm_ion-radio_2_entry_js"
	],
	"./ion-range.entry.js": [
		35454,
		"default-node_modules_ionic_core_dist_esm_theme-7670341c_js",
		"default-node_modules_ionic_core_dist_esm_index-8bf9b0cd_js",
		"common",
		"node_modules_ionic_core_dist_esm_ion-range_entry_js"
	],
	"./ion-refresher_2.entry.js": [
		290,
		"default-node_modules_ionic_core_dist_esm_index-8bf9b0cd_js",
		"common",
		"node_modules_ionic_core_dist_esm_ion-refresher_2_entry_js"
	],
	"./ion-reorder_2.entry.js": [
		92666,
		"default-node_modules_ionic_core_dist_esm_index-8bf9b0cd_js",
		"common",
		"node_modules_ionic_core_dist_esm_ion-reorder_2_entry_js"
	],
	"./ion-ripple-effect.entry.js": [
		64816,
		"node_modules_ionic_core_dist_esm_ion-ripple-effect_entry_js"
	],
	"./ion-route_4.entry.js": [
		45534,
		"default-node_modules_ionic_core_dist_esm_theme-7670341c_js",
		"node_modules_ionic_core_dist_esm_ion-route_4_entry_js"
	],
	"./ion-searchbar.entry.js": [
		94902,
		"default-node_modules_ionic_core_dist_esm_theme-7670341c_js",
		"common",
		"node_modules_ionic_core_dist_esm_ion-searchbar_entry_js"
	],
	"./ion-segment_2.entry.js": [
		91938,
		"default-node_modules_ionic_core_dist_esm_theme-7670341c_js",
		"common",
		"node_modules_ionic_core_dist_esm_ion-segment_2_entry_js"
	],
	"./ion-select_3.entry.js": [
		78179,
		"default-node_modules_ionic_core_dist_esm_theme-7670341c_js",
		"node_modules_ionic_core_dist_esm_ion-select_3_entry_js"
	],
	"./ion-slide_2.entry.js": [
		90668,
		"node_modules_ionic_core_dist_esm_ion-slide_2_entry_js"
	],
	"./ion-spinner.entry.js": [
		61624,
		"default-node_modules_ionic_core_dist_esm_theme-7670341c_js",
		"common",
		"node_modules_ionic_core_dist_esm_ion-spinner_entry_js"
	],
	"./ion-split-pane.entry.js": [
		19989,
		"node_modules_ionic_core_dist_esm_ion-split-pane_entry_js"
	],
	"./ion-tab-bar_2.entry.js": [
		28902,
		"default-node_modules_ionic_core_dist_esm_theme-7670341c_js",
		"node_modules_ionic_core_dist_esm_ion-tab-bar_2_entry_js"
	],
	"./ion-tab_2.entry.js": [
		70199,
		"default-node_modules_ionic_core_dist_esm_framework-delegate-ce4f806c_js",
		"node_modules_ionic_core_dist_esm_ion-tab_2_entry_js"
	],
	"./ion-text.entry.js": [
		48395,
		"default-node_modules_ionic_core_dist_esm_theme-7670341c_js",
		"node_modules_ionic_core_dist_esm_ion-text_entry_js"
	],
	"./ion-textarea.entry.js": [
		96357,
		"default-node_modules_ionic_core_dist_esm_theme-7670341c_js",
		"node_modules_ionic_core_dist_esm_ion-textarea_entry_js"
	],
	"./ion-toast.entry.js": [
		38268,
		"default-node_modules_ionic_core_dist_esm_theme-7670341c_js",
		"node_modules_ionic_core_dist_esm_ion-toast_entry_js"
	],
	"./ion-toggle.entry.js": [
		15269,
		"default-node_modules_ionic_core_dist_esm_theme-7670341c_js",
		"common",
		"node_modules_ionic_core_dist_esm_ion-toggle_entry_js"
	],
	"./ion-virtual-scroll.entry.js": [
		32875,
		"node_modules_ionic_core_dist_esm_ion-virtual-scroll_entry_js"
	]
};
function webpackAsyncContext(req) {
	if(!__webpack_require__.o(map, req)) {
		return Promise.resolve().then(function() {
			var e = new Error("Cannot find module '" + req + "'");
			e.code = 'MODULE_NOT_FOUND';
			throw e;
		});
	}

	var ids = map[req], id = ids[0];
	return Promise.all(ids.slice(1).map(__webpack_require__.e)).then(function() {
		return __webpack_require__(id);
	});
}
webpackAsyncContext.keys = function() { return Object.keys(map); };
webpackAsyncContext.id = 50863;
module.exports = webpackAsyncContext;

/***/ })

},
/******/ function(__webpack_require__) { // webpackRuntimeModules
/******/ var __webpack_exec__ = function(moduleId) { return __webpack_require__(__webpack_require__.s = moduleId); }
/******/ __webpack_require__.O(0, ["vendor"], function() { return __webpack_exec__(14431); });
/******/ var __webpack_exports__ = __webpack_require__.O();
/******/ }
]);
//# sourceMappingURL=main.js.map