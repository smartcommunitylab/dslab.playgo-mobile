"use strict";
(self["webpackChunkapp"] = self["webpackChunkapp"] || []).push([["src_app_pages_stats_stats_module_ts"],{

/***/ 41319:
/*!*****************************************************!*\
  !*** ./src/app/pages/stats/stats-routing.module.ts ***!
  \*****************************************************/
/***/ (function(__unused_webpack_module, __webpack_exports__, __webpack_require__) {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "StatsPageRoutingModule": function() { return /* binding */ StatsPageRoutingModule; }
/* harmony export */ });
/* harmony import */ var _Users_smartcommunitylab_Documents_work_projects_dslab_playgo_mobile_playgo_mobile_node_modules_babel_runtime_helpers_esm_createClass_js__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./node_modules/@babel/runtime/helpers/esm/createClass.js */ 48047);
/* harmony import */ var _Users_smartcommunitylab_Documents_work_projects_dslab_playgo_mobile_playgo_mobile_node_modules_babel_runtime_helpers_esm_classCallCheck_js__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ./node_modules/@babel/runtime/helpers/esm/classCallCheck.js */ 78069);
/* harmony import */ var _angular_router__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! @angular/router */ 52816);
/* harmony import */ var _stats_page__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! ./stats.page */ 13133);
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @angular/core */ 3184);






var routes = [{
  path: '',
  component: _stats_page__WEBPACK_IMPORTED_MODULE_2__.StatsPage,
  data: {
    title: 'report.stats.title'
  }
}];
var StatsPageRoutingModule = /*#__PURE__*/(0,_Users_smartcommunitylab_Documents_work_projects_dslab_playgo_mobile_playgo_mobile_node_modules_babel_runtime_helpers_esm_createClass_js__WEBPACK_IMPORTED_MODULE_0__["default"])(function StatsPageRoutingModule() {
  (0,_Users_smartcommunitylab_Documents_work_projects_dslab_playgo_mobile_playgo_mobile_node_modules_babel_runtime_helpers_esm_classCallCheck_js__WEBPACK_IMPORTED_MODULE_1__["default"])(this, StatsPageRoutingModule);
});

StatsPageRoutingModule.ɵfac = function StatsPageRoutingModule_Factory(t) {
  return new (t || StatsPageRoutingModule)();
};

StatsPageRoutingModule.ɵmod = /*@__PURE__*/_angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵdefineNgModule"]({
  type: StatsPageRoutingModule
});
StatsPageRoutingModule.ɵinj = /*@__PURE__*/_angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵdefineInjector"]({
  imports: [[_angular_router__WEBPACK_IMPORTED_MODULE_4__.RouterModule.forChild(routes)], _angular_router__WEBPACK_IMPORTED_MODULE_4__.RouterModule]
});

(function () {
  (typeof ngJitMode === "undefined" || ngJitMode) && _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵsetNgModuleScope"](StatsPageRoutingModule, {
    imports: [_angular_router__WEBPACK_IMPORTED_MODULE_4__.RouterModule],
    exports: [_angular_router__WEBPACK_IMPORTED_MODULE_4__.RouterModule]
  });
})();

/***/ }),

/***/ 6636:
/*!*********************************************!*\
  !*** ./src/app/pages/stats/stats.module.ts ***!
  \*********************************************/
/***/ (function(__unused_webpack_module, __webpack_exports__, __webpack_require__) {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "StatsPageModule": function() { return /* binding */ StatsPageModule; }
/* harmony export */ });
/* harmony import */ var _Users_smartcommunitylab_Documents_work_projects_dslab_playgo_mobile_playgo_mobile_node_modules_babel_runtime_helpers_esm_createClass_js__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./node_modules/@babel/runtime/helpers/esm/createClass.js */ 48047);
/* harmony import */ var _Users_smartcommunitylab_Documents_work_projects_dslab_playgo_mobile_playgo_mobile_node_modules_babel_runtime_helpers_esm_classCallCheck_js__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ./node_modules/@babel/runtime/helpers/esm/classCallCheck.js */ 78069);
/* harmony import */ var _stats_routing_module__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! ./stats-routing.module */ 41319);
/* harmony import */ var _stats_page__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! ./stats.page */ 13133);
/* harmony import */ var src_app_core_shared_shared_module__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! src/app/core/shared/shared.module */ 97205);
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! @angular/core */ 3184);






var StatsPageModule = /*#__PURE__*/(0,_Users_smartcommunitylab_Documents_work_projects_dslab_playgo_mobile_playgo_mobile_node_modules_babel_runtime_helpers_esm_createClass_js__WEBPACK_IMPORTED_MODULE_0__["default"])(function StatsPageModule() {
  (0,_Users_smartcommunitylab_Documents_work_projects_dslab_playgo_mobile_playgo_mobile_node_modules_babel_runtime_helpers_esm_classCallCheck_js__WEBPACK_IMPORTED_MODULE_1__["default"])(this, StatsPageModule);
});

StatsPageModule.ɵfac = function StatsPageModule_Factory(t) {
  return new (t || StatsPageModule)();
};

StatsPageModule.ɵmod = /*@__PURE__*/_angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵdefineNgModule"]({
  type: StatsPageModule
});
StatsPageModule.ɵinj = /*@__PURE__*/_angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵdefineInjector"]({
  imports: [[src_app_core_shared_shared_module__WEBPACK_IMPORTED_MODULE_4__.PlayGoSharedModule, _stats_routing_module__WEBPACK_IMPORTED_MODULE_2__.StatsPageRoutingModule]]
});

(function () {
  (typeof ngJitMode === "undefined" || ngJitMode) && _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵsetNgModuleScope"](StatsPageModule, {
    declarations: [_stats_page__WEBPACK_IMPORTED_MODULE_3__.StatsPage],
    imports: [src_app_core_shared_shared_module__WEBPACK_IMPORTED_MODULE_4__.PlayGoSharedModule, _stats_routing_module__WEBPACK_IMPORTED_MODULE_2__.StatsPageRoutingModule]
  });
})();

/***/ }),

/***/ 13133:
/*!*******************************************!*\
  !*** ./src/app/pages/stats/stats.page.ts ***!
  \*******************************************/
/***/ (function(__unused_webpack_module, __webpack_exports__, __webpack_require__) {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "StatsPage": function() { return /* binding */ StatsPage; }
/* harmony export */ });
/* harmony import */ var _Users_smartcommunitylab_Documents_work_projects_dslab_playgo_mobile_playgo_mobile_node_modules_babel_runtime_helpers_esm_createForOfIteratorHelper_js__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./node_modules/@babel/runtime/helpers/esm/createForOfIteratorHelper.js */ 95106);
/* harmony import */ var _Users_smartcommunitylab_Documents_work_projects_dslab_playgo_mobile_playgo_mobile_node_modules_babel_runtime_helpers_esm_defineProperty_js__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ./node_modules/@babel/runtime/helpers/esm/defineProperty.js */ 77797);
/* harmony import */ var _Users_smartcommunitylab_Documents_work_projects_dslab_playgo_mobile_playgo_mobile_node_modules_babel_runtime_helpers_esm_slicedToArray_js__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! ./node_modules/@babel/runtime/helpers/esm/slicedToArray.js */ 10507);
/* harmony import */ var _Users_smartcommunitylab_Documents_work_projects_dslab_playgo_mobile_playgo_mobile_node_modules_babel_runtime_helpers_esm_classCallCheck_js__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! ./node_modules/@babel/runtime/helpers/esm/classCallCheck.js */ 78069);
/* harmony import */ var _Users_smartcommunitylab_Documents_work_projects_dslab_playgo_mobile_playgo_mobile_node_modules_babel_runtime_helpers_esm_createClass_js__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! ./node_modules/@babel/runtime/helpers/esm/createClass.js */ 48047);
/* harmony import */ var _ionic_angular__WEBPACK_IMPORTED_MODULE_24__ = __webpack_require__(/*! @ionic/angular */ 93819);
/* harmony import */ var chart_js__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! chart.js */ 10177);
/* harmony import */ var rxjs__WEBPACK_IMPORTED_MODULE_14__ = __webpack_require__(/*! rxjs */ 80228);
/* harmony import */ var rxjs__WEBPACK_IMPORTED_MODULE_19__ = __webpack_require__(/*! rxjs */ 26562);
/* harmony import */ var luxon__WEBPACK_IMPORTED_MODULE_18__ = __webpack_require__(/*! luxon */ 29527);
/* harmony import */ var rxjs_operators__WEBPACK_IMPORTED_MODULE_15__ = __webpack_require__(/*! rxjs/operators */ 50635);
/* harmony import */ var rxjs_operators__WEBPACK_IMPORTED_MODULE_16__ = __webpack_require__(/*! rxjs/operators */ 44874);
/* harmony import */ var rxjs_operators__WEBPACK_IMPORTED_MODULE_17__ = __webpack_require__(/*! rxjs/operators */ 89196);
/* harmony import */ var rxjs_operators__WEBPACK_IMPORTED_MODULE_20__ = __webpack_require__(/*! rxjs/operators */ 98977);
/* harmony import */ var rxjs_operators__WEBPACK_IMPORTED_MODULE_22__ = __webpack_require__(/*! rxjs/operators */ 32673);
/* harmony import */ var lodash_es__WEBPACK_IMPORTED_MODULE_21__ = __webpack_require__(/*! lodash-es */ 63247);
/* harmony import */ var src_app_core_shared_time_utils__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! src/app/core/shared/time.utils */ 93462);
/* harmony import */ var src_app_core_shared_utils__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(/*! src/app/core/shared/utils */ 68647);
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_13__ = __webpack_require__(/*! @angular/core */ 3184);
/* harmony import */ var _angular_router__WEBPACK_IMPORTED_MODULE_23__ = __webpack_require__(/*! @angular/router */ 52816);
/* harmony import */ var src_app_core_api_generated_controllers_reportController_service__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(/*! src/app/core/api/generated/controllers/reportController.service */ 59730);
/* harmony import */ var src_app_core_shared_services_user_service__WEBPACK_IMPORTED_MODULE_9__ = __webpack_require__(/*! src/app/core/shared/services/user.service */ 50749);
/* harmony import */ var src_app_core_shared_services_error_service__WEBPACK_IMPORTED_MODULE_10__ = __webpack_require__(/*! src/app/core/shared/services/error.service */ 96204);
/* harmony import */ var _core_shared_layout_header_header_directive__WEBPACK_IMPORTED_MODULE_11__ = __webpack_require__(/*! ../../core/shared/layout/header/header.directive */ 34161);
/* harmony import */ var _angular_common__WEBPACK_IMPORTED_MODULE_25__ = __webpack_require__(/*! @angular/common */ 36362);
/* harmony import */ var _angular_forms__WEBPACK_IMPORTED_MODULE_26__ = __webpack_require__(/*! @angular/forms */ 90587);
/* harmony import */ var _ngx_translate_core__WEBPACK_IMPORTED_MODULE_27__ = __webpack_require__(/*! @ngx-translate/core */ 87514);
/* harmony import */ var _core_shared_pipes_localNumber_pipe__WEBPACK_IMPORTED_MODULE_12__ = __webpack_require__(/*! ../../core/shared/pipes/localNumber.pipe */ 89713);
























var _c0 = ["barCanvas"];
var _c1 = ["refresher"];

function StatsPage_ion_select_option_8_Template(rf, ctx) {
  if (rf & 1) {
    _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵelementStart"](0, "ion-select-option", 16);
    _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵtext"](1);
    _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵpipe"](2, "translate");
    _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵelementEnd"]();
  }

  if (rf & 2) {
    var statMeanType_r4 = ctx.$implicit;
    _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵproperty"]("value", statMeanType_r4);
    _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵadvance"](1);
    _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵtextInterpolate1"](" ", _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵpipeBind1"](2, 2, statMeanType_r4.labelKey), " ");
  }
}

function StatsPage_ion_select_option_16_Template(rf, ctx) {
  if (rf & 1) {
    _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵelementStart"](0, "ion-select-option", 16);
    _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵtext"](1);
    _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵpipe"](2, "translate");
    _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵelementEnd"]();
  }

  if (rf & 2) {
    var statUnitType_r5 = ctx.$implicit;
    _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵproperty"]("value", statUnitType_r5);
    _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵadvance"](1);
    _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵtextInterpolate1"](" ", _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵpipeBind1"](2, 2, statUnitType_r5.labelKey), " ");
  }
}

function StatsPage_ion_segment_button_19_Template(rf, ctx) {
  if (rf & 1) {
    _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵelementStart"](0, "ion-segment-button", 17)(1, "ion-label");
    _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵtext"](2);
    _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵpipe"](3, "translate");
    _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵelementEnd"]()();
  }

  if (rf & 2) {
    var period_r6 = ctx.$implicit;
    _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵproperty"]("value", period_r6);
    _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵadvance"](2);
    _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵtextInterpolate"](_angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵpipeBind1"](3, 2, period_r6.labelKey));
  }
}

var StatsPage = /*#__PURE__*/function () {
  function StatsPage(route, reportService, userService, errorService) {
    var _this = this;

    (0,_Users_smartcommunitylab_Documents_work_projects_dslab_playgo_mobile_playgo_mobile_node_modules_babel_runtime_helpers_esm_classCallCheck_js__WEBPACK_IMPORTED_MODULE_3__["default"])(this, StatsPage);

    this.route = route;
    this.reportService = reportService;
    this.userService = userService;
    this.errorService = errorService;
    this.statMeanChangedSubject = new rxjs__WEBPACK_IMPORTED_MODULE_14__.Subject();
    this.statUnitChangedSubject = new rxjs__WEBPACK_IMPORTED_MODULE_14__.Subject();
    this.allStatsMeanTypes = [{
      labelKey: 'campaigns.stats.filter.means.car.label',
      unitKey: 'car'
    }, {
      labelKey: 'campaigns.stats.filter.means.bike.label',
      unitKey: 'bike'
    }, {
      labelKey: 'campaigns.stats.filter.means.walk.label',
      unitKey: 'walk'
    }, {
      labelKey: 'campaigns.stats.filter.means.boat.label',
      unitKey: 'boat'
    }, {
      labelKey: 'campaigns.stats.filter.means.train.label',
      unitKey: 'train'
    }, {
      labelKey: 'campaigns.stats.filter.means.bus.label',
      unitKey: 'bus'
    }];
    this.allStatsUnitTypes = [{
      labelKey: 'campaigns.stats.filter.unit.km.label',
      unitKey: 'km',
      resultLabel: 'Km'
    }, {
      labelKey: 'campaigns.stats.filter.unit.co2.label',
      unitKey: 'co2',
      resultLabel: 'Kg'
    }];
    this.selectedStatMeanType$ = this.statMeanChangedSubject.pipe((0,rxjs_operators__WEBPACK_IMPORTED_MODULE_15__.map)(function (event) {
      return event.detail.value;
    }), (0,rxjs_operators__WEBPACK_IMPORTED_MODULE_16__.startWith)(this.allStatsMeanTypes[0]), (0,rxjs_operators__WEBPACK_IMPORTED_MODULE_17__.shareReplay)(1));
    this.selectedStatUnitType$ = this.statUnitChangedSubject.pipe((0,rxjs_operators__WEBPACK_IMPORTED_MODULE_15__.map)(function (event) {
      return event.detail.value;
    }), (0,rxjs_operators__WEBPACK_IMPORTED_MODULE_16__.startWith)(this.allStatsUnitTypes[0]), (0,rxjs_operators__WEBPACK_IMPORTED_MODULE_17__.shareReplay)(1));
    this.referenceDate = luxon__WEBPACK_IMPORTED_MODULE_18__.DateTime.local(); // initPeriods = this.getPeriods(this.referenceDate);

    this.totalValue = 0;
    this.periods = (0,src_app_core_shared_utils__WEBPACK_IMPORTED_MODULE_7__.getPeriods)(this.referenceDate);
    this.selectedPeriod = this.periods[0];
    this.statPeriodChangedSubject = new rxjs__WEBPACK_IMPORTED_MODULE_14__.Subject();
    this.selectedPeriod$ = this.statPeriodChangedSubject.pipe((0,rxjs_operators__WEBPACK_IMPORTED_MODULE_15__.map)(function (period) {
      console.log(period.group);
      _this.selectedPeriod = period;
      return _this.getPeriodByReference(period);
    }), (0,rxjs_operators__WEBPACK_IMPORTED_MODULE_16__.startWith)(this.periods[0]), (0,rxjs_operators__WEBPACK_IMPORTED_MODULE_17__.shareReplay)(1));
    this.campaignId$ = this.route.params.pipe((0,rxjs_operators__WEBPACK_IMPORTED_MODULE_15__.map)(function (params) {
      return params.id;
    }), (0,rxjs_operators__WEBPACK_IMPORTED_MODULE_17__.shareReplay)(1));
    this.statsMeanTypes$ = this.campaignId$.pipe((0,rxjs_operators__WEBPACK_IMPORTED_MODULE_15__.map)(function () {
      return _this.allStatsMeanTypes;
    }), (0,rxjs_operators__WEBPACK_IMPORTED_MODULE_17__.shareReplay)(1));
    this.statsUnitTypes$ = this.campaignId$.pipe((0,rxjs_operators__WEBPACK_IMPORTED_MODULE_15__.map)(function () {
      return _this.allStatsUnitTypes;
    }), (0,rxjs_operators__WEBPACK_IMPORTED_MODULE_17__.shareReplay)(1));
    this.playerId$ = this.userService.userProfile$.pipe((0,rxjs_operators__WEBPACK_IMPORTED_MODULE_15__.map)(function (userProfile) {
      return userProfile.playerId;
    }), (0,rxjs_operators__WEBPACK_IMPORTED_MODULE_17__.shareReplay)(1));
    this.filterOptions$ = (0,rxjs__WEBPACK_IMPORTED_MODULE_19__.combineLatest)([this.selectedStatMeanType$, this.selectedStatUnitType$, this.selectedPeriod$, this.campaignId$, // FIXME: investigate why this is needed.
    this.playerId$.pipe((0,rxjs_operators__WEBPACK_IMPORTED_MODULE_20__.distinctUntilChanged)(lodash_es__WEBPACK_IMPORTED_MODULE_21__["default"]))]).pipe((0,rxjs_operators__WEBPACK_IMPORTED_MODULE_15__.map)(function (_ref) {
      var _ref2 = (0,_Users_smartcommunitylab_Documents_work_projects_dslab_playgo_mobile_playgo_mobile_node_modules_babel_runtime_helpers_esm_slicedToArray_js__WEBPACK_IMPORTED_MODULE_2__["default"])(_ref, 5),
          meanType = _ref2[0],
          unitType = _ref2[1],
          period = _ref2[2],
          campaignId = _ref2[3],
          playerId = _ref2[4];

      return {
        meanType: meanType,
        unitType: unitType,
        period: period,
        campaignId: campaignId,
        playerId: playerId
      };
    }));
    this.statResponse$ = this.filterOptions$.pipe((0,rxjs_operators__WEBPACK_IMPORTED_MODULE_22__.switchMap)(function (_ref3) {
      var meanType = _ref3.meanType,
          unitType = _ref3.unitType,
          period = _ref3.period,
          campaignId = _ref3.campaignId,
          playerId = _ref3.playerId;
      return _this.reportService.getPlayerTransportStatsUsingGET({
        campaignId: campaignId,
        playerId: playerId,
        metric: unitType.unitKey,
        groupMode: period.group,
        mean: meanType.unitKey,
        dateFrom: (0,src_app_core_shared_time_utils__WEBPACK_IMPORTED_MODULE_6__.toServerDateOnly)(period.from),
        dateTo: (0,src_app_core_shared_time_utils__WEBPACK_IMPORTED_MODULE_6__.toServerDateOnly)(period.to)
      }).pipe(_this.errorService.getErrorHandler());
    }));
    this.statsSubs = this.statResponse$.subscribe(function (stats) {
      console.log('new stats' + stats);

      _this.barChartMethod(stats);

      _this.setTotal(stats);
    });
  }

  (0,_Users_smartcommunitylab_Documents_work_projects_dslab_playgo_mobile_playgo_mobile_node_modules_babel_runtime_helpers_esm_createClass_js__WEBPACK_IMPORTED_MODULE_4__["default"])(StatsPage, [{
    key: "setTotal",
    value: function setTotal(stats) {
      this.totalValue = stats.map(function (stat) {
        return stat.value >= 0 ? stat.value : 0;
      }).reduce(function (prev, next) {
        return prev + next;
      }, 0);
    }
  }, {
    key: "ngOnInit",
    value: function ngOnInit() {
      this.selectedSegment = this.periods[0];
    }
  }, {
    key: "ngOnDestroy",
    value: function ngOnDestroy() {
      this.statsSubs.unsubscribe();
    }
  }, {
    key: "getPeriodByReference",
    value: function getPeriodByReference(value) {
      return this.periods.find(function (period) {
        return period.group === value.group;
      });
    }
  }, {
    key: "segmentChanged",
    value: function segmentChanged(ev) {
      console.log('Segment changed, change the selected period', ev);
    }
  }, {
    key: "ngAfterViewInit",
    value: function ngAfterViewInit() {
      var selects = document.querySelectorAll('.app-alert');
      selects.forEach(function (select) {
        select.interfaceOptions = {
          cssClass: 'app-alert'
        };
      });
    }
  }, {
    key: "backPeriod",
    value: function backPeriod() {
      var _this2 = this;

      //change referenceDate
      this.referenceDate = this.referenceDate.plus((0,_Users_smartcommunitylab_Documents_work_projects_dslab_playgo_mobile_playgo_mobile_node_modules_babel_runtime_helpers_esm_defineProperty_js__WEBPACK_IMPORTED_MODULE_1__["default"])({}, this.selectedPeriod.add, -1)); //only get but it doesn't write on subject

      this.periods = (0,src_app_core_shared_utils__WEBPACK_IMPORTED_MODULE_7__.getPeriods)(this.referenceDate);
      var tabIndex = this.periods.findIndex(function (period) {
        return period.group === _this2.selectedPeriod.group;
      });
      this.selectedSegment = this.periods[tabIndex];
      this.statPeriodChangedSubject.next(this.periods[tabIndex]);
    }
  }, {
    key: "forwardPeriod",
    value: function forwardPeriod() {
      var _this3 = this;

      this.referenceDate = this.referenceDate.plus((0,_Users_smartcommunitylab_Documents_work_projects_dslab_playgo_mobile_playgo_mobile_node_modules_babel_runtime_helpers_esm_defineProperty_js__WEBPACK_IMPORTED_MODULE_1__["default"])({}, this.selectedPeriod.add, 1));
      this.periods = (0,src_app_core_shared_utils__WEBPACK_IMPORTED_MODULE_7__.getPeriods)(this.referenceDate);
      var tabIndex = this.periods.findIndex(function (period) {
        return period.group === _this3.selectedPeriod.group;
      });
      this.selectedSegment = this.periods[tabIndex];
      this.statPeriodChangedSubject.next(this.periods[tabIndex]);
    }
  }, {
    key: "daysFromInterval",
    value: function daysFromInterval() {
      var retArr = [];
      var start = this.selectedPeriod.from;
      var end = this.selectedPeriod.to;
      var interval = luxon__WEBPACK_IMPORTED_MODULE_18__.Interval.fromDateTimes(start, end);
      var cursor = interval.start;
      cursor = cursor.startOf(this.selectedPeriod.group);

      while (cursor < interval.end) {
        //begin of the element
        retArr.push(cursor);
        cursor = cursor.plus((0,_Users_smartcommunitylab_Documents_work_projects_dslab_playgo_mobile_playgo_mobile_node_modules_babel_runtime_helpers_esm_defineProperty_js__WEBPACK_IMPORTED_MODULE_1__["default"])({}, this.selectedPeriod.group, 1));
      }

      return retArr;
    }
  }, {
    key: "getObjectDate",
    value: function getObjectDate(statPeriod) {
      //anno - mese o anno numero settimana o anno mese giorno in base alla selezione
      var periodSplitted = statPeriod.split('-');

      switch (this.selectedPeriod.group) {
        case 'day':
          return {
            year: Number(periodSplitted[0]),
            month: Number(periodSplitted[1]),
            day: Number(periodSplitted[2])
          };

        case 'week':
          return {
            weekYear: Number(periodSplitted[0]),
            weekNumber: Number(periodSplitted[1])
          };

        case 'month':
          return {
            year: Number(periodSplitted[0]),
            month: Number(periodSplitted[1])
          };
      }
    }
  }, {
    key: "valuesFromStat",
    value: function valuesFromStat(arrOfPeriod, stats) {
      var _this4 = this;

      //  check if stats[i] is part of arrOfPeriod
      var statsArrayDate = stats.map(function (stat) {
        console.log(stat);
        return luxon__WEBPACK_IMPORTED_MODULE_18__.DateTime.fromObject(_this4.getObjectDate(stat.period));
      });
      console.log(statsArrayDate);
      var retArr = [];

      var _iterator = (0,_Users_smartcommunitylab_Documents_work_projects_dslab_playgo_mobile_playgo_mobile_node_modules_babel_runtime_helpers_esm_createForOfIteratorHelper_js__WEBPACK_IMPORTED_MODULE_0__["default"])(arrOfPeriod),
          _step;

      try {
        var _loop = function _loop() {
          var period = _step.value;
          //check if statsArrayDate has a period
          var i = statsArrayDate.findIndex(function (statPeriod) {
            return statPeriod.toISO() === period.toISO();
          });

          if (i !== -1) {
            retArr.push(stats[i].value >= 0 ? stats[i].value : 0);
          } else {
            retArr.push(0);
          }
        };

        for (_iterator.s(); !(_step = _iterator.n()).done;) {
          _loop();
        }
      } catch (err) {
        _iterator.e(err);
      } finally {
        _iterator.f();
      }

      return retArr;
    }
  }, {
    key: "barChartMethod",
    value: function barChartMethod(stats) {
      var _this5 = this;

      // Now we need to supply a Chart element reference with an
      //object that defines the type of chart we want to use, and the type of data we want to display.
      // eslint-disable-next-line max-len
      chart_js__WEBPACK_IMPORTED_MODULE_5__.Chart.register(chart_js__WEBPACK_IMPORTED_MODULE_5__.LineController, chart_js__WEBPACK_IMPORTED_MODULE_5__.BarController, chart_js__WEBPACK_IMPORTED_MODULE_5__.CategoryScale, chart_js__WEBPACK_IMPORTED_MODULE_5__.LinearScale, chart_js__WEBPACK_IMPORTED_MODULE_5__.BarElement, chart_js__WEBPACK_IMPORTED_MODULE_5__.DoughnutController, chart_js__WEBPACK_IMPORTED_MODULE_5__.ArcElement, chart_js__WEBPACK_IMPORTED_MODULE_5__.PointElement, chart_js__WEBPACK_IMPORTED_MODULE_5__.LineElement);

      if (!this.barCanvas) {
        return;
      } else {
        var chartExist = chart_js__WEBPACK_IMPORTED_MODULE_5__.Chart.getChart('statsChart');

        if (chartExist !== undefined) {
          chartExist.destroy();
        }
      } //build using stats and this.selectedPeriod


      var arrOfPeriod = this.daysFromInterval();
      var arrOfValues = this.valuesFromStat(arrOfPeriod, stats);
      this.barChart = new chart_js__WEBPACK_IMPORTED_MODULE_5__.Chart(this.barCanvas.nativeElement, {
        type: 'bar',
        options: {
          onClick: function onClick(e) {
            var points = _this5.barChart.getElementsAtEventForMode(e, 'nearest', {
              intersect: true
            }, true);

            if (points.length) {
              var firstPoint = points[0];
              var label = _this5.barChart.data.labels[firstPoint.index]; //clicked on label x so I have to switch to that view base on what I'm watching

              _this5.changeView(label); //const value = this.barChart.data.datasets[firstPoint.datasetIndex].data[firstPoint.index];

            }
          }
        },
        data: {
          labels: arrOfPeriod.map(function (period) {
            return period.toFormat(_this5.selectedPeriod.format);
          }),
          datasets: [{
            data: arrOfValues,
            backgroundColor: 'rgba(255, 99, 132, 0.2)',
            borderColor: 'rgba(255, 99, 132, 1)',
            borderWidth: 1
          }]
        }
      });
    }
  }, {
    key: "getSelectedPeriod",
    value: function getSelectedPeriod() {
      return this.selectedPeriod.from.toFormat(this.selectedPeriod.label);
    }
  }, {
    key: "changeView",
    value: function changeView(label) {
      var _this6 = this;

      // segmentChanged($event); statPeriodChangedSubject.next(selectedSegment)
      var switchToPeriod = null;

      switch (this.selectedSegment.group) {
        case 'month':
          label = luxon__WEBPACK_IMPORTED_MODULE_18__.DateTime.fromFormat(label, 'MM-yyyy').toFormat('yyyy-MM-dd');
          break;

        case 'week':
          label = luxon__WEBPACK_IMPORTED_MODULE_18__.DateTime.fromFormat(label, 'dd-MM-yyyy').toFormat('yyyy-WW');
          break;

        case 'day':
          // label = DateTime.fromFormat(label, 'dd-MM').toFormat('yyyy-MM-dd');
          return;

        default:
          break;
      } // change reference date
      //only get but it doesn't write on subject


      this.referenceDate = luxon__WEBPACK_IMPORTED_MODULE_18__.DateTime.fromObject(this.getObjectDate(label));
      this.periods = (0,src_app_core_shared_utils__WEBPACK_IMPORTED_MODULE_7__.getPeriods)(this.referenceDate);
      this.selectedSegment = this.periods.find(function (a) {
        return a.group === _this6.selectedSegment.switchTo;
      });
      this.statPeriodChangedSubject.next(this.selectedSegment);
      console.log('Vado a vedere' + label);
    }
  }]);

  return StatsPage;
}();

StatsPage.ɵfac = function StatsPage_Factory(t) {
  return new (t || StatsPage)(_angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵdirectiveInject"](_angular_router__WEBPACK_IMPORTED_MODULE_23__.ActivatedRoute), _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵdirectiveInject"](src_app_core_api_generated_controllers_reportController_service__WEBPACK_IMPORTED_MODULE_8__.ReportControllerService), _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵdirectiveInject"](src_app_core_shared_services_user_service__WEBPACK_IMPORTED_MODULE_9__.UserService), _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵdirectiveInject"](src_app_core_shared_services_error_service__WEBPACK_IMPORTED_MODULE_10__.ErrorService));
};

StatsPage.ɵcmp = /*@__PURE__*/_angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵdefineComponent"]({
  type: StatsPage,
  selectors: [["app-stats"]],
  viewQuery: function StatsPage_Query(rf, ctx) {
    if (rf & 1) {
      _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵviewQuery"](_c0, 5);
      _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵviewQuery"](_ionic_angular__WEBPACK_IMPORTED_MODULE_24__.IonInfiniteScroll, 5);
      _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵviewQuery"](_c1, 5);
    }

    if (rf & 2) {
      var _t;

      _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵqueryRefresh"](_t = _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵloadQuery"]()) && (ctx.barCanvas = _t.first);
      _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵqueryRefresh"](_t = _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵloadQuery"]()) && (ctx.infiniteScroll = _t.first);
      _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵqueryRefresh"](_t = _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵloadQuery"]()) && (ctx.refresher = _t.first);
    }
  },
  decls: 37,
  vars: 28,
  consts: [["appHeader", ""], [3, "fullscreen"], ["color", "playgo"], [1, "app-alert", 3, "value", "ionChange"], [3, "value", 4, "ngFor", "ngForOf"], ["mode", "md", "scrollable", "", 1, "app-segment", 3, "ngModel", "ngModelChange", "ionChange"], ["checked", "", "class", "app-segment-button", 3, "value", 4, "ngFor", "ngForOf"], [1, "table-header"], ["size", "2"], ["color", "light", "fill", "clear", 3, "click"], ["name", "chevron-back"], ["size", "8"], [1, "ion-text-center"], ["name", "chevron-forward"], ["id", "statsChart", 2, "position", "relative", "height", "20vh", "width", "40vw"], ["barCanvas", ""], [3, "value"], ["checked", "", 1, "app-segment-button", 3, "value"]],
  template: function StatsPage_Template(rf, ctx) {
    if (rf & 1) {
      _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵelement"](0, "ion-header", 0);
      _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵelementStart"](1, "ion-content", 1)(2, "ion-item", 2)(3, "ion-label");
      _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵtext"](4);
      _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵpipe"](5, "translate");
      _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵelementEnd"]();
      _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵelementStart"](6, "ion-select", 3);
      _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵlistener"]("ionChange", function StatsPage_Template_ion_select_ionChange_6_listener($event) {
        return ctx.statMeanChangedSubject.next($event);
      });
      _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵpipe"](7, "async");
      _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵtemplate"](8, StatsPage_ion_select_option_8_Template, 3, 4, "ion-select-option", 4);
      _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵpipe"](9, "async");
      _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵelementEnd"]()();
      _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵelementStart"](10, "ion-item", 2)(11, "ion-label");
      _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵtext"](12);
      _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵpipe"](13, "translate");
      _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵelementEnd"]();
      _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵelementStart"](14, "ion-select", 3);
      _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵlistener"]("ionChange", function StatsPage_Template_ion_select_ionChange_14_listener($event) {
        return ctx.statUnitChangedSubject.next($event);
      });
      _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵpipe"](15, "async");
      _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵtemplate"](16, StatsPage_ion_select_option_16_Template, 3, 4, "ion-select-option", 4);
      _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵpipe"](17, "async");
      _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵelementEnd"]()();
      _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵelementStart"](18, "ion-segment", 5);
      _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵlistener"]("ngModelChange", function StatsPage_Template_ion_segment_ngModelChange_18_listener($event) {
        return ctx.selectedSegment = $event;
      })("ionChange", function StatsPage_Template_ion_segment_ionChange_18_listener($event) {
        ctx.segmentChanged($event);
        return ctx.statPeriodChangedSubject.next(ctx.selectedSegment);
      });
      _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵtemplate"](19, StatsPage_ion_segment_button_19_Template, 4, 4, "ion-segment-button", 6);
      _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵelementEnd"]();
      _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵelementStart"](20, "ion-grid", 7)(21, "ion-row")(22, "ion-col", 8)(23, "ion-button", 9);
      _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵlistener"]("click", function StatsPage_Template_ion_button_click_23_listener() {
        return ctx.backPeriod();
      });
      _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵelement"](24, "ion-icon", 10);
      _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵelementEnd"]()();
      _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵelementStart"](25, "ion-col", 11)(26, "p", 12);
      _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵtext"](27);
      _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵelementEnd"]();
      _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵelementStart"](28, "p", 12);
      _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵtext"](29);
      _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵpipe"](30, "localNumber");
      _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵpipe"](31, "async");
      _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵelementEnd"]()();
      _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵelementStart"](32, "ion-col", 8)(33, "ion-button", 9);
      _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵlistener"]("click", function StatsPage_Template_ion_button_click_33_listener() {
        return ctx.forwardPeriod();
      });
      _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵelement"](34, "ion-icon", 13);
      _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵelementEnd"]()()()();
      _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵelement"](35, "canvas", 14, 15);
      _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵelementEnd"]();
    }

    if (rf & 2) {
      _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵadvance"](1);
      _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵproperty"]("fullscreen", true);
      _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵadvance"](3);
      _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵtextInterpolate"](_angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵpipeBind1"](5, 12, "campaigns.stats.filter.mean_type"));
      _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵadvance"](2);
      _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵproperty"]("value", _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵpipeBind1"](7, 14, ctx.selectedStatMeanType$));
      _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵadvance"](2);
      _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵproperty"]("ngForOf", _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵpipeBind1"](9, 16, ctx.statsMeanTypes$));
      _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵadvance"](4);
      _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵtextInterpolate"](_angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵpipeBind1"](13, 18, "campaigns.stats.filter.unit_type"));
      _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵadvance"](2);
      _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵproperty"]("value", _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵpipeBind1"](15, 20, ctx.selectedStatUnitType$));
      _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵadvance"](2);
      _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵproperty"]("ngForOf", _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵpipeBind1"](17, 22, ctx.statsUnitTypes$));
      _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵadvance"](2);
      _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵproperty"]("ngModel", ctx.selectedSegment);
      _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵadvance"](1);
      _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵproperty"]("ngForOf", ctx.periods);
      _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵadvance"](8);
      _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵtextInterpolate"](ctx.getSelectedPeriod());
      _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵadvance"](2);
      _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵtextInterpolate2"](" ", _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵpipeBind1"](30, 24, ctx.totalValue), " ", _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵpipeBind1"](31, 26, ctx.selectedStatUnitType$).unitKey, " ");
    }
  },
  directives: [_ionic_angular__WEBPACK_IMPORTED_MODULE_24__.IonHeader, _core_shared_layout_header_header_directive__WEBPACK_IMPORTED_MODULE_11__.HeaderDirective, _ionic_angular__WEBPACK_IMPORTED_MODULE_24__.IonContent, _ionic_angular__WEBPACK_IMPORTED_MODULE_24__.IonItem, _ionic_angular__WEBPACK_IMPORTED_MODULE_24__.IonLabel, _ionic_angular__WEBPACK_IMPORTED_MODULE_24__.IonSelect, _ionic_angular__WEBPACK_IMPORTED_MODULE_24__.SelectValueAccessor, _angular_common__WEBPACK_IMPORTED_MODULE_25__.NgForOf, _ionic_angular__WEBPACK_IMPORTED_MODULE_24__.IonSelectOption, _ionic_angular__WEBPACK_IMPORTED_MODULE_24__.IonSegment, _angular_forms__WEBPACK_IMPORTED_MODULE_26__.NgControlStatus, _angular_forms__WEBPACK_IMPORTED_MODULE_26__.NgModel, _ionic_angular__WEBPACK_IMPORTED_MODULE_24__.IonSegmentButton, _ionic_angular__WEBPACK_IMPORTED_MODULE_24__.IonGrid, _ionic_angular__WEBPACK_IMPORTED_MODULE_24__.IonRow, _ionic_angular__WEBPACK_IMPORTED_MODULE_24__.IonCol, _ionic_angular__WEBPACK_IMPORTED_MODULE_24__.IonButton, _ionic_angular__WEBPACK_IMPORTED_MODULE_24__.IonIcon],
  pipes: [_ngx_translate_core__WEBPACK_IMPORTED_MODULE_27__.TranslatePipe, _angular_common__WEBPACK_IMPORTED_MODULE_25__.AsyncPipe, _core_shared_pipes_localNumber_pipe__WEBPACK_IMPORTED_MODULE_12__.LocalNumberPipe],
  styles: [".table-header[_ngcontent-%COMP%] {\n  background-color: var(--ion-color-playgo);\n  color: white;\n  font-size: 22px;\n}\n/*# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbInN0YXRzLnBhZ2Uuc2NzcyJdLCJuYW1lcyI6W10sIm1hcHBpbmdzIjoiQUFBQTtFQUNFLHlDQUFBO0VBQ0EsWUFBQTtFQUNBLGVBQUE7QUFDRiIsImZpbGUiOiJzdGF0cy5wYWdlLnNjc3MiLCJzb3VyY2VzQ29udGVudCI6WyIudGFibGUtaGVhZGVyIHtcbiAgYmFja2dyb3VuZC1jb2xvcjogdmFyKC0taW9uLWNvbG9yLXBsYXlnbyk7XG4gIGNvbG9yOiB3aGl0ZTtcbiAgZm9udC1zaXplOiAyMnB4O1xufVxuIl19 */"]
});

/***/ })

}]);
//# sourceMappingURL=src_app_pages_stats_stats_module_ts.js.map