"use strict";
(self["webpackChunkapp"] = self["webpackChunkapp"] || []).push([["src_app_pages_pages-routing_module_ts"],{

/***/ 39730:
/*!***********************************************!*\
  !*** ./src/app/pages/pages-routing.module.ts ***!
  \***********************************************/
/***/ (function(__unused_webpack_module, __webpack_exports__, __webpack_require__) {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "PagesRoutingModule": function() { return /* binding */ PagesRoutingModule; }
/* harmony export */ });
/* harmony import */ var _Users_smartcommunitylab_Documents_work_projects_dslab_playgo_mobile_playgo_mobile_node_modules_babel_runtime_helpers_esm_createClass_js__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./node_modules/@babel/runtime/helpers/esm/createClass.js */ 48047);
/* harmony import */ var _Users_smartcommunitylab_Documents_work_projects_dslab_playgo_mobile_playgo_mobile_node_modules_babel_runtime_helpers_esm_classCallCheck_js__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ./node_modules/@babel/runtime/helpers/esm/classCallCheck.js */ 78069);
/* harmony import */ var _angular_router__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @angular/router */ 52816);
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @angular/core */ 3184);





var PagesRoutingModule = /*#__PURE__*/(0,_Users_smartcommunitylab_Documents_work_projects_dslab_playgo_mobile_playgo_mobile_node_modules_babel_runtime_helpers_esm_createClass_js__WEBPACK_IMPORTED_MODULE_0__["default"])(function PagesRoutingModule() {
  (0,_Users_smartcommunitylab_Documents_work_projects_dslab_playgo_mobile_playgo_mobile_node_modules_babel_runtime_helpers_esm_classCallCheck_js__WEBPACK_IMPORTED_MODULE_1__["default"])(this, PagesRoutingModule);
});

PagesRoutingModule.ɵfac = function PagesRoutingModule_Factory(t) {
  return new (t || PagesRoutingModule)();
};

PagesRoutingModule.ɵmod = /*@__PURE__*/_angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵdefineNgModule"]({
  type: PagesRoutingModule
});
PagesRoutingModule.ɵinj = /*@__PURE__*/_angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵdefineInjector"]({
  imports: [[_angular_router__WEBPACK_IMPORTED_MODULE_3__.RouterModule.forChild([{
    path: '',
    loadChildren: function loadChildren() {
      return Promise.all(/*! import() */[__webpack_require__.e("common"), __webpack_require__.e("src_app_pages_tabs-container_tabs_module_ts")]).then(__webpack_require__.bind(__webpack_require__, /*! ./tabs-container/tabs.module */ 54459)).then(function (m) {
        return m.TabsPageModule;
      });
    }
  }, {
    path: 'registration',
    loadChildren: function loadChildren() {
      return Promise.all(/*! import() */[__webpack_require__.e("common"), __webpack_require__.e("src_app_pages_registration_registration_module_ts")]).then(__webpack_require__.bind(__webpack_require__, /*! ./registration/registration.module */ 50015)).then(function (m) {
        return m.RegistrationPageModule;
      });
    }
  }, {
    path: 'notifications',
    loadChildren: function loadChildren() {
      return __webpack_require__.e(/*! import() */ "src_app_pages_notifications_notifications_module_ts").then(__webpack_require__.bind(__webpack_require__, /*! ./notifications/notifications.module */ 44558)).then(function (m) {
        return m.NotificationsPageModule;
      });
    }
  }, {
    path: 'stats/:id',
    loadChildren: function loadChildren() {
      return Promise.all(/*! import() */[__webpack_require__.e("default-node_modules_chart_js_dist_chart_esm_js"), __webpack_require__.e("src_app_pages_stats_stats_module_ts")]).then(__webpack_require__.bind(__webpack_require__, /*! ./stats/stats.module */ 6636)).then(function (m) {
        return m.StatsPageModule;
      });
    }
  }, {
    path: 'blacklist/:id',
    loadChildren: function loadChildren() {
      return __webpack_require__.e(/*! import() */ "src_app_pages_blacklist_blacklist_module_ts").then(__webpack_require__.bind(__webpack_require__, /*! ./blacklist/blacklist.module */ 60683)).then(function (m) {
        return m.BlacklistPageModule;
      });
    }
  }, {
    path: 'badges/:id',
    loadChildren: function loadChildren() {
      return __webpack_require__.e(/*! import() */ "src_app_pages_badges_badges_module_ts").then(__webpack_require__.bind(__webpack_require__, /*! ./badges/badges.module */ 11579)).then(function (m) {
        return m.BadgesPageModule;
      });
    }
  }, {
    path: 'user-profile/:id/:nickname',
    loadChildren: function loadChildren() {
      return Promise.all(/*! import() */[__webpack_require__.e("common"), __webpack_require__.e("src_app_pages_user-profile_user-profile_module_ts")]).then(__webpack_require__.bind(__webpack_require__, /*! ./user-profile/user-profile.module */ 71749)).then(function (m) {
        return m.UserProfilePageModule;
      });
    }
  }])]]
});

(function () {
  (typeof ngJitMode === "undefined" || ngJitMode) && _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵsetNgModuleScope"](PagesRoutingModule, {
    imports: [_angular_router__WEBPACK_IMPORTED_MODULE_3__.RouterModule]
  });
})();

/***/ })

}]);
//# sourceMappingURL=src_app_pages_pages-routing_module_ts.js.map