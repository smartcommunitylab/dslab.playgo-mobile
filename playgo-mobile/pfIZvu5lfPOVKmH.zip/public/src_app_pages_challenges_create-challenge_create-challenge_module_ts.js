"use strict";
(self["webpackChunkapp"] = self["webpackChunkapp"] || []).push([["src_app_pages_challenges_create-challenge_create-challenge_module_ts"],{

/***/ 38399:
/*!****************************************************************************************************!*\
  !*** ./src/app/pages/challenges/create-challenge/challenge-preview/challenge-preview.component.ts ***!
  \****************************************************************************************************/
/***/ (function(__unused_webpack_module, __webpack_exports__, __webpack_require__) {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "ChallengePreviewComponent": function() { return /* binding */ ChallengePreviewComponent; }
/* harmony export */ });
/* harmony import */ var _Users_smartcommunitylab_Documents_work_projects_dslab_playgo_mobile_playgo_mobile_node_modules_babel_runtime_helpers_esm_classCallCheck_js__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./node_modules/@babel/runtime/helpers/esm/classCallCheck.js */ 78069);
/* harmony import */ var _Users_smartcommunitylab_Documents_work_projects_dslab_playgo_mobile_playgo_mobile_node_modules_babel_runtime_helpers_esm_createClass_js__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ./node_modules/@babel/runtime/helpers/esm/createClass.js */ 48047);
/* harmony import */ var rxjs__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! rxjs */ 50635);
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! @angular/core */ 3184);
/* harmony import */ var src_app_core_shared_services_user_service__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! src/app/core/shared/services/user.service */ 50749);
/* harmony import */ var _angular_common__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! @angular/common */ 36362);
/* harmony import */ var _ionic_angular__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(/*! @ionic/angular */ 93819);
/* harmony import */ var _core_shared_pipes_languageMap_pipe__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! ../../../../core/shared/pipes/languageMap.pipe */ 73088);
/* harmony import */ var _ngx_translate_core__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(/*! @ngx-translate/core */ 87514);










function ChallengePreviewComponent_ng_container_0_Template(rf, ctx) {
  if (rf & 1) {
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵelementContainerStart"](0);
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵelementStart"](1, "ion-grid")(2, "ion-row", 1)(3, "ion-col", 2);
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵtext"](4);
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵpipe"](5, "languageMap");
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵelementEnd"]()();
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵelementStart"](6, "ion-row", 3)(7, "ion-col", 4)(8, "ion-avatar");
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵelement"](9, "img", 5);
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵpipe"](10, "async");
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵelementEnd"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵtext"](11);
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵpipe"](12, "translate");
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵelementEnd"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵelementStart"](13, "ion-col", 4)(14, "ion-avatar");
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵelement"](15, "img", 5);
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵelementEnd"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵtext"](16);
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵelementEnd"]()();
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵelementStart"](17, "ion-row", 1)(18, "ion-col", 6);
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵtext"](19);
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵpipe"](20, "translate");
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵelementEnd"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵelementStart"](21, "ion-col", 7);
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵtext"](22);
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵpipe"](23, "translate");
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵelementEnd"]()();
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵelementStart"](24, "ion-row")(25, "ion-col", 6);
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵtext"](26);
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵpipe"](27, "translate");
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵelementEnd"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵelementStart"](28, "ion-col", 7);
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵtext"](29);
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵpipe"](30, "translate");
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵelementEnd"]()();
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵelementStart"](31, "ion-row")(32, "ion-col", 6);
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵtext"](33);
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵpipe"](34, "translate");
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵelementEnd"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵelementStart"](35, "ion-col", 7);
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵtext"](36);
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵelementEnd"]()();
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵelementStart"](37, "ion-row", 1)(38, "ion-col", 8);
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵtext"](39);
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵpipe"](40, "languageMap");
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵelementEnd"]()()();
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵelementContainerEnd"]();
  }

  if (rf & 2) {
    var ctx_r0 = _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵnextContext"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵadvance"](4);
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵtextInterpolate"](_angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵpipeBind1"](5, 12, ctx_r0.preview.description));
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵadvance"](5);
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵproperty"]("src", _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵpipeBind1"](10, 14, ctx_r0.avatarUrl$), _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵsanitizeUrl"]);
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵadvance"](2);
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵtextInterpolate1"](" ", _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵpipeBind1"](12, 16, "challenges.create.preview.you"), " ");
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵadvance"](4);
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵproperty"]("src", ctx_r0.challengeable.avatarUrl, _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵsanitizeUrl"]);
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵadvance"](1);
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵtextInterpolate1"](" ", ctx_r0.challengeable.nickname, " ");
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵadvance"](3);
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵtextInterpolate"](_angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵpipeBind1"](20, 18, "challenges.create.preview.model"));
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵadvance"](3);
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵtextInterpolate"](_angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵpipeBind1"](23, 20, "challenges.challenge_model.name." + ctx_r0.challengeModelName));
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵadvance"](4);
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵtextInterpolate"](_angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵpipeBind1"](27, 22, "challenges.create.preview.mean"));
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵadvance"](3);
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵtextInterpolate"](_angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵpipeBind1"](30, 24, "challenges.challenge_mean.label." + ctx_r0.pointConcept));
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵadvance"](4);
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵtextInterpolate"](_angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵpipeBind1"](34, 26, "challenges.create.preview.challengeable"));
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵadvance"](3);
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵtextInterpolate"](ctx_r0.challengeable.nickname);
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵadvance"](3);
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵtextInterpolate"](_angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵpipeBind1"](40, 28, ctx_r0.preview.longDescription));
  }
}

var ChallengePreviewComponent = /*#__PURE__*/function () {
  function ChallengePreviewComponent(userService) {
    (0,_Users_smartcommunitylab_Documents_work_projects_dslab_playgo_mobile_playgo_mobile_node_modules_babel_runtime_helpers_esm_classCallCheck_js__WEBPACK_IMPORTED_MODULE_0__["default"])(this, ChallengePreviewComponent);

    this.userService = userService;
    this.avatarUrl$ = this.userService.userProfile$.pipe((0,rxjs__WEBPACK_IMPORTED_MODULE_5__.map)(function (profile) {
      return profile.avatar.avatarSmallUrl;
    }));
  }

  (0,_Users_smartcommunitylab_Documents_work_projects_dslab_playgo_mobile_playgo_mobile_node_modules_babel_runtime_helpers_esm_createClass_js__WEBPACK_IMPORTED_MODULE_1__["default"])(ChallengePreviewComponent, [{
    key: "ngOnInit",
    value: function ngOnInit() {}
  }]);

  return ChallengePreviewComponent;
}();

ChallengePreviewComponent.ɵfac = function ChallengePreviewComponent_Factory(t) {
  return new (t || ChallengePreviewComponent)(_angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵdirectiveInject"](src_app_core_shared_services_user_service__WEBPACK_IMPORTED_MODULE_2__.UserService));
};

ChallengePreviewComponent.ɵcmp = /*@__PURE__*/_angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵdefineComponent"]({
  type: ChallengePreviewComponent,
  selectors: [["app-challenge-preview"]],
  inputs: {
    challengeModelName: "challengeModelName",
    pointConcept: "pointConcept",
    challengeable: "challengeable",
    preview: "preview"
  },
  decls: 1,
  vars: 1,
  consts: [[4, "ngIf"], [1, "ion-margin-top"], [1, "text-bold", "ion-text-center"], [1, "ion-justify-content-around", "ion-margin-top"], ["size", "auto", 1, "ion-text-center"], [3, "src"], [1, "ion-text-left"], [1, "ion-text-right", "text-bold"], [1, "text-italic"]],
  template: function ChallengePreviewComponent_Template(rf, ctx) {
    if (rf & 1) {
      _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵtemplate"](0, ChallengePreviewComponent_ng_container_0_Template, 41, 30, "ng-container", 0);
    }

    if (rf & 2) {
      _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵproperty"]("ngIf", ctx.preview);
    }
  },
  directives: [_angular_common__WEBPACK_IMPORTED_MODULE_6__.NgIf, _ionic_angular__WEBPACK_IMPORTED_MODULE_7__.IonGrid, _ionic_angular__WEBPACK_IMPORTED_MODULE_7__.IonRow, _ionic_angular__WEBPACK_IMPORTED_MODULE_7__.IonCol, _ionic_angular__WEBPACK_IMPORTED_MODULE_7__.IonAvatar],
  pipes: [_core_shared_pipes_languageMap_pipe__WEBPACK_IMPORTED_MODULE_3__.LanguageMapPipe, _angular_common__WEBPACK_IMPORTED_MODULE_6__.AsyncPipe, _ngx_translate_core__WEBPACK_IMPORTED_MODULE_8__.TranslatePipe],
  styles: ["\n/*# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbXSwibmFtZXMiOltdLCJtYXBwaW5ncyI6IiIsImZpbGUiOiJjaGFsbGVuZ2UtcHJldmlldy5jb21wb25lbnQuc2NzcyJ9 */"]
});

/***/ }),

/***/ 80478:
/*!**************************************************************************************!*\
  !*** ./src/app/pages/challenges/create-challenge/create-challenge-routing.module.ts ***!
  \**************************************************************************************/
/***/ (function(__unused_webpack_module, __webpack_exports__, __webpack_require__) {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "CreateChallengePageRoutingModule": function() { return /* binding */ CreateChallengePageRoutingModule; }
/* harmony export */ });
/* harmony import */ var _Users_smartcommunitylab_Documents_work_projects_dslab_playgo_mobile_playgo_mobile_node_modules_babel_runtime_helpers_esm_createClass_js__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./node_modules/@babel/runtime/helpers/esm/createClass.js */ 48047);
/* harmony import */ var _Users_smartcommunitylab_Documents_work_projects_dslab_playgo_mobile_playgo_mobile_node_modules_babel_runtime_helpers_esm_classCallCheck_js__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ./node_modules/@babel/runtime/helpers/esm/classCallCheck.js */ 78069);
/* harmony import */ var _angular_router__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! @angular/router */ 52816);
/* harmony import */ var _create_challenge_page__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! ./create-challenge.page */ 24756);
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @angular/core */ 3184);






var routes = [{
  path: '',
  component: _create_challenge_page__WEBPACK_IMPORTED_MODULE_2__.CreateChallengePage,
  data: {
    title: 'challenges.create.title'
  }
}];
var CreateChallengePageRoutingModule = /*#__PURE__*/(0,_Users_smartcommunitylab_Documents_work_projects_dslab_playgo_mobile_playgo_mobile_node_modules_babel_runtime_helpers_esm_createClass_js__WEBPACK_IMPORTED_MODULE_0__["default"])(function CreateChallengePageRoutingModule() {
  (0,_Users_smartcommunitylab_Documents_work_projects_dslab_playgo_mobile_playgo_mobile_node_modules_babel_runtime_helpers_esm_classCallCheck_js__WEBPACK_IMPORTED_MODULE_1__["default"])(this, CreateChallengePageRoutingModule);
});

CreateChallengePageRoutingModule.ɵfac = function CreateChallengePageRoutingModule_Factory(t) {
  return new (t || CreateChallengePageRoutingModule)();
};

CreateChallengePageRoutingModule.ɵmod = /*@__PURE__*/_angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵdefineNgModule"]({
  type: CreateChallengePageRoutingModule
});
CreateChallengePageRoutingModule.ɵinj = /*@__PURE__*/_angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵdefineInjector"]({
  imports: [[_angular_router__WEBPACK_IMPORTED_MODULE_4__.RouterModule.forChild(routes)], _angular_router__WEBPACK_IMPORTED_MODULE_4__.RouterModule]
});

(function () {
  (typeof ngJitMode === "undefined" || ngJitMode) && _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵsetNgModuleScope"](CreateChallengePageRoutingModule, {
    imports: [_angular_router__WEBPACK_IMPORTED_MODULE_4__.RouterModule],
    exports: [_angular_router__WEBPACK_IMPORTED_MODULE_4__.RouterModule]
  });
})();

/***/ }),

/***/ 22423:
/*!******************************************************************************!*\
  !*** ./src/app/pages/challenges/create-challenge/create-challenge.module.ts ***!
  \******************************************************************************/
/***/ (function(__unused_webpack_module, __webpack_exports__, __webpack_require__) {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "CreateChallengePageModule": function() { return /* binding */ CreateChallengePageModule; }
/* harmony export */ });
/* harmony import */ var _Users_smartcommunitylab_Documents_work_projects_dslab_playgo_mobile_playgo_mobile_node_modules_babel_runtime_helpers_esm_createClass_js__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./node_modules/@babel/runtime/helpers/esm/createClass.js */ 48047);
/* harmony import */ var _Users_smartcommunitylab_Documents_work_projects_dslab_playgo_mobile_playgo_mobile_node_modules_babel_runtime_helpers_esm_classCallCheck_js__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ./node_modules/@babel/runtime/helpers/esm/classCallCheck.js */ 78069);
/* harmony import */ var _create_challenge_routing_module__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! ./create-challenge-routing.module */ 80478);
/* harmony import */ var _create_challenge_page__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! ./create-challenge.page */ 24756);
/* harmony import */ var src_app_core_shared_shared_module__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! src/app/core/shared/shared.module */ 97205);
/* harmony import */ var _wizard_wizard_component__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! ./wizard/wizard.component */ 1359);
/* harmony import */ var _wizard_wizard_step_wizard_step_component__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! ./wizard/wizard-step/wizard-step.component */ 68774);
/* harmony import */ var _select_challenge_model_select_challenge_model_component__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(/*! ./select-challenge-model/select-challenge-model.component */ 7776);
/* harmony import */ var _select_challenge_mean_select_challenge_mean_component__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(/*! ./select-challenge-mean/select-challenge-mean.component */ 64595);
/* harmony import */ var _select_challengeable_select_challengeable_component__WEBPACK_IMPORTED_MODULE_9__ = __webpack_require__(/*! ./select-challengeable/select-challengeable.component */ 56747);
/* harmony import */ var _challenge_preview_challenge_preview_component__WEBPACK_IMPORTED_MODULE_10__ = __webpack_require__(/*! ./challenge-preview/challenge-preview.component */ 38399);
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_13__ = __webpack_require__(/*! @angular/core */ 3184);
/* harmony import */ var _ionic_angular__WEBPACK_IMPORTED_MODULE_14__ = __webpack_require__(/*! @ionic/angular */ 93819);
/* harmony import */ var _core_shared_layout_header_header_directive__WEBPACK_IMPORTED_MODULE_11__ = __webpack_require__(/*! ../../../core/shared/layout/header/header.directive */ 34161);
/* harmony import */ var _angular_common__WEBPACK_IMPORTED_MODULE_15__ = __webpack_require__(/*! @angular/common */ 36362);
/* harmony import */ var _core_shared_pipes_languageMap_pipe__WEBPACK_IMPORTED_MODULE_12__ = __webpack_require__(/*! ../../../core/shared/pipes/languageMap.pipe */ 73088);
/* harmony import */ var _ngx_translate_core__WEBPACK_IMPORTED_MODULE_16__ = __webpack_require__(/*! @ngx-translate/core */ 87514);

















var CreateChallengePageModule = /*#__PURE__*/(0,_Users_smartcommunitylab_Documents_work_projects_dslab_playgo_mobile_playgo_mobile_node_modules_babel_runtime_helpers_esm_createClass_js__WEBPACK_IMPORTED_MODULE_0__["default"])(function CreateChallengePageModule() {
  (0,_Users_smartcommunitylab_Documents_work_projects_dslab_playgo_mobile_playgo_mobile_node_modules_babel_runtime_helpers_esm_classCallCheck_js__WEBPACK_IMPORTED_MODULE_1__["default"])(this, CreateChallengePageModule);
});

CreateChallengePageModule.ɵfac = function CreateChallengePageModule_Factory(t) {
  return new (t || CreateChallengePageModule)();
};

CreateChallengePageModule.ɵmod = /*@__PURE__*/_angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵdefineNgModule"]({
  type: CreateChallengePageModule
});
CreateChallengePageModule.ɵinj = /*@__PURE__*/_angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵdefineInjector"]({
  imports: [[src_app_core_shared_shared_module__WEBPACK_IMPORTED_MODULE_4__.PlayGoSharedModule, _create_challenge_routing_module__WEBPACK_IMPORTED_MODULE_2__.CreateChallengePageRoutingModule]]
});

(function () {
  (typeof ngJitMode === "undefined" || ngJitMode) && _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵsetNgModuleScope"](CreateChallengePageModule, {
    declarations: [_create_challenge_page__WEBPACK_IMPORTED_MODULE_3__.CreateChallengePage, _wizard_wizard_component__WEBPACK_IMPORTED_MODULE_5__.WizardComponent, _wizard_wizard_step_wizard_step_component__WEBPACK_IMPORTED_MODULE_6__.WizardStepComponent, _select_challenge_model_select_challenge_model_component__WEBPACK_IMPORTED_MODULE_7__.SelectChallengeModelComponent, _select_challenge_mean_select_challenge_mean_component__WEBPACK_IMPORTED_MODULE_8__.SelectChallengeMeanComponent, _select_challengeable_select_challengeable_component__WEBPACK_IMPORTED_MODULE_9__.SelectChallengeableComponent, _challenge_preview_challenge_preview_component__WEBPACK_IMPORTED_MODULE_10__.ChallengePreviewComponent],
    imports: [src_app_core_shared_shared_module__WEBPACK_IMPORTED_MODULE_4__.PlayGoSharedModule, _create_challenge_routing_module__WEBPACK_IMPORTED_MODULE_2__.CreateChallengePageRoutingModule]
  });
})();

_angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵsetComponentScope"](_create_challenge_page__WEBPACK_IMPORTED_MODULE_3__.CreateChallengePage, [_ionic_angular__WEBPACK_IMPORTED_MODULE_14__.IonHeader, _core_shared_layout_header_header_directive__WEBPACK_IMPORTED_MODULE_11__.HeaderDirective, _ionic_angular__WEBPACK_IMPORTED_MODULE_14__.IonContent, _angular_common__WEBPACK_IMPORTED_MODULE_15__.NgIf, _wizard_wizard_component__WEBPACK_IMPORTED_MODULE_5__.WizardComponent, _angular_common__WEBPACK_IMPORTED_MODULE_15__.NgClass, _wizard_wizard_step_wizard_step_component__WEBPACK_IMPORTED_MODULE_6__.WizardStepComponent, _select_challenge_model_select_challenge_model_component__WEBPACK_IMPORTED_MODULE_7__.SelectChallengeModelComponent, _select_challenge_mean_select_challenge_mean_component__WEBPACK_IMPORTED_MODULE_8__.SelectChallengeMeanComponent, _select_challengeable_select_challengeable_component__WEBPACK_IMPORTED_MODULE_9__.SelectChallengeableComponent, _challenge_preview_challenge_preview_component__WEBPACK_IMPORTED_MODULE_10__.ChallengePreviewComponent], [_core_shared_pipes_languageMap_pipe__WEBPACK_IMPORTED_MODULE_12__.LanguageMapPipe, _ngx_translate_core__WEBPACK_IMPORTED_MODULE_16__.TranslatePipe, _angular_common__WEBPACK_IMPORTED_MODULE_15__.AsyncPipe]);

/***/ }),

/***/ 24756:
/*!****************************************************************************!*\
  !*** ./src/app/pages/challenges/create-challenge/create-challenge.page.ts ***!
  \****************************************************************************/
/***/ (function(__unused_webpack_module, __webpack_exports__, __webpack_require__) {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "CreateChallengePage": function() { return /* binding */ CreateChallengePage; },
/* harmony export */   "POINT_CONCEPT_GAME": function() { return /* binding */ POINT_CONCEPT_GAME; },
/* harmony export */   "meanToPointConcept": function() { return /* binding */ meanToPointConcept; }
/* harmony export */ });
/* harmony import */ var _Users_smartcommunitylab_Documents_work_projects_dslab_playgo_mobile_playgo_mobile_node_modules_babel_runtime_helpers_esm_toConsumableArray_js__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./node_modules/@babel/runtime/helpers/esm/toConsumableArray.js */ 58277);
/* harmony import */ var _Users_smartcommunitylab_Documents_work_projects_dslab_playgo_mobile_playgo_mobile_node_modules_babel_runtime_helpers_esm_slicedToArray_js__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ./node_modules/@babel/runtime/helpers/esm/slicedToArray.js */ 10507);
/* harmony import */ var _Users_smartcommunitylab_Documents_work_projects_dslab_playgo_mobile_playgo_mobile_node_modules_babel_runtime_helpers_esm_classCallCheck_js__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! ./node_modules/@babel/runtime/helpers/esm/classCallCheck.js */ 78069);
/* harmony import */ var _Users_smartcommunitylab_Documents_work_projects_dslab_playgo_mobile_playgo_mobile_node_modules_babel_runtime_helpers_esm_createClass_js__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! ./node_modules/@babel/runtime/helpers/esm/createClass.js */ 48047);
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_22__ = __webpack_require__(/*! tslib */ 34929);
/* harmony import */ var lodash_es__WEBPACK_IMPORTED_MODULE_19__ = __webpack_require__(/*! lodash-es */ 97732);
/* harmony import */ var rxjs__WEBPACK_IMPORTED_MODULE_15__ = __webpack_require__(/*! rxjs */ 50635);
/* harmony import */ var rxjs__WEBPACK_IMPORTED_MODULE_16__ = __webpack_require__(/*! rxjs */ 32673);
/* harmony import */ var rxjs__WEBPACK_IMPORTED_MODULE_17__ = __webpack_require__(/*! rxjs */ 80228);
/* harmony import */ var rxjs__WEBPACK_IMPORTED_MODULE_18__ = __webpack_require__(/*! rxjs */ 26562);
/* harmony import */ var rxjs__WEBPACK_IMPORTED_MODULE_20__ = __webpack_require__(/*! rxjs */ 19337);
/* harmony import */ var rxjs__WEBPACK_IMPORTED_MODULE_21__ = __webpack_require__(/*! rxjs */ 89196);
/* harmony import */ var rxjs__WEBPACK_IMPORTED_MODULE_23__ = __webpack_require__(/*! rxjs */ 54363);
/* harmony import */ var src_app_core_shared_tracking_trip_model__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! src/app/core/shared/tracking/trip.model */ 49110);
/* harmony import */ var src_app_core_shared_utils__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! src/app/core/shared/utils */ 68647);
/* harmony import */ var _sent_invitation_modal_sent_invitation_modal__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! ./sent-invitation-modal/sent-invitation.modal */ 29212);
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_14__ = __webpack_require__(/*! @angular/core */ 3184);
/* harmony import */ var _angular_router__WEBPACK_IMPORTED_MODULE_24__ = __webpack_require__(/*! @angular/router */ 52816);
/* harmony import */ var src_app_core_shared_services_campaign_service__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(/*! src/app/core/shared/services/campaign.service */ 23645);
/* harmony import */ var src_app_core_api_generated_controllers_challengeController_service__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(/*! src/app/core/api/generated/controllers/challengeController.service */ 74458);
/* harmony import */ var src_app_core_shared_services_report_service__WEBPACK_IMPORTED_MODULE_9__ = __webpack_require__(/*! src/app/core/shared/services/report.service */ 93981);
/* harmony import */ var src_app_core_shared_services_error_service__WEBPACK_IMPORTED_MODULE_10__ = __webpack_require__(/*! src/app/core/shared/services/error.service */ 96204);
/* harmony import */ var src_app_core_shared_services_user_service__WEBPACK_IMPORTED_MODULE_11__ = __webpack_require__(/*! src/app/core/shared/services/user.service */ 50749);
/* harmony import */ var _ionic_angular__WEBPACK_IMPORTED_MODULE_25__ = __webpack_require__(/*! @ionic/angular */ 93819);
/* harmony import */ var src_app_core_shared_services_alert_service__WEBPACK_IMPORTED_MODULE_12__ = __webpack_require__(/*! src/app/core/shared/services/alert.service */ 46407);
/* harmony import */ var src_app_core_shared_services_challenge_service__WEBPACK_IMPORTED_MODULE_13__ = __webpack_require__(/*! src/app/core/shared/services/challenge.service */ 66324);





function _regeneratorRuntime() { "use strict"; /*! regenerator-runtime -- Copyright (c) 2014-present, Facebook, Inc. -- license (MIT): https://github.com/facebook/regenerator/blob/main/LICENSE */ _regeneratorRuntime = function _regeneratorRuntime() { return exports; }; var exports = {}, Op = Object.prototype, hasOwn = Op.hasOwnProperty, $Symbol = "function" == typeof Symbol ? Symbol : {}, iteratorSymbol = $Symbol.iterator || "@@iterator", asyncIteratorSymbol = $Symbol.asyncIterator || "@@asyncIterator", toStringTagSymbol = $Symbol.toStringTag || "@@toStringTag"; function define(obj, key, value) { return Object.defineProperty(obj, key, { value: value, enumerable: !0, configurable: !0, writable: !0 }), obj[key]; } try { define({}, ""); } catch (err) { define = function define(obj, key, value) { return obj[key] = value; }; } function wrap(innerFn, outerFn, self, tryLocsList) { var protoGenerator = outerFn && outerFn.prototype instanceof Generator ? outerFn : Generator, generator = Object.create(protoGenerator.prototype), context = new Context(tryLocsList || []); return generator._invoke = function (innerFn, self, context) { var state = "suspendedStart"; return function (method, arg) { if ("executing" === state) throw new Error("Generator is already running"); if ("completed" === state) { if ("throw" === method) throw arg; return doneResult(); } for (context.method = method, context.arg = arg;;) { var delegate = context.delegate; if (delegate) { var delegateResult = maybeInvokeDelegate(delegate, context); if (delegateResult) { if (delegateResult === ContinueSentinel) continue; return delegateResult; } } if ("next" === context.method) context.sent = context._sent = context.arg;else if ("throw" === context.method) { if ("suspendedStart" === state) throw state = "completed", context.arg; context.dispatchException(context.arg); } else "return" === context.method && context.abrupt("return", context.arg); state = "executing"; var record = tryCatch(innerFn, self, context); if ("normal" === record.type) { if (state = context.done ? "completed" : "suspendedYield", record.arg === ContinueSentinel) continue; return { value: record.arg, done: context.done }; } "throw" === record.type && (state = "completed", context.method = "throw", context.arg = record.arg); } }; }(innerFn, self, context), generator; } function tryCatch(fn, obj, arg) { try { return { type: "normal", arg: fn.call(obj, arg) }; } catch (err) { return { type: "throw", arg: err }; } } exports.wrap = wrap; var ContinueSentinel = {}; function Generator() {} function GeneratorFunction() {} function GeneratorFunctionPrototype() {} var IteratorPrototype = {}; define(IteratorPrototype, iteratorSymbol, function () { return this; }); var getProto = Object.getPrototypeOf, NativeIteratorPrototype = getProto && getProto(getProto(values([]))); NativeIteratorPrototype && NativeIteratorPrototype !== Op && hasOwn.call(NativeIteratorPrototype, iteratorSymbol) && (IteratorPrototype = NativeIteratorPrototype); var Gp = GeneratorFunctionPrototype.prototype = Generator.prototype = Object.create(IteratorPrototype); function defineIteratorMethods(prototype) { ["next", "throw", "return"].forEach(function (method) { define(prototype, method, function (arg) { return this._invoke(method, arg); }); }); } function AsyncIterator(generator, PromiseImpl) { function invoke(method, arg, resolve, reject) { var record = tryCatch(generator[method], generator, arg); if ("throw" !== record.type) { var result = record.arg, value = result.value; return value && "object" == typeof value && hasOwn.call(value, "__await") ? PromiseImpl.resolve(value.__await).then(function (value) { invoke("next", value, resolve, reject); }, function (err) { invoke("throw", err, resolve, reject); }) : PromiseImpl.resolve(value).then(function (unwrapped) { result.value = unwrapped, resolve(result); }, function (error) { return invoke("throw", error, resolve, reject); }); } reject(record.arg); } var previousPromise; this._invoke = function (method, arg) { function callInvokeWithMethodAndArg() { return new PromiseImpl(function (resolve, reject) { invoke(method, arg, resolve, reject); }); } return previousPromise = previousPromise ? previousPromise.then(callInvokeWithMethodAndArg, callInvokeWithMethodAndArg) : callInvokeWithMethodAndArg(); }; } function maybeInvokeDelegate(delegate, context) { var method = delegate.iterator[context.method]; if (undefined === method) { if (context.delegate = null, "throw" === context.method) { if (delegate.iterator.return && (context.method = "return", context.arg = undefined, maybeInvokeDelegate(delegate, context), "throw" === context.method)) return ContinueSentinel; context.method = "throw", context.arg = new TypeError("The iterator does not provide a 'throw' method"); } return ContinueSentinel; } var record = tryCatch(method, delegate.iterator, context.arg); if ("throw" === record.type) return context.method = "throw", context.arg = record.arg, context.delegate = null, ContinueSentinel; var info = record.arg; return info ? info.done ? (context[delegate.resultName] = info.value, context.next = delegate.nextLoc, "return" !== context.method && (context.method = "next", context.arg = undefined), context.delegate = null, ContinueSentinel) : info : (context.method = "throw", context.arg = new TypeError("iterator result is not an object"), context.delegate = null, ContinueSentinel); } function pushTryEntry(locs) { var entry = { tryLoc: locs[0] }; 1 in locs && (entry.catchLoc = locs[1]), 2 in locs && (entry.finallyLoc = locs[2], entry.afterLoc = locs[3]), this.tryEntries.push(entry); } function resetTryEntry(entry) { var record = entry.completion || {}; record.type = "normal", delete record.arg, entry.completion = record; } function Context(tryLocsList) { this.tryEntries = [{ tryLoc: "root" }], tryLocsList.forEach(pushTryEntry, this), this.reset(!0); } function values(iterable) { if (iterable) { var iteratorMethod = iterable[iteratorSymbol]; if (iteratorMethod) return iteratorMethod.call(iterable); if ("function" == typeof iterable.next) return iterable; if (!isNaN(iterable.length)) { var i = -1, next = function next() { for (; ++i < iterable.length;) { if (hasOwn.call(iterable, i)) return next.value = iterable[i], next.done = !1, next; } return next.value = undefined, next.done = !0, next; }; return next.next = next; } } return { next: doneResult }; } function doneResult() { return { value: undefined, done: !0 }; } return GeneratorFunction.prototype = GeneratorFunctionPrototype, define(Gp, "constructor", GeneratorFunctionPrototype), define(GeneratorFunctionPrototype, "constructor", GeneratorFunction), GeneratorFunction.displayName = define(GeneratorFunctionPrototype, toStringTagSymbol, "GeneratorFunction"), exports.isGeneratorFunction = function (genFun) { var ctor = "function" == typeof genFun && genFun.constructor; return !!ctor && (ctor === GeneratorFunction || "GeneratorFunction" === (ctor.displayName || ctor.name)); }, exports.mark = function (genFun) { return Object.setPrototypeOf ? Object.setPrototypeOf(genFun, GeneratorFunctionPrototype) : (genFun.__proto__ = GeneratorFunctionPrototype, define(genFun, toStringTagSymbol, "GeneratorFunction")), genFun.prototype = Object.create(Gp), genFun; }, exports.awrap = function (arg) { return { __await: arg }; }, defineIteratorMethods(AsyncIterator.prototype), define(AsyncIterator.prototype, asyncIteratorSymbol, function () { return this; }), exports.AsyncIterator = AsyncIterator, exports.async = function (innerFn, outerFn, self, tryLocsList, PromiseImpl) { void 0 === PromiseImpl && (PromiseImpl = Promise); var iter = new AsyncIterator(wrap(innerFn, outerFn, self, tryLocsList), PromiseImpl); return exports.isGeneratorFunction(outerFn) ? iter : iter.next().then(function (result) { return result.done ? result.value : iter.next(); }); }, defineIteratorMethods(Gp), define(Gp, toStringTagSymbol, "Generator"), define(Gp, iteratorSymbol, function () { return this; }), define(Gp, "toString", function () { return "[object Generator]"; }), exports.keys = function (object) { var keys = []; for (var key in object) { keys.push(key); } return keys.reverse(), function next() { for (; keys.length;) { var key = keys.pop(); if (key in object) return next.value = key, next.done = !1, next; } return next.done = !0, next; }; }, exports.values = values, Context.prototype = { constructor: Context, reset: function reset(skipTempReset) { if (this.prev = 0, this.next = 0, this.sent = this._sent = undefined, this.done = !1, this.delegate = null, this.method = "next", this.arg = undefined, this.tryEntries.forEach(resetTryEntry), !skipTempReset) for (var name in this) { "t" === name.charAt(0) && hasOwn.call(this, name) && !isNaN(+name.slice(1)) && (this[name] = undefined); } }, stop: function stop() { this.done = !0; var rootRecord = this.tryEntries[0].completion; if ("throw" === rootRecord.type) throw rootRecord.arg; return this.rval; }, dispatchException: function dispatchException(exception) { if (this.done) throw exception; var context = this; function handle(loc, caught) { return record.type = "throw", record.arg = exception, context.next = loc, caught && (context.method = "next", context.arg = undefined), !!caught; } for (var i = this.tryEntries.length - 1; i >= 0; --i) { var entry = this.tryEntries[i], record = entry.completion; if ("root" === entry.tryLoc) return handle("end"); if (entry.tryLoc <= this.prev) { var hasCatch = hasOwn.call(entry, "catchLoc"), hasFinally = hasOwn.call(entry, "finallyLoc"); if (hasCatch && hasFinally) { if (this.prev < entry.catchLoc) return handle(entry.catchLoc, !0); if (this.prev < entry.finallyLoc) return handle(entry.finallyLoc); } else if (hasCatch) { if (this.prev < entry.catchLoc) return handle(entry.catchLoc, !0); } else { if (!hasFinally) throw new Error("try statement without catch or finally"); if (this.prev < entry.finallyLoc) return handle(entry.finallyLoc); } } } }, abrupt: function abrupt(type, arg) { for (var i = this.tryEntries.length - 1; i >= 0; --i) { var entry = this.tryEntries[i]; if (entry.tryLoc <= this.prev && hasOwn.call(entry, "finallyLoc") && this.prev < entry.finallyLoc) { var finallyEntry = entry; break; } } finallyEntry && ("break" === type || "continue" === type) && finallyEntry.tryLoc <= arg && arg <= finallyEntry.finallyLoc && (finallyEntry = null); var record = finallyEntry ? finallyEntry.completion : {}; return record.type = type, record.arg = arg, finallyEntry ? (this.method = "next", this.next = finallyEntry.finallyLoc, ContinueSentinel) : this.complete(record); }, complete: function complete(record, afterLoc) { if ("throw" === record.type) throw record.arg; return "break" === record.type || "continue" === record.type ? this.next = record.arg : "return" === record.type ? (this.rval = this.arg = record.arg, this.method = "return", this.next = "end") : "normal" === record.type && afterLoc && (this.next = afterLoc), ContinueSentinel; }, finish: function finish(finallyLoc) { for (var i = this.tryEntries.length - 1; i >= 0; --i) { var entry = this.tryEntries[i]; if (entry.finallyLoc === finallyLoc) return this.complete(entry.completion, entry.afterLoc), resetTryEntry(entry), ContinueSentinel; } }, catch: function _catch(tryLoc) { for (var i = this.tryEntries.length - 1; i >= 0; --i) { var entry = this.tryEntries[i]; if (entry.tryLoc === tryLoc) { var record = entry.completion; if ("throw" === record.type) { var thrown = record.arg; resetTryEntry(entry); } return thrown; } } throw new Error("illegal catch attempt"); }, delegateYield: function delegateYield(iterable, resultName, nextLoc) { return this.delegate = { iterator: values(iterable), resultName: resultName, nextLoc: nextLoc }, "next" === this.method && (this.arg = undefined), ContinueSentinel; } }, exports; }


















function CreateChallengePage_app_wizard_2_Template(rf, ctx) {
  if (rf & 1) {
    var _r3 = _angular_core__WEBPACK_IMPORTED_MODULE_14__["ɵɵgetCurrentView"]();

    _angular_core__WEBPACK_IMPORTED_MODULE_14__["ɵɵelementStart"](0, "app-wizard", 2);
    _angular_core__WEBPACK_IMPORTED_MODULE_14__["ɵɵlistener"]("finish", function CreateChallengePage_app_wizard_2_Template_app_wizard_finish_0_listener() {
      _angular_core__WEBPACK_IMPORTED_MODULE_14__["ɵɵrestoreView"](_r3);
      var ctx_r2 = _angular_core__WEBPACK_IMPORTED_MODULE_14__["ɵɵnextContext"]();
      return ctx_r2.onInvite();
    });
    _angular_core__WEBPACK_IMPORTED_MODULE_14__["ɵɵpipe"](1, "languageMap");
    _angular_core__WEBPACK_IMPORTED_MODULE_14__["ɵɵpipe"](2, "translate");
    _angular_core__WEBPACK_IMPORTED_MODULE_14__["ɵɵelementStart"](3, "app-wizard-step", 3);
    _angular_core__WEBPACK_IMPORTED_MODULE_14__["ɵɵpipe"](4, "async");
    _angular_core__WEBPACK_IMPORTED_MODULE_14__["ɵɵelementStart"](5, "div", 4)(6, "h2");
    _angular_core__WEBPACK_IMPORTED_MODULE_14__["ɵɵtext"](7);
    _angular_core__WEBPACK_IMPORTED_MODULE_14__["ɵɵpipe"](8, "translate");
    _angular_core__WEBPACK_IMPORTED_MODULE_14__["ɵɵelementEnd"]()();
    _angular_core__WEBPACK_IMPORTED_MODULE_14__["ɵɵelementStart"](9, "app-select-challenge-model", 5);
    _angular_core__WEBPACK_IMPORTED_MODULE_14__["ɵɵlistener"]("selectedModel", function CreateChallengePage_app_wizard_2_Template_app_select_challenge_model_selectedModel_9_listener($event) {
      _angular_core__WEBPACK_IMPORTED_MODULE_14__["ɵɵrestoreView"](_r3);
      var ctx_r4 = _angular_core__WEBPACK_IMPORTED_MODULE_14__["ɵɵnextContext"]();
      return ctx_r4.selectedModelName$.next($event);
    });
    _angular_core__WEBPACK_IMPORTED_MODULE_14__["ɵɵpipe"](10, "async");
    _angular_core__WEBPACK_IMPORTED_MODULE_14__["ɵɵelementEnd"]()();
    _angular_core__WEBPACK_IMPORTED_MODULE_14__["ɵɵelementStart"](11, "app-wizard-step", 6);
    _angular_core__WEBPACK_IMPORTED_MODULE_14__["ɵɵpipe"](12, "async");
    _angular_core__WEBPACK_IMPORTED_MODULE_14__["ɵɵelementStart"](13, "div", 4)(14, "h2");
    _angular_core__WEBPACK_IMPORTED_MODULE_14__["ɵɵtext"](15);
    _angular_core__WEBPACK_IMPORTED_MODULE_14__["ɵɵpipe"](16, "translate");
    _angular_core__WEBPACK_IMPORTED_MODULE_14__["ɵɵelementEnd"]()();
    _angular_core__WEBPACK_IMPORTED_MODULE_14__["ɵɵelementStart"](17, "app-select-challenge-mean", 7);
    _angular_core__WEBPACK_IMPORTED_MODULE_14__["ɵɵlistener"]("selectedMean", function CreateChallengePage_app_wizard_2_Template_app_select_challenge_mean_selectedMean_17_listener($event) {
      _angular_core__WEBPACK_IMPORTED_MODULE_14__["ɵɵrestoreView"](_r3);
      var ctx_r5 = _angular_core__WEBPACK_IMPORTED_MODULE_14__["ɵɵnextContext"]();
      return ctx_r5.selectedPointConcept$.next($event);
    });
    _angular_core__WEBPACK_IMPORTED_MODULE_14__["ɵɵpipe"](18, "async");
    _angular_core__WEBPACK_IMPORTED_MODULE_14__["ɵɵelementEnd"]()();
    _angular_core__WEBPACK_IMPORTED_MODULE_14__["ɵɵelementStart"](19, "app-wizard-step", 8);
    _angular_core__WEBPACK_IMPORTED_MODULE_14__["ɵɵpipe"](20, "async");
    _angular_core__WEBPACK_IMPORTED_MODULE_14__["ɵɵelementStart"](21, "app-select-challengeable", 9);
    _angular_core__WEBPACK_IMPORTED_MODULE_14__["ɵɵlistener"]("selectedChallengeable", function CreateChallengePage_app_wizard_2_Template_app_select_challengeable_selectedChallengeable_21_listener($event) {
      _angular_core__WEBPACK_IMPORTED_MODULE_14__["ɵɵrestoreView"](_r3);
      var ctx_r6 = _angular_core__WEBPACK_IMPORTED_MODULE_14__["ɵɵnextContext"]();
      return ctx_r6.selectedChallengeableId$.next($event);
    });
    _angular_core__WEBPACK_IMPORTED_MODULE_14__["ɵɵpipe"](22, "async");
    _angular_core__WEBPACK_IMPORTED_MODULE_14__["ɵɵelementEnd"]()();
    _angular_core__WEBPACK_IMPORTED_MODULE_14__["ɵɵelementStart"](23, "app-wizard-step", 10);
    _angular_core__WEBPACK_IMPORTED_MODULE_14__["ɵɵlistener"]("activated", function CreateChallengePage_app_wizard_2_Template_app_wizard_step_activated_23_listener() {
      _angular_core__WEBPACK_IMPORTED_MODULE_14__["ɵɵrestoreView"](_r3);
      var ctx_r7 = _angular_core__WEBPACK_IMPORTED_MODULE_14__["ɵɵnextContext"]();
      return ctx_r7.previewActive$.next();
    });
    _angular_core__WEBPACK_IMPORTED_MODULE_14__["ɵɵelement"](24, "app-challenge-preview", 11);
    _angular_core__WEBPACK_IMPORTED_MODULE_14__["ɵɵpipe"](25, "async");
    _angular_core__WEBPACK_IMPORTED_MODULE_14__["ɵɵpipe"](26, "async");
    _angular_core__WEBPACK_IMPORTED_MODULE_14__["ɵɵpipe"](27, "async");
    _angular_core__WEBPACK_IMPORTED_MODULE_14__["ɵɵpipe"](28, "async");
    _angular_core__WEBPACK_IMPORTED_MODULE_14__["ɵɵelementEnd"]()();
  }

  if (rf & 2) {
    var campaign_r1 = ctx.ngIf;
    var ctx_r0 = _angular_core__WEBPACK_IMPORTED_MODULE_14__["ɵɵnextContext"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_14__["ɵɵproperty"]("title", _angular_core__WEBPACK_IMPORTED_MODULE_14__["ɵɵpipeBind1"](1, 16, campaign_r1.name))("backButton", false)("ngClass", "ion-color-" + ctx_r0.getCampaignColor(campaign_r1))("finishButtonLabel", _angular_core__WEBPACK_IMPORTED_MODULE_14__["ɵɵpipeBind1"](2, 18, "challenges.create.invite"));
    _angular_core__WEBPACK_IMPORTED_MODULE_14__["ɵɵadvance"](3);
    _angular_core__WEBPACK_IMPORTED_MODULE_14__["ɵɵproperty"]("validForNextStep", _angular_core__WEBPACK_IMPORTED_MODULE_14__["ɵɵpipeBind1"](4, 20, ctx_r0.selectedModelName$) !== null);
    _angular_core__WEBPACK_IMPORTED_MODULE_14__["ɵɵadvance"](4);
    _angular_core__WEBPACK_IMPORTED_MODULE_14__["ɵɵtextInterpolate"](_angular_core__WEBPACK_IMPORTED_MODULE_14__["ɵɵpipeBind1"](8, 22, "challenges.challenge_model.title"));
    _angular_core__WEBPACK_IMPORTED_MODULE_14__["ɵɵadvance"](2);
    _angular_core__WEBPACK_IMPORTED_MODULE_14__["ɵɵproperty"]("availableModels", _angular_core__WEBPACK_IMPORTED_MODULE_14__["ɵɵpipeBind1"](10, 24, ctx_r0.challengeModels$));
    _angular_core__WEBPACK_IMPORTED_MODULE_14__["ɵɵadvance"](2);
    _angular_core__WEBPACK_IMPORTED_MODULE_14__["ɵɵproperty"]("validForNextStep", _angular_core__WEBPACK_IMPORTED_MODULE_14__["ɵɵpipeBind1"](12, 26, ctx_r0.selectedPointConcept$) !== null);
    _angular_core__WEBPACK_IMPORTED_MODULE_14__["ɵɵadvance"](4);
    _angular_core__WEBPACK_IMPORTED_MODULE_14__["ɵɵtextInterpolate"](_angular_core__WEBPACK_IMPORTED_MODULE_14__["ɵɵpipeBind1"](16, 28, "challenges.challenge_mean.title"));
    _angular_core__WEBPACK_IMPORTED_MODULE_14__["ɵɵadvance"](2);
    _angular_core__WEBPACK_IMPORTED_MODULE_14__["ɵɵproperty"]("availableMeans", _angular_core__WEBPACK_IMPORTED_MODULE_14__["ɵɵpipeBind1"](18, 30, ctx_r0.pointConcepts$));
    _angular_core__WEBPACK_IMPORTED_MODULE_14__["ɵɵadvance"](2);
    _angular_core__WEBPACK_IMPORTED_MODULE_14__["ɵɵproperty"]("validForNextStep", _angular_core__WEBPACK_IMPORTED_MODULE_14__["ɵɵpipeBind1"](20, 32, ctx_r0.selectedChallengeableId$) !== null);
    _angular_core__WEBPACK_IMPORTED_MODULE_14__["ɵɵadvance"](2);
    _angular_core__WEBPACK_IMPORTED_MODULE_14__["ɵɵproperty"]("availableChallengeables", _angular_core__WEBPACK_IMPORTED_MODULE_14__["ɵɵpipeBind1"](22, 34, ctx_r0.challengeables$));
    _angular_core__WEBPACK_IMPORTED_MODULE_14__["ɵɵadvance"](3);
    _angular_core__WEBPACK_IMPORTED_MODULE_14__["ɵɵproperty"]("challengeModelName", _angular_core__WEBPACK_IMPORTED_MODULE_14__["ɵɵpipeBind1"](25, 36, ctx_r0.selectedModelName$))("pointConcept", _angular_core__WEBPACK_IMPORTED_MODULE_14__["ɵɵpipeBind1"](26, 38, ctx_r0.selectedPointConcept$))("challengeable", _angular_core__WEBPACK_IMPORTED_MODULE_14__["ɵɵpipeBind1"](27, 40, ctx_r0.selectedChallengeable$))("preview", _angular_core__WEBPACK_IMPORTED_MODULE_14__["ɵɵpipeBind1"](28, 42, ctx_r0.preview$));
  }
}

var CreateChallengePage = /*#__PURE__*/function () {
  function CreateChallengePage(route, campaignService, challengeControllerService, reportService, errorService, userService, navController, alertService, challengeService, modalController) {
    var _this = this;

    (0,_Users_smartcommunitylab_Documents_work_projects_dslab_playgo_mobile_playgo_mobile_node_modules_babel_runtime_helpers_esm_classCallCheck_js__WEBPACK_IMPORTED_MODULE_2__["default"])(this, CreateChallengePage);

    this.route = route;
    this.campaignService = campaignService;
    this.challengeControllerService = challengeControllerService;
    this.reportService = reportService;
    this.errorService = errorService;
    this.userService = userService;
    this.navController = navController;
    this.alertService = alertService;
    this.challengeService = challengeService;
    this.modalController = modalController;
    this.campaignId$ = this.route.params.pipe((0,rxjs__WEBPACK_IMPORTED_MODULE_15__.map)(function (params) {
      return params.id;
    }));
    this.campaign$ = this.campaignId$.pipe((0,rxjs__WEBPACK_IMPORTED_MODULE_16__.switchMap)(function (campaignId) {
      return _this.campaignService.myCampaigns$.pipe((0,rxjs__WEBPACK_IMPORTED_MODULE_15__.map)(function (campaigns) {
        var _a;

        return (_a = campaigns.find(function (campaignContainer) {
          return campaignContainer.campaign.campaignId === campaignId;
        })) === null || _a === void 0 ? void 0 : _a.campaign;
      }));
    }));
    this.challengeModels$ = this.campaignId$.pipe((0,rxjs__WEBPACK_IMPORTED_MODULE_16__.switchMap)(function (campaignId) {
      return _this.challengeControllerService.getChallengesStatusUsingGET(campaignId).pipe(_this.errorService.getErrorHandler());
    }), (0,rxjs__WEBPACK_IMPORTED_MODULE_15__.map)(function (availableChallenges) {
      var all = [{
        challengeModelName: 'groupCompetitivePerformance',
        availableFromLevel: 13
      }, {
        challengeModelName: 'groupCompetitiveTime',
        availableFromLevel: 9
      }, {
        challengeModelName: 'groupCooperative',
        availableFromLevel: 0
      }];
      var allWithAvailableInfo = all.map(function (challengeModel) {
        var _a;

        var serverState = (_a = availableChallenges.find(function (eachServerChallengeMode) {
          return eachServerChallengeMode.modelName === challengeModel.challengeModelName;
        })) === null || _a === void 0 ? void 0 : _a.state;
        return Object.assign(Object.assign({}, challengeModel), {
          available: serverState === 'ACTIVE'
        });
      });
      return allWithAvailableInfo;
    }));
    this.selectedModelName$ = new rxjs__WEBPACK_IMPORTED_MODULE_17__.Subject();
    this.pointConcepts$ = (0,rxjs__WEBPACK_IMPORTED_MODULE_18__.combineLatest)([this.userService.userProfileMeans$, this.campaign$]).pipe((0,rxjs__WEBPACK_IMPORTED_MODULE_15__.map)(function (_ref) {
      var _ref2 = (0,_Users_smartcommunitylab_Documents_work_projects_dslab_playgo_mobile_playgo_mobile_node_modules_babel_runtime_helpers_esm_slicedToArray_js__WEBPACK_IMPORTED_MODULE_1__["default"])(_ref, 2),
          means = _ref2[0],
          campaign = _ref2[1];

      var gameInfo = {
        isMean: false,
        icon: _this.campaignService.getCampaignScoreIcon(campaign),
        name: POINT_CONCEPT_GAME,
        title: _this.campaignService.getCampaignScoreLabel(campaign)
      };
      var meansInfos = means.filter(function (mean) {
        return meanToPointConcept[mean];
      }).map(function (mean) {
        return {
          isMean: true,
          icon: src_app_core_shared_tracking_trip_model__WEBPACK_IMPORTED_MODULE_4__.transportTypeIcons[mean],
          name: meanToPointConcept[mean],
          title: src_app_core_shared_tracking_trip_model__WEBPACK_IMPORTED_MODULE_4__.transportTypeLabels[mean]
        };
      });
      return [gameInfo].concat((0,_Users_smartcommunitylab_Documents_work_projects_dslab_playgo_mobile_playgo_mobile_node_modules_babel_runtime_helpers_esm_toConsumableArray_js__WEBPACK_IMPORTED_MODULE_0__["default"])(meansInfos));
    }));
    this.selectedPointConcept$ = new rxjs__WEBPACK_IMPORTED_MODULE_17__.Subject();
    this.challengeables$ = this.campaignId$.pipe((0,rxjs__WEBPACK_IMPORTED_MODULE_16__.switchMap)(function (campaignId) {
      return _this.challengeControllerService.getChallengeablesUsingGET(campaignId).pipe(_this.errorService.getErrorHandler());
    }), (0,rxjs__WEBPACK_IMPORTED_MODULE_15__.map)(function (challengeables) {
      return challengeables.map(function (eachUser) {
        var _a, _b;

        return {
          id: eachUser.id,
          nickname: eachUser.nickname,
          avatarUrl: (_b = (_a = eachUser === null || eachUser === void 0 ? void 0 : eachUser.avatar) === null || _a === void 0 ? void 0 : _a.url) !== null && _b !== void 0 ? _b : 'assets/images/registration/generic_user.png'
        };
      });
    }));
    this.selectedChallengeableId$ = new rxjs__WEBPACK_IMPORTED_MODULE_17__.Subject();
    this.selectedChallengeable$ = (0,rxjs__WEBPACK_IMPORTED_MODULE_18__.combineLatest)([this.challengeables$, this.selectedChallengeableId$]).pipe((0,rxjs__WEBPACK_IMPORTED_MODULE_15__.map)(function (_ref3) {
      var _ref4 = (0,_Users_smartcommunitylab_Documents_work_projects_dslab_playgo_mobile_playgo_mobile_node_modules_babel_runtime_helpers_esm_slicedToArray_js__WEBPACK_IMPORTED_MODULE_1__["default"])(_ref3, 2),
          allChallengeables = _ref4[0],
          selectedId = _ref4[1];

      return (0,lodash_es__WEBPACK_IMPORTED_MODULE_19__["default"])(allChallengeables, {
        id: selectedId
      });
    }), (0,rxjs__WEBPACK_IMPORTED_MODULE_20__.tap)(function (chall) {
      return _this.nicknameOpponent = chall.nickname;
    }));
    this.previewActive$ = new rxjs__WEBPACK_IMPORTED_MODULE_17__.Subject();
    this.inviteParams$ = (0,rxjs__WEBPACK_IMPORTED_MODULE_18__.combineLatest)({
      campaignId: this.campaignId$,
      selectedChallengeableId: this.selectedChallengeableId$,
      selectedModelName: this.selectedModelName$,
      selectedPointConcept: this.selectedPointConcept$
    }).pipe((0,rxjs__WEBPACK_IMPORTED_MODULE_15__.map)(function (_ref5) {
      var campaignId = _ref5.campaignId,
          selectedChallengeableId = _ref5.selectedChallengeableId,
          selectedModelName = _ref5.selectedModelName,
          selectedPointConcept = _ref5.selectedPointConcept;
      return {
        campaignId: campaignId,
        body: {
          attendeeId: selectedChallengeableId,
          challengeModelName: selectedModelName,
          challengePointConcept: selectedPointConcept
        }
      };
    }), (0,rxjs__WEBPACK_IMPORTED_MODULE_21__.shareReplay)(1));
    this.preview$ = this.inviteParams$.pipe((0,rxjs__WEBPACK_IMPORTED_MODULE_16__.switchMap)(function (data) {
      return _this.previewActive$.pipe((0,rxjs__WEBPACK_IMPORTED_MODULE_15__.map)(function () {
        return data;
      }));
    }), (0,rxjs__WEBPACK_IMPORTED_MODULE_16__.switchMap)(function (inviteParams) {
      return _this.challengeControllerService.getGroupChallengePreviewUsingPOST(inviteParams).pipe(_this.errorService.getErrorHandler(), (0,src_app_core_shared_utils__WEBPACK_IMPORTED_MODULE_5__.castTo)());
    }));
    this.getCampaignColor = this.campaignService.getCampaignColor;
  }

  (0,_Users_smartcommunitylab_Documents_work_projects_dslab_playgo_mobile_playgo_mobile_node_modules_babel_runtime_helpers_esm_createClass_js__WEBPACK_IMPORTED_MODULE_3__["default"])(CreateChallengePage, [{
    key: "ngOnInit",
    value: function ngOnInit() {}
  }, {
    key: "onInvite",
    value: function onInvite() {
      return (0,tslib__WEBPACK_IMPORTED_MODULE_22__.__awaiter)(this, void 0, void 0, /*#__PURE__*/_regeneratorRuntime().mark(function _callee() {
        var inviteParams, invitation, modal;
        return _regeneratorRuntime().wrap(function _callee$(_context) {
          while (1) {
            switch (_context.prev = _context.next) {
              case 0:
                console.log('Invite!');
                _context.next = 3;
                return (0,rxjs__WEBPACK_IMPORTED_MODULE_23__.firstValueFrom)(this.inviteParams$);

              case 3:
                inviteParams = _context.sent;
                _context.prev = 4;
                _context.next = 7;
                return (0,rxjs__WEBPACK_IMPORTED_MODULE_23__.firstValueFrom)(this.challengeControllerService.sendInvitationUsingPOST(inviteParams));

              case 7:
                invitation = _context.sent;
                _context.next = 10;
                return this.modalController.create({
                  component: _sent_invitation_modal_sent_invitation_modal__WEBPACK_IMPORTED_MODULE_6__.SentInvitationlModalPage,
                  cssClass: 'modal-challenge',
                  componentProps: {
                    opponentName: this.nicknameOpponent
                  },
                  swipeToClose: true
                });

              case 10:
                modal = _context.sent;
                _context.next = 13;
                return modal.present();

              case 13:
                this.navController.navigateBack('pages/tabs/challenges');
                this.challengeService.challengesRefresher$.next(null);
                _context.next = 20;
                break;

              case 17:
                _context.prev = 17;
                _context.t0 = _context["catch"](4);
                this.errorService.handleError(_context.t0);

              case 20:
              case "end":
                return _context.stop();
            }
          }
        }, _callee, this, [[4, 17]]);
      }));
    }
  }]);

  return CreateChallengePage;
}();

CreateChallengePage.ɵfac = function CreateChallengePage_Factory(t) {
  return new (t || CreateChallengePage)(_angular_core__WEBPACK_IMPORTED_MODULE_14__["ɵɵdirectiveInject"](_angular_router__WEBPACK_IMPORTED_MODULE_24__.ActivatedRoute), _angular_core__WEBPACK_IMPORTED_MODULE_14__["ɵɵdirectiveInject"](src_app_core_shared_services_campaign_service__WEBPACK_IMPORTED_MODULE_7__.CampaignService), _angular_core__WEBPACK_IMPORTED_MODULE_14__["ɵɵdirectiveInject"](src_app_core_api_generated_controllers_challengeController_service__WEBPACK_IMPORTED_MODULE_8__.ChallengeControllerService), _angular_core__WEBPACK_IMPORTED_MODULE_14__["ɵɵdirectiveInject"](src_app_core_shared_services_report_service__WEBPACK_IMPORTED_MODULE_9__.ReportService), _angular_core__WEBPACK_IMPORTED_MODULE_14__["ɵɵdirectiveInject"](src_app_core_shared_services_error_service__WEBPACK_IMPORTED_MODULE_10__.ErrorService), _angular_core__WEBPACK_IMPORTED_MODULE_14__["ɵɵdirectiveInject"](src_app_core_shared_services_user_service__WEBPACK_IMPORTED_MODULE_11__.UserService), _angular_core__WEBPACK_IMPORTED_MODULE_14__["ɵɵdirectiveInject"](_ionic_angular__WEBPACK_IMPORTED_MODULE_25__.NavController), _angular_core__WEBPACK_IMPORTED_MODULE_14__["ɵɵdirectiveInject"](src_app_core_shared_services_alert_service__WEBPACK_IMPORTED_MODULE_12__.AlertService), _angular_core__WEBPACK_IMPORTED_MODULE_14__["ɵɵdirectiveInject"](src_app_core_shared_services_challenge_service__WEBPACK_IMPORTED_MODULE_13__.ChallengeService), _angular_core__WEBPACK_IMPORTED_MODULE_14__["ɵɵdirectiveInject"](_ionic_angular__WEBPACK_IMPORTED_MODULE_25__.ModalController));
};

CreateChallengePage.ɵcmp = /*@__PURE__*/_angular_core__WEBPACK_IMPORTED_MODULE_14__["ɵɵdefineComponent"]({
  type: CreateChallengePage,
  selectors: [["app-create-challenge"]],
  decls: 4,
  vars: 3,
  consts: [["appHeader", ""], [3, "title", "backButton", "ngClass", "finishButtonLabel", "finish", 4, "ngIf"], [3, "title", "backButton", "ngClass", "finishButtonLabel", "finish"], ["title", "challenges.create.choose_type", 3, "validForNextStep"], [1, "ion-text-center"], [3, "availableModels", "selectedModel"], ["title", "challenges.create.choose_metric", 3, "validForNextStep"], [3, "availableMeans", "selectedMean"], ["title", "challenges.create.choose_partner", 3, "validForNextStep"], [3, "availableChallengeables", "selectedChallengeable"], ["title", "challenges.create.activate", 3, "activated"], [3, "challengeModelName", "pointConcept", "challengeable", "preview"]],
  template: function CreateChallengePage_Template(rf, ctx) {
    if (rf & 1) {
      _angular_core__WEBPACK_IMPORTED_MODULE_14__["ɵɵelement"](0, "ion-header", 0);
      _angular_core__WEBPACK_IMPORTED_MODULE_14__["ɵɵelementStart"](1, "ion-content");
      _angular_core__WEBPACK_IMPORTED_MODULE_14__["ɵɵtemplate"](2, CreateChallengePage_app_wizard_2_Template, 29, 44, "app-wizard", 1);
      _angular_core__WEBPACK_IMPORTED_MODULE_14__["ɵɵpipe"](3, "async");
      _angular_core__WEBPACK_IMPORTED_MODULE_14__["ɵɵelementEnd"]();
    }

    if (rf & 2) {
      _angular_core__WEBPACK_IMPORTED_MODULE_14__["ɵɵadvance"](2);
      _angular_core__WEBPACK_IMPORTED_MODULE_14__["ɵɵproperty"]("ngIf", _angular_core__WEBPACK_IMPORTED_MODULE_14__["ɵɵpipeBind1"](3, 1, ctx.campaign$));
    }
  },
  styles: ["\n/*# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbXSwibmFtZXMiOltdLCJtYXBwaW5ncyI6IiIsImZpbGUiOiJjcmVhdGUtY2hhbGxlbmdlLnBhZ2Uuc2NzcyJ9 */"]
}); // | 'Boat_Km'
// | 'Bus_Km'
// | 'Car_Km'
// | 'Train_Km';

var POINT_CONCEPT_GAME = 'green leaves';
var meanToPointConcept = {
  bike: 'Bike_Km',
  walk: 'Walk_Km',
  boat: null,
  bus: null,
  car: null,
  train: null
};

/***/ }),

/***/ 64595:
/*!************************************************************************************************************!*\
  !*** ./src/app/pages/challenges/create-challenge/select-challenge-mean/select-challenge-mean.component.ts ***!
  \************************************************************************************************************/
/***/ (function(__unused_webpack_module, __webpack_exports__, __webpack_require__) {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "SelectChallengeMeanComponent": function() { return /* binding */ SelectChallengeMeanComponent; }
/* harmony export */ });
/* harmony import */ var _Users_smartcommunitylab_Documents_work_projects_dslab_playgo_mobile_playgo_mobile_node_modules_babel_runtime_helpers_esm_classCallCheck_js__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./node_modules/@babel/runtime/helpers/esm/classCallCheck.js */ 78069);
/* harmony import */ var _Users_smartcommunitylab_Documents_work_projects_dslab_playgo_mobile_playgo_mobile_node_modules_babel_runtime_helpers_esm_createClass_js__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ./node_modules/@babel/runtime/helpers/esm/createClass.js */ 48047);
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @angular/core */ 3184);
/* harmony import */ var _angular_common__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! @angular/common */ 36362);
/* harmony import */ var _core_shared_ui_icon_icon_component__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! ../../../../core/shared/ui/icon/icon.component */ 71888);
/* harmony import */ var _ngx_translate_core__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! @ngx-translate/core */ 87514);








function SelectChallengeMeanComponent_div_1_Template(rf, ctx) {
  if (rf & 1) {
    var _r3 = _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵgetCurrentView"]();

    _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵelementStart"](0, "div", 2);
    _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵlistener"]("click", function SelectChallengeMeanComponent_div_1_Template_div_click_0_listener() {
      var restoredCtx = _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵrestoreView"](_r3);
      var mean_r1 = restoredCtx.$implicit;
      var ctx_r2 = _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵnextContext"]();
      return ctx_r2.selectMean(mean_r1);
    });
    _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵpipe"](1, "translate");
    _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵelement"](2, "app-icon", 3);
    _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵelementEnd"]();
  }

  if (rf & 2) {
    var mean_r1 = ctx.$implicit;
    var ctx_r0 = _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵnextContext"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵclassProp"]("selected", mean_r1.name === ctx_r0.selectedMeanName);
    _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵpropertyInterpolate"]("title", _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵpipeBind1"](1, 4, mean_r1.title));
    _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵadvance"](2);
    _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵproperty"]("name", mean_r1.icon);
  }
}

var SelectChallengeMeanComponent = /*#__PURE__*/function () {
  function SelectChallengeMeanComponent() {
    (0,_Users_smartcommunitylab_Documents_work_projects_dslab_playgo_mobile_playgo_mobile_node_modules_babel_runtime_helpers_esm_classCallCheck_js__WEBPACK_IMPORTED_MODULE_0__["default"])(this, SelectChallengeMeanComponent);

    this.selectedMean = new _angular_core__WEBPACK_IMPORTED_MODULE_3__.EventEmitter();
  }

  (0,_Users_smartcommunitylab_Documents_work_projects_dslab_playgo_mobile_playgo_mobile_node_modules_babel_runtime_helpers_esm_createClass_js__WEBPACK_IMPORTED_MODULE_1__["default"])(SelectChallengeMeanComponent, [{
    key: "ngOnInit",
    value: function ngOnInit() {}
  }, {
    key: "selectMean",
    value: function selectMean(model) {
      this.selectedMeanName = model.name;
      this.selectedMean.emit(this.selectedMeanName);
    }
  }]);

  return SelectChallengeMeanComponent;
}();

SelectChallengeMeanComponent.ɵfac = function SelectChallengeMeanComponent_Factory(t) {
  return new (t || SelectChallengeMeanComponent)();
};

SelectChallengeMeanComponent.ɵcmp = /*@__PURE__*/_angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵdefineComponent"]({
  type: SelectChallengeMeanComponent,
  selectors: [["app-select-challenge-mean"]],
  inputs: {
    availableMeans: "availableMeans"
  },
  outputs: {
    selectedMean: "selectedMean"
  },
  decls: 2,
  vars: 1,
  consts: [[1, "wrapper"], ["class", "mean", 3, "selected", "title", "click", 4, "ngFor", "ngForOf"], [1, "mean", 3, "title", "click"], [3, "name"]],
  template: function SelectChallengeMeanComponent_Template(rf, ctx) {
    if (rf & 1) {
      _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵelementStart"](0, "div", 0);
      _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵtemplate"](1, SelectChallengeMeanComponent_div_1_Template, 3, 6, "div", 1);
      _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵelementEnd"]();
    }

    if (rf & 2) {
      _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵadvance"](1);
      _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵproperty"]("ngForOf", ctx.availableMeans);
    }
  },
  directives: [_angular_common__WEBPACK_IMPORTED_MODULE_4__.NgForOf, _core_shared_ui_icon_icon_component__WEBPACK_IMPORTED_MODULE_2__.IconComponent],
  pipes: [_ngx_translate_core__WEBPACK_IMPORTED_MODULE_5__.TranslatePipe],
  styles: [".wrapper[_ngcontent-%COMP%] {\n  display: grid;\n  grid-template-columns: repeat(3, 1fr);\n  grid-column-gap: 10px;\n  grid-row-gap: 10px;\n}\n\n.mean[_ngcontent-%COMP%] {\n  aspect-ratio: 1/1;\n  border: 2px solid var(--ion-color-base);\n  background-color: var(--ion-color-lighter);\n  border-radius: 10px;\n  display: flex;\n  align-items: center;\n  justify-content: center;\n}\n\n.mean.disabled[_ngcontent-%COMP%] {\n  border-color: gray;\n}\n\n.mean.selected[_ngcontent-%COMP%] {\n  border-width: 4px;\n}\n\n.mean[_ngcontent-%COMP%]   app-icon[_ngcontent-%COMP%] {\n  font-size: 56px;\n  line-height: 100%;\n}\n/*# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbInNlbGVjdC1jaGFsbGVuZ2UtbWVhbi5jb21wb25lbnQuc2NzcyJdLCJuYW1lcyI6W10sIm1hcHBpbmdzIjoiQUFBQTtFQUNFLGFBQUE7RUFDQSxxQ0FBQTtFQUNBLHFCQUFBO0VBQ0Esa0JBQUE7QUFDRjs7QUFDQTtFQUNFLGlCQUFBO0VBQ0EsdUNBQUE7RUFDQSwwQ0FBQTtFQUNBLG1CQUFBO0VBRUEsYUFBQTtFQUNBLG1CQUFBO0VBQ0EsdUJBQUE7QUFDRjs7QUFFRTtFQUNFLGtCQUFBO0FBQUo7O0FBRUU7RUFDRSxpQkFBQTtBQUFKOztBQUVFO0VBQ0UsZUFBQTtFQUVBLGlCQUFBO0FBREoiLCJmaWxlIjoic2VsZWN0LWNoYWxsZW5nZS1tZWFuLmNvbXBvbmVudC5zY3NzIiwic291cmNlc0NvbnRlbnQiOlsiLndyYXBwZXIge1xuICBkaXNwbGF5OiBncmlkO1xuICBncmlkLXRlbXBsYXRlLWNvbHVtbnM6IHJlcGVhdCgzLCAxZnIpO1xuICBncmlkLWNvbHVtbi1nYXA6IDEwcHg7XG4gIGdyaWQtcm93LWdhcDogMTBweDtcbn1cbi5tZWFuIHtcbiAgYXNwZWN0LXJhdGlvOiAxLzE7XG4gIGJvcmRlcjogMnB4IHNvbGlkIHZhcigtLWlvbi1jb2xvci1iYXNlKTtcbiAgYmFja2dyb3VuZC1jb2xvcjogdmFyKC0taW9uLWNvbG9yLWxpZ2h0ZXIpO1xuICBib3JkZXItcmFkaXVzOiAxMHB4O1xuXG4gIGRpc3BsYXk6IGZsZXg7XG4gIGFsaWduLWl0ZW1zOiBjZW50ZXI7XG4gIGp1c3RpZnktY29udGVudDogY2VudGVyO1xuXG4gIC8vIG1hcmdpbjogMTBweDtcbiAgJi5kaXNhYmxlZCB7XG4gICAgYm9yZGVyLWNvbG9yOiBncmF5O1xuICB9XG4gICYuc2VsZWN0ZWQge1xuICAgIGJvcmRlci13aWR0aDogNHB4O1xuICB9XG4gIGFwcC1pY29uIHtcbiAgICBmb250LXNpemU6IDU2cHg7XG4gICAgLy8gb3V0bGluZTogMXB4IHNvbGlkIHJlZDtcbiAgICBsaW5lLWhlaWdodDogMTAwJTtcbiAgfVxufVxuIl19 */"]
});

/***/ }),

/***/ 7776:
/*!**************************************************************************************************************!*\
  !*** ./src/app/pages/challenges/create-challenge/select-challenge-model/select-challenge-model.component.ts ***!
  \**************************************************************************************************************/
/***/ (function(__unused_webpack_module, __webpack_exports__, __webpack_require__) {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "SelectChallengeModelComponent": function() { return /* binding */ SelectChallengeModelComponent; }
/* harmony export */ });
/* harmony import */ var _Users_smartcommunitylab_Documents_work_projects_dslab_playgo_mobile_playgo_mobile_node_modules_babel_runtime_helpers_esm_classCallCheck_js__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./node_modules/@babel/runtime/helpers/esm/classCallCheck.js */ 78069);
/* harmony import */ var _Users_smartcommunitylab_Documents_work_projects_dslab_playgo_mobile_playgo_mobile_node_modules_babel_runtime_helpers_esm_createClass_js__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ./node_modules/@babel/runtime/helpers/esm/createClass.js */ 48047);
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @angular/core */ 3184);
/* harmony import */ var _ionic_angular__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! @ionic/angular */ 93819);
/* harmony import */ var _angular_common__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! @angular/common */ 36362);
/* harmony import */ var _core_shared_ui_icon_icon_component__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! ../../../../core/shared/ui/icon/icon.component */ 71888);
/* harmony import */ var _ngx_translate_core__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! @ngx-translate/core */ 87514);









function SelectChallengeModelComponent_ion_col_2_div_5_Template(rf, ctx) {
  if (rf & 1) {
    _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵelementStart"](0, "div")(1, "div");
    _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵelement"](2, "app-icon", 6);
    _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵelementEnd"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵelementStart"](3, "div", 7);
    _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵtext"](4);
    _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵpipe"](5, "translate");
    _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵelementEnd"]()();
  }

  if (rf & 2) {
    var eachModel_r1 = _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵnextContext"]().$implicit;
    _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵadvance"](2);
    _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵproperty"]("name", eachModel_r1.challengeModelName);
    _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵadvance"](2);
    _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵtextInterpolate1"](" ", _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵpipeBind1"](5, 2, "challenges.challenge_model.description." + eachModel_r1.challengeModelName), " ");
  }
}

var _c0 = function _c0(a0) {
  return {
    level: a0
  };
};

function SelectChallengeModelComponent_ion_col_2_div_6_Template(rf, ctx) {
  if (rf & 1) {
    _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵelementStart"](0, "div")(1, "div");
    _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵelement"](2, "app-icon", 8);
    _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵelementEnd"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵelementStart"](3, "div");
    _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵtext"](4);
    _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵpipe"](5, "translate");
    _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵelementEnd"]()();
  }

  if (rf & 2) {
    var eachModel_r1 = _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵnextContext"]().$implicit;
    _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵadvance"](4);
    _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵtextInterpolate1"](" ", _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵpipeBind2"](5, 1, "challenges.challenge_model.disabled_until_level", _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵpureFunction1"](4, _c0, eachModel_r1.availableFromLevel)), " ");
  }
}

function SelectChallengeModelComponent_ion_col_2_Template(rf, ctx) {
  if (rf & 1) {
    var _r7 = _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵgetCurrentView"]();

    _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵelementStart"](0, "ion-col", 2)(1, "div", 3);
    _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵlistener"]("click", function SelectChallengeModelComponent_ion_col_2_Template_div_click_1_listener() {
      var restoredCtx = _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵrestoreView"](_r7);
      var eachModel_r1 = restoredCtx.$implicit;
      var ctx_r6 = _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵnextContext"]();
      return ctx_r6.selectModel(eachModel_r1);
    });
    _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵelementStart"](2, "div", 4);
    _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵtext"](3);
    _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵpipe"](4, "translate");
    _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵelementEnd"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵtemplate"](5, SelectChallengeModelComponent_ion_col_2_div_5_Template, 6, 4, "div", 5);
    _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵtemplate"](6, SelectChallengeModelComponent_ion_col_2_div_6_Template, 6, 6, "div", 5);
    _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵelementEnd"]()();
  }

  if (rf & 2) {
    var eachModel_r1 = ctx.$implicit;
    var ctx_r0 = _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵnextContext"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵadvance"](1);
    _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵclassProp"]("disabled", !eachModel_r1.available)("selected", eachModel_r1.challengeModelName === ctx_r0.selectedModelName);
    _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵadvance"](2);
    _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵtextInterpolate1"](" ", _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵpipeBind1"](4, 7, "challenges.challenge_model.name." + eachModel_r1.challengeModelName), " ");
    _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵadvance"](2);
    _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵproperty"]("ngIf", eachModel_r1.available);
    _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵadvance"](1);
    _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵproperty"]("ngIf", !eachModel_r1.available);
  }
}

var SelectChallengeModelComponent = /*#__PURE__*/function () {
  function SelectChallengeModelComponent() {
    (0,_Users_smartcommunitylab_Documents_work_projects_dslab_playgo_mobile_playgo_mobile_node_modules_babel_runtime_helpers_esm_classCallCheck_js__WEBPACK_IMPORTED_MODULE_0__["default"])(this, SelectChallengeModelComponent);

    this.selectedModel = new _angular_core__WEBPACK_IMPORTED_MODULE_3__.EventEmitter();
  }

  (0,_Users_smartcommunitylab_Documents_work_projects_dslab_playgo_mobile_playgo_mobile_node_modules_babel_runtime_helpers_esm_createClass_js__WEBPACK_IMPORTED_MODULE_1__["default"])(SelectChallengeModelComponent, [{
    key: "ngOnInit",
    value: function ngOnInit() {}
  }, {
    key: "selectModel",
    value: function selectModel(model) {
      if (model.available) {
        this.selectedModelName = model.challengeModelName;
        this.selectedModel.emit(this.selectedModelName);
      }
    }
  }]);

  return SelectChallengeModelComponent;
}();

SelectChallengeModelComponent.ɵfac = function SelectChallengeModelComponent_Factory(t) {
  return new (t || SelectChallengeModelComponent)();
};

SelectChallengeModelComponent.ɵcmp = /*@__PURE__*/_angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵdefineComponent"]({
  type: SelectChallengeModelComponent,
  selectors: [["app-select-challenge-model"]],
  inputs: {
    availableModels: "availableModels"
  },
  outputs: {
    selectedModel: "selectedModel"
  },
  decls: 3,
  vars: 1,
  consts: [[1, "wrapper"], ["size", "6", "class", "ion-text-center", 4, "ngFor", "ngForOf"], ["size", "6", 1, "ion-text-center"], [1, "model", 3, "click"], [1, "text-bold"], [4, "ngIf"], [3, "name"], [1, "description"], ["name", "lock"]],
  template: function SelectChallengeModelComponent_Template(rf, ctx) {
    if (rf & 1) {
      _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵelementStart"](0, "ion-grid", 0)(1, "ion-row");
      _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵtemplate"](2, SelectChallengeModelComponent_ion_col_2_Template, 7, 9, "ion-col", 1);
      _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵelementEnd"]()();
    }

    if (rf & 2) {
      _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵadvance"](2);
      _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵproperty"]("ngForOf", ctx.availableModels);
    }
  },
  directives: [_ionic_angular__WEBPACK_IMPORTED_MODULE_4__.IonGrid, _ionic_angular__WEBPACK_IMPORTED_MODULE_4__.IonRow, _angular_common__WEBPACK_IMPORTED_MODULE_5__.NgForOf, _ionic_angular__WEBPACK_IMPORTED_MODULE_4__.IonCol, _angular_common__WEBPACK_IMPORTED_MODULE_5__.NgIf, _core_shared_ui_icon_icon_component__WEBPACK_IMPORTED_MODULE_2__.IconComponent],
  pipes: [_ngx_translate_core__WEBPACK_IMPORTED_MODULE_6__.TranslatePipe],
  styles: [".model[_ngcontent-%COMP%] {\n  border: 2px solid var(--ion-color-base);\n  background-color: var(--ion-color-lighter);\n  border-radius: 10px;\n  margin: 10px;\n}\n.model[_ngcontent-%COMP%]   .description[_ngcontent-%COMP%] {\n  font-size: 13px;\n  font-style: italic;\n}\n.model.disabled[_ngcontent-%COMP%] {\n  border-color: gray;\n}\n.model.selected[_ngcontent-%COMP%] {\n  border-width: 4px;\n}\n.model[_ngcontent-%COMP%]   app-icon[_ngcontent-%COMP%] {\n  font-size: 32px;\n}\n/*# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbInNlbGVjdC1jaGFsbGVuZ2UtbW9kZWwuY29tcG9uZW50LnNjc3MiXSwibmFtZXMiOltdLCJtYXBwaW5ncyI6IkFBQUE7RUFDRSx1Q0FBQTtFQUNBLDBDQUFBO0VBQ0EsbUJBQUE7RUFDQSxZQUFBO0FBQ0Y7QUFBRTtFQUNFLGVBQUE7RUFDQSxrQkFBQTtBQUVKO0FBQUU7RUFDRSxrQkFBQTtBQUVKO0FBQUU7RUFDRSxpQkFBQTtBQUVKO0FBQUU7RUFDRSxlQUFBO0FBRUoiLCJmaWxlIjoic2VsZWN0LWNoYWxsZW5nZS1tb2RlbC5jb21wb25lbnQuc2NzcyIsInNvdXJjZXNDb250ZW50IjpbIi5tb2RlbCB7XG4gIGJvcmRlcjogMnB4IHNvbGlkIHZhcigtLWlvbi1jb2xvci1iYXNlKTtcbiAgYmFja2dyb3VuZC1jb2xvcjogdmFyKC0taW9uLWNvbG9yLWxpZ2h0ZXIpO1xuICBib3JkZXItcmFkaXVzOiAxMHB4O1xuICBtYXJnaW46IDEwcHg7XG4gIC5kZXNjcmlwdGlvbiB7XG4gICAgZm9udC1zaXplOiAxM3B4O1xuICAgIGZvbnQtc3R5bGU6IGl0YWxpYztcbiAgfVxuICAmLmRpc2FibGVkIHtcbiAgICBib3JkZXItY29sb3I6IGdyYXk7XG4gIH1cbiAgJi5zZWxlY3RlZCB7XG4gICAgYm9yZGVyLXdpZHRoOiA0cHg7XG4gIH1cbiAgYXBwLWljb24ge1xuICAgIGZvbnQtc2l6ZTogMzJweDtcbiAgfVxufVxuIl19 */"]
});

/***/ }),

/***/ 56747:
/*!**********************************************************************************************************!*\
  !*** ./src/app/pages/challenges/create-challenge/select-challengeable/select-challengeable.component.ts ***!
  \**********************************************************************************************************/
/***/ (function(__unused_webpack_module, __webpack_exports__, __webpack_require__) {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "SelectChallengeableComponent": function() { return /* binding */ SelectChallengeableComponent; }
/* harmony export */ });
/* harmony import */ var _Users_smartcommunitylab_Documents_work_projects_dslab_playgo_mobile_playgo_mobile_node_modules_babel_runtime_helpers_esm_classCallCheck_js__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./node_modules/@babel/runtime/helpers/esm/classCallCheck.js */ 78069);
/* harmony import */ var _Users_smartcommunitylab_Documents_work_projects_dslab_playgo_mobile_playgo_mobile_node_modules_babel_runtime_helpers_esm_createClass_js__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ./node_modules/@babel/runtime/helpers/esm/createClass.js */ 48047);
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @angular/core */ 3184);
/* harmony import */ var _angular_common__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @angular/common */ 36362);
/* harmony import */ var _ionic_angular__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! @ionic/angular */ 93819);







function SelectChallengeableComponent_ion_item_0_ion_icon_5_Template(rf, ctx) {
  if (rf & 1) {
    _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵelement"](0, "ion-icon", 4);
  }
}

function SelectChallengeableComponent_ion_item_0_Template(rf, ctx) {
  if (rf & 1) {
    var _r4 = _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵgetCurrentView"]();

    _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵelementStart"](0, "ion-item", 1);
    _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵlistener"]("click", function SelectChallengeableComponent_ion_item_0_Template_ion_item_click_0_listener() {
      var restoredCtx = _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵrestoreView"](_r4);
      var user_r1 = restoredCtx.$implicit;
      var ctx_r3 = _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵnextContext"]();
      return ctx_r3.selectChallengeable(user_r1);
    });
    _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵelementStart"](1, "ion-avatar");
    _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵelement"](2, "img", 2);
    _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵelementEnd"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵelementStart"](3, "ion-label");
    _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵtext"](4);
    _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵelementEnd"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵtemplate"](5, SelectChallengeableComponent_ion_item_0_ion_icon_5_Template, 1, 0, "ion-icon", 3);
    _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵelementEnd"]();
  }

  if (rf & 2) {
    var user_r1 = ctx.$implicit;
    var ctx_r0 = _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵnextContext"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵclassProp"]("selected", user_r1.id === ctx_r0.selectedChallengeableId);
    _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵadvance"](2);
    _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵproperty"]("src", user_r1.avatarUrl, _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵsanitizeUrl"]);
    _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵadvance"](2);
    _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵtextInterpolate1"](" ", user_r1.nickname, " ");
    _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵadvance"](1);
    _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵproperty"]("ngIf", user_r1.id === ctx_r0.selectedChallengeableId);
  }
}

var SelectChallengeableComponent = /*#__PURE__*/function () {
  function SelectChallengeableComponent() {
    (0,_Users_smartcommunitylab_Documents_work_projects_dslab_playgo_mobile_playgo_mobile_node_modules_babel_runtime_helpers_esm_classCallCheck_js__WEBPACK_IMPORTED_MODULE_0__["default"])(this, SelectChallengeableComponent);

    this.selectedChallengeable = new _angular_core__WEBPACK_IMPORTED_MODULE_2__.EventEmitter();
  }

  (0,_Users_smartcommunitylab_Documents_work_projects_dslab_playgo_mobile_playgo_mobile_node_modules_babel_runtime_helpers_esm_createClass_js__WEBPACK_IMPORTED_MODULE_1__["default"])(SelectChallengeableComponent, [{
    key: "selectChallengeable",
    value: function selectChallengeable(challengeable) {
      this.selectedChallengeableId = challengeable.id;
      this.selectedChallengeable.emit(this.selectedChallengeableId);
    }
  }]);

  return SelectChallengeableComponent;
}();

SelectChallengeableComponent.ɵfac = function SelectChallengeableComponent_Factory(t) {
  return new (t || SelectChallengeableComponent)();
};

SelectChallengeableComponent.ɵcmp = /*@__PURE__*/_angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵdefineComponent"]({
  type: SelectChallengeableComponent,
  selectors: [["app-select-challengeable"]],
  inputs: {
    availableChallengeables: "availableChallengeables"
  },
  outputs: {
    selectedChallengeable: "selectedChallengeable"
  },
  decls: 1,
  vars: 1,
  consts: [["class", "user", 3, "selected", "click", 4, "ngFor", "ngForOf"], [1, "user", 3, "click"], [3, "src"], ["color", "success", "name", "checkmark", 4, "ngIf"], ["color", "success", "name", "checkmark"]],
  template: function SelectChallengeableComponent_Template(rf, ctx) {
    if (rf & 1) {
      _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵtemplate"](0, SelectChallengeableComponent_ion_item_0_Template, 6, 5, "ion-item", 0);
    }

    if (rf & 2) {
      _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵproperty"]("ngForOf", ctx.availableChallengeables);
    }
  },
  directives: [_angular_common__WEBPACK_IMPORTED_MODULE_3__.NgForOf, _ionic_angular__WEBPACK_IMPORTED_MODULE_4__.IonItem, _ionic_angular__WEBPACK_IMPORTED_MODULE_4__.IonAvatar, _ionic_angular__WEBPACK_IMPORTED_MODULE_4__.IonLabel, _angular_common__WEBPACK_IMPORTED_MODULE_3__.NgIf, _ionic_angular__WEBPACK_IMPORTED_MODULE_4__.IonIcon],
  styles: [".user.selected[_ngcontent-%COMP%] {\n  --border-color: var(--ion-color-base);\n}\n/*# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbInNlbGVjdC1jaGFsbGVuZ2VhYmxlLmNvbXBvbmVudC5zY3NzIl0sIm5hbWVzIjpbXSwibWFwcGluZ3MiOiJBQUNFO0VBQ0UscUNBQUE7QUFBSiIsImZpbGUiOiJzZWxlY3QtY2hhbGxlbmdlYWJsZS5jb21wb25lbnQuc2NzcyIsInNvdXJjZXNDb250ZW50IjpbIi51c2VyIHtcbiAgJi5zZWxlY3RlZCB7XG4gICAgLS1ib3JkZXItY29sb3I6IHZhcigtLWlvbi1jb2xvci1iYXNlKTtcbiAgICAvLyBib3JkZXI6IDJweCBzb2xpZCB2YXIoLS1pb24tY29sb3ItYmFzZSk7XG4gIH1cbn1cbiJdfQ== */"]
});

/***/ }),

/***/ 68774:
/*!***********************************************************************************************!*\
  !*** ./src/app/pages/challenges/create-challenge/wizard/wizard-step/wizard-step.component.ts ***!
  \***********************************************************************************************/
/***/ (function(__unused_webpack_module, __webpack_exports__, __webpack_require__) {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "WizardStepComponent": function() { return /* binding */ WizardStepComponent; }
/* harmony export */ });
/* harmony import */ var _Users_smartcommunitylab_Documents_work_projects_dslab_playgo_mobile_playgo_mobile_node_modules_babel_runtime_helpers_esm_createClass_js__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./node_modules/@babel/runtime/helpers/esm/createClass.js */ 48047);
/* harmony import */ var _Users_smartcommunitylab_Documents_work_projects_dslab_playgo_mobile_playgo_mobile_node_modules_babel_runtime_helpers_esm_classCallCheck_js__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ./node_modules/@babel/runtime/helpers/esm/classCallCheck.js */ 78069);
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @angular/core */ 3184);




var _c0 = ["template"];

function WizardStepComponent_ng_template_0_Template(rf, ctx) {
  if (rf & 1) {
    _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵprojection"](0);
  }
}

var _c1 = ["*"];
var WizardStepComponent = /*#__PURE__*/(0,_Users_smartcommunitylab_Documents_work_projects_dslab_playgo_mobile_playgo_mobile_node_modules_babel_runtime_helpers_esm_createClass_js__WEBPACK_IMPORTED_MODULE_0__["default"])(function WizardStepComponent() {
  (0,_Users_smartcommunitylab_Documents_work_projects_dslab_playgo_mobile_playgo_mobile_node_modules_babel_runtime_helpers_esm_classCallCheck_js__WEBPACK_IMPORTED_MODULE_1__["default"])(this, WizardStepComponent);

  this.validForNextStep = true;
  this.activated = new _angular_core__WEBPACK_IMPORTED_MODULE_2__.EventEmitter();
});

WizardStepComponent.ɵfac = function WizardStepComponent_Factory(t) {
  return new (t || WizardStepComponent)();
};

WizardStepComponent.ɵcmp = /*@__PURE__*/_angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵdefineComponent"]({
  type: WizardStepComponent,
  selectors: [["app-wizard-step"]],
  viewQuery: function WizardStepComponent_Query(rf, ctx) {
    if (rf & 1) {
      _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵviewQuery"](_c0, 7, _angular_core__WEBPACK_IMPORTED_MODULE_2__.TemplateRef);
    }

    if (rf & 2) {
      var _t;

      _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵqueryRefresh"](_t = _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵloadQuery"]()) && (ctx.template = _t.first);
    }
  },
  inputs: {
    title: "title",
    validForNextStep: "validForNextStep"
  },
  outputs: {
    activated: "activated"
  },
  ngContentSelectors: _c1,
  decls: 2,
  vars: 0,
  consts: [["template", ""]],
  template: function WizardStepComponent_Template(rf, ctx) {
    if (rf & 1) {
      _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵprojectionDef"]();
      _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵtemplate"](0, WizardStepComponent_ng_template_0_Template, 1, 0, "ng-template", null, 0, _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵtemplateRefExtractor"]);
    }
  },
  styles: ["\n/*# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbXSwibmFtZXMiOltdLCJtYXBwaW5ncyI6IiIsImZpbGUiOiJ3aXphcmQtc3RlcC5jb21wb25lbnQuc2NzcyJ9 */"]
});

/***/ }),

/***/ 1359:
/*!******************************************************************************!*\
  !*** ./src/app/pages/challenges/create-challenge/wizard/wizard.component.ts ***!
  \******************************************************************************/
/***/ (function(__unused_webpack_module, __webpack_exports__, __webpack_require__) {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "WizardComponent": function() { return /* binding */ WizardComponent; }
/* harmony export */ });
/* harmony import */ var _Users_smartcommunitylab_Documents_work_projects_dslab_playgo_mobile_playgo_mobile_node_modules_babel_runtime_helpers_esm_classCallCheck_js__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./node_modules/@babel/runtime/helpers/esm/classCallCheck.js */ 78069);
/* harmony import */ var _Users_smartcommunitylab_Documents_work_projects_dslab_playgo_mobile_playgo_mobile_node_modules_babel_runtime_helpers_esm_createClass_js__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ./node_modules/@babel/runtime/helpers/esm/createClass.js */ 48047);
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @angular/core */ 3184);
/* harmony import */ var _wizard_step_wizard_step_component__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! ./wizard-step/wizard-step.component */ 68774);
/* harmony import */ var _ionic_angular__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! @ionic/angular */ 93819);
/* harmony import */ var _angular_common__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! @angular/common */ 36362);
/* harmony import */ var _ngx_translate_core__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! @ngx-translate/core */ 87514);









function WizardComponent_div_4_Template(rf, ctx) {
  if (rf & 1) {
    _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵelementStart"](0, "div", 10);
    _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵtext"](1);
    _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵelementEnd"]();
  }

  if (rf & 2) {
    var ctx_r0 = _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵnextContext"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵadvance"](1);
    _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵtextInterpolate1"](" ", ctx_r0.title, " ");
  }
}

function WizardComponent_div_5_Template(rf, ctx) {
  if (rf & 1) {
    _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵelementStart"](0, "div", 11);
    _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵtext"](1);
    _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵpipe"](2, "translate");
    _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵelementEnd"]();
  }

  if (rf & 2) {
    var ctx_r1 = _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵnextContext"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵadvance"](1);
    _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵtextInterpolate1"](" ", _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵpipeBind1"](2, 1, ctx_r1.selectedStep.title), " ");
  }
}

function WizardComponent_ng_container_8_Template(rf, ctx) {
  if (rf & 1) {
    var _r9 = _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵgetCurrentView"]();

    _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵelementContainerStart"](0);
    _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵelement"](1, "div", 12);
    _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵelementStart"](2, "div", 13);
    _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵlistener"]("click", function WizardComponent_ng_container_8_Template_div_click_2_listener() {
      var restoredCtx = _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵrestoreView"](_r9);
      var currentStepIndex_r7 = restoredCtx.index;
      var ctx_r8 = _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵnextContext"]();
      return ctx_r8.changeStep(currentStepIndex_r7);
    });
    _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵtext"](3);
    _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵelementEnd"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵelementContainerEnd"]();
  }

  if (rf & 2) {
    var currentStepIndex_r7 = ctx.index;
    var ctx_r2 = _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵnextContext"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵadvance"](1);
    _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵclassProp"]("first-step", currentStepIndex_r7 === 0);
    _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵadvance"](1);
    _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵclassProp"]("step-current", currentStepIndex_r7 === ctx_r2.selectedStepIndex)("last-step", currentStepIndex_r7 === ctx_r2.steps.length - 1);
    _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵadvance"](1);
    _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵtextInterpolate1"](" ", currentStepIndex_r7 + 1, " ");
  }
}

function WizardComponent_ion_button_12_Template(rf, ctx) {
  if (rf & 1) {
    var _r11 = _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵgetCurrentView"]();

    _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵelementStart"](0, "ion-button", 14);
    _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵlistener"]("click", function WizardComponent_ion_button_12_Template_ion_button_click_0_listener() {
      _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵrestoreView"](_r11);
      var ctx_r10 = _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵnextContext"]();
      return ctx_r10.changeStep(ctx_r10.selectedStepIndex - 1);
    });
    _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵtext"](1);
    _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵpipe"](2, "translate");
    _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵelementEnd"]();
  }

  if (rf & 2) {
    var ctx_r3 = _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵnextContext"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵproperty"]("disabled", ctx_r3.selectedStepIndex === 0);
    _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵadvance"](1);
    _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵtextInterpolate1"](" ", _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵpipeBind1"](2, 2, "wizard.back"), " ");
  }
}

function WizardComponent_ion_button_13_Template(rf, ctx) {
  if (rf & 1) {
    var _r13 = _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵgetCurrentView"]();

    _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵelementStart"](0, "ion-button", 14);
    _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵlistener"]("click", function WizardComponent_ion_button_13_Template_ion_button_click_0_listener() {
      _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵrestoreView"](_r13);
      var ctx_r12 = _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵnextContext"]();
      return ctx_r12.changeStep(ctx_r12.selectedStepIndex + 1);
    });
    _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵtext"](1);
    _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵpipe"](2, "translate");
    _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵelementEnd"]();
  }

  if (rf & 2) {
    var ctx_r4 = _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵnextContext"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵproperty"]("disabled", ctx_r4.selectedStep.validForNextStep !== true);
    _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵadvance"](1);
    _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵtextInterpolate1"](" ", _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵpipeBind1"](2, 2, "wizard.next"), " ");
  }
}

function WizardComponent_ion_button_14_Template(rf, ctx) {
  if (rf & 1) {
    var _r15 = _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵgetCurrentView"]();

    _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵelementStart"](0, "ion-button", 14);
    _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵlistener"]("click", function WizardComponent_ion_button_14_Template_ion_button_click_0_listener() {
      _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵrestoreView"](_r15);
      var ctx_r14 = _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵnextContext"]();
      return ctx_r14.finish.emit();
    });
    _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵtext"](1);
    _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵelementEnd"]();
  }

  if (rf & 2) {
    var ctx_r5 = _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵnextContext"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵproperty"]("disabled", ctx_r5.selectedStep.validForNextStep !== true);
    _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵadvance"](1);
    _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵtextInterpolate1"](" ", ctx_r5.finishButtonLabel, " ");
  }
}

var WizardComponent = /*#__PURE__*/function () {
  function WizardComponent() {
    (0,_Users_smartcommunitylab_Documents_work_projects_dslab_playgo_mobile_playgo_mobile_node_modules_babel_runtime_helpers_esm_classCallCheck_js__WEBPACK_IMPORTED_MODULE_0__["default"])(this, WizardComponent);

    this.title = '';
    this.backButton = true;
    this.finishButtonLabel = '';
    this.finish = new _angular_core__WEBPACK_IMPORTED_MODULE_3__.EventEmitter();
    this.steps = [];
    this.templates = [];
    this.selectedStepIndex = 0;
  }

  (0,_Users_smartcommunitylab_Documents_work_projects_dslab_playgo_mobile_playgo_mobile_node_modules_babel_runtime_helpers_esm_createClass_js__WEBPACK_IMPORTED_MODULE_1__["default"])(WizardComponent, [{
    key: "stepComponents",
    set: function set(stepComponents) {
      this.steps = stepComponents.toArray();
      this.templates = stepComponents.map(function (eachComponent) {
        return eachComponent.template;
      });
      this.changeStep(0);
    }
  }, {
    key: "ngAfterContentInit",
    value: function ngAfterContentInit() {}
  }, {
    key: "isStepValid",
    value: function isStepValid(newStepIdx) {
      if (newStepIdx === 0) {
        return true;
      }

      var previousStepIdx = Math.max(newStepIdx - 1, 0);
      var previousStep = this.steps[previousStepIdx];
      return previousStep.validForNextStep !== false;
    }
  }, {
    key: "changeStep",
    value: function changeStep(newStepIdx) {
      if (!this.isStepValid(newStepIdx)) {
        return;
      }

      this.selectedStepIndex = newStepIdx;
      this.selectedStep = this.steps[this.selectedStepIndex];
      this.selectedStep.activated.next();
    }
  }, {
    key: "ngOnInit",
    value: function ngOnInit() {}
  }]);

  return WizardComponent;
}();

WizardComponent.ɵfac = function WizardComponent_Factory(t) {
  return new (t || WizardComponent)();
};

WizardComponent.ɵcmp = /*@__PURE__*/_angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵdefineComponent"]({
  type: WizardComponent,
  selectors: [["app-wizard"]],
  contentQueries: function WizardComponent_ContentQueries(rf, ctx, dirIndex) {
    if (rf & 1) {
      _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵcontentQuery"](dirIndex, _wizard_step_wizard_step_component__WEBPACK_IMPORTED_MODULE_2__.WizardStepComponent, 4);
    }

    if (rf & 2) {
      var _t;

      _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵqueryRefresh"](_t = _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵloadQuery"]()) && (ctx.stepComponents = _t);
    }
  },
  inputs: {
    title: "title",
    backButton: "backButton",
    finishButtonLabel: "finishButtonLabel"
  },
  outputs: {
    finish: "finish"
  },
  decls: 15,
  vars: 7,
  consts: [[1, "wrapper"], ["color", "base", 1, "title-header"], ["class", "ion-text-start", 4, "ngIf"], ["class", "ion-text-end", 4, "ngIf"], [1, "form-steps-container"], [4, "ngFor", "ngForOf"], [1, "step-content-wrapper"], [3, "ngTemplateOutlet"], [1, "ion-justify-content-around", 2, "display", "flex"], ["color", "base", 3, "disabled", "click", 4, "ngIf"], [1, "ion-text-start"], [1, "ion-text-end"], [1, "step-divider"], [1, "step-bubble", 3, "click"], ["color", "base", 3, "disabled", "click"]],
  template: function WizardComponent_Template(rf, ctx) {
    if (rf & 1) {
      _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵelementStart"](0, "div", 0)(1, "ion-card")(2, "ion-card-header", 1)(3, "ion-card-title");
      _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵtemplate"](4, WizardComponent_div_4_Template, 2, 1, "div", 2);
      _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵtemplate"](5, WizardComponent_div_5_Template, 3, 3, "div", 3);
      _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵelementEnd"]()();
      _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵelementStart"](6, "ion-card-content")(7, "div", 4);
      _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵtemplate"](8, WizardComponent_ng_container_8_Template, 4, 7, "ng-container", 5);
      _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵelementEnd"]();
      _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵelementStart"](9, "div", 6);
      _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵelementContainer"](10, 7);
      _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵelementEnd"]();
      _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵelementStart"](11, "div", 8);
      _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵtemplate"](12, WizardComponent_ion_button_12_Template, 3, 4, "ion-button", 9);
      _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵtemplate"](13, WizardComponent_ion_button_13_Template, 3, 4, "ion-button", 9);
      _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵtemplate"](14, WizardComponent_ion_button_14_Template, 2, 2, "ion-button", 9);
      _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵelementEnd"]()()()();
    }

    if (rf & 2) {
      _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵadvance"](4);
      _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵproperty"]("ngIf", ctx.title);
      _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵadvance"](1);
      _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵproperty"]("ngIf", ctx.selectedStep.title);
      _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵadvance"](3);
      _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵproperty"]("ngForOf", ctx.steps);
      _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵadvance"](2);
      _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵproperty"]("ngTemplateOutlet", ctx.templates[ctx.selectedStepIndex]);
      _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵadvance"](2);
      _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵproperty"]("ngIf", ctx.backButton);
      _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵadvance"](1);
      _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵproperty"]("ngIf", ctx.selectedStepIndex !== ctx.steps.length - 1);
      _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵadvance"](1);
      _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵproperty"]("ngIf", ctx.selectedStepIndex === ctx.steps.length - 1);
    }
  },
  directives: [_ionic_angular__WEBPACK_IMPORTED_MODULE_4__.IonCard, _ionic_angular__WEBPACK_IMPORTED_MODULE_4__.IonCardHeader, _ionic_angular__WEBPACK_IMPORTED_MODULE_4__.IonCardTitle, _angular_common__WEBPACK_IMPORTED_MODULE_5__.NgIf, _ionic_angular__WEBPACK_IMPORTED_MODULE_4__.IonCardContent, _angular_common__WEBPACK_IMPORTED_MODULE_5__.NgForOf, _angular_common__WEBPACK_IMPORTED_MODULE_5__.NgTemplateOutlet, _ionic_angular__WEBPACK_IMPORTED_MODULE_4__.IonButton],
  pipes: [_ngx_translate_core__WEBPACK_IMPORTED_MODULE_6__.TranslatePipe],
  styles: ["[_nghost-%COMP%] {\n  height: 100%;\n}\n\n.wrapper[_ngcontent-%COMP%] {\n  height: calc(100% - 20px);\n}\n\n.wrapper[_ngcontent-%COMP%]   ion-card[_ngcontent-%COMP%] {\n  height: 100%;\n  margin: 10px;\n  display: flex;\n  flex-direction: column;\n}\n\n.wrapper[_ngcontent-%COMP%]   ion-card[_ngcontent-%COMP%]   ion-card-content[_ngcontent-%COMP%] {\n  flex: 1;\n  display: flex;\n  flex-direction: column;\n  overflow-y: auto;\n}\n\n.title-header[_ngcontent-%COMP%]   ion-card-title[_ngcontent-%COMP%] {\n  font-size: 10px;\n  display: flex;\n  justify-content: space-between;\n}\n\n.form-steps-container[_ngcontent-%COMP%] {\n  display: flex;\n  justify-content: space-between;\n  align-items: center;\n  padding: 0 20px 0 10px;\n  margin-top: 10px;\n}\n\n.step-bubble[_ngcontent-%COMP%] {\n  padding: 8px;\n  border: 3px solid var(--ion-color-base);\n  width: 30px;\n  height: 30px;\n  display: flex;\n  justify-content: center;\n  align-items: center;\n  border-radius: 50%;\n  font-size: 1em;\n  cursor: pointer;\n  -webkit-user-select: none;\n          user-select: none;\n  background: #e0e0e0;\n}\n\n.step-bubble.step-current[_ngcontent-%COMP%] {\n  border-width: 5px;\n  width: 34px;\n  height: 34px;\n  margin-left: -2px;\n  margin-right: -2px;\n  background: white;\n  font-weight: bold;\n}\n\n.step-bubble.last-step[_ngcontent-%COMP%] {\n  border-radius: 0;\n}\n\n.step-divider[_ngcontent-%COMP%] {\n  height: 2px;\n  background: var(--ion-color-base);\n  flex: 1;\n}\n\n.step-divider.first-step[_ngcontent-%COMP%] {\n  flex: 0.2;\n}\n\n.step-content-wrapper[_ngcontent-%COMP%] {\n  flex: 1;\n}\n/*# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbIndpemFyZC5jb21wb25lbnQuc2NzcyJdLCJuYW1lcyI6W10sIm1hcHBpbmdzIjoiQUFJQTtFQUNFLFlBQUE7QUFIRjs7QUFNQTtFQUNFLHlCQUFBO0FBSEY7O0FBSUU7RUFDRSxZQUFBO0VBQ0EsWUFBQTtFQUVBLGFBQUE7RUFDQSxzQkFBQTtBQUhKOztBQUlJO0VBQ0UsT0FBQTtFQUNBLGFBQUE7RUFDQSxzQkFBQTtFQUNBLGdCQUFBO0FBRk47O0FBUUU7RUFDRSxlQUFBO0VBQ0EsYUFBQTtFQUNBLDhCQUFBO0FBTEo7O0FBUUE7RUFDRSxhQUFBO0VBQ0EsOEJBQUE7RUFDQSxtQkFBQTtFQUNBLHNCQUFBO0VBQ0EsZ0JBQUE7QUFMRjs7QUFXQTtFQUNFLFlBQUE7RUFDQSx1Q0FBQTtFQUNBLFdBTlk7RUFPWixZQVBZO0VBUVosYUFBQTtFQUNBLHVCQUFBO0VBQ0EsbUJBQUE7RUFDQSxrQkFBQTtFQUNBLGNBQUE7RUFDQSxlQUFBO0VBQ0EseUJBQUE7VUFBQSxpQkFBQTtFQUNBLG1CQXREd0I7QUE4QzFCOztBQVVFO0VBQ0UsaUJBQUE7RUFDQSxXQUFBO0VBQ0EsWUFBQTtFQUNBLGlCQUFBO0VBQ0Esa0JBQUE7RUFDQSxpQkEvRGtCO0VBZ0VsQixpQkFBQTtBQVJKOztBQVdFO0VBQ0UsZ0JBQUE7QUFUSjs7QUFhQTtFQUNFLFdBQUE7RUFDQSxpQ0FBQTtFQUNBLE9BQUE7QUFWRjs7QUFZRTtFQUNFLFNBQUE7QUFWSjs7QUFjQTtFQUNFLE9BQUE7QUFYRiIsImZpbGUiOiJ3aXphcmQuY29tcG9uZW50LnNjc3MiLCJzb3VyY2VzQ29udGVudCI6WyIkc2VsZWN0ZWQtYmFja2dyb3VuZDogd2hpdGU7XG4kbm90LXNlbGVjdGVkLWJhY2tncm91bmQ6IHJnYigyMjQsIDIyNCwgMjI0KTtcbi8vICRub3Qtc2VsZWN0ZWQtYmFja2dyb3VuZDogcmVkO1xuXG46aG9zdCB7XG4gIGhlaWdodDogMTAwJTtcbn1cblxuLndyYXBwZXIge1xuICBoZWlnaHQ6IGNhbGMoMTAwJSAtIDIwcHgpO1xuICBpb24tY2FyZCB7XG4gICAgaGVpZ2h0OiAxMDAlO1xuICAgIG1hcmdpbjogMTBweDtcblxuICAgIGRpc3BsYXk6IGZsZXg7XG4gICAgZmxleC1kaXJlY3Rpb246IGNvbHVtbjtcbiAgICBpb24tY2FyZC1jb250ZW50IHtcbiAgICAgIGZsZXg6IDE7XG4gICAgICBkaXNwbGF5OiBmbGV4O1xuICAgICAgZmxleC1kaXJlY3Rpb246IGNvbHVtbjtcbiAgICAgIG92ZXJmbG93LXk6IGF1dG87XG4gICAgfVxuICB9XG59XG5cbi50aXRsZS1oZWFkZXIge1xuICBpb24tY2FyZC10aXRsZSB7XG4gICAgZm9udC1zaXplOiAxMHB4O1xuICAgIGRpc3BsYXk6IGZsZXg7XG4gICAganVzdGlmeS1jb250ZW50OiBzcGFjZS1iZXR3ZWVuO1xuICB9XG59XG4uZm9ybS1zdGVwcy1jb250YWluZXIge1xuICBkaXNwbGF5OiBmbGV4O1xuICBqdXN0aWZ5LWNvbnRlbnQ6IHNwYWNlLWJldHdlZW47XG4gIGFsaWduLWl0ZW1zOiBjZW50ZXI7XG4gIHBhZGRpbmc6IDAgMjBweCAwIDEwcHg7XG4gIG1hcmdpbi10b3A6IDEwcHg7XG59XG5cbiRidWJibGUtc2l6ZTogMzBweDtcbiRidWJibGUtYm9yZGVyOiAzcHg7XG4kc2VsZWN0ZWQtYnViYmxlLWluY3JlYXNlOiAycHg7XG4uc3RlcC1idWJibGUge1xuICBwYWRkaW5nOiA4cHg7XG4gIGJvcmRlcjogJGJ1YmJsZS1ib3JkZXIgc29saWQgdmFyKC0taW9uLWNvbG9yLWJhc2UpO1xuICB3aWR0aDogJGJ1YmJsZS1zaXplO1xuICBoZWlnaHQ6ICRidWJibGUtc2l6ZTtcbiAgZGlzcGxheTogZmxleDtcbiAganVzdGlmeS1jb250ZW50OiBjZW50ZXI7XG4gIGFsaWduLWl0ZW1zOiBjZW50ZXI7XG4gIGJvcmRlci1yYWRpdXM6IDUwJTtcbiAgZm9udC1zaXplOiAxZW07XG4gIGN1cnNvcjogcG9pbnRlcjtcbiAgdXNlci1zZWxlY3Q6IG5vbmU7XG4gIGJhY2tncm91bmQ6ICRub3Qtc2VsZWN0ZWQtYmFja2dyb3VuZDtcblxuICAmLnN0ZXAtY3VycmVudCB7XG4gICAgYm9yZGVyLXdpZHRoOiAkYnViYmxlLWJvcmRlciArICRzZWxlY3RlZC1idWJibGUtaW5jcmVhc2U7XG4gICAgd2lkdGg6ICRidWJibGUtc2l6ZSArIDIgKiAkc2VsZWN0ZWQtYnViYmxlLWluY3JlYXNlO1xuICAgIGhlaWdodDogJGJ1YmJsZS1zaXplICsgMiAqICRzZWxlY3RlZC1idWJibGUtaW5jcmVhc2U7XG4gICAgbWFyZ2luLWxlZnQ6IC0kc2VsZWN0ZWQtYnViYmxlLWluY3JlYXNlO1xuICAgIG1hcmdpbi1yaWdodDogLSRzZWxlY3RlZC1idWJibGUtaW5jcmVhc2U7XG4gICAgYmFja2dyb3VuZDogJHNlbGVjdGVkLWJhY2tncm91bmQ7XG4gICAgZm9udC13ZWlnaHQ6IGJvbGQ7XG4gIH1cblxuICAmLmxhc3Qtc3RlcCB7XG4gICAgYm9yZGVyLXJhZGl1czogMDtcbiAgfVxufVxuXG4uc3RlcC1kaXZpZGVyIHtcbiAgaGVpZ2h0OiAycHg7XG4gIGJhY2tncm91bmQ6IHZhcigtLWlvbi1jb2xvci1iYXNlKTtcbiAgZmxleDogMTtcblxuICAmLmZpcnN0LXN0ZXAge1xuICAgIGZsZXg6IDAuMjtcbiAgfVxufVxuXG4uc3RlcC1jb250ZW50LXdyYXBwZXIge1xuICBmbGV4OiAxO1xufVxuIl19 */"]
});

/***/ })

}]);
//# sourceMappingURL=src_app_pages_challenges_create-challenge_create-challenge_module_ts.js.map