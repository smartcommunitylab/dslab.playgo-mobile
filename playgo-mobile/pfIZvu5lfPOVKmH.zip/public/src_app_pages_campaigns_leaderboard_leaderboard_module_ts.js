"use strict";
(self["webpackChunkapp"] = self["webpackChunkapp"] || []).push([["src_app_pages_campaigns_leaderboard_leaderboard_module_ts"],{

/***/ 70906:
/*!***************************************************************************!*\
  !*** ./src/app/pages/campaigns/leaderboard/leaderboard-routing.module.ts ***!
  \***************************************************************************/
/***/ (function(__unused_webpack_module, __webpack_exports__, __webpack_require__) {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "LeaderboardPageRoutingModule": function() { return /* binding */ LeaderboardPageRoutingModule; }
/* harmony export */ });
/* harmony import */ var _Users_smartcommunitylab_Documents_work_projects_dslab_playgo_mobile_playgo_mobile_node_modules_babel_runtime_helpers_esm_createClass_js__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./node_modules/@babel/runtime/helpers/esm/createClass.js */ 48047);
/* harmony import */ var _Users_smartcommunitylab_Documents_work_projects_dslab_playgo_mobile_playgo_mobile_node_modules_babel_runtime_helpers_esm_classCallCheck_js__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ./node_modules/@babel/runtime/helpers/esm/classCallCheck.js */ 78069);
/* harmony import */ var _angular_router__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! @angular/router */ 52816);
/* harmony import */ var _leaderboard_page__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! ./leaderboard.page */ 53798);
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @angular/core */ 3184);






var routes = [{
  path: '',
  component: _leaderboard_page__WEBPACK_IMPORTED_MODULE_2__.LeaderboardPage,
  data: {
    title: 'leaderboard.title'
  }
}];
var LeaderboardPageRoutingModule = /*#__PURE__*/(0,_Users_smartcommunitylab_Documents_work_projects_dslab_playgo_mobile_playgo_mobile_node_modules_babel_runtime_helpers_esm_createClass_js__WEBPACK_IMPORTED_MODULE_0__["default"])(function LeaderboardPageRoutingModule() {
  (0,_Users_smartcommunitylab_Documents_work_projects_dslab_playgo_mobile_playgo_mobile_node_modules_babel_runtime_helpers_esm_classCallCheck_js__WEBPACK_IMPORTED_MODULE_1__["default"])(this, LeaderboardPageRoutingModule);
});

LeaderboardPageRoutingModule.ɵfac = function LeaderboardPageRoutingModule_Factory(t) {
  return new (t || LeaderboardPageRoutingModule)();
};

LeaderboardPageRoutingModule.ɵmod = /*@__PURE__*/_angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵdefineNgModule"]({
  type: LeaderboardPageRoutingModule
});
LeaderboardPageRoutingModule.ɵinj = /*@__PURE__*/_angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵdefineInjector"]({
  imports: [[_angular_router__WEBPACK_IMPORTED_MODULE_4__.RouterModule.forChild(routes)], _angular_router__WEBPACK_IMPORTED_MODULE_4__.RouterModule]
});

(function () {
  (typeof ngJitMode === "undefined" || ngJitMode) && _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵsetNgModuleScope"](LeaderboardPageRoutingModule, {
    imports: [_angular_router__WEBPACK_IMPORTED_MODULE_4__.RouterModule],
    exports: [_angular_router__WEBPACK_IMPORTED_MODULE_4__.RouterModule]
  });
})();

/***/ }),

/***/ 75450:
/*!*******************************************************************!*\
  !*** ./src/app/pages/campaigns/leaderboard/leaderboard.module.ts ***!
  \*******************************************************************/
/***/ (function(__unused_webpack_module, __webpack_exports__, __webpack_require__) {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "LeaderboardModule": function() { return /* binding */ LeaderboardModule; }
/* harmony export */ });
/* harmony import */ var _Users_smartcommunitylab_Documents_work_projects_dslab_playgo_mobile_playgo_mobile_node_modules_babel_runtime_helpers_esm_createClass_js__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./node_modules/@babel/runtime/helpers/esm/createClass.js */ 48047);
/* harmony import */ var _Users_smartcommunitylab_Documents_work_projects_dslab_playgo_mobile_playgo_mobile_node_modules_babel_runtime_helpers_esm_classCallCheck_js__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ./node_modules/@babel/runtime/helpers/esm/classCallCheck.js */ 78069);
/* harmony import */ var src_app_core_shared_shared_module__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! src/app/core/shared/shared.module */ 97205);
/* harmony import */ var _leaderboard_routing_module__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! ./leaderboard-routing.module */ 70906);
/* harmony import */ var _leaderboard_page__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! ./leaderboard.page */ 53798);
/* harmony import */ var _placing_detail_placing_detail_component__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! ./placing-detail/placing-detail.component */ 21461);
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! @angular/core */ 3184);







var LeaderboardModule = /*#__PURE__*/(0,_Users_smartcommunitylab_Documents_work_projects_dslab_playgo_mobile_playgo_mobile_node_modules_babel_runtime_helpers_esm_createClass_js__WEBPACK_IMPORTED_MODULE_0__["default"])(function LeaderboardModule() {
  (0,_Users_smartcommunitylab_Documents_work_projects_dslab_playgo_mobile_playgo_mobile_node_modules_babel_runtime_helpers_esm_classCallCheck_js__WEBPACK_IMPORTED_MODULE_1__["default"])(this, LeaderboardModule);
});

LeaderboardModule.ɵfac = function LeaderboardModule_Factory(t) {
  return new (t || LeaderboardModule)();
};

LeaderboardModule.ɵmod = /*@__PURE__*/_angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵdefineNgModule"]({
  type: LeaderboardModule
});
LeaderboardModule.ɵinj = /*@__PURE__*/_angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵdefineInjector"]({
  imports: [[_leaderboard_routing_module__WEBPACK_IMPORTED_MODULE_3__.LeaderboardPageRoutingModule, src_app_core_shared_shared_module__WEBPACK_IMPORTED_MODULE_2__.PlayGoSharedModule]]
});

(function () {
  (typeof ngJitMode === "undefined" || ngJitMode) && _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵsetNgModuleScope"](LeaderboardModule, {
    declarations: [_leaderboard_page__WEBPACK_IMPORTED_MODULE_4__.LeaderboardPage, _placing_detail_placing_detail_component__WEBPACK_IMPORTED_MODULE_5__.PlacingDetailComponent],
    imports: [_leaderboard_routing_module__WEBPACK_IMPORTED_MODULE_3__.LeaderboardPageRoutingModule, src_app_core_shared_shared_module__WEBPACK_IMPORTED_MODULE_2__.PlayGoSharedModule]
  });
})();

/***/ }),

/***/ 53798:
/*!*****************************************************************!*\
  !*** ./src/app/pages/campaigns/leaderboard/leaderboard.page.ts ***!
  \*****************************************************************/
/***/ (function(__unused_webpack_module, __webpack_exports__, __webpack_require__) {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "LeaderboardPage": function() { return /* binding */ LeaderboardPage; }
/* harmony export */ });
/* harmony import */ var _Users_smartcommunitylab_Documents_work_projects_dslab_playgo_mobile_playgo_mobile_node_modules_babel_runtime_helpers_esm_slicedToArray_js__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./node_modules/@babel/runtime/helpers/esm/slicedToArray.js */ 10507);
/* harmony import */ var _Users_smartcommunitylab_Documents_work_projects_dslab_playgo_mobile_playgo_mobile_node_modules_babel_runtime_helpers_esm_toConsumableArray_js__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ./node_modules/@babel/runtime/helpers/esm/toConsumableArray.js */ 58277);
/* harmony import */ var _Users_smartcommunitylab_Documents_work_projects_dslab_playgo_mobile_playgo_mobile_node_modules_babel_runtime_helpers_esm_classCallCheck_js__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! ./node_modules/@babel/runtime/helpers/esm/classCallCheck.js */ 78069);
/* harmony import */ var _Users_smartcommunitylab_Documents_work_projects_dslab_playgo_mobile_playgo_mobile_node_modules_babel_runtime_helpers_esm_createClass_js__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! ./node_modules/@babel/runtime/helpers/esm/createClass.js */ 48047);
/* harmony import */ var lodash_es__WEBPACK_IMPORTED_MODULE_20__ = __webpack_require__(/*! lodash-es */ 97732);
/* harmony import */ var lodash_es__WEBPACK_IMPORTED_MODULE_25__ = __webpack_require__(/*! lodash-es */ 63247);
/* harmony import */ var rxjs__WEBPACK_IMPORTED_MODULE_21__ = __webpack_require__(/*! rxjs */ 80228);
/* harmony import */ var rxjs__WEBPACK_IMPORTED_MODULE_24__ = __webpack_require__(/*! rxjs */ 26562);
/* harmony import */ var rxjs_operators__WEBPACK_IMPORTED_MODULE_16__ = __webpack_require__(/*! rxjs/operators */ 50635);
/* harmony import */ var rxjs_operators__WEBPACK_IMPORTED_MODULE_17__ = __webpack_require__(/*! rxjs/operators */ 98977);
/* harmony import */ var rxjs_operators__WEBPACK_IMPORTED_MODULE_18__ = __webpack_require__(/*! rxjs/operators */ 89196);
/* harmony import */ var rxjs_operators__WEBPACK_IMPORTED_MODULE_19__ = __webpack_require__(/*! rxjs/operators */ 32673);
/* harmony import */ var rxjs_operators__WEBPACK_IMPORTED_MODULE_22__ = __webpack_require__(/*! rxjs/operators */ 80155);
/* harmony import */ var rxjs_operators__WEBPACK_IMPORTED_MODULE_23__ = __webpack_require__(/*! rxjs/operators */ 44874);
/* harmony import */ var luxon__WEBPACK_IMPORTED_MODULE_15__ = __webpack_require__(/*! luxon */ 29527);
/* harmony import */ var src_app_core_shared_tracking_trip_model__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! src/app/core/shared/tracking/trip.model */ 49110);
/* harmony import */ var src_app_core_shared_utils__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! src/app/core/shared/utils */ 68647);
/* harmony import */ var src_app_core_shared_time_utils__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! src/app/core/shared/time.utils */ 93462);
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_14__ = __webpack_require__(/*! @angular/core */ 3184);
/* harmony import */ var _angular_router__WEBPACK_IMPORTED_MODULE_26__ = __webpack_require__(/*! @angular/router */ 52816);
/* harmony import */ var src_app_core_api_generated_controllers_reportController_service__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(/*! src/app/core/api/generated/controllers/reportController.service */ 59730);
/* harmony import */ var src_app_core_shared_services_user_service__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(/*! src/app/core/shared/services/user.service */ 50749);
/* harmony import */ var src_app_core_shared_services_campaign_service__WEBPACK_IMPORTED_MODULE_9__ = __webpack_require__(/*! src/app/core/shared/services/campaign.service */ 23645);
/* harmony import */ var src_app_core_shared_services_error_service__WEBPACK_IMPORTED_MODULE_10__ = __webpack_require__(/*! src/app/core/shared/services/error.service */ 96204);
/* harmony import */ var _ionic_angular__WEBPACK_IMPORTED_MODULE_27__ = __webpack_require__(/*! @ionic/angular */ 93819);
/* harmony import */ var _core_shared_layout_header_header_directive__WEBPACK_IMPORTED_MODULE_11__ = __webpack_require__(/*! ../../../core/shared/layout/header/header.directive */ 34161);
/* harmony import */ var _angular_common__WEBPACK_IMPORTED_MODULE_28__ = __webpack_require__(/*! @angular/common */ 36362);
/* harmony import */ var _placing_detail_placing_detail_component__WEBPACK_IMPORTED_MODULE_12__ = __webpack_require__(/*! ./placing-detail/placing-detail.component */ 21461);
/* harmony import */ var _core_shared_infinite_scroll_infinite_scroll_component__WEBPACK_IMPORTED_MODULE_13__ = __webpack_require__(/*! ../../../core/shared/infinite-scroll/infinite-scroll.component */ 3299);
/* harmony import */ var _ngx_translate_core__WEBPACK_IMPORTED_MODULE_29__ = __webpack_require__(/*! @ngx-translate/core */ 87514);
























function LeaderboardPage_ng_container_2_ion_select_option_7_span_3_Template(rf, ctx) {
  if (rf & 1) {
    _angular_core__WEBPACK_IMPORTED_MODULE_14__["ɵɵelementStart"](0, "span");
    _angular_core__WEBPACK_IMPORTED_MODULE_14__["ɵɵtext"](1);
    _angular_core__WEBPACK_IMPORTED_MODULE_14__["ɵɵpipe"](2, "translate");
    _angular_core__WEBPACK_IMPORTED_MODULE_14__["ɵɵelementEnd"]();
  }

  if (rf & 2) {
    var leaderboardType_r4 = _angular_core__WEBPACK_IMPORTED_MODULE_14__["ɵɵnextContext"]().$implicit;
    _angular_core__WEBPACK_IMPORTED_MODULE_14__["ɵɵadvance"](1);
    _angular_core__WEBPACK_IMPORTED_MODULE_14__["ɵɵtextInterpolate1"]("[", _angular_core__WEBPACK_IMPORTED_MODULE_14__["ɵɵpipeBind1"](2, 1, leaderboardType_r4.unitLabelKey), "]");
  }
}

function LeaderboardPage_ng_container_2_ion_select_option_7_Template(rf, ctx) {
  if (rf & 1) {
    _angular_core__WEBPACK_IMPORTED_MODULE_14__["ɵɵelementStart"](0, "ion-select-option", 6);
    _angular_core__WEBPACK_IMPORTED_MODULE_14__["ɵɵtext"](1);
    _angular_core__WEBPACK_IMPORTED_MODULE_14__["ɵɵpipe"](2, "translate");
    _angular_core__WEBPACK_IMPORTED_MODULE_14__["ɵɵtemplate"](3, LeaderboardPage_ng_container_2_ion_select_option_7_span_3_Template, 3, 3, "span", 1);
    _angular_core__WEBPACK_IMPORTED_MODULE_14__["ɵɵelementEnd"]();
  }

  if (rf & 2) {
    var leaderboardType_r4 = ctx.$implicit;
    _angular_core__WEBPACK_IMPORTED_MODULE_14__["ɵɵproperty"]("value", leaderboardType_r4);
    _angular_core__WEBPACK_IMPORTED_MODULE_14__["ɵɵadvance"](1);
    _angular_core__WEBPACK_IMPORTED_MODULE_14__["ɵɵtextInterpolate1"](" ", _angular_core__WEBPACK_IMPORTED_MODULE_14__["ɵɵpipeBind1"](2, 3, leaderboardType_r4.labelKey), " ");
    _angular_core__WEBPACK_IMPORTED_MODULE_14__["ɵɵadvance"](2);
    _angular_core__WEBPACK_IMPORTED_MODULE_14__["ɵɵproperty"]("ngIf", leaderboardType_r4 == null ? null : leaderboardType_r4.unitLabelKey);
  }
}

function LeaderboardPage_ng_container_2_ion_select_option_15_Template(rf, ctx) {
  if (rf & 1) {
    _angular_core__WEBPACK_IMPORTED_MODULE_14__["ɵɵelementStart"](0, "ion-select-option", 6);
    _angular_core__WEBPACK_IMPORTED_MODULE_14__["ɵɵtext"](1);
    _angular_core__WEBPACK_IMPORTED_MODULE_14__["ɵɵpipe"](2, "translate");
    _angular_core__WEBPACK_IMPORTED_MODULE_14__["ɵɵelementEnd"]();
  }

  if (rf & 2) {
    var period_r7 = ctx.$implicit;
    _angular_core__WEBPACK_IMPORTED_MODULE_14__["ɵɵproperty"]("value", period_r7);
    _angular_core__WEBPACK_IMPORTED_MODULE_14__["ɵɵadvance"](1);
    _angular_core__WEBPACK_IMPORTED_MODULE_14__["ɵɵtextInterpolate1"](" ", _angular_core__WEBPACK_IMPORTED_MODULE_14__["ɵɵpipeBind1"](2, 2, period_r7.labelKey), " ");
  }
}

function LeaderboardPage_ng_container_2_ng_container_19_ng_template_4_Template(rf, ctx) {
  if (rf & 1) {
    _angular_core__WEBPACK_IMPORTED_MODULE_14__["ɵɵelement"](0, "app-placing-detail", 5);
    _angular_core__WEBPACK_IMPORTED_MODULE_14__["ɵɵpipe"](1, "async");
  }

  if (rf & 2) {
    var placing_r10 = ctx.item;
    var ctx_r9 = _angular_core__WEBPACK_IMPORTED_MODULE_14__["ɵɵnextContext"](3);
    _angular_core__WEBPACK_IMPORTED_MODULE_14__["ɵɵproperty"]("placing", placing_r10)("unitLabelKey", _angular_core__WEBPACK_IMPORTED_MODULE_14__["ɵɵpipeBind1"](1, 2, ctx_r9.numberWithUnitKey$));
  }
}

function LeaderboardPage_ng_container_2_ng_container_19_Template(rf, ctx) {
  if (rf & 1) {
    var _r12 = _angular_core__WEBPACK_IMPORTED_MODULE_14__["ɵɵgetCurrentView"]();

    _angular_core__WEBPACK_IMPORTED_MODULE_14__["ɵɵelementContainerStart"](0);
    _angular_core__WEBPACK_IMPORTED_MODULE_14__["ɵɵelementStart"](1, "app-infinite-scroll", 7);
    _angular_core__WEBPACK_IMPORTED_MODULE_14__["ɵɵlistener"]("request", function LeaderboardPage_ng_container_2_ng_container_19_Template_app_infinite_scroll_request_1_listener($event) {
      _angular_core__WEBPACK_IMPORTED_MODULE_14__["ɵɵrestoreView"](_r12);
      var ctx_r11 = _angular_core__WEBPACK_IMPORTED_MODULE_14__["ɵɵnextContext"](2);
      return ctx_r11.scrollRequestSubject.next($event);
    });
    _angular_core__WEBPACK_IMPORTED_MODULE_14__["ɵɵpipe"](2, "async");
    _angular_core__WEBPACK_IMPORTED_MODULE_14__["ɵɵpipe"](3, "async");
    _angular_core__WEBPACK_IMPORTED_MODULE_14__["ɵɵtemplate"](4, LeaderboardPage_ng_container_2_ng_container_19_ng_template_4_Template, 2, 4, "ng-template", 8);
    _angular_core__WEBPACK_IMPORTED_MODULE_14__["ɵɵelementEnd"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_14__["ɵɵelementContainerEnd"]();
  }

  if (rf & 2) {
    var ctx_r3 = _angular_core__WEBPACK_IMPORTED_MODULE_14__["ɵɵnextContext"](2);
    _angular_core__WEBPACK_IMPORTED_MODULE_14__["ɵɵadvance"](1);
    _angular_core__WEBPACK_IMPORTED_MODULE_14__["ɵɵproperty"]("resetItems", _angular_core__WEBPACK_IMPORTED_MODULE_14__["ɵɵpipeBind1"](2, 2, ctx_r3.resetItems$))("response", _angular_core__WEBPACK_IMPORTED_MODULE_14__["ɵɵpipeBind1"](3, 4, ctx_r3.leaderboardScrollResponse$));
  }
}

function LeaderboardPage_ng_container_2_Template(rf, ctx) {
  if (rf & 1) {
    var _r14 = _angular_core__WEBPACK_IMPORTED_MODULE_14__["ɵɵgetCurrentView"]();

    _angular_core__WEBPACK_IMPORTED_MODULE_14__["ɵɵelementContainerStart"](0);
    _angular_core__WEBPACK_IMPORTED_MODULE_14__["ɵɵelementStart"](1, "ion-item", 2)(2, "ion-label");
    _angular_core__WEBPACK_IMPORTED_MODULE_14__["ɵɵtext"](3);
    _angular_core__WEBPACK_IMPORTED_MODULE_14__["ɵɵpipe"](4, "translate");
    _angular_core__WEBPACK_IMPORTED_MODULE_14__["ɵɵelementEnd"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_14__["ɵɵelementStart"](5, "ion-select", 3);
    _angular_core__WEBPACK_IMPORTED_MODULE_14__["ɵɵlistener"]("ionChange", function LeaderboardPage_ng_container_2_Template_ion_select_ionChange_5_listener($event) {
      _angular_core__WEBPACK_IMPORTED_MODULE_14__["ɵɵrestoreView"](_r14);
      var ctx_r13 = _angular_core__WEBPACK_IMPORTED_MODULE_14__["ɵɵnextContext"]();
      return ctx_r13.leaderboardTypeChangedSubject.next($event);
    });
    _angular_core__WEBPACK_IMPORTED_MODULE_14__["ɵɵpipe"](6, "async");
    _angular_core__WEBPACK_IMPORTED_MODULE_14__["ɵɵtemplate"](7, LeaderboardPage_ng_container_2_ion_select_option_7_Template, 4, 5, "ion-select-option", 4);
    _angular_core__WEBPACK_IMPORTED_MODULE_14__["ɵɵpipe"](8, "async");
    _angular_core__WEBPACK_IMPORTED_MODULE_14__["ɵɵelementEnd"]()();
    _angular_core__WEBPACK_IMPORTED_MODULE_14__["ɵɵelementStart"](9, "ion-item", 2)(10, "ion-label");
    _angular_core__WEBPACK_IMPORTED_MODULE_14__["ɵɵtext"](11);
    _angular_core__WEBPACK_IMPORTED_MODULE_14__["ɵɵpipe"](12, "translate");
    _angular_core__WEBPACK_IMPORTED_MODULE_14__["ɵɵelementEnd"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_14__["ɵɵelementStart"](13, "ion-select", 3);
    _angular_core__WEBPACK_IMPORTED_MODULE_14__["ɵɵlistener"]("ionChange", function LeaderboardPage_ng_container_2_Template_ion_select_ionChange_13_listener($event) {
      _angular_core__WEBPACK_IMPORTED_MODULE_14__["ɵɵrestoreView"](_r14);
      var ctx_r15 = _angular_core__WEBPACK_IMPORTED_MODULE_14__["ɵɵnextContext"]();
      return ctx_r15.periodChangedSubject.next($event);
    });
    _angular_core__WEBPACK_IMPORTED_MODULE_14__["ɵɵpipe"](14, "async");
    _angular_core__WEBPACK_IMPORTED_MODULE_14__["ɵɵtemplate"](15, LeaderboardPage_ng_container_2_ion_select_option_15_Template, 3, 4, "ion-select-option", 4);
    _angular_core__WEBPACK_IMPORTED_MODULE_14__["ɵɵelementEnd"]()();
    _angular_core__WEBPACK_IMPORTED_MODULE_14__["ɵɵelement"](16, "app-placing-detail", 5);
    _angular_core__WEBPACK_IMPORTED_MODULE_14__["ɵɵpipe"](17, "async");
    _angular_core__WEBPACK_IMPORTED_MODULE_14__["ɵɵpipe"](18, "async");
    _angular_core__WEBPACK_IMPORTED_MODULE_14__["ɵɵtemplate"](19, LeaderboardPage_ng_container_2_ng_container_19_Template, 5, 6, "ng-container", 1);
    _angular_core__WEBPACK_IMPORTED_MODULE_14__["ɵɵpipe"](20, "async");
    _angular_core__WEBPACK_IMPORTED_MODULE_14__["ɵɵelementContainerEnd"]();
  }

  if (rf & 2) {
    var ctx_r0 = _angular_core__WEBPACK_IMPORTED_MODULE_14__["ɵɵnextContext"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_14__["ɵɵadvance"](3);
    _angular_core__WEBPACK_IMPORTED_MODULE_14__["ɵɵtextInterpolate"](_angular_core__WEBPACK_IMPORTED_MODULE_14__["ɵɵpipeBind1"](4, 9, "campaigns.leaderboard.filter.leaderboard_type"));
    _angular_core__WEBPACK_IMPORTED_MODULE_14__["ɵɵadvance"](2);
    _angular_core__WEBPACK_IMPORTED_MODULE_14__["ɵɵproperty"]("value", _angular_core__WEBPACK_IMPORTED_MODULE_14__["ɵɵpipeBind1"](6, 11, ctx_r0.selectedLeaderboardType$));
    _angular_core__WEBPACK_IMPORTED_MODULE_14__["ɵɵadvance"](2);
    _angular_core__WEBPACK_IMPORTED_MODULE_14__["ɵɵproperty"]("ngForOf", _angular_core__WEBPACK_IMPORTED_MODULE_14__["ɵɵpipeBind1"](8, 13, ctx_r0.leaderboardTypes$));
    _angular_core__WEBPACK_IMPORTED_MODULE_14__["ɵɵadvance"](4);
    _angular_core__WEBPACK_IMPORTED_MODULE_14__["ɵɵtextInterpolate"](_angular_core__WEBPACK_IMPORTED_MODULE_14__["ɵɵpipeBind1"](12, 15, "campaigns.leaderboard.filter.period"));
    _angular_core__WEBPACK_IMPORTED_MODULE_14__["ɵɵadvance"](2);
    _angular_core__WEBPACK_IMPORTED_MODULE_14__["ɵɵproperty"]("value", _angular_core__WEBPACK_IMPORTED_MODULE_14__["ɵɵpipeBind1"](14, 17, ctx_r0.selectedPeriod$));
    _angular_core__WEBPACK_IMPORTED_MODULE_14__["ɵɵadvance"](2);
    _angular_core__WEBPACK_IMPORTED_MODULE_14__["ɵɵproperty"]("ngForOf", ctx_r0.periods);
    _angular_core__WEBPACK_IMPORTED_MODULE_14__["ɵɵadvance"](1);
    _angular_core__WEBPACK_IMPORTED_MODULE_14__["ɵɵproperty"]("placing", _angular_core__WEBPACK_IMPORTED_MODULE_14__["ɵɵpipeBind1"](17, 19, ctx_r0.playerPosition$))("unitLabelKey", _angular_core__WEBPACK_IMPORTED_MODULE_14__["ɵɵpipeBind1"](18, 21, ctx_r0.numberWithUnitKey$));
    _angular_core__WEBPACK_IMPORTED_MODULE_14__["ɵɵadvance"](3);
    _angular_core__WEBPACK_IMPORTED_MODULE_14__["ɵɵproperty"]("ngIf", _angular_core__WEBPACK_IMPORTED_MODULE_14__["ɵɵpipeBind1"](20, 23, ctx_r0.filterOptions$));
  }
}

var LeaderboardPage = /*#__PURE__*/function () {
  function LeaderboardPage(route, reportControllerService, userService, campaignService, errorService) {
    var _this = this;

    (0,_Users_smartcommunitylab_Documents_work_projects_dslab_playgo_mobile_playgo_mobile_node_modules_babel_runtime_helpers_esm_classCallCheck_js__WEBPACK_IMPORTED_MODULE_2__["default"])(this, LeaderboardPage);

    this.route = route;
    this.reportControllerService = reportControllerService;
    this.userService = userService;
    this.campaignService = campaignService;
    this.errorService = errorService;
    this.referenceDate = luxon__WEBPACK_IMPORTED_MODULE_15__.DateTime.local();
    this.periods = this.getPeriods(this.referenceDate);
    this.metricToNumberWithUnitLabel = {
      co2: 'campaigns.leaderboard.leaderboard_type_unit.co2',
      km: 'campaigns.leaderboard.leaderboard_type_unit.km'
    };
    this.metricToUnitLabel = {
      co2: 'campaigns.leaderboard.unit.co2',
      km: 'campaigns.leaderboard.unit.km'
    }; // we need to keep references the same, because they are used as select values.

    this.allLeaderboardTypes = [{
      labelKey: 'campaigns.leaderboard.leaderboard_type.GL',
      numberWithUnitKey: 'campaigns.leaderboard.leaderboard_type_unit.GL',
      filter: function filter(campaign) {
        return campaign.type === 'city' || campaign.type === 'school';
      },
      playerApi: function playerApi(args) {
        return _this.reportControllerService.getPlayerCampaingPlacingByGameUsingGET(args);
      },
      leaderboardApi: function leaderboardApi(args) {
        return _this.reportControllerService.getCampaingPlacingByGameUsingGET(args);
      }
    }, {
      labelKey: 'campaigns.leaderboard.leaderboard_type.co2',
      numberWithUnitKey: 'campaigns.leaderboard.leaderboard_type_unit.co2',
      filter: function filter(campaign) {
        return campaign.type !== 'school';
      },
      playerApi: function playerApi(args) {
        return _this.reportControllerService.getPlayerCampaingPlacingByTransportModeUsingGET(Object.assign(Object.assign({}, args), {
          mean: null,
          metric: 'co2'
        }));
      },
      leaderboardApi: function leaderboardApi(args) {
        return _this.reportControllerService.getCampaingPlacingByTransportStatsUsingGET(Object.assign(Object.assign({}, args), {
          mean: null,
          metric: 'co2'
        }));
      }
    }].concat((0,_Users_smartcommunitylab_Documents_work_projects_dslab_playgo_mobile_playgo_mobile_node_modules_babel_runtime_helpers_esm_toConsumableArray_js__WEBPACK_IMPORTED_MODULE_1__["default"])((0,src_app_core_shared_utils__WEBPACK_IMPORTED_MODULE_5__.cartesian)(src_app_core_shared_tracking_trip_model__WEBPACK_IMPORTED_MODULE_4__.transportTypes, ['co2', 'km']).map(function (_ref) {
      var _ref2 = (0,_Users_smartcommunitylab_Documents_work_projects_dslab_playgo_mobile_playgo_mobile_node_modules_babel_runtime_helpers_esm_slicedToArray_js__WEBPACK_IMPORTED_MODULE_0__["default"])(_ref, 2),
          transportType = _ref2[0],
          metric = _ref2[1];

      return {
        labelKey: src_app_core_shared_tracking_trip_model__WEBPACK_IMPORTED_MODULE_4__.transportTypeLabels[transportType],
        numberWithUnitKey: _this.metricToNumberWithUnitLabel[metric],
        unitLabelKey: _this.metricToUnitLabel[metric],
        filter: function filter(campaign) {
          return campaign.type !== 'school';
        },
        playerApi: function playerApi(args) {
          return _this.reportControllerService.getPlayerCampaingPlacingByTransportModeUsingGET(Object.assign(Object.assign({}, args), {
            mean: transportType,
            metric: metric
          }));
        },
        leaderboardApi: function leaderboardApi(args) {
          return _this.reportControllerService.getCampaingPlacingByTransportStatsUsingGET(Object.assign(Object.assign({}, args), {
            mean: transportType,
            metric: metric
          }));
        }
      };
    })));
    this.campaignId$ = this.route.params.pipe((0,rxjs_operators__WEBPACK_IMPORTED_MODULE_16__.map)(function (params) {
      return params.id;
    }), (0,rxjs_operators__WEBPACK_IMPORTED_MODULE_17__.distinctUntilChanged)(), (0,rxjs_operators__WEBPACK_IMPORTED_MODULE_18__.shareReplay)(1));
    this.campaign$ = this.campaignId$.pipe((0,rxjs_operators__WEBPACK_IMPORTED_MODULE_19__.switchMap)(function (campaignId) {
      return _this.campaignService.allCampaigns$.pipe((0,rxjs_operators__WEBPACK_IMPORTED_MODULE_16__.map)(function (campaigns) {
        return (0,lodash_es__WEBPACK_IMPORTED_MODULE_20__["default"])(campaigns, {
          campaignId: campaignId
        });
      }), (0,src_app_core_shared_utils__WEBPACK_IMPORTED_MODULE_5__.throwIfNil)(function () {
        return new Error('Campaign not found');
      }), _this.errorService.getErrorHandler());
    }), (0,rxjs_operators__WEBPACK_IMPORTED_MODULE_18__.shareReplay)(1));
    this.leaderboardTypes$ = this.campaign$.pipe((0,rxjs_operators__WEBPACK_IMPORTED_MODULE_16__.map)(function (campaign) {
      return _this.getLeaderboardTypes(campaign);
    }), (0,rxjs_operators__WEBPACK_IMPORTED_MODULE_18__.shareReplay)(1));
    this.leaderboardTypeChangedSubject = new rxjs__WEBPACK_IMPORTED_MODULE_21__.Subject();
    this.selectedLeaderboardType$ = this.leaderboardTypeChangedSubject.pipe((0,rxjs_operators__WEBPACK_IMPORTED_MODULE_16__.map)(function (event) {
      return event.detail.value;
    }), (0,src_app_core_shared_utils__WEBPACK_IMPORTED_MODULE_5__.startFrom)( // initial select value
    this.leaderboardTypes$.pipe((0,rxjs_operators__WEBPACK_IMPORTED_MODULE_22__.first)(), (0,rxjs_operators__WEBPACK_IMPORTED_MODULE_16__.map)(function (allLeaderboardTypes) {
      return allLeaderboardTypes[0];
    }))), (0,rxjs_operators__WEBPACK_IMPORTED_MODULE_18__.shareReplay)(1));
    this.numberWithUnitKey$ = this.selectedLeaderboardType$.pipe((0,rxjs_operators__WEBPACK_IMPORTED_MODULE_16__.map)(function (leaderboardType) {
      return leaderboardType.numberWithUnitKey;
    }), (0,rxjs_operators__WEBPACK_IMPORTED_MODULE_18__.shareReplay)(1));
    this.periodChangedSubject = new rxjs__WEBPACK_IMPORTED_MODULE_21__.Subject();
    this.selectedPeriod$ = this.periodChangedSubject.pipe((0,rxjs_operators__WEBPACK_IMPORTED_MODULE_16__.map)(function (event) {
      return event.detail.value;
    }), (0,rxjs_operators__WEBPACK_IMPORTED_MODULE_23__.startWith)((0,lodash_es__WEBPACK_IMPORTED_MODULE_20__["default"])(this.periods, {
      default: true
    })), // initial select value
    (0,rxjs_operators__WEBPACK_IMPORTED_MODULE_18__.shareReplay)(1));
    this.playerId$ = this.userService.userProfile$.pipe((0,rxjs_operators__WEBPACK_IMPORTED_MODULE_16__.map)(function (userProfile) {
      return userProfile.playerId;
    }));
    this.filterOptions$ = (0,rxjs__WEBPACK_IMPORTED_MODULE_24__.combineLatest)([this.selectedLeaderboardType$, this.selectedPeriod$, this.campaignId$, // FIXME: investigate why this is needed.
    this.playerId$.pipe((0,rxjs_operators__WEBPACK_IMPORTED_MODULE_17__.distinctUntilChanged)(lodash_es__WEBPACK_IMPORTED_MODULE_25__["default"]))]).pipe((0,rxjs_operators__WEBPACK_IMPORTED_MODULE_16__.map)(function (_ref3) {
      var _ref4 = (0,_Users_smartcommunitylab_Documents_work_projects_dslab_playgo_mobile_playgo_mobile_node_modules_babel_runtime_helpers_esm_slicedToArray_js__WEBPACK_IMPORTED_MODULE_0__["default"])(_ref3, 4),
          leaderboardType = _ref4[0],
          period = _ref4[1],
          campaignId = _ref4[2],
          playerId = _ref4[3];

      return {
        leaderboardType: leaderboardType,
        period: period,
        campaignId: campaignId,
        playerId: playerId
      };
    }));
    this.playerPosition$ = this.filterOptions$.pipe((0,rxjs_operators__WEBPACK_IMPORTED_MODULE_19__.switchMap)(function (_ref5) {
      var leaderboardType = _ref5.leaderboardType,
          period = _ref5.period,
          campaignId = _ref5.campaignId,
          playerId = _ref5.playerId;
      return bind(leaderboardType.playerApi, _this)({
        campaignId: campaignId,
        playerId: playerId,
        dateFrom: period.from,
        dateTo: period.to
      }).pipe(_this.errorService.getErrorHandler());
    }));
    this.scrollRequestSubject = new rxjs__WEBPACK_IMPORTED_MODULE_21__.Subject();
    this.leaderboardScrollResponse$ = this.filterOptions$.pipe((0,rxjs_operators__WEBPACK_IMPORTED_MODULE_19__.switchMap)(function (_ref6) {
      var leaderboardType = _ref6.leaderboardType,
          period = _ref6.period,
          campaignId = _ref6.campaignId;
      return _this.scrollRequestSubject.pipe((0,rxjs_operators__WEBPACK_IMPORTED_MODULE_23__.startWith)({
        page: 0,
        size: 10
      }), (0,rxjs_operators__WEBPACK_IMPORTED_MODULE_19__.switchMap)(function (_ref7) {
        var page = _ref7.page,
            size = _ref7.size;
        return bind(leaderboardType.leaderboardApi, _this.reportControllerService)({
          campaignId: campaignId,
          page: page,
          size: size,
          sort: null,
          dateFrom: period.from,
          dateTo: period.to
        }).pipe(_this.errorService.getErrorHandler());
      }));
    }));
    this.resetItems$ = this.filterOptions$.pipe((0,rxjs_operators__WEBPACK_IMPORTED_MODULE_16__.map)(function () {
      return Symbol();
    }));
  }

  (0,_Users_smartcommunitylab_Documents_work_projects_dslab_playgo_mobile_playgo_mobile_node_modules_babel_runtime_helpers_esm_createClass_js__WEBPACK_IMPORTED_MODULE_3__["default"])(LeaderboardPage, [{
    key: "getLeaderboardTypes",
    value: function getLeaderboardTypes(campaign) {
      return this.allLeaderboardTypes.filter(function (type) {
        return type.filter(campaign);
      });
    }
  }, {
    key: "getPeriods",
    value: function getPeriods(referenceDate) {
      return [{
        labelKey: 'campaigns.leaderboard.period.today',
        from: this.toServerDate(referenceDate.startOf('day')),
        to: this.toServerDate(referenceDate)
      }, {
        labelKey: 'campaigns.leaderboard.period.this_week',
        from: this.toServerDate(referenceDate.startOf('week')),
        to: this.toServerDate(referenceDate),
        default: true
      }, {
        labelKey: 'campaigns.leaderboard.period.this_month',
        from: this.toServerDate(referenceDate.startOf('month')),
        to: this.toServerDate(referenceDate)
      }, {
        labelKey: 'campaigns.leaderboard.period.all_time',
        // not specifying dates, will improve the server performance because of special handling
        // but we will lose the confidence that player position and leaderboard are in sync.
        // maybe it is not such deal, "All Time" leaderboard will not change so rapidly.
        from: null,
        to: null //this.toServerDate(referenceDate),

      }];
    }
  }, {
    key: "toServerDate",
    value: function toServerDate(dateTime) {
      // TODO: This is actually quite tricky bug.
      // When we round reference date to the start of the day, than we get this period
      // from beginning of the day to now, where events affecting this period will
      // cause inconsistent data between the loaded pages of pagination.
      return (0,src_app_core_shared_time_utils__WEBPACK_IMPORTED_MODULE_6__.toServerDateOnly)(dateTime);
    }
  }, {
    key: "ngOnInit",
    value: function ngOnInit() {}
  }, {
    key: "ngAfterViewInit",
    value: function ngAfterViewInit() {
      var selects = document.querySelectorAll('.app-alert');
      selects.forEach(function (select) {
        select.interfaceOptions = {
          cssClass: 'app-alert'
        };
      });
    }
  }]);

  return LeaderboardPage;
}();

LeaderboardPage.ɵfac = function LeaderboardPage_Factory(t) {
  return new (t || LeaderboardPage)(_angular_core__WEBPACK_IMPORTED_MODULE_14__["ɵɵdirectiveInject"](_angular_router__WEBPACK_IMPORTED_MODULE_26__.ActivatedRoute), _angular_core__WEBPACK_IMPORTED_MODULE_14__["ɵɵdirectiveInject"](src_app_core_api_generated_controllers_reportController_service__WEBPACK_IMPORTED_MODULE_7__.ReportControllerService), _angular_core__WEBPACK_IMPORTED_MODULE_14__["ɵɵdirectiveInject"](src_app_core_shared_services_user_service__WEBPACK_IMPORTED_MODULE_8__.UserService), _angular_core__WEBPACK_IMPORTED_MODULE_14__["ɵɵdirectiveInject"](src_app_core_shared_services_campaign_service__WEBPACK_IMPORTED_MODULE_9__.CampaignService), _angular_core__WEBPACK_IMPORTED_MODULE_14__["ɵɵdirectiveInject"](src_app_core_shared_services_error_service__WEBPACK_IMPORTED_MODULE_10__.ErrorService));
};

LeaderboardPage.ɵcmp = /*@__PURE__*/_angular_core__WEBPACK_IMPORTED_MODULE_14__["ɵɵdefineComponent"]({
  type: LeaderboardPage,
  selectors: [["app-leaderboard"]],
  decls: 4,
  vars: 3,
  consts: [["appHeader", ""], [4, "ngIf"], ["color", "playgo"], [1, "app-alert", 3, "value", "ionChange"], [3, "value", 4, "ngFor", "ngForOf"], [3, "placing", "unitLabelKey"], [3, "value"], [3, "resetItems", "response", "request"], ["appInfiniteScrollContent", ""]],
  template: function LeaderboardPage_Template(rf, ctx) {
    if (rf & 1) {
      _angular_core__WEBPACK_IMPORTED_MODULE_14__["ɵɵelement"](0, "ion-header", 0);
      _angular_core__WEBPACK_IMPORTED_MODULE_14__["ɵɵelementStart"](1, "ion-content");
      _angular_core__WEBPACK_IMPORTED_MODULE_14__["ɵɵtemplate"](2, LeaderboardPage_ng_container_2_Template, 21, 25, "ng-container", 1);
      _angular_core__WEBPACK_IMPORTED_MODULE_14__["ɵɵpipe"](3, "async");
      _angular_core__WEBPACK_IMPORTED_MODULE_14__["ɵɵelementEnd"]();
    }

    if (rf & 2) {
      _angular_core__WEBPACK_IMPORTED_MODULE_14__["ɵɵadvance"](2);
      _angular_core__WEBPACK_IMPORTED_MODULE_14__["ɵɵproperty"]("ngIf", _angular_core__WEBPACK_IMPORTED_MODULE_14__["ɵɵpipeBind1"](3, 1, ctx.campaign$) !== null);
    }
  },
  directives: [_ionic_angular__WEBPACK_IMPORTED_MODULE_27__.IonHeader, _core_shared_layout_header_header_directive__WEBPACK_IMPORTED_MODULE_11__.HeaderDirective, _ionic_angular__WEBPACK_IMPORTED_MODULE_27__.IonContent, _angular_common__WEBPACK_IMPORTED_MODULE_28__.NgIf, _ionic_angular__WEBPACK_IMPORTED_MODULE_27__.IonItem, _ionic_angular__WEBPACK_IMPORTED_MODULE_27__.IonLabel, _ionic_angular__WEBPACK_IMPORTED_MODULE_27__.IonSelect, _ionic_angular__WEBPACK_IMPORTED_MODULE_27__.SelectValueAccessor, _angular_common__WEBPACK_IMPORTED_MODULE_28__.NgForOf, _ionic_angular__WEBPACK_IMPORTED_MODULE_27__.IonSelectOption, _placing_detail_placing_detail_component__WEBPACK_IMPORTED_MODULE_12__.PlacingDetailComponent, _core_shared_infinite_scroll_infinite_scroll_component__WEBPACK_IMPORTED_MODULE_13__.InfiniteScrollComponent, _core_shared_infinite_scroll_infinite_scroll_component__WEBPACK_IMPORTED_MODULE_13__.InfiniteScrollContentDirective],
  pipes: [_angular_common__WEBPACK_IMPORTED_MODULE_28__.AsyncPipe, _ngx_translate_core__WEBPACK_IMPORTED_MODULE_29__.TranslatePipe],
  styles: ["\n/*# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbXSwibmFtZXMiOltdLCJtYXBwaW5ncyI6IiIsImZpbGUiOiJsZWFkZXJib2FyZC5wYWdlLnNjc3MifQ== */"]
});

function bind(f, thisValue) {
  return f.bind(thisValue);
}

function isType(campaign) {
  for (var _len = arguments.length, type = new Array(_len > 1 ? _len - 1 : 0), _key = 1; _key < _len; _key++) {
    type[_key - 1] = arguments[_key];
  }

  return type.some(function (t) {
    return campaign.type === t;
  });
}

/***/ }),

/***/ 21461:
/*!****************************************************************************************!*\
  !*** ./src/app/pages/campaigns/leaderboard/placing-detail/placing-detail.component.ts ***!
  \****************************************************************************************/
/***/ (function(__unused_webpack_module, __webpack_exports__, __webpack_require__) {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "PlacingDetailComponent": function() { return /* binding */ PlacingDetailComponent; }
/* harmony export */ });
/* harmony import */ var _Users_smartcommunitylab_Documents_work_projects_dslab_playgo_mobile_playgo_mobile_node_modules_babel_runtime_helpers_esm_classCallCheck_js__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./node_modules/@babel/runtime/helpers/esm/classCallCheck.js */ 78069);
/* harmony import */ var _Users_smartcommunitylab_Documents_work_projects_dslab_playgo_mobile_playgo_mobile_node_modules_babel_runtime_helpers_esm_createClass_js__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ./node_modules/@babel/runtime/helpers/esm/createClass.js */ 48047);
/* harmony import */ var rxjs_operators__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! rxjs/operators */ 50635);
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! @angular/core */ 3184);
/* harmony import */ var src_app_core_shared_services_user_service__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! src/app/core/shared/services/user.service */ 50749);
/* harmony import */ var _angular_common__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(/*! @angular/common */ 36362);
/* harmony import */ var _ionic_angular__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(/*! @ionic/angular */ 93819);
/* harmony import */ var _angular_router__WEBPACK_IMPORTED_MODULE_9__ = __webpack_require__(/*! @angular/router */ 52816);
/* harmony import */ var _core_shared_globalization_ordinal_number_ordinal_number_component__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! ../../../../core/shared/globalization/ordinal-number/ordinal-number.component */ 56032);
/* harmony import */ var _ngx_translate_core__WEBPACK_IMPORTED_MODULE_10__ = __webpack_require__(/*! @ngx-translate/core */ 87514);
/* harmony import */ var _core_shared_pipes_localNumber_pipe__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! ../../../../core/shared/pipes/localNumber.pipe */ 89713);












function PlacingDetailComponent_ion_item_0_ng_container_5_Template(rf, ctx) {
  if (rf & 1) {
    _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵelementContainerStart"](0);
    _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵelementStart"](1, "ion-avatar");
    _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵelement"](2, "img", 4);
    _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵpipe"](3, "async");
    _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵelementEnd"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵelementContainerEnd"]();
  }

  if (rf & 2) {
    var ctx_r1 = _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵnextContext"](2);
    _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵadvance"](2);
    _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵproperty"]("src", _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵpipeBind1"](3, 1, ctx_r1.playerAvatarUrl$), _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵsanitizeUrl"]);
  }
}

function PlacingDetailComponent_ion_item_0_ng_container_7_ion_avatar_1_Template(rf, ctx) {
  if (rf & 1) {
    _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵelementStart"](0, "ion-avatar");
    _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵelement"](1, "img", 4);
    _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵelementEnd"]();
  }

  if (rf & 2) {
    var ctx_r3 = _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵnextContext"](3);
    _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵadvance"](1);
    _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵproperty"]("src", ctx_r3.placing.avatar.url, _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵsanitizeUrl"]);
  }
}

function PlacingDetailComponent_ion_item_0_ng_container_7_Template(rf, ctx) {
  if (rf & 1) {
    _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵelementContainerStart"](0);
    _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵtemplate"](1, PlacingDetailComponent_ion_item_0_ng_container_7_ion_avatar_1_Template, 2, 1, "ion-avatar", 3);
    _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵelementContainerEnd"]();
  }

  if (rf & 2) {
    var ctx_r2 = _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵnextContext"](2);
    _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵadvance"](1);
    _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵproperty"]("ngIf", ctx_r2.placing.avatar);
  }
}

var _c0 = function _c0(a0) {
  return [a0];
};

var _c1 = function _c1() {
  return [];
};

var _c2 = function _c2(a0) {
  return {
    value: a0
  };
};

function PlacingDetailComponent_ion_item_0_Template(rf, ctx) {
  if (rf & 1) {
    _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵelementStart"](0, "ion-item", 1);
    _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵpipe"](1, "async");
    _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵpipe"](2, "async");
    _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵelementStart"](3, "ion-label");
    _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵelement"](4, "app-ordinal-number", 2);
    _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵelementEnd"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵtemplate"](5, PlacingDetailComponent_ion_item_0_ng_container_5_Template, 4, 3, "ng-container", 3);
    _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵpipe"](6, "async");
    _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵtemplate"](7, PlacingDetailComponent_ion_item_0_ng_container_7_Template, 2, 1, "ng-container", 3);
    _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵpipe"](8, "async");
    _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵtext"](9);
    _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵpipe"](10, "translate");
    _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵpipe"](11, "localNumber");
    _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵelementEnd"]();
  }

  if (rf & 2) {
    var ctx_r0 = _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵnextContext"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵclassProp"]("my-placing", _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵpipeBind1"](1, 8, ctx_r0.playerId$) === ctx_r0.placing.playerId);
    _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵproperty"]("routerLink", _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵpipeBind1"](2, 10, ctx_r0.playerId$) !== ctx_r0.placing.playerId ? _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵpureFunction1"](21, _c0, "/pages/user-profile/" + ctx_r0.placing.playerId + "/" + ctx_r0.placing.nickname) : _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵpureFunction0"](23, _c1));
    _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵadvance"](4);
    _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵproperty"]("value", ctx_r0.placing.position);
    _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵadvance"](1);
    _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵproperty"]("ngIf", _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵpipeBind1"](6, 12, ctx_r0.playerId$) === ctx_r0.placing.playerId);
    _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵadvance"](2);
    _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵproperty"]("ngIf", _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵpipeBind1"](8, 14, ctx_r0.playerId$) !== ctx_r0.placing.playerId);
    _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵadvance"](2);
    _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵtextInterpolate2"](" ", ctx_r0.placing.nickname, " ", _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵpipeBind2"](10, 16, ctx_r0.unitLabelKey, _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵpureFunction1"](24, _c2, _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵpipeBind1"](11, 19, ctx_r0.placing.value))), "\n");
  }
}

var PlacingDetailComponent = /*#__PURE__*/function () {
  function PlacingDetailComponent(userService) {
    (0,_Users_smartcommunitylab_Documents_work_projects_dslab_playgo_mobile_playgo_mobile_node_modules_babel_runtime_helpers_esm_classCallCheck_js__WEBPACK_IMPORTED_MODULE_0__["default"])(this, PlacingDetailComponent);

    this.userService = userService;
    this.playerId$ = this.userService.userProfile$.pipe((0,rxjs_operators__WEBPACK_IMPORTED_MODULE_6__.map)(function (userProfile) {
      return userProfile.playerId;
    }));
    this.playerAvatarUrl$ = this.userService.userProfile$.pipe((0,rxjs_operators__WEBPACK_IMPORTED_MODULE_6__.map)(function (userProfile) {
      return userProfile.avatar.avatarSmallUrl;
    }));
  }

  (0,_Users_smartcommunitylab_Documents_work_projects_dslab_playgo_mobile_playgo_mobile_node_modules_babel_runtime_helpers_esm_createClass_js__WEBPACK_IMPORTED_MODULE_1__["default"])(PlacingDetailComponent, [{
    key: "ngOnInit",
    value: function ngOnInit() {}
  }]);

  return PlacingDetailComponent;
}();

PlacingDetailComponent.ɵfac = function PlacingDetailComponent_Factory(t) {
  return new (t || PlacingDetailComponent)(_angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵdirectiveInject"](src_app_core_shared_services_user_service__WEBPACK_IMPORTED_MODULE_2__.UserService));
};

PlacingDetailComponent.ɵcmp = /*@__PURE__*/_angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵdefineComponent"]({
  type: PlacingDetailComponent,
  selectors: [["app-placing-detail"]],
  inputs: {
    placing: "placing",
    unitLabelKey: "unitLabelKey"
  },
  decls: 1,
  vars: 1,
  consts: [["detail", "false", 3, "my-placing", "routerLink", 4, "ngIf"], ["detail", "false", 3, "routerLink"], [3, "value"], [4, "ngIf"], [3, "src"]],
  template: function PlacingDetailComponent_Template(rf, ctx) {
    if (rf & 1) {
      _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵtemplate"](0, PlacingDetailComponent_ion_item_0_Template, 12, 26, "ion-item", 0);
    }

    if (rf & 2) {
      _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵproperty"]("ngIf", ctx.placing);
    }
  },
  directives: [_angular_common__WEBPACK_IMPORTED_MODULE_7__.NgIf, _ionic_angular__WEBPACK_IMPORTED_MODULE_8__.IonItem, _angular_router__WEBPACK_IMPORTED_MODULE_9__.RouterLink, _ionic_angular__WEBPACK_IMPORTED_MODULE_8__.RouterLinkDelegate, _ionic_angular__WEBPACK_IMPORTED_MODULE_8__.IonLabel, _core_shared_globalization_ordinal_number_ordinal_number_component__WEBPACK_IMPORTED_MODULE_3__.OrdinalNumberComponent, _ionic_angular__WEBPACK_IMPORTED_MODULE_8__.IonAvatar],
  pipes: [_angular_common__WEBPACK_IMPORTED_MODULE_7__.AsyncPipe, _ngx_translate_core__WEBPACK_IMPORTED_MODULE_10__.TranslatePipe, _core_shared_pipes_localNumber_pipe__WEBPACK_IMPORTED_MODULE_4__.LocalNumberPipe],
  styles: [".my-placing[_ngcontent-%COMP%] {\n  font-weight: bold;\n}\n/*# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbInBsYWNpbmctZGV0YWlsLmNvbXBvbmVudC5zY3NzIl0sIm5hbWVzIjpbXSwibWFwcGluZ3MiOiJBQUFBO0VBQ0UsaUJBQUE7QUFDRiIsImZpbGUiOiJwbGFjaW5nLWRldGFpbC5jb21wb25lbnQuc2NzcyIsInNvdXJjZXNDb250ZW50IjpbIi5teS1wbGFjaW5nIHtcbiAgZm9udC13ZWlnaHQ6IGJvbGQ7XG59XG4iXX0= */"]
});

/***/ })

}]);
//# sourceMappingURL=src_app_pages_campaigns_leaderboard_leaderboard_module_ts.js.map