"use strict";
(self["webpackChunkapp"] = self["webpackChunkapp"] || []).push([["default-src_app_pages_home_campaign-details_campaign-details_module_ts"],{

/***/ 92310:
/*!********************************************************************************!*\
  !*** ./src/app/pages/home/campaign-details/campaign-details-routing.module.ts ***!
  \********************************************************************************/
/***/ (function(__unused_webpack_module, __webpack_exports__, __webpack_require__) {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "CampaignDetailsPageRoutingModule": function() { return /* binding */ CampaignDetailsPageRoutingModule; }
/* harmony export */ });
/* harmony import */ var _Users_smartcommunitylab_Documents_work_projects_dslab_playgo_mobile_playgo_mobile_node_modules_babel_runtime_helpers_esm_createClass_js__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./node_modules/@babel/runtime/helpers/esm/createClass.js */ 48047);
/* harmony import */ var _Users_smartcommunitylab_Documents_work_projects_dslab_playgo_mobile_playgo_mobile_node_modules_babel_runtime_helpers_esm_classCallCheck_js__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ./node_modules/@babel/runtime/helpers/esm/classCallCheck.js */ 78069);
/* harmony import */ var _angular_router__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! @angular/router */ 52816);
/* harmony import */ var _campaign_details_page__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! ./campaign-details.page */ 69003);
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @angular/core */ 3184);






var routes = [{
  path: '',
  component: _campaign_details_page__WEBPACK_IMPORTED_MODULE_2__.CampaignDetailsPage,
  data: {
    title: '',
    customHeader: true,
    showPlayButton: true,
    backButton: true
  }
}, {
  path: 'leaderboard',
  loadChildren: function loadChildren() {
    return __webpack_require__.e(/*! import() */ "src_app_pages_home_campaign-details_leaderboard_leaderboard_module_ts").then(__webpack_require__.bind(__webpack_require__, /*! ./leaderboard/leaderboard.module */ 28285)).then(function (m) {
      return m.LeaderboardModule;
    });
  }
}, {
  path: 'school-leaderboard',
  loadChildren: function loadChildren() {
    return __webpack_require__.e(/*! import() */ "src_app_pages_home_campaign-details_school-leaderboard_school-leaderboard_module_ts").then(__webpack_require__.bind(__webpack_require__, /*! ./school-leaderboard/school-leaderboard.module */ 67379)).then(function (m) {
      return m.SchoolLeaderboardPageModule;
    });
  }
}, {
  path: 'stats',
  loadChildren: function loadChildren() {
    return Promise.all(/*! import() */[__webpack_require__.e("default-node_modules_chart_js_dist_chart_esm_js"), __webpack_require__.e("common"), __webpack_require__.e("src_app_pages_home_campaign-details_stats_stats_module_ts")]).then(__webpack_require__.bind(__webpack_require__, /*! ./stats/stats.module */ 18533)).then(function (m) {
      return m.StatsPageModule;
    });
  }
}, {
  path: 'stats-team',
  loadChildren: function loadChildren() {
    return Promise.all(/*! import() */[__webpack_require__.e("default-node_modules_chart_js_dist_chart_esm_js"), __webpack_require__.e("common"), __webpack_require__.e("src_app_pages_home_campaign-details_stats-team_stats-team_module_ts")]).then(__webpack_require__.bind(__webpack_require__, /*! ./stats-team/stats-team.module */ 1346)).then(function (m) {
      return m.StatsTeamPageModule;
    });
  }
}, {
  path: 'faq',
  loadChildren: function loadChildren() {
    return __webpack_require__.e(/*! import() */ "src_app_pages_home_campaign-details_faq_faq_module_ts").then(__webpack_require__.bind(__webpack_require__, /*! ./faq/faq.module */ 35959)).then(function (m) {
      return m.FaqPageModule;
    });
  }
}, {
  path: 'badges',
  loadChildren: function loadChildren() {
    return __webpack_require__.e(/*! import() */ "src_app_pages_home_campaign-details_badges_badges_module_ts").then(__webpack_require__.bind(__webpack_require__, /*! ./badges/badges.module */ 31573)).then(function (m) {
      return m.BadgesPageModule;
    });
  }
}, {
  path: 'companies',
  loadChildren: function loadChildren() {
    return __webpack_require__.e(/*! import() */ "src_app_pages_home_campaign-details_companies_companies_module_ts").then(__webpack_require__.bind(__webpack_require__, /*! ./companies/companies.module */ 95177)).then(function (m) {
      return m.CompaniesPageModule;
    });
  }
}];
var CampaignDetailsPageRoutingModule = /*#__PURE__*/(0,_Users_smartcommunitylab_Documents_work_projects_dslab_playgo_mobile_playgo_mobile_node_modules_babel_runtime_helpers_esm_createClass_js__WEBPACK_IMPORTED_MODULE_0__["default"])(function CampaignDetailsPageRoutingModule() {
  (0,_Users_smartcommunitylab_Documents_work_projects_dslab_playgo_mobile_playgo_mobile_node_modules_babel_runtime_helpers_esm_classCallCheck_js__WEBPACK_IMPORTED_MODULE_1__["default"])(this, CampaignDetailsPageRoutingModule);
});

CampaignDetailsPageRoutingModule.ɵfac = function CampaignDetailsPageRoutingModule_Factory(t) {
  return new (t || CampaignDetailsPageRoutingModule)();
};

CampaignDetailsPageRoutingModule.ɵmod = /*@__PURE__*/_angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵdefineNgModule"]({
  type: CampaignDetailsPageRoutingModule
});
CampaignDetailsPageRoutingModule.ɵinj = /*@__PURE__*/_angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵdefineInjector"]({
  imports: [[_angular_router__WEBPACK_IMPORTED_MODULE_4__.RouterModule.forChild(routes)], _angular_router__WEBPACK_IMPORTED_MODULE_4__.RouterModule]
});

(function () {
  (typeof ngJitMode === "undefined" || ngJitMode) && _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵsetNgModuleScope"](CampaignDetailsPageRoutingModule, {
    imports: [_angular_router__WEBPACK_IMPORTED_MODULE_4__.RouterModule],
    exports: [_angular_router__WEBPACK_IMPORTED_MODULE_4__.RouterModule]
  });
})();

/***/ }),

/***/ 51818:
/*!************************************************************************!*\
  !*** ./src/app/pages/home/campaign-details/campaign-details.module.ts ***!
  \************************************************************************/
/***/ (function(__unused_webpack_module, __webpack_exports__, __webpack_require__) {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "CampaignDetailsPageModule": function() { return /* binding */ CampaignDetailsPageModule; }
/* harmony export */ });
/* harmony import */ var _Users_smartcommunitylab_Documents_work_projects_dslab_playgo_mobile_playgo_mobile_node_modules_babel_runtime_helpers_esm_createClass_js__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./node_modules/@babel/runtime/helpers/esm/createClass.js */ 48047);
/* harmony import */ var _Users_smartcommunitylab_Documents_work_projects_dslab_playgo_mobile_playgo_mobile_node_modules_babel_runtime_helpers_esm_classCallCheck_js__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ./node_modules/@babel/runtime/helpers/esm/classCallCheck.js */ 78069);
/* harmony import */ var _campaign_details_routing_module__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! ./campaign-details-routing.module */ 92310);
/* harmony import */ var _campaign_details_page__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! ./campaign-details.page */ 69003);
/* harmony import */ var src_app_core_shared_shared_module__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! src/app/core/shared/shared.module */ 97205);
/* harmony import */ var _detail_modal_detail_modal__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! ./detail-modal/detail.modal */ 30451);
/* harmony import */ var _campaign_notification_campaign_notification_component__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! ./campaign-notification/campaign-notification.component */ 48058);
/* harmony import */ var _unsubscribe_modal_unsubscribe_modal__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(/*! ./unsubscribe-modal/unsubscribe.modal */ 57164);
/* harmony import */ var _companies_modal_companies_modal__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(/*! ./companies-modal/companies.modal */ 88043);
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_9__ = __webpack_require__(/*! @angular/core */ 3184);










var CampaignDetailsPageModule = /*#__PURE__*/(0,_Users_smartcommunitylab_Documents_work_projects_dslab_playgo_mobile_playgo_mobile_node_modules_babel_runtime_helpers_esm_createClass_js__WEBPACK_IMPORTED_MODULE_0__["default"])(function CampaignDetailsPageModule() {
  (0,_Users_smartcommunitylab_Documents_work_projects_dslab_playgo_mobile_playgo_mobile_node_modules_babel_runtime_helpers_esm_classCallCheck_js__WEBPACK_IMPORTED_MODULE_1__["default"])(this, CampaignDetailsPageModule);
});

CampaignDetailsPageModule.ɵfac = function CampaignDetailsPageModule_Factory(t) {
  return new (t || CampaignDetailsPageModule)();
};

CampaignDetailsPageModule.ɵmod = /*@__PURE__*/_angular_core__WEBPACK_IMPORTED_MODULE_9__["ɵɵdefineNgModule"]({
  type: CampaignDetailsPageModule
});
CampaignDetailsPageModule.ɵinj = /*@__PURE__*/_angular_core__WEBPACK_IMPORTED_MODULE_9__["ɵɵdefineInjector"]({
  imports: [[_campaign_details_routing_module__WEBPACK_IMPORTED_MODULE_2__.CampaignDetailsPageRoutingModule, src_app_core_shared_shared_module__WEBPACK_IMPORTED_MODULE_4__.PlayGoSharedModule]]
});

(function () {
  (typeof ngJitMode === "undefined" || ngJitMode) && _angular_core__WEBPACK_IMPORTED_MODULE_9__["ɵɵsetNgModuleScope"](CampaignDetailsPageModule, {
    declarations: [_campaign_details_page__WEBPACK_IMPORTED_MODULE_3__.CampaignDetailsPage, _detail_modal_detail_modal__WEBPACK_IMPORTED_MODULE_5__.DetailCampaignModalPage, _companies_modal_companies_modal__WEBPACK_IMPORTED_MODULE_8__.CompaniesCampaignModalPage, _campaign_notification_campaign_notification_component__WEBPACK_IMPORTED_MODULE_6__.CampaignNotificationComponent, _unsubscribe_modal_unsubscribe_modal__WEBPACK_IMPORTED_MODULE_7__.UnsubscribeModalPage],
    imports: [_campaign_details_routing_module__WEBPACK_IMPORTED_MODULE_2__.CampaignDetailsPageRoutingModule, src_app_core_shared_shared_module__WEBPACK_IMPORTED_MODULE_4__.PlayGoSharedModule]
  });
})();

/***/ }),

/***/ 69003:
/*!**********************************************************************!*\
  !*** ./src/app/pages/home/campaign-details/campaign-details.page.ts ***!
  \**********************************************************************/
/***/ (function(__unused_webpack_module, __webpack_exports__, __webpack_require__) {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "CampaignDetailsPage": function() { return /* binding */ CampaignDetailsPage; }
/* harmony export */ });
/* harmony import */ var _Users_smartcommunitylab_Documents_work_projects_dslab_playgo_mobile_playgo_mobile_node_modules_babel_runtime_helpers_esm_slicedToArray_js__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./node_modules/@babel/runtime/helpers/esm/slicedToArray.js */ 10507);
/* harmony import */ var _Users_smartcommunitylab_Documents_work_projects_dslab_playgo_mobile_playgo_mobile_node_modules_babel_runtime_helpers_esm_classCallCheck_js__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ./node_modules/@babel/runtime/helpers/esm/classCallCheck.js */ 78069);
/* harmony import */ var _Users_smartcommunitylab_Documents_work_projects_dslab_playgo_mobile_playgo_mobile_node_modules_babel_runtime_helpers_esm_createClass_js__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! ./node_modules/@babel/runtime/helpers/esm/createClass.js */ 48047);
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_35__ = __webpack_require__(/*! tslib */ 34929);
/* harmony import */ var _detail_modal_detail_modal__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! ./detail-modal/detail.modal */ 30451);
/* harmony import */ var rxjs__WEBPACK_IMPORTED_MODULE_24__ = __webpack_require__(/*! rxjs */ 80228);
/* harmony import */ var rxjs__WEBPACK_IMPORTED_MODULE_25__ = __webpack_require__(/*! rxjs */ 50635);
/* harmony import */ var rxjs__WEBPACK_IMPORTED_MODULE_26__ = __webpack_require__(/*! rxjs */ 98977);
/* harmony import */ var rxjs__WEBPACK_IMPORTED_MODULE_27__ = __webpack_require__(/*! rxjs */ 89196);
/* harmony import */ var rxjs__WEBPACK_IMPORTED_MODULE_28__ = __webpack_require__(/*! rxjs */ 32673);
/* harmony import */ var rxjs__WEBPACK_IMPORTED_MODULE_30__ = __webpack_require__(/*! rxjs */ 19337);
/* harmony import */ var rxjs__WEBPACK_IMPORTED_MODULE_31__ = __webpack_require__(/*! rxjs */ 26562);
/* harmony import */ var rxjs__WEBPACK_IMPORTED_MODULE_32__ = __webpack_require__(/*! rxjs */ 20591);
/* harmony import */ var rxjs__WEBPACK_IMPORTED_MODULE_33__ = __webpack_require__(/*! rxjs */ 68951);
/* harmony import */ var rxjs__WEBPACK_IMPORTED_MODULE_34__ = __webpack_require__(/*! rxjs */ 10745);
/* harmony import */ var _unsubscribe_modal_unsubscribe_modal__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! ./unsubscribe-modal/unsubscribe.modal */ 57164);
/* harmony import */ var src_app_core_shared_rxjs_utils__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! src/app/core/shared/rxjs.utils */ 9257);
/* harmony import */ var src_environments_environment__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! src/environments/environment */ 92340);
/* harmony import */ var src_app_core_shared_services_error_service__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(/*! src/app/core/shared/services/error.service */ 96204);
/* harmony import */ var _companies_modal_companies_modal__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(/*! ./companies-modal/companies.modal */ 88043);
/* harmony import */ var lodash_es__WEBPACK_IMPORTED_MODULE_29__ = __webpack_require__(/*! lodash-es */ 97732);
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_23__ = __webpack_require__(/*! @angular/core */ 3184);
/* harmony import */ var _angular_router__WEBPACK_IMPORTED_MODULE_36__ = __webpack_require__(/*! @angular/router */ 52816);
/* harmony import */ var src_app_core_shared_services_campaign_service__WEBPACK_IMPORTED_MODULE_9__ = __webpack_require__(/*! src/app/core/shared/services/campaign.service */ 23645);
/* harmony import */ var src_app_core_shared_services_alert_service__WEBPACK_IMPORTED_MODULE_10__ = __webpack_require__(/*! src/app/core/shared/services/alert.service */ 46407);
/* harmony import */ var src_app_core_shared_services_user_service__WEBPACK_IMPORTED_MODULE_11__ = __webpack_require__(/*! src/app/core/shared/services/user.service */ 50749);
/* harmony import */ var _ionic_angular__WEBPACK_IMPORTED_MODULE_37__ = __webpack_require__(/*! @ionic/angular */ 93819);
/* harmony import */ var src_app_core_shared_services_notifications_notifications_service__WEBPACK_IMPORTED_MODULE_12__ = __webpack_require__(/*! src/app/core/shared/services/notifications/notifications.service */ 30299);
/* harmony import */ var src_app_core_shared_services_page_settings_service__WEBPACK_IMPORTED_MODULE_13__ = __webpack_require__(/*! src/app/core/shared/services/page-settings.service */ 85294);
/* harmony import */ var src_app_core_shared_services_team_service__WEBPACK_IMPORTED_MODULE_14__ = __webpack_require__(/*! src/app/core/shared/services/team.service */ 86612);
/* harmony import */ var _angular_common__WEBPACK_IMPORTED_MODULE_38__ = __webpack_require__(/*! @angular/common */ 36362);
/* harmony import */ var _core_shared_directives_parallax_header_directive__WEBPACK_IMPORTED_MODULE_15__ = __webpack_require__(/*! ../../../core/shared/directives/parallax-header.directive */ 2773);
/* harmony import */ var _core_shared_layout_header_header_directive__WEBPACK_IMPORTED_MODULE_16__ = __webpack_require__(/*! ../../../core/shared/layout/header/header.directive */ 34161);
/* harmony import */ var _core_shared_layout_content_content_directive__WEBPACK_IMPORTED_MODULE_17__ = __webpack_require__(/*! ../../../core/shared/layout/content/content.directive */ 69669);
/* harmony import */ var _core_shared_campaigns_app_widget_campaign_app_widget_campaign_component__WEBPACK_IMPORTED_MODULE_18__ = __webpack_require__(/*! ../../../core/shared/campaigns/app-widget-campaign/app-widget-campaign.component */ 519);
/* harmony import */ var _campaign_notification_campaign_notification_component__WEBPACK_IMPORTED_MODULE_19__ = __webpack_require__(/*! ./campaign-notification/campaign-notification.component */ 48058);
/* harmony import */ var _core_shared_ui_icon_icon_component__WEBPACK_IMPORTED_MODULE_20__ = __webpack_require__(/*! ../../../core/shared/ui/icon/icon.component */ 71888);
/* harmony import */ var _ngx_translate_core__WEBPACK_IMPORTED_MODULE_39__ = __webpack_require__(/*! @ngx-translate/core */ 87514);
/* harmony import */ var _core_shared_pipes_localDate_pipe__WEBPACK_IMPORTED_MODULE_21__ = __webpack_require__(/*! ../../../core/shared/pipes/localDate.pipe */ 34489);
/* harmony import */ var _core_shared_pipes_languageMap_pipe__WEBPACK_IMPORTED_MODULE_22__ = __webpack_require__(/*! ../../../core/shared/pipes/languageMap.pipe */ 73088);




function _regeneratorRuntime() { "use strict"; /*! regenerator-runtime -- Copyright (c) 2014-present, Facebook, Inc. -- license (MIT): https://github.com/facebook/regenerator/blob/main/LICENSE */ _regeneratorRuntime = function _regeneratorRuntime() { return exports; }; var exports = {}, Op = Object.prototype, hasOwn = Op.hasOwnProperty, $Symbol = "function" == typeof Symbol ? Symbol : {}, iteratorSymbol = $Symbol.iterator || "@@iterator", asyncIteratorSymbol = $Symbol.asyncIterator || "@@asyncIterator", toStringTagSymbol = $Symbol.toStringTag || "@@toStringTag"; function define(obj, key, value) { return Object.defineProperty(obj, key, { value: value, enumerable: !0, configurable: !0, writable: !0 }), obj[key]; } try { define({}, ""); } catch (err) { define = function define(obj, key, value) { return obj[key] = value; }; } function wrap(innerFn, outerFn, self, tryLocsList) { var protoGenerator = outerFn && outerFn.prototype instanceof Generator ? outerFn : Generator, generator = Object.create(protoGenerator.prototype), context = new Context(tryLocsList || []); return generator._invoke = function (innerFn, self, context) { var state = "suspendedStart"; return function (method, arg) { if ("executing" === state) throw new Error("Generator is already running"); if ("completed" === state) { if ("throw" === method) throw arg; return doneResult(); } for (context.method = method, context.arg = arg;;) { var delegate = context.delegate; if (delegate) { var delegateResult = maybeInvokeDelegate(delegate, context); if (delegateResult) { if (delegateResult === ContinueSentinel) continue; return delegateResult; } } if ("next" === context.method) context.sent = context._sent = context.arg;else if ("throw" === context.method) { if ("suspendedStart" === state) throw state = "completed", context.arg; context.dispatchException(context.arg); } else "return" === context.method && context.abrupt("return", context.arg); state = "executing"; var record = tryCatch(innerFn, self, context); if ("normal" === record.type) { if (state = context.done ? "completed" : "suspendedYield", record.arg === ContinueSentinel) continue; return { value: record.arg, done: context.done }; } "throw" === record.type && (state = "completed", context.method = "throw", context.arg = record.arg); } }; }(innerFn, self, context), generator; } function tryCatch(fn, obj, arg) { try { return { type: "normal", arg: fn.call(obj, arg) }; } catch (err) { return { type: "throw", arg: err }; } } exports.wrap = wrap; var ContinueSentinel = {}; function Generator() {} function GeneratorFunction() {} function GeneratorFunctionPrototype() {} var IteratorPrototype = {}; define(IteratorPrototype, iteratorSymbol, function () { return this; }); var getProto = Object.getPrototypeOf, NativeIteratorPrototype = getProto && getProto(getProto(values([]))); NativeIteratorPrototype && NativeIteratorPrototype !== Op && hasOwn.call(NativeIteratorPrototype, iteratorSymbol) && (IteratorPrototype = NativeIteratorPrototype); var Gp = GeneratorFunctionPrototype.prototype = Generator.prototype = Object.create(IteratorPrototype); function defineIteratorMethods(prototype) { ["next", "throw", "return"].forEach(function (method) { define(prototype, method, function (arg) { return this._invoke(method, arg); }); }); } function AsyncIterator(generator, PromiseImpl) { function invoke(method, arg, resolve, reject) { var record = tryCatch(generator[method], generator, arg); if ("throw" !== record.type) { var result = record.arg, value = result.value; return value && "object" == typeof value && hasOwn.call(value, "__await") ? PromiseImpl.resolve(value.__await).then(function (value) { invoke("next", value, resolve, reject); }, function (err) { invoke("throw", err, resolve, reject); }) : PromiseImpl.resolve(value).then(function (unwrapped) { result.value = unwrapped, resolve(result); }, function (error) { return invoke("throw", error, resolve, reject); }); } reject(record.arg); } var previousPromise; this._invoke = function (method, arg) { function callInvokeWithMethodAndArg() { return new PromiseImpl(function (resolve, reject) { invoke(method, arg, resolve, reject); }); } return previousPromise = previousPromise ? previousPromise.then(callInvokeWithMethodAndArg, callInvokeWithMethodAndArg) : callInvokeWithMethodAndArg(); }; } function maybeInvokeDelegate(delegate, context) { var method = delegate.iterator[context.method]; if (undefined === method) { if (context.delegate = null, "throw" === context.method) { if (delegate.iterator.return && (context.method = "return", context.arg = undefined, maybeInvokeDelegate(delegate, context), "throw" === context.method)) return ContinueSentinel; context.method = "throw", context.arg = new TypeError("The iterator does not provide a 'throw' method"); } return ContinueSentinel; } var record = tryCatch(method, delegate.iterator, context.arg); if ("throw" === record.type) return context.method = "throw", context.arg = record.arg, context.delegate = null, ContinueSentinel; var info = record.arg; return info ? info.done ? (context[delegate.resultName] = info.value, context.next = delegate.nextLoc, "return" !== context.method && (context.method = "next", context.arg = undefined), context.delegate = null, ContinueSentinel) : info : (context.method = "throw", context.arg = new TypeError("iterator result is not an object"), context.delegate = null, ContinueSentinel); } function pushTryEntry(locs) { var entry = { tryLoc: locs[0] }; 1 in locs && (entry.catchLoc = locs[1]), 2 in locs && (entry.finallyLoc = locs[2], entry.afterLoc = locs[3]), this.tryEntries.push(entry); } function resetTryEntry(entry) { var record = entry.completion || {}; record.type = "normal", delete record.arg, entry.completion = record; } function Context(tryLocsList) { this.tryEntries = [{ tryLoc: "root" }], tryLocsList.forEach(pushTryEntry, this), this.reset(!0); } function values(iterable) { if (iterable) { var iteratorMethod = iterable[iteratorSymbol]; if (iteratorMethod) return iteratorMethod.call(iterable); if ("function" == typeof iterable.next) return iterable; if (!isNaN(iterable.length)) { var i = -1, next = function next() { for (; ++i < iterable.length;) { if (hasOwn.call(iterable, i)) return next.value = iterable[i], next.done = !1, next; } return next.value = undefined, next.done = !0, next; }; return next.next = next; } } return { next: doneResult }; } function doneResult() { return { value: undefined, done: !0 }; } return GeneratorFunction.prototype = GeneratorFunctionPrototype, define(Gp, "constructor", GeneratorFunctionPrototype), define(GeneratorFunctionPrototype, "constructor", GeneratorFunction), GeneratorFunction.displayName = define(GeneratorFunctionPrototype, toStringTagSymbol, "GeneratorFunction"), exports.isGeneratorFunction = function (genFun) { var ctor = "function" == typeof genFun && genFun.constructor; return !!ctor && (ctor === GeneratorFunction || "GeneratorFunction" === (ctor.displayName || ctor.name)); }, exports.mark = function (genFun) { return Object.setPrototypeOf ? Object.setPrototypeOf(genFun, GeneratorFunctionPrototype) : (genFun.__proto__ = GeneratorFunctionPrototype, define(genFun, toStringTagSymbol, "GeneratorFunction")), genFun.prototype = Object.create(Gp), genFun; }, exports.awrap = function (arg) { return { __await: arg }; }, defineIteratorMethods(AsyncIterator.prototype), define(AsyncIterator.prototype, asyncIteratorSymbol, function () { return this; }), exports.AsyncIterator = AsyncIterator, exports.async = function (innerFn, outerFn, self, tryLocsList, PromiseImpl) { void 0 === PromiseImpl && (PromiseImpl = Promise); var iter = new AsyncIterator(wrap(innerFn, outerFn, self, tryLocsList), PromiseImpl); return exports.isGeneratorFunction(outerFn) ? iter : iter.next().then(function (result) { return result.done ? result.value : iter.next(); }); }, defineIteratorMethods(Gp), define(Gp, toStringTagSymbol, "Generator"), define(Gp, iteratorSymbol, function () { return this; }), define(Gp, "toString", function () { return "[object Generator]"; }), exports.keys = function (object) { var keys = []; for (var key in object) { keys.push(key); } return keys.reverse(), function next() { for (; keys.length;) { var key = keys.pop(); if (key in object) return next.value = key, next.done = !1, next; } return next.done = !0, next; }; }, exports.values = values, Context.prototype = { constructor: Context, reset: function reset(skipTempReset) { if (this.prev = 0, this.next = 0, this.sent = this._sent = undefined, this.done = !1, this.delegate = null, this.method = "next", this.arg = undefined, this.tryEntries.forEach(resetTryEntry), !skipTempReset) for (var name in this) { "t" === name.charAt(0) && hasOwn.call(this, name) && !isNaN(+name.slice(1)) && (this[name] = undefined); } }, stop: function stop() { this.done = !0; var rootRecord = this.tryEntries[0].completion; if ("throw" === rootRecord.type) throw rootRecord.arg; return this.rval; }, dispatchException: function dispatchException(exception) { if (this.done) throw exception; var context = this; function handle(loc, caught) { return record.type = "throw", record.arg = exception, context.next = loc, caught && (context.method = "next", context.arg = undefined), !!caught; } for (var i = this.tryEntries.length - 1; i >= 0; --i) { var entry = this.tryEntries[i], record = entry.completion; if ("root" === entry.tryLoc) return handle("end"); if (entry.tryLoc <= this.prev) { var hasCatch = hasOwn.call(entry, "catchLoc"), hasFinally = hasOwn.call(entry, "finallyLoc"); if (hasCatch && hasFinally) { if (this.prev < entry.catchLoc) return handle(entry.catchLoc, !0); if (this.prev < entry.finallyLoc) return handle(entry.finallyLoc); } else if (hasCatch) { if (this.prev < entry.catchLoc) return handle(entry.catchLoc, !0); } else { if (!hasFinally) throw new Error("try statement without catch or finally"); if (this.prev < entry.finallyLoc) return handle(entry.finallyLoc); } } } }, abrupt: function abrupt(type, arg) { for (var i = this.tryEntries.length - 1; i >= 0; --i) { var entry = this.tryEntries[i]; if (entry.tryLoc <= this.prev && hasOwn.call(entry, "finallyLoc") && this.prev < entry.finallyLoc) { var finallyEntry = entry; break; } } finallyEntry && ("break" === type || "continue" === type) && finallyEntry.tryLoc <= arg && arg <= finallyEntry.finallyLoc && (finallyEntry = null); var record = finallyEntry ? finallyEntry.completion : {}; return record.type = type, record.arg = arg, finallyEntry ? (this.method = "next", this.next = finallyEntry.finallyLoc, ContinueSentinel) : this.complete(record); }, complete: function complete(record, afterLoc) { if ("throw" === record.type) throw record.arg; return "break" === record.type || "continue" === record.type ? this.next = record.arg : "return" === record.type ? (this.rval = this.arg = record.arg, this.method = "return", this.next = "end") : "normal" === record.type && afterLoc && (this.next = afterLoc), ContinueSentinel; }, finish: function finish(finallyLoc) { for (var i = this.tryEntries.length - 1; i >= 0; --i) { var entry = this.tryEntries[i]; if (entry.finallyLoc === finallyLoc) return this.complete(entry.completion, entry.afterLoc), resetTryEntry(entry), ContinueSentinel; } }, catch: function _catch(tryLoc) { for (var i = this.tryEntries.length - 1; i >= 0; --i) { var entry = this.tryEntries[i]; if (entry.tryLoc === tryLoc) { var record = entry.completion; if ("throw" === record.type) { var thrown = record.arg; resetTryEntry(entry); } return thrown; } } throw new Error("illegal catch attempt"); }, delegateYield: function delegateYield(iterable, resultName, nextLoc) { return this.delegate = { iterator: values(iterable), resultName: resultName, nextLoc: nextLoc }, "next" === this.method && (this.arg = undefined), ContinueSentinel; } }, exports; }






























var _c0 = ["ionContent"];

function CampaignDetailsPage_ng_container_0_ion_content_2_ng_container_4_Template(rf, ctx) {
  if (rf & 1) {
    _angular_core__WEBPACK_IMPORTED_MODULE_23__["ɵɵelementContainerStart"](0);
    _angular_core__WEBPACK_IMPORTED_MODULE_23__["ɵɵelement"](1, "app-campaign-notification", 21);
    _angular_core__WEBPACK_IMPORTED_MODULE_23__["ɵɵelementContainerEnd"]();
  }

  if (rf & 2) {
    var notification_r18 = ctx.$implicit;
    var ctx_r2 = _angular_core__WEBPACK_IMPORTED_MODULE_23__["ɵɵnextContext"](3);
    _angular_core__WEBPACK_IMPORTED_MODULE_23__["ɵɵadvance"](1);
    _angular_core__WEBPACK_IMPORTED_MODULE_23__["ɵɵproperty"]("campaign", ctx_r2.campaignContainer)("notification", notification_r18);
  }
}

function CampaignDetailsPage_ng_container_0_ion_content_2_ion_card_5_Template(rf, ctx) {
  if (rf & 1) {
    _angular_core__WEBPACK_IMPORTED_MODULE_23__["ɵɵelementStart"](0, "ion-card", 9)(1, "ion-item", 10)(2, "ion-label");
    _angular_core__WEBPACK_IMPORTED_MODULE_23__["ɵɵtext"](3);
    _angular_core__WEBPACK_IMPORTED_MODULE_23__["ɵɵpipe"](4, "translate");
    _angular_core__WEBPACK_IMPORTED_MODULE_23__["ɵɵelementEnd"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_23__["ɵɵelement"](5, "app-icon", 22);
    _angular_core__WEBPACK_IMPORTED_MODULE_23__["ɵɵelementEnd"]()();
  }

  if (rf & 2) {
    var ctx_r3 = _angular_core__WEBPACK_IMPORTED_MODULE_23__["ɵɵnextContext"](3);
    _angular_core__WEBPACK_IMPORTED_MODULE_23__["ɵɵproperty"]("routerLink", ctx_r3.getLeaderboardLink());
    _angular_core__WEBPACK_IMPORTED_MODULE_23__["ɵɵadvance"](1);
    _angular_core__WEBPACK_IMPORTED_MODULE_23__["ɵɵproperty"]("color", ctx_r3.campaignContainer == null ? null : ctx_r3.campaignContainer.campaign == null ? null : ctx_r3.campaignContainer.campaign.type);
    _angular_core__WEBPACK_IMPORTED_MODULE_23__["ɵɵadvance"](2);
    _angular_core__WEBPACK_IMPORTED_MODULE_23__["ɵɵtextInterpolate1"]("", _angular_core__WEBPACK_IMPORTED_MODULE_23__["ɵɵpipeBind1"](4, 3, "campaigns.detail.leaderboard"), " ");
  }
}

var _c1 = function _c1(a0) {
  return [a0];
};

function CampaignDetailsPage_ng_container_0_ion_content_2_ion_card_6_Template(rf, ctx) {
  if (rf & 1) {
    _angular_core__WEBPACK_IMPORTED_MODULE_23__["ɵɵelementStart"](0, "ion-card", 9)(1, "ion-item", 10)(2, "ion-label");
    _angular_core__WEBPACK_IMPORTED_MODULE_23__["ɵɵtext"](3);
    _angular_core__WEBPACK_IMPORTED_MODULE_23__["ɵɵpipe"](4, "translate");
    _angular_core__WEBPACK_IMPORTED_MODULE_23__["ɵɵelementEnd"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_23__["ɵɵelement"](5, "app-icon", 23);
    _angular_core__WEBPACK_IMPORTED_MODULE_23__["ɵɵelementEnd"]()();
  }

  if (rf & 2) {
    var ctx_r4 = _angular_core__WEBPACK_IMPORTED_MODULE_23__["ɵɵnextContext"](3);
    _angular_core__WEBPACK_IMPORTED_MODULE_23__["ɵɵproperty"]("routerLink", _angular_core__WEBPACK_IMPORTED_MODULE_23__["ɵɵpureFunction1"](5, _c1, "/pages/tabs/home/details/" + ctx_r4.campaignContainer.campaign.campaignId + "/stats"));
    _angular_core__WEBPACK_IMPORTED_MODULE_23__["ɵɵadvance"](1);
    _angular_core__WEBPACK_IMPORTED_MODULE_23__["ɵɵproperty"]("color", ctx_r4.campaignContainer == null ? null : ctx_r4.campaignContainer.campaign == null ? null : ctx_r4.campaignContainer.campaign.type);
    _angular_core__WEBPACK_IMPORTED_MODULE_23__["ɵɵadvance"](2);
    _angular_core__WEBPACK_IMPORTED_MODULE_23__["ɵɵtextInterpolate1"]("", _angular_core__WEBPACK_IMPORTED_MODULE_23__["ɵɵpipeBind1"](4, 3, "campaigns.detail.stats"), " ");
  }
}

function CampaignDetailsPage_ng_container_0_ion_content_2_ion_card_7_Template(rf, ctx) {
  if (rf & 1) {
    _angular_core__WEBPACK_IMPORTED_MODULE_23__["ɵɵelementStart"](0, "ion-card", 9)(1, "ion-item", 10)(2, "ion-label");
    _angular_core__WEBPACK_IMPORTED_MODULE_23__["ɵɵtext"](3);
    _angular_core__WEBPACK_IMPORTED_MODULE_23__["ɵɵpipe"](4, "translate");
    _angular_core__WEBPACK_IMPORTED_MODULE_23__["ɵɵelementEnd"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_23__["ɵɵelement"](5, "app-icon", 23);
    _angular_core__WEBPACK_IMPORTED_MODULE_23__["ɵɵelementEnd"]()();
  }

  if (rf & 2) {
    var ctx_r5 = _angular_core__WEBPACK_IMPORTED_MODULE_23__["ɵɵnextContext"](3);
    _angular_core__WEBPACK_IMPORTED_MODULE_23__["ɵɵproperty"]("routerLink", _angular_core__WEBPACK_IMPORTED_MODULE_23__["ɵɵpureFunction1"](5, _c1, "/pages/tabs/home/details/" + ctx_r5.campaignContainer.campaign.campaignId + "/stats-team"));
    _angular_core__WEBPACK_IMPORTED_MODULE_23__["ɵɵadvance"](1);
    _angular_core__WEBPACK_IMPORTED_MODULE_23__["ɵɵproperty"]("color", ctx_r5.campaignContainer == null ? null : ctx_r5.campaignContainer.campaign == null ? null : ctx_r5.campaignContainer.campaign.type);
    _angular_core__WEBPACK_IMPORTED_MODULE_23__["ɵɵadvance"](2);
    _angular_core__WEBPACK_IMPORTED_MODULE_23__["ɵɵtextInterpolate1"]("", _angular_core__WEBPACK_IMPORTED_MODULE_23__["ɵɵpipeBind1"](4, 3, "campaigns.detail.statsTeam"), " ");
  }
}

var _c2 = function _c2() {
  return ["/pages/tabs/challenges"];
};

function CampaignDetailsPage_ng_container_0_ion_content_2_ion_card_8_Template(rf, ctx) {
  if (rf & 1) {
    _angular_core__WEBPACK_IMPORTED_MODULE_23__["ɵɵelementStart"](0, "ion-card", 9)(1, "ion-item", 10)(2, "ion-label");
    _angular_core__WEBPACK_IMPORTED_MODULE_23__["ɵɵtext"](3);
    _angular_core__WEBPACK_IMPORTED_MODULE_23__["ɵɵpipe"](4, "translate");
    _angular_core__WEBPACK_IMPORTED_MODULE_23__["ɵɵelementEnd"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_23__["ɵɵelement"](5, "app-icon", 24);
    _angular_core__WEBPACK_IMPORTED_MODULE_23__["ɵɵelementEnd"]()();
  }

  if (rf & 2) {
    var ctx_r6 = _angular_core__WEBPACK_IMPORTED_MODULE_23__["ɵɵnextContext"](3);
    _angular_core__WEBPACK_IMPORTED_MODULE_23__["ɵɵproperty"]("routerLink", _angular_core__WEBPACK_IMPORTED_MODULE_23__["ɵɵpureFunction0"](5, _c2));
    _angular_core__WEBPACK_IMPORTED_MODULE_23__["ɵɵadvance"](1);
    _angular_core__WEBPACK_IMPORTED_MODULE_23__["ɵɵproperty"]("color", ctx_r6.campaignContainer == null ? null : ctx_r6.campaignContainer.campaign == null ? null : ctx_r6.campaignContainer.campaign.type);
    _angular_core__WEBPACK_IMPORTED_MODULE_23__["ɵɵadvance"](2);
    _angular_core__WEBPACK_IMPORTED_MODULE_23__["ɵɵtextInterpolate1"]("", _angular_core__WEBPACK_IMPORTED_MODULE_23__["ɵɵpipeBind1"](4, 3, "campaigns.detail.challenges"), " ");
  }
}

function CampaignDetailsPage_ng_container_0_ion_content_2_ion_card_9_Template(rf, ctx) {
  if (rf & 1) {
    _angular_core__WEBPACK_IMPORTED_MODULE_23__["ɵɵelementStart"](0, "ion-card", 9)(1, "ion-item", 10)(2, "ion-label");
    _angular_core__WEBPACK_IMPORTED_MODULE_23__["ɵɵtext"](3);
    _angular_core__WEBPACK_IMPORTED_MODULE_23__["ɵɵpipe"](4, "translate");
    _angular_core__WEBPACK_IMPORTED_MODULE_23__["ɵɵelementEnd"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_23__["ɵɵelement"](5, "app-icon", 25);
    _angular_core__WEBPACK_IMPORTED_MODULE_23__["ɵɵelementEnd"]()();
  }

  if (rf & 2) {
    var ctx_r7 = _angular_core__WEBPACK_IMPORTED_MODULE_23__["ɵɵnextContext"](3);
    _angular_core__WEBPACK_IMPORTED_MODULE_23__["ɵɵproperty"]("routerLink", _angular_core__WEBPACK_IMPORTED_MODULE_23__["ɵɵpureFunction1"](5, _c1, "/pages/tabs/home/details/" + ctx_r7.campaignContainer.campaign.campaignId + "/badges"));
    _angular_core__WEBPACK_IMPORTED_MODULE_23__["ɵɵadvance"](1);
    _angular_core__WEBPACK_IMPORTED_MODULE_23__["ɵɵproperty"]("color", ctx_r7.campaignContainer == null ? null : ctx_r7.campaignContainer.campaign == null ? null : ctx_r7.campaignContainer.campaign.type);
    _angular_core__WEBPACK_IMPORTED_MODULE_23__["ɵɵadvance"](2);
    _angular_core__WEBPACK_IMPORTED_MODULE_23__["ɵɵtextInterpolate1"]("", _angular_core__WEBPACK_IMPORTED_MODULE_23__["ɵɵpipeBind1"](4, 3, "campaigns.detail.badges"), " ");
  }
}

function CampaignDetailsPage_ng_container_0_ion_content_2_ion_card_16_Template(rf, ctx) {
  if (rf & 1) {
    _angular_core__WEBPACK_IMPORTED_MODULE_23__["ɵɵelementStart"](0, "ion-card", 9)(1, "ion-item", 10)(2, "ion-label");
    _angular_core__WEBPACK_IMPORTED_MODULE_23__["ɵɵtext"](3);
    _angular_core__WEBPACK_IMPORTED_MODULE_23__["ɵɵpipe"](4, "translate");
    _angular_core__WEBPACK_IMPORTED_MODULE_23__["ɵɵelementEnd"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_23__["ɵɵelement"](5, "app-icon", 26);
    _angular_core__WEBPACK_IMPORTED_MODULE_23__["ɵɵelementEnd"]()();
  }

  if (rf & 2) {
    var ctx_r8 = _angular_core__WEBPACK_IMPORTED_MODULE_23__["ɵɵnextContext"](3);
    _angular_core__WEBPACK_IMPORTED_MODULE_23__["ɵɵproperty"]("routerLink", _angular_core__WEBPACK_IMPORTED_MODULE_23__["ɵɵpureFunction1"](5, _c1, "/pages/blacklist/" + ctx_r8.campaignContainer.campaign.campaignId));
    _angular_core__WEBPACK_IMPORTED_MODULE_23__["ɵɵadvance"](1);
    _angular_core__WEBPACK_IMPORTED_MODULE_23__["ɵɵproperty"]("color", ctx_r8.campaignContainer == null ? null : ctx_r8.campaignContainer.campaign == null ? null : ctx_r8.campaignContainer.campaign.type);
    _angular_core__WEBPACK_IMPORTED_MODULE_23__["ɵɵadvance"](2);
    _angular_core__WEBPACK_IMPORTED_MODULE_23__["ɵɵtextInterpolate1"]("", _angular_core__WEBPACK_IMPORTED_MODULE_23__["ɵɵpipeBind1"](4, 3, "campaigns.detail.blacklist"), " ");
  }
}

function CampaignDetailsPage_ng_container_0_ion_content_2_ion_item_23_Template(rf, ctx) {
  if (rf & 1) {
    _angular_core__WEBPACK_IMPORTED_MODULE_23__["ɵɵelementStart"](0, "ion-item", 27)(1, "ion-label");
    _angular_core__WEBPACK_IMPORTED_MODULE_23__["ɵɵtext"](2);
    _angular_core__WEBPACK_IMPORTED_MODULE_23__["ɵɵpipe"](3, "translate");
    _angular_core__WEBPACK_IMPORTED_MODULE_23__["ɵɵelementStart"](4, "span", 28);
    _angular_core__WEBPACK_IMPORTED_MODULE_23__["ɵɵtext"](5);
    _angular_core__WEBPACK_IMPORTED_MODULE_23__["ɵɵpipe"](6, "localDate");
    _angular_core__WEBPACK_IMPORTED_MODULE_23__["ɵɵelementEnd"]()()();
  }

  if (rf & 2) {
    var ctx_r9 = _angular_core__WEBPACK_IMPORTED_MODULE_23__["ɵɵnextContext"](3);
    _angular_core__WEBPACK_IMPORTED_MODULE_23__["ɵɵadvance"](2);
    _angular_core__WEBPACK_IMPORTED_MODULE_23__["ɵɵtextInterpolate"](_angular_core__WEBPACK_IMPORTED_MODULE_23__["ɵɵpipeBind1"](3, 2, "campaigns.detail.dateFrom"));
    _angular_core__WEBPACK_IMPORTED_MODULE_23__["ɵɵadvance"](3);
    _angular_core__WEBPACK_IMPORTED_MODULE_23__["ɵɵtextInterpolate"](_angular_core__WEBPACK_IMPORTED_MODULE_23__["ɵɵpipeBind1"](6, 4, ctx_r9.campaignContainer == null ? null : ctx_r9.campaignContainer.campaign == null ? null : ctx_r9.campaignContainer.campaign.dateFrom));
  }
}

function CampaignDetailsPage_ng_container_0_ion_content_2_ion_item_24_Template(rf, ctx) {
  if (rf & 1) {
    _angular_core__WEBPACK_IMPORTED_MODULE_23__["ɵɵelementStart"](0, "ion-item", 27)(1, "ion-label");
    _angular_core__WEBPACK_IMPORTED_MODULE_23__["ɵɵtext"](2);
    _angular_core__WEBPACK_IMPORTED_MODULE_23__["ɵɵpipe"](3, "translate");
    _angular_core__WEBPACK_IMPORTED_MODULE_23__["ɵɵelementStart"](4, "span", 28);
    _angular_core__WEBPACK_IMPORTED_MODULE_23__["ɵɵtext"](5);
    _angular_core__WEBPACK_IMPORTED_MODULE_23__["ɵɵpipe"](6, "localDate");
    _angular_core__WEBPACK_IMPORTED_MODULE_23__["ɵɵelementEnd"]()()();
  }

  if (rf & 2) {
    var ctx_r10 = _angular_core__WEBPACK_IMPORTED_MODULE_23__["ɵɵnextContext"](3);
    _angular_core__WEBPACK_IMPORTED_MODULE_23__["ɵɵadvance"](2);
    _angular_core__WEBPACK_IMPORTED_MODULE_23__["ɵɵtextInterpolate"](_angular_core__WEBPACK_IMPORTED_MODULE_23__["ɵɵpipeBind1"](3, 2, "campaigns.detail.dateTo"));
    _angular_core__WEBPACK_IMPORTED_MODULE_23__["ɵɵadvance"](3);
    _angular_core__WEBPACK_IMPORTED_MODULE_23__["ɵɵtextInterpolate"](_angular_core__WEBPACK_IMPORTED_MODULE_23__["ɵɵpipeBind1"](6, 4, ctx_r10.campaignContainer == null ? null : ctx_r10.campaignContainer.campaign == null ? null : ctx_r10.campaignContainer.campaign.dateTo));
  }
}

function CampaignDetailsPage_ng_container_0_ion_content_2_ion_icon_29_Template(rf, ctx) {
  if (rf & 1) {
    _angular_core__WEBPACK_IMPORTED_MODULE_23__["ɵɵelement"](0, "ion-icon", 29);
  }
}

function CampaignDetailsPage_ng_container_0_ion_content_2_ion_icon_30_Template(rf, ctx) {
  if (rf & 1) {
    _angular_core__WEBPACK_IMPORTED_MODULE_23__["ɵɵelement"](0, "ion-icon", 30);
  }
}

function CampaignDetailsPage_ng_container_0_ion_content_2_div_31_ng_container_1_div_1_Template(rf, ctx) {
  if (rf & 1) {
    var _r25 = _angular_core__WEBPACK_IMPORTED_MODULE_23__["ɵɵgetCurrentView"]();

    _angular_core__WEBPACK_IMPORTED_MODULE_23__["ɵɵelementStart"](0, "div", 31);
    _angular_core__WEBPACK_IMPORTED_MODULE_23__["ɵɵlistener"]("click", function CampaignDetailsPage_ng_container_0_ion_content_2_div_31_ng_container_1_div_1_Template_div_click_0_listener() {
      _angular_core__WEBPACK_IMPORTED_MODULE_23__["ɵɵrestoreView"](_r25);
      var detail_r21 = _angular_core__WEBPACK_IMPORTED_MODULE_23__["ɵɵnextContext"]().$implicit;
      var ctx_r23 = _angular_core__WEBPACK_IMPORTED_MODULE_23__["ɵɵnextContext"](4);
      return ctx_r23.openDetail(detail_r21);
    });
    _angular_core__WEBPACK_IMPORTED_MODULE_23__["ɵɵelementStart"](1, "ion-item", 27)(2, "ion-label")(3, "span", 32);
    _angular_core__WEBPACK_IMPORTED_MODULE_23__["ɵɵtext"](4);
    _angular_core__WEBPACK_IMPORTED_MODULE_23__["ɵɵelementEnd"]()();
    _angular_core__WEBPACK_IMPORTED_MODULE_23__["ɵɵelement"](5, "ion-icon", 33);
    _angular_core__WEBPACK_IMPORTED_MODULE_23__["ɵɵelementEnd"]()();
  }

  if (rf & 2) {
    var detail_r21 = _angular_core__WEBPACK_IMPORTED_MODULE_23__["ɵɵnextContext"]().$implicit;
    _angular_core__WEBPACK_IMPORTED_MODULE_23__["ɵɵadvance"](4);
    _angular_core__WEBPACK_IMPORTED_MODULE_23__["ɵɵtextInterpolate1"](" ", detail_r21.name, "");
  }
}

function CampaignDetailsPage_ng_container_0_ion_content_2_div_31_ng_container_1_Template(rf, ctx) {
  if (rf & 1) {
    _angular_core__WEBPACK_IMPORTED_MODULE_23__["ɵɵelementContainerStart"](0);
    _angular_core__WEBPACK_IMPORTED_MODULE_23__["ɵɵtemplate"](1, CampaignDetailsPage_ng_container_0_ion_content_2_div_31_ng_container_1_div_1_Template, 6, 1, "div", 20);
    _angular_core__WEBPACK_IMPORTED_MODULE_23__["ɵɵelementContainerEnd"]();
  }

  if (rf & 2) {
    var detail_r21 = ctx.$implicit;
    _angular_core__WEBPACK_IMPORTED_MODULE_23__["ɵɵadvance"](1);
    _angular_core__WEBPACK_IMPORTED_MODULE_23__["ɵɵproperty"]("ngIf", detail_r21.type !== "sponsor" && detail_r21.type !== "faq");
  }
}

function CampaignDetailsPage_ng_container_0_ion_content_2_div_31_Template(rf, ctx) {
  if (rf & 1) {
    _angular_core__WEBPACK_IMPORTED_MODULE_23__["ɵɵelementStart"](0, "div");
    _angular_core__WEBPACK_IMPORTED_MODULE_23__["ɵɵtemplate"](1, CampaignDetailsPage_ng_container_0_ion_content_2_div_31_ng_container_1_Template, 2, 1, "ng-container", 7);
    _angular_core__WEBPACK_IMPORTED_MODULE_23__["ɵɵelementEnd"]();
  }

  if (rf & 2) {
    var details_r19 = ctx.ngIf;
    _angular_core__WEBPACK_IMPORTED_MODULE_23__["ɵɵadvance"](1);
    _angular_core__WEBPACK_IMPORTED_MODULE_23__["ɵɵproperty"]("ngForOf", details_r19);
  }
}

function CampaignDetailsPage_ng_container_0_ion_content_2_ion_card_33_Template(rf, ctx) {
  if (rf & 1) {
    _angular_core__WEBPACK_IMPORTED_MODULE_23__["ɵɵelementStart"](0, "ion-card", 9)(1, "ion-item", 10)(2, "ion-label");
    _angular_core__WEBPACK_IMPORTED_MODULE_23__["ɵɵtext"](3);
    _angular_core__WEBPACK_IMPORTED_MODULE_23__["ɵɵpipe"](4, "translate");
    _angular_core__WEBPACK_IMPORTED_MODULE_23__["ɵɵelementEnd"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_23__["ɵɵelement"](5, "ion-icon", 34);
    _angular_core__WEBPACK_IMPORTED_MODULE_23__["ɵɵelementEnd"]()();
  }

  if (rf & 2) {
    var ctx_r14 = _angular_core__WEBPACK_IMPORTED_MODULE_23__["ɵɵnextContext"](3);
    _angular_core__WEBPACK_IMPORTED_MODULE_23__["ɵɵproperty"]("routerLink", _angular_core__WEBPACK_IMPORTED_MODULE_23__["ɵɵpureFunction1"](5, _c1, "/pages/tabs/home/details/" + ctx_r14.campaignContainer.campaign.campaignId + "/companies"));
    _angular_core__WEBPACK_IMPORTED_MODULE_23__["ɵɵadvance"](1);
    _angular_core__WEBPACK_IMPORTED_MODULE_23__["ɵɵproperty"]("color", ctx_r14.campaignContainer == null ? null : ctx_r14.campaignContainer.campaign == null ? null : ctx_r14.campaignContainer.campaign.type);
    _angular_core__WEBPACK_IMPORTED_MODULE_23__["ɵɵadvance"](2);
    _angular_core__WEBPACK_IMPORTED_MODULE_23__["ɵɵtextInterpolate1"](" ", _angular_core__WEBPACK_IMPORTED_MODULE_23__["ɵɵpipeBind1"](4, 3, "campaigns.detail.companies"), "");
  }
}

function CampaignDetailsPage_ng_container_0_ion_content_2_ion_card_34_Template(rf, ctx) {
  if (rf & 1) {
    _angular_core__WEBPACK_IMPORTED_MODULE_23__["ɵɵelementStart"](0, "ion-card", 9)(1, "ion-item", 10)(2, "ion-label");
    _angular_core__WEBPACK_IMPORTED_MODULE_23__["ɵɵtext"](3);
    _angular_core__WEBPACK_IMPORTED_MODULE_23__["ɵɵpipe"](4, "translate");
    _angular_core__WEBPACK_IMPORTED_MODULE_23__["ɵɵelementEnd"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_23__["ɵɵelement"](5, "ion-icon", 35);
    _angular_core__WEBPACK_IMPORTED_MODULE_23__["ɵɵelementEnd"]()();
  }

  if (rf & 2) {
    var ctx_r15 = _angular_core__WEBPACK_IMPORTED_MODULE_23__["ɵɵnextContext"](3);
    _angular_core__WEBPACK_IMPORTED_MODULE_23__["ɵɵproperty"]("routerLink", _angular_core__WEBPACK_IMPORTED_MODULE_23__["ɵɵpureFunction1"](5, _c1, "/pages/tabs/home/details/" + ctx_r15.campaignContainer.campaign.campaignId + "/faq"));
    _angular_core__WEBPACK_IMPORTED_MODULE_23__["ɵɵadvance"](1);
    _angular_core__WEBPACK_IMPORTED_MODULE_23__["ɵɵproperty"]("color", ctx_r15.campaignContainer == null ? null : ctx_r15.campaignContainer.campaign == null ? null : ctx_r15.campaignContainer.campaign.type);
    _angular_core__WEBPACK_IMPORTED_MODULE_23__["ɵɵadvance"](2);
    _angular_core__WEBPACK_IMPORTED_MODULE_23__["ɵɵtextInterpolate1"](" ", _angular_core__WEBPACK_IMPORTED_MODULE_23__["ɵɵpipeBind1"](4, 3, "campaigns.detail.faq"), "");
  }
}

function CampaignDetailsPage_ng_container_0_ion_content_2_ion_card_42_Template(rf, ctx) {
  if (rf & 1) {
    _angular_core__WEBPACK_IMPORTED_MODULE_23__["ɵɵelementStart"](0, "ion-card")(1, "ion-card-title")(2, "ion-item", 10)(3, "ion-label");
    _angular_core__WEBPACK_IMPORTED_MODULE_23__["ɵɵtext"](4);
    _angular_core__WEBPACK_IMPORTED_MODULE_23__["ɵɵpipe"](5, "translate");
    _angular_core__WEBPACK_IMPORTED_MODULE_23__["ɵɵelementEnd"]()()();
    _angular_core__WEBPACK_IMPORTED_MODULE_23__["ɵɵelementStart"](6, "ion-card-content");
    _angular_core__WEBPACK_IMPORTED_MODULE_23__["ɵɵelement"](7, "div", 36);
    _angular_core__WEBPACK_IMPORTED_MODULE_23__["ɵɵpipe"](8, "languageMap");
    _angular_core__WEBPACK_IMPORTED_MODULE_23__["ɵɵelementEnd"]()();
  }

  if (rf & 2) {
    var ctx_r16 = _angular_core__WEBPACK_IMPORTED_MODULE_23__["ɵɵnextContext"](3);
    var tmp_2_0;
    _angular_core__WEBPACK_IMPORTED_MODULE_23__["ɵɵadvance"](2);
    _angular_core__WEBPACK_IMPORTED_MODULE_23__["ɵɵproperty"]("color", ctx_r16.campaignContainer == null ? null : ctx_r16.campaignContainer.campaign == null ? null : ctx_r16.campaignContainer.campaign.type);
    _angular_core__WEBPACK_IMPORTED_MODULE_23__["ɵɵadvance"](2);
    _angular_core__WEBPACK_IMPORTED_MODULE_23__["ɵɵtextInterpolate"](_angular_core__WEBPACK_IMPORTED_MODULE_23__["ɵɵpipeBind1"](5, 3, "campaigns.detail.sponsor"));
    _angular_core__WEBPACK_IMPORTED_MODULE_23__["ɵɵadvance"](3);
    _angular_core__WEBPACK_IMPORTED_MODULE_23__["ɵɵproperty"]("innerHTML", (tmp_2_0 = ctx_r16.getCampaignSponsor(_angular_core__WEBPACK_IMPORTED_MODULE_23__["ɵɵpipeBind1"](8, 5, ctx_r16.campaignContainer == null ? null : ctx_r16.campaignContainer.campaign == null ? null : ctx_r16.campaignContainer.campaign.details))) == null ? null : tmp_2_0.content, _angular_core__WEBPACK_IMPORTED_MODULE_23__["ɵɵsanitizeHtml"]);
  }
}

function CampaignDetailsPage_ng_container_0_ion_content_2_ion_card_44_Template(rf, ctx) {
  if (rf & 1) {
    var _r28 = _angular_core__WEBPACK_IMPORTED_MODULE_23__["ɵɵgetCurrentView"]();

    _angular_core__WEBPACK_IMPORTED_MODULE_23__["ɵɵelementStart"](0, "ion-card", 31);
    _angular_core__WEBPACK_IMPORTED_MODULE_23__["ɵɵlistener"]("click", function CampaignDetailsPage_ng_container_0_ion_content_2_ion_card_44_Template_ion_card_click_0_listener() {
      _angular_core__WEBPACK_IMPORTED_MODULE_23__["ɵɵrestoreView"](_r28);
      var ctx_r27 = _angular_core__WEBPACK_IMPORTED_MODULE_23__["ɵɵnextContext"](3);
      return ctx_r27.unsubscribeCampaign();
    });
    _angular_core__WEBPACK_IMPORTED_MODULE_23__["ɵɵelementStart"](1, "ion-item", 37)(2, "ion-label");
    _angular_core__WEBPACK_IMPORTED_MODULE_23__["ɵɵtext"](3);
    _angular_core__WEBPACK_IMPORTED_MODULE_23__["ɵɵpipe"](4, "translate");
    _angular_core__WEBPACK_IMPORTED_MODULE_23__["ɵɵelementEnd"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_23__["ɵɵelement"](5, "app-icon", 38);
    _angular_core__WEBPACK_IMPORTED_MODULE_23__["ɵɵelementEnd"]()();
  }

  if (rf & 2) {
    _angular_core__WEBPACK_IMPORTED_MODULE_23__["ɵɵadvance"](3);
    _angular_core__WEBPACK_IMPORTED_MODULE_23__["ɵɵtextInterpolate1"]("", _angular_core__WEBPACK_IMPORTED_MODULE_23__["ɵɵpipeBind1"](4, 1, "campaigns.detail.unsubscribe"), " ");
  }
}

var _c3 = function _c3(a0) {
  return {
    "border": a0
  };
};

var _c4 = function _c4(a1) {
  return ["/pages/tabs/trips/campaign", a1];
};

function CampaignDetailsPage_ng_container_0_ion_content_2_Template(rf, ctx) {
  if (rf & 1) {
    var _r30 = _angular_core__WEBPACK_IMPORTED_MODULE_23__["ɵɵgetCurrentView"]();

    _angular_core__WEBPACK_IMPORTED_MODULE_23__["ɵɵelementStart"](0, "ion-content", 3)(1, "ion-avatar", 4);
    _angular_core__WEBPACK_IMPORTED_MODULE_23__["ɵɵelement"](2, "img", 5);
    _angular_core__WEBPACK_IMPORTED_MODULE_23__["ɵɵelementEnd"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_23__["ɵɵelement"](3, "app-widget-campaign", 6);
    _angular_core__WEBPACK_IMPORTED_MODULE_23__["ɵɵtemplate"](4, CampaignDetailsPage_ng_container_0_ion_content_2_ng_container_4_Template, 2, 2, "ng-container", 7);
    _angular_core__WEBPACK_IMPORTED_MODULE_23__["ɵɵtemplate"](5, CampaignDetailsPage_ng_container_0_ion_content_2_ion_card_5_Template, 6, 5, "ion-card", 8);
    _angular_core__WEBPACK_IMPORTED_MODULE_23__["ɵɵtemplate"](6, CampaignDetailsPage_ng_container_0_ion_content_2_ion_card_6_Template, 6, 7, "ion-card", 8);
    _angular_core__WEBPACK_IMPORTED_MODULE_23__["ɵɵtemplate"](7, CampaignDetailsPage_ng_container_0_ion_content_2_ion_card_7_Template, 6, 7, "ion-card", 8);
    _angular_core__WEBPACK_IMPORTED_MODULE_23__["ɵɵtemplate"](8, CampaignDetailsPage_ng_container_0_ion_content_2_ion_card_8_Template, 6, 6, "ion-card", 8);
    _angular_core__WEBPACK_IMPORTED_MODULE_23__["ɵɵtemplate"](9, CampaignDetailsPage_ng_container_0_ion_content_2_ion_card_9_Template, 6, 7, "ion-card", 8);
    _angular_core__WEBPACK_IMPORTED_MODULE_23__["ɵɵelementStart"](10, "ion-card", 9)(11, "ion-item", 10)(12, "ion-label");
    _angular_core__WEBPACK_IMPORTED_MODULE_23__["ɵɵtext"](13);
    _angular_core__WEBPACK_IMPORTED_MODULE_23__["ɵɵpipe"](14, "translate");
    _angular_core__WEBPACK_IMPORTED_MODULE_23__["ɵɵelementEnd"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_23__["ɵɵelement"](15, "app-icon", 11);
    _angular_core__WEBPACK_IMPORTED_MODULE_23__["ɵɵelementEnd"]()();
    _angular_core__WEBPACK_IMPORTED_MODULE_23__["ɵɵtemplate"](16, CampaignDetailsPage_ng_container_0_ion_content_2_ion_card_16_Template, 6, 7, "ion-card", 8);
    _angular_core__WEBPACK_IMPORTED_MODULE_23__["ɵɵelementStart"](17, "ion-card")(18, "ion-card-title")(19, "ion-item", 10);
    _angular_core__WEBPACK_IMPORTED_MODULE_23__["ɵɵtext"](20);
    _angular_core__WEBPACK_IMPORTED_MODULE_23__["ɵɵpipe"](21, "translate");
    _angular_core__WEBPACK_IMPORTED_MODULE_23__["ɵɵelementEnd"]()();
    _angular_core__WEBPACK_IMPORTED_MODULE_23__["ɵɵelementStart"](22, "ion-card-content");
    _angular_core__WEBPACK_IMPORTED_MODULE_23__["ɵɵtemplate"](23, CampaignDetailsPage_ng_container_0_ion_content_2_ion_item_23_Template, 7, 6, "ion-item", 12);
    _angular_core__WEBPACK_IMPORTED_MODULE_23__["ɵɵtemplate"](24, CampaignDetailsPage_ng_container_0_ion_content_2_ion_item_24_Template, 7, 6, "ion-item", 12);
    _angular_core__WEBPACK_IMPORTED_MODULE_23__["ɵɵelementStart"](25, "div", 13);
    _angular_core__WEBPACK_IMPORTED_MODULE_23__["ɵɵlistener"]("click", function CampaignDetailsPage_ng_container_0_ion_content_2_Template_div_click_25_listener() {
      _angular_core__WEBPACK_IMPORTED_MODULE_23__["ɵɵrestoreView"](_r30);
      var ctx_r29 = _angular_core__WEBPACK_IMPORTED_MODULE_23__["ɵɵnextContext"](2);
      return ctx_r29.clickDescription();
    });
    _angular_core__WEBPACK_IMPORTED_MODULE_23__["ɵɵelement"](26, "div", 14);
    _angular_core__WEBPACK_IMPORTED_MODULE_23__["ɵɵpipe"](27, "languageMap");
    _angular_core__WEBPACK_IMPORTED_MODULE_23__["ɵɵelementEnd"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_23__["ɵɵelementStart"](28, "div", 15);
    _angular_core__WEBPACK_IMPORTED_MODULE_23__["ɵɵlistener"]("click", function CampaignDetailsPage_ng_container_0_ion_content_2_Template_div_click_28_listener() {
      _angular_core__WEBPACK_IMPORTED_MODULE_23__["ɵɵrestoreView"](_r30);
      var ctx_r31 = _angular_core__WEBPACK_IMPORTED_MODULE_23__["ɵɵnextContext"](2);
      return ctx_r31.clickDescription();
    });
    _angular_core__WEBPACK_IMPORTED_MODULE_23__["ɵɵtemplate"](29, CampaignDetailsPage_ng_container_0_ion_content_2_ion_icon_29_Template, 1, 0, "ion-icon", 16);
    _angular_core__WEBPACK_IMPORTED_MODULE_23__["ɵɵtemplate"](30, CampaignDetailsPage_ng_container_0_ion_content_2_ion_icon_30_Template, 1, 0, "ion-icon", 17);
    _angular_core__WEBPACK_IMPORTED_MODULE_23__["ɵɵelementEnd"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_23__["ɵɵtemplate"](31, CampaignDetailsPage_ng_container_0_ion_content_2_div_31_Template, 2, 1, "div", 0);
    _angular_core__WEBPACK_IMPORTED_MODULE_23__["ɵɵpipe"](32, "languageMap");
    _angular_core__WEBPACK_IMPORTED_MODULE_23__["ɵɵelementEnd"]()();
    _angular_core__WEBPACK_IMPORTED_MODULE_23__["ɵɵtemplate"](33, CampaignDetailsPage_ng_container_0_ion_content_2_ion_card_33_Template, 6, 7, "ion-card", 8);
    _angular_core__WEBPACK_IMPORTED_MODULE_23__["ɵɵtemplate"](34, CampaignDetailsPage_ng_container_0_ion_content_2_ion_card_34_Template, 6, 7, "ion-card", 8);
    _angular_core__WEBPACK_IMPORTED_MODULE_23__["ɵɵpipe"](35, "languageMap");
    _angular_core__WEBPACK_IMPORTED_MODULE_23__["ɵɵelementStart"](36, "ion-card")(37, "ion-item", 18);
    _angular_core__WEBPACK_IMPORTED_MODULE_23__["ɵɵlistener"]("click", function CampaignDetailsPage_ng_container_0_ion_content_2_Template_ion_item_click_37_listener() {
      _angular_core__WEBPACK_IMPORTED_MODULE_23__["ɵɵrestoreView"](_r30);
      var ctx_r32 = _angular_core__WEBPACK_IMPORTED_MODULE_23__["ɵɵnextContext"](2);
      return ctx_r32.openSupport();
    });
    _angular_core__WEBPACK_IMPORTED_MODULE_23__["ɵɵelementStart"](38, "ion-label");
    _angular_core__WEBPACK_IMPORTED_MODULE_23__["ɵɵtext"](39);
    _angular_core__WEBPACK_IMPORTED_MODULE_23__["ɵɵpipe"](40, "translate");
    _angular_core__WEBPACK_IMPORTED_MODULE_23__["ɵɵelementEnd"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_23__["ɵɵelement"](41, "ion-icon", 19);
    _angular_core__WEBPACK_IMPORTED_MODULE_23__["ɵɵelementEnd"]()();
    _angular_core__WEBPACK_IMPORTED_MODULE_23__["ɵɵtemplate"](42, CampaignDetailsPage_ng_container_0_ion_content_2_ion_card_42_Template, 9, 7, "ion-card", 0);
    _angular_core__WEBPACK_IMPORTED_MODULE_23__["ɵɵpipe"](43, "languageMap");
    _angular_core__WEBPACK_IMPORTED_MODULE_23__["ɵɵtemplate"](44, CampaignDetailsPage_ng_container_0_ion_content_2_ion_card_44_Template, 6, 3, "ion-card", 20);
    _angular_core__WEBPACK_IMPORTED_MODULE_23__["ɵɵelementEnd"]();
  }

  if (rf & 2) {
    var ctx_r1 = _angular_core__WEBPACK_IMPORTED_MODULE_23__["ɵɵnextContext"](2);
    _angular_core__WEBPACK_IMPORTED_MODULE_23__["ɵɵproperty"]("fullscreen", true)("scrollEvents", true);
    _angular_core__WEBPACK_IMPORTED_MODULE_23__["ɵɵadvance"](1);
    _angular_core__WEBPACK_IMPORTED_MODULE_23__["ɵɵproperty"]("ngStyle", _angular_core__WEBPACK_IMPORTED_MODULE_23__["ɵɵpureFunction1"](45, _c3, "3px solid var(--ion-color-" + (ctx_r1.campaignContainer == null ? null : ctx_r1.campaignContainer.campaign == null ? null : ctx_r1.campaignContainer.campaign.type) + ")"));
    _angular_core__WEBPACK_IMPORTED_MODULE_23__["ɵɵadvance"](1);
    _angular_core__WEBPACK_IMPORTED_MODULE_23__["ɵɵproperty"]("src", ctx_r1.imagePath, _angular_core__WEBPACK_IMPORTED_MODULE_23__["ɵɵsanitizeUrl"]);
    _angular_core__WEBPACK_IMPORTED_MODULE_23__["ɵɵadvance"](1);
    _angular_core__WEBPACK_IMPORTED_MODULE_23__["ɵɵproperty"]("campaign", ctx_r1.campaignContainer)("header", false);
    _angular_core__WEBPACK_IMPORTED_MODULE_23__["ɵɵadvance"](1);
    _angular_core__WEBPACK_IMPORTED_MODULE_23__["ɵɵproperty"]("ngForOf", ctx_r1.unreadNotifications);
    _angular_core__WEBPACK_IMPORTED_MODULE_23__["ɵɵadvance"](1);
    _angular_core__WEBPACK_IMPORTED_MODULE_23__["ɵɵproperty"]("ngIf", ctx_r1.campaignHas("leaderboard"));
    _angular_core__WEBPACK_IMPORTED_MODULE_23__["ɵɵadvance"](1);
    _angular_core__WEBPACK_IMPORTED_MODULE_23__["ɵɵproperty"]("ngIf", ctx_r1.campaignHas("stats"));
    _angular_core__WEBPACK_IMPORTED_MODULE_23__["ɵɵadvance"](1);
    _angular_core__WEBPACK_IMPORTED_MODULE_23__["ɵɵproperty"]("ngIf", ctx_r1.campaignHas("statsTeam"));
    _angular_core__WEBPACK_IMPORTED_MODULE_23__["ɵɵadvance"](1);
    _angular_core__WEBPACK_IMPORTED_MODULE_23__["ɵɵproperty"]("ngIf", ctx_r1.campaignHas("challenge"));
    _angular_core__WEBPACK_IMPORTED_MODULE_23__["ɵɵadvance"](1);
    _angular_core__WEBPACK_IMPORTED_MODULE_23__["ɵɵproperty"]("ngIf", ctx_r1.campaignHas("badges"));
    _angular_core__WEBPACK_IMPORTED_MODULE_23__["ɵɵadvance"](1);
    _angular_core__WEBPACK_IMPORTED_MODULE_23__["ɵɵproperty"]("routerLink", _angular_core__WEBPACK_IMPORTED_MODULE_23__["ɵɵpureFunction1"](47, _c4, ctx_r1.campaignContainer == null ? null : ctx_r1.campaignContainer.campaign == null ? null : ctx_r1.campaignContainer.campaign.campaignId));
    _angular_core__WEBPACK_IMPORTED_MODULE_23__["ɵɵadvance"](1);
    _angular_core__WEBPACK_IMPORTED_MODULE_23__["ɵɵproperty"]("color", ctx_r1.campaignContainer == null ? null : ctx_r1.campaignContainer.campaign == null ? null : ctx_r1.campaignContainer.campaign.type);
    _angular_core__WEBPACK_IMPORTED_MODULE_23__["ɵɵadvance"](2);
    _angular_core__WEBPACK_IMPORTED_MODULE_23__["ɵɵtextInterpolate1"]("", _angular_core__WEBPACK_IMPORTED_MODULE_23__["ɵɵpipeBind1"](14, 31, "campaigns.detail.journeys"), " ");
    _angular_core__WEBPACK_IMPORTED_MODULE_23__["ɵɵadvance"](3);
    _angular_core__WEBPACK_IMPORTED_MODULE_23__["ɵɵproperty"]("ngIf", ctx_r1.campaignHas("blacklist"));
    _angular_core__WEBPACK_IMPORTED_MODULE_23__["ɵɵadvance"](3);
    _angular_core__WEBPACK_IMPORTED_MODULE_23__["ɵɵproperty"]("color", ctx_r1.campaignContainer == null ? null : ctx_r1.campaignContainer.campaign == null ? null : ctx_r1.campaignContainer.campaign.type);
    _angular_core__WEBPACK_IMPORTED_MODULE_23__["ɵɵadvance"](1);
    _angular_core__WEBPACK_IMPORTED_MODULE_23__["ɵɵtextInterpolate1"]("", _angular_core__WEBPACK_IMPORTED_MODULE_23__["ɵɵpipeBind1"](21, 33, "campaigns.detail.details"), " ");
    _angular_core__WEBPACK_IMPORTED_MODULE_23__["ɵɵadvance"](3);
    _angular_core__WEBPACK_IMPORTED_MODULE_23__["ɵɵproperty"]("ngIf", ctx_r1.campaignHas("dates"));
    _angular_core__WEBPACK_IMPORTED_MODULE_23__["ɵɵadvance"](1);
    _angular_core__WEBPACK_IMPORTED_MODULE_23__["ɵɵproperty"]("ngIf", ctx_r1.campaignHas("dates"));
    _angular_core__WEBPACK_IMPORTED_MODULE_23__["ɵɵadvance"](1);
    _angular_core__WEBPACK_IMPORTED_MODULE_23__["ɵɵproperty"]("ngClass", ctx_r1.descriptionExpanded ? "open" : "");
    _angular_core__WEBPACK_IMPORTED_MODULE_23__["ɵɵadvance"](1);
    _angular_core__WEBPACK_IMPORTED_MODULE_23__["ɵɵproperty"]("innerHTML", _angular_core__WEBPACK_IMPORTED_MODULE_23__["ɵɵpipeBind1"](27, 35, ctx_r1.campaignContainer == null ? null : ctx_r1.campaignContainer.campaign == null ? null : ctx_r1.campaignContainer.campaign.description), _angular_core__WEBPACK_IMPORTED_MODULE_23__["ɵɵsanitizeHtml"]);
    _angular_core__WEBPACK_IMPORTED_MODULE_23__["ɵɵadvance"](3);
    _angular_core__WEBPACK_IMPORTED_MODULE_23__["ɵɵproperty"]("ngIf", ctx_r1.descriptionExpanded);
    _angular_core__WEBPACK_IMPORTED_MODULE_23__["ɵɵadvance"](1);
    _angular_core__WEBPACK_IMPORTED_MODULE_23__["ɵɵproperty"]("ngIf", !ctx_r1.descriptionExpanded);
    _angular_core__WEBPACK_IMPORTED_MODULE_23__["ɵɵadvance"](1);
    _angular_core__WEBPACK_IMPORTED_MODULE_23__["ɵɵproperty"]("ngIf", _angular_core__WEBPACK_IMPORTED_MODULE_23__["ɵɵpipeBind1"](32, 37, ctx_r1.campaignContainer == null ? null : ctx_r1.campaignContainer.campaign == null ? null : ctx_r1.campaignContainer.campaign.details));
    _angular_core__WEBPACK_IMPORTED_MODULE_23__["ɵɵadvance"](2);
    _angular_core__WEBPACK_IMPORTED_MODULE_23__["ɵɵproperty"]("ngIf", ctx_r1.campaignHas("companies"));
    _angular_core__WEBPACK_IMPORTED_MODULE_23__["ɵɵadvance"](1);
    _angular_core__WEBPACK_IMPORTED_MODULE_23__["ɵɵproperty"]("ngIf", ctx_r1.campaignHasFAQ(_angular_core__WEBPACK_IMPORTED_MODULE_23__["ɵɵpipeBind1"](35, 39, ctx_r1.campaignContainer == null ? null : ctx_r1.campaignContainer.campaign == null ? null : ctx_r1.campaignContainer.campaign.details)));
    _angular_core__WEBPACK_IMPORTED_MODULE_23__["ɵɵadvance"](3);
    _angular_core__WEBPACK_IMPORTED_MODULE_23__["ɵɵproperty"]("color", ctx_r1.campaignContainer == null ? null : ctx_r1.campaignContainer.campaign == null ? null : ctx_r1.campaignContainer.campaign.type);
    _angular_core__WEBPACK_IMPORTED_MODULE_23__["ɵɵadvance"](2);
    _angular_core__WEBPACK_IMPORTED_MODULE_23__["ɵɵtextInterpolate1"]("", _angular_core__WEBPACK_IMPORTED_MODULE_23__["ɵɵpipeBind1"](40, 41, "campaigns.detail.signal"), " ");
    _angular_core__WEBPACK_IMPORTED_MODULE_23__["ɵɵadvance"](3);
    _angular_core__WEBPACK_IMPORTED_MODULE_23__["ɵɵproperty"]("ngIf", ctx_r1.campaignHasSponsor(_angular_core__WEBPACK_IMPORTED_MODULE_23__["ɵɵpipeBind1"](43, 43, ctx_r1.campaignContainer == null ? null : ctx_r1.campaignContainer.campaign == null ? null : ctx_r1.campaignContainer.campaign.details)));
    _angular_core__WEBPACK_IMPORTED_MODULE_23__["ɵɵadvance"](2);
    _angular_core__WEBPACK_IMPORTED_MODULE_23__["ɵɵproperty"]("ngIf", !ctx_r1.isPersonal() && !ctx_r1.isSchool());
  }
}

function CampaignDetailsPage_ng_container_0_Template(rf, ctx) {
  if (rf & 1) {
    _angular_core__WEBPACK_IMPORTED_MODULE_23__["ɵɵelementContainerStart"](0);
    _angular_core__WEBPACK_IMPORTED_MODULE_23__["ɵɵelement"](1, "ion-header", 1);
    _angular_core__WEBPACK_IMPORTED_MODULE_23__["ɵɵtemplate"](2, CampaignDetailsPage_ng_container_0_ion_content_2_Template, 45, 49, "ion-content", 2);
    _angular_core__WEBPACK_IMPORTED_MODULE_23__["ɵɵelementContainerEnd"]();
  }

  if (rf & 2) {
    var ctx_r0 = _angular_core__WEBPACK_IMPORTED_MODULE_23__["ɵɵnextContext"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_23__["ɵɵadvance"](1);
    _angular_core__WEBPACK_IMPORTED_MODULE_23__["ɵɵproperty"]("imageUrl", ctx_r0.campaignContainer == null ? null : ctx_r0.campaignContainer.campaign == null ? null : ctx_r0.campaignContainer.campaign.banner == null ? null : ctx_r0.campaignContainer.campaign.banner.url);
    _angular_core__WEBPACK_IMPORTED_MODULE_23__["ɵɵadvance"](1);
    _angular_core__WEBPACK_IMPORTED_MODULE_23__["ɵɵproperty"]("ngIf", ctx_r0.campaignContainer);
  }
}

var CampaignDetailsPage = /*#__PURE__*/function () {
  function CampaignDetailsPage(route, campaignService, alertService, userService, navCtrl, modalController, notificationService, pageSettingsService, errorService, teamService) {
    var _this = this;

    (0,_Users_smartcommunitylab_Documents_work_projects_dslab_playgo_mobile_playgo_mobile_node_modules_babel_runtime_helpers_esm_classCallCheck_js__WEBPACK_IMPORTED_MODULE_1__["default"])(this, CampaignDetailsPage);

    this.route = route;
    this.campaignService = campaignService;
    this.alertService = alertService;
    this.userService = userService;
    this.navCtrl = navCtrl;
    this.modalController = modalController;
    this.notificationService = notificationService;
    this.pageSettingsService = pageSettingsService;
    this.errorService = errorService;
    this.teamService = teamService;
    this.titlePage = '';
    this.colorCampaign = null;
    this.isDestroyed$ = new rxjs__WEBPACK_IMPORTED_MODULE_24__.Subject();
    this.unreadNotifications = [];
    this.descriptionExpanded = false;
    this.campaignId$ = this.route.params.pipe((0,rxjs__WEBPACK_IMPORTED_MODULE_25__.map)(function (params) {
      return params.id;
    }), (0,rxjs__WEBPACK_IMPORTED_MODULE_26__.distinctUntilChanged)(), (0,rxjs__WEBPACK_IMPORTED_MODULE_27__.shareReplay)(1));
    this.playerCampaign$ = this.campaignId$.pipe((0,rxjs__WEBPACK_IMPORTED_MODULE_28__.switchMap)(function (campaignId) {
      return _this.campaignService.myCampaigns$.pipe((0,rxjs__WEBPACK_IMPORTED_MODULE_25__.map)(function (campaigns) {
        return (0,lodash_es__WEBPACK_IMPORTED_MODULE_29__["default"])(campaigns, function (playercampaign) {
          return playercampaign.subscription.campaignId === campaignId;
        });
      }), (0,rxjs__WEBPACK_IMPORTED_MODULE_30__.tap)(function (campaigns) {
        return console.log(campaigns);
      }), // throwIfNil(() => new Error('Campaign not found')),
      _this.errorService.getErrorHandler());
    }), (0,rxjs__WEBPACK_IMPORTED_MODULE_30__.tap)(function (campaign) {
      return console.log('playercampaign' + campaign);
    }), (0,rxjs__WEBPACK_IMPORTED_MODULE_27__.shareReplay)(1));
    this.teamId$ = this.playerCampaign$.pipe((0,rxjs__WEBPACK_IMPORTED_MODULE_25__.map)(function (campaign) {
      var _a, _b;

      console.log(campaign);
      return (_b = (_a = campaign === null || campaign === void 0 ? void 0 : campaign.subscription) === null || _a === void 0 ? void 0 : _a.campaignData) === null || _b === void 0 ? void 0 : _b.teamId;
    }), (0,rxjs__WEBPACK_IMPORTED_MODULE_30__.tap)(function (team) {
      return console.log(team);
    }), (0,rxjs__WEBPACK_IMPORTED_MODULE_27__.shareReplay)(1));
    this.route.params.subscribe(function (params) {
      return _this.id = params.id;
    });
  }

  (0,_Users_smartcommunitylab_Documents_work_projects_dslab_playgo_mobile_playgo_mobile_node_modules_babel_runtime_helpers_esm_createClass_js__WEBPACK_IMPORTED_MODULE_2__["default"])(CampaignDetailsPage, [{
    key: "ngOnDestroy",
    value: function ngOnDestroy() {
      this.isDestroyed$.next();
      this.isDestroyed$.complete();
    }
  }, {
    key: "ionViewDidLeave",
    value: function ionViewDidLeave() {
      var _a, _b;

      (_a = this.subStat) === null || _a === void 0 ? void 0 : _a.unsubscribe();
      (_b = this.myCampaignSub) === null || _b === void 0 ? void 0 : _b.unsubscribe();
    }
  }, {
    key: "ngOnInit",
    value: function ngOnInit() {
      var _this2 = this;

      this.subTeam = (0,rxjs__WEBPACK_IMPORTED_MODULE_31__.combineLatest)([this.campaignId$, this.teamId$]).pipe((0,rxjs__WEBPACK_IMPORTED_MODULE_28__.switchMap)(function (_ref) {
        var _ref2 = (0,_Users_smartcommunitylab_Documents_work_projects_dslab_playgo_mobile_playgo_mobile_node_modules_babel_runtime_helpers_esm_slicedToArray_js__WEBPACK_IMPORTED_MODULE_0__["default"])(_ref, 2),
            campaignId = _ref2[0],
            teamId = _ref2[1];

        return teamId ? _this2.teamService.getMyTeam(campaignId, teamId) : rxjs__WEBPACK_IMPORTED_MODULE_32__.EMPTY;
      }), this.errorService.getErrorHandler()).subscribe(function (team) {
        return _this2.team = team;
      });
      this.subStat = this.userService.userProfile$.subscribe(function (profile) {
        _this2.profile = profile;
      });
      this.language = this.userService.getLanguage();
      this.notificationService.getUnreadCampaignNotifications(this.id).pipe((0,rxjs__WEBPACK_IMPORTED_MODULE_33__.takeUntil)(this.isDestroyed$)).subscribe(function (notifications) {
        _this2.unreadNotifications = notifications;
      });
      this.myCampaignSub = this.campaignService.myCampaigns$.pipe((0,rxjs__WEBPACK_IMPORTED_MODULE_33__.takeUntil)(this.isDestroyed$), (0,rxjs__WEBPACK_IMPORTED_MODULE_28__.switchMap)(function (campaigns) {
        var campaignContainer = campaigns.find(function (eachCampaignContainer) {
          return eachCampaignContainer.campaign.campaignId === _this2.id;
        });

        if (campaignContainer) {
          return (0,rxjs__WEBPACK_IMPORTED_MODULE_34__.of)(campaignContainer);
        } else {
          return _this2.campaignService.getCampaignDetailsById(_this2.id).pipe((0,src_app_core_shared_rxjs_utils__WEBPACK_IMPORTED_MODULE_5__.throwIfNil)(function () {
            return new src_app_core_shared_services_error_service__WEBPACK_IMPORTED_MODULE_7__.UserError({
              id: 'campaign-not-found',
              message: 'campaigns.detail.not_found'
            });
          }), (0,rxjs__WEBPACK_IMPORTED_MODULE_25__.map)(function (campaign) {
            return {
              campaign: campaign,
              player: null
            };
          }), _this2.errorService.getErrorHandler('normal'));
        }
      })).subscribe(function (campaignContainer) {
        var _a, _b, _c, _d, _e, _f, _g, _h, _j, _k;

        _this2.campaignContainer = campaignContainer;
        _this2.titlePage = (_b = (_a = _this2.campaignContainer) === null || _a === void 0 ? void 0 : _a.campaign) === null || _b === void 0 ? void 0 : _b.name[_this2.language];
        _this2.colorCampaign = (_d = (_c = _this2.campaignContainer) === null || _c === void 0 ? void 0 : _c.campaign) === null || _d === void 0 ? void 0 : _d.type;
        _this2.imagePath = ((_f = (_e = _this2.campaignContainer) === null || _e === void 0 ? void 0 : _e.campaign) === null || _f === void 0 ? void 0 : _f.logo.url) ? (_h = (_g = _this2.campaignContainer) === null || _g === void 0 ? void 0 : _g.campaign) === null || _h === void 0 ? void 0 : _h.logo.url : 'data:image/jpg;base64,' + ((_k = (_j = _this2.campaignContainer) === null || _j === void 0 ? void 0 : _j.campaign) === null || _k === void 0 ? void 0 : _k.logo.image);

        _this2.changePageSettings();
      });
    }
  }, {
    key: "ionViewWillEnter",
    value: function ionViewWillEnter() {
      this.changePageSettings();
    }
  }, {
    key: "changePageSettings",
    value: function changePageSettings() {
      this.pageSettingsService.set({
        color: this.colorCampaign,
        // FIXME: ! title is already translated!
        title: this.titlePage
      });
    }
  }, {
    key: "openDetail",
    value: function openDetail(detail) {
      var _a, _b;

      return (0,tslib__WEBPACK_IMPORTED_MODULE_35__.__awaiter)(this, void 0, void 0, /*#__PURE__*/_regeneratorRuntime().mark(function _callee() {
        var modal;
        return _regeneratorRuntime().wrap(function _callee$(_context) {
          while (1) {
            switch (_context.prev = _context.next) {
              case 0:
                _context.next = 2;
                return this.modalController.create({
                  component: _detail_modal_detail_modal__WEBPACK_IMPORTED_MODULE_3__.DetailCampaignModalPage,
                  cssClass: 'modalConfirm',
                  componentProps: {
                    detail: detail,
                    type: (_b = (_a = this.campaignContainer) === null || _a === void 0 ? void 0 : _a.campaign) === null || _b === void 0 ? void 0 : _b.type
                  }
                });

              case 2:
                modal = _context.sent;
                _context.next = 5;
                return modal.present();

              case 5:
                _context.next = 7;
                return modal.onWillDismiss();

              case 7:
              case "end":
                return _context.stop();
            }
          }
        }, _callee, this);
      }));
    }
  }, {
    key: "openCompanies",
    value: function openCompanies() {
      return (0,tslib__WEBPACK_IMPORTED_MODULE_35__.__awaiter)(this, void 0, void 0, /*#__PURE__*/_regeneratorRuntime().mark(function _callee2() {
        var modal;
        return _regeneratorRuntime().wrap(function _callee2$(_context2) {
          while (1) {
            switch (_context2.prev = _context2.next) {
              case 0:
                _context2.next = 2;
                return this.modalController.create({
                  component: _companies_modal_companies_modal__WEBPACK_IMPORTED_MODULE_8__.CompaniesCampaignModalPage,
                  cssClass: 'modalConfirm',
                  componentProps: {
                    campaign: this.campaignContainer.campaign
                  }
                });

              case 2:
                modal = _context2.sent;
                _context2.next = 5;
                return modal.present();

              case 5:
                _context2.next = 7;
                return modal.onWillDismiss();

              case 7:
              case "end":
                return _context2.stop();
            }
          }
        }, _callee2, this);
      }));
    }
  }, {
    key: "getCampaignSponsor",
    value: function getCampaignSponsor(details) {
      return details.filter(function (detail) {
        return detail.type === 'sponsor';
      })[0];
    }
  }, {
    key: "campaignHasSponsor",
    value: function campaignHasSponsor(details) {
      return details.filter(function (detail) {
        return detail.type === 'sponsor';
      }).length > 0;
    }
  }, {
    key: "getCampaignFAQ",
    value: function getCampaignFAQ(details) {
      return details.filter(function (detail) {
        return detail.type === 'faq';
      })[0];
    }
  }, {
    key: "campaignHasFAQ",
    value: function campaignHasFAQ(details) {
      return details.filter(function (detail) {
        return detail.type === 'faq';
      }).length > 0;
    }
  }, {
    key: "clickDescription",
    value: function clickDescription() {
      this.descriptionExpanded = !this.descriptionExpanded;
    }
  }, {
    key: "getCampaign",
    value: function getCampaign() {
      return JSON.stringify(this.campaignContainer.campaign);
    }
  }, {
    key: "isPersonal",
    value: function isPersonal() {
      return this.campaignContainer.campaign.type === 'personal';
    }
  }, {
    key: "isCompany",
    value: function isCompany() {
      return this.campaignContainer.campaign.type === 'company';
    }
  }, {
    key: "isSchool",
    value: function isSchool() {
      return this.campaignContainer.campaign.type === 'school';
    }
  }, {
    key: "getLeaderboardLink",
    value: function getLeaderboardLink() {
      var isSchool = this.campaignContainer.campaign.type === 'school';
      var page = isSchool ? 'school-leaderboard' : 'leaderboard';
      var campaignId = this.campaignContainer.campaign.campaignId;
      return ["/pages/tabs/home/details/".concat(campaignId, "/").concat(page)];
    }
  }, {
    key: "campaignHas",
    value: function campaignHas(what) {
      var _a;

      return ((_a = this.campaignService.getFunctionalityByType(what, this.campaignContainer.campaign.type)) === null || _a === void 0 ? void 0 : _a.present) || false;
    }
  }, {
    key: "unsubscribeCampaign",
    value: function unsubscribeCampaign() {
      return (0,tslib__WEBPACK_IMPORTED_MODULE_35__.__awaiter)(this, void 0, void 0, /*#__PURE__*/_regeneratorRuntime().mark(function _callee3() {
        var _this3 = this;

        var modal, _yield$modal$onWillDi, data;

        return _regeneratorRuntime().wrap(function _callee3$(_context3) {
          while (1) {
            switch (_context3.prev = _context3.next) {
              case 0:
                _context3.next = 2;
                return this.modalController.create({
                  component: _unsubscribe_modal_unsubscribe_modal__WEBPACK_IMPORTED_MODULE_4__.UnsubscribeModalPage,
                  cssClass: 'modal-challenge',
                  swipeToClose: true
                });

              case 2:
                modal = _context3.sent;
                _context3.next = 5;
                return modal.present();

              case 5:
                _context3.next = 7;
                return modal.onWillDismiss();

              case 7:
                _yield$modal$onWillDi = _context3.sent;
                data = _yield$modal$onWillDi.data;

                if (data) {
                  this.unsubSub = this.campaignService.unsubscribeCampaign(this.campaignContainer.campaign.campaignId).subscribe(function (result) {
                    var _a, _b;

                    _this3.alertService.showToast({
                      messageTranslateKey: 'campaigns.unregistered'
                    });

                    (_a = _this3.subStat) === null || _a === void 0 ? void 0 : _a.unsubscribe();
                    (_b = _this3.myCampaignSub) === null || _b === void 0 ? void 0 : _b.unsubscribe();

                    _this3.navCtrl.back();
                  });
                }

              case 10:
              case "end":
                return _context3.stop();
            }
          }
        }, _callee3, this);
      }));
    }
  }, {
    key: "back",
    value: function back() {
      this.navCtrl.back();
    }
  }, {
    key: "openSupport",
    value: function openSupport() {
      var _a, _b, _c, _d, _e, _f, _g, _h;

      window.open('mailto:' + src_environments_environment__WEBPACK_IMPORTED_MODULE_6__.environment.support.email + '?subject=Play%26go%20' + ((_b = (_a = this.campaignContainer) === null || _a === void 0 ? void 0 : _a.campaign) === null || _b === void 0 ? void 0 : _b.name.it) + '%20Supporto&body=-----------NON CANCELLARE-----------%0D%0A%0D%0A' + 'territoryId: ' + this.profile.territoryId + '%0D%0Acampagna: ' + ((_d = (_c = this.campaignContainer) === null || _c === void 0 ? void 0 : _c.campaign) === null || _d === void 0 ? void 0 : _d.campaignId) + (((_f = (_e = this.campaignContainer) === null || _e === void 0 ? void 0 : _e.campaign) === null || _f === void 0 ? void 0 : _f.type) === 'school' ? '%0D%0Ateam: ' + ((_h = (_g = this.team) === null || _g === void 0 ? void 0 : _g.customData) === null || _h === void 0 ? void 0 : _h.name) : '') + '%0D%0AplayerId: ' + this.profile.playerId + '%0D%0A%0D%0A-----SCRIVI IL TUO MESSAGGIO QUI SOTTO----'); // territorio, campagna, nome squadra, ID utente (Oggetto: "Play&go <nome campagna> Supporto"
    }
  }]);

  return CampaignDetailsPage;
}();

CampaignDetailsPage.ɵfac = function CampaignDetailsPage_Factory(t) {
  return new (t || CampaignDetailsPage)(_angular_core__WEBPACK_IMPORTED_MODULE_23__["ɵɵdirectiveInject"](_angular_router__WEBPACK_IMPORTED_MODULE_36__.ActivatedRoute), _angular_core__WEBPACK_IMPORTED_MODULE_23__["ɵɵdirectiveInject"](src_app_core_shared_services_campaign_service__WEBPACK_IMPORTED_MODULE_9__.CampaignService), _angular_core__WEBPACK_IMPORTED_MODULE_23__["ɵɵdirectiveInject"](src_app_core_shared_services_alert_service__WEBPACK_IMPORTED_MODULE_10__.AlertService), _angular_core__WEBPACK_IMPORTED_MODULE_23__["ɵɵdirectiveInject"](src_app_core_shared_services_user_service__WEBPACK_IMPORTED_MODULE_11__.UserService), _angular_core__WEBPACK_IMPORTED_MODULE_23__["ɵɵdirectiveInject"](_ionic_angular__WEBPACK_IMPORTED_MODULE_37__.NavController), _angular_core__WEBPACK_IMPORTED_MODULE_23__["ɵɵdirectiveInject"](_ionic_angular__WEBPACK_IMPORTED_MODULE_37__.ModalController), _angular_core__WEBPACK_IMPORTED_MODULE_23__["ɵɵdirectiveInject"](src_app_core_shared_services_notifications_notifications_service__WEBPACK_IMPORTED_MODULE_12__.NotificationService), _angular_core__WEBPACK_IMPORTED_MODULE_23__["ɵɵdirectiveInject"](src_app_core_shared_services_page_settings_service__WEBPACK_IMPORTED_MODULE_13__.PageSettingsService), _angular_core__WEBPACK_IMPORTED_MODULE_23__["ɵɵdirectiveInject"](src_app_core_shared_services_error_service__WEBPACK_IMPORTED_MODULE_7__.ErrorService), _angular_core__WEBPACK_IMPORTED_MODULE_23__["ɵɵdirectiveInject"](src_app_core_shared_services_team_service__WEBPACK_IMPORTED_MODULE_14__.TeamService));
};

CampaignDetailsPage.ɵcmp = /*@__PURE__*/_angular_core__WEBPACK_IMPORTED_MODULE_23__["ɵɵdefineComponent"]({
  type: CampaignDetailsPage,
  selectors: [["app-campaign-details"]],
  viewQuery: function CampaignDetailsPage_Query(rf, ctx) {
    if (rf & 1) {
      _angular_core__WEBPACK_IMPORTED_MODULE_23__["ɵɵviewQuery"](_c0, 5);
    }

    if (rf & 2) {
      var _t;

      _angular_core__WEBPACK_IMPORTED_MODULE_23__["ɵɵqueryRefresh"](_t = _angular_core__WEBPACK_IMPORTED_MODULE_23__["ɵɵloadQuery"]()) && (ctx.ionContent = _t.first);
    }
  },
  decls: 1,
  vars: 1,
  consts: [[4, "ngIf"], ["appHeader", "", "parallax", "", "height", "30vh", 3, "imageUrl"], ["appContent", "", "class", "page", 3, "fullscreen", "scrollEvents", 4, "ngIf"], ["appContent", "", 1, "page", 3, "fullscreen", "scrollEvents"], [1, "avatar-campaign", 3, "ngStyle"], ["title", "campaign logo", 3, "src"], [3, "campaign", "header"], [4, "ngFor", "ngForOf"], [3, "routerLink", 4, "ngIf"], [3, "routerLink"], [3, "color"], ["name", "list", 1, "icon-size-normal"], ["lines", "none", 4, "ngIf"], [1, "box", 3, "ngClass", "click"], [1, "text", 3, "innerHTML"], [1, "expansion", 3, "click"], ["name", "chevron-up-outline", 4, "ngIf"], ["name", "chevron-down-outline", 4, "ngIf"], [3, "color", "click"], ["name", "mail-outline", "end", ""], [3, "click", 4, "ngIf"], [3, "campaign", "notification"], ["name", "leaderboard", 1, "icon-size-normal"], ["name", "stat", 1, "icon-size-normal"], ["name", "default", 1, "icon-size-normal"], ["name", "badges", 1, "icon-size-normal"], ["name", "blacklist", 1, "icon-size-normal"], ["lines", "none"], [1, "text-bold"], ["name", "chevron-up-outline"], ["name", "chevron-down-outline"], [3, "click"], [1, "text-bold", "text-underlined"], ["name", "information-circle-outline", "end", ""], ["name", "list", "end", ""], ["name", "help-circle-outline", "end", ""], [3, "innerHTML"], ["color", "danger"], ["name", "leave", 1, "icon-size-normal"]],
  template: function CampaignDetailsPage_Template(rf, ctx) {
    if (rf & 1) {
      _angular_core__WEBPACK_IMPORTED_MODULE_23__["ɵɵtemplate"](0, CampaignDetailsPage_ng_container_0_Template, 3, 2, "ng-container", 0);
    }

    if (rf & 2) {
      _angular_core__WEBPACK_IMPORTED_MODULE_23__["ɵɵproperty"]("ngIf", ctx.campaignContainer);
    }
  },
  directives: [_angular_common__WEBPACK_IMPORTED_MODULE_38__.NgIf, _ionic_angular__WEBPACK_IMPORTED_MODULE_37__.IonHeader, _core_shared_directives_parallax_header_directive__WEBPACK_IMPORTED_MODULE_15__.ParallaxDirective, _core_shared_layout_header_header_directive__WEBPACK_IMPORTED_MODULE_16__.HeaderDirective, _ionic_angular__WEBPACK_IMPORTED_MODULE_37__.IonContent, _core_shared_layout_content_content_directive__WEBPACK_IMPORTED_MODULE_17__.ContentDirective, _ionic_angular__WEBPACK_IMPORTED_MODULE_37__.IonAvatar, _angular_common__WEBPACK_IMPORTED_MODULE_38__.NgStyle, _core_shared_campaigns_app_widget_campaign_app_widget_campaign_component__WEBPACK_IMPORTED_MODULE_18__.WidgetComponent, _angular_common__WEBPACK_IMPORTED_MODULE_38__.NgForOf, _campaign_notification_campaign_notification_component__WEBPACK_IMPORTED_MODULE_19__.CampaignNotificationComponent, _ionic_angular__WEBPACK_IMPORTED_MODULE_37__.IonCard, _angular_router__WEBPACK_IMPORTED_MODULE_36__.RouterLink, _ionic_angular__WEBPACK_IMPORTED_MODULE_37__.RouterLinkDelegate, _ionic_angular__WEBPACK_IMPORTED_MODULE_37__.IonItem, _ionic_angular__WEBPACK_IMPORTED_MODULE_37__.IonLabel, _core_shared_ui_icon_icon_component__WEBPACK_IMPORTED_MODULE_20__.IconComponent, _ionic_angular__WEBPACK_IMPORTED_MODULE_37__.IonCardTitle, _ionic_angular__WEBPACK_IMPORTED_MODULE_37__.IonCardContent, _angular_common__WEBPACK_IMPORTED_MODULE_38__.NgClass, _ionic_angular__WEBPACK_IMPORTED_MODULE_37__.IonIcon],
  pipes: [_ngx_translate_core__WEBPACK_IMPORTED_MODULE_39__.TranslatePipe, _core_shared_pipes_localDate_pipe__WEBPACK_IMPORTED_MODULE_21__.LocalDatePipe, _core_shared_pipes_languageMap_pipe__WEBPACK_IMPORTED_MODULE_22__.LanguageMapPipe],
  styles: [".avatar-campaign[_ngcontent-%COMP%] {\n  margin: 16px auto;\n}\n\n.expansion[_ngcontent-%COMP%] {\n  text-align: center;\n  font-size: xx-large;\n}\n\n\n\n.box[_ngcontent-%COMP%] {\n  max-height: 162px;\n  overflow: hidden;\n  transition: max-height 0.3s cubic-bezier(0, 1, 0, 1);\n}\n\nion-card[_ngcontent-%COMP%] {\n  margin-top: 40px;\n}\n\nion-card[_ngcontent-%COMP%]   ion-card-title[_ngcontent-%COMP%] {\n  font-weight: 600;\n}\n\nion-card[_ngcontent-%COMP%]   ion-item[_ngcontent-%COMP%]   ion-label[_ngcontent-%COMP%] {\n  font-weight: 600;\n}\n\n.box.open[_ngcontent-%COMP%] {\n  max-height: 100rem;\n  transition: max-height 0.3s cubic-bezier(0.9, 0, 0.8, 0.2);\n}\n\n.text[_ngcontent-%COMP%] {\n  display: -webkit-box;\n  -webkit-box-orient: vertical;\n  padding: 2px;\n  text-overflow: ellipsis;\n  overflow: hidden;\n  margin: 12px 0;\n  animation: close 0.1s linear 0.1s forwards;\n}\n\n.open[_ngcontent-%COMP%]   .text[_ngcontent-%COMP%] {\n  animation: open 0.1s linear 0s forwards;\n}\n\n\n\n@keyframes open {\n  from {\n    display: -webkit-box;\n    line-clamp: 3;\n    -webkit-line-clamp: 3;\n    -webkit-box-orient: vertical;\n  }\n  to {\n    display: -webkit-box;\n    line-clamp: initial;\n    -webkit-line-clamp: initial;\n    -webkit-box-orient: vertical;\n  }\n}\n\n@keyframes close {\n  from {\n    display: -webkit-box;\n    line-clamp: initial;\n    -webkit-line-clamp: initial;\n    -webkit-box-orient: vertical;\n  }\n  to {\n    display: -webkit-box;\n    line-clamp: 3;\n    -webkit-line-clamp: 3;\n    -webkit-box-orient: vertical;\n  }\n}\n/*# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbImNhbXBhaWduLWRldGFpbHMucGFnZS5zY3NzIl0sIm5hbWVzIjpbXSwibWFwcGluZ3MiOiJBQUFBO0VBQ0UsaUJBQUE7QUFDRjs7QUFDQTtFQUNFLGtCQUFBO0VBQ0EsbUJBQUE7QUFFRjs7QUFBQSxRQUFBOztBQUNBO0VBSUUsaUJBQUE7RUFDQSxnQkFBQTtFQUNBLG9EQUFBO0FBQUY7O0FBRUE7RUFDRSxnQkFBQTtBQUNGOztBQUFFO0VBQ0UsZ0JBQUE7QUFFSjs7QUFDSTtFQUNFLGdCQUFBO0FBQ047O0FBR0E7RUFDRSxrQkFBQTtFQUNBLDBEQUFBO0FBQUY7O0FBRUE7RUFDRSxvQkFBQTtFQUNBLDRCQUFBO0VBQ0EsWUFBQTtFQUNBLHVCQUFBO0VBQ0EsZ0JBQUE7RUFDQSxjQUFBO0VBQ0EsMENBQUE7QUFDRjs7QUFDQTtFQUNFLHVDQUFBO0FBRUY7O0FBQ0EsU0FBQTs7QUFDQTtFQUNFO0lBQ0Usb0JBQUE7SUFDQSxhQUFBO0lBQ0EscUJBQUE7SUFDQSw0QkFBQTtFQUVGO0VBQUE7SUFDRSxvQkFBQTtJQUNBLG1CQUFBO0lBQ0EsMkJBQUE7SUFDQSw0QkFBQTtFQUVGO0FBQ0Y7O0FBQ0E7RUFDRTtJQUNFLG9CQUFBO0lBQ0EsbUJBQUE7SUFDQSwyQkFBQTtJQUNBLDRCQUFBO0VBQ0Y7RUFDQTtJQUNFLG9CQUFBO0lBQ0EsYUFBQTtJQUNBLHFCQUFBO0lBQ0EsNEJBQUE7RUFDRjtBQUNGIiwiZmlsZSI6ImNhbXBhaWduLWRldGFpbHMucGFnZS5zY3NzIiwic291cmNlc0NvbnRlbnQiOlsiLmF2YXRhci1jYW1wYWlnbiB7XG4gIG1hcmdpbjogMTZweCBhdXRvO1xufVxuLmV4cGFuc2lvbiB7XG4gIHRleHQtYWxpZ246IGNlbnRlcjtcbiAgZm9udC1zaXplOiB4eC1sYXJnZTtcbn1cbi8qIEJveCAqL1xuLmJveCB7XG4gIC8vIG1hcmdpbjogMjJweCBhdXRvO1xuICAvLyB3aWR0aDogMzIwcHg7XG4gIC8vIHBhZGRpbmc6IDEycHggMzJweCA2NHB4O1xuICBtYXgtaGVpZ2h0OiAxNjJweDtcbiAgb3ZlcmZsb3c6IGhpZGRlbjtcbiAgdHJhbnNpdGlvbjogbWF4LWhlaWdodCAwLjNzIGN1YmljLWJlemllcigwLCAxLCAwLCAxKTtcbn1cbmlvbi1jYXJkIHtcbiAgbWFyZ2luLXRvcDogNDBweDtcbiAgaW9uLWNhcmQtdGl0bGUge1xuICAgIGZvbnQtd2VpZ2h0OiA2MDA7XG4gIH1cbiAgaW9uLWl0ZW0ge1xuICAgIGlvbi1sYWJlbCB7XG4gICAgICBmb250LXdlaWdodDogNjAwO1xuICAgIH1cbiAgfVxufVxuLmJveC5vcGVuIHtcbiAgbWF4LWhlaWdodDogMTAwcmVtO1xuICB0cmFuc2l0aW9uOiBtYXgtaGVpZ2h0IDAuM3MgY3ViaWMtYmV6aWVyKDAuOSwgMCwgMC44LCAwLjIpO1xufVxuLnRleHQge1xuICBkaXNwbGF5OiAtd2Via2l0LWJveDtcbiAgLXdlYmtpdC1ib3gtb3JpZW50OiB2ZXJ0aWNhbDtcbiAgcGFkZGluZzogMnB4O1xuICB0ZXh0LW92ZXJmbG93OiBlbGxpcHNpcztcbiAgb3ZlcmZsb3c6IGhpZGRlbjtcbiAgbWFyZ2luOiAxMnB4IDA7XG4gIGFuaW1hdGlvbjogY2xvc2UgMC4xcyBsaW5lYXIgMC4xcyBmb3J3YXJkcztcbn1cbi5vcGVuIC50ZXh0IHtcbiAgYW5pbWF0aW9uOiBvcGVuIDAuMXMgbGluZWFyIDBzIGZvcndhcmRzO1xufVxuXG4vKiBUZXh0ICovXG5Aa2V5ZnJhbWVzIG9wZW4ge1xuICBmcm9tIHtcbiAgICBkaXNwbGF5OiAtd2Via2l0LWJveDtcbiAgICBsaW5lLWNsYW1wOiAzO1xuICAgIC13ZWJraXQtbGluZS1jbGFtcDogMztcbiAgICAtd2Via2l0LWJveC1vcmllbnQ6IHZlcnRpY2FsO1xuICB9XG4gIHRvIHtcbiAgICBkaXNwbGF5OiAtd2Via2l0LWJveDtcbiAgICBsaW5lLWNsYW1wOiBpbml0aWFsO1xuICAgIC13ZWJraXQtbGluZS1jbGFtcDogaW5pdGlhbDtcbiAgICAtd2Via2l0LWJveC1vcmllbnQ6IHZlcnRpY2FsO1xuICB9XG59XG5cbkBrZXlmcmFtZXMgY2xvc2Uge1xuICBmcm9tIHtcbiAgICBkaXNwbGF5OiAtd2Via2l0LWJveDtcbiAgICBsaW5lLWNsYW1wOiBpbml0aWFsO1xuICAgIC13ZWJraXQtbGluZS1jbGFtcDogaW5pdGlhbDtcbiAgICAtd2Via2l0LWJveC1vcmllbnQ6IHZlcnRpY2FsO1xuICB9XG4gIHRvIHtcbiAgICBkaXNwbGF5OiAtd2Via2l0LWJveDtcbiAgICBsaW5lLWNsYW1wOiAzO1xuICAgIC13ZWJraXQtbGluZS1jbGFtcDogMztcbiAgICAtd2Via2l0LWJveC1vcmllbnQ6IHZlcnRpY2FsO1xuICB9XG59XG4iXX0= */"]
});

/***/ }),

/***/ 48058:
/*!******************************************************************************************************!*\
  !*** ./src/app/pages/home/campaign-details/campaign-notification/campaign-notification.component.ts ***!
  \******************************************************************************************************/
/***/ (function(__unused_webpack_module, __webpack_exports__, __webpack_require__) {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "CampaignNotificationComponent": function() { return /* binding */ CampaignNotificationComponent; }
/* harmony export */ });
/* harmony import */ var _Users_smartcommunitylab_Documents_work_projects_dslab_playgo_mobile_playgo_mobile_node_modules_babel_runtime_helpers_esm_classCallCheck_js__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./node_modules/@babel/runtime/helpers/esm/classCallCheck.js */ 78069);
/* harmony import */ var _Users_smartcommunitylab_Documents_work_projects_dslab_playgo_mobile_playgo_mobile_node_modules_babel_runtime_helpers_esm_createClass_js__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ./node_modules/@babel/runtime/helpers/esm/createClass.js */ 48047);
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! tslib */ 34929);
/* harmony import */ var src_app_core_shared_detail_notification_detail_notification_modal__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! src/app/core/shared/detail-notification/detail-notification.modal */ 72526);
/* harmony import */ var src_app_core_shared_services_notifications_notifications_service__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! src/app/core/shared/services/notifications/notifications.service */ 30299);
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! @angular/core */ 3184);
/* harmony import */ var _ionic_angular__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(/*! @ionic/angular */ 93819);
/* harmony import */ var _ngx_translate_core__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(/*! @ngx-translate/core */ 87514);
/* harmony import */ var _core_shared_ui_icon_icon_component__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! ../../../../core/shared/ui/icon/icon.component */ 71888);



function _regeneratorRuntime() { "use strict"; /*! regenerator-runtime -- Copyright (c) 2014-present, Facebook, Inc. -- license (MIT): https://github.com/facebook/regenerator/blob/main/LICENSE */ _regeneratorRuntime = function _regeneratorRuntime() { return exports; }; var exports = {}, Op = Object.prototype, hasOwn = Op.hasOwnProperty, $Symbol = "function" == typeof Symbol ? Symbol : {}, iteratorSymbol = $Symbol.iterator || "@@iterator", asyncIteratorSymbol = $Symbol.asyncIterator || "@@asyncIterator", toStringTagSymbol = $Symbol.toStringTag || "@@toStringTag"; function define(obj, key, value) { return Object.defineProperty(obj, key, { value: value, enumerable: !0, configurable: !0, writable: !0 }), obj[key]; } try { define({}, ""); } catch (err) { define = function define(obj, key, value) { return obj[key] = value; }; } function wrap(innerFn, outerFn, self, tryLocsList) { var protoGenerator = outerFn && outerFn.prototype instanceof Generator ? outerFn : Generator, generator = Object.create(protoGenerator.prototype), context = new Context(tryLocsList || []); return generator._invoke = function (innerFn, self, context) { var state = "suspendedStart"; return function (method, arg) { if ("executing" === state) throw new Error("Generator is already running"); if ("completed" === state) { if ("throw" === method) throw arg; return doneResult(); } for (context.method = method, context.arg = arg;;) { var delegate = context.delegate; if (delegate) { var delegateResult = maybeInvokeDelegate(delegate, context); if (delegateResult) { if (delegateResult === ContinueSentinel) continue; return delegateResult; } } if ("next" === context.method) context.sent = context._sent = context.arg;else if ("throw" === context.method) { if ("suspendedStart" === state) throw state = "completed", context.arg; context.dispatchException(context.arg); } else "return" === context.method && context.abrupt("return", context.arg); state = "executing"; var record = tryCatch(innerFn, self, context); if ("normal" === record.type) { if (state = context.done ? "completed" : "suspendedYield", record.arg === ContinueSentinel) continue; return { value: record.arg, done: context.done }; } "throw" === record.type && (state = "completed", context.method = "throw", context.arg = record.arg); } }; }(innerFn, self, context), generator; } function tryCatch(fn, obj, arg) { try { return { type: "normal", arg: fn.call(obj, arg) }; } catch (err) { return { type: "throw", arg: err }; } } exports.wrap = wrap; var ContinueSentinel = {}; function Generator() {} function GeneratorFunction() {} function GeneratorFunctionPrototype() {} var IteratorPrototype = {}; define(IteratorPrototype, iteratorSymbol, function () { return this; }); var getProto = Object.getPrototypeOf, NativeIteratorPrototype = getProto && getProto(getProto(values([]))); NativeIteratorPrototype && NativeIteratorPrototype !== Op && hasOwn.call(NativeIteratorPrototype, iteratorSymbol) && (IteratorPrototype = NativeIteratorPrototype); var Gp = GeneratorFunctionPrototype.prototype = Generator.prototype = Object.create(IteratorPrototype); function defineIteratorMethods(prototype) { ["next", "throw", "return"].forEach(function (method) { define(prototype, method, function (arg) { return this._invoke(method, arg); }); }); } function AsyncIterator(generator, PromiseImpl) { function invoke(method, arg, resolve, reject) { var record = tryCatch(generator[method], generator, arg); if ("throw" !== record.type) { var result = record.arg, value = result.value; return value && "object" == typeof value && hasOwn.call(value, "__await") ? PromiseImpl.resolve(value.__await).then(function (value) { invoke("next", value, resolve, reject); }, function (err) { invoke("throw", err, resolve, reject); }) : PromiseImpl.resolve(value).then(function (unwrapped) { result.value = unwrapped, resolve(result); }, function (error) { return invoke("throw", error, resolve, reject); }); } reject(record.arg); } var previousPromise; this._invoke = function (method, arg) { function callInvokeWithMethodAndArg() { return new PromiseImpl(function (resolve, reject) { invoke(method, arg, resolve, reject); }); } return previousPromise = previousPromise ? previousPromise.then(callInvokeWithMethodAndArg, callInvokeWithMethodAndArg) : callInvokeWithMethodAndArg(); }; } function maybeInvokeDelegate(delegate, context) { var method = delegate.iterator[context.method]; if (undefined === method) { if (context.delegate = null, "throw" === context.method) { if (delegate.iterator.return && (context.method = "return", context.arg = undefined, maybeInvokeDelegate(delegate, context), "throw" === context.method)) return ContinueSentinel; context.method = "throw", context.arg = new TypeError("The iterator does not provide a 'throw' method"); } return ContinueSentinel; } var record = tryCatch(method, delegate.iterator, context.arg); if ("throw" === record.type) return context.method = "throw", context.arg = record.arg, context.delegate = null, ContinueSentinel; var info = record.arg; return info ? info.done ? (context[delegate.resultName] = info.value, context.next = delegate.nextLoc, "return" !== context.method && (context.method = "next", context.arg = undefined), context.delegate = null, ContinueSentinel) : info : (context.method = "throw", context.arg = new TypeError("iterator result is not an object"), context.delegate = null, ContinueSentinel); } function pushTryEntry(locs) { var entry = { tryLoc: locs[0] }; 1 in locs && (entry.catchLoc = locs[1]), 2 in locs && (entry.finallyLoc = locs[2], entry.afterLoc = locs[3]), this.tryEntries.push(entry); } function resetTryEntry(entry) { var record = entry.completion || {}; record.type = "normal", delete record.arg, entry.completion = record; } function Context(tryLocsList) { this.tryEntries = [{ tryLoc: "root" }], tryLocsList.forEach(pushTryEntry, this), this.reset(!0); } function values(iterable) { if (iterable) { var iteratorMethod = iterable[iteratorSymbol]; if (iteratorMethod) return iteratorMethod.call(iterable); if ("function" == typeof iterable.next) return iterable; if (!isNaN(iterable.length)) { var i = -1, next = function next() { for (; ++i < iterable.length;) { if (hasOwn.call(iterable, i)) return next.value = iterable[i], next.done = !1, next; } return next.value = undefined, next.done = !0, next; }; return next.next = next; } } return { next: doneResult }; } function doneResult() { return { value: undefined, done: !0 }; } return GeneratorFunction.prototype = GeneratorFunctionPrototype, define(Gp, "constructor", GeneratorFunctionPrototype), define(GeneratorFunctionPrototype, "constructor", GeneratorFunction), GeneratorFunction.displayName = define(GeneratorFunctionPrototype, toStringTagSymbol, "GeneratorFunction"), exports.isGeneratorFunction = function (genFun) { var ctor = "function" == typeof genFun && genFun.constructor; return !!ctor && (ctor === GeneratorFunction || "GeneratorFunction" === (ctor.displayName || ctor.name)); }, exports.mark = function (genFun) { return Object.setPrototypeOf ? Object.setPrototypeOf(genFun, GeneratorFunctionPrototype) : (genFun.__proto__ = GeneratorFunctionPrototype, define(genFun, toStringTagSymbol, "GeneratorFunction")), genFun.prototype = Object.create(Gp), genFun; }, exports.awrap = function (arg) { return { __await: arg }; }, defineIteratorMethods(AsyncIterator.prototype), define(AsyncIterator.prototype, asyncIteratorSymbol, function () { return this; }), exports.AsyncIterator = AsyncIterator, exports.async = function (innerFn, outerFn, self, tryLocsList, PromiseImpl) { void 0 === PromiseImpl && (PromiseImpl = Promise); var iter = new AsyncIterator(wrap(innerFn, outerFn, self, tryLocsList), PromiseImpl); return exports.isGeneratorFunction(outerFn) ? iter : iter.next().then(function (result) { return result.done ? result.value : iter.next(); }); }, defineIteratorMethods(Gp), define(Gp, toStringTagSymbol, "Generator"), define(Gp, iteratorSymbol, function () { return this; }), define(Gp, "toString", function () { return "[object Generator]"; }), exports.keys = function (object) { var keys = []; for (var key in object) { keys.push(key); } return keys.reverse(), function next() { for (; keys.length;) { var key = keys.pop(); if (key in object) return next.value = key, next.done = !1, next; } return next.done = !0, next; }; }, exports.values = values, Context.prototype = { constructor: Context, reset: function reset(skipTempReset) { if (this.prev = 0, this.next = 0, this.sent = this._sent = undefined, this.done = !1, this.delegate = null, this.method = "next", this.arg = undefined, this.tryEntries.forEach(resetTryEntry), !skipTempReset) for (var name in this) { "t" === name.charAt(0) && hasOwn.call(this, name) && !isNaN(+name.slice(1)) && (this[name] = undefined); } }, stop: function stop() { this.done = !0; var rootRecord = this.tryEntries[0].completion; if ("throw" === rootRecord.type) throw rootRecord.arg; return this.rval; }, dispatchException: function dispatchException(exception) { if (this.done) throw exception; var context = this; function handle(loc, caught) { return record.type = "throw", record.arg = exception, context.next = loc, caught && (context.method = "next", context.arg = undefined), !!caught; } for (var i = this.tryEntries.length - 1; i >= 0; --i) { var entry = this.tryEntries[i], record = entry.completion; if ("root" === entry.tryLoc) return handle("end"); if (entry.tryLoc <= this.prev) { var hasCatch = hasOwn.call(entry, "catchLoc"), hasFinally = hasOwn.call(entry, "finallyLoc"); if (hasCatch && hasFinally) { if (this.prev < entry.catchLoc) return handle(entry.catchLoc, !0); if (this.prev < entry.finallyLoc) return handle(entry.finallyLoc); } else if (hasCatch) { if (this.prev < entry.catchLoc) return handle(entry.catchLoc, !0); } else { if (!hasFinally) throw new Error("try statement without catch or finally"); if (this.prev < entry.finallyLoc) return handle(entry.finallyLoc); } } } }, abrupt: function abrupt(type, arg) { for (var i = this.tryEntries.length - 1; i >= 0; --i) { var entry = this.tryEntries[i]; if (entry.tryLoc <= this.prev && hasOwn.call(entry, "finallyLoc") && this.prev < entry.finallyLoc) { var finallyEntry = entry; break; } } finallyEntry && ("break" === type || "continue" === type) && finallyEntry.tryLoc <= arg && arg <= finallyEntry.finallyLoc && (finallyEntry = null); var record = finallyEntry ? finallyEntry.completion : {}; return record.type = type, record.arg = arg, finallyEntry ? (this.method = "next", this.next = finallyEntry.finallyLoc, ContinueSentinel) : this.complete(record); }, complete: function complete(record, afterLoc) { if ("throw" === record.type) throw record.arg; return "break" === record.type || "continue" === record.type ? this.next = record.arg : "return" === record.type ? (this.rval = this.arg = record.arg, this.method = "return", this.next = "end") : "normal" === record.type && afterLoc && (this.next = afterLoc), ContinueSentinel; }, finish: function finish(finallyLoc) { for (var i = this.tryEntries.length - 1; i >= 0; --i) { var entry = this.tryEntries[i]; if (entry.finallyLoc === finallyLoc) return this.complete(entry.completion, entry.afterLoc), resetTryEntry(entry), ContinueSentinel; } }, catch: function _catch(tryLoc) { for (var i = this.tryEntries.length - 1; i >= 0; --i) { var entry = this.tryEntries[i]; if (entry.tryLoc === tryLoc) { var record = entry.completion; if ("throw" === record.type) { var thrown = record.arg; resetTryEntry(entry); } return thrown; } } throw new Error("illegal catch attempt"); }, delegateYield: function delegateYield(iterable, resultName, nextLoc) { return this.delegate = { iterator: values(iterable), resultName: resultName, nextLoc: nextLoc }, "next" === this.method && (this.arg = undefined), ContinueSentinel; } }, exports; }









var CampaignNotificationComponent = /*#__PURE__*/function () {
  function CampaignNotificationComponent(modalController, notificationService, translateService) {
    (0,_Users_smartcommunitylab_Documents_work_projects_dslab_playgo_mobile_playgo_mobile_node_modules_babel_runtime_helpers_esm_classCallCheck_js__WEBPACK_IMPORTED_MODULE_0__["default"])(this, CampaignNotificationComponent);

    this.modalController = modalController;
    this.notificationService = notificationService;
    this.translateService = translateService;
  }

  (0,_Users_smartcommunitylab_Documents_work_projects_dslab_playgo_mobile_playgo_mobile_node_modules_babel_runtime_helpers_esm_createClass_js__WEBPACK_IMPORTED_MODULE_1__["default"])(CampaignNotificationComponent, [{
    key: "ngOnInit",
    value: function ngOnInit() {}
  }, {
    key: "openDetail",
    value: function openDetail(notification) {
      return (0,tslib__WEBPACK_IMPORTED_MODULE_5__.__awaiter)(this, void 0, void 0, /*#__PURE__*/_regeneratorRuntime().mark(function _callee() {
        var modal;
        return _regeneratorRuntime().wrap(function _callee$(_context) {
          while (1) {
            switch (_context.prev = _context.next) {
              case 0:
                _context.next = 2;
                return this.modalController.create({
                  component: src_app_core_shared_detail_notification_detail_notification_modal__WEBPACK_IMPORTED_MODULE_2__.DetailNotificationModalPage,
                  cssClass: 'campaign-notification',
                  componentProps: {
                    notification: notification,
                    campaign: this.campaign
                  }
                });

              case 2:
                modal = _context.sent;
                _context.next = 5;
                return modal.present();

              case 5:
                //mark as read the notification
                this.notificationService.markListOfNotificationAsRead([notification]);
                _context.next = 8;
                return modal.onWillDismiss();

              case 8:
              case "end":
                return _context.stop();
            }
          }
        }, _callee, this);
      }));
    }
  }, {
    key: "getTitle",
    value: function getTitle(notification) {
      var _a;

      switch ((_a = notification === null || notification === void 0 ? void 0 : notification.content) === null || _a === void 0 ? void 0 : _a.type) {
        case src_app_core_shared_services_notifications_notifications_service__WEBPACK_IMPORTED_MODULE_3__.NotificationType.level:
          return this.translateService.instant('modal.levelup');

        case src_app_core_shared_services_notifications_notifications_service__WEBPACK_IMPORTED_MODULE_3__.NotificationType.badge:
          return this.translateService.instant('modal.newbadge');

        default:
          return '';
      }
    }
  }, {
    key: "getImage",
    value: function getImage(notification) {
      var _a;

      switch ((_a = notification === null || notification === void 0 ? void 0 : notification.content) === null || _a === void 0 ? void 0 : _a.type) {
        case src_app_core_shared_services_notifications_notifications_service__WEBPACK_IMPORTED_MODULE_3__.NotificationType.level:
          return 'leaderboard';

        case src_app_core_shared_services_notifications_notifications_service__WEBPACK_IMPORTED_MODULE_3__.NotificationType.badge:
          return 'badges';

        default:
          return '';
      }
    }
  }]);

  return CampaignNotificationComponent;
}();

CampaignNotificationComponent.ɵfac = function CampaignNotificationComponent_Factory(t) {
  return new (t || CampaignNotificationComponent)(_angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵdirectiveInject"](_ionic_angular__WEBPACK_IMPORTED_MODULE_7__.ModalController), _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵdirectiveInject"](src_app_core_shared_services_notifications_notifications_service__WEBPACK_IMPORTED_MODULE_3__.NotificationService), _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵdirectiveInject"](_ngx_translate_core__WEBPACK_IMPORTED_MODULE_8__.TranslateService));
};

CampaignNotificationComponent.ɵcmp = /*@__PURE__*/_angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵdefineComponent"]({
  type: CampaignNotificationComponent,
  selectors: [["app-campaign-notification"]],
  inputs: {
    notification: "notification",
    campaign: "campaign"
  },
  decls: 17,
  vars: 4,
  consts: [[3, "color", "click"], ["color", "danger"], ["name", "alert"], ["size", "10"], [1, "description"], ["size", "2"], [1, "icon-size-big", 3, "name"]],
  template: function CampaignNotificationComponent_Template(rf, ctx) {
    if (rf & 1) {
      _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵelementStart"](0, "ion-card", 0);
      _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵlistener"]("click", function CampaignNotificationComponent_Template_ion_card_click_0_listener() {
        return ctx.openDetail(ctx.notification);
      });
      _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵelementStart"](1, "ion-badge", 1);
      _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵelement"](2, "ion-icon", 2);
      _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵelementEnd"]();
      _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵelementStart"](3, "ion-grid")(4, "ion-row")(5, "ion-col", 3)(6, "ion-row")(7, "ion-col")(8, "span")(9, "b");
      _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵtext"](10);
      _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵelementEnd"]()()();
      _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵelementStart"](11, "ion-row")(12, "ion-col")(13, "span", 4);
      _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵtext"](14);
      _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵelementEnd"]()()()()();
      _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵelementStart"](15, "ion-col", 5);
      _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵelement"](16, "app-icon", 6);
      _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵelementEnd"]()()()();
    }

    if (rf & 2) {
      _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵproperty"]("color", (ctx.campaign == null ? null : ctx.campaign.campaign == null ? null : ctx.campaign.campaign.type) + "-light");
      _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵadvance"](10);
      _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵtextInterpolate"](ctx.getTitle(ctx.notification));
      _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵadvance"](4);
      _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵtextInterpolate"](ctx.notification.description);
      _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵadvance"](2);
      _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵproperty"]("name", ctx.getImage(ctx.notification));
    }
  },
  directives: [_ionic_angular__WEBPACK_IMPORTED_MODULE_7__.IonCard, _ionic_angular__WEBPACK_IMPORTED_MODULE_7__.IonBadge, _ionic_angular__WEBPACK_IMPORTED_MODULE_7__.IonIcon, _ionic_angular__WEBPACK_IMPORTED_MODULE_7__.IonGrid, _ionic_angular__WEBPACK_IMPORTED_MODULE_7__.IonRow, _ionic_angular__WEBPACK_IMPORTED_MODULE_7__.IonCol, _core_shared_ui_icon_icon_component__WEBPACK_IMPORTED_MODULE_4__.IconComponent],
  styles: ["ion-card[_ngcontent-%COMP%] {\n  overflow: visible;\n}\nion-card[_ngcontent-%COMP%]   .description[_ngcontent-%COMP%] {\n  font-style: italic;\n  font-size: 13px;\n  \n  width: 100%;\n  display: -webkit-box;\n  -webkit-line-clamp: 2;\n  -webkit-box-orient: vertical;\n  overflow: hidden;\n  text-overflow: ellipsis;\n}\nion-card[_ngcontent-%COMP%]   ion-badge[_ngcontent-%COMP%] {\n  position: absolute;\n  z-index: 99;\n  right: -8px;\n  top: -8px;\n}\n/*# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbImNhbXBhaWduLW5vdGlmaWNhdGlvbi5jb21wb25lbnQuc2NzcyJdLCJuYW1lcyI6W10sIm1hcHBpbmdzIjoiQUFBQTtFQUNFLGlCQUFBO0FBQ0Y7QUFBRTtFQUNFLGtCQUFBO0VBQ0EsZUFBQTtFQUNBLHFCQUFBO0VBQ0EsV0FBQTtFQUNBLG9CQUFBO0VBQ0EscUJBQUE7RUFDQSw0QkFBQTtFQUNBLGdCQUFBO0VBQ0EsdUJBQUE7QUFFSjtBQUFFO0VBQ0Usa0JBQUE7RUFDQSxXQUFBO0VBQ0EsV0FBQTtFQUNBLFNBQUE7QUFFSiIsImZpbGUiOiJjYW1wYWlnbi1ub3RpZmljYXRpb24uY29tcG9uZW50LnNjc3MiLCJzb3VyY2VzQ29udGVudCI6WyJpb24tY2FyZCB7XG4gIG92ZXJmbG93OiB2aXNpYmxlO1xuICAuZGVzY3JpcHRpb24ge1xuICAgIGZvbnQtc3R5bGU6IGl0YWxpYztcbiAgICBmb250LXNpemU6IDEzcHg7XG4gICAgLyogZm9udC1zaXplOiAxN3B4OyAqL1xuICAgIHdpZHRoOiAxMDAlO1xuICAgIGRpc3BsYXk6IC13ZWJraXQtYm94O1xuICAgIC13ZWJraXQtbGluZS1jbGFtcDogMjtcbiAgICAtd2Via2l0LWJveC1vcmllbnQ6IHZlcnRpY2FsO1xuICAgIG92ZXJmbG93OiBoaWRkZW47XG4gICAgdGV4dC1vdmVyZmxvdzogZWxsaXBzaXM7XG4gIH1cbiAgaW9uLWJhZGdlIHtcbiAgICBwb3NpdGlvbjogYWJzb2x1dGU7XG4gICAgei1pbmRleDogOTk7XG4gICAgcmlnaHQ6IC04cHg7XG4gICAgdG9wOiAtOHB4O1xuICB9XG59XG4iXX0= */"]
});

/***/ }),

/***/ 88043:
/*!********************************************************************************!*\
  !*** ./src/app/pages/home/campaign-details/companies-modal/companies.modal.ts ***!
  \********************************************************************************/
/***/ (function(__unused_webpack_module, __webpack_exports__, __webpack_require__) {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "CompaniesCampaignModalPage": function() { return /* binding */ CompaniesCampaignModalPage; }
/* harmony export */ });
/* harmony import */ var _Users_smartcommunitylab_Documents_work_projects_dslab_playgo_mobile_playgo_mobile_node_modules_babel_runtime_helpers_esm_classCallCheck_js__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./node_modules/@babel/runtime/helpers/esm/classCallCheck.js */ 78069);
/* harmony import */ var _Users_smartcommunitylab_Documents_work_projects_dslab_playgo_mobile_playgo_mobile_node_modules_babel_runtime_helpers_esm_createClass_js__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ./node_modules/@babel/runtime/helpers/esm/createClass.js */ 48047);
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @angular/core */ 3184);
/* harmony import */ var _ionic_angular__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! @ionic/angular */ 93819);
/* harmony import */ var src_app_core_shared_services_campaign_service__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! src/app/core/shared/services/campaign.service */ 23645);
/* harmony import */ var _angular_common__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! @angular/common */ 36362);
/* harmony import */ var _ngx_translate_core__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! @ngx-translate/core */ 87514);








function CompaniesCampaignModalPage_div_10_Template(rf, ctx) {
  if (rf & 1) {
    _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵelementStart"](0, "div")(1, "ion-item")(2, "ion-label");
    _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵtext"](3);
    _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵelementEnd"]()()();
  }

  if (rf & 2) {
    var company_r1 = ctx.$implicit;
    _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵadvance"](3);
    _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵtextInterpolate"](company_r1.name);
  }
}

var CompaniesCampaignModalPage = /*#__PURE__*/function () {
  function CompaniesCampaignModalPage(modalController, campaignService) {
    (0,_Users_smartcommunitylab_Documents_work_projects_dslab_playgo_mobile_playgo_mobile_node_modules_babel_runtime_helpers_esm_classCallCheck_js__WEBPACK_IMPORTED_MODULE_0__["default"])(this, CompaniesCampaignModalPage);

    this.modalController = modalController;
    this.campaignService = campaignService;
  }

  (0,_Users_smartcommunitylab_Documents_work_projects_dslab_playgo_mobile_playgo_mobile_node_modules_babel_runtime_helpers_esm_createClass_js__WEBPACK_IMPORTED_MODULE_1__["default"])(CompaniesCampaignModalPage, [{
    key: "ngOnInit",
    value: function ngOnInit() {
      var _this = this;

      var _a;

      this.sub = this.campaignService.getCompaniesForSubscription((_a = this === null || this === void 0 ? void 0 : this.campaign) === null || _a === void 0 ? void 0 : _a.campaignId).subscribe(function (result) {
        if (result) {
          _this.companies = result;
        }
      });
    }
  }, {
    key: "close",
    value: function close() {
      this.modalController.dismiss(false);
    }
  }]);

  return CompaniesCampaignModalPage;
}();

CompaniesCampaignModalPage.ɵfac = function CompaniesCampaignModalPage_Factory(t) {
  return new (t || CompaniesCampaignModalPage)(_angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵdirectiveInject"](_ionic_angular__WEBPACK_IMPORTED_MODULE_4__.ModalController), _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵdirectiveInject"](src_app_core_shared_services_campaign_service__WEBPACK_IMPORTED_MODULE_2__.CampaignService));
};

CompaniesCampaignModalPage.ɵcmp = /*@__PURE__*/_angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵdefineComponent"]({
  type: CompaniesCampaignModalPage,
  selectors: [["app-detail-modal"]],
  decls: 11,
  vars: 7,
  consts: [["color", "playgo"], ["slot", "end"], [3, "click"], [1, "ion-padding"], [4, "ngFor", "ngForOf"]],
  template: function CompaniesCampaignModalPage_Template(rf, ctx) {
    if (rf & 1) {
      _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵelementStart"](0, "ion-header")(1, "ion-toolbar", 0)(2, "ion-title");
      _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵtext"](3);
      _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵpipe"](4, "translate");
      _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵelementEnd"]();
      _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵelementStart"](5, "ion-buttons", 1)(6, "ion-button", 2);
      _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵlistener"]("click", function CompaniesCampaignModalPage_Template_ion_button_click_6_listener() {
        return ctx.close();
      });
      _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵtext"](7);
      _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵpipe"](8, "translate");
      _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵelementEnd"]()()()();
      _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵelementStart"](9, "ion-content", 3);
      _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵtemplate"](10, CompaniesCampaignModalPage_div_10_Template, 4, 1, "div", 4);
      _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵelementEnd"]();
    }

    if (rf & 2) {
      _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵadvance"](3);
      _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵtextInterpolate"](_angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵpipeBind1"](4, 3, "campaigns.campaignmodal.title"));
      _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵadvance"](4);
      _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵtextInterpolate"](_angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵpipeBind1"](8, 5, "campaigns.campaignmodal.close"));
      _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵadvance"](3);
      _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵproperty"]("ngForOf", ctx.companies);
    }
  },
  directives: [_ionic_angular__WEBPACK_IMPORTED_MODULE_4__.IonHeader, _ionic_angular__WEBPACK_IMPORTED_MODULE_4__.IonToolbar, _ionic_angular__WEBPACK_IMPORTED_MODULE_4__.IonTitle, _ionic_angular__WEBPACK_IMPORTED_MODULE_4__.IonButtons, _ionic_angular__WEBPACK_IMPORTED_MODULE_4__.IonButton, _ionic_angular__WEBPACK_IMPORTED_MODULE_4__.IonContent, _angular_common__WEBPACK_IMPORTED_MODULE_5__.NgForOf, _ionic_angular__WEBPACK_IMPORTED_MODULE_4__.IonItem, _ionic_angular__WEBPACK_IMPORTED_MODULE_4__.IonLabel],
  pipes: [_ngx_translate_core__WEBPACK_IMPORTED_MODULE_6__.TranslatePipe],
  styles: ["\n/*# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbXSwibmFtZXMiOltdLCJtYXBwaW5ncyI6IiIsImZpbGUiOiJjb21wYW5pZXMubW9kYWwuc2NzcyJ9 */"]
});

/***/ }),

/***/ 30451:
/*!**************************************************************************!*\
  !*** ./src/app/pages/home/campaign-details/detail-modal/detail.modal.ts ***!
  \**************************************************************************/
/***/ (function(__unused_webpack_module, __webpack_exports__, __webpack_require__) {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "DetailCampaignModalPage": function() { return /* binding */ DetailCampaignModalPage; }
/* harmony export */ });
/* harmony import */ var _Users_smartcommunitylab_Documents_work_projects_dslab_playgo_mobile_playgo_mobile_node_modules_babel_runtime_helpers_esm_classCallCheck_js__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./node_modules/@babel/runtime/helpers/esm/classCallCheck.js */ 78069);
/* harmony import */ var _Users_smartcommunitylab_Documents_work_projects_dslab_playgo_mobile_playgo_mobile_node_modules_babel_runtime_helpers_esm_createClass_js__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ./node_modules/@babel/runtime/helpers/esm/createClass.js */ 48047);
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @angular/core */ 3184);
/* harmony import */ var _ionic_angular__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @ionic/angular */ 93819);




var DetailCampaignModalPage = /*#__PURE__*/function () {
  function DetailCampaignModalPage(modalController) {
    (0,_Users_smartcommunitylab_Documents_work_projects_dslab_playgo_mobile_playgo_mobile_node_modules_babel_runtime_helpers_esm_classCallCheck_js__WEBPACK_IMPORTED_MODULE_0__["default"])(this, DetailCampaignModalPage);

    this.modalController = modalController;
    this.type = 'playgo';
  }

  (0,_Users_smartcommunitylab_Documents_work_projects_dslab_playgo_mobile_playgo_mobile_node_modules_babel_runtime_helpers_esm_createClass_js__WEBPACK_IMPORTED_MODULE_1__["default"])(DetailCampaignModalPage, [{
    key: "ngOnInit",
    value: function ngOnInit() {}
  }, {
    key: "close",
    value: function close() {
      this.modalController.dismiss(false);
    }
  }]);

  return DetailCampaignModalPage;
}();

DetailCampaignModalPage.ɵfac = function DetailCampaignModalPage_Factory(t) {
  return new (t || DetailCampaignModalPage)(_angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵdirectiveInject"](_ionic_angular__WEBPACK_IMPORTED_MODULE_3__.ModalController));
};

DetailCampaignModalPage.ɵcmp = /*@__PURE__*/_angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵdefineComponent"]({
  type: DetailCampaignModalPage,
  selectors: [["app-detail-modal"]],
  decls: 9,
  vars: 3,
  consts: [[3, "color"], ["slot", "end"], [3, "click"], ["name", "close-circle-outline"], [1, "ion-padding"], [3, "innerHTML"]],
  template: function DetailCampaignModalPage_Template(rf, ctx) {
    if (rf & 1) {
      _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵelementStart"](0, "ion-header")(1, "ion-toolbar", 0)(2, "ion-title");
      _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵtext"](3);
      _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵelementEnd"]();
      _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵelementStart"](4, "ion-buttons", 1)(5, "ion-button", 2);
      _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵlistener"]("click", function DetailCampaignModalPage_Template_ion_button_click_5_listener() {
        return ctx.close();
      });
      _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵelement"](6, "ion-icon", 3);
      _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵelementEnd"]()()()();
      _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵelementStart"](7, "ion-content", 4);
      _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵelement"](8, "div", 5);
      _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵelementEnd"]();
    }

    if (rf & 2) {
      _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵadvance"](1);
      _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵproperty"]("color", ctx.type);
      _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵadvance"](2);
      _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵtextInterpolate"](ctx.detail == null ? null : ctx.detail.name);
      _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵadvance"](5);
      _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵproperty"]("innerHTML", ctx.detail == null ? null : ctx.detail.content, _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵsanitizeHtml"]);
    }
  },
  directives: [_ionic_angular__WEBPACK_IMPORTED_MODULE_3__.IonHeader, _ionic_angular__WEBPACK_IMPORTED_MODULE_3__.IonToolbar, _ionic_angular__WEBPACK_IMPORTED_MODULE_3__.IonTitle, _ionic_angular__WEBPACK_IMPORTED_MODULE_3__.IonButtons, _ionic_angular__WEBPACK_IMPORTED_MODULE_3__.IonButton, _ionic_angular__WEBPACK_IMPORTED_MODULE_3__.IonIcon, _ionic_angular__WEBPACK_IMPORTED_MODULE_3__.IonContent],
  styles: ["\n/*# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbXSwibmFtZXMiOltdLCJtYXBwaW5ncyI6IiIsImZpbGUiOiJkZXRhaWwubW9kYWwuc2NzcyJ9 */"]
});

/***/ }),

/***/ 57164:
/*!************************************************************************************!*\
  !*** ./src/app/pages/home/campaign-details/unsubscribe-modal/unsubscribe.modal.ts ***!
  \************************************************************************************/
/***/ (function(__unused_webpack_module, __webpack_exports__, __webpack_require__) {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "UnsubscribeModalPage": function() { return /* binding */ UnsubscribeModalPage; }
/* harmony export */ });
/* harmony import */ var _Users_smartcommunitylab_Documents_work_projects_dslab_playgo_mobile_playgo_mobile_node_modules_babel_runtime_helpers_esm_classCallCheck_js__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./node_modules/@babel/runtime/helpers/esm/classCallCheck.js */ 78069);
/* harmony import */ var _Users_smartcommunitylab_Documents_work_projects_dslab_playgo_mobile_playgo_mobile_node_modules_babel_runtime_helpers_esm_createClass_js__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ./node_modules/@babel/runtime/helpers/esm/createClass.js */ 48047);
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @angular/core */ 3184);
/* harmony import */ var _ionic_angular__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @ionic/angular */ 93819);
/* harmony import */ var _ngx_translate_core__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! @ngx-translate/core */ 87514);





var _c0 = ["class", "modal"];
var UnsubscribeModalPage = /*#__PURE__*/function () {
  function UnsubscribeModalPage(modalController) {
    (0,_Users_smartcommunitylab_Documents_work_projects_dslab_playgo_mobile_playgo_mobile_node_modules_babel_runtime_helpers_esm_classCallCheck_js__WEBPACK_IMPORTED_MODULE_0__["default"])(this, UnsubscribeModalPage);

    this.modalController = modalController;
  }

  (0,_Users_smartcommunitylab_Documents_work_projects_dslab_playgo_mobile_playgo_mobile_node_modules_babel_runtime_helpers_esm_createClass_js__WEBPACK_IMPORTED_MODULE_1__["default"])(UnsubscribeModalPage, [{
    key: "ngOnInit",
    value: function ngOnInit() {}
  }, {
    key: "close",
    value: function close() {
      this.modalController.dismiss(false);
    }
  }, {
    key: "confirm",
    value: function confirm() {
      this.modalController.dismiss(true);
    }
  }]);

  return UnsubscribeModalPage;
}();

UnsubscribeModalPage.ɵfac = function UnsubscribeModalPage_Factory(t) {
  return new (t || UnsubscribeModalPage)(_angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵdirectiveInject"](_ionic_angular__WEBPACK_IMPORTED_MODULE_3__.ModalController));
};

UnsubscribeModalPage.ɵcmp = /*@__PURE__*/_angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵdefineComponent"]({
  type: UnsubscribeModalPage,
  selectors: [["app-unsubscribe", 8, "modal"]],
  attrs: _c0,
  decls: 18,
  vars: 12,
  consts: [["color", "playgo", 1, "external"], [1, "title"], ["color", "playgo", 1, "internal"], [1, "body"], ["size", "6"], ["expand", "block", "color", "light", 3, "click"], ["expand", "block", "color", "danger", 3, "click"]],
  template: function UnsubscribeModalPage_Template(rf, ctx) {
    if (rf & 1) {
      _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵelementStart"](0, "ion-content", 0)(1, "p", 1);
      _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵtext"](2);
      _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵpipe"](3, "translate");
      _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵelementEnd"]();
      _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵelementStart"](4, "div", 2)(5, "p", 3);
      _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵtext"](6);
      _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵpipe"](7, "translate");
      _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵelementEnd"]()();
      _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵelementStart"](8, "ion-grid")(9, "ion-row")(10, "ion-col", 4)(11, "ion-button", 5);
      _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵlistener"]("click", function UnsubscribeModalPage_Template_ion_button_click_11_listener() {
        return ctx.close();
      });
      _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵtext"](12);
      _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵpipe"](13, "translate");
      _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵelementEnd"]()();
      _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵelementStart"](14, "ion-col", 4)(15, "ion-button", 6);
      _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵlistener"]("click", function UnsubscribeModalPage_Template_ion_button_click_15_listener() {
        return ctx.confirm();
      });
      _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵtext"](16);
      _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵpipe"](17, "translate");
      _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵelementEnd"]()()()()();
    }

    if (rf & 2) {
      _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵadvance"](2);
      _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵtextInterpolate"](_angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵpipeBind1"](3, 4, "campaigns.unsub.title"));
      _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵadvance"](4);
      _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵtextInterpolate"](_angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵpipeBind1"](7, 6, "campaigns.unsub.text"));
      _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵadvance"](6);
      _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵtextInterpolate"](_angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵpipeBind1"](13, 8, "campaigns.unsub.close"));
      _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵadvance"](4);
      _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵtextInterpolate"](_angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵpipeBind1"](17, 10, "campaigns.unsub.confirm"));
    }
  },
  directives: [_ionic_angular__WEBPACK_IMPORTED_MODULE_3__.IonContent, _ionic_angular__WEBPACK_IMPORTED_MODULE_3__.IonGrid, _ionic_angular__WEBPACK_IMPORTED_MODULE_3__.IonRow, _ionic_angular__WEBPACK_IMPORTED_MODULE_3__.IonCol, _ionic_angular__WEBPACK_IMPORTED_MODULE_3__.IonButton],
  pipes: [_ngx_translate_core__WEBPACK_IMPORTED_MODULE_4__.TranslatePipe],
  styles: [".external[_ngcontent-%COMP%]   .title[_ngcontent-%COMP%] {\n  text-align: center;\n  font-weight: bold;\n  padding: 8px;\n}\n.external[_ngcontent-%COMP%]   .internal[_ngcontent-%COMP%]   .body[_ngcontent-%COMP%] {\n  text-align: justify;\n  padding: 8px;\n}\n.external[_ngcontent-%COMP%]   ion-grid[_ngcontent-%COMP%] {\n  position: absolute;\n  bottom: 0px;\n  width: 100%;\n}\n/*# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbInVuc3Vic2NyaWJlLm1vZGFsLnNjc3MiXSwibmFtZXMiOltdLCJtYXBwaW5ncyI6IkFBQ0U7RUFDRSxrQkFBQTtFQUNBLGlCQUFBO0VBQ0EsWUFBQTtBQUFKO0FBR0k7RUFDRSxtQkFBQTtFQUNBLFlBQUE7QUFETjtBQUlFO0VBQ0Usa0JBQUE7RUFDQSxXQUFBO0VBQ0EsV0FBQTtBQUZKIiwiZmlsZSI6InVuc3Vic2NyaWJlLm1vZGFsLnNjc3MiLCJzb3VyY2VzQ29udGVudCI6WyIuZXh0ZXJuYWwge1xuICAudGl0bGUge1xuICAgIHRleHQtYWxpZ246IGNlbnRlcjtcbiAgICBmb250LXdlaWdodDogYm9sZDtcbiAgICBwYWRkaW5nOiA4cHg7XG4gIH1cbiAgLmludGVybmFsIHtcbiAgICAuYm9keSB7XG4gICAgICB0ZXh0LWFsaWduOiBqdXN0aWZ5O1xuICAgICAgcGFkZGluZzogOHB4O1xuICAgIH1cbiAgfVxuICBpb24tZ3JpZCB7XG4gICAgcG9zaXRpb246IGFic29sdXRlO1xuICAgIGJvdHRvbTogMHB4O1xuICAgIHdpZHRoOiAxMDAlO1xuICB9XG59XG4iXX0= */"]
});

/***/ })

}]);
//# sourceMappingURL=default-src_app_pages_home_campaign-details_campaign-details_module_ts.js.map