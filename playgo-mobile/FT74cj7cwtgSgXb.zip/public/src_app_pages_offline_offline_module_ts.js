"use strict";
(self["webpackChunkapp"] = self["webpackChunkapp"] || []).push([["src_app_pages_offline_offline_module_ts"],{

/***/ 45988:
/*!*********************************************************!*\
  !*** ./src/app/pages/offline/offline-routing.module.ts ***!
  \*********************************************************/
/***/ (function(__unused_webpack_module, __webpack_exports__, __webpack_require__) {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "OfflinePageRoutingModule": function() { return /* binding */ OfflinePageRoutingModule; }
/* harmony export */ });
/* harmony import */ var _Users_smartcommunitylab_Desktop_newWork_dslab_playgo_mobile_playgo_mobile_node_modules_babel_runtime_helpers_esm_createClass_js__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./node_modules/@babel/runtime/helpers/esm/createClass.js */ 48047);
/* harmony import */ var _Users_smartcommunitylab_Desktop_newWork_dslab_playgo_mobile_playgo_mobile_node_modules_babel_runtime_helpers_esm_classCallCheck_js__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ./node_modules/@babel/runtime/helpers/esm/classCallCheck.js */ 78069);
/* harmony import */ var _angular_router__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! @angular/router */ 52816);
/* harmony import */ var _offline_page__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! ./offline.page */ 97178);
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @angular/core */ 3184);






var routes = [{
  path: '',
  component: _offline_page__WEBPACK_IMPORTED_MODULE_2__.OfflinePage,
  data: {
    title: 'offline.title',
    isOfflinePage: true
  }
}];
var OfflinePageRoutingModule = /*#__PURE__*/(0,_Users_smartcommunitylab_Desktop_newWork_dslab_playgo_mobile_playgo_mobile_node_modules_babel_runtime_helpers_esm_createClass_js__WEBPACK_IMPORTED_MODULE_0__["default"])(function OfflinePageRoutingModule() {
  (0,_Users_smartcommunitylab_Desktop_newWork_dslab_playgo_mobile_playgo_mobile_node_modules_babel_runtime_helpers_esm_classCallCheck_js__WEBPACK_IMPORTED_MODULE_1__["default"])(this, OfflinePageRoutingModule);
});

OfflinePageRoutingModule.ɵfac = function OfflinePageRoutingModule_Factory(t) {
  return new (t || OfflinePageRoutingModule)();
};

OfflinePageRoutingModule.ɵmod = /*@__PURE__*/_angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵdefineNgModule"]({
  type: OfflinePageRoutingModule
});
OfflinePageRoutingModule.ɵinj = /*@__PURE__*/_angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵdefineInjector"]({
  imports: [[_angular_router__WEBPACK_IMPORTED_MODULE_4__.RouterModule.forChild(routes)], _angular_router__WEBPACK_IMPORTED_MODULE_4__.RouterModule]
});

(function () {
  (typeof ngJitMode === "undefined" || ngJitMode) && _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵsetNgModuleScope"](OfflinePageRoutingModule, {
    imports: [_angular_router__WEBPACK_IMPORTED_MODULE_4__.RouterModule],
    exports: [_angular_router__WEBPACK_IMPORTED_MODULE_4__.RouterModule]
  });
})();

/***/ }),

/***/ 66175:
/*!*************************************************!*\
  !*** ./src/app/pages/offline/offline.module.ts ***!
  \*************************************************/
/***/ (function(__unused_webpack_module, __webpack_exports__, __webpack_require__) {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "OfflinePageModule": function() { return /* binding */ OfflinePageModule; }
/* harmony export */ });
/* harmony import */ var _Users_smartcommunitylab_Desktop_newWork_dslab_playgo_mobile_playgo_mobile_node_modules_babel_runtime_helpers_esm_createClass_js__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./node_modules/@babel/runtime/helpers/esm/createClass.js */ 48047);
/* harmony import */ var _Users_smartcommunitylab_Desktop_newWork_dslab_playgo_mobile_playgo_mobile_node_modules_babel_runtime_helpers_esm_classCallCheck_js__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ./node_modules/@babel/runtime/helpers/esm/classCallCheck.js */ 78069);
/* harmony import */ var _offline_routing_module__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! ./offline-routing.module */ 45988);
/* harmony import */ var _offline_page__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! ./offline.page */ 97178);
/* harmony import */ var src_app_core_shared_shared_module__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! src/app/core/shared/shared.module */ 97205);
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! @angular/core */ 3184);






var OfflinePageModule = /*#__PURE__*/(0,_Users_smartcommunitylab_Desktop_newWork_dslab_playgo_mobile_playgo_mobile_node_modules_babel_runtime_helpers_esm_createClass_js__WEBPACK_IMPORTED_MODULE_0__["default"])(function OfflinePageModule() {
  (0,_Users_smartcommunitylab_Desktop_newWork_dslab_playgo_mobile_playgo_mobile_node_modules_babel_runtime_helpers_esm_classCallCheck_js__WEBPACK_IMPORTED_MODULE_1__["default"])(this, OfflinePageModule);
});

OfflinePageModule.ɵfac = function OfflinePageModule_Factory(t) {
  return new (t || OfflinePageModule)();
};

OfflinePageModule.ɵmod = /*@__PURE__*/_angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵdefineNgModule"]({
  type: OfflinePageModule
});
OfflinePageModule.ɵinj = /*@__PURE__*/_angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵdefineInjector"]({
  imports: [[_offline_routing_module__WEBPACK_IMPORTED_MODULE_2__.OfflinePageRoutingModule, src_app_core_shared_shared_module__WEBPACK_IMPORTED_MODULE_4__.PlayGoSharedModule]]
});

(function () {
  (typeof ngJitMode === "undefined" || ngJitMode) && _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵsetNgModuleScope"](OfflinePageModule, {
    declarations: [_offline_page__WEBPACK_IMPORTED_MODULE_3__.OfflinePage],
    imports: [_offline_routing_module__WEBPACK_IMPORTED_MODULE_2__.OfflinePageRoutingModule, src_app_core_shared_shared_module__WEBPACK_IMPORTED_MODULE_4__.PlayGoSharedModule]
  });
})();

/***/ }),

/***/ 97178:
/*!***********************************************!*\
  !*** ./src/app/pages/offline/offline.page.ts ***!
  \***********************************************/
/***/ (function(__unused_webpack_module, __webpack_exports__, __webpack_require__) {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "OfflinePage": function() { return /* binding */ OfflinePage; }
/* harmony export */ });
/* harmony import */ var _Users_smartcommunitylab_Desktop_newWork_dslab_playgo_mobile_playgo_mobile_node_modules_babel_runtime_helpers_esm_classCallCheck_js__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./node_modules/@babel/runtime/helpers/esm/classCallCheck.js */ 78069);
/* harmony import */ var _Users_smartcommunitylab_Desktop_newWork_dslab_playgo_mobile_playgo_mobile_node_modules_babel_runtime_helpers_esm_createClass_js__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ./node_modules/@babel/runtime/helpers/esm/createClass.js */ 48047);
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! @angular/core */ 3184);
/* harmony import */ var _ionic_angular__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! @ionic/angular */ 93819);
/* harmony import */ var _core_shared_layout_header_header_directive__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! ../../core/shared/layout/header/header.directive */ 34161);
/* harmony import */ var _core_shared_layout_content_content_directive__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! ../../core/shared/layout/content/content.directive */ 69669);
/* harmony import */ var _core_shared_ui_icon_icon_component__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! ../../core/shared/ui/icon/icon.component */ 71888);
/* harmony import */ var _angular_router__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(/*! @angular/router */ 52816);
/* harmony import */ var _ngx_translate_core__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(/*! @ngx-translate/core */ 87514);










var _c0 = function _c0() {
  return ["/"];
};

var OfflinePage = /*#__PURE__*/function () {
  function OfflinePage() {
    (0,_Users_smartcommunitylab_Desktop_newWork_dslab_playgo_mobile_playgo_mobile_node_modules_babel_runtime_helpers_esm_classCallCheck_js__WEBPACK_IMPORTED_MODULE_0__["default"])(this, OfflinePage);
  }

  (0,_Users_smartcommunitylab_Desktop_newWork_dslab_playgo_mobile_playgo_mobile_node_modules_babel_runtime_helpers_esm_createClass_js__WEBPACK_IMPORTED_MODULE_1__["default"])(OfflinePage, [{
    key: "ngOnInit",
    value: function ngOnInit() {}
  }]);

  return OfflinePage;
}();

OfflinePage.ɵfac = function OfflinePage_Factory(t) {
  return new (t || OfflinePage)();
};

OfflinePage.ɵcmp = /*@__PURE__*/_angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵdefineComponent"]({
  type: OfflinePage,
  selectors: [["app-offline"]],
  decls: 19,
  vars: 14,
  consts: [["appHeader", ""], ["appContent", ""], [1, "ion-text-center"], ["name", "offline", 2, "font-size", "300%"], [3, "routerLink"]],
  template: function OfflinePage_Template(rf, ctx) {
    if (rf & 1) {
      _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵelement"](0, "ion-header", 0);
      _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵelementStart"](1, "ion-content", 1)(2, "div", 2)(3, "p");
      _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵelement"](4, "app-icon", 3);
      _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵelementEnd"]();
      _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵelementStart"](5, "p")(6, "b");
      _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵtext"](7);
      _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵpipe"](8, "translate");
      _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵelementEnd"]()();
      _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵelementStart"](9, "p");
      _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵtext"](10);
      _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵpipe"](11, "translate");
      _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵelementEnd"]();
      _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵelementStart"](12, "p");
      _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵtext"](13);
      _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵpipe"](14, "translate");
      _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵelementEnd"]();
      _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵelementStart"](15, "p")(16, "a", 4);
      _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵtext"](17);
      _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵpipe"](18, "translate");
      _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵelementEnd"]()()()();
    }

    if (rf & 2) {
      _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵadvance"](7);
      _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵtextInterpolate"](_angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵpipeBind1"](8, 5, "offline.page.body_1"));
      _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵadvance"](3);
      _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵtextInterpolate"](_angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵpipeBind1"](11, 7, "offline.page.body_2"));
      _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵadvance"](3);
      _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵtextInterpolate"](_angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵpipeBind1"](14, 9, "offline.page.body_3"));
      _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵadvance"](3);
      _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵproperty"]("routerLink", _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵpureFunction0"](13, _c0));
      _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵadvance"](1);
      _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵtextInterpolate1"](" ", _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵpipeBind1"](18, 11, "offline.page.return_home"), " ");
    }
  },
  directives: [_ionic_angular__WEBPACK_IMPORTED_MODULE_6__.IonHeader, _core_shared_layout_header_header_directive__WEBPACK_IMPORTED_MODULE_2__.HeaderDirective, _ionic_angular__WEBPACK_IMPORTED_MODULE_6__.IonContent, _core_shared_layout_content_content_directive__WEBPACK_IMPORTED_MODULE_3__.ContentDirective, _core_shared_ui_icon_icon_component__WEBPACK_IMPORTED_MODULE_4__.IconComponent, _angular_router__WEBPACK_IMPORTED_MODULE_7__.RouterLinkWithHref, _ionic_angular__WEBPACK_IMPORTED_MODULE_6__.RouterLinkWithHrefDelegate],
  pipes: [_ngx_translate_core__WEBPACK_IMPORTED_MODULE_8__.TranslatePipe],
  styles: ["\n/*# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbXSwibmFtZXMiOltdLCJtYXBwaW5ncyI6IiIsImZpbGUiOiJvZmZsaW5lLnBhZ2Uuc2NzcyJ9 */"]
});

/***/ })

}]);
//# sourceMappingURL=src_app_pages_offline_offline_module_ts.js.map