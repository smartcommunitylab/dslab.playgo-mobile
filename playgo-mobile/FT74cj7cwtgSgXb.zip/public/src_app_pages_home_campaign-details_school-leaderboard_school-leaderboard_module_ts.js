"use strict";
(self["webpackChunkapp"] = self["webpackChunkapp"] || []).push([["src_app_pages_home_campaign-details_school-leaderboard_school-leaderboard_module_ts"],{

/***/ 42341:
/*!*****************************************************************************************************!*\
  !*** ./src/app/pages/home/campaign-details/school-leaderboard/school-leaderboard-routing.module.ts ***!
  \*****************************************************************************************************/
/***/ (function(__unused_webpack_module, __webpack_exports__, __webpack_require__) {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "SchoolLeaderboardPageRoutingModule": function() { return /* binding */ SchoolLeaderboardPageRoutingModule; }
/* harmony export */ });
/* harmony import */ var _Users_smartcommunitylab_Desktop_newWork_dslab_playgo_mobile_playgo_mobile_node_modules_babel_runtime_helpers_esm_createClass_js__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./node_modules/@babel/runtime/helpers/esm/createClass.js */ 48047);
/* harmony import */ var _Users_smartcommunitylab_Desktop_newWork_dslab_playgo_mobile_playgo_mobile_node_modules_babel_runtime_helpers_esm_classCallCheck_js__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ./node_modules/@babel/runtime/helpers/esm/classCallCheck.js */ 78069);
/* harmony import */ var _angular_router__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! @angular/router */ 52816);
/* harmony import */ var _school_leaderboard_page__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! ./school-leaderboard.page */ 92541);
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @angular/core */ 3184);






var routes = [{
  path: '',
  component: _school_leaderboard_page__WEBPACK_IMPORTED_MODULE_2__.SchoolLeaderboardPage,
  data: {
    title: 'leaderboard.title',
    color: 'school',
    backButton: true
  }
}];
var SchoolLeaderboardPageRoutingModule = /*#__PURE__*/(0,_Users_smartcommunitylab_Desktop_newWork_dslab_playgo_mobile_playgo_mobile_node_modules_babel_runtime_helpers_esm_createClass_js__WEBPACK_IMPORTED_MODULE_0__["default"])(function SchoolLeaderboardPageRoutingModule() {
  (0,_Users_smartcommunitylab_Desktop_newWork_dslab_playgo_mobile_playgo_mobile_node_modules_babel_runtime_helpers_esm_classCallCheck_js__WEBPACK_IMPORTED_MODULE_1__["default"])(this, SchoolLeaderboardPageRoutingModule);
});

SchoolLeaderboardPageRoutingModule.ɵfac = function SchoolLeaderboardPageRoutingModule_Factory(t) {
  return new (t || SchoolLeaderboardPageRoutingModule)();
};

SchoolLeaderboardPageRoutingModule.ɵmod = /*@__PURE__*/_angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵdefineNgModule"]({
  type: SchoolLeaderboardPageRoutingModule
});
SchoolLeaderboardPageRoutingModule.ɵinj = /*@__PURE__*/_angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵdefineInjector"]({
  imports: [[_angular_router__WEBPACK_IMPORTED_MODULE_4__.RouterModule.forChild(routes)], _angular_router__WEBPACK_IMPORTED_MODULE_4__.RouterModule]
});

(function () {
  (typeof ngJitMode === "undefined" || ngJitMode) && _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵsetNgModuleScope"](SchoolLeaderboardPageRoutingModule, {
    imports: [_angular_router__WEBPACK_IMPORTED_MODULE_4__.RouterModule],
    exports: [_angular_router__WEBPACK_IMPORTED_MODULE_4__.RouterModule]
  });
})();

/***/ }),

/***/ 67379:
/*!*********************************************************************************************!*\
  !*** ./src/app/pages/home/campaign-details/school-leaderboard/school-leaderboard.module.ts ***!
  \*********************************************************************************************/
/***/ (function(__unused_webpack_module, __webpack_exports__, __webpack_require__) {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "SchoolLeaderboardPageModule": function() { return /* binding */ SchoolLeaderboardPageModule; }
/* harmony export */ });
/* harmony import */ var _Users_smartcommunitylab_Desktop_newWork_dslab_playgo_mobile_playgo_mobile_node_modules_babel_runtime_helpers_esm_createClass_js__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./node_modules/@babel/runtime/helpers/esm/createClass.js */ 48047);
/* harmony import */ var _Users_smartcommunitylab_Desktop_newWork_dslab_playgo_mobile_playgo_mobile_node_modules_babel_runtime_helpers_esm_classCallCheck_js__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ./node_modules/@babel/runtime/helpers/esm/classCallCheck.js */ 78069);
/* harmony import */ var _school_leaderboard_routing_module__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! ./school-leaderboard-routing.module */ 42341);
/* harmony import */ var _school_leaderboard_page__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! ./school-leaderboard.page */ 92541);
/* harmony import */ var src_app_core_shared_shared_module__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! src/app/core/shared/shared.module */ 97205);
/* harmony import */ var _school_placing_detail_school_placing_detail_component__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! ./school-placing-detail/school-placing-detail.component */ 73106);
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! @angular/core */ 3184);







var SchoolLeaderboardPageModule = /*#__PURE__*/(0,_Users_smartcommunitylab_Desktop_newWork_dslab_playgo_mobile_playgo_mobile_node_modules_babel_runtime_helpers_esm_createClass_js__WEBPACK_IMPORTED_MODULE_0__["default"])(function SchoolLeaderboardPageModule() {
  (0,_Users_smartcommunitylab_Desktop_newWork_dslab_playgo_mobile_playgo_mobile_node_modules_babel_runtime_helpers_esm_classCallCheck_js__WEBPACK_IMPORTED_MODULE_1__["default"])(this, SchoolLeaderboardPageModule);
});

SchoolLeaderboardPageModule.ɵfac = function SchoolLeaderboardPageModule_Factory(t) {
  return new (t || SchoolLeaderboardPageModule)();
};

SchoolLeaderboardPageModule.ɵmod = /*@__PURE__*/_angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵdefineNgModule"]({
  type: SchoolLeaderboardPageModule
});
SchoolLeaderboardPageModule.ɵinj = /*@__PURE__*/_angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵdefineInjector"]({
  imports: [[_school_leaderboard_routing_module__WEBPACK_IMPORTED_MODULE_2__.SchoolLeaderboardPageRoutingModule, src_app_core_shared_shared_module__WEBPACK_IMPORTED_MODULE_4__.PlayGoSharedModule]]
});

(function () {
  (typeof ngJitMode === "undefined" || ngJitMode) && _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵsetNgModuleScope"](SchoolLeaderboardPageModule, {
    declarations: [_school_leaderboard_page__WEBPACK_IMPORTED_MODULE_3__.SchoolLeaderboardPage, _school_placing_detail_school_placing_detail_component__WEBPACK_IMPORTED_MODULE_5__.SchoolPlacingDetailComponent],
    imports: [_school_leaderboard_routing_module__WEBPACK_IMPORTED_MODULE_2__.SchoolLeaderboardPageRoutingModule, src_app_core_shared_shared_module__WEBPACK_IMPORTED_MODULE_4__.PlayGoSharedModule]
  });
})();

/***/ }),

/***/ 92541:
/*!*******************************************************************************************!*\
  !*** ./src/app/pages/home/campaign-details/school-leaderboard/school-leaderboard.page.ts ***!
  \*******************************************************************************************/
/***/ (function(__unused_webpack_module, __webpack_exports__, __webpack_require__) {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "SchoolLeaderboardPage": function() { return /* binding */ SchoolLeaderboardPage; }
/* harmony export */ });
/* harmony import */ var _Users_smartcommunitylab_Desktop_newWork_dslab_playgo_mobile_playgo_mobile_node_modules_babel_runtime_helpers_esm_slicedToArray_js__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./node_modules/@babel/runtime/helpers/esm/slicedToArray.js */ 10507);
/* harmony import */ var _Users_smartcommunitylab_Desktop_newWork_dslab_playgo_mobile_playgo_mobile_node_modules_babel_runtime_helpers_esm_toConsumableArray_js__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ./node_modules/@babel/runtime/helpers/esm/toConsumableArray.js */ 58277);
/* harmony import */ var _Users_smartcommunitylab_Desktop_newWork_dslab_playgo_mobile_playgo_mobile_node_modules_babel_runtime_helpers_esm_defineProperty_js__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! ./node_modules/@babel/runtime/helpers/esm/defineProperty.js */ 77797);
/* harmony import */ var _Users_smartcommunitylab_Desktop_newWork_dslab_playgo_mobile_playgo_mobile_node_modules_babel_runtime_helpers_esm_classCallCheck_js__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! ./node_modules/@babel/runtime/helpers/esm/classCallCheck.js */ 78069);
/* harmony import */ var _Users_smartcommunitylab_Desktop_newWork_dslab_playgo_mobile_playgo_mobile_node_modules_babel_runtime_helpers_esm_createClass_js__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! ./node_modules/@babel/runtime/helpers/esm/createClass.js */ 48047);
/* harmony import */ var luxon__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! luxon */ 20020);
/* harmony import */ var lodash_es__WEBPACK_IMPORTED_MODULE_23__ = __webpack_require__(/*! lodash-es */ 97732);
/* harmony import */ var rxjs__WEBPACK_IMPORTED_MODULE_25__ = __webpack_require__(/*! rxjs */ 80228);
/* harmony import */ var rxjs__WEBPACK_IMPORTED_MODULE_27__ = __webpack_require__(/*! rxjs */ 26562);
/* harmony import */ var rxjs_operators__WEBPACK_IMPORTED_MODULE_19__ = __webpack_require__(/*! rxjs/operators */ 50635);
/* harmony import */ var rxjs_operators__WEBPACK_IMPORTED_MODULE_20__ = __webpack_require__(/*! rxjs/operators */ 98977);
/* harmony import */ var rxjs_operators__WEBPACK_IMPORTED_MODULE_21__ = __webpack_require__(/*! rxjs/operators */ 89196);
/* harmony import */ var rxjs_operators__WEBPACK_IMPORTED_MODULE_22__ = __webpack_require__(/*! rxjs/operators */ 32673);
/* harmony import */ var rxjs_operators__WEBPACK_IMPORTED_MODULE_24__ = __webpack_require__(/*! rxjs/operators */ 19337);
/* harmony import */ var rxjs_operators__WEBPACK_IMPORTED_MODULE_26__ = __webpack_require__(/*! rxjs/operators */ 44874);
/* harmony import */ var src_app_core_shared_rxjs_utils__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! src/app/core/shared/rxjs.utils */ 9257);
/* harmony import */ var src_app_core_shared_time_utils__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(/*! src/app/core/shared/time.utils */ 93462);
/* harmony import */ var src_app_core_shared_tracking_trip_model__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(/*! src/app/core/shared/tracking/trip.model */ 49110);
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_18__ = __webpack_require__(/*! @angular/core */ 3184);
/* harmony import */ var _angular_router__WEBPACK_IMPORTED_MODULE_28__ = __webpack_require__(/*! @angular/router */ 52816);
/* harmony import */ var src_app_core_shared_services_team_service__WEBPACK_IMPORTED_MODULE_9__ = __webpack_require__(/*! src/app/core/shared/services/team.service */ 86612);
/* harmony import */ var src_app_core_api_generated_hsc_controllers_teamStatsController_service__WEBPACK_IMPORTED_MODULE_10__ = __webpack_require__(/*! src/app/core/api/generated-hsc/controllers/teamStatsController.service */ 7400);
/* harmony import */ var src_app_core_shared_services_campaign_service__WEBPACK_IMPORTED_MODULE_11__ = __webpack_require__(/*! src/app/core/shared/services/campaign.service */ 23645);
/* harmony import */ var src_app_core_shared_services_error_service__WEBPACK_IMPORTED_MODULE_12__ = __webpack_require__(/*! src/app/core/shared/services/error.service */ 96204);
/* harmony import */ var src_app_core_shared_services_page_settings_service__WEBPACK_IMPORTED_MODULE_13__ = __webpack_require__(/*! src/app/core/shared/services/page-settings.service */ 85294);
/* harmony import */ var _ionic_angular__WEBPACK_IMPORTED_MODULE_29__ = __webpack_require__(/*! @ionic/angular */ 93819);
/* harmony import */ var _core_shared_layout_header_header_directive__WEBPACK_IMPORTED_MODULE_14__ = __webpack_require__(/*! ../../../../core/shared/layout/header/header.directive */ 34161);
/* harmony import */ var _core_shared_layout_content_content_directive__WEBPACK_IMPORTED_MODULE_15__ = __webpack_require__(/*! ../../../../core/shared/layout/content/content.directive */ 69669);
/* harmony import */ var _angular_common__WEBPACK_IMPORTED_MODULE_30__ = __webpack_require__(/*! @angular/common */ 36362);
/* harmony import */ var _school_placing_detail_school_placing_detail_component__WEBPACK_IMPORTED_MODULE_16__ = __webpack_require__(/*! ./school-placing-detail/school-placing-detail.component */ 73106);
/* harmony import */ var _core_shared_infinite_scroll_infinite_scroll_component__WEBPACK_IMPORTED_MODULE_17__ = __webpack_require__(/*! ../../../../core/shared/infinite-scroll/infinite-scroll.component */ 3299);
/* harmony import */ var _ngx_translate_core__WEBPACK_IMPORTED_MODULE_31__ = __webpack_require__(/*! @ngx-translate/core */ 87514);



























function SchoolLeaderboardPage_ng_container_2_ion_col_8_Template(rf, ctx) {
  if (rf & 1) {
    _angular_core__WEBPACK_IMPORTED_MODULE_18__["ɵɵelementStart"](0, "ion-col", 13)(1, "ion-item", 14)(2, "span");
    _angular_core__WEBPACK_IMPORTED_MODULE_18__["ɵɵtext"](3);
    _angular_core__WEBPACK_IMPORTED_MODULE_18__["ɵɵpipe"](4, "translate");
    _angular_core__WEBPACK_IMPORTED_MODULE_18__["ɵɵelementEnd"]()()();
  }

  if (rf & 2) {
    var ctx_r1 = _angular_core__WEBPACK_IMPORTED_MODULE_18__["ɵɵnextContext"](2);
    _angular_core__WEBPACK_IMPORTED_MODULE_18__["ɵɵadvance"](1);
    _angular_core__WEBPACK_IMPORTED_MODULE_18__["ɵɵproperty"]("color", ctx_r1.campaignContainer == null ? null : ctx_r1.campaignContainer.campaign == null ? null : ctx_r1.campaignContainer.campaign.type);
    _angular_core__WEBPACK_IMPORTED_MODULE_18__["ɵɵadvance"](2);
    _angular_core__WEBPACK_IMPORTED_MODULE_18__["ɵɵtextInterpolate"](_angular_core__WEBPACK_IMPORTED_MODULE_18__["ɵɵpipeBind1"](4, 2, "campaigns.leaderboard.leaderboard_type.GL"));
  }
}

function SchoolLeaderboardPage_ng_container_2_ion_select_option_15_Template(rf, ctx) {
  if (rf & 1) {
    _angular_core__WEBPACK_IMPORTED_MODULE_18__["ɵɵelementStart"](0, "ion-select-option", 15);
    _angular_core__WEBPACK_IMPORTED_MODULE_18__["ɵɵtext"](1);
    _angular_core__WEBPACK_IMPORTED_MODULE_18__["ɵɵpipe"](2, "translate");
    _angular_core__WEBPACK_IMPORTED_MODULE_18__["ɵɵelementEnd"]();
  }

  if (rf & 2) {
    var period_r7 = ctx.$implicit;
    _angular_core__WEBPACK_IMPORTED_MODULE_18__["ɵɵproperty"]("value", period_r7);
    _angular_core__WEBPACK_IMPORTED_MODULE_18__["ɵɵadvance"](1);
    _angular_core__WEBPACK_IMPORTED_MODULE_18__["ɵɵtextInterpolate1"](" ", _angular_core__WEBPACK_IMPORTED_MODULE_18__["ɵɵpipeBind1"](2, 2, period_r7.labelKey), " ");
  }
}

function SchoolLeaderboardPage_ng_container_2_app_school_placing_detail_16_Template(rf, ctx) {
  if (rf & 1) {
    _angular_core__WEBPACK_IMPORTED_MODULE_18__["ɵɵelement"](0, "app-school-placing-detail", 16);
    _angular_core__WEBPACK_IMPORTED_MODULE_18__["ɵɵpipe"](1, "async");
    _angular_core__WEBPACK_IMPORTED_MODULE_18__["ɵɵpipe"](2, "async");
  }

  if (rf & 2) {
    var ctx_r3 = _angular_core__WEBPACK_IMPORTED_MODULE_18__["ɵɵnextContext"](2);
    _angular_core__WEBPACK_IMPORTED_MODULE_18__["ɵɵproperty"]("myTeam", ctx_r3.myTeam)("placing", _angular_core__WEBPACK_IMPORTED_MODULE_18__["ɵɵpipeBind1"](1, 5, ctx_r3.teamPosition$))("unitLabelKey", _angular_core__WEBPACK_IMPORTED_MODULE_18__["ɵɵpipeBind1"](2, 7, ctx_r3.numberWithUnitKey$))("mine", true)("campaign", ctx_r3.campaignContainer);
  }
}

function SchoolLeaderboardPage_ng_container_2_ng_container_18_ng_template_4_Template(rf, ctx) {
  if (rf & 1) {
    _angular_core__WEBPACK_IMPORTED_MODULE_18__["ɵɵelement"](0, "app-school-placing-detail", 19);
    _angular_core__WEBPACK_IMPORTED_MODULE_18__["ɵɵpipe"](1, "async");
  }

  if (rf & 2) {
    var placing_r10 = ctx.item;
    var ctx_r9 = _angular_core__WEBPACK_IMPORTED_MODULE_18__["ɵɵnextContext"](3);
    _angular_core__WEBPACK_IMPORTED_MODULE_18__["ɵɵproperty"]("placing", placing_r10)("unitLabelKey", _angular_core__WEBPACK_IMPORTED_MODULE_18__["ɵɵpipeBind1"](1, 5, ctx_r9.numberWithUnitKey$))("mine", false)("campaign", ctx_r9.campaignContainer)("myTeam", ctx_r9.myTeam);
  }
}

function SchoolLeaderboardPage_ng_container_2_ng_container_18_Template(rf, ctx) {
  if (rf & 1) {
    var _r12 = _angular_core__WEBPACK_IMPORTED_MODULE_18__["ɵɵgetCurrentView"]();

    _angular_core__WEBPACK_IMPORTED_MODULE_18__["ɵɵelementContainerStart"](0);
    _angular_core__WEBPACK_IMPORTED_MODULE_18__["ɵɵelementStart"](1, "app-infinite-scroll", 17);
    _angular_core__WEBPACK_IMPORTED_MODULE_18__["ɵɵlistener"]("request", function SchoolLeaderboardPage_ng_container_2_ng_container_18_Template_app_infinite_scroll_request_1_listener($event) {
      _angular_core__WEBPACK_IMPORTED_MODULE_18__["ɵɵrestoreView"](_r12);
      var ctx_r11 = _angular_core__WEBPACK_IMPORTED_MODULE_18__["ɵɵnextContext"](2);
      return ctx_r11.scrollRequestSubject.next($event);
    });
    _angular_core__WEBPACK_IMPORTED_MODULE_18__["ɵɵpipe"](2, "async");
    _angular_core__WEBPACK_IMPORTED_MODULE_18__["ɵɵpipe"](3, "async");
    _angular_core__WEBPACK_IMPORTED_MODULE_18__["ɵɵtemplate"](4, SchoolLeaderboardPage_ng_container_2_ng_container_18_ng_template_4_Template, 2, 7, "ng-template", 18);
    _angular_core__WEBPACK_IMPORTED_MODULE_18__["ɵɵelementEnd"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_18__["ɵɵelementContainerEnd"]();
  }

  if (rf & 2) {
    var ctx_r4 = _angular_core__WEBPACK_IMPORTED_MODULE_18__["ɵɵnextContext"](2);
    _angular_core__WEBPACK_IMPORTED_MODULE_18__["ɵɵadvance"](1);
    _angular_core__WEBPACK_IMPORTED_MODULE_18__["ɵɵproperty"]("resetItems", _angular_core__WEBPACK_IMPORTED_MODULE_18__["ɵɵpipeBind1"](2, 2, ctx_r4.resetItems$))("response", _angular_core__WEBPACK_IMPORTED_MODULE_18__["ɵɵpipeBind1"](3, 4, ctx_r4.leaderboardScrollResponse$));
  }
}

function SchoolLeaderboardPage_ng_container_2_ng_template_21_Template(rf, ctx) {
  if (rf & 1) {
    _angular_core__WEBPACK_IMPORTED_MODULE_18__["ɵɵelementStart"](0, "ion-col")(1, "div", 20);
    _angular_core__WEBPACK_IMPORTED_MODULE_18__["ɵɵtext"](2);
    _angular_core__WEBPACK_IMPORTED_MODULE_18__["ɵɵpipe"](3, "translate");
    _angular_core__WEBPACK_IMPORTED_MODULE_18__["ɵɵelementEnd"]()();
  }

  if (rf & 2) {
    _angular_core__WEBPACK_IMPORTED_MODULE_18__["ɵɵadvance"](2);
    _angular_core__WEBPACK_IMPORTED_MODULE_18__["ɵɵtextInterpolate"](_angular_core__WEBPACK_IMPORTED_MODULE_18__["ɵɵpipeBind1"](3, 1, "campaigns.leaderboard.empty"));
  }
}

var _c0 = function _c0() {
  return {
    cssClass: "app-alert"
  };
};

function SchoolLeaderboardPage_ng_container_2_Template(rf, ctx) {
  if (rf & 1) {
    var _r14 = _angular_core__WEBPACK_IMPORTED_MODULE_18__["ɵɵgetCurrentView"]();

    _angular_core__WEBPACK_IMPORTED_MODULE_18__["ɵɵelementContainerStart"](0);
    _angular_core__WEBPACK_IMPORTED_MODULE_18__["ɵɵelementStart"](1, "div", 3)(2, "div", 4)(3, "ion-row")(4, "ion-col")(5, "ion-item", 5);
    _angular_core__WEBPACK_IMPORTED_MODULE_18__["ɵɵtext"](6);
    _angular_core__WEBPACK_IMPORTED_MODULE_18__["ɵɵpipe"](7, "translate");
    _angular_core__WEBPACK_IMPORTED_MODULE_18__["ɵɵelementEnd"]()();
    _angular_core__WEBPACK_IMPORTED_MODULE_18__["ɵɵtemplate"](8, SchoolLeaderboardPage_ng_container_2_ion_col_8_Template, 5, 4, "ion-col", 6);
    _angular_core__WEBPACK_IMPORTED_MODULE_18__["ɵɵpipe"](9, "async");
    _angular_core__WEBPACK_IMPORTED_MODULE_18__["ɵɵelementEnd"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_18__["ɵɵelementStart"](10, "ion-row")(11, "ion-col")(12, "ion-item", 7)(13, "ion-select", 8);
    _angular_core__WEBPACK_IMPORTED_MODULE_18__["ɵɵlistener"]("ionChange", function SchoolLeaderboardPage_ng_container_2_Template_ion_select_ionChange_13_listener($event) {
      _angular_core__WEBPACK_IMPORTED_MODULE_18__["ɵɵrestoreView"](_r14);
      var ctx_r13 = _angular_core__WEBPACK_IMPORTED_MODULE_18__["ɵɵnextContext"]();
      return ctx_r13.periodChangedSubject.next($event);
    });
    _angular_core__WEBPACK_IMPORTED_MODULE_18__["ɵɵpipe"](14, "async");
    _angular_core__WEBPACK_IMPORTED_MODULE_18__["ɵɵtemplate"](15, SchoolLeaderboardPage_ng_container_2_ion_select_option_15_Template, 3, 4, "ion-select-option", 9);
    _angular_core__WEBPACK_IMPORTED_MODULE_18__["ɵɵelementEnd"]()()()();
    _angular_core__WEBPACK_IMPORTED_MODULE_18__["ɵɵtemplate"](16, SchoolLeaderboardPage_ng_container_2_app_school_placing_detail_16_Template, 3, 9, "app-school-placing-detail", 10);
    _angular_core__WEBPACK_IMPORTED_MODULE_18__["ɵɵpipe"](17, "async");
    _angular_core__WEBPACK_IMPORTED_MODULE_18__["ɵɵelementEnd"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_18__["ɵɵtemplate"](18, SchoolLeaderboardPage_ng_container_2_ng_container_18_Template, 5, 6, "ng-container", 11);
    _angular_core__WEBPACK_IMPORTED_MODULE_18__["ɵɵpipe"](19, "async");
    _angular_core__WEBPACK_IMPORTED_MODULE_18__["ɵɵpipe"](20, "async");
    _angular_core__WEBPACK_IMPORTED_MODULE_18__["ɵɵtemplate"](21, SchoolLeaderboardPage_ng_container_2_ng_template_21_Template, 4, 3, "ng-template", null, 12, _angular_core__WEBPACK_IMPORTED_MODULE_18__["ɵɵtemplateRefExtractor"]);
    _angular_core__WEBPACK_IMPORTED_MODULE_18__["ɵɵelementEnd"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_18__["ɵɵelementContainerEnd"]();
  }

  if (rf & 2) {
    var _r5 = _angular_core__WEBPACK_IMPORTED_MODULE_18__["ɵɵreference"](22);

    var ctx_r0 = _angular_core__WEBPACK_IMPORTED_MODULE_18__["ɵɵnextContext"]();
    var tmp_9_0;
    var tmp_10_0;
    _angular_core__WEBPACK_IMPORTED_MODULE_18__["ɵɵadvance"](2);
    _angular_core__WEBPACK_IMPORTED_MODULE_18__["ɵɵstyleProp"]("color", "var(--ion-color-" + ctx_r0.campaignContainer.campaign.type + "-stat-contrast)")("background-color", "var(--ion-color-" + ctx_r0.campaignContainer.campaign.type + ")");
    _angular_core__WEBPACK_IMPORTED_MODULE_18__["ɵɵadvance"](3);
    _angular_core__WEBPACK_IMPORTED_MODULE_18__["ɵɵproperty"]("color", ctx_r0.campaignContainer == null ? null : ctx_r0.campaignContainer.campaign == null ? null : ctx_r0.campaignContainer.campaign.type);
    _angular_core__WEBPACK_IMPORTED_MODULE_18__["ɵɵadvance"](1);
    _angular_core__WEBPACK_IMPORTED_MODULE_18__["ɵɵtextInterpolate1"](" ", _angular_core__WEBPACK_IMPORTED_MODULE_18__["ɵɵpipeBind1"](7, 14, "campaigns.leaderboard.all_means"), " ");
    _angular_core__WEBPACK_IMPORTED_MODULE_18__["ɵɵadvance"](2);
    _angular_core__WEBPACK_IMPORTED_MODULE_18__["ɵɵproperty"]("ngIf", _angular_core__WEBPACK_IMPORTED_MODULE_18__["ɵɵpipeBind1"](9, 16, ctx_r0.useMeanAndMetric$) === false);
    _angular_core__WEBPACK_IMPORTED_MODULE_18__["ɵɵadvance"](4);
    _angular_core__WEBPACK_IMPORTED_MODULE_18__["ɵɵproperty"]("color", ctx_r0.campaignContainer == null ? null : ctx_r0.campaignContainer.campaign == null ? null : ctx_r0.campaignContainer.campaign.type);
    _angular_core__WEBPACK_IMPORTED_MODULE_18__["ɵɵadvance"](1);
    _angular_core__WEBPACK_IMPORTED_MODULE_18__["ɵɵproperty"]("interfaceOptions", _angular_core__WEBPACK_IMPORTED_MODULE_18__["ɵɵpureFunction0"](26, _c0))("value", _angular_core__WEBPACK_IMPORTED_MODULE_18__["ɵɵpipeBind1"](14, 18, ctx_r0.selectedPeriod$));
    _angular_core__WEBPACK_IMPORTED_MODULE_18__["ɵɵadvance"](2);
    _angular_core__WEBPACK_IMPORTED_MODULE_18__["ɵɵproperty"]("ngForOf", ctx_r0.periods);
    _angular_core__WEBPACK_IMPORTED_MODULE_18__["ɵɵadvance"](1);
    _angular_core__WEBPACK_IMPORTED_MODULE_18__["ɵɵproperty"]("ngIf", ((tmp_9_0 = _angular_core__WEBPACK_IMPORTED_MODULE_18__["ɵɵpipeBind1"](17, 20, ctx_r0.leaderboardScrollResponse$)) == null ? null : tmp_9_0.totalElements) > 0);
    _angular_core__WEBPACK_IMPORTED_MODULE_18__["ɵɵadvance"](2);
    _angular_core__WEBPACK_IMPORTED_MODULE_18__["ɵɵproperty"]("ngIf", ((tmp_10_0 = _angular_core__WEBPACK_IMPORTED_MODULE_18__["ɵɵpipeBind1"](19, 22, ctx_r0.leaderboardScrollResponse$)) == null ? null : tmp_10_0.totalElements) > 0 && _angular_core__WEBPACK_IMPORTED_MODULE_18__["ɵɵpipeBind1"](20, 24, ctx_r0.filterOptions$))("ngIfElse", _r5);
  }
}

var SchoolLeaderboardPage = /*#__PURE__*/function () {
  function SchoolLeaderboardPage(route, teamService, teamStatsControllerService, campaignService, errorService, pageSettingsService) {
    var _this = this;

    (0,_Users_smartcommunitylab_Desktop_newWork_dslab_playgo_mobile_playgo_mobile_node_modules_babel_runtime_helpers_esm_classCallCheck_js__WEBPACK_IMPORTED_MODULE_3__["default"])(this, SchoolLeaderboardPage);

    this.route = route;
    this.teamService = teamService;
    this.teamStatsControllerService = teamStatsControllerService;
    this.campaignService = campaignService;
    this.errorService = errorService;
    this.pageSettingsService = pageSettingsService;
    this.referenceDate = luxon__WEBPACK_IMPORTED_MODULE_5__.DateTime.local();
    this.periods = this.getPeriods(this.referenceDate);
    this.metricToNumberWithUnitLabel = {
      co2: 'campaigns.leaderboard.leaderboard_type_unit.co2',
      km: 'campaigns.leaderboard.leaderboard_type_unit.km'
    };
    this.metricToUnitLabel = {
      co2: 'campaigns.leaderboard.unit.co2',
      km: 'campaigns.leaderboard.unit.km'
    };
    this.meanLabels = Object.assign(Object.assign({}, src_app_core_shared_tracking_trip_model__WEBPACK_IMPORTED_MODULE_8__.transportTypeLabels), (0,_Users_smartcommunitylab_Desktop_newWork_dslab_playgo_mobile_playgo_mobile_node_modules_babel_runtime_helpers_esm_defineProperty_js__WEBPACK_IMPORTED_MODULE_2__["default"])({}, ALL_MEANS, 'campaigns.leaderboard.all_means'));
    this.campaignId$ = this.route.params.pipe((0,rxjs_operators__WEBPACK_IMPORTED_MODULE_19__.map)(function (params) {
      return params.id;
    }), (0,rxjs_operators__WEBPACK_IMPORTED_MODULE_20__.distinctUntilChanged)(), (0,rxjs_operators__WEBPACK_IMPORTED_MODULE_21__.shareReplay)(1));
    this.campaign$ = this.campaignId$.pipe((0,rxjs_operators__WEBPACK_IMPORTED_MODULE_22__.switchMap)(function (campaignId) {
      return _this.campaignService.allCampaigns$.pipe((0,rxjs_operators__WEBPACK_IMPORTED_MODULE_19__.map)(function (campaigns) {
        return (0,lodash_es__WEBPACK_IMPORTED_MODULE_23__["default"])(campaigns, {
          campaignId: campaignId
        });
      }), (0,src_app_core_shared_rxjs_utils__WEBPACK_IMPORTED_MODULE_6__.throwIfNil)(function () {
        return new Error('Campaign not found');
      }), _this.errorService.getErrorHandler());
    }), (0,rxjs_operators__WEBPACK_IMPORTED_MODULE_21__.shareReplay)(1));
    this.playerCampaign$ = this.campaignId$.pipe((0,rxjs_operators__WEBPACK_IMPORTED_MODULE_22__.switchMap)(function (campaignId) {
      return _this.campaignService.myCampaigns$.pipe((0,rxjs_operators__WEBPACK_IMPORTED_MODULE_19__.map)(function (campaigns) {
        return (0,lodash_es__WEBPACK_IMPORTED_MODULE_23__["default"])(campaigns, function (playercampaign) {
          return playercampaign.subscription.campaignId === campaignId;
        });
      }), (0,src_app_core_shared_rxjs_utils__WEBPACK_IMPORTED_MODULE_6__.throwIfNil)(function () {
        return new Error('Campaign not found');
      }), _this.errorService.getErrorHandler());
    }), (0,rxjs_operators__WEBPACK_IMPORTED_MODULE_24__.tap)(function (campaign) {
      return console.log('playercampaign' + campaign);
    }), (0,rxjs_operators__WEBPACK_IMPORTED_MODULE_21__.shareReplay)(1));
    this.useMeanAndMetric$ = this.campaign$.pipe((0,rxjs_operators__WEBPACK_IMPORTED_MODULE_19__.map)(function (campaign) {
      return campaign.type === 'personal';
    }));
    this.means$ = this.campaignService.availableMeans$.pipe((0,rxjs_operators__WEBPACK_IMPORTED_MODULE_19__.map)(function (availableMeans) {
      return [ALL_MEANS].concat((0,_Users_smartcommunitylab_Desktop_newWork_dslab_playgo_mobile_playgo_mobile_node_modules_babel_runtime_helpers_esm_toConsumableArray_js__WEBPACK_IMPORTED_MODULE_1__["default"])(availableMeans));
    }));
    this.selectedMeanChangedSubject = new rxjs__WEBPACK_IMPORTED_MODULE_25__.Subject();
    this.selectedMean$ = this.selectedMeanChangedSubject.pipe((0,rxjs_operators__WEBPACK_IMPORTED_MODULE_19__.map)(function (event) {
      return event.detail.value;
    }), (0,rxjs_operators__WEBPACK_IMPORTED_MODULE_26__.startWith)(ALL_MEANS), (0,rxjs_operators__WEBPACK_IMPORTED_MODULE_21__.shareReplay)(1));
    this.metrics = ['co2', 'km'];
    this.selectedMetricChangedSubject = new rxjs__WEBPACK_IMPORTED_MODULE_25__.Subject();
    this.selectedMetric$ = this.selectedMetricChangedSubject.pipe((0,rxjs_operators__WEBPACK_IMPORTED_MODULE_19__.map)(function (event) {
      return event.detail.value;
    }), (0,rxjs_operators__WEBPACK_IMPORTED_MODULE_26__.startWith)( // initial select value
    'co2'), (0,rxjs_operators__WEBPACK_IMPORTED_MODULE_21__.shareReplay)(1));
    this.periodChangedSubject = new rxjs__WEBPACK_IMPORTED_MODULE_25__.Subject();
    this.selectedPeriod$ = this.periodChangedSubject.pipe((0,rxjs_operators__WEBPACK_IMPORTED_MODULE_19__.map)(function (event) {
      return event.detail.value;
    }), (0,rxjs_operators__WEBPACK_IMPORTED_MODULE_26__.startWith)((0,lodash_es__WEBPACK_IMPORTED_MODULE_23__["default"])(this.periods, {
      default: true
    })), // initial select value
    (0,rxjs_operators__WEBPACK_IMPORTED_MODULE_21__.shareReplay)(1));
    this.teamId$ = this.playerCampaign$.pipe((0,rxjs_operators__WEBPACK_IMPORTED_MODULE_19__.map)(function (campaign) {
      var _a, _b;

      console.log(campaign);
      return (_b = (_a = campaign === null || campaign === void 0 ? void 0 : campaign.subscription) === null || _a === void 0 ? void 0 : _a.campaignData) === null || _b === void 0 ? void 0 : _b.teamId;
    }), (0,rxjs_operators__WEBPACK_IMPORTED_MODULE_24__.tap)(function (team) {
      return console.log(team);
    }), (0,rxjs_operators__WEBPACK_IMPORTED_MODULE_21__.shareReplay)(1)); // this.userService.userProfile$.pipe(
    //   map((userProfile) => userProfile.playerId),
    //   distinctUntilChanged()
    // );
    // this.route.params.pipe(
    //   map((params) => params.id),

    this.filterOptions$ = (0,rxjs__WEBPACK_IMPORTED_MODULE_27__.combineLatest)({
      mean: this.selectedMean$,
      metric: this.selectedMetric$,
      period: this.selectedPeriod$,
      campaignId: this.campaignId$,
      useMeanAndMetric: this.useMeanAndMetric$,
      teamId: this.teamId$
    });
    this.numberWithUnitKey$ = this.filterOptions$.pipe((0,rxjs_operators__WEBPACK_IMPORTED_MODULE_19__.map)(function (_ref) {
      var useMeanAndMetric = _ref.useMeanAndMetric,
          metric = _ref.metric;
      return useMeanAndMetric ? _this.metricToNumberWithUnitLabel[metric] : 'campaigns.leaderboard.leaderboard_type_unit.GL';
    }), (0,rxjs_operators__WEBPACK_IMPORTED_MODULE_21__.shareReplay)(1));
    this.teamPosition$ = this.filterOptions$.pipe((0,rxjs_operators__WEBPACK_IMPORTED_MODULE_22__.switchMap)(function (_ref2) {
      var useMeanAndMetric = _ref2.useMeanAndMetric,
          metric = _ref2.metric,
          mean = _ref2.mean,
          period = _ref2.period,
          campaignId = _ref2.campaignId,
          teamId = _ref2.teamId;

      if (useMeanAndMetric) {
        return _this.teamStatsControllerService.geGroupCampaingPlacingByTransportModeUsingGET({
          campaignId: campaignId,
          groupId: teamId,
          metric: metric,
          mean: mean === ALL_MEANS ? null : mean,
          dateFrom: period.from,
          dateTo: period.to
        }).pipe((0,rxjs_operators__WEBPACK_IMPORTED_MODULE_19__.map)(function (place) {
          place.groupId = teamId;
          return place;
        }), _this.errorService.getErrorHandler());
      } else {
        return _this.teamStatsControllerService.getGroupCampaingPlacingByGameUsingGET({
          campaignId: campaignId,
          groupId: teamId,
          dateFrom: period.from,
          dateTo: period.to
        }).pipe((0,rxjs_operators__WEBPACK_IMPORTED_MODULE_19__.map)(function (place) {
          place.groupId = teamId;
          return place;
        }), _this.errorService.getErrorHandler());
      }
    }), (0,rxjs_operators__WEBPACK_IMPORTED_MODULE_21__.shareReplay)(1));
    this.scrollRequestSubject = new rxjs__WEBPACK_IMPORTED_MODULE_25__.Subject();
    this.leaderboardScrollResponse$ = this.filterOptions$.pipe((0,rxjs_operators__WEBPACK_IMPORTED_MODULE_22__.switchMap)(function (_ref3) {
      var useMeanAndMetric = _ref3.useMeanAndMetric,
          metric = _ref3.metric,
          mean = _ref3.mean,
          period = _ref3.period,
          campaignId = _ref3.campaignId;
      return _this.scrollRequestSubject.pipe((0,rxjs_operators__WEBPACK_IMPORTED_MODULE_26__.startWith)({
        page: 0,
        size: 10
      }), (0,rxjs_operators__WEBPACK_IMPORTED_MODULE_22__.switchMap)(function (_ref4) {
        var page = _ref4.page,
            size = _ref4.size;

        if (useMeanAndMetric) {
          return _this.teamStatsControllerService.getCampaingPlacingByTransportStatsUsingGET({
            page: page,
            size: size,
            campaignId: campaignId,
            metric: metric,
            mean: mean === ALL_MEANS ? null : mean,
            dateFrom: period.from,
            dateTo: period.to
          }).pipe(_this.errorService.getErrorHandler());
        } else {
          return _this.teamStatsControllerService.getCampaingPlacingByGameUsingGET({
            page: page,
            size: size,
            campaignId: campaignId,
            dateFrom: period.from,
            dateTo: period.to
          }).pipe(_this.errorService.getErrorHandler());
        }
      }));
    }));
    this.resetItems$ = this.filterOptions$.pipe((0,rxjs_operators__WEBPACK_IMPORTED_MODULE_19__.map)(function () {
      return Symbol();
    }));
    this.subId = this.route.params.subscribe(function (params) {
      _this.id = params.id;
      _this.subCampaign = _this.campaignService.myCampaigns$.subscribe(function (campaigns) {
        _this.campaignContainer = campaigns.find(function (campaignContainer) {
          return campaignContainer.campaign.campaignId === _this.id;
        });
      });
    });
  }

  (0,_Users_smartcommunitylab_Desktop_newWork_dslab_playgo_mobile_playgo_mobile_node_modules_babel_runtime_helpers_esm_createClass_js__WEBPACK_IMPORTED_MODULE_4__["default"])(SchoolLeaderboardPage, [{
    key: "ngOnDestroy",
    value: function ngOnDestroy() {
      this.subCampaign.unsubscribe();
      this.subId.unsubscribe();
      this.myTeamSub.unsubscribe();
    }
  }, {
    key: "ionViewWillEnter",
    value: function ionViewWillEnter() {
      this.changePageSettings();
    }
  }, {
    key: "changePageSettings",
    value: function changePageSettings() {
      var _a, _b;

      this.pageSettingsService.set({
        color: (_b = (_a = this.campaignContainer) === null || _a === void 0 ? void 0 : _a.campaign) === null || _b === void 0 ? void 0 : _b.type
      });
    }
  }, {
    key: "getPeriods",
    value: function getPeriods(referenceDate) {
      return [{
        labelKey: 'campaigns.leaderboard.period.today',
        from: this.toServerDate(referenceDate.startOf('day')),
        to: this.toServerDate(referenceDate),
        default: false
      }, {
        labelKey: 'campaigns.leaderboard.period.this_week',
        from: this.toServerDate(referenceDate.startOf('week')),
        to: this.toServerDate(referenceDate),
        default: true
      }, {
        labelKey: 'campaigns.leaderboard.period.last_week',
        from: this.toServerDate(referenceDate.startOf('week').minus({
          weeks: 1
        })),
        to: this.toServerDate(referenceDate.startOf('week').minus({
          weeks: 1
        }).endOf('week')),
        default: false
      }, {
        labelKey: 'campaigns.leaderboard.period.this_month',
        from: this.toServerDate(referenceDate.startOf('month')),
        to: this.toServerDate(referenceDate),
        default: false
      }, {
        labelKey: 'campaigns.leaderboard.period.all_time',
        // not specifying dates, will improve the server performance because of special handling
        // but we will lose the confidence that player position and leaderboard are in sync.
        // maybe it is not such deal, "All Time" leaderboard will not change so rapidly.
        from: null,
        to: null,
        default: false
      }];
    }
  }, {
    key: "toServerDate",
    value: function toServerDate(dateTime) {
      // TODO: This is actually quite tricky bug.
      // When we round reference date to the start of the day, than we get this period
      // from beginning of the day to now, where events affecting this period will
      // cause inconsistent data between the loaded pages of pagination.
      return (0,src_app_core_shared_time_utils__WEBPACK_IMPORTED_MODULE_7__.toServerDateOnly)(dateTime);
    }
  }, {
    key: "ngOnInit",
    value: function ngOnInit() {
      var _this2 = this;

      this.myTeamSub = (0,rxjs__WEBPACK_IMPORTED_MODULE_27__.combineLatest)([this.campaignId$, this.teamId$]).pipe((0,rxjs_operators__WEBPACK_IMPORTED_MODULE_22__.switchMap)(function (_ref5) {
        var _ref6 = (0,_Users_smartcommunitylab_Desktop_newWork_dslab_playgo_mobile_playgo_mobile_node_modules_babel_runtime_helpers_esm_slicedToArray_js__WEBPACK_IMPORTED_MODULE_0__["default"])(_ref5, 2),
            campaignId = _ref6[0],
            teamId = _ref6[1];

        return _this2.teamService.getMyTeam(campaignId, teamId);
      })).subscribe(function (team) {
        return _this2.myTeam = team;
      });
    }
  }]);

  return SchoolLeaderboardPage;
}();

SchoolLeaderboardPage.ɵfac = function SchoolLeaderboardPage_Factory(t) {
  return new (t || SchoolLeaderboardPage)(_angular_core__WEBPACK_IMPORTED_MODULE_18__["ɵɵdirectiveInject"](_angular_router__WEBPACK_IMPORTED_MODULE_28__.ActivatedRoute), _angular_core__WEBPACK_IMPORTED_MODULE_18__["ɵɵdirectiveInject"](src_app_core_shared_services_team_service__WEBPACK_IMPORTED_MODULE_9__.TeamService), _angular_core__WEBPACK_IMPORTED_MODULE_18__["ɵɵdirectiveInject"](src_app_core_api_generated_hsc_controllers_teamStatsController_service__WEBPACK_IMPORTED_MODULE_10__.TeamStatsControllerService), _angular_core__WEBPACK_IMPORTED_MODULE_18__["ɵɵdirectiveInject"](src_app_core_shared_services_campaign_service__WEBPACK_IMPORTED_MODULE_11__.CampaignService), _angular_core__WEBPACK_IMPORTED_MODULE_18__["ɵɵdirectiveInject"](src_app_core_shared_services_error_service__WEBPACK_IMPORTED_MODULE_12__.ErrorService), _angular_core__WEBPACK_IMPORTED_MODULE_18__["ɵɵdirectiveInject"](src_app_core_shared_services_page_settings_service__WEBPACK_IMPORTED_MODULE_13__.PageSettingsService));
};

SchoolLeaderboardPage.ɵcmp = /*@__PURE__*/_angular_core__WEBPACK_IMPORTED_MODULE_18__["ɵɵdefineComponent"]({
  type: SchoolLeaderboardPage,
  selectors: [["app-school-leaderboard"]],
  decls: 4,
  vars: 3,
  consts: [["appHeader", ""], ["appContent", ""], [4, "ngIf"], [1, "header-margin"], [1, "header-sticky"], ["lines", "full", 3, "color"], ["class", "flex-end", 4, "ngIf"], [1, "", 3, "color"], ["interface", "popover", 3, "interfaceOptions", "value", "ionChange"], [3, "value", 4, "ngFor", "ngForOf"], [3, "myTeam", "placing", "unitLabelKey", "mine", "campaign", 4, "ngIf"], [4, "ngIf", "ngIfElse"], ["emptyLead", ""], [1, "flex-end"], ["lines", "full", 1, "ion-text-end", 3, "color"], [3, "value"], [3, "myTeam", "placing", "unitLabelKey", "mine", "campaign"], [3, "resetItems", "response", "request"], ["appInfiniteScrollContent", ""], [3, "placing", "unitLabelKey", "mine", "campaign", "myTeam"], [1, "empty-lead"]],
  template: function SchoolLeaderboardPage_Template(rf, ctx) {
    if (rf & 1) {
      _angular_core__WEBPACK_IMPORTED_MODULE_18__["ɵɵelement"](0, "ion-header", 0);
      _angular_core__WEBPACK_IMPORTED_MODULE_18__["ɵɵelementStart"](1, "ion-content", 1);
      _angular_core__WEBPACK_IMPORTED_MODULE_18__["ɵɵtemplate"](2, SchoolLeaderboardPage_ng_container_2_Template, 23, 27, "ng-container", 2);
      _angular_core__WEBPACK_IMPORTED_MODULE_18__["ɵɵpipe"](3, "async");
      _angular_core__WEBPACK_IMPORTED_MODULE_18__["ɵɵelementEnd"]();
    }

    if (rf & 2) {
      _angular_core__WEBPACK_IMPORTED_MODULE_18__["ɵɵadvance"](2);
      _angular_core__WEBPACK_IMPORTED_MODULE_18__["ɵɵproperty"]("ngIf", _angular_core__WEBPACK_IMPORTED_MODULE_18__["ɵɵpipeBind1"](3, 1, ctx.campaign$) !== null && ctx.myTeam !== null);
    }
  },
  directives: [_ionic_angular__WEBPACK_IMPORTED_MODULE_29__.IonHeader, _core_shared_layout_header_header_directive__WEBPACK_IMPORTED_MODULE_14__.HeaderDirective, _ionic_angular__WEBPACK_IMPORTED_MODULE_29__.IonContent, _core_shared_layout_content_content_directive__WEBPACK_IMPORTED_MODULE_15__.ContentDirective, _angular_common__WEBPACK_IMPORTED_MODULE_30__.NgIf, _ionic_angular__WEBPACK_IMPORTED_MODULE_29__.IonRow, _ionic_angular__WEBPACK_IMPORTED_MODULE_29__.IonCol, _ionic_angular__WEBPACK_IMPORTED_MODULE_29__.IonItem, _ionic_angular__WEBPACK_IMPORTED_MODULE_29__.IonSelect, _ionic_angular__WEBPACK_IMPORTED_MODULE_29__.SelectValueAccessor, _angular_common__WEBPACK_IMPORTED_MODULE_30__.NgForOf, _ionic_angular__WEBPACK_IMPORTED_MODULE_29__.IonSelectOption, _school_placing_detail_school_placing_detail_component__WEBPACK_IMPORTED_MODULE_16__.SchoolPlacingDetailComponent, _core_shared_infinite_scroll_infinite_scroll_component__WEBPACK_IMPORTED_MODULE_17__.InfiniteScrollComponent, _core_shared_infinite_scroll_infinite_scroll_component__WEBPACK_IMPORTED_MODULE_17__.InfiniteScrollContentDirective],
  pipes: [_angular_common__WEBPACK_IMPORTED_MODULE_30__.AsyncPipe, _ngx_translate_core__WEBPACK_IMPORTED_MODULE_31__.TranslatePipe],
  styles: ["ion-item[_ngcontent-%COMP%] {\n  width: 100%;\n}\nion-item[_ngcontent-%COMP%]   span[_ngcontent-%COMP%] {\n  width: 100%;\n}\n.empty-lead[_ngcontent-%COMP%] {\n  margin: auto;\n  padding: 8px;\n  font-size: 20px;\n  text-align: center;\n}\n/*# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbInNjaG9vbC1sZWFkZXJib2FyZC5wYWdlLnNjc3MiXSwibmFtZXMiOltdLCJtYXBwaW5ncyI6IkFBQUE7RUFDRSxXQUFBO0FBQ0Y7QUFBRTtFQUNFLFdBQUE7QUFFSjtBQUNBO0VBQ0UsWUFBQTtFQUNBLFlBQUE7RUFDQSxlQUFBO0VBQ0Esa0JBQUE7QUFFRiIsImZpbGUiOiJzY2hvb2wtbGVhZGVyYm9hcmQucGFnZS5zY3NzIiwic291cmNlc0NvbnRlbnQiOlsiaW9uLWl0ZW0ge1xuICB3aWR0aDogMTAwJTtcbiAgc3BhbiB7XG4gICAgd2lkdGg6IDEwMCU7XG4gIH1cbn1cbi5lbXB0eS1sZWFkIHtcbiAgbWFyZ2luOiBhdXRvO1xuICBwYWRkaW5nOiA4cHg7XG4gIGZvbnQtc2l6ZTogMjBweDtcbiAgdGV4dC1hbGlnbjogY2VudGVyO1xufVxuIl19 */"]
});
var ALL_MEANS = 'ALL_MEANS';

/***/ }),

/***/ 73106:
/*!*************************************************************************************************************************!*\
  !*** ./src/app/pages/home/campaign-details/school-leaderboard/school-placing-detail/school-placing-detail.component.ts ***!
  \*************************************************************************************************************************/
/***/ (function(__unused_webpack_module, __webpack_exports__, __webpack_require__) {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "SchoolPlacingDetailComponent": function() { return /* binding */ SchoolPlacingDetailComponent; }
/* harmony export */ });
/* harmony import */ var _Users_smartcommunitylab_Desktop_newWork_dslab_playgo_mobile_playgo_mobile_node_modules_babel_runtime_helpers_esm_classCallCheck_js__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./node_modules/@babel/runtime/helpers/esm/classCallCheck.js */ 78069);
/* harmony import */ var _Users_smartcommunitylab_Desktop_newWork_dslab_playgo_mobile_playgo_mobile_node_modules_babel_runtime_helpers_esm_createClass_js__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ./node_modules/@babel/runtime/helpers/esm/createClass.js */ 48047);
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(/*! @angular/core */ 3184);
/* harmony import */ var src_app_core_shared_services_user_service__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! src/app/core/shared/services/user.service */ 50749);
/* harmony import */ var src_app_core_shared_services_team_service__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! src/app/core/shared/services/team.service */ 86612);
/* harmony import */ var _angular_common__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(/*! @angular/common */ 36362);
/* harmony import */ var _ionic_angular__WEBPACK_IMPORTED_MODULE_9__ = __webpack_require__(/*! @ionic/angular */ 93819);
/* harmony import */ var _angular_router__WEBPACK_IMPORTED_MODULE_10__ = __webpack_require__(/*! @angular/router */ 52816);
/* harmony import */ var _core_shared_globalization_ordinal_number_ordinal_number_component__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! ../../../../../core/shared/globalization/ordinal-number/ordinal-number.component */ 56032);
/* harmony import */ var _core_shared_ui_icon_icon_component__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! ../../../../../core/shared/ui/icon/icon.component */ 71888);
/* harmony import */ var _core_shared_pipes_localNumber_pipe__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! ../../../../../core/shared/pipes/localNumber.pipe */ 89713);












function SchoolPlacingDetailComponent_ion_item_0_ng_container_5_ion_avatar_2_Template(rf, ctx) {
  if (rf & 1) {
    _angular_core__WEBPACK_IMPORTED_MODULE_7__["ɵɵelementStart"](0, "ion-avatar");
    _angular_core__WEBPACK_IMPORTED_MODULE_7__["ɵɵelement"](1, "img", 12);
    _angular_core__WEBPACK_IMPORTED_MODULE_7__["ɵɵelementEnd"]();
  }

  if (rf & 2) {
    var ctx_r3 = _angular_core__WEBPACK_IMPORTED_MODULE_7__["ɵɵnextContext"](3);
    _angular_core__WEBPACK_IMPORTED_MODULE_7__["ɵɵadvance"](1);
    _angular_core__WEBPACK_IMPORTED_MODULE_7__["ɵɵproperty"]("src", ctx_r3.myTeam == null ? null : ctx_r3.myTeam.avatar == null ? null : ctx_r3.myTeam.avatar.url, _angular_core__WEBPACK_IMPORTED_MODULE_7__["ɵɵsanitizeUrl"]);
  }
}

function SchoolPlacingDetailComponent_ion_item_0_ng_container_5_ng_template_3_Template(rf, ctx) {
  if (rf & 1) {
    _angular_core__WEBPACK_IMPORTED_MODULE_7__["ɵɵelementStart"](0, "ion-avatar");
    _angular_core__WEBPACK_IMPORTED_MODULE_7__["ɵɵelement"](1, "ion-icon", 13);
    _angular_core__WEBPACK_IMPORTED_MODULE_7__["ɵɵelementEnd"]();
  }
}

function SchoolPlacingDetailComponent_ion_item_0_ng_container_5_Template(rf, ctx) {
  if (rf & 1) {
    _angular_core__WEBPACK_IMPORTED_MODULE_7__["ɵɵelementContainerStart"](0);
    _angular_core__WEBPACK_IMPORTED_MODULE_7__["ɵɵelementStart"](1, "ion-col", 2);
    _angular_core__WEBPACK_IMPORTED_MODULE_7__["ɵɵtemplate"](2, SchoolPlacingDetailComponent_ion_item_0_ng_container_5_ion_avatar_2_Template, 2, 1, "ion-avatar", 10);
    _angular_core__WEBPACK_IMPORTED_MODULE_7__["ɵɵtemplate"](3, SchoolPlacingDetailComponent_ion_item_0_ng_container_5_ng_template_3_Template, 2, 0, "ng-template", null, 11, _angular_core__WEBPACK_IMPORTED_MODULE_7__["ɵɵtemplateRefExtractor"]);
    _angular_core__WEBPACK_IMPORTED_MODULE_7__["ɵɵelementEnd"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_7__["ɵɵelementContainerEnd"]();
  }

  if (rf & 2) {
    var _r4 = _angular_core__WEBPACK_IMPORTED_MODULE_7__["ɵɵreference"](4);

    var ctx_r1 = _angular_core__WEBPACK_IMPORTED_MODULE_7__["ɵɵnextContext"](2);
    _angular_core__WEBPACK_IMPORTED_MODULE_7__["ɵɵadvance"](2);
    _angular_core__WEBPACK_IMPORTED_MODULE_7__["ɵɵproperty"]("ngIf", ctx_r1.myTeam == null ? null : ctx_r1.myTeam.avatar == null ? null : ctx_r1.myTeam.avatar.url)("ngIfElse", _r4);
  }
}

function SchoolPlacingDetailComponent_ion_item_0_ng_container_6_ion_avatar_2_Template(rf, ctx) {
  if (rf & 1) {
    _angular_core__WEBPACK_IMPORTED_MODULE_7__["ɵɵelementStart"](0, "ion-avatar");
    _angular_core__WEBPACK_IMPORTED_MODULE_7__["ɵɵelement"](1, "img", 12);
    _angular_core__WEBPACK_IMPORTED_MODULE_7__["ɵɵelementEnd"]();
  }

  if (rf & 2) {
    var ctx_r6 = _angular_core__WEBPACK_IMPORTED_MODULE_7__["ɵɵnextContext"](3);
    _angular_core__WEBPACK_IMPORTED_MODULE_7__["ɵɵadvance"](1);
    _angular_core__WEBPACK_IMPORTED_MODULE_7__["ɵɵproperty"]("src", ctx_r6.placing == null ? null : ctx_r6.placing.avatar == null ? null : ctx_r6.placing.avatar.url, _angular_core__WEBPACK_IMPORTED_MODULE_7__["ɵɵsanitizeUrl"]);
  }
}

function SchoolPlacingDetailComponent_ion_item_0_ng_container_6_ng_template_3_Template(rf, ctx) {
  if (rf & 1) {
    _angular_core__WEBPACK_IMPORTED_MODULE_7__["ɵɵelementStart"](0, "ion-avatar");
    _angular_core__WEBPACK_IMPORTED_MODULE_7__["ɵɵelement"](1, "ion-icon", 13);
    _angular_core__WEBPACK_IMPORTED_MODULE_7__["ɵɵelementEnd"]();
  }
}

function SchoolPlacingDetailComponent_ion_item_0_ng_container_6_Template(rf, ctx) {
  if (rf & 1) {
    _angular_core__WEBPACK_IMPORTED_MODULE_7__["ɵɵelementContainerStart"](0);
    _angular_core__WEBPACK_IMPORTED_MODULE_7__["ɵɵelementStart"](1, "ion-col", 2);
    _angular_core__WEBPACK_IMPORTED_MODULE_7__["ɵɵtemplate"](2, SchoolPlacingDetailComponent_ion_item_0_ng_container_6_ion_avatar_2_Template, 2, 1, "ion-avatar", 10);
    _angular_core__WEBPACK_IMPORTED_MODULE_7__["ɵɵtemplate"](3, SchoolPlacingDetailComponent_ion_item_0_ng_container_6_ng_template_3_Template, 2, 0, "ng-template", null, 11, _angular_core__WEBPACK_IMPORTED_MODULE_7__["ɵɵtemplateRefExtractor"]);
    _angular_core__WEBPACK_IMPORTED_MODULE_7__["ɵɵelementEnd"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_7__["ɵɵelementContainerEnd"]();
  }

  if (rf & 2) {
    var _r7 = _angular_core__WEBPACK_IMPORTED_MODULE_7__["ɵɵreference"](4);

    var ctx_r2 = _angular_core__WEBPACK_IMPORTED_MODULE_7__["ɵɵnextContext"](2);
    _angular_core__WEBPACK_IMPORTED_MODULE_7__["ɵɵadvance"](2);
    _angular_core__WEBPACK_IMPORTED_MODULE_7__["ɵɵproperty"]("ngIf", ctx_r2.placing == null ? null : ctx_r2.placing.avatar)("ngIfElse", _r7);
  }
}

var _c0 = function _c0(a0) {
  return {
    border: a0
  };
};

var _c1 = function _c1(a0) {
  return [a0];
};

function SchoolPlacingDetailComponent_ion_item_0_Template(rf, ctx) {
  if (rf & 1) {
    _angular_core__WEBPACK_IMPORTED_MODULE_7__["ɵɵelementStart"](0, "ion-item", 1)(1, "ion-grid")(2, "ion-row")(3, "ion-col", 2);
    _angular_core__WEBPACK_IMPORTED_MODULE_7__["ɵɵelement"](4, "app-ordinal-number", 3);
    _angular_core__WEBPACK_IMPORTED_MODULE_7__["ɵɵelementEnd"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_7__["ɵɵtemplate"](5, SchoolPlacingDetailComponent_ion_item_0_ng_container_5_Template, 5, 2, "ng-container", 4);
    _angular_core__WEBPACK_IMPORTED_MODULE_7__["ɵɵtemplate"](6, SchoolPlacingDetailComponent_ion_item_0_ng_container_6_Template, 5, 2, "ng-container", 4);
    _angular_core__WEBPACK_IMPORTED_MODULE_7__["ɵɵelementStart"](7, "ion-col", 5)(8, "p", 6);
    _angular_core__WEBPACK_IMPORTED_MODULE_7__["ɵɵtext"](9);
    _angular_core__WEBPACK_IMPORTED_MODULE_7__["ɵɵelementEnd"]()();
    _angular_core__WEBPACK_IMPORTED_MODULE_7__["ɵɵelementStart"](10, "ion-col", 7)(11, "div", 8);
    _angular_core__WEBPACK_IMPORTED_MODULE_7__["ɵɵtext"](12);
    _angular_core__WEBPACK_IMPORTED_MODULE_7__["ɵɵpipe"](13, "localNumber");
    _angular_core__WEBPACK_IMPORTED_MODULE_7__["ɵɵelement"](14, "app-icon", 9);
    _angular_core__WEBPACK_IMPORTED_MODULE_7__["ɵɵelementEnd"]()()()()();
  }

  if (rf & 2) {
    var ctx_r0 = _angular_core__WEBPACK_IMPORTED_MODULE_7__["ɵɵnextContext"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_7__["ɵɵclassProp"]("my-placing", (ctx_r0.myTeam == null ? null : ctx_r0.myTeam.id) === ctx_r0.placing.groupId);
    _angular_core__WEBPACK_IMPORTED_MODULE_7__["ɵɵproperty"]("ngStyle", _angular_core__WEBPACK_IMPORTED_MODULE_7__["ɵɵpureFunction1"](12, _c0, ctx_r0.mine ? "3px solid var(--ion-color-" + (ctx_r0.campaign == null ? null : ctx_r0.campaign.campaign == null ? null : ctx_r0.campaign.campaign.type) + ")" : ""))("routerLink", (ctx_r0.myTeam == null ? null : ctx_r0.myTeam.id) !== ctx_r0.placing.groupId ? _angular_core__WEBPACK_IMPORTED_MODULE_7__["ɵɵpureFunction1"](14, _c1, "/pages/team-profile/" + (ctx_r0.campaign == null ? null : ctx_r0.campaign.campaign == null ? null : ctx_r0.campaign.campaign.campaignId) + "/" + ctx_r0.placing.groupId + "/public") : _angular_core__WEBPACK_IMPORTED_MODULE_7__["ɵɵpureFunction1"](16, _c1, "/pages/team-profile/" + (ctx_r0.campaign == null ? null : ctx_r0.campaign.campaign == null ? null : ctx_r0.campaign.campaign.campaignId) + "/" + ctx_r0.placing.groupId + "/my"));
    _angular_core__WEBPACK_IMPORTED_MODULE_7__["ɵɵadvance"](4);
    _angular_core__WEBPACK_IMPORTED_MODULE_7__["ɵɵproperty"]("value", ctx_r0.placing.position);
    _angular_core__WEBPACK_IMPORTED_MODULE_7__["ɵɵadvance"](1);
    _angular_core__WEBPACK_IMPORTED_MODULE_7__["ɵɵproperty"]("ngIf", (ctx_r0.myTeam == null ? null : ctx_r0.myTeam.id) === ctx_r0.placing.groupId);
    _angular_core__WEBPACK_IMPORTED_MODULE_7__["ɵɵadvance"](1);
    _angular_core__WEBPACK_IMPORTED_MODULE_7__["ɵɵproperty"]("ngIf", (ctx_r0.myTeam == null ? null : ctx_r0.myTeam.id) !== ctx_r0.placing.groupId);
    _angular_core__WEBPACK_IMPORTED_MODULE_7__["ɵɵadvance"](3);
    _angular_core__WEBPACK_IMPORTED_MODULE_7__["ɵɵtextInterpolate"](ctx_r0.placing == null ? null : ctx_r0.placing.customData == null ? null : ctx_r0.placing.customData.name);
    _angular_core__WEBPACK_IMPORTED_MODULE_7__["ɵɵadvance"](3);
    _angular_core__WEBPACK_IMPORTED_MODULE_7__["ɵɵtextInterpolate1"]("", _angular_core__WEBPACK_IMPORTED_MODULE_7__["ɵɵpipeBind2"](13, 9, ctx_r0.getValue(ctx_r0.placing.value), "0.0-1"), " ");
  }
}

var SchoolPlacingDetailComponent = /*#__PURE__*/function () {
  // playerId$ = this.userService.userProfile$.pipe(
  //   map((userProfile) => userProfile.playerId)
  // );
  // playerAvatarUrl$ = this.userService.userProfile$.pipe(
  //   map((userProfile) => userProfile.avatar.avatarSmallUrl)
  // );
  function SchoolPlacingDetailComponent(userService, teamService) {
    (0,_Users_smartcommunitylab_Desktop_newWork_dslab_playgo_mobile_playgo_mobile_node_modules_babel_runtime_helpers_esm_classCallCheck_js__WEBPACK_IMPORTED_MODULE_0__["default"])(this, SchoolPlacingDetailComponent);

    this.userService = userService;
    this.teamService = teamService;
  }

  (0,_Users_smartcommunitylab_Desktop_newWork_dslab_playgo_mobile_playgo_mobile_node_modules_babel_runtime_helpers_esm_createClass_js__WEBPACK_IMPORTED_MODULE_1__["default"])(SchoolPlacingDetailComponent, [{
    key: "getValue",
    value: function getValue(value) {
      if (this.unitLabelKey === 'campaigns.leaderboard.leaderboard_type_unit.km') {
        return value / 1000;
      }

      return value;
    }
  }, {
    key: "ngOnInit",
    value: function ngOnInit() {
      console.log(this.placing); // this.myTeam$ = this.teamService.getMyTeam(
      //   this.campaign?.campaign?.campaignId,
      //   this.campaign?.subscription?.campaignData?.teamId
      // ).pipe(shareReplay(1));
    }
  }]);

  return SchoolPlacingDetailComponent;
}();

SchoolPlacingDetailComponent.ɵfac = function SchoolPlacingDetailComponent_Factory(t) {
  return new (t || SchoolPlacingDetailComponent)(_angular_core__WEBPACK_IMPORTED_MODULE_7__["ɵɵdirectiveInject"](src_app_core_shared_services_user_service__WEBPACK_IMPORTED_MODULE_2__.UserService), _angular_core__WEBPACK_IMPORTED_MODULE_7__["ɵɵdirectiveInject"](src_app_core_shared_services_team_service__WEBPACK_IMPORTED_MODULE_3__.TeamService));
};

SchoolPlacingDetailComponent.ɵcmp = /*@__PURE__*/_angular_core__WEBPACK_IMPORTED_MODULE_7__["ɵɵdefineComponent"]({
  type: SchoolPlacingDetailComponent,
  selectors: [["app-school-placing-detail"]],
  inputs: {
    placing: "placing",
    unitLabelKey: "unitLabelKey",
    mine: "mine",
    campaign: "campaign",
    myTeam: "myTeam",
    teamId: "teamId"
  },
  decls: 1,
  vars: 1,
  consts: [["detail", "false", 3, "my-placing", "ngStyle", "routerLink", 4, "ngIf"], ["detail", "false", 3, "ngStyle", "routerLink"], ["size", "2"], [3, "value"], [4, "ngIf"], ["size", "5", 1, "ion-text-start"], [1, "nickname"], ["size", "3", 1, "ion-text-end"], [1, "points"], ["name", "ecoLeavesHsc"], [4, "ngIf", "ngIfElse"], ["alternativeAvatar", ""], ["title", "avatar", 3, "src"], ["name", "people-circle-outline"]],
  template: function SchoolPlacingDetailComponent_Template(rf, ctx) {
    if (rf & 1) {
      _angular_core__WEBPACK_IMPORTED_MODULE_7__["ɵɵtemplate"](0, SchoolPlacingDetailComponent_ion_item_0_Template, 15, 18, "ion-item", 0);
    }

    if (rf & 2) {
      _angular_core__WEBPACK_IMPORTED_MODULE_7__["ɵɵproperty"]("ngIf", ctx.placing);
    }
  },
  directives: [_angular_common__WEBPACK_IMPORTED_MODULE_8__.NgIf, _ionic_angular__WEBPACK_IMPORTED_MODULE_9__.IonItem, _angular_common__WEBPACK_IMPORTED_MODULE_8__.NgStyle, _angular_router__WEBPACK_IMPORTED_MODULE_10__.RouterLink, _ionic_angular__WEBPACK_IMPORTED_MODULE_9__.RouterLinkDelegate, _ionic_angular__WEBPACK_IMPORTED_MODULE_9__.IonGrid, _ionic_angular__WEBPACK_IMPORTED_MODULE_9__.IonRow, _ionic_angular__WEBPACK_IMPORTED_MODULE_9__.IonCol, _core_shared_globalization_ordinal_number_ordinal_number_component__WEBPACK_IMPORTED_MODULE_4__.OrdinalNumberComponent, _ionic_angular__WEBPACK_IMPORTED_MODULE_9__.IonAvatar, _ionic_angular__WEBPACK_IMPORTED_MODULE_9__.IonIcon, _core_shared_ui_icon_icon_component__WEBPACK_IMPORTED_MODULE_5__.IconComponent],
  pipes: [_core_shared_pipes_localNumber_pipe__WEBPACK_IMPORTED_MODULE_6__.LocalNumberPipe],
  styles: [".my-placing[_ngcontent-%COMP%] {\n  font-weight: bold;\n}\n\n.nickname[_ngcontent-%COMP%] {\n  text-overflow: ellipsis;\n  white-space: nowrap;\n  overflow: hidden;\n}\n\nion-row[_ngcontent-%COMP%] {\n  align-items: center;\n}\n\nion-avatar[_ngcontent-%COMP%] {\n  width: 48px;\n  height: 48px;\n}\n\nion-avatar[_ngcontent-%COMP%]   img[_ngcontent-%COMP%] {\n  margin: 4px;\n}\n\nion-icon[_ngcontent-%COMP%] {\n  width: 59px;\n  height: 59px;\n}\n\n.points[_ngcontent-%COMP%] {\n  display: flex;\n  align-items: center;\n  justify-content: flex-end;\n}\n\n.points[_ngcontent-%COMP%]   app-icon[_ngcontent-%COMP%] {\n  margin: 0px 4px;\n}\n/*# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbInNjaG9vbC1wbGFjaW5nLWRldGFpbC5jb21wb25lbnQuc2NzcyJdLCJuYW1lcyI6W10sIm1hcHBpbmdzIjoiQUFBQTtFQUNFLGlCQUFBO0FBQ0Y7O0FBQ0E7RUFDRSx1QkFBQTtFQUNBLG1CQUFBO0VBQ0EsZ0JBQUE7QUFFRjs7QUFBQTtFQUNFLG1CQUFBO0FBR0Y7O0FBREE7RUFDRSxXQUFBO0VBQ0EsWUFBQTtBQUlGOztBQUhFO0VBQ0UsV0FBQTtBQUtKOztBQUZBO0VBQ0UsV0FBQTtFQUNBLFlBQUE7QUFLRjs7QUFIQTtFQUNFLGFBQUE7RUFDQSxtQkFBQTtFQUNBLHlCQUFBO0FBTUY7O0FBTEU7RUFDRSxlQUFBO0FBT0oiLCJmaWxlIjoic2Nob29sLXBsYWNpbmctZGV0YWlsLmNvbXBvbmVudC5zY3NzIiwic291cmNlc0NvbnRlbnQiOlsiLm15LXBsYWNpbmcge1xuICBmb250LXdlaWdodDogYm9sZDtcbn1cbi5uaWNrbmFtZSB7XG4gIHRleHQtb3ZlcmZsb3c6IGVsbGlwc2lzO1xuICB3aGl0ZS1zcGFjZTogbm93cmFwO1xuICBvdmVyZmxvdzogaGlkZGVuO1xufVxuaW9uLXJvdyB7XG4gIGFsaWduLWl0ZW1zOiBjZW50ZXI7XG59XG5pb24tYXZhdGFyIHtcbiAgd2lkdGg6IDQ4cHg7XG4gIGhlaWdodDogNDhweDtcbiAgaW1nIHtcbiAgICBtYXJnaW46IDRweDtcbiAgfVxufVxuaW9uLWljb24ge1xuICB3aWR0aDogNTlweDtcbiAgaGVpZ2h0OiA1OXB4O1xufVxuLnBvaW50cyB7XG4gIGRpc3BsYXk6IGZsZXg7XG4gIGFsaWduLWl0ZW1zOiBjZW50ZXI7XG4gIGp1c3RpZnktY29udGVudDogZmxleC1lbmQ7XG4gIGFwcC1pY29uIHtcbiAgICBtYXJnaW46IDBweCA0cHg7XG4gIH1cbn1cbiJdfQ== */"]
});

/***/ })

}]);
//# sourceMappingURL=src_app_pages_home_campaign-details_school-leaderboard_school-leaderboard_module_ts.js.map