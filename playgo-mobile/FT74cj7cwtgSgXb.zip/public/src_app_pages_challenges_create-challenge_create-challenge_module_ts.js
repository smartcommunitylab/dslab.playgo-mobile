"use strict";
(self["webpackChunkapp"] = self["webpackChunkapp"] || []).push([["src_app_pages_challenges_create-challenge_create-challenge_module_ts"],{

/***/ 38399:
/*!****************************************************************************************************!*\
  !*** ./src/app/pages/challenges/create-challenge/challenge-preview/challenge-preview.component.ts ***!
  \****************************************************************************************************/
/***/ (function(__unused_webpack_module, __webpack_exports__, __webpack_require__) {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "ChallengePreviewComponent": function() { return /* binding */ ChallengePreviewComponent; }
/* harmony export */ });
/* harmony import */ var _Users_smartcommunitylab_Desktop_newWork_dslab_playgo_mobile_playgo_mobile_node_modules_babel_runtime_helpers_esm_classCallCheck_js__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./node_modules/@babel/runtime/helpers/esm/classCallCheck.js */ 78069);
/* harmony import */ var _Users_smartcommunitylab_Desktop_newWork_dslab_playgo_mobile_playgo_mobile_node_modules_babel_runtime_helpers_esm_createClass_js__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ./node_modules/@babel/runtime/helpers/esm/createClass.js */ 48047);
/* harmony import */ var rxjs__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! rxjs */ 50635);
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! @angular/core */ 3184);
/* harmony import */ var src_app_core_shared_services_user_service__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! src/app/core/shared/services/user.service */ 50749);
/* harmony import */ var _angular_common__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! @angular/common */ 36362);
/* harmony import */ var _ionic_angular__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(/*! @ionic/angular */ 93819);
/* harmony import */ var _core_shared_pipes_languageMap_pipe__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! ../../../../core/shared/pipes/languageMap.pipe */ 73088);
/* harmony import */ var _ngx_translate_core__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(/*! @ngx-translate/core */ 87514);










function ChallengePreviewComponent_ng_container_0_Template(rf, ctx) {
  if (rf & 1) {
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵelementContainerStart"](0);
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵelementStart"](1, "ion-grid")(2, "ion-row", 1)(3, "ion-col", 2);
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵtext"](4);
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵpipe"](5, "languageMap");
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵelementEnd"]()();
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵelementStart"](6, "ion-row", 3)(7, "ion-col", 4)(8, "ion-avatar");
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵelement"](9, "img", 5);
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵpipe"](10, "async");
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵelementEnd"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵtext"](11);
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵpipe"](12, "translate");
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵelementEnd"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵelementStart"](13, "ion-col", 4)(14, "ion-avatar");
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵelement"](15, "img", 5);
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵelementEnd"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵtext"](16);
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵelementEnd"]()();
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵelementStart"](17, "ion-row", 1)(18, "ion-col", 6);
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵtext"](19);
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵpipe"](20, "translate");
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵelementEnd"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵelementStart"](21, "ion-col", 7);
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵtext"](22);
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵpipe"](23, "translate");
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵelementEnd"]()();
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵelementStart"](24, "ion-row")(25, "ion-col", 6);
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵtext"](26);
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵpipe"](27, "translate");
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵelementEnd"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵelementStart"](28, "ion-col", 7);
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵtext"](29);
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵpipe"](30, "translate");
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵelementEnd"]()();
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵelementStart"](31, "ion-row")(32, "ion-col", 6);
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵtext"](33);
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵpipe"](34, "translate");
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵelementEnd"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵelementStart"](35, "ion-col", 7);
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵtext"](36);
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵelementEnd"]()();
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵelementStart"](37, "ion-row", 1)(38, "ion-col", 8);
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵtext"](39);
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵpipe"](40, "languageMap");
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵelementEnd"]()()();
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵelementContainerEnd"]();
  }

  if (rf & 2) {
    var ctx_r0 = _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵnextContext"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵadvance"](4);
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵtextInterpolate"](_angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵpipeBind1"](5, 12, ctx_r0.preview.description));
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵadvance"](5);
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵproperty"]("src", _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵpipeBind1"](10, 14, ctx_r0.avatarUrl$), _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵsanitizeUrl"]);
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵadvance"](2);
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵtextInterpolate1"](" ", _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵpipeBind1"](12, 16, "challenges.create.preview.you"), " ");
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵadvance"](4);
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵproperty"]("src", ctx_r0.challengeable.avatarUrl, _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵsanitizeUrl"]);
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵadvance"](1);
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵtextInterpolate1"](" ", ctx_r0.challengeable.nickname, " ");
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵadvance"](3);
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵtextInterpolate"](_angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵpipeBind1"](20, 18, "challenges.create.preview.model"));
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵadvance"](3);
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵtextInterpolate"](_angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵpipeBind1"](23, 20, "challenges.challenge_model.name." + ctx_r0.challengeModelName));
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵadvance"](4);
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵtextInterpolate"](_angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵpipeBind1"](27, 22, "challenges.create.preview.mean"));
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵadvance"](3);
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵtextInterpolate"](_angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵpipeBind1"](30, 24, "challenges.challenge_mean.pointconcept." + ctx_r0.pointConcept));
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵadvance"](4);
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵtextInterpolate"](_angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵpipeBind1"](34, 26, "challenges.create.preview.challengeable"));
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵadvance"](3);
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵtextInterpolate"](ctx_r0.challengeable.nickname);
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵadvance"](3);
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵtextInterpolate"](_angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵpipeBind1"](40, 28, ctx_r0.preview.longDescription));
  }
}

var ChallengePreviewComponent = /*#__PURE__*/function () {
  function ChallengePreviewComponent(userService) {
    (0,_Users_smartcommunitylab_Desktop_newWork_dslab_playgo_mobile_playgo_mobile_node_modules_babel_runtime_helpers_esm_classCallCheck_js__WEBPACK_IMPORTED_MODULE_0__["default"])(this, ChallengePreviewComponent);

    this.userService = userService;
    this.avatarUrl$ = this.userService.userProfile$.pipe((0,rxjs__WEBPACK_IMPORTED_MODULE_5__.map)(function (profile) {
      return profile.avatar.avatarSmallUrl;
    }));
  }

  (0,_Users_smartcommunitylab_Desktop_newWork_dslab_playgo_mobile_playgo_mobile_node_modules_babel_runtime_helpers_esm_createClass_js__WEBPACK_IMPORTED_MODULE_1__["default"])(ChallengePreviewComponent, [{
    key: "ngOnInit",
    value: function ngOnInit() {}
  }]);

  return ChallengePreviewComponent;
}();

ChallengePreviewComponent.ɵfac = function ChallengePreviewComponent_Factory(t) {
  return new (t || ChallengePreviewComponent)(_angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵdirectiveInject"](src_app_core_shared_services_user_service__WEBPACK_IMPORTED_MODULE_2__.UserService));
};

ChallengePreviewComponent.ɵcmp = /*@__PURE__*/_angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵdefineComponent"]({
  type: ChallengePreviewComponent,
  selectors: [["app-challenge-preview"]],
  inputs: {
    challengeModelName: "challengeModelName",
    pointConcept: "pointConcept",
    challengeable: "challengeable",
    preview: "preview"
  },
  decls: 1,
  vars: 1,
  consts: [[4, "ngIf"], [1, "ion-margin-top"], [1, "text-bold", "ion-text-center"], [1, "ion-justify-content-around", "ion-margin-top"], ["size", "auto", 1, "ion-text-center"], [3, "src"], [1, "ion-text-left"], [1, "ion-text-right", "text-bold"], [1, "text-italic"]],
  template: function ChallengePreviewComponent_Template(rf, ctx) {
    if (rf & 1) {
      _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵtemplate"](0, ChallengePreviewComponent_ng_container_0_Template, 41, 30, "ng-container", 0);
    }

    if (rf & 2) {
      _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵproperty"]("ngIf", ctx.preview);
    }
  },
  directives: [_angular_common__WEBPACK_IMPORTED_MODULE_6__.NgIf, _ionic_angular__WEBPACK_IMPORTED_MODULE_7__.IonGrid, _ionic_angular__WEBPACK_IMPORTED_MODULE_7__.IonRow, _ionic_angular__WEBPACK_IMPORTED_MODULE_7__.IonCol, _ionic_angular__WEBPACK_IMPORTED_MODULE_7__.IonAvatar],
  pipes: [_core_shared_pipes_languageMap_pipe__WEBPACK_IMPORTED_MODULE_3__.LanguageMapPipe, _angular_common__WEBPACK_IMPORTED_MODULE_6__.AsyncPipe, _ngx_translate_core__WEBPACK_IMPORTED_MODULE_8__.TranslatePipe],
  styles: ["\n/*# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbXSwibmFtZXMiOltdLCJtYXBwaW5ncyI6IiIsImZpbGUiOiJjaGFsbGVuZ2UtcHJldmlldy5jb21wb25lbnQuc2NzcyJ9 */"]
});

/***/ }),

/***/ 80478:
/*!**************************************************************************************!*\
  !*** ./src/app/pages/challenges/create-challenge/create-challenge-routing.module.ts ***!
  \**************************************************************************************/
/***/ (function(__unused_webpack_module, __webpack_exports__, __webpack_require__) {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "CreateChallengePageRoutingModule": function() { return /* binding */ CreateChallengePageRoutingModule; }
/* harmony export */ });
/* harmony import */ var _Users_smartcommunitylab_Desktop_newWork_dslab_playgo_mobile_playgo_mobile_node_modules_babel_runtime_helpers_esm_createClass_js__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./node_modules/@babel/runtime/helpers/esm/createClass.js */ 48047);
/* harmony import */ var _Users_smartcommunitylab_Desktop_newWork_dslab_playgo_mobile_playgo_mobile_node_modules_babel_runtime_helpers_esm_classCallCheck_js__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ./node_modules/@babel/runtime/helpers/esm/classCallCheck.js */ 78069);
/* harmony import */ var _angular_router__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! @angular/router */ 52816);
/* harmony import */ var _create_challenge_page__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! ./create-challenge.page */ 24756);
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @angular/core */ 3184);






var routes = [{
  path: '',
  component: _create_challenge_page__WEBPACK_IMPORTED_MODULE_2__.CreateChallengePage,
  data: {
    title: 'challenges.create.title'
  }
}];
var CreateChallengePageRoutingModule = /*#__PURE__*/(0,_Users_smartcommunitylab_Desktop_newWork_dslab_playgo_mobile_playgo_mobile_node_modules_babel_runtime_helpers_esm_createClass_js__WEBPACK_IMPORTED_MODULE_0__["default"])(function CreateChallengePageRoutingModule() {
  (0,_Users_smartcommunitylab_Desktop_newWork_dslab_playgo_mobile_playgo_mobile_node_modules_babel_runtime_helpers_esm_classCallCheck_js__WEBPACK_IMPORTED_MODULE_1__["default"])(this, CreateChallengePageRoutingModule);
});

CreateChallengePageRoutingModule.ɵfac = function CreateChallengePageRoutingModule_Factory(t) {
  return new (t || CreateChallengePageRoutingModule)();
};

CreateChallengePageRoutingModule.ɵmod = /*@__PURE__*/_angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵdefineNgModule"]({
  type: CreateChallengePageRoutingModule
});
CreateChallengePageRoutingModule.ɵinj = /*@__PURE__*/_angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵdefineInjector"]({
  imports: [[_angular_router__WEBPACK_IMPORTED_MODULE_4__.RouterModule.forChild(routes)], _angular_router__WEBPACK_IMPORTED_MODULE_4__.RouterModule]
});

(function () {
  (typeof ngJitMode === "undefined" || ngJitMode) && _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵsetNgModuleScope"](CreateChallengePageRoutingModule, {
    imports: [_angular_router__WEBPACK_IMPORTED_MODULE_4__.RouterModule],
    exports: [_angular_router__WEBPACK_IMPORTED_MODULE_4__.RouterModule]
  });
})();

/***/ }),

/***/ 22423:
/*!******************************************************************************!*\
  !*** ./src/app/pages/challenges/create-challenge/create-challenge.module.ts ***!
  \******************************************************************************/
/***/ (function(__unused_webpack_module, __webpack_exports__, __webpack_require__) {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "CreateChallengePageModule": function() { return /* binding */ CreateChallengePageModule; }
/* harmony export */ });
/* harmony import */ var _Users_smartcommunitylab_Desktop_newWork_dslab_playgo_mobile_playgo_mobile_node_modules_babel_runtime_helpers_esm_createClass_js__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./node_modules/@babel/runtime/helpers/esm/createClass.js */ 48047);
/* harmony import */ var _Users_smartcommunitylab_Desktop_newWork_dslab_playgo_mobile_playgo_mobile_node_modules_babel_runtime_helpers_esm_classCallCheck_js__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ./node_modules/@babel/runtime/helpers/esm/classCallCheck.js */ 78069);
/* harmony import */ var _create_challenge_routing_module__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! ./create-challenge-routing.module */ 80478);
/* harmony import */ var _create_challenge_page__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! ./create-challenge.page */ 24756);
/* harmony import */ var src_app_core_shared_shared_module__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! src/app/core/shared/shared.module */ 97205);
/* harmony import */ var _wizard_wizard_component__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! ./wizard/wizard.component */ 1359);
/* harmony import */ var _wizard_wizard_step_wizard_step_component__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! ./wizard/wizard-step/wizard-step.component */ 68774);
/* harmony import */ var _select_challenge_model_select_challenge_model_component__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(/*! ./select-challenge-model/select-challenge-model.component */ 7776);
/* harmony import */ var _select_challenge_mean_select_challenge_mean_component__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(/*! ./select-challenge-mean/select-challenge-mean.component */ 64595);
/* harmony import */ var _select_challengeable_select_challengeable_component__WEBPACK_IMPORTED_MODULE_9__ = __webpack_require__(/*! ./select-challengeable/select-challengeable.component */ 56747);
/* harmony import */ var _challenge_preview_challenge_preview_component__WEBPACK_IMPORTED_MODULE_10__ = __webpack_require__(/*! ./challenge-preview/challenge-preview.component */ 38399);
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_14__ = __webpack_require__(/*! @angular/core */ 3184);
/* harmony import */ var _ionic_angular__WEBPACK_IMPORTED_MODULE_15__ = __webpack_require__(/*! @ionic/angular */ 93819);
/* harmony import */ var _core_shared_layout_header_header_directive__WEBPACK_IMPORTED_MODULE_11__ = __webpack_require__(/*! ../../../core/shared/layout/header/header.directive */ 34161);
/* harmony import */ var _core_shared_layout_content_content_directive__WEBPACK_IMPORTED_MODULE_12__ = __webpack_require__(/*! ../../../core/shared/layout/content/content.directive */ 69669);
/* harmony import */ var _angular_common__WEBPACK_IMPORTED_MODULE_16__ = __webpack_require__(/*! @angular/common */ 36362);
/* harmony import */ var _core_shared_pipes_languageMap_pipe__WEBPACK_IMPORTED_MODULE_13__ = __webpack_require__(/*! ../../../core/shared/pipes/languageMap.pipe */ 73088);
/* harmony import */ var _ngx_translate_core__WEBPACK_IMPORTED_MODULE_17__ = __webpack_require__(/*! @ngx-translate/core */ 87514);


















var CreateChallengePageModule = /*#__PURE__*/(0,_Users_smartcommunitylab_Desktop_newWork_dslab_playgo_mobile_playgo_mobile_node_modules_babel_runtime_helpers_esm_createClass_js__WEBPACK_IMPORTED_MODULE_0__["default"])(function CreateChallengePageModule() {
  (0,_Users_smartcommunitylab_Desktop_newWork_dslab_playgo_mobile_playgo_mobile_node_modules_babel_runtime_helpers_esm_classCallCheck_js__WEBPACK_IMPORTED_MODULE_1__["default"])(this, CreateChallengePageModule);
});

CreateChallengePageModule.ɵfac = function CreateChallengePageModule_Factory(t) {
  return new (t || CreateChallengePageModule)();
};

CreateChallengePageModule.ɵmod = /*@__PURE__*/_angular_core__WEBPACK_IMPORTED_MODULE_14__["ɵɵdefineNgModule"]({
  type: CreateChallengePageModule
});
CreateChallengePageModule.ɵinj = /*@__PURE__*/_angular_core__WEBPACK_IMPORTED_MODULE_14__["ɵɵdefineInjector"]({
  imports: [[src_app_core_shared_shared_module__WEBPACK_IMPORTED_MODULE_4__.PlayGoSharedModule, _create_challenge_routing_module__WEBPACK_IMPORTED_MODULE_2__.CreateChallengePageRoutingModule]]
});

(function () {
  (typeof ngJitMode === "undefined" || ngJitMode) && _angular_core__WEBPACK_IMPORTED_MODULE_14__["ɵɵsetNgModuleScope"](CreateChallengePageModule, {
    declarations: [_create_challenge_page__WEBPACK_IMPORTED_MODULE_3__.CreateChallengePage, _wizard_wizard_component__WEBPACK_IMPORTED_MODULE_5__.WizardComponent, _wizard_wizard_step_wizard_step_component__WEBPACK_IMPORTED_MODULE_6__.WizardStepComponent, _select_challenge_model_select_challenge_model_component__WEBPACK_IMPORTED_MODULE_7__.SelectChallengeModelComponent, _select_challenge_mean_select_challenge_mean_component__WEBPACK_IMPORTED_MODULE_8__.SelectChallengeMeanComponent, _select_challengeable_select_challengeable_component__WEBPACK_IMPORTED_MODULE_9__.SelectChallengeableComponent, _challenge_preview_challenge_preview_component__WEBPACK_IMPORTED_MODULE_10__.ChallengePreviewComponent],
    imports: [src_app_core_shared_shared_module__WEBPACK_IMPORTED_MODULE_4__.PlayGoSharedModule, _create_challenge_routing_module__WEBPACK_IMPORTED_MODULE_2__.CreateChallengePageRoutingModule]
  });
})();

_angular_core__WEBPACK_IMPORTED_MODULE_14__["ɵɵsetComponentScope"](_create_challenge_page__WEBPACK_IMPORTED_MODULE_3__.CreateChallengePage, [_ionic_angular__WEBPACK_IMPORTED_MODULE_15__.IonHeader, _core_shared_layout_header_header_directive__WEBPACK_IMPORTED_MODULE_11__.HeaderDirective, _ionic_angular__WEBPACK_IMPORTED_MODULE_15__.IonContent, _core_shared_layout_content_content_directive__WEBPACK_IMPORTED_MODULE_12__.ContentDirective, _angular_common__WEBPACK_IMPORTED_MODULE_16__.NgIf, _wizard_wizard_component__WEBPACK_IMPORTED_MODULE_5__.WizardComponent, _angular_common__WEBPACK_IMPORTED_MODULE_16__.NgClass, _wizard_wizard_step_wizard_step_component__WEBPACK_IMPORTED_MODULE_6__.WizardStepComponent, _select_challenge_model_select_challenge_model_component__WEBPACK_IMPORTED_MODULE_7__.SelectChallengeModelComponent, _select_challenge_mean_select_challenge_mean_component__WEBPACK_IMPORTED_MODULE_8__.SelectChallengeMeanComponent, _select_challengeable_select_challengeable_component__WEBPACK_IMPORTED_MODULE_9__.SelectChallengeableComponent, _challenge_preview_challenge_preview_component__WEBPACK_IMPORTED_MODULE_10__.ChallengePreviewComponent], [_core_shared_pipes_languageMap_pipe__WEBPACK_IMPORTED_MODULE_13__.LanguageMapPipe, _ngx_translate_core__WEBPACK_IMPORTED_MODULE_17__.TranslatePipe, _angular_common__WEBPACK_IMPORTED_MODULE_16__.AsyncPipe]);

/***/ }),

/***/ 24756:
/*!****************************************************************************!*\
  !*** ./src/app/pages/challenges/create-challenge/create-challenge.page.ts ***!
  \****************************************************************************/
/***/ (function(__unused_webpack_module, __webpack_exports__, __webpack_require__) {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "CreateChallengePage": function() { return /* binding */ CreateChallengePage; },
/* harmony export */   "POINT_CONCEPT_GAME": function() { return /* binding */ POINT_CONCEPT_GAME; },
/* harmony export */   "meanToPointConcept": function() { return /* binding */ meanToPointConcept; }
/* harmony export */ });
/* harmony import */ var _Users_smartcommunitylab_Desktop_newWork_dslab_playgo_mobile_playgo_mobile_node_modules_babel_runtime_helpers_esm_toConsumableArray_js__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./node_modules/@babel/runtime/helpers/esm/toConsumableArray.js */ 58277);
/* harmony import */ var _Users_smartcommunitylab_Desktop_newWork_dslab_playgo_mobile_playgo_mobile_node_modules_babel_runtime_helpers_esm_slicedToArray_js__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ./node_modules/@babel/runtime/helpers/esm/slicedToArray.js */ 10507);
/* harmony import */ var _Users_smartcommunitylab_Desktop_newWork_dslab_playgo_mobile_playgo_mobile_node_modules_babel_runtime_helpers_esm_classCallCheck_js__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! ./node_modules/@babel/runtime/helpers/esm/classCallCheck.js */ 78069);
/* harmony import */ var _Users_smartcommunitylab_Desktop_newWork_dslab_playgo_mobile_playgo_mobile_node_modules_babel_runtime_helpers_esm_createClass_js__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! ./node_modules/@babel/runtime/helpers/esm/createClass.js */ 48047);
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_19__ = __webpack_require__(/*! tslib */ 42321);
/* harmony import */ var lodash_es__WEBPACK_IMPORTED_MODULE_16__ = __webpack_require__(/*! lodash-es */ 97732);
/* harmony import */ var rxjs__WEBPACK_IMPORTED_MODULE_12__ = __webpack_require__(/*! rxjs */ 50635);
/* harmony import */ var rxjs__WEBPACK_IMPORTED_MODULE_13__ = __webpack_require__(/*! rxjs */ 32673);
/* harmony import */ var rxjs__WEBPACK_IMPORTED_MODULE_14__ = __webpack_require__(/*! rxjs */ 80228);
/* harmony import */ var rxjs__WEBPACK_IMPORTED_MODULE_15__ = __webpack_require__(/*! rxjs */ 26562);
/* harmony import */ var rxjs__WEBPACK_IMPORTED_MODULE_17__ = __webpack_require__(/*! rxjs */ 19337);
/* harmony import */ var rxjs__WEBPACK_IMPORTED_MODULE_18__ = __webpack_require__(/*! rxjs */ 89196);
/* harmony import */ var rxjs__WEBPACK_IMPORTED_MODULE_20__ = __webpack_require__(/*! rxjs */ 54363);
/* harmony import */ var src_app_core_shared_tracking_trip_model__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! src/app/core/shared/tracking/trip.model */ 49110);
/* harmony import */ var src_app_core_shared_rxjs_utils__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! src/app/core/shared/rxjs.utils */ 9257);
/* harmony import */ var _sent_invitation_modal_sent_invitation_modal__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! ./sent-invitation-modal/sent-invitation.modal */ 29212);
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_11__ = __webpack_require__(/*! @angular/core */ 3184);
/* harmony import */ var _angular_router__WEBPACK_IMPORTED_MODULE_21__ = __webpack_require__(/*! @angular/router */ 52816);
/* harmony import */ var src_app_core_shared_services_campaign_service__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(/*! src/app/core/shared/services/campaign.service */ 23645);
/* harmony import */ var src_app_core_api_generated_controllers_challengeController_service__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(/*! src/app/core/api/generated/controllers/challengeController.service */ 74458);
/* harmony import */ var src_app_core_shared_services_error_service__WEBPACK_IMPORTED_MODULE_9__ = __webpack_require__(/*! src/app/core/shared/services/error.service */ 96204);
/* harmony import */ var _ionic_angular__WEBPACK_IMPORTED_MODULE_22__ = __webpack_require__(/*! @ionic/angular */ 93819);
/* harmony import */ var src_app_core_shared_services_challenge_service__WEBPACK_IMPORTED_MODULE_10__ = __webpack_require__(/*! src/app/core/shared/services/challenge.service */ 66324);





function _regeneratorRuntime() { "use strict"; /*! regenerator-runtime -- Copyright (c) 2014-present, Facebook, Inc. -- license (MIT): https://github.com/facebook/regenerator/blob/main/LICENSE */ _regeneratorRuntime = function _regeneratorRuntime() { return e; }; var t, e = {}, r = Object.prototype, n = r.hasOwnProperty, o = Object.defineProperty || function (t, e, r) { t[e] = r.value; }, i = "function" == typeof Symbol ? Symbol : {}, a = i.iterator || "@@iterator", c = i.asyncIterator || "@@asyncIterator", u = i.toStringTag || "@@toStringTag"; function define(t, e, r) { return Object.defineProperty(t, e, { value: r, enumerable: !0, configurable: !0, writable: !0 }), t[e]; } try { define({}, ""); } catch (t) { define = function define(t, e, r) { return t[e] = r; }; } function wrap(t, e, r, n) { var i = e && e.prototype instanceof Generator ? e : Generator, a = Object.create(i.prototype), c = new Context(n || []); return o(a, "_invoke", { value: makeInvokeMethod(t, r, c) }), a; } function tryCatch(t, e, r) { try { return { type: "normal", arg: t.call(e, r) }; } catch (t) { return { type: "throw", arg: t }; } } e.wrap = wrap; var h = "suspendedStart", l = "suspendedYield", f = "executing", s = "completed", y = {}; function Generator() {} function GeneratorFunction() {} function GeneratorFunctionPrototype() {} var p = {}; define(p, a, function () { return this; }); var d = Object.getPrototypeOf, v = d && d(d(values([]))); v && v !== r && n.call(v, a) && (p = v); var g = GeneratorFunctionPrototype.prototype = Generator.prototype = Object.create(p); function defineIteratorMethods(t) { ["next", "throw", "return"].forEach(function (e) { define(t, e, function (t) { return this._invoke(e, t); }); }); } function AsyncIterator(t, e) { function invoke(r, o, i, a) { var c = tryCatch(t[r], t, o); if ("throw" !== c.type) { var u = c.arg, h = u.value; return h && "object" == typeof h && n.call(h, "__await") ? e.resolve(h.__await).then(function (t) { invoke("next", t, i, a); }, function (t) { invoke("throw", t, i, a); }) : e.resolve(h).then(function (t) { u.value = t, i(u); }, function (t) { return invoke("throw", t, i, a); }); } a(c.arg); } var r; o(this, "_invoke", { value: function value(t, n) { function callInvokeWithMethodAndArg() { return new e(function (e, r) { invoke(t, n, e, r); }); } return r = r ? r.then(callInvokeWithMethodAndArg, callInvokeWithMethodAndArg) : callInvokeWithMethodAndArg(); } }); } function makeInvokeMethod(e, r, n) { var o = h; return function (i, a) { if (o === f) throw new Error("Generator is already running"); if (o === s) { if ("throw" === i) throw a; return { value: t, done: !0 }; } for (n.method = i, n.arg = a;;) { var c = n.delegate; if (c) { var u = maybeInvokeDelegate(c, n); if (u) { if (u === y) continue; return u; } } if ("next" === n.method) n.sent = n._sent = n.arg;else if ("throw" === n.method) { if (o === h) throw o = s, n.arg; n.dispatchException(n.arg); } else "return" === n.method && n.abrupt("return", n.arg); o = f; var p = tryCatch(e, r, n); if ("normal" === p.type) { if (o = n.done ? s : l, p.arg === y) continue; return { value: p.arg, done: n.done }; } "throw" === p.type && (o = s, n.method = "throw", n.arg = p.arg); } }; } function maybeInvokeDelegate(e, r) { var n = r.method, o = e.iterator[n]; if (o === t) return r.delegate = null, "throw" === n && e.iterator.return && (r.method = "return", r.arg = t, maybeInvokeDelegate(e, r), "throw" === r.method) || "return" !== n && (r.method = "throw", r.arg = new TypeError("The iterator does not provide a '" + n + "' method")), y; var i = tryCatch(o, e.iterator, r.arg); if ("throw" === i.type) return r.method = "throw", r.arg = i.arg, r.delegate = null, y; var a = i.arg; return a ? a.done ? (r[e.resultName] = a.value, r.next = e.nextLoc, "return" !== r.method && (r.method = "next", r.arg = t), r.delegate = null, y) : a : (r.method = "throw", r.arg = new TypeError("iterator result is not an object"), r.delegate = null, y); } function pushTryEntry(t) { var e = { tryLoc: t[0] }; 1 in t && (e.catchLoc = t[1]), 2 in t && (e.finallyLoc = t[2], e.afterLoc = t[3]), this.tryEntries.push(e); } function resetTryEntry(t) { var e = t.completion || {}; e.type = "normal", delete e.arg, t.completion = e; } function Context(t) { this.tryEntries = [{ tryLoc: "root" }], t.forEach(pushTryEntry, this), this.reset(!0); } function values(e) { if (e || "" === e) { var r = e[a]; if (r) return r.call(e); if ("function" == typeof e.next) return e; if (!isNaN(e.length)) { var o = -1, i = function next() { for (; ++o < e.length;) if (n.call(e, o)) return next.value = e[o], next.done = !1, next; return next.value = t, next.done = !0, next; }; return i.next = i; } } throw new TypeError(typeof e + " is not iterable"); } return GeneratorFunction.prototype = GeneratorFunctionPrototype, o(g, "constructor", { value: GeneratorFunctionPrototype, configurable: !0 }), o(GeneratorFunctionPrototype, "constructor", { value: GeneratorFunction, configurable: !0 }), GeneratorFunction.displayName = define(GeneratorFunctionPrototype, u, "GeneratorFunction"), e.isGeneratorFunction = function (t) { var e = "function" == typeof t && t.constructor; return !!e && (e === GeneratorFunction || "GeneratorFunction" === (e.displayName || e.name)); }, e.mark = function (t) { return Object.setPrototypeOf ? Object.setPrototypeOf(t, GeneratorFunctionPrototype) : (t.__proto__ = GeneratorFunctionPrototype, define(t, u, "GeneratorFunction")), t.prototype = Object.create(g), t; }, e.awrap = function (t) { return { __await: t }; }, defineIteratorMethods(AsyncIterator.prototype), define(AsyncIterator.prototype, c, function () { return this; }), e.AsyncIterator = AsyncIterator, e.async = function (t, r, n, o, i) { void 0 === i && (i = Promise); var a = new AsyncIterator(wrap(t, r, n, o), i); return e.isGeneratorFunction(r) ? a : a.next().then(function (t) { return t.done ? t.value : a.next(); }); }, defineIteratorMethods(g), define(g, u, "Generator"), define(g, a, function () { return this; }), define(g, "toString", function () { return "[object Generator]"; }), e.keys = function (t) { var e = Object(t), r = []; for (var n in e) r.push(n); return r.reverse(), function next() { for (; r.length;) { var t = r.pop(); if (t in e) return next.value = t, next.done = !1, next; } return next.done = !0, next; }; }, e.values = values, Context.prototype = { constructor: Context, reset: function reset(e) { if (this.prev = 0, this.next = 0, this.sent = this._sent = t, this.done = !1, this.delegate = null, this.method = "next", this.arg = t, this.tryEntries.forEach(resetTryEntry), !e) for (var r in this) "t" === r.charAt(0) && n.call(this, r) && !isNaN(+r.slice(1)) && (this[r] = t); }, stop: function stop() { this.done = !0; var t = this.tryEntries[0].completion; if ("throw" === t.type) throw t.arg; return this.rval; }, dispatchException: function dispatchException(e) { if (this.done) throw e; var r = this; function handle(n, o) { return a.type = "throw", a.arg = e, r.next = n, o && (r.method = "next", r.arg = t), !!o; } for (var o = this.tryEntries.length - 1; o >= 0; --o) { var i = this.tryEntries[o], a = i.completion; if ("root" === i.tryLoc) return handle("end"); if (i.tryLoc <= this.prev) { var c = n.call(i, "catchLoc"), u = n.call(i, "finallyLoc"); if (c && u) { if (this.prev < i.catchLoc) return handle(i.catchLoc, !0); if (this.prev < i.finallyLoc) return handle(i.finallyLoc); } else if (c) { if (this.prev < i.catchLoc) return handle(i.catchLoc, !0); } else { if (!u) throw new Error("try statement without catch or finally"); if (this.prev < i.finallyLoc) return handle(i.finallyLoc); } } } }, abrupt: function abrupt(t, e) { for (var r = this.tryEntries.length - 1; r >= 0; --r) { var o = this.tryEntries[r]; if (o.tryLoc <= this.prev && n.call(o, "finallyLoc") && this.prev < o.finallyLoc) { var i = o; break; } } i && ("break" === t || "continue" === t) && i.tryLoc <= e && e <= i.finallyLoc && (i = null); var a = i ? i.completion : {}; return a.type = t, a.arg = e, i ? (this.method = "next", this.next = i.finallyLoc, y) : this.complete(a); }, complete: function complete(t, e) { if ("throw" === t.type) throw t.arg; return "break" === t.type || "continue" === t.type ? this.next = t.arg : "return" === t.type ? (this.rval = this.arg = t.arg, this.method = "return", this.next = "end") : "normal" === t.type && e && (this.next = e), y; }, finish: function finish(t) { for (var e = this.tryEntries.length - 1; e >= 0; --e) { var r = this.tryEntries[e]; if (r.finallyLoc === t) return this.complete(r.completion, r.afterLoc), resetTryEntry(r), y; } }, catch: function _catch(t) { for (var e = this.tryEntries.length - 1; e >= 0; --e) { var r = this.tryEntries[e]; if (r.tryLoc === t) { var n = r.completion; if ("throw" === n.type) { var o = n.arg; resetTryEntry(r); } return o; } } throw new Error("illegal catch attempt"); }, delegateYield: function delegateYield(e, r, n) { return this.delegate = { iterator: values(e), resultName: r, nextLoc: n }, "next" === this.method && (this.arg = t), y; } }, e; }















function CreateChallengePage_app_wizard_2_Template(rf, ctx) {
  if (rf & 1) {
    var _r3 = _angular_core__WEBPACK_IMPORTED_MODULE_11__["ɵɵgetCurrentView"]();

    _angular_core__WEBPACK_IMPORTED_MODULE_11__["ɵɵelementStart"](0, "app-wizard", 3);
    _angular_core__WEBPACK_IMPORTED_MODULE_11__["ɵɵlistener"]("finish", function CreateChallengePage_app_wizard_2_Template_app_wizard_finish_0_listener() {
      _angular_core__WEBPACK_IMPORTED_MODULE_11__["ɵɵrestoreView"](_r3);
      var ctx_r2 = _angular_core__WEBPACK_IMPORTED_MODULE_11__["ɵɵnextContext"]();
      return ctx_r2.onInvite();
    });
    _angular_core__WEBPACK_IMPORTED_MODULE_11__["ɵɵpipe"](1, "languageMap");
    _angular_core__WEBPACK_IMPORTED_MODULE_11__["ɵɵpipe"](2, "translate");
    _angular_core__WEBPACK_IMPORTED_MODULE_11__["ɵɵelementStart"](3, "app-wizard-step", 4);
    _angular_core__WEBPACK_IMPORTED_MODULE_11__["ɵɵpipe"](4, "async");
    _angular_core__WEBPACK_IMPORTED_MODULE_11__["ɵɵelementStart"](5, "div", 5)(6, "h2");
    _angular_core__WEBPACK_IMPORTED_MODULE_11__["ɵɵtext"](7);
    _angular_core__WEBPACK_IMPORTED_MODULE_11__["ɵɵpipe"](8, "translate");
    _angular_core__WEBPACK_IMPORTED_MODULE_11__["ɵɵelementEnd"]()();
    _angular_core__WEBPACK_IMPORTED_MODULE_11__["ɵɵelementStart"](9, "app-select-challenge-model", 6);
    _angular_core__WEBPACK_IMPORTED_MODULE_11__["ɵɵlistener"]("selectedModel", function CreateChallengePage_app_wizard_2_Template_app_select_challenge_model_selectedModel_9_listener($event) {
      _angular_core__WEBPACK_IMPORTED_MODULE_11__["ɵɵrestoreView"](_r3);
      var ctx_r4 = _angular_core__WEBPACK_IMPORTED_MODULE_11__["ɵɵnextContext"]();
      return ctx_r4.selectedModelName$.next($event);
    });
    _angular_core__WEBPACK_IMPORTED_MODULE_11__["ɵɵpipe"](10, "async");
    _angular_core__WEBPACK_IMPORTED_MODULE_11__["ɵɵelementEnd"]()();
    _angular_core__WEBPACK_IMPORTED_MODULE_11__["ɵɵelementStart"](11, "app-wizard-step", 7);
    _angular_core__WEBPACK_IMPORTED_MODULE_11__["ɵɵpipe"](12, "async");
    _angular_core__WEBPACK_IMPORTED_MODULE_11__["ɵɵelementStart"](13, "div", 5)(14, "h2");
    _angular_core__WEBPACK_IMPORTED_MODULE_11__["ɵɵtext"](15);
    _angular_core__WEBPACK_IMPORTED_MODULE_11__["ɵɵpipe"](16, "translate");
    _angular_core__WEBPACK_IMPORTED_MODULE_11__["ɵɵelementEnd"]()();
    _angular_core__WEBPACK_IMPORTED_MODULE_11__["ɵɵelementStart"](17, "app-select-challenge-mean", 8);
    _angular_core__WEBPACK_IMPORTED_MODULE_11__["ɵɵlistener"]("selectedMean", function CreateChallengePage_app_wizard_2_Template_app_select_challenge_mean_selectedMean_17_listener($event) {
      _angular_core__WEBPACK_IMPORTED_MODULE_11__["ɵɵrestoreView"](_r3);
      var ctx_r5 = _angular_core__WEBPACK_IMPORTED_MODULE_11__["ɵɵnextContext"]();
      return ctx_r5.selectedPointConcept$.next($event);
    });
    _angular_core__WEBPACK_IMPORTED_MODULE_11__["ɵɵpipe"](18, "async");
    _angular_core__WEBPACK_IMPORTED_MODULE_11__["ɵɵelementEnd"]()();
    _angular_core__WEBPACK_IMPORTED_MODULE_11__["ɵɵelementStart"](19, "app-wizard-step", 9);
    _angular_core__WEBPACK_IMPORTED_MODULE_11__["ɵɵpipe"](20, "async");
    _angular_core__WEBPACK_IMPORTED_MODULE_11__["ɵɵelementStart"](21, "app-select-challengeable", 10);
    _angular_core__WEBPACK_IMPORTED_MODULE_11__["ɵɵlistener"]("selectedChallengeable", function CreateChallengePage_app_wizard_2_Template_app_select_challengeable_selectedChallengeable_21_listener($event) {
      _angular_core__WEBPACK_IMPORTED_MODULE_11__["ɵɵrestoreView"](_r3);
      var ctx_r6 = _angular_core__WEBPACK_IMPORTED_MODULE_11__["ɵɵnextContext"]();
      return ctx_r6.selectedChallengeableId$.next($event);
    });
    _angular_core__WEBPACK_IMPORTED_MODULE_11__["ɵɵpipe"](22, "async");
    _angular_core__WEBPACK_IMPORTED_MODULE_11__["ɵɵelementEnd"]()();
    _angular_core__WEBPACK_IMPORTED_MODULE_11__["ɵɵelementStart"](23, "app-wizard-step", 11);
    _angular_core__WEBPACK_IMPORTED_MODULE_11__["ɵɵlistener"]("activated", function CreateChallengePage_app_wizard_2_Template_app_wizard_step_activated_23_listener() {
      _angular_core__WEBPACK_IMPORTED_MODULE_11__["ɵɵrestoreView"](_r3);
      var ctx_r7 = _angular_core__WEBPACK_IMPORTED_MODULE_11__["ɵɵnextContext"]();
      return ctx_r7.previewActive$.next();
    });
    _angular_core__WEBPACK_IMPORTED_MODULE_11__["ɵɵelement"](24, "app-challenge-preview", 12);
    _angular_core__WEBPACK_IMPORTED_MODULE_11__["ɵɵpipe"](25, "async");
    _angular_core__WEBPACK_IMPORTED_MODULE_11__["ɵɵpipe"](26, "async");
    _angular_core__WEBPACK_IMPORTED_MODULE_11__["ɵɵpipe"](27, "async");
    _angular_core__WEBPACK_IMPORTED_MODULE_11__["ɵɵpipe"](28, "async");
    _angular_core__WEBPACK_IMPORTED_MODULE_11__["ɵɵelementEnd"]()();
  }

  if (rf & 2) {
    var campaign_r1 = ctx.ngIf;
    var ctx_r0 = _angular_core__WEBPACK_IMPORTED_MODULE_11__["ɵɵnextContext"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_11__["ɵɵproperty"]("title", _angular_core__WEBPACK_IMPORTED_MODULE_11__["ɵɵpipeBind1"](1, 16, campaign_r1.name))("backButton", false)("ngClass", "ion-color-" + ctx_r0.getCampaignColor(campaign_r1))("finishButtonLabel", _angular_core__WEBPACK_IMPORTED_MODULE_11__["ɵɵpipeBind1"](2, 18, "challenges.create.invite"));
    _angular_core__WEBPACK_IMPORTED_MODULE_11__["ɵɵadvance"](3);
    _angular_core__WEBPACK_IMPORTED_MODULE_11__["ɵɵproperty"]("validForNextStep", _angular_core__WEBPACK_IMPORTED_MODULE_11__["ɵɵpipeBind1"](4, 20, ctx_r0.selectedModelName$) !== null);
    _angular_core__WEBPACK_IMPORTED_MODULE_11__["ɵɵadvance"](4);
    _angular_core__WEBPACK_IMPORTED_MODULE_11__["ɵɵtextInterpolate"](_angular_core__WEBPACK_IMPORTED_MODULE_11__["ɵɵpipeBind1"](8, 22, "challenges.challenge_model.title"));
    _angular_core__WEBPACK_IMPORTED_MODULE_11__["ɵɵadvance"](2);
    _angular_core__WEBPACK_IMPORTED_MODULE_11__["ɵɵproperty"]("availableModels", _angular_core__WEBPACK_IMPORTED_MODULE_11__["ɵɵpipeBind1"](10, 24, ctx_r0.challengeModels$));
    _angular_core__WEBPACK_IMPORTED_MODULE_11__["ɵɵadvance"](2);
    _angular_core__WEBPACK_IMPORTED_MODULE_11__["ɵɵproperty"]("validForNextStep", _angular_core__WEBPACK_IMPORTED_MODULE_11__["ɵɵpipeBind1"](12, 26, ctx_r0.selectedPointConcept$) !== null);
    _angular_core__WEBPACK_IMPORTED_MODULE_11__["ɵɵadvance"](4);
    _angular_core__WEBPACK_IMPORTED_MODULE_11__["ɵɵtextInterpolate"](_angular_core__WEBPACK_IMPORTED_MODULE_11__["ɵɵpipeBind1"](16, 28, "challenges.challenge_mean.title"));
    _angular_core__WEBPACK_IMPORTED_MODULE_11__["ɵɵadvance"](2);
    _angular_core__WEBPACK_IMPORTED_MODULE_11__["ɵɵproperty"]("availableMeans", _angular_core__WEBPACK_IMPORTED_MODULE_11__["ɵɵpipeBind1"](18, 30, ctx_r0.pointConcepts$));
    _angular_core__WEBPACK_IMPORTED_MODULE_11__["ɵɵadvance"](2);
    _angular_core__WEBPACK_IMPORTED_MODULE_11__["ɵɵproperty"]("validForNextStep", _angular_core__WEBPACK_IMPORTED_MODULE_11__["ɵɵpipeBind1"](20, 32, ctx_r0.selectedChallengeableId$) !== null);
    _angular_core__WEBPACK_IMPORTED_MODULE_11__["ɵɵadvance"](2);
    _angular_core__WEBPACK_IMPORTED_MODULE_11__["ɵɵproperty"]("availableChallengeables", _angular_core__WEBPACK_IMPORTED_MODULE_11__["ɵɵpipeBind1"](22, 34, ctx_r0.challengeables$));
    _angular_core__WEBPACK_IMPORTED_MODULE_11__["ɵɵadvance"](3);
    _angular_core__WEBPACK_IMPORTED_MODULE_11__["ɵɵproperty"]("challengeModelName", _angular_core__WEBPACK_IMPORTED_MODULE_11__["ɵɵpipeBind1"](25, 36, ctx_r0.selectedModelName$))("pointConcept", _angular_core__WEBPACK_IMPORTED_MODULE_11__["ɵɵpipeBind1"](26, 38, ctx_r0.selectedPointConcept$))("challengeable", _angular_core__WEBPACK_IMPORTED_MODULE_11__["ɵɵpipeBind1"](27, 40, ctx_r0.selectedChallengeable$))("preview", _angular_core__WEBPACK_IMPORTED_MODULE_11__["ɵɵpipeBind1"](28, 42, ctx_r0.preview$));
  }
}

var CreateChallengePage = /*#__PURE__*/function () {
  function CreateChallengePage(route, campaignService, challengeControllerService, errorService, navController, challengeService, modalController) {
    var _this = this;

    (0,_Users_smartcommunitylab_Desktop_newWork_dslab_playgo_mobile_playgo_mobile_node_modules_babel_runtime_helpers_esm_classCallCheck_js__WEBPACK_IMPORTED_MODULE_2__["default"])(this, CreateChallengePage);

    this.route = route;
    this.campaignService = campaignService;
    this.challengeControllerService = challengeControllerService;
    this.errorService = errorService;
    this.navController = navController;
    this.challengeService = challengeService;
    this.modalController = modalController;
    this.campaignId$ = this.route.params.pipe((0,rxjs__WEBPACK_IMPORTED_MODULE_12__.map)(function (params) {
      return params.id;
    }));
    this.campaign$ = this.campaignId$.pipe((0,rxjs__WEBPACK_IMPORTED_MODULE_13__.switchMap)(function (campaignId) {
      return _this.campaignService.myCampaigns$.pipe((0,rxjs__WEBPACK_IMPORTED_MODULE_12__.map)(function (campaigns) {
        var _a;

        return (_a = campaigns.find(function (campaignContainer) {
          return campaignContainer.campaign.campaignId === campaignId;
        })) === null || _a === void 0 ? void 0 : _a.campaign;
      }));
    }));
    this.challengeModels$ = this.campaignId$.pipe((0,rxjs__WEBPACK_IMPORTED_MODULE_13__.switchMap)(function (campaignId) {
      return _this.challengeControllerService.getChallengesStatusUsingGET(campaignId).pipe(_this.errorService.getErrorHandler());
    }), (0,rxjs__WEBPACK_IMPORTED_MODULE_12__.map)(function (availableChallenges) {
      var all = [{
        challengeModelName: 'groupCooperative',
        availableFromLevel: 4
      }, {
        challengeModelName: 'groupCompetitiveTime',
        availableFromLevel: 5
      }, {
        challengeModelName: 'groupCompetitivePerformance',
        availableFromLevel: 6
      }];
      var allWithAvailableInfo = all.map(function (challengeModel) {
        var _a;

        var serverState = (_a = availableChallenges.find(function (eachServerChallengeMode) {
          return eachServerChallengeMode.modelName === challengeModel.challengeModelName;
        })) === null || _a === void 0 ? void 0 : _a.state;
        return Object.assign(Object.assign({}, challengeModel), {
          available: serverState === 'ACTIVE'
        });
      });
      return allWithAvailableInfo;
    }));
    this.selectedModelName$ = new rxjs__WEBPACK_IMPORTED_MODULE_14__.Subject();
    this.pointConcepts$ = (0,rxjs__WEBPACK_IMPORTED_MODULE_15__.combineLatest)([this.campaignService.availableMeans$, this.campaign$]).pipe((0,rxjs__WEBPACK_IMPORTED_MODULE_12__.map)(function (_ref) {
      var _ref2 = (0,_Users_smartcommunitylab_Desktop_newWork_dslab_playgo_mobile_playgo_mobile_node_modules_babel_runtime_helpers_esm_slicedToArray_js__WEBPACK_IMPORTED_MODULE_1__["default"])(_ref, 2),
          means = _ref2[0],
          campaign = _ref2[1];

      var gameInfo = {
        isMean: false,
        icon: _this.campaignService.getCampaignScoreIcon(campaign),
        name: POINT_CONCEPT_GAME,
        title: _this.campaignService.getCampaignScoreLabel(campaign)
      };
      var meansInfos = means.filter(function (mean) {
        return meanToPointConcept[mean];
      }).map(function (mean) {
        return {
          isMean: true,
          icon: src_app_core_shared_tracking_trip_model__WEBPACK_IMPORTED_MODULE_4__.transportTypeIcons[mean],
          name: meanToPointConcept[mean],
          title: src_app_core_shared_tracking_trip_model__WEBPACK_IMPORTED_MODULE_4__.transportTypeLabels[mean]
        };
      });
      return [gameInfo].concat((0,_Users_smartcommunitylab_Desktop_newWork_dslab_playgo_mobile_playgo_mobile_node_modules_babel_runtime_helpers_esm_toConsumableArray_js__WEBPACK_IMPORTED_MODULE_0__["default"])(meansInfos));
    }));
    this.selectedPointConcept$ = new rxjs__WEBPACK_IMPORTED_MODULE_14__.Subject();
    this.challengeables$ = this.campaignId$.pipe((0,rxjs__WEBPACK_IMPORTED_MODULE_13__.switchMap)(function (campaignId) {
      return _this.challengeControllerService.getChallengeablesUsingGET(campaignId).pipe(_this.errorService.getErrorHandler());
    }), (0,rxjs__WEBPACK_IMPORTED_MODULE_12__.map)(function (challengeables) {
      return challengeables.map(function (eachUser) {
        var _a, _b;

        return {
          id: eachUser.id,
          nickname: eachUser.nickname,
          avatarUrl: (_b = (_a = eachUser === null || eachUser === void 0 ? void 0 : eachUser.avatar) === null || _a === void 0 ? void 0 : _a.url) !== null && _b !== void 0 ? _b : 'assets/images/registration/generic_user.png'
        };
      });
    }));
    this.selectedChallengeableId$ = new rxjs__WEBPACK_IMPORTED_MODULE_14__.Subject();
    this.selectedChallengeable$ = (0,rxjs__WEBPACK_IMPORTED_MODULE_15__.combineLatest)([this.challengeables$, this.selectedChallengeableId$]).pipe((0,rxjs__WEBPACK_IMPORTED_MODULE_12__.map)(function (_ref3) {
      var _ref4 = (0,_Users_smartcommunitylab_Desktop_newWork_dslab_playgo_mobile_playgo_mobile_node_modules_babel_runtime_helpers_esm_slicedToArray_js__WEBPACK_IMPORTED_MODULE_1__["default"])(_ref3, 2),
          allChallengeables = _ref4[0],
          selectedId = _ref4[1];

      return (0,lodash_es__WEBPACK_IMPORTED_MODULE_16__["default"])(allChallengeables, {
        id: selectedId
      });
    }), (0,rxjs__WEBPACK_IMPORTED_MODULE_17__.tap)(function (chall) {
      return _this.nicknameOpponent = chall.nickname;
    }));
    this.previewActive$ = new rxjs__WEBPACK_IMPORTED_MODULE_14__.Subject();
    this.inviteParams$ = (0,rxjs__WEBPACK_IMPORTED_MODULE_15__.combineLatest)({
      campaignId: this.campaignId$,
      selectedChallengeableId: this.selectedChallengeableId$,
      selectedModelName: this.selectedModelName$,
      selectedPointConcept: this.selectedPointConcept$
    }).pipe((0,rxjs__WEBPACK_IMPORTED_MODULE_12__.map)(function (_ref5) {
      var campaignId = _ref5.campaignId,
          selectedChallengeableId = _ref5.selectedChallengeableId,
          selectedModelName = _ref5.selectedModelName,
          selectedPointConcept = _ref5.selectedPointConcept;
      return {
        campaignId: campaignId,
        body: {
          attendeeId: selectedChallengeableId,
          challengeModelName: selectedModelName,
          challengePointConcept: selectedPointConcept
        }
      };
    }), (0,rxjs__WEBPACK_IMPORTED_MODULE_18__.shareReplay)(1));
    this.preview$ = this.inviteParams$.pipe((0,rxjs__WEBPACK_IMPORTED_MODULE_13__.switchMap)(function (data) {
      return _this.previewActive$.pipe((0,rxjs__WEBPACK_IMPORTED_MODULE_12__.map)(function () {
        return data;
      }));
    }), (0,rxjs__WEBPACK_IMPORTED_MODULE_13__.switchMap)(function (inviteParams) {
      return _this.challengeControllerService.getGroupChallengePreviewUsingPOST(inviteParams).pipe(_this.errorService.getErrorHandler(), (0,src_app_core_shared_rxjs_utils__WEBPACK_IMPORTED_MODULE_5__.castTo)());
    }));
    this.getCampaignColor = this.campaignService.getCampaignColor;
  }

  (0,_Users_smartcommunitylab_Desktop_newWork_dslab_playgo_mobile_playgo_mobile_node_modules_babel_runtime_helpers_esm_createClass_js__WEBPACK_IMPORTED_MODULE_3__["default"])(CreateChallengePage, [{
    key: "ngOnInit",
    value: function ngOnInit() {}
  }, {
    key: "onInvite",
    value: function onInvite() {
      return (0,tslib__WEBPACK_IMPORTED_MODULE_19__.__awaiter)(this, void 0, void 0, /*#__PURE__*/_regeneratorRuntime().mark(function _callee() {
        var inviteParams, modal, navigationExtras;
        return _regeneratorRuntime().wrap(function _callee$(_context) {
          while (1) switch (_context.prev = _context.next) {
            case 0:
              console.log('Invite!');
              _context.next = 3;
              return (0,rxjs__WEBPACK_IMPORTED_MODULE_20__.firstValueFrom)(this.inviteParams$);

            case 3:
              inviteParams = _context.sent;
              _context.prev = 4;
              _context.next = 7;
              return this.challengeService.sendInvitation(inviteParams);

            case 7:
              _context.next = 9;
              return this.modalController.create({
                component: _sent_invitation_modal_sent_invitation_modal__WEBPACK_IMPORTED_MODULE_6__.SentInvitationlModalPage,
                cssClass: 'modal-challenge',
                componentProps: {
                  opponentName: this.nicknameOpponent
                },
                swipeToClose: true
              });

            case 9:
              modal = _context.sent;
              _context.next = 12;
              return modal.present();

            case 12:
              navigationExtras = {
                queryParams: {
                  selectedSegment: 'futureChallenges'
                }
              };
              this.navController.navigateBack('pages/tabs/challenges', navigationExtras);
              _context.next = 19;
              break;

            case 16:
              _context.prev = 16;
              _context.t0 = _context["catch"](4);
              this.errorService.handleError(_context.t0);

            case 19:
            case "end":
              return _context.stop();
          }
        }, _callee, this, [[4, 16]]);
      }));
    }
  }]);

  return CreateChallengePage;
}();

CreateChallengePage.ɵfac = function CreateChallengePage_Factory(t) {
  return new (t || CreateChallengePage)(_angular_core__WEBPACK_IMPORTED_MODULE_11__["ɵɵdirectiveInject"](_angular_router__WEBPACK_IMPORTED_MODULE_21__.ActivatedRoute), _angular_core__WEBPACK_IMPORTED_MODULE_11__["ɵɵdirectiveInject"](src_app_core_shared_services_campaign_service__WEBPACK_IMPORTED_MODULE_7__.CampaignService), _angular_core__WEBPACK_IMPORTED_MODULE_11__["ɵɵdirectiveInject"](src_app_core_api_generated_controllers_challengeController_service__WEBPACK_IMPORTED_MODULE_8__.ChallengeControllerService), _angular_core__WEBPACK_IMPORTED_MODULE_11__["ɵɵdirectiveInject"](src_app_core_shared_services_error_service__WEBPACK_IMPORTED_MODULE_9__.ErrorService), _angular_core__WEBPACK_IMPORTED_MODULE_11__["ɵɵdirectiveInject"](_ionic_angular__WEBPACK_IMPORTED_MODULE_22__.NavController), _angular_core__WEBPACK_IMPORTED_MODULE_11__["ɵɵdirectiveInject"](src_app_core_shared_services_challenge_service__WEBPACK_IMPORTED_MODULE_10__.ChallengeService), _angular_core__WEBPACK_IMPORTED_MODULE_11__["ɵɵdirectiveInject"](_ionic_angular__WEBPACK_IMPORTED_MODULE_22__.ModalController));
};

CreateChallengePage.ɵcmp = /*@__PURE__*/_angular_core__WEBPACK_IMPORTED_MODULE_11__["ɵɵdefineComponent"]({
  type: CreateChallengePage,
  selectors: [["app-create-challenge"]],
  decls: 4,
  vars: 3,
  consts: [["appHeader", ""], ["appContent", ""], [3, "title", "backButton", "ngClass", "finishButtonLabel", "finish", 4, "ngIf"], [3, "title", "backButton", "ngClass", "finishButtonLabel", "finish"], ["title", "challenges.create.choose_type", 3, "validForNextStep"], [1, "ion-text-center"], [3, "availableModels", "selectedModel"], ["title", "challenges.create.choose_metric", 3, "validForNextStep"], [3, "availableMeans", "selectedMean"], ["title", "challenges.create.choose_partner", 3, "validForNextStep"], [3, "availableChallengeables", "selectedChallengeable"], ["title", "challenges.create.activate", 3, "activated"], [3, "challengeModelName", "pointConcept", "challengeable", "preview"]],
  template: function CreateChallengePage_Template(rf, ctx) {
    if (rf & 1) {
      _angular_core__WEBPACK_IMPORTED_MODULE_11__["ɵɵelement"](0, "ion-header", 0);
      _angular_core__WEBPACK_IMPORTED_MODULE_11__["ɵɵelementStart"](1, "ion-content", 1);
      _angular_core__WEBPACK_IMPORTED_MODULE_11__["ɵɵtemplate"](2, CreateChallengePage_app_wizard_2_Template, 29, 44, "app-wizard", 2);
      _angular_core__WEBPACK_IMPORTED_MODULE_11__["ɵɵpipe"](3, "async");
      _angular_core__WEBPACK_IMPORTED_MODULE_11__["ɵɵelementEnd"]();
    }

    if (rf & 2) {
      _angular_core__WEBPACK_IMPORTED_MODULE_11__["ɵɵadvance"](2);
      _angular_core__WEBPACK_IMPORTED_MODULE_11__["ɵɵproperty"]("ngIf", _angular_core__WEBPACK_IMPORTED_MODULE_11__["ɵɵpipeBind1"](3, 1, ctx.campaign$));
    }
  },
  styles: ["\n/*# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbXSwibmFtZXMiOltdLCJtYXBwaW5ncyI6IiIsImZpbGUiOiJjcmVhdGUtY2hhbGxlbmdlLnBhZ2Uuc2NzcyJ9 */"]
}); // | 'Boat_Km'
// | 'Bus_Km'
// | 'Car_Km'
// | 'Train_Km';

var POINT_CONCEPT_GAME = 'green leaves';
var meanToPointConcept = {
  bike: 'Bike_Km',
  walk: 'Walk_Km',
  boat: null,
  bus: null,
  car: null,
  train: null,
  unknown: null
};

/***/ }),

/***/ 64595:
/*!************************************************************************************************************!*\
  !*** ./src/app/pages/challenges/create-challenge/select-challenge-mean/select-challenge-mean.component.ts ***!
  \************************************************************************************************************/
/***/ (function(__unused_webpack_module, __webpack_exports__, __webpack_require__) {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "SelectChallengeMeanComponent": function() { return /* binding */ SelectChallengeMeanComponent; }
/* harmony export */ });
/* harmony import */ var _Users_smartcommunitylab_Desktop_newWork_dslab_playgo_mobile_playgo_mobile_node_modules_babel_runtime_helpers_esm_classCallCheck_js__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./node_modules/@babel/runtime/helpers/esm/classCallCheck.js */ 78069);
/* harmony import */ var _Users_smartcommunitylab_Desktop_newWork_dslab_playgo_mobile_playgo_mobile_node_modules_babel_runtime_helpers_esm_createClass_js__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ./node_modules/@babel/runtime/helpers/esm/createClass.js */ 48047);
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @angular/core */ 3184);
/* harmony import */ var _angular_common__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! @angular/common */ 36362);
/* harmony import */ var _core_shared_ui_icon_icon_component__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! ../../../../core/shared/ui/icon/icon.component */ 71888);
/* harmony import */ var _ngx_translate_core__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! @ngx-translate/core */ 87514);








function SelectChallengeMeanComponent_div_1_Template(rf, ctx) {
  if (rf & 1) {
    var _r3 = _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵgetCurrentView"]();

    _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵelementStart"](0, "div", 2);
    _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵlistener"]("click", function SelectChallengeMeanComponent_div_1_Template_div_click_0_listener() {
      var restoredCtx = _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵrestoreView"](_r3);
      var mean_r1 = restoredCtx.$implicit;
      var ctx_r2 = _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵnextContext"]();
      return ctx_r2.selectMean(mean_r1);
    });
    _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵpipe"](1, "translate");
    _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵelement"](2, "app-icon", 3);
    _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵelementEnd"]();
  }

  if (rf & 2) {
    var mean_r1 = ctx.$implicit;
    var ctx_r0 = _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵnextContext"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵclassProp"]("selected", mean_r1.name === ctx_r0.selectedMeanName);
    _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵpropertyInterpolate"]("title", _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵpipeBind1"](1, 4, mean_r1.title));
    _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵadvance"](2);
    _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵproperty"]("name", mean_r1.icon);
  }
}

var SelectChallengeMeanComponent = /*#__PURE__*/function () {
  function SelectChallengeMeanComponent() {
    (0,_Users_smartcommunitylab_Desktop_newWork_dslab_playgo_mobile_playgo_mobile_node_modules_babel_runtime_helpers_esm_classCallCheck_js__WEBPACK_IMPORTED_MODULE_0__["default"])(this, SelectChallengeMeanComponent);

    this.selectedMean = new _angular_core__WEBPACK_IMPORTED_MODULE_3__.EventEmitter();
  }

  (0,_Users_smartcommunitylab_Desktop_newWork_dslab_playgo_mobile_playgo_mobile_node_modules_babel_runtime_helpers_esm_createClass_js__WEBPACK_IMPORTED_MODULE_1__["default"])(SelectChallengeMeanComponent, [{
    key: "ngOnInit",
    value: function ngOnInit() {}
  }, {
    key: "selectMean",
    value: function selectMean(model) {
      this.selectedMeanName = model.name;
      this.selectedMean.emit(this.selectedMeanName);
    }
  }]);

  return SelectChallengeMeanComponent;
}();

SelectChallengeMeanComponent.ɵfac = function SelectChallengeMeanComponent_Factory(t) {
  return new (t || SelectChallengeMeanComponent)();
};

SelectChallengeMeanComponent.ɵcmp = /*@__PURE__*/_angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵdefineComponent"]({
  type: SelectChallengeMeanComponent,
  selectors: [["app-select-challenge-mean"]],
  inputs: {
    availableMeans: "availableMeans"
  },
  outputs: {
    selectedMean: "selectedMean"
  },
  decls: 2,
  vars: 1,
  consts: [[1, "wrapper"], ["class", "mean", 3, "selected", "title", "click", 4, "ngFor", "ngForOf"], [1, "mean", 3, "title", "click"], [3, "name"]],
  template: function SelectChallengeMeanComponent_Template(rf, ctx) {
    if (rf & 1) {
      _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵelementStart"](0, "div", 0);
      _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵtemplate"](1, SelectChallengeMeanComponent_div_1_Template, 3, 6, "div", 1);
      _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵelementEnd"]();
    }

    if (rf & 2) {
      _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵadvance"](1);
      _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵproperty"]("ngForOf", ctx.availableMeans);
    }
  },
  directives: [_angular_common__WEBPACK_IMPORTED_MODULE_4__.NgForOf, _core_shared_ui_icon_icon_component__WEBPACK_IMPORTED_MODULE_2__.IconComponent],
  pipes: [_ngx_translate_core__WEBPACK_IMPORTED_MODULE_5__.TranslatePipe],
  styles: [".wrapper[_ngcontent-%COMP%] {\n  display: grid;\n  grid-template-columns: repeat(3, 1fr);\n  grid-column-gap: 10px;\n  grid-row-gap: 10px;\n}\n\n.mean[_ngcontent-%COMP%] {\n  aspect-ratio: 1/1;\n  border: 2px solid var(--ion-color-base);\n  background-color: var(--ion-color-lighter);\n  border-radius: 10px;\n  display: flex;\n  align-items: center;\n  justify-content: center;\n  background-color: #f2f6fa;\n}\n\n.mean.disabled[_ngcontent-%COMP%] {\n  border-color: gray;\n  background-color: lightgray;\n}\n\n.mean.selected[_ngcontent-%COMP%] {\n  border-width: 4px;\n  background-color: #fdfdaa;\n}\n\n.mean[_ngcontent-%COMP%]   app-icon[_ngcontent-%COMP%] {\n  font-size: 56px;\n  line-height: 100%;\n}\n/*# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbInNlbGVjdC1jaGFsbGVuZ2UtbWVhbi5jb21wb25lbnQuc2NzcyJdLCJuYW1lcyI6W10sIm1hcHBpbmdzIjoiQUFBQTtFQUNFLGFBQUE7RUFDQSxxQ0FBQTtFQUNBLHFCQUFBO0VBQ0Esa0JBQUE7QUFDRjs7QUFDQTtFQUNFLGlCQUFBO0VBQ0EsdUNBQUE7RUFDQSwwQ0FBQTtFQUNBLG1CQUFBO0VBRUEsYUFBQTtFQUNBLG1CQUFBO0VBQ0EsdUJBQUE7RUFDQSx5QkFBQTtBQUNGOztBQUVFO0VBQ0Usa0JBQUE7RUFDQSwyQkFBQTtBQUFKOztBQUVFO0VBQ0UsaUJBQUE7RUFDQSx5QkFBQTtBQUFKOztBQUVFO0VBQ0UsZUFBQTtFQUVBLGlCQUFBO0FBREoiLCJmaWxlIjoic2VsZWN0LWNoYWxsZW5nZS1tZWFuLmNvbXBvbmVudC5zY3NzIiwic291cmNlc0NvbnRlbnQiOlsiLndyYXBwZXIge1xuICBkaXNwbGF5OiBncmlkO1xuICBncmlkLXRlbXBsYXRlLWNvbHVtbnM6IHJlcGVhdCgzLCAxZnIpO1xuICBncmlkLWNvbHVtbi1nYXA6IDEwcHg7XG4gIGdyaWQtcm93LWdhcDogMTBweDtcbn1cbi5tZWFuIHtcbiAgYXNwZWN0LXJhdGlvOiAxLzE7XG4gIGJvcmRlcjogMnB4IHNvbGlkIHZhcigtLWlvbi1jb2xvci1iYXNlKTtcbiAgYmFja2dyb3VuZC1jb2xvcjogdmFyKC0taW9uLWNvbG9yLWxpZ2h0ZXIpO1xuICBib3JkZXItcmFkaXVzOiAxMHB4O1xuXG4gIGRpc3BsYXk6IGZsZXg7XG4gIGFsaWduLWl0ZW1zOiBjZW50ZXI7XG4gIGp1c3RpZnktY29udGVudDogY2VudGVyO1xuICBiYWNrZ3JvdW5kLWNvbG9yOiAjZjJmNmZhO1xuXG4gIC8vIG1hcmdpbjogMTBweDtcbiAgJi5kaXNhYmxlZCB7XG4gICAgYm9yZGVyLWNvbG9yOiBncmF5O1xuICAgIGJhY2tncm91bmQtY29sb3I6IGxpZ2h0Z3JheTtcbiAgfVxuICAmLnNlbGVjdGVkIHtcbiAgICBib3JkZXItd2lkdGg6IDRweDtcbiAgICBiYWNrZ3JvdW5kLWNvbG9yOiAjZmRmZGFhO1xuICB9XG4gIGFwcC1pY29uIHtcbiAgICBmb250LXNpemU6IDU2cHg7XG4gICAgLy8gb3V0bGluZTogMXB4IHNvbGlkIHJlZDtcbiAgICBsaW5lLWhlaWdodDogMTAwJTtcbiAgfVxufVxuIl19 */"]
});

/***/ }),

/***/ 7776:
/*!**************************************************************************************************************!*\
  !*** ./src/app/pages/challenges/create-challenge/select-challenge-model/select-challenge-model.component.ts ***!
  \**************************************************************************************************************/
/***/ (function(__unused_webpack_module, __webpack_exports__, __webpack_require__) {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "SelectChallengeModelComponent": function() { return /* binding */ SelectChallengeModelComponent; }
/* harmony export */ });
/* harmony import */ var _Users_smartcommunitylab_Desktop_newWork_dslab_playgo_mobile_playgo_mobile_node_modules_babel_runtime_helpers_esm_classCallCheck_js__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./node_modules/@babel/runtime/helpers/esm/classCallCheck.js */ 78069);
/* harmony import */ var _Users_smartcommunitylab_Desktop_newWork_dslab_playgo_mobile_playgo_mobile_node_modules_babel_runtime_helpers_esm_createClass_js__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ./node_modules/@babel/runtime/helpers/esm/createClass.js */ 48047);
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @angular/core */ 3184);
/* harmony import */ var _ionic_angular__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! @ionic/angular */ 93819);
/* harmony import */ var _angular_common__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! @angular/common */ 36362);
/* harmony import */ var _core_shared_ui_icon_icon_component__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! ../../../../core/shared/ui/icon/icon.component */ 71888);
/* harmony import */ var _ngx_translate_core__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! @ngx-translate/core */ 87514);









function SelectChallengeModelComponent_ion_col_2_div_5_Template(rf, ctx) {
  if (rf & 1) {
    _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵelementStart"](0, "div")(1, "div");
    _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵelement"](2, "app-icon", 6);
    _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵelementEnd"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵelementStart"](3, "div", 7);
    _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵtext"](4);
    _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵpipe"](5, "translate");
    _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵelementEnd"]()();
  }

  if (rf & 2) {
    var eachModel_r1 = _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵnextContext"]().$implicit;
    _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵadvance"](2);
    _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵproperty"]("name", eachModel_r1.challengeModelName);
    _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵadvance"](2);
    _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵtextInterpolate1"](" ", _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵpipeBind1"](5, 2, "challenges.challenge_model.description." + eachModel_r1.challengeModelName), " ");
  }
}

var _c0 = function _c0(a0) {
  return {
    level: a0
  };
};

function SelectChallengeModelComponent_ion_col_2_div_6_Template(rf, ctx) {
  if (rf & 1) {
    _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵelementStart"](0, "div")(1, "div");
    _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵelement"](2, "app-icon", 8);
    _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵelementEnd"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵelementStart"](3, "div");
    _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵtext"](4);
    _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵpipe"](5, "translate");
    _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵelementEnd"]()();
  }

  if (rf & 2) {
    var eachModel_r1 = _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵnextContext"]().$implicit;
    _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵadvance"](4);
    _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵtextInterpolate1"](" ", _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵpipeBind2"](5, 1, "challenges.challenge_model.disabled_until_level", _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵpureFunction1"](4, _c0, eachModel_r1.availableFromLevel)), " ");
  }
}

function SelectChallengeModelComponent_ion_col_2_Template(rf, ctx) {
  if (rf & 1) {
    var _r7 = _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵgetCurrentView"]();

    _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵelementStart"](0, "ion-col", 2)(1, "div", 3);
    _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵlistener"]("click", function SelectChallengeModelComponent_ion_col_2_Template_div_click_1_listener() {
      var restoredCtx = _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵrestoreView"](_r7);
      var eachModel_r1 = restoredCtx.$implicit;
      var ctx_r6 = _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵnextContext"]();
      return ctx_r6.selectModel(eachModel_r1);
    });
    _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵelementStart"](2, "div", 4);
    _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵtext"](3);
    _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵpipe"](4, "translate");
    _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵelementEnd"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵtemplate"](5, SelectChallengeModelComponent_ion_col_2_div_5_Template, 6, 4, "div", 5);
    _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵtemplate"](6, SelectChallengeModelComponent_ion_col_2_div_6_Template, 6, 6, "div", 5);
    _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵelementEnd"]()();
  }

  if (rf & 2) {
    var eachModel_r1 = ctx.$implicit;
    var ctx_r0 = _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵnextContext"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵadvance"](1);
    _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵclassProp"]("disabled", !eachModel_r1.available)("selected", eachModel_r1.challengeModelName === ctx_r0.selectedModelName);
    _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵadvance"](2);
    _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵtextInterpolate1"](" ", _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵpipeBind1"](4, 7, "challenges.challenge_model.name." + eachModel_r1.challengeModelName), " ");
    _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵadvance"](2);
    _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵproperty"]("ngIf", eachModel_r1.available);
    _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵadvance"](1);
    _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵproperty"]("ngIf", !eachModel_r1.available);
  }
}

var SelectChallengeModelComponent = /*#__PURE__*/function () {
  function SelectChallengeModelComponent() {
    (0,_Users_smartcommunitylab_Desktop_newWork_dslab_playgo_mobile_playgo_mobile_node_modules_babel_runtime_helpers_esm_classCallCheck_js__WEBPACK_IMPORTED_MODULE_0__["default"])(this, SelectChallengeModelComponent);

    this.selectedModel = new _angular_core__WEBPACK_IMPORTED_MODULE_3__.EventEmitter();
  }

  (0,_Users_smartcommunitylab_Desktop_newWork_dslab_playgo_mobile_playgo_mobile_node_modules_babel_runtime_helpers_esm_createClass_js__WEBPACK_IMPORTED_MODULE_1__["default"])(SelectChallengeModelComponent, [{
    key: "ngOnInit",
    value: function ngOnInit() {}
  }, {
    key: "selectModel",
    value: function selectModel(model) {
      if (model.available) {
        this.selectedModelName = model.challengeModelName;
        this.selectedModel.emit(this.selectedModelName);
      }
    }
  }]);

  return SelectChallengeModelComponent;
}();

SelectChallengeModelComponent.ɵfac = function SelectChallengeModelComponent_Factory(t) {
  return new (t || SelectChallengeModelComponent)();
};

SelectChallengeModelComponent.ɵcmp = /*@__PURE__*/_angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵdefineComponent"]({
  type: SelectChallengeModelComponent,
  selectors: [["app-select-challenge-model"]],
  inputs: {
    availableModels: "availableModels"
  },
  outputs: {
    selectedModel: "selectedModel"
  },
  decls: 3,
  vars: 1,
  consts: [[1, "wrapper"], ["size", "6", "class", "ion-text-center", 4, "ngFor", "ngForOf"], ["size", "6", 1, "ion-text-center"], [1, "model", 3, "click"], [1, "text-bold"], [4, "ngIf"], [3, "name"], [1, "description"], ["name", "lock"]],
  template: function SelectChallengeModelComponent_Template(rf, ctx) {
    if (rf & 1) {
      _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵelementStart"](0, "ion-grid", 0)(1, "ion-row");
      _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵtemplate"](2, SelectChallengeModelComponent_ion_col_2_Template, 7, 9, "ion-col", 1);
      _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵelementEnd"]()();
    }

    if (rf & 2) {
      _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵadvance"](2);
      _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵproperty"]("ngForOf", ctx.availableModels);
    }
  },
  directives: [_ionic_angular__WEBPACK_IMPORTED_MODULE_4__.IonGrid, _ionic_angular__WEBPACK_IMPORTED_MODULE_4__.IonRow, _angular_common__WEBPACK_IMPORTED_MODULE_5__.NgForOf, _ionic_angular__WEBPACK_IMPORTED_MODULE_4__.IonCol, _angular_common__WEBPACK_IMPORTED_MODULE_5__.NgIf, _core_shared_ui_icon_icon_component__WEBPACK_IMPORTED_MODULE_2__.IconComponent],
  pipes: [_ngx_translate_core__WEBPACK_IMPORTED_MODULE_6__.TranslatePipe],
  styles: [".model[_ngcontent-%COMP%] {\n  border: 2px solid var(--ion-color-base);\n  background-color: var(--ion-color-lighter);\n  border-radius: 10px;\n  margin: 10px;\n  padding: 4px;\n  background-color: #f2f6fa;\n  height: 100%;\n}\n.model[_ngcontent-%COMP%]   .description[_ngcontent-%COMP%] {\n  font-size: 13px;\n  font-style: italic;\n}\n.model.disabled[_ngcontent-%COMP%] {\n  border-color: gray;\n  background-color: lightgray;\n}\n.model.selected[_ngcontent-%COMP%] {\n  border-width: 4px;\n  padding: 2px;\n  background-color: #fdfdaa;\n}\n.model[_ngcontent-%COMP%]   app-icon[_ngcontent-%COMP%] {\n  font-size: 32px;\n}\n/*# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbInNlbGVjdC1jaGFsbGVuZ2UtbW9kZWwuY29tcG9uZW50LnNjc3MiXSwibmFtZXMiOltdLCJtYXBwaW5ncyI6IkFBQUE7RUFDRSx1Q0FBQTtFQUNBLDBDQUFBO0VBQ0EsbUJBQUE7RUFDQSxZQUFBO0VBQ0EsWUFBQTtFQUNBLHlCQUFBO0VBQ0EsWUFBQTtBQUNGO0FBQUU7RUFDRSxlQUFBO0VBQ0Esa0JBQUE7QUFFSjtBQUFFO0VBQ0Usa0JBQUE7RUFDQSwyQkFBQTtBQUVKO0FBQUU7RUFDRSxpQkFBQTtFQUNBLFlBQUE7RUFDQSx5QkFBQTtBQUVKO0FBQUU7RUFDRSxlQUFBO0FBRUoiLCJmaWxlIjoic2VsZWN0LWNoYWxsZW5nZS1tb2RlbC5jb21wb25lbnQuc2NzcyIsInNvdXJjZXNDb250ZW50IjpbIi5tb2RlbCB7XG4gIGJvcmRlcjogMnB4IHNvbGlkIHZhcigtLWlvbi1jb2xvci1iYXNlKTtcbiAgYmFja2dyb3VuZC1jb2xvcjogdmFyKC0taW9uLWNvbG9yLWxpZ2h0ZXIpO1xuICBib3JkZXItcmFkaXVzOiAxMHB4O1xuICBtYXJnaW46IDEwcHg7XG4gIHBhZGRpbmc6IDRweDtcbiAgYmFja2dyb3VuZC1jb2xvcjogI2YyZjZmYTtcbiAgaGVpZ2h0OiAxMDAlO1xuICAuZGVzY3JpcHRpb24ge1xuICAgIGZvbnQtc2l6ZTogMTNweDtcbiAgICBmb250LXN0eWxlOiBpdGFsaWM7XG4gIH1cbiAgJi5kaXNhYmxlZCB7XG4gICAgYm9yZGVyLWNvbG9yOiBncmF5O1xuICAgIGJhY2tncm91bmQtY29sb3I6IGxpZ2h0Z3JheTtcbiAgfVxuICAmLnNlbGVjdGVkIHtcbiAgICBib3JkZXItd2lkdGg6IDRweDtcbiAgICBwYWRkaW5nOiAycHg7XG4gICAgYmFja2dyb3VuZC1jb2xvcjogI2ZkZmRhYTtcbiAgfVxuICBhcHAtaWNvbiB7XG4gICAgZm9udC1zaXplOiAzMnB4O1xuICB9XG59XG4iXX0= */"]
});

/***/ }),

/***/ 56747:
/*!**********************************************************************************************************!*\
  !*** ./src/app/pages/challenges/create-challenge/select-challengeable/select-challengeable.component.ts ***!
  \**********************************************************************************************************/
/***/ (function(__unused_webpack_module, __webpack_exports__, __webpack_require__) {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "SelectChallengeableComponent": function() { return /* binding */ SelectChallengeableComponent; }
/* harmony export */ });
/* harmony import */ var _Users_smartcommunitylab_Desktop_newWork_dslab_playgo_mobile_playgo_mobile_node_modules_babel_runtime_helpers_esm_classCallCheck_js__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./node_modules/@babel/runtime/helpers/esm/classCallCheck.js */ 78069);
/* harmony import */ var _Users_smartcommunitylab_Desktop_newWork_dslab_playgo_mobile_playgo_mobile_node_modules_babel_runtime_helpers_esm_createClass_js__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ./node_modules/@babel/runtime/helpers/esm/createClass.js */ 48047);
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @angular/core */ 3184);
/* harmony import */ var _ionic_angular__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! @ionic/angular */ 93819);
/* harmony import */ var _angular_forms__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! @angular/forms */ 90587);
/* harmony import */ var _angular_common__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! @angular/common */ 36362);
/* harmony import */ var _core_shared_pipes_filter_pipe__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! ../../../../core/shared/pipes/filter.pipe */ 57760);









function SelectChallengeableComponent_ion_item_1_ion_icon_5_Template(rf, ctx) {
  if (rf & 1) {
    _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵelement"](0, "ion-icon", 5);
  }
}

function SelectChallengeableComponent_ion_item_1_Template(rf, ctx) {
  if (rf & 1) {
    var _r4 = _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵgetCurrentView"]();

    _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵelementStart"](0, "ion-item", 2);
    _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵlistener"]("click", function SelectChallengeableComponent_ion_item_1_Template_ion_item_click_0_listener() {
      var restoredCtx = _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵrestoreView"](_r4);
      var user_r1 = restoredCtx.$implicit;
      var ctx_r3 = _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵnextContext"]();
      return ctx_r3.selectChallengeable(user_r1);
    });
    _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵelementStart"](1, "ion-avatar");
    _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵelement"](2, "img", 3);
    _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵelementEnd"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵelementStart"](3, "ion-label");
    _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵtext"](4);
    _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵelementEnd"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵtemplate"](5, SelectChallengeableComponent_ion_item_1_ion_icon_5_Template, 1, 0, "ion-icon", 4);
    _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵelementEnd"]();
  }

  if (rf & 2) {
    var user_r1 = ctx.$implicit;
    var ctx_r0 = _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵnextContext"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵclassProp"]("selected", user_r1.id === ctx_r0.selectedChallengeableId);
    _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵadvance"](2);
    _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵproperty"]("src", user_r1.avatarUrl, _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵsanitizeUrl"]);
    _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵadvance"](2);
    _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵtextInterpolate1"](" ", user_r1.nickname, " ");
    _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵadvance"](1);
    _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵproperty"]("ngIf", user_r1.id === ctx_r0.selectedChallengeableId);
  }
}

var _c0 = function _c0() {
  return ["nickname"];
};

var SelectChallengeableComponent = /*#__PURE__*/function () {
  function SelectChallengeableComponent() {
    (0,_Users_smartcommunitylab_Desktop_newWork_dslab_playgo_mobile_playgo_mobile_node_modules_babel_runtime_helpers_esm_classCallCheck_js__WEBPACK_IMPORTED_MODULE_0__["default"])(this, SelectChallengeableComponent);

    this.selectedChallengeable = new _angular_core__WEBPACK_IMPORTED_MODULE_3__.EventEmitter();
  }

  (0,_Users_smartcommunitylab_Desktop_newWork_dslab_playgo_mobile_playgo_mobile_node_modules_babel_runtime_helpers_esm_createClass_js__WEBPACK_IMPORTED_MODULE_1__["default"])(SelectChallengeableComponent, [{
    key: "selectChallengeable",
    value: function selectChallengeable(challengeable) {
      this.selectedChallengeableId = challengeable.id;
      this.selectedChallengeable.emit(this.selectedChallengeableId);
    }
  }]);

  return SelectChallengeableComponent;
}();

SelectChallengeableComponent.ɵfac = function SelectChallengeableComponent_Factory(t) {
  return new (t || SelectChallengeableComponent)();
};

SelectChallengeableComponent.ɵcmp = /*@__PURE__*/_angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵdefineComponent"]({
  type: SelectChallengeableComponent,
  selectors: [["app-select-challengeable"]],
  inputs: {
    availableChallengeables: "availableChallengeables"
  },
  outputs: {
    selectedChallengeable: "selectedChallengeable"
  },
  decls: 3,
  vars: 7,
  consts: [["color", "light", "mode", "ios", "placeholder", "nome utente", 1, "ion-no-padding", 3, "ngModel", "ngModelChange"], ["class", "user", 3, "selected", "click", 4, "ngFor", "ngForOf"], [1, "user", 3, "click"], [3, "src"], ["color", "success", "name", "checkmark", 4, "ngIf"], ["color", "success", "name", "checkmark"]],
  template: function SelectChallengeableComponent_Template(rf, ctx) {
    if (rf & 1) {
      _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵelementStart"](0, "ion-searchbar", 0);
      _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵlistener"]("ngModelChange", function SelectChallengeableComponent_Template_ion_searchbar_ngModelChange_0_listener($event) {
        return ctx.searchData = $event;
      });
      _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵelementEnd"]();
      _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵtemplate"](1, SelectChallengeableComponent_ion_item_1_Template, 6, 5, "ion-item", 1);
      _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵpipe"](2, "filterData");
    }

    if (rf & 2) {
      _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵproperty"]("ngModel", ctx.searchData);
      _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵadvance"](1);
      _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵproperty"]("ngForOf", _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵpipeBind3"](2, 2, ctx.availableChallengeables, _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵpureFunction0"](6, _c0), ctx.searchData));
    }
  },
  directives: [_ionic_angular__WEBPACK_IMPORTED_MODULE_4__.IonSearchbar, _ionic_angular__WEBPACK_IMPORTED_MODULE_4__.TextValueAccessor, _angular_forms__WEBPACK_IMPORTED_MODULE_5__.NgControlStatus, _angular_forms__WEBPACK_IMPORTED_MODULE_5__.NgModel, _angular_common__WEBPACK_IMPORTED_MODULE_6__.NgForOf, _ionic_angular__WEBPACK_IMPORTED_MODULE_4__.IonItem, _ionic_angular__WEBPACK_IMPORTED_MODULE_4__.IonAvatar, _ionic_angular__WEBPACK_IMPORTED_MODULE_4__.IonLabel, _angular_common__WEBPACK_IMPORTED_MODULE_6__.NgIf, _ionic_angular__WEBPACK_IMPORTED_MODULE_4__.IonIcon],
  pipes: [_core_shared_pipes_filter_pipe__WEBPACK_IMPORTED_MODULE_2__.FilterPipe],
  styles: [".user.selected[_ngcontent-%COMP%] {\n  --border-color: var(--ion-color-base);\n  border: 2px solid var(--ion-color-base);\n}\n.user[_ngcontent-%COMP%]   ion-label[_ngcontent-%COMP%] {\n  margin-left: 17px;\n}\n/*# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbInNlbGVjdC1jaGFsbGVuZ2VhYmxlLmNvbXBvbmVudC5zY3NzIl0sIm5hbWVzIjpbXSwibWFwcGluZ3MiOiJBQUNFO0VBQ0UscUNBQUE7RUFDQSx1Q0FBQTtBQUFKO0FBRUU7RUFDRSxpQkFBQTtBQUFKIiwiZmlsZSI6InNlbGVjdC1jaGFsbGVuZ2VhYmxlLmNvbXBvbmVudC5zY3NzIiwic291cmNlc0NvbnRlbnQiOlsiLnVzZXIge1xuICAmLnNlbGVjdGVkIHtcbiAgICAtLWJvcmRlci1jb2xvcjogdmFyKC0taW9uLWNvbG9yLWJhc2UpO1xuICAgIGJvcmRlcjogMnB4IHNvbGlkIHZhcigtLWlvbi1jb2xvci1iYXNlKTtcbiAgfVxuICBpb24tbGFiZWwge1xuICAgIG1hcmdpbi1sZWZ0OiAxN3B4O1xuICB9XG59XG4iXX0= */"]
});

/***/ }),

/***/ 68774:
/*!***********************************************************************************************!*\
  !*** ./src/app/pages/challenges/create-challenge/wizard/wizard-step/wizard-step.component.ts ***!
  \***********************************************************************************************/
/***/ (function(__unused_webpack_module, __webpack_exports__, __webpack_require__) {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "WizardStepComponent": function() { return /* binding */ WizardStepComponent; }
/* harmony export */ });
/* harmony import */ var _Users_smartcommunitylab_Desktop_newWork_dslab_playgo_mobile_playgo_mobile_node_modules_babel_runtime_helpers_esm_createClass_js__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./node_modules/@babel/runtime/helpers/esm/createClass.js */ 48047);
/* harmony import */ var _Users_smartcommunitylab_Desktop_newWork_dslab_playgo_mobile_playgo_mobile_node_modules_babel_runtime_helpers_esm_classCallCheck_js__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ./node_modules/@babel/runtime/helpers/esm/classCallCheck.js */ 78069);
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @angular/core */ 3184);




var _c0 = ["template"];

function WizardStepComponent_ng_template_0_Template(rf, ctx) {
  if (rf & 1) {
    _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵprojection"](0);
  }
}

var _c1 = ["*"];
var WizardStepComponent = /*#__PURE__*/(0,_Users_smartcommunitylab_Desktop_newWork_dslab_playgo_mobile_playgo_mobile_node_modules_babel_runtime_helpers_esm_createClass_js__WEBPACK_IMPORTED_MODULE_0__["default"])(function WizardStepComponent() {
  (0,_Users_smartcommunitylab_Desktop_newWork_dslab_playgo_mobile_playgo_mobile_node_modules_babel_runtime_helpers_esm_classCallCheck_js__WEBPACK_IMPORTED_MODULE_1__["default"])(this, WizardStepComponent);

  this.validForNextStep = true;
  this.activated = new _angular_core__WEBPACK_IMPORTED_MODULE_2__.EventEmitter();
});

WizardStepComponent.ɵfac = function WizardStepComponent_Factory(t) {
  return new (t || WizardStepComponent)();
};

WizardStepComponent.ɵcmp = /*@__PURE__*/_angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵdefineComponent"]({
  type: WizardStepComponent,
  selectors: [["app-wizard-step"]],
  viewQuery: function WizardStepComponent_Query(rf, ctx) {
    if (rf & 1) {
      _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵviewQuery"](_c0, 7, _angular_core__WEBPACK_IMPORTED_MODULE_2__.TemplateRef);
    }

    if (rf & 2) {
      var _t;

      _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵqueryRefresh"](_t = _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵloadQuery"]()) && (ctx.template = _t.first);
    }
  },
  inputs: {
    title: "title",
    validForNextStep: "validForNextStep"
  },
  outputs: {
    activated: "activated"
  },
  ngContentSelectors: _c1,
  decls: 2,
  vars: 0,
  consts: [["template", ""]],
  template: function WizardStepComponent_Template(rf, ctx) {
    if (rf & 1) {
      _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵprojectionDef"]();
      _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵtemplate"](0, WizardStepComponent_ng_template_0_Template, 1, 0, "ng-template", null, 0, _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵtemplateRefExtractor"]);
    }
  },
  styles: ["\n/*# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbXSwibmFtZXMiOltdLCJtYXBwaW5ncyI6IiIsImZpbGUiOiJ3aXphcmQtc3RlcC5jb21wb25lbnQuc2NzcyJ9 */"]
});

/***/ }),

/***/ 1359:
/*!******************************************************************************!*\
  !*** ./src/app/pages/challenges/create-challenge/wizard/wizard.component.ts ***!
  \******************************************************************************/
/***/ (function(__unused_webpack_module, __webpack_exports__, __webpack_require__) {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "WizardComponent": function() { return /* binding */ WizardComponent; }
/* harmony export */ });
/* harmony import */ var _Users_smartcommunitylab_Desktop_newWork_dslab_playgo_mobile_playgo_mobile_node_modules_babel_runtime_helpers_esm_classCallCheck_js__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./node_modules/@babel/runtime/helpers/esm/classCallCheck.js */ 78069);
/* harmony import */ var _Users_smartcommunitylab_Desktop_newWork_dslab_playgo_mobile_playgo_mobile_node_modules_babel_runtime_helpers_esm_createClass_js__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ./node_modules/@babel/runtime/helpers/esm/createClass.js */ 48047);
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @angular/core */ 3184);
/* harmony import */ var _wizard_step_wizard_step_component__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! ./wizard-step/wizard-step.component */ 68774);
/* harmony import */ var _ionic_angular__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! @ionic/angular */ 93819);
/* harmony import */ var _angular_common__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! @angular/common */ 36362);
/* harmony import */ var _ngx_translate_core__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! @ngx-translate/core */ 87514);









function WizardComponent_div_4_Template(rf, ctx) {
  if (rf & 1) {
    _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵelementStart"](0, "div", 10);
    _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵtext"](1);
    _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵelementEnd"]();
  }

  if (rf & 2) {
    var ctx_r0 = _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵnextContext"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵadvance"](1);
    _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵtextInterpolate1"](" ", ctx_r0.title, " ");
  }
}

function WizardComponent_div_5_Template(rf, ctx) {
  if (rf & 1) {
    _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵelementStart"](0, "div", 11);
    _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵtext"](1);
    _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵpipe"](2, "translate");
    _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵelementEnd"]();
  }

  if (rf & 2) {
    var ctx_r1 = _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵnextContext"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵadvance"](1);
    _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵtextInterpolate1"](" ", _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵpipeBind1"](2, 1, ctx_r1.selectedStep.title), " ");
  }
}

function WizardComponent_ng_container_8_Template(rf, ctx) {
  if (rf & 1) {
    var _r9 = _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵgetCurrentView"]();

    _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵelementContainerStart"](0);
    _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵelement"](1, "div", 12);
    _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵelementStart"](2, "div", 13);
    _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵlistener"]("click", function WizardComponent_ng_container_8_Template_div_click_2_listener() {
      var restoredCtx = _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵrestoreView"](_r9);
      var currentStepIndex_r7 = restoredCtx.index;
      var ctx_r8 = _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵnextContext"]();
      return ctx_r8.changeStep(currentStepIndex_r7);
    });
    _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵtext"](3);
    _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵelementEnd"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵelementContainerEnd"]();
  }

  if (rf & 2) {
    var currentStepIndex_r7 = ctx.index;
    var ctx_r2 = _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵnextContext"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵadvance"](1);
    _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵclassProp"]("first-step", currentStepIndex_r7 === 0);
    _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵadvance"](1);
    _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵclassProp"]("previous", currentStepIndex_r7 < ctx_r2.selectedStepIndex)("step-current", currentStepIndex_r7 === ctx_r2.selectedStepIndex)("last-step", currentStepIndex_r7 === ctx_r2.steps.length - 1);
    _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵadvance"](1);
    _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵtextInterpolate1"](" ", currentStepIndex_r7 + 1, " ");
  }
}

function WizardComponent_ion_button_12_Template(rf, ctx) {
  if (rf & 1) {
    var _r11 = _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵgetCurrentView"]();

    _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵelementStart"](0, "ion-button", 14);
    _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵlistener"]("click", function WizardComponent_ion_button_12_Template_ion_button_click_0_listener() {
      _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵrestoreView"](_r11);
      var ctx_r10 = _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵnextContext"]();
      return ctx_r10.changeStep(ctx_r10.selectedStepIndex - 1);
    });
    _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵtext"](1);
    _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵpipe"](2, "translate");
    _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵelementEnd"]();
  }

  if (rf & 2) {
    var ctx_r3 = _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵnextContext"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵproperty"]("disabled", ctx_r3.selectedStepIndex === 0);
    _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵadvance"](1);
    _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵtextInterpolate1"](" ", _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵpipeBind1"](2, 2, "wizard.back"), " ");
  }
}

function WizardComponent_ion_button_13_Template(rf, ctx) {
  if (rf & 1) {
    var _r13 = _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵgetCurrentView"]();

    _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵelementStart"](0, "ion-button", 14);
    _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵlistener"]("click", function WizardComponent_ion_button_13_Template_ion_button_click_0_listener() {
      _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵrestoreView"](_r13);
      var ctx_r12 = _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵnextContext"]();
      return ctx_r12.changeStep(ctx_r12.selectedStepIndex + 1);
    });
    _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵtext"](1);
    _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵpipe"](2, "translate");
    _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵelementEnd"]();
  }

  if (rf & 2) {
    var ctx_r4 = _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵnextContext"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵproperty"]("disabled", ctx_r4.selectedStep.validForNextStep !== true);
    _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵadvance"](1);
    _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵtextInterpolate1"](" ", _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵpipeBind1"](2, 2, "wizard.next"), " ");
  }
}

function WizardComponent_ion_button_14_Template(rf, ctx) {
  if (rf & 1) {
    var _r15 = _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵgetCurrentView"]();

    _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵelementStart"](0, "ion-button", 14);
    _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵlistener"]("click", function WizardComponent_ion_button_14_Template_ion_button_click_0_listener() {
      _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵrestoreView"](_r15);
      var ctx_r14 = _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵnextContext"]();
      return ctx_r14.finish.emit();
    });
    _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵtext"](1);
    _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵelementEnd"]();
  }

  if (rf & 2) {
    var ctx_r5 = _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵnextContext"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵproperty"]("disabled", ctx_r5.selectedStep.validForNextStep !== true);
    _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵadvance"](1);
    _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵtextInterpolate1"](" ", ctx_r5.finishButtonLabel, " ");
  }
}

var WizardComponent = /*#__PURE__*/function () {
  function WizardComponent() {
    (0,_Users_smartcommunitylab_Desktop_newWork_dslab_playgo_mobile_playgo_mobile_node_modules_babel_runtime_helpers_esm_classCallCheck_js__WEBPACK_IMPORTED_MODULE_0__["default"])(this, WizardComponent);

    this.title = '';
    this.backButton = true;
    this.finishButtonLabel = '';
    this.finish = new _angular_core__WEBPACK_IMPORTED_MODULE_3__.EventEmitter();
    this.steps = [];
    this.templates = [];
    this.selectedStepIndex = 0;
  }

  (0,_Users_smartcommunitylab_Desktop_newWork_dslab_playgo_mobile_playgo_mobile_node_modules_babel_runtime_helpers_esm_createClass_js__WEBPACK_IMPORTED_MODULE_1__["default"])(WizardComponent, [{
    key: "stepComponents",
    set: function set(stepComponents) {
      this.steps = stepComponents.toArray();
      this.templates = stepComponents.map(function (eachComponent) {
        return eachComponent.template;
      });
      this.changeStep(0);
    }
  }, {
    key: "ngAfterContentInit",
    value: function ngAfterContentInit() {}
  }, {
    key: "isStepValid",
    value: function isStepValid(newStepIdx) {
      if (newStepIdx === 0) {
        return true;
      }

      var previousStepIdx = Math.max(newStepIdx - 1, 0);
      var previousStep = this.steps[previousStepIdx];
      return previousStep.validForNextStep !== false;
    }
  }, {
    key: "changeStep",
    value: function changeStep(newStepIdx) {
      if (!this.isStepValid(newStepIdx)) {
        return;
      }

      this.selectedStepIndex = newStepIdx;
      this.selectedStep = this.steps[this.selectedStepIndex];
      this.selectedStep.activated.next();
    }
  }, {
    key: "ngOnInit",
    value: function ngOnInit() {}
  }]);

  return WizardComponent;
}();

WizardComponent.ɵfac = function WizardComponent_Factory(t) {
  return new (t || WizardComponent)();
};

WizardComponent.ɵcmp = /*@__PURE__*/_angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵdefineComponent"]({
  type: WizardComponent,
  selectors: [["app-wizard"]],
  contentQueries: function WizardComponent_ContentQueries(rf, ctx, dirIndex) {
    if (rf & 1) {
      _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵcontentQuery"](dirIndex, _wizard_step_wizard_step_component__WEBPACK_IMPORTED_MODULE_2__.WizardStepComponent, 4);
    }

    if (rf & 2) {
      var _t;

      _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵqueryRefresh"](_t = _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵloadQuery"]()) && (ctx.stepComponents = _t);
    }
  },
  inputs: {
    title: "title",
    backButton: "backButton",
    finishButtonLabel: "finishButtonLabel"
  },
  outputs: {
    finish: "finish"
  },
  decls: 15,
  vars: 7,
  consts: [[1, "wrapper"], ["color", "base", 1, "title-header"], ["class", "ion-text-start", 4, "ngIf"], ["class", "ion-text-end", 4, "ngIf"], [1, "form-steps-container"], [4, "ngFor", "ngForOf"], [1, "step-content-wrapper"], [3, "ngTemplateOutlet"], [1, "ion-justify-content-around", 2, "display", "flex"], ["color", "base", 3, "disabled", "click", 4, "ngIf"], [1, "ion-text-start"], [1, "ion-text-end"], [1, "step-divider"], [1, "step-bubble", 3, "click"], ["color", "base", 3, "disabled", "click"]],
  template: function WizardComponent_Template(rf, ctx) {
    if (rf & 1) {
      _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵelementStart"](0, "div", 0)(1, "ion-card")(2, "ion-card-header", 1)(3, "ion-card-title");
      _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵtemplate"](4, WizardComponent_div_4_Template, 2, 1, "div", 2);
      _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵtemplate"](5, WizardComponent_div_5_Template, 3, 3, "div", 3);
      _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵelementEnd"]()();
      _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵelementStart"](6, "ion-card-content")(7, "div", 4);
      _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵtemplate"](8, WizardComponent_ng_container_8_Template, 4, 9, "ng-container", 5);
      _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵelementEnd"]();
      _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵelementStart"](9, "div", 6);
      _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵelementContainer"](10, 7);
      _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵelementEnd"]();
      _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵelementStart"](11, "div", 8);
      _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵtemplate"](12, WizardComponent_ion_button_12_Template, 3, 4, "ion-button", 9);
      _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵtemplate"](13, WizardComponent_ion_button_13_Template, 3, 4, "ion-button", 9);
      _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵtemplate"](14, WizardComponent_ion_button_14_Template, 2, 2, "ion-button", 9);
      _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵelementEnd"]()()()();
    }

    if (rf & 2) {
      _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵadvance"](4);
      _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵproperty"]("ngIf", ctx.title);
      _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵadvance"](1);
      _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵproperty"]("ngIf", ctx.selectedStep.title);
      _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵadvance"](3);
      _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵproperty"]("ngForOf", ctx.steps);
      _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵadvance"](2);
      _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵproperty"]("ngTemplateOutlet", ctx.templates[ctx.selectedStepIndex]);
      _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵadvance"](2);
      _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵproperty"]("ngIf", ctx.backButton);
      _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵadvance"](1);
      _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵproperty"]("ngIf", ctx.selectedStepIndex !== ctx.steps.length - 1);
      _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵadvance"](1);
      _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵproperty"]("ngIf", ctx.selectedStepIndex === ctx.steps.length - 1);
    }
  },
  directives: [_ionic_angular__WEBPACK_IMPORTED_MODULE_4__.IonCard, _ionic_angular__WEBPACK_IMPORTED_MODULE_4__.IonCardHeader, _ionic_angular__WEBPACK_IMPORTED_MODULE_4__.IonCardTitle, _angular_common__WEBPACK_IMPORTED_MODULE_5__.NgIf, _ionic_angular__WEBPACK_IMPORTED_MODULE_4__.IonCardContent, _angular_common__WEBPACK_IMPORTED_MODULE_5__.NgForOf, _angular_common__WEBPACK_IMPORTED_MODULE_5__.NgTemplateOutlet, _ionic_angular__WEBPACK_IMPORTED_MODULE_4__.IonButton],
  pipes: [_ngx_translate_core__WEBPACK_IMPORTED_MODULE_6__.TranslatePipe],
  styles: ["[_nghost-%COMP%] {\n  height: 100%;\n}\n\n.wrapper[_ngcontent-%COMP%] {\n  height: calc(100% - 20px);\n}\n\n.wrapper[_ngcontent-%COMP%]   ion-card[_ngcontent-%COMP%] {\n  height: 100%;\n  margin: 10px;\n  display: flex;\n  flex-direction: column;\n}\n\n.wrapper[_ngcontent-%COMP%]   ion-card[_ngcontent-%COMP%]   ion-card-content[_ngcontent-%COMP%] {\n  flex: 1;\n  display: flex;\n  flex-direction: column;\n  overflow-y: auto;\n}\n\n.title-header[_ngcontent-%COMP%]   ion-card-title[_ngcontent-%COMP%] {\n  font-size: 10px;\n  display: flex;\n  justify-content: space-between;\n}\n\n.form-steps-container[_ngcontent-%COMP%] {\n  display: flex;\n  justify-content: space-between;\n  align-items: center;\n  padding: 0 20px 0 10px;\n  margin-top: 10px;\n}\n\n.step-bubble[_ngcontent-%COMP%] {\n  padding: 8px;\n  border: 3px solid var(--ion-color-base);\n  width: 30px;\n  height: 30px;\n  display: flex;\n  justify-content: center;\n  align-items: center;\n  border-radius: 50%;\n  font-size: 1em;\n  cursor: pointer;\n  -webkit-user-select: none;\n          user-select: none;\n  background: #f2f6fa;\n}\n\n.step-bubble.step-current[_ngcontent-%COMP%] {\n  border-width: 5px;\n  width: 34px;\n  height: 34px;\n  margin-left: -2px;\n  margin-right: -2px;\n  background: white;\n  font-weight: bold;\n}\n\n.step-bubble.previous[_ngcontent-%COMP%] {\n  background-color: #fdfdaa;\n}\n\n.step-bubble.last-step[_ngcontent-%COMP%] {\n  border-radius: 0;\n}\n\n.step-divider[_ngcontent-%COMP%] {\n  height: 2px;\n  background: var(--ion-color-base);\n  flex: 1;\n}\n\n.step-divider.first-step[_ngcontent-%COMP%] {\n  flex: 0.2;\n}\n\n.step-content-wrapper[_ngcontent-%COMP%] {\n  flex: 1;\n}\n/*# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbIndpemFyZC5jb21wb25lbnQuc2NzcyJdLCJuYW1lcyI6W10sIm1hcHBpbmdzIjoiQUFJQTtFQUNFLFlBQUE7QUFIRjs7QUFNQTtFQUNFLHlCQUFBO0FBSEY7O0FBSUU7RUFDRSxZQUFBO0VBQ0EsWUFBQTtFQUVBLGFBQUE7RUFDQSxzQkFBQTtBQUhKOztBQUlJO0VBQ0UsT0FBQTtFQUNBLGFBQUE7RUFDQSxzQkFBQTtFQUNBLGdCQUFBO0FBRk47O0FBUUU7RUFDRSxlQUFBO0VBQ0EsYUFBQTtFQUNBLDhCQUFBO0FBTEo7O0FBUUE7RUFDRSxhQUFBO0VBQ0EsOEJBQUE7RUFDQSxtQkFBQTtFQUNBLHNCQUFBO0VBQ0EsZ0JBQUE7QUFMRjs7QUFXQTtFQUNFLFlBQUE7RUFDQSx1Q0FBQTtFQUNBLFdBTlk7RUFPWixZQVBZO0VBUVosYUFBQTtFQUNBLHVCQUFBO0VBQ0EsbUJBQUE7RUFDQSxrQkFBQTtFQUNBLGNBQUE7RUFDQSxlQUFBO0VBQ0EseUJBQUE7VUFBQSxpQkFBQTtFQUNBLG1CQXREd0I7QUE4QzFCOztBQVVFO0VBQ0UsaUJBQUE7RUFDQSxXQUFBO0VBQ0EsWUFBQTtFQUNBLGlCQUFBO0VBQ0Esa0JBQUE7RUFDQSxpQkEvRGtCO0VBZ0VsQixpQkFBQTtBQVJKOztBQVVFO0VBQ0UseUJBQUE7QUFSSjs7QUFVRTtFQUNFLGdCQUFBO0FBUko7O0FBWUE7RUFDRSxXQUFBO0VBQ0EsaUNBQUE7RUFDQSxPQUFBO0FBVEY7O0FBV0U7RUFDRSxTQUFBO0FBVEo7O0FBYUE7RUFDRSxPQUFBO0FBVkYiLCJmaWxlIjoid2l6YXJkLmNvbXBvbmVudC5zY3NzIiwic291cmNlc0NvbnRlbnQiOlsiJHNlbGVjdGVkLWJhY2tncm91bmQ6IHdoaXRlO1xuJG5vdC1zZWxlY3RlZC1iYWNrZ3JvdW5kOiAjZjJmNmZhO1xuLy8gJG5vdC1zZWxlY3RlZC1iYWNrZ3JvdW5kOiByZWQ7XG5cbjpob3N0IHtcbiAgaGVpZ2h0OiAxMDAlO1xufVxuXG4ud3JhcHBlciB7XG4gIGhlaWdodDogY2FsYygxMDAlIC0gMjBweCk7XG4gIGlvbi1jYXJkIHtcbiAgICBoZWlnaHQ6IDEwMCU7XG4gICAgbWFyZ2luOiAxMHB4O1xuXG4gICAgZGlzcGxheTogZmxleDtcbiAgICBmbGV4LWRpcmVjdGlvbjogY29sdW1uO1xuICAgIGlvbi1jYXJkLWNvbnRlbnQge1xuICAgICAgZmxleDogMTtcbiAgICAgIGRpc3BsYXk6IGZsZXg7XG4gICAgICBmbGV4LWRpcmVjdGlvbjogY29sdW1uO1xuICAgICAgb3ZlcmZsb3cteTogYXV0bztcbiAgICB9XG4gIH1cbn1cblxuLnRpdGxlLWhlYWRlciB7XG4gIGlvbi1jYXJkLXRpdGxlIHtcbiAgICBmb250LXNpemU6IDEwcHg7XG4gICAgZGlzcGxheTogZmxleDtcbiAgICBqdXN0aWZ5LWNvbnRlbnQ6IHNwYWNlLWJldHdlZW47XG4gIH1cbn1cbi5mb3JtLXN0ZXBzLWNvbnRhaW5lciB7XG4gIGRpc3BsYXk6IGZsZXg7XG4gIGp1c3RpZnktY29udGVudDogc3BhY2UtYmV0d2VlbjtcbiAgYWxpZ24taXRlbXM6IGNlbnRlcjtcbiAgcGFkZGluZzogMCAyMHB4IDAgMTBweDtcbiAgbWFyZ2luLXRvcDogMTBweDtcbn1cblxuJGJ1YmJsZS1zaXplOiAzMHB4O1xuJGJ1YmJsZS1ib3JkZXI6IDNweDtcbiRzZWxlY3RlZC1idWJibGUtaW5jcmVhc2U6IDJweDtcbi5zdGVwLWJ1YmJsZSB7XG4gIHBhZGRpbmc6IDhweDtcbiAgYm9yZGVyOiAkYnViYmxlLWJvcmRlciBzb2xpZCB2YXIoLS1pb24tY29sb3ItYmFzZSk7XG4gIHdpZHRoOiAkYnViYmxlLXNpemU7XG4gIGhlaWdodDogJGJ1YmJsZS1zaXplO1xuICBkaXNwbGF5OiBmbGV4O1xuICBqdXN0aWZ5LWNvbnRlbnQ6IGNlbnRlcjtcbiAgYWxpZ24taXRlbXM6IGNlbnRlcjtcbiAgYm9yZGVyLXJhZGl1czogNTAlO1xuICBmb250LXNpemU6IDFlbTtcbiAgY3Vyc29yOiBwb2ludGVyO1xuICB1c2VyLXNlbGVjdDogbm9uZTtcbiAgYmFja2dyb3VuZDogJG5vdC1zZWxlY3RlZC1iYWNrZ3JvdW5kO1xuXG4gICYuc3RlcC1jdXJyZW50IHtcbiAgICBib3JkZXItd2lkdGg6ICRidWJibGUtYm9yZGVyICsgJHNlbGVjdGVkLWJ1YmJsZS1pbmNyZWFzZTtcbiAgICB3aWR0aDogJGJ1YmJsZS1zaXplICsgMiAqICRzZWxlY3RlZC1idWJibGUtaW5jcmVhc2U7XG4gICAgaGVpZ2h0OiAkYnViYmxlLXNpemUgKyAyICogJHNlbGVjdGVkLWJ1YmJsZS1pbmNyZWFzZTtcbiAgICBtYXJnaW4tbGVmdDogLSRzZWxlY3RlZC1idWJibGUtaW5jcmVhc2U7XG4gICAgbWFyZ2luLXJpZ2h0OiAtJHNlbGVjdGVkLWJ1YmJsZS1pbmNyZWFzZTtcbiAgICBiYWNrZ3JvdW5kOiAkc2VsZWN0ZWQtYmFja2dyb3VuZDtcbiAgICBmb250LXdlaWdodDogYm9sZDtcbiAgfVxuICAmLnByZXZpb3VzIHtcbiAgICBiYWNrZ3JvdW5kLWNvbG9yOiAjZmRmZGFhO1xuICB9XG4gICYubGFzdC1zdGVwIHtcbiAgICBib3JkZXItcmFkaXVzOiAwO1xuICB9XG59XG5cbi5zdGVwLWRpdmlkZXIge1xuICBoZWlnaHQ6IDJweDtcbiAgYmFja2dyb3VuZDogdmFyKC0taW9uLWNvbG9yLWJhc2UpO1xuICBmbGV4OiAxO1xuXG4gICYuZmlyc3Qtc3RlcCB7XG4gICAgZmxleDogMC4yO1xuICB9XG59XG5cbi5zdGVwLWNvbnRlbnQtd3JhcHBlciB7XG4gIGZsZXg6IDE7XG59XG4iXX0= */"]
});

/***/ })

}]);
//# sourceMappingURL=src_app_pages_challenges_create-challenge_create-challenge_module_ts.js.map