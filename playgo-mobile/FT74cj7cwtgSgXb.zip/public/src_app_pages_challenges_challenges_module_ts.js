"use strict";
(self["webpackChunkapp"] = self["webpackChunkapp"] || []).push([["src_app_pages_challenges_challenges_module_ts"],{

/***/ 39729:
/*!*****************************************************************************!*\
  !*** ./src/app/pages/challenges/challenge-card/challenge-card.component.ts ***!
  \*****************************************************************************/
/***/ (function(__unused_webpack_module, __webpack_exports__, __webpack_require__) {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "ChallengeCardComponent": function() { return /* binding */ ChallengeCardComponent; }
/* harmony export */ });
/* harmony import */ var _Users_smartcommunitylab_Desktop_newWork_dslab_playgo_mobile_playgo_mobile_node_modules_babel_runtime_helpers_esm_classCallCheck_js__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./node_modules/@babel/runtime/helpers/esm/classCallCheck.js */ 78069);
/* harmony import */ var _Users_smartcommunitylab_Desktop_newWork_dslab_playgo_mobile_playgo_mobile_node_modules_babel_runtime_helpers_esm_createClass_js__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ./node_modules/@babel/runtime/helpers/esm/createClass.js */ 48047);
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_14__ = __webpack_require__(/*! tslib */ 42321);
/* harmony import */ var _capacitor_browser__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @capacitor/browser */ 18313);
/* harmony import */ var _detail_modal_detail_modal__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! ./detail-modal/detail.modal */ 9321);
/* harmony import */ var src_app_core_shared_campaigns_campaign_utils__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! src/app/core/shared/campaigns/campaign.utils */ 87725);
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_13__ = __webpack_require__(/*! @angular/core */ 3184);
/* harmony import */ var src_app_core_shared_services_campaign_service__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! src/app/core/shared/services/campaign.service */ 23645);
/* harmony import */ var _ionic_angular__WEBPACK_IMPORTED_MODULE_15__ = __webpack_require__(/*! @ionic/angular */ 93819);
/* harmony import */ var _ngx_translate_core__WEBPACK_IMPORTED_MODULE_16__ = __webpack_require__(/*! @ngx-translate/core */ 87514);
/* harmony import */ var src_app_core_shared_services_refresher_service__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! src/app/core/shared/services/refresher.service */ 30813);
/* harmony import */ var src_app_core_shared_services_team_service__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(/*! src/app/core/shared/services/team.service */ 86612);
/* harmony import */ var _core_shared_ui_icon_icon_component__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(/*! ../../../core/shared/ui/icon/icon.component */ 71888);
/* harmony import */ var _angular_common__WEBPACK_IMPORTED_MODULE_17__ = __webpack_require__(/*! @angular/common */ 36362);
/* harmony import */ var _core_shared_campaigns_challenge_users_status_challenge_users_status_component__WEBPACK_IMPORTED_MODULE_9__ = __webpack_require__(/*! ../../../core/shared/campaigns/challenge-users-status/challenge-users-status.component */ 47298);
/* harmony import */ var _core_shared_campaigns_challenge_bar_status_challenge_bar_status_component__WEBPACK_IMPORTED_MODULE_10__ = __webpack_require__(/*! ../../../core/shared/campaigns/challenge-bar-status/challenge-bar-status.component */ 69723);
/* harmony import */ var _core_shared_pipes_languageMap_pipe__WEBPACK_IMPORTED_MODULE_11__ = __webpack_require__(/*! ../../../core/shared/pipes/languageMap.pipe */ 73088);
/* harmony import */ var _core_shared_pipes_localDate_pipe__WEBPACK_IMPORTED_MODULE_12__ = __webpack_require__(/*! ../../../core/shared/pipes/localDate.pipe */ 34489);



function _regeneratorRuntime() { "use strict"; /*! regenerator-runtime -- Copyright (c) 2014-present, Facebook, Inc. -- license (MIT): https://github.com/facebook/regenerator/blob/main/LICENSE */ _regeneratorRuntime = function _regeneratorRuntime() { return e; }; var t, e = {}, r = Object.prototype, n = r.hasOwnProperty, o = Object.defineProperty || function (t, e, r) { t[e] = r.value; }, i = "function" == typeof Symbol ? Symbol : {}, a = i.iterator || "@@iterator", c = i.asyncIterator || "@@asyncIterator", u = i.toStringTag || "@@toStringTag"; function define(t, e, r) { return Object.defineProperty(t, e, { value: r, enumerable: !0, configurable: !0, writable: !0 }), t[e]; } try { define({}, ""); } catch (t) { define = function define(t, e, r) { return t[e] = r; }; } function wrap(t, e, r, n) { var i = e && e.prototype instanceof Generator ? e : Generator, a = Object.create(i.prototype), c = new Context(n || []); return o(a, "_invoke", { value: makeInvokeMethod(t, r, c) }), a; } function tryCatch(t, e, r) { try { return { type: "normal", arg: t.call(e, r) }; } catch (t) { return { type: "throw", arg: t }; } } e.wrap = wrap; var h = "suspendedStart", l = "suspendedYield", f = "executing", s = "completed", y = {}; function Generator() {} function GeneratorFunction() {} function GeneratorFunctionPrototype() {} var p = {}; define(p, a, function () { return this; }); var d = Object.getPrototypeOf, v = d && d(d(values([]))); v && v !== r && n.call(v, a) && (p = v); var g = GeneratorFunctionPrototype.prototype = Generator.prototype = Object.create(p); function defineIteratorMethods(t) { ["next", "throw", "return"].forEach(function (e) { define(t, e, function (t) { return this._invoke(e, t); }); }); } function AsyncIterator(t, e) { function invoke(r, o, i, a) { var c = tryCatch(t[r], t, o); if ("throw" !== c.type) { var u = c.arg, h = u.value; return h && "object" == typeof h && n.call(h, "__await") ? e.resolve(h.__await).then(function (t) { invoke("next", t, i, a); }, function (t) { invoke("throw", t, i, a); }) : e.resolve(h).then(function (t) { u.value = t, i(u); }, function (t) { return invoke("throw", t, i, a); }); } a(c.arg); } var r; o(this, "_invoke", { value: function value(t, n) { function callInvokeWithMethodAndArg() { return new e(function (e, r) { invoke(t, n, e, r); }); } return r = r ? r.then(callInvokeWithMethodAndArg, callInvokeWithMethodAndArg) : callInvokeWithMethodAndArg(); } }); } function makeInvokeMethod(e, r, n) { var o = h; return function (i, a) { if (o === f) throw new Error("Generator is already running"); if (o === s) { if ("throw" === i) throw a; return { value: t, done: !0 }; } for (n.method = i, n.arg = a;;) { var c = n.delegate; if (c) { var u = maybeInvokeDelegate(c, n); if (u) { if (u === y) continue; return u; } } if ("next" === n.method) n.sent = n._sent = n.arg;else if ("throw" === n.method) { if (o === h) throw o = s, n.arg; n.dispatchException(n.arg); } else "return" === n.method && n.abrupt("return", n.arg); o = f; var p = tryCatch(e, r, n); if ("normal" === p.type) { if (o = n.done ? s : l, p.arg === y) continue; return { value: p.arg, done: n.done }; } "throw" === p.type && (o = s, n.method = "throw", n.arg = p.arg); } }; } function maybeInvokeDelegate(e, r) { var n = r.method, o = e.iterator[n]; if (o === t) return r.delegate = null, "throw" === n && e.iterator.return && (r.method = "return", r.arg = t, maybeInvokeDelegate(e, r), "throw" === r.method) || "return" !== n && (r.method = "throw", r.arg = new TypeError("The iterator does not provide a '" + n + "' method")), y; var i = tryCatch(o, e.iterator, r.arg); if ("throw" === i.type) return r.method = "throw", r.arg = i.arg, r.delegate = null, y; var a = i.arg; return a ? a.done ? (r[e.resultName] = a.value, r.next = e.nextLoc, "return" !== r.method && (r.method = "next", r.arg = t), r.delegate = null, y) : a : (r.method = "throw", r.arg = new TypeError("iterator result is not an object"), r.delegate = null, y); } function pushTryEntry(t) { var e = { tryLoc: t[0] }; 1 in t && (e.catchLoc = t[1]), 2 in t && (e.finallyLoc = t[2], e.afterLoc = t[3]), this.tryEntries.push(e); } function resetTryEntry(t) { var e = t.completion || {}; e.type = "normal", delete e.arg, t.completion = e; } function Context(t) { this.tryEntries = [{ tryLoc: "root" }], t.forEach(pushTryEntry, this), this.reset(!0); } function values(e) { if (e || "" === e) { var r = e[a]; if (r) return r.call(e); if ("function" == typeof e.next) return e; if (!isNaN(e.length)) { var o = -1, i = function next() { for (; ++o < e.length;) if (n.call(e, o)) return next.value = e[o], next.done = !1, next; return next.value = t, next.done = !0, next; }; return i.next = i; } } throw new TypeError(typeof e + " is not iterable"); } return GeneratorFunction.prototype = GeneratorFunctionPrototype, o(g, "constructor", { value: GeneratorFunctionPrototype, configurable: !0 }), o(GeneratorFunctionPrototype, "constructor", { value: GeneratorFunction, configurable: !0 }), GeneratorFunction.displayName = define(GeneratorFunctionPrototype, u, "GeneratorFunction"), e.isGeneratorFunction = function (t) { var e = "function" == typeof t && t.constructor; return !!e && (e === GeneratorFunction || "GeneratorFunction" === (e.displayName || e.name)); }, e.mark = function (t) { return Object.setPrototypeOf ? Object.setPrototypeOf(t, GeneratorFunctionPrototype) : (t.__proto__ = GeneratorFunctionPrototype, define(t, u, "GeneratorFunction")), t.prototype = Object.create(g), t; }, e.awrap = function (t) { return { __await: t }; }, defineIteratorMethods(AsyncIterator.prototype), define(AsyncIterator.prototype, c, function () { return this; }), e.AsyncIterator = AsyncIterator, e.async = function (t, r, n, o, i) { void 0 === i && (i = Promise); var a = new AsyncIterator(wrap(t, r, n, o), i); return e.isGeneratorFunction(r) ? a : a.next().then(function (t) { return t.done ? t.value : a.next(); }); }, defineIteratorMethods(g), define(g, u, "Generator"), define(g, a, function () { return this; }), define(g, "toString", function () { return "[object Generator]"; }), e.keys = function (t) { var e = Object(t), r = []; for (var n in e) r.push(n); return r.reverse(), function next() { for (; r.length;) { var t = r.pop(); if (t in e) return next.value = t, next.done = !1, next; } return next.done = !0, next; }; }, e.values = values, Context.prototype = { constructor: Context, reset: function reset(e) { if (this.prev = 0, this.next = 0, this.sent = this._sent = t, this.done = !1, this.delegate = null, this.method = "next", this.arg = t, this.tryEntries.forEach(resetTryEntry), !e) for (var r in this) "t" === r.charAt(0) && n.call(this, r) && !isNaN(+r.slice(1)) && (this[r] = t); }, stop: function stop() { this.done = !0; var t = this.tryEntries[0].completion; if ("throw" === t.type) throw t.arg; return this.rval; }, dispatchException: function dispatchException(e) { if (this.done) throw e; var r = this; function handle(n, o) { return a.type = "throw", a.arg = e, r.next = n, o && (r.method = "next", r.arg = t), !!o; } for (var o = this.tryEntries.length - 1; o >= 0; --o) { var i = this.tryEntries[o], a = i.completion; if ("root" === i.tryLoc) return handle("end"); if (i.tryLoc <= this.prev) { var c = n.call(i, "catchLoc"), u = n.call(i, "finallyLoc"); if (c && u) { if (this.prev < i.catchLoc) return handle(i.catchLoc, !0); if (this.prev < i.finallyLoc) return handle(i.finallyLoc); } else if (c) { if (this.prev < i.catchLoc) return handle(i.catchLoc, !0); } else { if (!u) throw new Error("try statement without catch or finally"); if (this.prev < i.finallyLoc) return handle(i.finallyLoc); } } } }, abrupt: function abrupt(t, e) { for (var r = this.tryEntries.length - 1; r >= 0; --r) { var o = this.tryEntries[r]; if (o.tryLoc <= this.prev && n.call(o, "finallyLoc") && this.prev < o.finallyLoc) { var i = o; break; } } i && ("break" === t || "continue" === t) && i.tryLoc <= e && e <= i.finallyLoc && (i = null); var a = i ? i.completion : {}; return a.type = t, a.arg = e, i ? (this.method = "next", this.next = i.finallyLoc, y) : this.complete(a); }, complete: function complete(t, e) { if ("throw" === t.type) throw t.arg; return "break" === t.type || "continue" === t.type ? this.next = t.arg : "return" === t.type ? (this.rval = this.arg = t.arg, this.method = "return", this.next = "end") : "normal" === t.type && e && (this.next = e), y; }, finish: function finish(t) { for (var e = this.tryEntries.length - 1; e >= 0; --e) { var r = this.tryEntries[e]; if (r.finallyLoc === t) return this.complete(r.completion, r.afterLoc), resetTryEntry(r), y; } }, catch: function _catch(t) { for (var e = this.tryEntries.length - 1; e >= 0; --e) { var r = this.tryEntries[e]; if (r.tryLoc === t) { var n = r.completion; if ("throw" === n.type) { var o = n.arg; resetTryEntry(r); } return o; } } throw new Error("illegal catch attempt"); }, delegateYield: function delegateYield(e, r, n) { return this.delegate = { iterator: values(e), resultName: r, nextLoc: n }, "next" === this.method && (this.arg = t), y; } }, e; }


















var _c0 = function _c0(a0) {
  return {
    prize: a0
  };
};

function ChallengeCardComponent_ion_row_19_div_2_Template(rf, ctx) {
  if (rf & 1) {
    _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵelementStart"](0, "div")(1, "p", 19);
    _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵtext"](2);
    _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵpipe"](3, "uppercase");
    _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵpipe"](4, "translate");
    _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵelementEnd"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵelementStart"](5, "p", 20);
    _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵtext"](6);
    _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵpipe"](7, "translate");
    _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵelement"](8, "app-icon", 16);
    _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵelementEnd"]()();
  }

  if (rf & 2) {
    var ctx_r5 = _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵnextContext"](2);
    _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵadvance"](2);
    _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵtextInterpolate1"](" ", _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵpipeBind1"](3, 3, _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵpipeBind1"](4, 5, "challenges.challenge_detail.won")), " ");
    _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵadvance"](4);
    _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵtextInterpolate1"](" ", _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵpipeBind2"](7, 7, "challenges.challenge_detail.prize", _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵpureFunction1"](10, _c0, ctx_r5.challenge.bonus)), " ");
    _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵadvance"](2);
    _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵproperty"]("name", ctx_r5.campaignService.getCampaignScoreIcon(ctx_r5.challenge.campaign));
  }
}

function ChallengeCardComponent_ion_row_19_ng_template_3_Template(rf, ctx) {
  if (rf & 1) {
    _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵelementStart"](0, "p", 21);
    _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵtext"](1);
    _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵpipe"](2, "uppercase");
    _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵpipe"](3, "translate");
    _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵelementEnd"]();
  }

  if (rf & 2) {
    _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵadvance"](1);
    _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵtextInterpolate1"](" ", _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵpipeBind1"](2, 1, _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵpipeBind1"](3, 3, "challenges.challenge_detail.lost")), " ");
  }
}

function ChallengeCardComponent_ion_row_19_Template(rf, ctx) {
  if (rf & 1) {
    _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵelementStart"](0, "ion-row")(1, "ion-col", 17);
    _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵtemplate"](2, ChallengeCardComponent_ion_row_19_div_2_Template, 9, 12, "div", 11);
    _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵtemplate"](3, ChallengeCardComponent_ion_row_19_ng_template_3_Template, 4, 5, "ng-template", null, 18, _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵtemplateRefExtractor"]);
    _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵelementEnd"]()();
  }

  if (rf & 2) {
    var _r6 = _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵreference"](4);

    var ctx_r0 = _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵnextContext"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵadvance"](2);
    _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵproperty"]("ngIf", ctx_r0.challengeWon())("ngIfElse", _r6);
  }
}

function ChallengeCardComponent_app_challenge_users_status_22_Template(rf, ctx) {
  if (rf & 1) {
    _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵelement"](0, "app-challenge-users-status", 22);
  }

  if (rf & 2) {
    var ctx_r1 = _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵnextContext"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵproperty"]("status", ctx_r1.challenge.status)("rowStatus", ctx_r1.challenge.row_status)("type", ctx_r1.type)("challengeType", ctx_r1.challenge.type)("otherUser", ctx_r1.challenge.otherAttendeeData)("kind", ctx_r1.challenge.kind)("campaignContainer", ctx_r1.campaignContainer)("unitHasKm", ctx_r1.getUnitChallenge(ctx_r1.challenge));
  }
}

function ChallengeCardComponent_div_25_app_challenge_bar_status_1_Template(rf, ctx) {
  if (rf & 1) {
    _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵelement"](0, "app-challenge-bar-status", 25);
  }

  if (rf & 2) {
    var ctx_r8 = _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵnextContext"](2);
    _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵproperty"]("status", ctx_r8.challenge.status)("rowStatus", ctx_r8.challenge.row_status)("otherStatus", ctx_r8.challenge.otherAttendeeData == null ? null : ctx_r8.challenge.otherAttendeeData.status)("challengeType", ctx_r8.challenge.type)("type", ctx_r8.type)("campaignType", ctx_r8.challenge.campaign.type);
  }
}

function ChallengeCardComponent_div_25_ng_template_2_ion_button_0_Template(rf, ctx) {
  if (rf & 1) {
    var _r13 = _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵgetCurrentView"]();

    _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵelementStart"](0, "ion-button", 27);
    _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵlistener"]("click", function ChallengeCardComponent_div_25_ng_template_2_ion_button_0_Template_ion_button_click_0_listener() {
      _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵrestoreView"](_r13);
      var ctx_r12 = _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵnextContext"](3);
      return ctx_r12.fillSurvey();
    });
    _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵtext"](1);
    _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵpipe"](2, "translate");
    _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵelementEnd"]();
  }

  if (rf & 2) {
    var ctx_r11 = _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵnextContext"](3);
    _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵproperty"]("color", ctx_r11.challenge == null ? null : ctx_r11.challenge.campaign == null ? null : ctx_r11.challenge.campaign.type);
    _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵadvance"](1);
    _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵtextInterpolate1"](" ", _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵpipeBind1"](2, 2, "challenges.challenge_detail.survey"), " ");
  }
}

function ChallengeCardComponent_div_25_ng_template_2_Template(rf, ctx) {
  if (rf & 1) {
    _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵtemplate"](0, ChallengeCardComponent_div_25_ng_template_2_ion_button_0_Template, 3, 4, "ion-button", 26);
  }

  if (rf & 2) {
    var ctx_r10 = _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵnextContext"](2);
    _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵproperty"]("ngIf", ctx_r10.challenge.extUrl && ctx_r10.challenge.status < 100);
  }
}

function ChallengeCardComponent_div_25_Template(rf, ctx) {
  if (rf & 1) {
    _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵelementStart"](0, "div");
    _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵtemplate"](1, ChallengeCardComponent_div_25_app_challenge_bar_status_1_Template, 1, 6, "app-challenge-bar-status", 23);
    _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵtemplate"](2, ChallengeCardComponent_div_25_ng_template_2_Template, 1, 1, "ng-template", null, 24, _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵtemplateRefExtractor"]);
    _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵelementEnd"]();
  }

  if (rf & 2) {
    var _r9 = _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵreference"](3);

    var ctx_r2 = _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵnextContext"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵadvance"](1);
    _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵproperty"]("ngIf", ctx_r2.challenge.type !== "survey")("ngIfElse", _r9);
  }
}

var _c1 = function _c1(a0) {
  return {
    startDate: a0
  };
};

function ChallengeCardComponent_ng_template_26_Template(rf, ctx) {
  if (rf & 1) {
    _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵelementStart"](0, "div", 28);
    _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵtext"](1);
    _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵpipe"](2, "translate");
    _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵpipe"](3, "localDate");
    _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵelementEnd"]();
  }

  if (rf & 2) {
    var ctx_r4 = _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵnextContext"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵadvance"](1);
    _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵtextInterpolate1"](" ", _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵpipeBind2"](2, 1, "challenges.challenge_detail.challenge_future_start", _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵpureFunction1"](6, _c1, _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵpipeBind1"](3, 4, ctx_r4.challenge.startDate))), " ");
  }
}

var _c2 = function _c2(a0, a1) {
  return {
    from: a0,
    to: a1
  };
};

var ChallengeCardComponent = /*#__PURE__*/function () {
  function ChallengeCardComponent(campaignService, elementRef, modalController, translateService, refresherService, teamService) {
    (0,_Users_smartcommunitylab_Desktop_newWork_dslab_playgo_mobile_playgo_mobile_node_modules_babel_runtime_helpers_esm_classCallCheck_js__WEBPACK_IMPORTED_MODULE_0__["default"])(this, ChallengeCardComponent);

    this.campaignService = campaignService;
    this.elementRef = elementRef;
    this.modalController = modalController;
    this.translateService = translateService;
    this.refresherService = refresherService;
    this.teamService = teamService;
    this.team = false;
    this.imgChallenge = src_app_core_shared_campaigns_campaign_utils__WEBPACK_IMPORTED_MODULE_4__.getImgChallenge;

    this.handleAnchorClick = function (event) {
      // Prevent opening anchors the default way
      event.preventDefault();
      var anchor = event.target;
      _capacitor_browser__WEBPACK_IMPORTED_MODULE_2__.Browser.open({
        url: anchor.href,
        windowName: '_system',
        presentationStyle: 'popover'
      });
    };
  }

  (0,_Users_smartcommunitylab_Desktop_newWork_dslab_playgo_mobile_playgo_mobile_node_modules_babel_runtime_helpers_esm_createClass_js__WEBPACK_IMPORTED_MODULE_1__["default"])(ChallengeCardComponent, [{
    key: "ngAfterViewInit",
    value: function ngAfterViewInit() {
      var _this = this;

      //change the behaviour of _blank arrived with editor, adding a new listener and opening a browser
      this.anchors = this.elementRef.nativeElement.querySelectorAll('a');
      this.anchors.forEach(function (anchor) {
        anchor.addEventListener('click', _this.handleAnchorClick);
      });
    }
  }, {
    key: "ngOnInit",
    value: function ngOnInit() {
      var _a, _b, _c, _d;

      if (this.team && ((_a = this.challenge) === null || _a === void 0 ? void 0 : _a.otherAttendeeData)) {
        this.otherTeam$ = this.teamService.getPublicTeam((_c = (_b = this.campaignContainer) === null || _b === void 0 ? void 0 : _b.campaign) === null || _c === void 0 ? void 0 : _c.campaignId, (_d = this.challenge) === null || _d === void 0 ? void 0 : _d.otherAttendeeData.playerId);
      }

      ;
    }
  }, {
    key: "typeChallenge",
    value: function typeChallenge(kind, type, other) {
      return kind === "team" ? other ? this.translateService.instant('challenges.challenge_model.name.teams') : this.translateService.instant('challenges.challenge_model.name.default-team') : this.translateService.instant((0,src_app_core_shared_campaigns_campaign_utils__WEBPACK_IMPORTED_MODULE_4__.getTypeStringChallenge)(type));
    }
  }, {
    key: "fillSurvey",
    value: function fillSurvey() {
      var _this2 = this;

      _capacitor_browser__WEBPACK_IMPORTED_MODULE_2__.Browser.addListener('browserFinished', function () {
        //send refresh challenge event
        _this2.refresherService.onRefresh(null);
      });
      _capacitor_browser__WEBPACK_IMPORTED_MODULE_2__.Browser.open({
        url: this.challenge.extUrl,
        windowName: '_system',
        presentationStyle: 'popover'
      });
    }
  }, {
    key: "getUnitChallenge",
    value: function getUnitChallenge(challenge) {
      var _a;

      return (_a = challenge === null || challenge === void 0 ? void 0 : challenge.unit) === null || _a === void 0 ? void 0 : _a.toLowerCase().includes('km'.toLowerCase());
    }
  }, {
    key: "moreInfo",
    value: function moreInfo() {
      return (0,tslib__WEBPACK_IMPORTED_MODULE_14__.__awaiter)(this, void 0, void 0, /*#__PURE__*/_regeneratorRuntime().mark(function _callee() {
        var modal, _yield$modal$onWillDi, data;

        return _regeneratorRuntime().wrap(function _callee$(_context) {
          while (1) switch (_context.prev = _context.next) {
            case 0:
              _context.next = 2;
              return this.modalController.create({
                component: _detail_modal_detail_modal__WEBPACK_IMPORTED_MODULE_3__.DetailChallengenModalPage,
                componentProps: {
                  campaignContainer: this.campaignContainer,
                  challenge: this.challenge,
                  team: this.team
                },
                cssClass: 'challenge-info'
              });

            case 2:
              modal = _context.sent;
              _context.next = 5;
              return modal.present();

            case 5:
              _context.next = 7;
              return modal.onWillDismiss();

            case 7:
              _yield$modal$onWillDi = _context.sent;
              data = _yield$modal$onWillDi.data;

            case 9:
            case "end":
              return _context.stop();
          }
        }, _callee, this);
      }));
    }
  }, {
    key: "challengeEnded",
    value: function challengeEnded() {
      var _a, _b, _c, _d;

      if (!this.isGroupCompetitivePerformance()) {
        {
          if (((_a = this.challenge) === null || _a === void 0 ? void 0 : _a.status) === 100 || ((_b = this.challenge) === null || _b === void 0 ? void 0 : _b.success) === true || ((_d = (_c = this.challenge) === null || _c === void 0 ? void 0 : _c.otherAttendeeData) === null || _d === void 0 ? void 0 : _d.status) === 100) {
            return true;
          }
        }
      }

      return false;
    }
  }, {
    key: "challengeWon",
    value: function challengeWon() {
      var _a;

      if (!this.isGroupCompetitivePerformance()) {
        if (((_a = this.challenge) === null || _a === void 0 ? void 0 : _a.status) === 100 || this.challenge.success === true) {
          return true;
        } else {
          return this.challenge.success;
        }
      }
    }
  }, {
    key: "isGroupCompetitivePerformance",
    value: function isGroupCompetitivePerformance() {
      return this.challenge.type === 'groupCompetitivePerformance';
    }
  }, {
    key: "challDesc",
    value: function challDesc(desc, name) {
      var _a, _b; //sub id with name


      var search = (_b = (_a = this.challenge) === null || _a === void 0 ? void 0 : _a.otherAttendeeData) === null || _b === void 0 ? void 0 : _b.playerId;
      var searchRegExp = new RegExp(search, 'g');
      var replaceWith = name;
      if (this.team && name && desc) return desc.replace(searchRegExp, replaceWith);
      return desc;
    }
  }]);

  return ChallengeCardComponent;
}();

ChallengeCardComponent.ɵfac = function ChallengeCardComponent_Factory(t) {
  return new (t || ChallengeCardComponent)(_angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵdirectiveInject"](src_app_core_shared_services_campaign_service__WEBPACK_IMPORTED_MODULE_5__.CampaignService), _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵdirectiveInject"](_angular_core__WEBPACK_IMPORTED_MODULE_13__.ElementRef), _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵdirectiveInject"](_ionic_angular__WEBPACK_IMPORTED_MODULE_15__.ModalController), _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵdirectiveInject"](_ngx_translate_core__WEBPACK_IMPORTED_MODULE_16__.TranslateService), _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵdirectiveInject"](src_app_core_shared_services_refresher_service__WEBPACK_IMPORTED_MODULE_6__.RefresherService), _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵdirectiveInject"](src_app_core_shared_services_team_service__WEBPACK_IMPORTED_MODULE_7__.TeamService));
};

ChallengeCardComponent.ɵcmp = /*@__PURE__*/_angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵdefineComponent"]({
  type: ChallengeCardComponent,
  selectors: [["app-challenge-card"]],
  inputs: {
    campaignContainer: "campaignContainer",
    challenge: "challenge",
    type: "type",
    team: "team"
  },
  decls: 40,
  vars: 28,
  consts: [[1, "header", 3, "color"], [1, "ion-no-padding"], [1, "ion-align-items-center"], [1, "ion-text-center", "challenge-type"], ["size", "2"], [1, "icon-size-medium", 3, "name"], [3, "innerHTML"], ["size", "1"], ["name", "information-circle-outline", 1, "popup-icon", 3, "click"], [4, "ngIf"], [3, "status", "rowStatus", "type", "challengeType", "otherUser", "kind", "campaignContainer", "unitHasKm", 4, "ngIf"], [4, "ngIf", "ngIfElse"], ["future", ""], ["size", "8"], [1, "challenge-date"], ["size", "4", 1, "ion-text-end", "point-col"], [3, "name"], [1, "ion-text-center", "status-chall"], ["challengeLost", ""], [1, "won"], [1, "prize"], [1, "lost"], [3, "status", "rowStatus", "type", "challengeType", "otherUser", "kind", "campaignContainer", "unitHasKm"], [3, "status", "rowStatus", "otherStatus", "challengeType", "type", "campaignType", 4, "ngIf", "ngIfElse"], ["survey", ""], [3, "status", "rowStatus", "otherStatus", "challengeType", "type", "campaignType"], ["expand", "block", 3, "color", "click", 4, "ngIf"], ["expand", "block", 3, "color", "click"], [1, "ion-text-center", "challenge-date"]],
  template: function ChallengeCardComponent_Template(rf, ctx) {
    if (rf & 1) {
      _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵelementStart"](0, "ion-card")(1, "ion-card-header", 0)(2, "span");
      _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵtext"](3);
      _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵpipe"](4, "languageMap");
      _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵelementEnd"]()();
      _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵelementStart"](5, "ion-card-content", 1)(6, "ion-grid")(7, "ion-row", 2)(8, "ion-col", 3);
      _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵtext"](9);
      _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵelementEnd"]()();
      _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵelementStart"](10, "ion-row", 2)(11, "ion-col", 4);
      _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵelement"](12, "app-icon", 5);
      _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵelementEnd"]();
      _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵelementStart"](13, "ion-col");
      _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵelement"](14, "p", 6);
      _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵpipe"](15, "languageMap");
      _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵpipe"](16, "async");
      _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵelementEnd"]();
      _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵelementStart"](17, "ion-col", 7)(18, "ion-icon", 8);
      _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵlistener"]("click", function ChallengeCardComponent_Template_ion_icon_click_18_listener() {
        return ctx.moreInfo();
      });
      _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵelementEnd"]()()();
      _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵtemplate"](19, ChallengeCardComponent_ion_row_19_Template, 5, 2, "ion-row", 9);
      _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵelementStart"](20, "ion-row")(21, "ion-col");
      _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵtemplate"](22, ChallengeCardComponent_app_challenge_users_status_22_Template, 1, 8, "app-challenge-users-status", 10);
      _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵelementEnd"]()();
      _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵelementStart"](23, "ion-row")(24, "ion-col");
      _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵtemplate"](25, ChallengeCardComponent_div_25_Template, 4, 2, "div", 11);
      _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵtemplate"](26, ChallengeCardComponent_ng_template_26_Template, 4, 8, "ng-template", null, 12, _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵtemplateRefExtractor"]);
      _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵelementEnd"]()();
      _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵelementStart"](28, "ion-row")(29, "ion-col", 13)(30, "span", 14);
      _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵtext"](31);
      _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵpipe"](32, "translate");
      _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵpipe"](33, "localDate");
      _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵpipe"](34, "localDate");
      _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵelementEnd"]()();
      _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵelementStart"](35, "ion-col", 15)(36, "span", 14);
      _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵtext"](37);
      _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵelementEnd"]();
      _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵelement"](38, "app-icon", 16);
      _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵelementEnd"]()()();
      _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵelement"](39, "p");
      _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵelementEnd"]()();
    }

    if (rf & 2) {
      var _r3 = _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵreference"](27);

      var tmp_4_0;
      _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵadvance"](1);
      _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵproperty"]("color", ctx.challenge == null ? null : ctx.challenge.campaign == null ? null : ctx.challenge.campaign.type);
      _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵadvance"](2);
      _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵtextInterpolate"](_angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵpipeBind1"](4, 12, ctx.challenge == null ? null : ctx.challenge.campaign == null ? null : ctx.challenge.campaign.name));
      _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵadvance"](6);
      _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵtextInterpolate1"](" ", ctx.typeChallenge(ctx.challenge.kind, ctx.challenge.type, ctx.challenge.otherAttendeeData ? true : false), " ");
      _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵadvance"](3);
      _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵproperty"]("name", ctx.imgChallenge(ctx.challenge.type));
      _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵadvance"](2);
      _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵproperty"]("innerHTML", ctx.challDesc(_angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵpipeBind1"](15, 14, ctx.challenge == null ? null : ctx.challenge.challDesc), (tmp_4_0 = _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵpipeBind1"](16, 16, ctx.otherTeam$)) == null ? null : tmp_4_0.customData == null ? null : tmp_4_0.customData.name), _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵsanitizeHtml"]);
      _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵadvance"](5);
      _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵproperty"]("ngIf", ctx.challengeEnded());
      _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵadvance"](3);
      _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵproperty"]("ngIf", ctx.challenge.type !== "survey");
      _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵadvance"](3);
      _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵproperty"]("ngIf", ctx.type === "active")("ngIfElse", _r3);
      _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵadvance"](6);
      _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵtextInterpolate"](_angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵpipeBind2"](32, 18, "date.from_to", _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵpureFunction2"](25, _c2, _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵpipeBind1"](33, 21, ctx.challenge.startDate), _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵpipeBind1"](34, 23, ctx.challenge.endDate))));
      _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵadvance"](6);
      _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵtextInterpolate"](ctx.challenge.bonus);
      _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵadvance"](1);
      _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵproperty"]("name", ctx.campaignService.getCampaignScoreIcon(ctx.challenge.campaign));
    }
  },
  directives: [_ionic_angular__WEBPACK_IMPORTED_MODULE_15__.IonCard, _ionic_angular__WEBPACK_IMPORTED_MODULE_15__.IonCardHeader, _ionic_angular__WEBPACK_IMPORTED_MODULE_15__.IonCardContent, _ionic_angular__WEBPACK_IMPORTED_MODULE_15__.IonGrid, _ionic_angular__WEBPACK_IMPORTED_MODULE_15__.IonRow, _ionic_angular__WEBPACK_IMPORTED_MODULE_15__.IonCol, _core_shared_ui_icon_icon_component__WEBPACK_IMPORTED_MODULE_8__.IconComponent, _ionic_angular__WEBPACK_IMPORTED_MODULE_15__.IonIcon, _angular_common__WEBPACK_IMPORTED_MODULE_17__.NgIf, _core_shared_campaigns_challenge_users_status_challenge_users_status_component__WEBPACK_IMPORTED_MODULE_9__.ChallengeUsersStatusComponent, _core_shared_campaigns_challenge_bar_status_challenge_bar_status_component__WEBPACK_IMPORTED_MODULE_10__.ChallengeBarStatusComponent, _ionic_angular__WEBPACK_IMPORTED_MODULE_15__.IonButton],
  pipes: [_core_shared_pipes_languageMap_pipe__WEBPACK_IMPORTED_MODULE_11__.LanguageMapPipe, _angular_common__WEBPACK_IMPORTED_MODULE_17__.AsyncPipe, _angular_common__WEBPACK_IMPORTED_MODULE_17__.UpperCasePipe, _ngx_translate_core__WEBPACK_IMPORTED_MODULE_16__.TranslatePipe, _core_shared_pipes_localDate_pipe__WEBPACK_IMPORTED_MODULE_12__.LocalDatePipe],
  styles: ["ion-card-title[_ngcontent-%COMP%] {\n  font-size: small;\n}\n\n.header[_ngcontent-%COMP%] {\n  text-align: start;\n  padding: 4px;\n  font-style: italic;\n  font-weight: 300;\n  font-size: 13px;\n}\n\n.header[_ngcontent-%COMP%]   span[_ngcontent-%COMP%] {\n  margin-left: 18px;\n}\n\nion-card-content[_ngcontent-%COMP%] {\n  padding: 0px 4px;\n}\n\nion-card-content[_ngcontent-%COMP%]   .challenge-type[_ngcontent-%COMP%] {\n  font-style: italic;\n  font-weight: 200;\n  font-size: 16px;\n}\n\nion-card-content[_ngcontent-%COMP%]   .challenge-date[_ngcontent-%COMP%] {\n  font-style: italic;\n  font-weight: 300;\n  font-size: 13px;\n}\n\nion-card-content[_ngcontent-%COMP%]   .point-col[_ngcontent-%COMP%] {\n  line-height: 15px;\n  display: flex;\n  justify-content: flex-end;\n  align-items: center;\n}\n\nion-card-content[_ngcontent-%COMP%]   .popup-icon[_ngcontent-%COMP%] {\n  font-size: 30px;\n}\n\nion-card-content[_ngcontent-%COMP%]   .status-chall[_ngcontent-%COMP%] {\n  font-style: normal;\n  font-weight: 600;\n  font-size: 18px;\n  line-height: 21px;\n}\n\nion-card-content[_ngcontent-%COMP%]   .status-chall[_ngcontent-%COMP%]   .won[_ngcontent-%COMP%] {\n  color: var(--ion-color-start);\n  font-size: 18px;\n}\n\nion-card-content[_ngcontent-%COMP%]   .status-chall[_ngcontent-%COMP%]   .prize[_ngcontent-%COMP%] {\n  font-size: 13px;\n  font-style: italic;\n  font-weight: 300;\n  line-height: 15px;\n  letter-spacing: 0px;\n  text-align: center;\n}\n\nion-card-content[_ngcontent-%COMP%]   .status-chall[_ngcontent-%COMP%]   .lost[_ngcontent-%COMP%] {\n  color: #c61010;\n  font-size: 18px;\n}\n/*# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbImNoYWxsZW5nZS1jYXJkLmNvbXBvbmVudC5zY3NzIl0sIm5hbWVzIjpbXSwibWFwcGluZ3MiOiJBQUFBO0VBQ0UsZ0JBQUE7QUFDRjs7QUFDQTtFQUNFLGlCQUFBO0VBQ0EsWUFBQTtFQUNBLGtCQUFBO0VBQ0EsZ0JBQUE7RUFDQSxlQUFBO0FBRUY7O0FBREU7RUFDRSxpQkFBQTtBQUdKOztBQUFBO0VBQ0UsZ0JBQUE7QUFHRjs7QUFGRTtFQUNFLGtCQUFBO0VBQ0EsZ0JBQUE7RUFDQSxlQUFBO0FBSUo7O0FBRkU7RUFDRSxrQkFBQTtFQUNBLGdCQUFBO0VBQ0EsZUFBQTtBQUlKOztBQUZFO0VBQ0UsaUJBQUE7RUFDQSxhQUFBO0VBQ0EseUJBQUE7RUFDQSxtQkFBQTtBQUlKOztBQUZFO0VBQ0UsZUFBQTtBQUlKOztBQUZFO0VBQ0Usa0JBQUE7RUFDQSxnQkFBQTtFQUNBLGVBQUE7RUFDQSxpQkFBQTtBQUlKOztBQUhJO0VBQ0UsNkJBQUE7RUFDQSxlQUFBO0FBS047O0FBSEk7RUFDRSxlQUFBO0VBQ0Esa0JBQUE7RUFDQSxnQkFBQTtFQUNBLGlCQUFBO0VBQ0EsbUJBQUE7RUFDQSxrQkFBQTtBQUtOOztBQUhJO0VBQ0UsY0FBQTtFQUNBLGVBQUE7QUFLTiIsImZpbGUiOiJjaGFsbGVuZ2UtY2FyZC5jb21wb25lbnQuc2NzcyIsInNvdXJjZXNDb250ZW50IjpbImlvbi1jYXJkLXRpdGxlIHtcbiAgZm9udC1zaXplOiBzbWFsbDtcbn1cbi5oZWFkZXIge1xuICB0ZXh0LWFsaWduOiBzdGFydDtcbiAgcGFkZGluZzogNHB4O1xuICBmb250LXN0eWxlOiBpdGFsaWM7XG4gIGZvbnQtd2VpZ2h0OiAzMDA7XG4gIGZvbnQtc2l6ZTogMTNweDtcbiAgc3BhbiB7XG4gICAgbWFyZ2luLWxlZnQ6IDE4cHg7XG4gIH1cbn1cbmlvbi1jYXJkLWNvbnRlbnQge1xuICBwYWRkaW5nOiAwcHggNHB4O1xuICAuY2hhbGxlbmdlLXR5cGUge1xuICAgIGZvbnQtc3R5bGU6IGl0YWxpYztcbiAgICBmb250LXdlaWdodDogMjAwO1xuICAgIGZvbnQtc2l6ZTogMTZweDtcbiAgfVxuICAuY2hhbGxlbmdlLWRhdGUge1xuICAgIGZvbnQtc3R5bGU6IGl0YWxpYztcbiAgICBmb250LXdlaWdodDogMzAwO1xuICAgIGZvbnQtc2l6ZTogMTNweDtcbiAgfVxuICAucG9pbnQtY29sIHtcbiAgICBsaW5lLWhlaWdodDogMTVweDtcbiAgICBkaXNwbGF5OiBmbGV4O1xuICAgIGp1c3RpZnktY29udGVudDogZmxleC1lbmQ7XG4gICAgYWxpZ24taXRlbXM6IGNlbnRlcjtcbiAgfVxuICAucG9wdXAtaWNvbiB7XG4gICAgZm9udC1zaXplOiAzMHB4O1xuICB9XG4gIC5zdGF0dXMtY2hhbGwge1xuICAgIGZvbnQtc3R5bGU6IG5vcm1hbDtcbiAgICBmb250LXdlaWdodDogNjAwO1xuICAgIGZvbnQtc2l6ZTogMThweDtcbiAgICBsaW5lLWhlaWdodDogMjFweDtcbiAgICAud29uIHtcbiAgICAgIGNvbG9yOiB2YXIoLS1pb24tY29sb3Itc3RhcnQpO1xuICAgICAgZm9udC1zaXplOiAxOHB4O1xuICAgIH1cbiAgICAucHJpemUge1xuICAgICAgZm9udC1zaXplOiAxM3B4O1xuICAgICAgZm9udC1zdHlsZTogaXRhbGljO1xuICAgICAgZm9udC13ZWlnaHQ6IDMwMDtcbiAgICAgIGxpbmUtaGVpZ2h0OiAxNXB4O1xuICAgICAgbGV0dGVyLXNwYWNpbmc6IDBweDtcbiAgICAgIHRleHQtYWxpZ246IGNlbnRlcjtcbiAgICB9XG4gICAgLmxvc3Qge1xuICAgICAgY29sb3I6ICNjNjEwMTA7XG4gICAgICBmb250LXNpemU6IDE4cHg7XG4gICAgfVxuICB9XG59XG4iXX0= */"]
});

/***/ }),

/***/ 9321:
/*!******************************************************************************!*\
  !*** ./src/app/pages/challenges/challenge-card/detail-modal/detail.modal.ts ***!
  \******************************************************************************/
/***/ (function(__unused_webpack_module, __webpack_exports__, __webpack_require__) {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "DetailChallengenModalPage": function() { return /* binding */ DetailChallengenModalPage; }
/* harmony export */ });
/* harmony import */ var _Users_smartcommunitylab_Desktop_newWork_dslab_playgo_mobile_playgo_mobile_node_modules_babel_runtime_helpers_esm_classCallCheck_js__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./node_modules/@babel/runtime/helpers/esm/classCallCheck.js */ 78069);
/* harmony import */ var _Users_smartcommunitylab_Desktop_newWork_dslab_playgo_mobile_playgo_mobile_node_modules_babel_runtime_helpers_esm_createClass_js__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ./node_modules/@babel/runtime/helpers/esm/createClass.js */ 48047);
/* harmony import */ var _capacitor_browser__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @capacitor/browser */ 18313);
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! @angular/core */ 3184);
/* harmony import */ var _ionic_angular__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! @ionic/angular */ 93819);
/* harmony import */ var src_app_core_shared_services_team_service__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! src/app/core/shared/services/team.service */ 86612);
/* harmony import */ var _ngx_translate_core__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(/*! @ngx-translate/core */ 87514);
/* harmony import */ var _core_shared_pipes_languageMap_pipe__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! ../../../../core/shared/pipes/languageMap.pipe */ 73088);
/* harmony import */ var _angular_common__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(/*! @angular/common */ 36362);









var DetailChallengenModalPage = /*#__PURE__*/function () {
  function DetailChallengenModalPage(elementRef, modalController, teamService) {
    (0,_Users_smartcommunitylab_Desktop_newWork_dslab_playgo_mobile_playgo_mobile_node_modules_babel_runtime_helpers_esm_classCallCheck_js__WEBPACK_IMPORTED_MODULE_0__["default"])(this, DetailChallengenModalPage);

    this.elementRef = elementRef;
    this.modalController = modalController;
    this.teamService = teamService;

    this.handleAnchorClick = function (event) {
      // Prevent opening anchors the default way
      event.preventDefault();
      var anchor = event.target;
      _capacitor_browser__WEBPACK_IMPORTED_MODULE_2__.Browser.open({
        url: anchor.href,
        windowName: '_system',
        presentationStyle: 'popover'
      });
    };
  }

  (0,_Users_smartcommunitylab_Desktop_newWork_dslab_playgo_mobile_playgo_mobile_node_modules_babel_runtime_helpers_esm_createClass_js__WEBPACK_IMPORTED_MODULE_1__["default"])(DetailChallengenModalPage, [{
    key: "ngAfterViewInit",
    value: function ngAfterViewInit() {
      var _this = this;

      //change the behaviour of _blank arrived with editor, adding a new listener and opening a browser
      this.anchors = this.elementRef.nativeElement.querySelectorAll('a');
      this.anchors.forEach(function (anchor) {
        anchor.addEventListener('click', _this.handleAnchorClick);
      });
    }
  }, {
    key: "ngOnInit",
    value: function ngOnInit() {
      var _a, _b, _c, _d;

      if (this.team && ((_a = this.challenge) === null || _a === void 0 ? void 0 : _a.otherAttendeeData)) {
        this.otherTeam$ = this.teamService.getPublicTeam((_c = (_b = this.campaignContainer) === null || _b === void 0 ? void 0 : _b.campaign) === null || _c === void 0 ? void 0 : _c.campaignId, (_d = this.challenge) === null || _d === void 0 ? void 0 : _d.otherAttendeeData.playerId);
      }

      ;
    }
  }, {
    key: "close",
    value: function close() {
      this.modalController.dismiss(false);
    }
  }, {
    key: "challDesc",
    value: function challDesc(desc, name) {
      var _a, _b; //sub id with name


      var search = (_b = (_a = this.challenge) === null || _a === void 0 ? void 0 : _a.otherAttendeeData) === null || _b === void 0 ? void 0 : _b.playerId;
      var searchRegExp = new RegExp(search, 'g');
      var replaceWith = name;
      if (this.team && name && desc) return desc.replace(searchRegExp, replaceWith);
      return desc;
    }
  }]);

  return DetailChallengenModalPage;
}();

DetailChallengenModalPage.ɵfac = function DetailChallengenModalPage_Factory(t) {
  return new (t || DetailChallengenModalPage)(_angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵdirectiveInject"](_angular_core__WEBPACK_IMPORTED_MODULE_5__.ElementRef), _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵdirectiveInject"](_ionic_angular__WEBPACK_IMPORTED_MODULE_6__.ModalController), _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵdirectiveInject"](src_app_core_shared_services_team_service__WEBPACK_IMPORTED_MODULE_3__.TeamService));
};

DetailChallengenModalPage.ɵcmp = /*@__PURE__*/_angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵdefineComponent"]({
  type: DetailChallengenModalPage,
  selectors: [["app-detail-modal"]],
  decls: 16,
  vars: 11,
  consts: [["color", "playgo"], ["slot", "end"], [3, "click"], ["name", "close-circle-outline"], ["color", "playgo", 1, "ion-padding"], [1, "ion-padding", 3, "innerHTML"], ["color", "light", "expand", "block", 3, "click"]],
  template: function DetailChallengenModalPage_Template(rf, ctx) {
    if (rf & 1) {
      _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵelementStart"](0, "ion-header")(1, "ion-toolbar", 0)(2, "ion-title");
      _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵtext"](3);
      _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵpipe"](4, "translate");
      _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵelementEnd"]();
      _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵelementStart"](5, "ion-buttons", 1)(6, "ion-button", 2);
      _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵlistener"]("click", function DetailChallengenModalPage_Template_ion_button_click_6_listener() {
        return ctx.close();
      });
      _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵelement"](7, "ion-icon", 3);
      _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵelementEnd"]()()()();
      _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵelementStart"](8, "ion-content", 4);
      _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵelement"](9, "div", 5);
      _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵpipe"](10, "languageMap");
      _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵpipe"](11, "async");
      _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵelementEnd"]();
      _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵelementStart"](12, "ion-footer", 0)(13, "ion-button", 6);
      _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵlistener"]("click", function DetailChallengenModalPage_Template_ion_button_click_13_listener() {
        return ctx.close();
      });
      _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵtext"](14);
      _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵpipe"](15, "translate");
      _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵelementEnd"]()();
    }

    if (rf & 2) {
      var tmp_1_0;
      _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵadvance"](3);
      _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵtextInterpolate"](_angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵpipeBind1"](4, 3, "challenges.detail.title"));
      _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵadvance"](6);
      _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵproperty"]("innerHTML", ctx.challDesc(_angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵpipeBind1"](10, 5, ctx.challenge == null ? null : ctx.challenge.challCompleteDesc), (tmp_1_0 = _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵpipeBind1"](11, 7, ctx.otherTeam$)) == null ? null : tmp_1_0.customData == null ? null : tmp_1_0.customData.name), _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵsanitizeHtml"]);
      _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵadvance"](5);
      _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵtextInterpolate"](_angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵpipeBind1"](15, 9, "challenges.detail.close"));
    }
  },
  directives: [_ionic_angular__WEBPACK_IMPORTED_MODULE_6__.IonHeader, _ionic_angular__WEBPACK_IMPORTED_MODULE_6__.IonToolbar, _ionic_angular__WEBPACK_IMPORTED_MODULE_6__.IonTitle, _ionic_angular__WEBPACK_IMPORTED_MODULE_6__.IonButtons, _ionic_angular__WEBPACK_IMPORTED_MODULE_6__.IonButton, _ionic_angular__WEBPACK_IMPORTED_MODULE_6__.IonIcon, _ionic_angular__WEBPACK_IMPORTED_MODULE_6__.IonContent, _ionic_angular__WEBPACK_IMPORTED_MODULE_6__.IonFooter],
  pipes: [_ngx_translate_core__WEBPACK_IMPORTED_MODULE_7__.TranslatePipe, _core_shared_pipes_languageMap_pipe__WEBPACK_IMPORTED_MODULE_4__.LanguageMapPipe, _angular_common__WEBPACK_IMPORTED_MODULE_8__.AsyncPipe],
  styles: ["\n/*# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbXSwibmFtZXMiOltdLCJtYXBwaW5ncyI6IiIsImZpbGUiOiJkZXRhaWwubW9kYWwuc2NzcyJ9 */"]
});

/***/ }),

/***/ 44286:
/*!***************************************************************************************!*\
  !*** ./src/app/pages/challenges/challenge-container/challenge-container.component.ts ***!
  \***************************************************************************************/
/***/ (function(__unused_webpack_module, __webpack_exports__, __webpack_require__) {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "ChallengeContainerComponent": function() { return /* binding */ ChallengeContainerComponent; }
/* harmony export */ });
/* harmony import */ var _Users_smartcommunitylab_Desktop_newWork_dslab_playgo_mobile_playgo_mobile_node_modules_babel_runtime_helpers_esm_classCallCheck_js__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./node_modules/@babel/runtime/helpers/esm/classCallCheck.js */ 78069);
/* harmony import */ var _Users_smartcommunitylab_Desktop_newWork_dslab_playgo_mobile_playgo_mobile_node_modules_babel_runtime_helpers_esm_createClass_js__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ./node_modules/@babel/runtime/helpers/esm/createClass.js */ 48047);
/* harmony import */ var src_app_core_shared_utils__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! src/app/core/shared/utils */ 68647);
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! @angular/core */ 3184);
/* harmony import */ var src_app_core_shared_services_campaign_service__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! src/app/core/shared/services/campaign.service */ 23645);






function ChallengeContainerComponent_ng_container_0_app_challenge_card_1_Template(rf, ctx) {
  if (rf & 1) {
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵelement"](0, "app-challenge-card", 3);
  }

  if (rf & 2) {
    var challenge_r1 = _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵnextContext"]().$implicit;
    var ctx_r2 = _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵnextContext"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵproperty"]("team", ctx_r2.team)("challenge", challenge_r1)("campaignContainer", ctx_r2.campaign)("type", ctx_r2.type);
  }
}

function ChallengeContainerComponent_ng_container_0_Template(rf, ctx) {
  if (rf & 1) {
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵelementContainerStart"](0);
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵtemplate"](1, ChallengeContainerComponent_ng_container_0_app_challenge_card_1_Template, 1, 4, "app-challenge-card", 2);
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵelementContainerEnd"]();
  }

  if (rf & 2) {
    var challenge_r1 = ctx.$implicit;
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵadvance"](1);
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵproperty"]("ngIf", challenge_r1.challengeType !== "PROPOSED");
  }
}

var ChallengeContainerComponent = /*#__PURE__*/function () {
  function ChallengeContainerComponent(campaignService) {
    (0,_Users_smartcommunitylab_Desktop_newWork_dslab_playgo_mobile_playgo_mobile_node_modules_babel_runtime_helpers_esm_classCallCheck_js__WEBPACK_IMPORTED_MODULE_0__["default"])(this, ChallengeContainerComponent);

    this.campaignService = campaignService;
    this.team = false;
    this.challengeTracking = (0,src_app_core_shared_utils__WEBPACK_IMPORTED_MODULE_2__.trackByProperty)('challId');
  }

  (0,_Users_smartcommunitylab_Desktop_newWork_dslab_playgo_mobile_playgo_mobile_node_modules_babel_runtime_helpers_esm_createClass_js__WEBPACK_IMPORTED_MODULE_1__["default"])(ChallengeContainerComponent, [{
    key: "ngOnInit",
    value: function ngOnInit() {}
  }, {
    key: "ngOnChanges",
    value: function ngOnChanges() {
      var _this = this;

      var _a, _b;

      this.challengeProposed = (_a = this.challenges) === null || _a === void 0 ? void 0 : _a.filter(function (challenge) {
        return challenge.challengeType === 'PROPOSED';
      });
      (_b = this.challenges) === null || _b === void 0 ? void 0 : _b.map(function (chall) {
        if (chall.challengeType === 'FUTURE' && chall.otherAttendeeData) {
          _this.canInvite = false;
        }
      }); // console.log(this.challengeProposed);
    }
  }]);

  return ChallengeContainerComponent;
}();

ChallengeContainerComponent.ɵfac = function ChallengeContainerComponent_Factory(t) {
  return new (t || ChallengeContainerComponent)(_angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵdirectiveInject"](src_app_core_shared_services_campaign_service__WEBPACK_IMPORTED_MODULE_3__.CampaignService));
};

ChallengeContainerComponent.ɵcmp = /*@__PURE__*/_angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵdefineComponent"]({
  type: ChallengeContainerComponent,
  selectors: [["app-challenge-container"]],
  inputs: {
    campaign: "campaign",
    challenges: "challenges",
    type: "type",
    canInvite: "canInvite",
    team: "team"
  },
  features: [_angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵNgOnChangesFeature"]],
  decls: 2,
  vars: 6,
  consts: [[4, "ngFor", "ngForOf", "ngForTrackBy"], [3, "challenges", "type", "campaign", "canInvite"], [3, "team", "challenge", "campaignContainer", "type", 4, "ngIf"], [3, "team", "challenge", "campaignContainer", "type"]],
  template: function ChallengeContainerComponent_Template(rf, ctx) {
    if (rf & 1) {
      _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵtemplate"](0, ChallengeContainerComponent_ng_container_0_Template, 2, 1, "ng-container", 0);
      _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵelement"](1, "app-challenges-proposed-card", 1);
    }

    if (rf & 2) {
      _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵproperty"]("ngForOf", ctx.challenges)("ngForTrackBy", ctx.challengeTracking);
      _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵadvance"](1);
      _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵproperty"]("challenges", ctx.challengeProposed)("type", ctx.type)("campaign", ctx.campaign)("canInvite", ctx.canInvite);
    }
  },
  styles: ["ion-card-title[_ngcontent-%COMP%] {\n  font-size: small;\n}\n/*# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbImNoYWxsZW5nZS1jb250YWluZXIuY29tcG9uZW50LnNjc3MiXSwibmFtZXMiOltdLCJtYXBwaW5ncyI6IkFBQUE7RUFDRSxnQkFBQTtBQUNGIiwiZmlsZSI6ImNoYWxsZW5nZS1jb250YWluZXIuY29tcG9uZW50LnNjc3MiLCJzb3VyY2VzQ29udGVudCI6WyJpb24tY2FyZC10aXRsZSB7XG4gIGZvbnQtc2l6ZTogc21hbGw7XG59XG4iXX0= */"]
});

/***/ }),

/***/ 8256:
/*!*************************************************************************************************!*\
  !*** ./src/app/pages/challenges/challenges-proposed-card/challenges-proposed-card.component.ts ***!
  \*************************************************************************************************/
/***/ (function(__unused_webpack_module, __webpack_exports__, __webpack_require__) {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "ChallengesProposedCardComponent": function() { return /* binding */ ChallengesProposedCardComponent; }
/* harmony export */ });
/* harmony import */ var _Users_smartcommunitylab_Desktop_newWork_dslab_playgo_mobile_playgo_mobile_node_modules_babel_runtime_helpers_esm_slicedToArray_js__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./node_modules/@babel/runtime/helpers/esm/slicedToArray.js */ 10507);
/* harmony import */ var _Users_smartcommunitylab_Desktop_newWork_dslab_playgo_mobile_playgo_mobile_node_modules_babel_runtime_helpers_esm_classCallCheck_js__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ./node_modules/@babel/runtime/helpers/esm/classCallCheck.js */ 78069);
/* harmony import */ var _Users_smartcommunitylab_Desktop_newWork_dslab_playgo_mobile_playgo_mobile_node_modules_babel_runtime_helpers_esm_createClass_js__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! ./node_modules/@babel/runtime/helpers/esm/createClass.js */ 48047);
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_17__ = __webpack_require__(/*! tslib */ 42321);
/* harmony import */ var rxjs__WEBPACK_IMPORTED_MODULE_14__ = __webpack_require__(/*! rxjs */ 26562);
/* harmony import */ var rxjs__WEBPACK_IMPORTED_MODULE_15__ = __webpack_require__(/*! rxjs */ 32673);
/* harmony import */ var rxjs__WEBPACK_IMPORTED_MODULE_16__ = __webpack_require__(/*! rxjs */ 10745);
/* harmony import */ var _info_challenge_single_modal_info_challenge_single_modal__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! ./info-challenge-single-modal/info-challenge-single.modal */ 79107);
/* harmony import */ var _info_challenge_group_modal_info_challenge_group_modal__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! ./info-challenge-group-modal/info-challenge-group.modal */ 36014);
/* harmony import */ var src_app_core_shared_campaigns_campaign_utils__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! src/app/core/shared/campaigns/campaign.utils */ 87725);
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_13__ = __webpack_require__(/*! @angular/core */ 3184);
/* harmony import */ var src_app_core_shared_services_campaign_service__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! src/app/core/shared/services/campaign.service */ 23645);
/* harmony import */ var _ionic_angular__WEBPACK_IMPORTED_MODULE_18__ = __webpack_require__(/*! @ionic/angular */ 93819);
/* harmony import */ var src_app_core_shared_services_challenge_service__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(/*! src/app/core/shared/services/challenge.service */ 66324);
/* harmony import */ var src_app_core_shared_services_user_service__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(/*! src/app/core/shared/services/user.service */ 50749);
/* harmony import */ var _angular_common__WEBPACK_IMPORTED_MODULE_19__ = __webpack_require__(/*! @angular/common */ 36362);
/* harmony import */ var _single_challenge_proposed_single_challenge_proposed_component__WEBPACK_IMPORTED_MODULE_9__ = __webpack_require__(/*! ../single-challenge-proposed/single-challenge-proposed.component */ 53051);
/* harmony import */ var _create_challenge_button_create_challenge_button_component__WEBPACK_IMPORTED_MODULE_10__ = __webpack_require__(/*! ../create-challenge-button/create-challenge-button.component */ 41988);
/* harmony import */ var _couple_challenge_proposed_couple_challenge_proposed_component__WEBPACK_IMPORTED_MODULE_11__ = __webpack_require__(/*! ../couple-challenge-proposed/couple-challenge-proposed.component */ 69537);
/* harmony import */ var _core_shared_pipes_languageMap_pipe__WEBPACK_IMPORTED_MODULE_12__ = __webpack_require__(/*! ../../../core/shared/pipes/languageMap.pipe */ 73088);
/* harmony import */ var _ngx_translate_core__WEBPACK_IMPORTED_MODULE_20__ = __webpack_require__(/*! @ngx-translate/core */ 87514);




function _regeneratorRuntime() { "use strict"; /*! regenerator-runtime -- Copyright (c) 2014-present, Facebook, Inc. -- license (MIT): https://github.com/facebook/regenerator/blob/main/LICENSE */ _regeneratorRuntime = function _regeneratorRuntime() { return e; }; var t, e = {}, r = Object.prototype, n = r.hasOwnProperty, o = Object.defineProperty || function (t, e, r) { t[e] = r.value; }, i = "function" == typeof Symbol ? Symbol : {}, a = i.iterator || "@@iterator", c = i.asyncIterator || "@@asyncIterator", u = i.toStringTag || "@@toStringTag"; function define(t, e, r) { return Object.defineProperty(t, e, { value: r, enumerable: !0, configurable: !0, writable: !0 }), t[e]; } try { define({}, ""); } catch (t) { define = function define(t, e, r) { return t[e] = r; }; } function wrap(t, e, r, n) { var i = e && e.prototype instanceof Generator ? e : Generator, a = Object.create(i.prototype), c = new Context(n || []); return o(a, "_invoke", { value: makeInvokeMethod(t, r, c) }), a; } function tryCatch(t, e, r) { try { return { type: "normal", arg: t.call(e, r) }; } catch (t) { return { type: "throw", arg: t }; } } e.wrap = wrap; var h = "suspendedStart", l = "suspendedYield", f = "executing", s = "completed", y = {}; function Generator() {} function GeneratorFunction() {} function GeneratorFunctionPrototype() {} var p = {}; define(p, a, function () { return this; }); var d = Object.getPrototypeOf, v = d && d(d(values([]))); v && v !== r && n.call(v, a) && (p = v); var g = GeneratorFunctionPrototype.prototype = Generator.prototype = Object.create(p); function defineIteratorMethods(t) { ["next", "throw", "return"].forEach(function (e) { define(t, e, function (t) { return this._invoke(e, t); }); }); } function AsyncIterator(t, e) { function invoke(r, o, i, a) { var c = tryCatch(t[r], t, o); if ("throw" !== c.type) { var u = c.arg, h = u.value; return h && "object" == typeof h && n.call(h, "__await") ? e.resolve(h.__await).then(function (t) { invoke("next", t, i, a); }, function (t) { invoke("throw", t, i, a); }) : e.resolve(h).then(function (t) { u.value = t, i(u); }, function (t) { return invoke("throw", t, i, a); }); } a(c.arg); } var r; o(this, "_invoke", { value: function value(t, n) { function callInvokeWithMethodAndArg() { return new e(function (e, r) { invoke(t, n, e, r); }); } return r = r ? r.then(callInvokeWithMethodAndArg, callInvokeWithMethodAndArg) : callInvokeWithMethodAndArg(); } }); } function makeInvokeMethod(e, r, n) { var o = h; return function (i, a) { if (o === f) throw new Error("Generator is already running"); if (o === s) { if ("throw" === i) throw a; return { value: t, done: !0 }; } for (n.method = i, n.arg = a;;) { var c = n.delegate; if (c) { var u = maybeInvokeDelegate(c, n); if (u) { if (u === y) continue; return u; } } if ("next" === n.method) n.sent = n._sent = n.arg;else if ("throw" === n.method) { if (o === h) throw o = s, n.arg; n.dispatchException(n.arg); } else "return" === n.method && n.abrupt("return", n.arg); o = f; var p = tryCatch(e, r, n); if ("normal" === p.type) { if (o = n.done ? s : l, p.arg === y) continue; return { value: p.arg, done: n.done }; } "throw" === p.type && (o = s, n.method = "throw", n.arg = p.arg); } }; } function maybeInvokeDelegate(e, r) { var n = r.method, o = e.iterator[n]; if (o === t) return r.delegate = null, "throw" === n && e.iterator.return && (r.method = "return", r.arg = t, maybeInvokeDelegate(e, r), "throw" === r.method) || "return" !== n && (r.method = "throw", r.arg = new TypeError("The iterator does not provide a '" + n + "' method")), y; var i = tryCatch(o, e.iterator, r.arg); if ("throw" === i.type) return r.method = "throw", r.arg = i.arg, r.delegate = null, y; var a = i.arg; return a ? a.done ? (r[e.resultName] = a.value, r.next = e.nextLoc, "return" !== r.method && (r.method = "next", r.arg = t), r.delegate = null, y) : a : (r.method = "throw", r.arg = new TypeError("iterator result is not an object"), r.delegate = null, y); } function pushTryEntry(t) { var e = { tryLoc: t[0] }; 1 in t && (e.catchLoc = t[1]), 2 in t && (e.finallyLoc = t[2], e.afterLoc = t[3]), this.tryEntries.push(e); } function resetTryEntry(t) { var e = t.completion || {}; e.type = "normal", delete e.arg, t.completion = e; } function Context(t) { this.tryEntries = [{ tryLoc: "root" }], t.forEach(pushTryEntry, this), this.reset(!0); } function values(e) { if (e || "" === e) { var r = e[a]; if (r) return r.call(e); if ("function" == typeof e.next) return e; if (!isNaN(e.length)) { var o = -1, i = function next() { for (; ++o < e.length;) if (n.call(e, o)) return next.value = e[o], next.done = !1, next; return next.value = t, next.done = !0, next; }; return i.next = i; } } throw new TypeError(typeof e + " is not iterable"); } return GeneratorFunction.prototype = GeneratorFunctionPrototype, o(g, "constructor", { value: GeneratorFunctionPrototype, configurable: !0 }), o(GeneratorFunctionPrototype, "constructor", { value: GeneratorFunction, configurable: !0 }), GeneratorFunction.displayName = define(GeneratorFunctionPrototype, u, "GeneratorFunction"), e.isGeneratorFunction = function (t) { var e = "function" == typeof t && t.constructor; return !!e && (e === GeneratorFunction || "GeneratorFunction" === (e.displayName || e.name)); }, e.mark = function (t) { return Object.setPrototypeOf ? Object.setPrototypeOf(t, GeneratorFunctionPrototype) : (t.__proto__ = GeneratorFunctionPrototype, define(t, u, "GeneratorFunction")), t.prototype = Object.create(g), t; }, e.awrap = function (t) { return { __await: t }; }, defineIteratorMethods(AsyncIterator.prototype), define(AsyncIterator.prototype, c, function () { return this; }), e.AsyncIterator = AsyncIterator, e.async = function (t, r, n, o, i) { void 0 === i && (i = Promise); var a = new AsyncIterator(wrap(t, r, n, o), i); return e.isGeneratorFunction(r) ? a : a.next().then(function (t) { return t.done ? t.value : a.next(); }); }, defineIteratorMethods(g), define(g, u, "Generator"), define(g, a, function () { return this; }), define(g, "toString", function () { return "[object Generator]"; }), e.keys = function (t) { var e = Object(t), r = []; for (var n in e) r.push(n); return r.reverse(), function next() { for (; r.length;) { var t = r.pop(); if (t in e) return next.value = t, next.done = !1, next; } return next.done = !0, next; }; }, e.values = values, Context.prototype = { constructor: Context, reset: function reset(e) { if (this.prev = 0, this.next = 0, this.sent = this._sent = t, this.done = !1, this.delegate = null, this.method = "next", this.arg = t, this.tryEntries.forEach(resetTryEntry), !e) for (var r in this) "t" === r.charAt(0) && n.call(this, r) && !isNaN(+r.slice(1)) && (this[r] = t); }, stop: function stop() { this.done = !0; var t = this.tryEntries[0].completion; if ("throw" === t.type) throw t.arg; return this.rval; }, dispatchException: function dispatchException(e) { if (this.done) throw e; var r = this; function handle(n, o) { return a.type = "throw", a.arg = e, r.next = n, o && (r.method = "next", r.arg = t), !!o; } for (var o = this.tryEntries.length - 1; o >= 0; --o) { var i = this.tryEntries[o], a = i.completion; if ("root" === i.tryLoc) return handle("end"); if (i.tryLoc <= this.prev) { var c = n.call(i, "catchLoc"), u = n.call(i, "finallyLoc"); if (c && u) { if (this.prev < i.catchLoc) return handle(i.catchLoc, !0); if (this.prev < i.finallyLoc) return handle(i.finallyLoc); } else if (c) { if (this.prev < i.catchLoc) return handle(i.catchLoc, !0); } else { if (!u) throw new Error("try statement without catch or finally"); if (this.prev < i.finallyLoc) return handle(i.finallyLoc); } } } }, abrupt: function abrupt(t, e) { for (var r = this.tryEntries.length - 1; r >= 0; --r) { var o = this.tryEntries[r]; if (o.tryLoc <= this.prev && n.call(o, "finallyLoc") && this.prev < o.finallyLoc) { var i = o; break; } } i && ("break" === t || "continue" === t) && i.tryLoc <= e && e <= i.finallyLoc && (i = null); var a = i ? i.completion : {}; return a.type = t, a.arg = e, i ? (this.method = "next", this.next = i.finallyLoc, y) : this.complete(a); }, complete: function complete(t, e) { if ("throw" === t.type) throw t.arg; return "break" === t.type || "continue" === t.type ? this.next = t.arg : "return" === t.type ? (this.rval = this.arg = t.arg, this.method = "return", this.next = "end") : "normal" === t.type && e && (this.next = e), y; }, finish: function finish(t) { for (var e = this.tryEntries.length - 1; e >= 0; --e) { var r = this.tryEntries[e]; if (r.finallyLoc === t) return this.complete(r.completion, r.afterLoc), resetTryEntry(r), y; } }, catch: function _catch(t) { for (var e = this.tryEntries.length - 1; e >= 0; --e) { var r = this.tryEntries[e]; if (r.tryLoc === t) { var n = r.completion; if ("throw" === n.type) { var o = n.arg; resetTryEntry(r); } return o; } } throw new Error("illegal catch attempt"); }, delegateYield: function delegateYield(e, r, n) { return this.delegate = { iterator: values(e), resultName: r, nextLoc: n }, "next" === this.method && (this.arg = t), y; } }, e; }


















function ChallengesProposedCardComponent_ion_card_0_div_9_app_single_challenge_proposed_5_Template(rf, ctx) {
  if (rf & 1) {
    _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵelement"](0, "app-single-challenge-proposed", 9);
  }

  if (rf & 2) {
    var chall_r4 = ctx.$implicit;
    var ctx_r3 = _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵnextContext"](3);
    _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵproperty"]("challenge", chall_r4)("campaign", ctx_r3.campaign);
  }
}

function ChallengesProposedCardComponent_ion_card_0_div_9_Template(rf, ctx) {
  if (rf & 1) {
    var _r6 = _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵgetCurrentView"]();

    _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵelementStart"](0, "div", 5)(1, "ion-icon", 6);
    _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵlistener"]("click", function ChallengesProposedCardComponent_ion_card_0_div_9_Template_ion_icon_click_1_listener() {
      _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵrestoreView"](_r6);
      var ctx_r5 = _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵnextContext"](2);
      return ctx_r5.openInfoChallengeSingle();
    });
    _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵelementEnd"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵelementStart"](2, "p", 7);
    _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵtext"](3);
    _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵpipe"](4, "translate");
    _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵelementEnd"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵtemplate"](5, ChallengesProposedCardComponent_ion_card_0_div_9_app_single_challenge_proposed_5_Template, 1, 2, "app-single-challenge-proposed", 8);
    _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵelementEnd"]();
  }

  if (rf & 2) {
    var ctx_r1 = _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵnextContext"](2);
    _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵadvance"](3);
    _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵtextInterpolate1"](" ", _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵpipeBind1"](4, 2, "challenges.choose_single"), " ");
    _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵadvance"](2);
    _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵproperty"]("ngForOf", ctx_r1.singleChallenges);
  }
}

function ChallengesProposedCardComponent_ion_card_0_div_10_app_create_challenge_button_5_Template(rf, ctx) {
  if (rf & 1) {
    var _r10 = _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵgetCurrentView"]();

    _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵelementStart"](0, "app-create-challenge-button", 12);
    _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵlistener"]("click", function ChallengesProposedCardComponent_ion_card_0_div_10_app_create_challenge_button_5_Template_app_create_challenge_button_click_0_listener($event) {
      _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵrestoreView"](_r10);
      var ctx_r9 = _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵnextContext"](3);
      return ctx_r9.goToCreateChallenge($event, ctx_r9.campaign);
    });
    _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵelementEnd"]();
  }

  if (rf & 2) {
    var ctx_r7 = _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵnextContext"](3);
    _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵproperty"]("campaign", ctx_r7.campaign);
  }
}

function ChallengesProposedCardComponent_ion_card_0_div_10_app_couple_challenge_proposed_7_Template(rf, ctx) {
  if (rf & 1) {
    _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵelement"](0, "app-couple-challenge-proposed", 9);
  }

  if (rf & 2) {
    var chall_r11 = ctx.$implicit;
    var ctx_r8 = _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵnextContext"](3);
    _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵproperty"]("challenge", chall_r11)("campaign", ctx_r8.campaign);
  }
}

function ChallengesProposedCardComponent_ion_card_0_div_10_Template(rf, ctx) {
  if (rf & 1) {
    var _r13 = _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵgetCurrentView"]();

    _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵelementStart"](0, "div", 5)(1, "ion-icon", 6);
    _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵlistener"]("click", function ChallengesProposedCardComponent_ion_card_0_div_10_Template_ion_icon_click_1_listener() {
      _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵrestoreView"](_r13);
      var ctx_r12 = _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵnextContext"](2);
      return ctx_r12.openInfoChallengeGroup();
    });
    _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵelementEnd"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵelementStart"](2, "p", 10);
    _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵtext"](3);
    _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵpipe"](4, "translate");
    _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵelementEnd"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵtemplate"](5, ChallengesProposedCardComponent_ion_card_0_div_10_app_create_challenge_button_5_Template, 1, 1, "app-create-challenge-button", 11);
    _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵpipe"](6, "async");
    _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵtemplate"](7, ChallengesProposedCardComponent_ion_card_0_div_10_app_couple_challenge_proposed_7_Template, 1, 2, "app-couple-challenge-proposed", 8);
    _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵelementEnd"]();
  }

  if (rf & 2) {
    var ctx_r2 = _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵnextContext"](2);
    _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵadvance"](3);
    _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵtextInterpolate1"](" ", _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵpipeBind1"](4, 3, "challenges.choose_or_configure"), " ");
    _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵadvance"](2);
    _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵproperty"]("ngIf", ctx_r2.canInvite && _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵpipeBind1"](6, 5, ctx_r2.sentInvitation$) === false);
    _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵadvance"](2);
    _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵproperty"]("ngForOf", ctx_r2.coupleChallenges);
  }
}

var _c0 = function _c0(a0) {
  return {
    "background-color": a0
  };
};

function ChallengesProposedCardComponent_ion_card_0_Template(rf, ctx) {
  if (rf & 1) {
    _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵelementStart"](0, "ion-card")(1, "ion-card-header", 1)(2, "span");
    _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵtext"](3);
    _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵpipe"](4, "languageMap");
    _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵelementEnd"]()();
    _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵelementStart"](5, "ion-card-content", 2)(6, "p", 3);
    _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵtext"](7);
    _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵpipe"](8, "translate");
    _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵelementEnd"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵtemplate"](9, ChallengesProposedCardComponent_ion_card_0_div_9_Template, 6, 4, "div", 4);
    _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵtemplate"](10, ChallengesProposedCardComponent_ion_card_0_div_10_Template, 8, 7, "div", 4);
    _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵpipe"](11, "async");
    _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵelementEnd"]()();
  }

  if (rf & 2) {
    var ctx_r0 = _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵnextContext"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵadvance"](1);
    _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵproperty"]("color", ctx_r0.campaign == null ? null : ctx_r0.campaign.campaign == null ? null : ctx_r0.campaign.campaign.type);
    _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵadvance"](2);
    _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵtextInterpolate"](_angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵpipeBind1"](4, 6, ctx_r0.campaign == null ? null : ctx_r0.campaign.campaign == null ? null : ctx_r0.campaign.campaign.name));
    _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵadvance"](2);
    _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵproperty"]("ngStyle", _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵpureFunction1"](12, _c0, "var(--ion-color-" + (ctx_r0.campaign == null ? null : ctx_r0.campaign.campaign == null ? null : ctx_r0.campaign.campaign.type) + "-light)"));
    _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵadvance"](2);
    _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵtextInterpolate"](_angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵpipeBind1"](8, 8, "challenges.proposed"));
    _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵadvance"](2);
    _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵproperty"]("ngIf", (ctx_r0.singleChallenges == null ? null : ctx_r0.singleChallenges.length) > 0);
    _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵadvance"](1);
    _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵproperty"]("ngIf", ctx_r0.canInvite && _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵpipeBind1"](11, 10, ctx_r0.sentInvitation$) === false || ctx_r0.coupleChallenges.length > 0);
  }
}

var ChallengesProposedCardComponent = /*#__PURE__*/function () {
  function ChallengesProposedCardComponent(campaignService, navCtrl, challengeService, userService, modalController) {
    (0,_Users_smartcommunitylab_Desktop_newWork_dslab_playgo_mobile_playgo_mobile_node_modules_babel_runtime_helpers_esm_classCallCheck_js__WEBPACK_IMPORTED_MODULE_1__["default"])(this, ChallengesProposedCardComponent);

    this.campaignService = campaignService;
    this.navCtrl = navCtrl;
    this.challengeService = challengeService;
    this.userService = userService;
    this.modalController = modalController;
    this.challenges = [];
    this.imgChallenge = src_app_core_shared_campaigns_campaign_utils__WEBPACK_IMPORTED_MODULE_5__.getImgChallenge;
    this.singleChallenges = [];
    this.coupleChallenges = [];
  }

  (0,_Users_smartcommunitylab_Desktop_newWork_dslab_playgo_mobile_playgo_mobile_node_modules_babel_runtime_helpers_esm_createClass_js__WEBPACK_IMPORTED_MODULE_2__["default"])(ChallengesProposedCardComponent, [{
    key: "ngOnInit",
    value: function ngOnInit() {
      this.sentInvitation$ = (0,rxjs__WEBPACK_IMPORTED_MODULE_14__.combineLatest)([this.userService.userProfile$, this.challengeService.futureChallenges$, this.challengeService.futureChallengesTeam$]).pipe((0,rxjs__WEBPACK_IMPORTED_MODULE_15__.switchMap)(function (_ref) {
        var _ref2 = (0,_Users_smartcommunitylab_Desktop_newWork_dslab_playgo_mobile_playgo_mobile_node_modules_babel_runtime_helpers_esm_slicedToArray_js__WEBPACK_IMPORTED_MODULE_0__["default"])(_ref, 3),
            profile = _ref2[0],
            challenges = _ref2[1],
            challengesTeam = _ref2[2];

        if (challenges.some(function (chall) {
          return chall.proposerId === profile.playerId;
        }) || challengesTeam.some(function (chall) {
          return chall.proposerId === profile.playerId;
        })) {
          return (0,rxjs__WEBPACK_IMPORTED_MODULE_16__.of)(true);
        }

        return (0,rxjs__WEBPACK_IMPORTED_MODULE_16__.of)(false);
      }));
    }
  }, {
    key: "ngOnChanges",
    value: function ngOnChanges() {
      var _a, _b; // console.log(this.canInvite);


      this.singleChallenges = (_a = this.challenges) === null || _a === void 0 ? void 0 : _a.filter(function (challenge) {
        return challenge.otherAttendeeData == null;
      });
      this.coupleChallenges = (_b = this.challenges) === null || _b === void 0 ? void 0 : _b.filter(function (challenge) {
        return challenge.otherAttendeeData != null;
      });
    }
  }, {
    key: "goToCreateChallenge",
    value: function goToCreateChallenge(event, campaign) {
      this.navCtrl.navigateRoot("/pages/tabs/challenges/create-challenge/".concat(campaign.campaign.campaignId));
    }
  }, {
    key: "openInfoChallengeSingle",
    value: function openInfoChallengeSingle() {
      return (0,tslib__WEBPACK_IMPORTED_MODULE_17__.__awaiter)(this, void 0, void 0, /*#__PURE__*/_regeneratorRuntime().mark(function _callee() {
        var modal;
        return _regeneratorRuntime().wrap(function _callee$(_context) {
          while (1) switch (_context.prev = _context.next) {
            case 0:
              _context.next = 2;
              return this.modalController.create({
                component: _info_challenge_single_modal_info_challenge_single_modal__WEBPACK_IMPORTED_MODULE_3__.InfoChallengeSingleModalPage,
                cssClass: 'modal-challenge',
                swipeToClose: true
              });

            case 2:
              modal = _context.sent;
              _context.next = 5;
              return modal.present();

            case 5:
              _context.next = 7;
              return modal.onWillDismiss();

            case 7:
            case "end":
              return _context.stop();
          }
        }, _callee, this);
      }));
    }
  }, {
    key: "openInfoChallengeGroup",
    value: function openInfoChallengeGroup() {
      return (0,tslib__WEBPACK_IMPORTED_MODULE_17__.__awaiter)(this, void 0, void 0, /*#__PURE__*/_regeneratorRuntime().mark(function _callee2() {
        var modal;
        return _regeneratorRuntime().wrap(function _callee2$(_context2) {
          while (1) switch (_context2.prev = _context2.next) {
            case 0:
              _context2.next = 2;
              return this.modalController.create({
                component: _info_challenge_group_modal_info_challenge_group_modal__WEBPACK_IMPORTED_MODULE_4__.InfoChallengeGroupModalPage,
                cssClass: 'modal-challenge',
                swipeToClose: true
              });

            case 2:
              modal = _context2.sent;
              _context2.next = 5;
              return modal.present();

            case 5:
              _context2.next = 7;
              return modal.onWillDismiss();

            case 7:
            case "end":
              return _context2.stop();
          }
        }, _callee2, this);
      }));
    }
  }]);

  return ChallengesProposedCardComponent;
}();

ChallengesProposedCardComponent.ɵfac = function ChallengesProposedCardComponent_Factory(t) {
  return new (t || ChallengesProposedCardComponent)(_angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵdirectiveInject"](src_app_core_shared_services_campaign_service__WEBPACK_IMPORTED_MODULE_6__.CampaignService), _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵdirectiveInject"](_ionic_angular__WEBPACK_IMPORTED_MODULE_18__.NavController), _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵdirectiveInject"](src_app_core_shared_services_challenge_service__WEBPACK_IMPORTED_MODULE_7__.ChallengeService), _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵdirectiveInject"](src_app_core_shared_services_user_service__WEBPACK_IMPORTED_MODULE_8__.UserService), _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵdirectiveInject"](_ionic_angular__WEBPACK_IMPORTED_MODULE_18__.ModalController));
};

ChallengesProposedCardComponent.ɵcmp = /*@__PURE__*/_angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵdefineComponent"]({
  type: ChallengesProposedCardComponent,
  selectors: [["app-challenges-proposed-card"]],
  inputs: {
    challenges: "challenges",
    campaign: "campaign",
    type: "type",
    canInvite: "canInvite"
  },
  features: [_angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵNgOnChangesFeature"]],
  decls: 2,
  vars: 3,
  consts: [[4, "ngIf"], [1, "header", 3, "color"], [3, "ngStyle"], [1, "text-proposed"], ["class", "container", 4, "ngIf"], [1, "container"], ["name", "information-circle-outline", 1, "popup-icon", 3, "click"], [1, "subtext-proposed"], [3, "challenge", "campaign", 4, "ngFor", "ngForOf"], [3, "challenge", "campaign"], [1, "ion-text-center", "subtext-proposed"], [3, "campaign", "click", 4, "ngIf"], [3, "campaign", "click"]],
  template: function ChallengesProposedCardComponent_Template(rf, ctx) {
    if (rf & 1) {
      _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵtemplate"](0, ChallengesProposedCardComponent_ion_card_0_Template, 12, 14, "ion-card", 0);
      _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵpipe"](1, "async");
    }

    if (rf & 2) {
      _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵproperty"]("ngIf", (ctx.singleChallenges == null ? null : ctx.singleChallenges.length) > 0 || ctx.canInvite && _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵpipeBind1"](1, 1, ctx.sentInvitation$) === false || ctx.coupleChallenges.length > 0);
    }
  },
  directives: [_angular_common__WEBPACK_IMPORTED_MODULE_19__.NgIf, _ionic_angular__WEBPACK_IMPORTED_MODULE_18__.IonCard, _ionic_angular__WEBPACK_IMPORTED_MODULE_18__.IonCardHeader, _ionic_angular__WEBPACK_IMPORTED_MODULE_18__.IonCardContent, _angular_common__WEBPACK_IMPORTED_MODULE_19__.NgStyle, _ionic_angular__WEBPACK_IMPORTED_MODULE_18__.IonIcon, _angular_common__WEBPACK_IMPORTED_MODULE_19__.NgForOf, _single_challenge_proposed_single_challenge_proposed_component__WEBPACK_IMPORTED_MODULE_9__.SingleChallengeProposedComponent, _create_challenge_button_create_challenge_button_component__WEBPACK_IMPORTED_MODULE_10__.CreateChallengeButtonComponent, _couple_challenge_proposed_couple_challenge_proposed_component__WEBPACK_IMPORTED_MODULE_11__.CoupleChallengeProposedComponent],
  pipes: [_angular_common__WEBPACK_IMPORTED_MODULE_19__.AsyncPipe, _core_shared_pipes_languageMap_pipe__WEBPACK_IMPORTED_MODULE_12__.LanguageMapPipe, _ngx_translate_core__WEBPACK_IMPORTED_MODULE_20__.TranslatePipe],
  styles: ["ion-card-title[_ngcontent-%COMP%] {\n  font-size: small;\n}\n\n.text-proposed[_ngcontent-%COMP%] {\n  text-align: center;\n  font-style: normal;\n  font-weight: 600;\n  font-size: 18px;\n  text-align: center;\n  color: #000000;\n}\n\n.subtext-proposed[_ngcontent-%COMP%] {\n  font-style: normal;\n  font-weight: 300;\n  font-size: 15px;\n  line-height: 18px;\n  text-align: center;\n  color: #000000;\n}\n\n.container[_ngcontent-%COMP%] {\n  position: relative;\n}\n\n.container[_ngcontent-%COMP%]   .popup-icon[_ngcontent-%COMP%] {\n  position: absolute;\n  right: 0px;\n  top: 0px;\n  font-size: 20px;\n}\n\n.header[_ngcontent-%COMP%] {\n  text-align: start;\n  padding: 4px;\n  font-style: italic;\n  font-weight: 300;\n  font-size: 13px;\n}\n\n.header[_ngcontent-%COMP%]   span[_ngcontent-%COMP%] {\n  margin-left: 18px;\n}\n/*# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbImNoYWxsZW5nZXMtcHJvcG9zZWQtY2FyZC5jb21wb25lbnQuc2NzcyJdLCJuYW1lcyI6W10sIm1hcHBpbmdzIjoiQUFBQTtFQUNFLGdCQUFBO0FBQ0Y7O0FBQ0E7RUFDRSxrQkFBQTtFQUNBLGtCQUFBO0VBQ0EsZ0JBQUE7RUFDQSxlQUFBO0VBQ0Esa0JBQUE7RUFDQSxjQUFBO0FBRUY7O0FBQUE7RUFDRSxrQkFBQTtFQUNBLGdCQUFBO0VBQ0EsZUFBQTtFQUNBLGlCQUFBO0VBQ0Esa0JBQUE7RUFDQSxjQUFBO0FBR0Y7O0FBREE7RUFDRSxrQkFBQTtBQUlGOztBQUhFO0VBQ0Usa0JBQUE7RUFDQSxVQUFBO0VBQ0EsUUFBQTtFQUNBLGVBQUE7QUFLSjs7QUFGQTtFQUNFLGlCQUFBO0VBQ0EsWUFBQTtFQUNBLGtCQUFBO0VBQ0EsZ0JBQUE7RUFDQSxlQUFBO0FBS0Y7O0FBSkU7RUFDRSxpQkFBQTtBQU1KIiwiZmlsZSI6ImNoYWxsZW5nZXMtcHJvcG9zZWQtY2FyZC5jb21wb25lbnQuc2NzcyIsInNvdXJjZXNDb250ZW50IjpbImlvbi1jYXJkLXRpdGxlIHtcbiAgZm9udC1zaXplOiBzbWFsbDtcbn1cbi50ZXh0LXByb3Bvc2VkIHtcbiAgdGV4dC1hbGlnbjogY2VudGVyO1xuICBmb250LXN0eWxlOiBub3JtYWw7XG4gIGZvbnQtd2VpZ2h0OiA2MDA7XG4gIGZvbnQtc2l6ZTogMThweDtcbiAgdGV4dC1hbGlnbjogY2VudGVyO1xuICBjb2xvcjogIzAwMDAwMDtcbn1cbi5zdWJ0ZXh0LXByb3Bvc2VkIHtcbiAgZm9udC1zdHlsZTogbm9ybWFsO1xuICBmb250LXdlaWdodDogMzAwO1xuICBmb250LXNpemU6IDE1cHg7XG4gIGxpbmUtaGVpZ2h0OiAxOHB4O1xuICB0ZXh0LWFsaWduOiBjZW50ZXI7XG4gIGNvbG9yOiAjMDAwMDAwO1xufVxuLmNvbnRhaW5lciB7XG4gIHBvc2l0aW9uOiByZWxhdGl2ZTtcbiAgLnBvcHVwLWljb24ge1xuICAgIHBvc2l0aW9uOiBhYnNvbHV0ZTtcbiAgICByaWdodDogMHB4O1xuICAgIHRvcDogMHB4O1xuICAgIGZvbnQtc2l6ZTogMjBweDtcbiAgfVxufVxuLmhlYWRlciB7XG4gIHRleHQtYWxpZ246IHN0YXJ0O1xuICBwYWRkaW5nOiA0cHg7XG4gIGZvbnQtc3R5bGU6IGl0YWxpYztcbiAgZm9udC13ZWlnaHQ6IDMwMDtcbiAgZm9udC1zaXplOiAxM3B4O1xuICBzcGFuIHtcbiAgICBtYXJnaW4tbGVmdDogMThweDtcbiAgfVxufVxuIl19 */"]
});

/***/ }),

/***/ 36014:
/*!********************************************************************************************************************!*\
  !*** ./src/app/pages/challenges/challenges-proposed-card/info-challenge-group-modal/info-challenge-group.modal.ts ***!
  \********************************************************************************************************************/
/***/ (function(__unused_webpack_module, __webpack_exports__, __webpack_require__) {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "InfoChallengeGroupModalPage": function() { return /* binding */ InfoChallengeGroupModalPage; }
/* harmony export */ });
/* harmony import */ var _Users_smartcommunitylab_Desktop_newWork_dslab_playgo_mobile_playgo_mobile_node_modules_babel_runtime_helpers_esm_classCallCheck_js__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./node_modules/@babel/runtime/helpers/esm/classCallCheck.js */ 78069);
/* harmony import */ var _Users_smartcommunitylab_Desktop_newWork_dslab_playgo_mobile_playgo_mobile_node_modules_babel_runtime_helpers_esm_createClass_js__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ./node_modules/@babel/runtime/helpers/esm/createClass.js */ 48047);
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @angular/core */ 3184);
/* harmony import */ var _ionic_angular__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @ionic/angular */ 93819);
/* harmony import */ var _ngx_translate_core__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! @ngx-translate/core */ 87514);





var _c0 = ["class", "modal"];
var InfoChallengeGroupModalPage = /*#__PURE__*/function () {
  function InfoChallengeGroupModalPage(modalController) {
    (0,_Users_smartcommunitylab_Desktop_newWork_dslab_playgo_mobile_playgo_mobile_node_modules_babel_runtime_helpers_esm_classCallCheck_js__WEBPACK_IMPORTED_MODULE_0__["default"])(this, InfoChallengeGroupModalPage);

    this.modalController = modalController;
  }

  (0,_Users_smartcommunitylab_Desktop_newWork_dslab_playgo_mobile_playgo_mobile_node_modules_babel_runtime_helpers_esm_createClass_js__WEBPACK_IMPORTED_MODULE_1__["default"])(InfoChallengeGroupModalPage, [{
    key: "ngOnInit",
    value: function ngOnInit() {}
  }, {
    key: "close",
    value: function close() {
      this.modalController.dismiss(false);
    }
  }]);

  return InfoChallengeGroupModalPage;
}();

InfoChallengeGroupModalPage.ɵfac = function InfoChallengeGroupModalPage_Factory(t) {
  return new (t || InfoChallengeGroupModalPage)(_angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵdirectiveInject"](_ionic_angular__WEBPACK_IMPORTED_MODULE_3__.ModalController));
};

InfoChallengeGroupModalPage.ɵcmp = /*@__PURE__*/_angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵdefineComponent"]({
  type: InfoChallengeGroupModalPage,
  selectors: [["app-info-challenge-group", 8, "modal"]],
  attrs: _c0,
  decls: 15,
  vars: 9,
  consts: [["color", "playgo"], ["slot", "end"], [3, "click"], ["name", "close-circle-outline"], ["color", "playgo", 1, "ion-padding"], [3, "innerHTML"], ["color", "light", "expand", "block", 3, "click"]],
  template: function InfoChallengeGroupModalPage_Template(rf, ctx) {
    if (rf & 1) {
      _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵelementStart"](0, "ion-header")(1, "ion-toolbar", 0)(2, "ion-title");
      _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵtext"](3);
      _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵpipe"](4, "translate");
      _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵelementEnd"]();
      _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵelementStart"](5, "ion-buttons", 1)(6, "ion-button", 2);
      _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵlistener"]("click", function InfoChallengeGroupModalPage_Template_ion_button_click_6_listener() {
        return ctx.close();
      });
      _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵelement"](7, "ion-icon", 3);
      _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵelementEnd"]()()()();
      _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵelementStart"](8, "ion-content", 4);
      _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵelement"](9, "div", 5);
      _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵpipe"](10, "translate");
      _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵelementEnd"]();
      _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵelementStart"](11, "ion-footer", 0)(12, "ion-button", 6);
      _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵlistener"]("click", function InfoChallengeGroupModalPage_Template_ion_button_click_12_listener() {
        return ctx.close();
      });
      _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵtext"](13);
      _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵpipe"](14, "translate");
      _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵelementEnd"]()();
    }

    if (rf & 2) {
      _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵadvance"](3);
      _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵtextInterpolate"](_angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵpipeBind1"](4, 3, "challenges.infogroup.title"));
      _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵadvance"](6);
      _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵproperty"]("innerHTML", _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵpipeBind1"](10, 5, "challenges.infogroup.body"), _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵsanitizeHtml"]);
      _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵadvance"](4);
      _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵtextInterpolate"](_angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵpipeBind1"](14, 7, "challenges.info.close"));
    }
  },
  directives: [_ionic_angular__WEBPACK_IMPORTED_MODULE_3__.IonHeader, _ionic_angular__WEBPACK_IMPORTED_MODULE_3__.IonToolbar, _ionic_angular__WEBPACK_IMPORTED_MODULE_3__.IonTitle, _ionic_angular__WEBPACK_IMPORTED_MODULE_3__.IonButtons, _ionic_angular__WEBPACK_IMPORTED_MODULE_3__.IonButton, _ionic_angular__WEBPACK_IMPORTED_MODULE_3__.IonIcon, _ionic_angular__WEBPACK_IMPORTED_MODULE_3__.IonContent, _ionic_angular__WEBPACK_IMPORTED_MODULE_3__.IonFooter],
  pipes: [_ngx_translate_core__WEBPACK_IMPORTED_MODULE_4__.TranslatePipe],
  styles: [".external[_ngcontent-%COMP%]   .title[_ngcontent-%COMP%] {\n  text-align: center;\n  font-weight: bold;\n  padding: 8px;\n}\n.external[_ngcontent-%COMP%]   .internal[_ngcontent-%COMP%]   .body[_ngcontent-%COMP%] {\n  text-align: justify;\n  padding: 8px;\n}\n/*# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbImluZm8tY2hhbGxlbmdlLWdyb3VwLm1vZGFsLnNjc3MiXSwibmFtZXMiOltdLCJtYXBwaW5ncyI6IkFBQ0U7RUFDRSxrQkFBQTtFQUNBLGlCQUFBO0VBQ0EsWUFBQTtBQUFKO0FBR0k7RUFDRSxtQkFBQTtFQUNBLFlBQUE7QUFETiIsImZpbGUiOiJpbmZvLWNoYWxsZW5nZS1ncm91cC5tb2RhbC5zY3NzIiwic291cmNlc0NvbnRlbnQiOlsiLmV4dGVybmFsIHtcbiAgLnRpdGxlIHtcbiAgICB0ZXh0LWFsaWduOiBjZW50ZXI7XG4gICAgZm9udC13ZWlnaHQ6IGJvbGQ7XG4gICAgcGFkZGluZzogOHB4O1xuICB9XG4gIC5pbnRlcm5hbCB7XG4gICAgLmJvZHkge1xuICAgICAgdGV4dC1hbGlnbjoganVzdGlmeTtcbiAgICAgIHBhZGRpbmc6IDhweDtcbiAgICB9XG4gIH1cbn1cbiJdfQ== */"]
});

/***/ }),

/***/ 79107:
/*!**********************************************************************************************************************!*\
  !*** ./src/app/pages/challenges/challenges-proposed-card/info-challenge-single-modal/info-challenge-single.modal.ts ***!
  \**********************************************************************************************************************/
/***/ (function(__unused_webpack_module, __webpack_exports__, __webpack_require__) {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "InfoChallengeSingleModalPage": function() { return /* binding */ InfoChallengeSingleModalPage; }
/* harmony export */ });
/* harmony import */ var _Users_smartcommunitylab_Desktop_newWork_dslab_playgo_mobile_playgo_mobile_node_modules_babel_runtime_helpers_esm_classCallCheck_js__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./node_modules/@babel/runtime/helpers/esm/classCallCheck.js */ 78069);
/* harmony import */ var _Users_smartcommunitylab_Desktop_newWork_dslab_playgo_mobile_playgo_mobile_node_modules_babel_runtime_helpers_esm_createClass_js__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ./node_modules/@babel/runtime/helpers/esm/createClass.js */ 48047);
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @angular/core */ 3184);
/* harmony import */ var _ionic_angular__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @ionic/angular */ 93819);
/* harmony import */ var _ngx_translate_core__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! @ngx-translate/core */ 87514);





var _c0 = ["class", "modal"];
var InfoChallengeSingleModalPage = /*#__PURE__*/function () {
  function InfoChallengeSingleModalPage(modalController) {
    (0,_Users_smartcommunitylab_Desktop_newWork_dslab_playgo_mobile_playgo_mobile_node_modules_babel_runtime_helpers_esm_classCallCheck_js__WEBPACK_IMPORTED_MODULE_0__["default"])(this, InfoChallengeSingleModalPage);

    this.modalController = modalController;
  }

  (0,_Users_smartcommunitylab_Desktop_newWork_dslab_playgo_mobile_playgo_mobile_node_modules_babel_runtime_helpers_esm_createClass_js__WEBPACK_IMPORTED_MODULE_1__["default"])(InfoChallengeSingleModalPage, [{
    key: "ngOnInit",
    value: function ngOnInit() {}
  }, {
    key: "close",
    value: function close() {
      this.modalController.dismiss(false);
    }
  }]);

  return InfoChallengeSingleModalPage;
}();

InfoChallengeSingleModalPage.ɵfac = function InfoChallengeSingleModalPage_Factory(t) {
  return new (t || InfoChallengeSingleModalPage)(_angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵdirectiveInject"](_ionic_angular__WEBPACK_IMPORTED_MODULE_3__.ModalController));
};

InfoChallengeSingleModalPage.ɵcmp = /*@__PURE__*/_angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵdefineComponent"]({
  type: InfoChallengeSingleModalPage,
  selectors: [["app-info-challenge", 8, "modal"]],
  attrs: _c0,
  decls: 15,
  vars: 9,
  consts: [["color", "playgo"], ["slot", "end"], [3, "click"], ["name", "close-circle-outline"], ["color", "playgo", 1, "ion-padding"], [3, "innerHTML"], ["color", "light", "expand", "block", 3, "click"]],
  template: function InfoChallengeSingleModalPage_Template(rf, ctx) {
    if (rf & 1) {
      _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵelementStart"](0, "ion-header")(1, "ion-toolbar", 0)(2, "ion-title");
      _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵtext"](3);
      _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵpipe"](4, "translate");
      _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵelementEnd"]();
      _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵelementStart"](5, "ion-buttons", 1)(6, "ion-button", 2);
      _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵlistener"]("click", function InfoChallengeSingleModalPage_Template_ion_button_click_6_listener() {
        return ctx.close();
      });
      _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵelement"](7, "ion-icon", 3);
      _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵelementEnd"]()()()();
      _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵelementStart"](8, "ion-content", 4);
      _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵelement"](9, "div", 5);
      _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵpipe"](10, "translate");
      _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵelementEnd"]();
      _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵelementStart"](11, "ion-footer", 0)(12, "ion-button", 6);
      _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵlistener"]("click", function InfoChallengeSingleModalPage_Template_ion_button_click_12_listener() {
        return ctx.close();
      });
      _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵtext"](13);
      _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵpipe"](14, "translate");
      _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵelementEnd"]()();
    }

    if (rf & 2) {
      _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵadvance"](3);
      _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵtextInterpolate"](_angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵpipeBind1"](4, 3, "challenges.info.title"));
      _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵadvance"](6);
      _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵproperty"]("innerHTML", _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵpipeBind1"](10, 5, "challenges.info.body"), _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵsanitizeHtml"]);
      _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵadvance"](4);
      _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵtextInterpolate"](_angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵpipeBind1"](14, 7, "challenges.info.close"));
    }
  },
  directives: [_ionic_angular__WEBPACK_IMPORTED_MODULE_3__.IonHeader, _ionic_angular__WEBPACK_IMPORTED_MODULE_3__.IonToolbar, _ionic_angular__WEBPACK_IMPORTED_MODULE_3__.IonTitle, _ionic_angular__WEBPACK_IMPORTED_MODULE_3__.IonButtons, _ionic_angular__WEBPACK_IMPORTED_MODULE_3__.IonButton, _ionic_angular__WEBPACK_IMPORTED_MODULE_3__.IonIcon, _ionic_angular__WEBPACK_IMPORTED_MODULE_3__.IonContent, _ionic_angular__WEBPACK_IMPORTED_MODULE_3__.IonFooter],
  pipes: [_ngx_translate_core__WEBPACK_IMPORTED_MODULE_4__.TranslatePipe],
  styles: [".external[_ngcontent-%COMP%]   .title[_ngcontent-%COMP%] {\n  text-align: center;\n  font-weight: bold;\n  padding: 8px;\n}\n.external[_ngcontent-%COMP%]   .internal[_ngcontent-%COMP%]   .body[_ngcontent-%COMP%] {\n  text-align: justify;\n  padding: 8px;\n}\n/*# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbImluZm8tY2hhbGxlbmdlLXNpbmdsZS5tb2RhbC5zY3NzIl0sIm5hbWVzIjpbXSwibWFwcGluZ3MiOiJBQUNFO0VBQ0Usa0JBQUE7RUFDQSxpQkFBQTtFQUNBLFlBQUE7QUFBSjtBQUdJO0VBQ0UsbUJBQUE7RUFDQSxZQUFBO0FBRE4iLCJmaWxlIjoiaW5mby1jaGFsbGVuZ2Utc2luZ2xlLm1vZGFsLnNjc3MiLCJzb3VyY2VzQ29udGVudCI6WyIuZXh0ZXJuYWwge1xuICAudGl0bGUge1xuICAgIHRleHQtYWxpZ246IGNlbnRlcjtcbiAgICBmb250LXdlaWdodDogYm9sZDtcbiAgICBwYWRkaW5nOiA4cHg7XG4gIH1cbiAgLmludGVybmFsIHtcbiAgICAuYm9keSB7XG4gICAgICB0ZXh0LWFsaWduOiBqdXN0aWZ5O1xuICAgICAgcGFkZGluZzogOHB4O1xuICAgIH1cbiAgfVxufVxuIl19 */"]
});

/***/ }),

/***/ 92351:
/*!***************************************************************!*\
  !*** ./src/app/pages/challenges/challenges-routing.module.ts ***!
  \***************************************************************/
/***/ (function(__unused_webpack_module, __webpack_exports__, __webpack_require__) {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "ChallengesRoutingModule": function() { return /* binding */ ChallengesRoutingModule; }
/* harmony export */ });
/* harmony import */ var _Users_smartcommunitylab_Desktop_newWork_dslab_playgo_mobile_playgo_mobile_node_modules_babel_runtime_helpers_esm_createClass_js__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./node_modules/@babel/runtime/helpers/esm/createClass.js */ 48047);
/* harmony import */ var _Users_smartcommunitylab_Desktop_newWork_dslab_playgo_mobile_playgo_mobile_node_modules_babel_runtime_helpers_esm_classCallCheck_js__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ./node_modules/@babel/runtime/helpers/esm/classCallCheck.js */ 78069);
/* harmony import */ var _angular_router__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! @angular/router */ 52816);
/* harmony import */ var _challenges_page__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! ./challenges.page */ 465);
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @angular/core */ 3184);






var routes = [{
  path: '',
  component: _challenges_page__WEBPACK_IMPORTED_MODULE_2__.ChallengesPage,
  data: {
    title: 'challenges.challenges',
    backButton: false,
    showPlayButton: true,
    refresher: true
  }
}, {
  path: 'create-challenge/:id',
  loadChildren: function loadChildren() {
    return Promise.all(/*! import() */[__webpack_require__.e("common"), __webpack_require__.e("src_app_pages_challenges_create-challenge_create-challenge_module_ts")]).then(__webpack_require__.bind(__webpack_require__, /*! ./create-challenge/create-challenge.module */ 22423)).then(function (m) {
      return m.CreateChallengePageModule;
    });
  }
}];
var ChallengesRoutingModule = /*#__PURE__*/(0,_Users_smartcommunitylab_Desktop_newWork_dslab_playgo_mobile_playgo_mobile_node_modules_babel_runtime_helpers_esm_createClass_js__WEBPACK_IMPORTED_MODULE_0__["default"])(function ChallengesRoutingModule() {
  (0,_Users_smartcommunitylab_Desktop_newWork_dslab_playgo_mobile_playgo_mobile_node_modules_babel_runtime_helpers_esm_classCallCheck_js__WEBPACK_IMPORTED_MODULE_1__["default"])(this, ChallengesRoutingModule);
});

ChallengesRoutingModule.ɵfac = function ChallengesRoutingModule_Factory(t) {
  return new (t || ChallengesRoutingModule)();
};

ChallengesRoutingModule.ɵmod = /*@__PURE__*/_angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵdefineNgModule"]({
  type: ChallengesRoutingModule
});
ChallengesRoutingModule.ɵinj = /*@__PURE__*/_angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵdefineInjector"]({
  imports: [[_angular_router__WEBPACK_IMPORTED_MODULE_4__.RouterModule.forChild(routes)], _angular_router__WEBPACK_IMPORTED_MODULE_4__.RouterModule]
});

(function () {
  (typeof ngJitMode === "undefined" || ngJitMode) && _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵsetNgModuleScope"](ChallengesRoutingModule, {
    imports: [_angular_router__WEBPACK_IMPORTED_MODULE_4__.RouterModule],
    exports: [_angular_router__WEBPACK_IMPORTED_MODULE_4__.RouterModule]
  });
})();

/***/ }),

/***/ 6301:
/*!***********************************************************************************************************!*\
  !*** ./src/app/pages/challenges/challenges-stat/challenge-single-stat/challenge-single-stat.component.ts ***!
  \***********************************************************************************************************/
/***/ (function(__unused_webpack_module, __webpack_exports__, __webpack_require__) {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "ChalengeSingleStatComponent": function() { return /* binding */ ChalengeSingleStatComponent; }
/* harmony export */ });
/* harmony import */ var _Users_smartcommunitylab_Desktop_newWork_dslab_playgo_mobile_playgo_mobile_node_modules_babel_runtime_helpers_esm_classCallCheck_js__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./node_modules/@babel/runtime/helpers/esm/classCallCheck.js */ 78069);
/* harmony import */ var _Users_smartcommunitylab_Desktop_newWork_dslab_playgo_mobile_playgo_mobile_node_modules_babel_runtime_helpers_esm_createClass_js__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ./node_modules/@babel/runtime/helpers/esm/createClass.js */ 48047);
/* harmony import */ var src_app_core_shared_campaigns_campaign_utils__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! src/app/core/shared/campaigns/campaign.utils */ 87725);
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! @angular/core */ 3184);
/* harmony import */ var _ngx_translate_core__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! @ngx-translate/core */ 87514);
/* harmony import */ var _core_shared_ui_icon_icon_component__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! ../../../../core/shared/ui/icon/icon.component */ 71888);
/* harmony import */ var _angular_common__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! @angular/common */ 36362);








function ChalengeSingleStatComponent_div_8_span_3_Template(rf, ctx) {
  if (rf & 1) {
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵelementStart"](0, "span");
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵtext"](1);
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵpipe"](2, "translate");
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵelementEnd"]();
  }

  if (rf & 2) {
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵadvance"](1);
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵtextInterpolate1"]("\xA0", _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵpipeBind1"](2, 1, "challenges.stats.singleChallengeWin.single"), "");
  }
}

function ChalengeSingleStatComponent_div_8_span_4_Template(rf, ctx) {
  if (rf & 1) {
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵelementStart"](0, "span");
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵtext"](1);
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵpipe"](2, "translate");
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵelementEnd"]();
  }

  if (rf & 2) {
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵadvance"](1);
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵtextInterpolate1"]("\xA0", _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵpipeBind1"](2, 1, "challenges.stats.singleChallengeWin.plural"), "");
  }
}

function ChalengeSingleStatComponent_div_8_Template(rf, ctx) {
  if (rf & 1) {
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵelementStart"](0, "div", 7)(1, "span");
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵtext"](2);
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵelementEnd"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵtemplate"](3, ChalengeSingleStatComponent_div_8_span_3_Template, 3, 3, "span", 8);
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵtemplate"](4, ChalengeSingleStatComponent_div_8_span_4_Template, 3, 3, "span", 8);
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵelementEnd"]();
  }

  if (rf & 2) {
    var ctx_r0 = _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵnextContext"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵadvance"](2);
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵtextInterpolate"](ctx_r0.stat.completed);
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵadvance"](1);
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵproperty"]("ngIf", ctx_r0.stat.completed <= 1);
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵadvance"](1);
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵproperty"]("ngIf", ctx_r0.stat.completed > 1);
  }
}

function ChalengeSingleStatComponent_div_9_span_3_Template(rf, ctx) {
  if (rf & 1) {
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵelementStart"](0, "span");
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵtext"](1);
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵpipe"](2, "translate");
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵelementEnd"]();
  }

  if (rf & 2) {
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵadvance"](1);
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵtextInterpolate1"]("\xA0", _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵpipeBind1"](2, 1, "challenges.stats.singleChallengeLost.single"), "");
  }
}

function ChalengeSingleStatComponent_div_9_span_4_Template(rf, ctx) {
  if (rf & 1) {
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵelementStart"](0, "span");
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵtext"](1);
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵpipe"](2, "translate");
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵelementEnd"]();
  }

  if (rf & 2) {
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵadvance"](1);
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵtextInterpolate1"]("\xA0", _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵpipeBind1"](2, 1, "challenges.stats.singleChallengeLost.plural"), "");
  }
}

function ChalengeSingleStatComponent_div_9_Template(rf, ctx) {
  if (rf & 1) {
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵelementStart"](0, "div", 9)(1, "span");
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵtext"](2);
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵelementEnd"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵtemplate"](3, ChalengeSingleStatComponent_div_9_span_3_Template, 3, 3, "span", 8);
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵtemplate"](4, ChalengeSingleStatComponent_div_9_span_4_Template, 3, 3, "span", 8);
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵelementEnd"]();
  }

  if (rf & 2) {
    var ctx_r1 = _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵnextContext"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵadvance"](2);
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵtextInterpolate"](ctx_r1.stat.failed);
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵadvance"](1);
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵproperty"]("ngIf", ctx_r1.stat.failed <= 1);
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵadvance"](1);
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵproperty"]("ngIf", ctx_r1.stat.failed > 1);
  }
}

var ChalengeSingleStatComponent = /*#__PURE__*/function () {
  function ChalengeSingleStatComponent(translateService) {
    (0,_Users_smartcommunitylab_Desktop_newWork_dslab_playgo_mobile_playgo_mobile_node_modules_babel_runtime_helpers_esm_classCallCheck_js__WEBPACK_IMPORTED_MODULE_0__["default"])(this, ChalengeSingleStatComponent);

    this.translateService = translateService;
    this.imgChallenge = src_app_core_shared_campaigns_campaign_utils__WEBPACK_IMPORTED_MODULE_2__.getImgChallenge;
  }

  (0,_Users_smartcommunitylab_Desktop_newWork_dslab_playgo_mobile_playgo_mobile_node_modules_babel_runtime_helpers_esm_createClass_js__WEBPACK_IMPORTED_MODULE_1__["default"])(ChalengeSingleStatComponent, [{
    key: "ngOnInit",
    value: function ngOnInit() {
      this.typeChallenge = this.kind === "school" && this.stat.type === 'single' ? this.translateService.instant('challenges.challenge_model.name.default-team') : this.translateService.instant((0,src_app_core_shared_campaigns_campaign_utils__WEBPACK_IMPORTED_MODULE_2__.getTypeStringChallenge)(this.stat.type));
    }
  }]);

  return ChalengeSingleStatComponent;
}();

ChalengeSingleStatComponent.ɵfac = function ChalengeSingleStatComponent_Factory(t) {
  return new (t || ChalengeSingleStatComponent)(_angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵdirectiveInject"](_ngx_translate_core__WEBPACK_IMPORTED_MODULE_5__.TranslateService));
};

ChalengeSingleStatComponent.ɵcmp = /*@__PURE__*/_angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵdefineComponent"]({
  type: ChalengeSingleStatComponent,
  selectors: [["app-challenge-single-stat"]],
  inputs: {
    stat: "stat",
    kind: "kind"
  },
  decls: 10,
  vars: 4,
  consts: [[1, "container"], [1, "single-stat-container"], [1, "single-stat-content"], [1, "ion-text-center"], [1, "icon-size-big", 3, "name"], ["class", "challenge-won", 4, "ngIf"], ["class", "challenge-lost", 4, "ngIf"], [1, "challenge-won"], [4, "ngIf"], [1, "challenge-lost"]],
  template: function ChalengeSingleStatComponent_Template(rf, ctx) {
    if (rf & 1) {
      _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵelementStart"](0, "div", 0)(1, "div", 1)(2, "div", 2)(3, "div", 3);
      _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵelement"](4, "app-icon", 4);
      _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵelementEnd"]();
      _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵelementStart"](5, "div", 3)(6, "div");
      _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵtext"](7);
      _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵelementEnd"]();
      _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵtemplate"](8, ChalengeSingleStatComponent_div_8_Template, 5, 3, "div", 5);
      _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵtemplate"](9, ChalengeSingleStatComponent_div_9_Template, 5, 3, "div", 6);
      _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵelementEnd"]()()()();
    }

    if (rf & 2) {
      _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵadvance"](4);
      _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵproperty"]("name", ctx.imgChallenge(ctx.stat.type));
      _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵadvance"](3);
      _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵtextInterpolate"](ctx.typeChallenge);
      _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵadvance"](1);
      _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵproperty"]("ngIf", ctx.stat.completed);
      _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵadvance"](1);
      _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵproperty"]("ngIf", ctx.stat.failed);
    }
  },
  directives: [_core_shared_ui_icon_icon_component__WEBPACK_IMPORTED_MODULE_3__.IconComponent, _angular_common__WEBPACK_IMPORTED_MODULE_6__.NgIf],
  pipes: [_ngx_translate_core__WEBPACK_IMPORTED_MODULE_5__.TranslatePipe],
  styles: [".container[_ngcontent-%COMP%] {\n  display: flex;\n  justify-content: center;\n}\n.container[_ngcontent-%COMP%]   .single-stat-container[_ngcontent-%COMP%] {\n  display: flex;\n  align-items: center;\n  justify-content: center;\n}\n.container[_ngcontent-%COMP%]   .single-stat-container[_ngcontent-%COMP%]   .single-stat-content[_ngcontent-%COMP%] {\n  width: 150px;\n  height: 150px;\n  border: solid 2px #ccc;\n  border-radius: 50%;\n  margin: auto;\n  font-size: 13px;\n}\n.container[_ngcontent-%COMP%]   .single-stat-container[_ngcontent-%COMP%]   .single-stat-content[_ngcontent-%COMP%]   .challenge-lost[_ngcontent-%COMP%] {\n  color: #c61010;\n  font-weight: 500;\n}\n.container[_ngcontent-%COMP%]   .single-stat-container[_ngcontent-%COMP%]   .single-stat-content[_ngcontent-%COMP%]   .challenge-won[_ngcontent-%COMP%] {\n  color: #359675;\n  font-weight: 500;\n}\n/*# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbImNoYWxsZW5nZS1zaW5nbGUtc3RhdC5jb21wb25lbnQuc2NzcyJdLCJuYW1lcyI6W10sIm1hcHBpbmdzIjoiQUFBQTtFQUNFLGFBQUE7RUFDQSx1QkFBQTtBQUNGO0FBQUU7RUFDRSxhQUFBO0VBQ0EsbUJBQUE7RUFDQSx1QkFBQTtBQUVKO0FBREk7RUFDRSxZQUFBO0VBQ0EsYUFBQTtFQUNBLHNCQUFBO0VBQ0Esa0JBQUE7RUFDQSxZQUFBO0VBQ0EsZUFBQTtBQUdOO0FBRk07RUFDRSxjQUFBO0VBQ0EsZ0JBQUE7QUFJUjtBQUZNO0VBQ0UsY0FBQTtFQUNBLGdCQUFBO0FBSVIiLCJmaWxlIjoiY2hhbGxlbmdlLXNpbmdsZS1zdGF0LmNvbXBvbmVudC5zY3NzIiwic291cmNlc0NvbnRlbnQiOlsiLmNvbnRhaW5lciB7XG4gIGRpc3BsYXk6IGZsZXg7XG4gIGp1c3RpZnktY29udGVudDogY2VudGVyO1xuICAuc2luZ2xlLXN0YXQtY29udGFpbmVyIHtcbiAgICBkaXNwbGF5OiBmbGV4O1xuICAgIGFsaWduLWl0ZW1zOiBjZW50ZXI7XG4gICAganVzdGlmeS1jb250ZW50OiBjZW50ZXI7XG4gICAgLnNpbmdsZS1zdGF0LWNvbnRlbnQge1xuICAgICAgd2lkdGg6IDE1MHB4O1xuICAgICAgaGVpZ2h0OiAxNTBweDtcbiAgICAgIGJvcmRlcjogc29saWQgMnB4ICNjY2M7XG4gICAgICBib3JkZXItcmFkaXVzOiA1MCU7XG4gICAgICBtYXJnaW46IGF1dG87XG4gICAgICBmb250LXNpemU6IDEzcHg7XG4gICAgICAuY2hhbGxlbmdlLWxvc3Qge1xuICAgICAgICBjb2xvcjogI2M2MTAxMDtcbiAgICAgICAgZm9udC13ZWlnaHQ6IDUwMDtcbiAgICAgIH1cbiAgICAgIC5jaGFsbGVuZ2Utd29uIHtcbiAgICAgICAgY29sb3I6ICMzNTk2NzU7XG4gICAgICAgIGZvbnQtd2VpZ2h0OiA1MDA7XG4gICAgICB9XG4gICAgfVxuICB9XG59XG4iXX0= */"]
});

/***/ }),

/***/ 56987:
/*!*******************************************************************************!*\
  !*** ./src/app/pages/challenges/challenges-stat/challenges-stat.component.ts ***!
  \*******************************************************************************/
/***/ (function(__unused_webpack_module, __webpack_exports__, __webpack_require__) {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "ChallengesStatComponent": function() { return /* binding */ ChallengesStatComponent; }
/* harmony export */ });
/* harmony import */ var _Users_smartcommunitylab_Desktop_newWork_dslab_playgo_mobile_playgo_mobile_node_modules_babel_runtime_helpers_esm_createForOfIteratorHelper_js__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./node_modules/@babel/runtime/helpers/esm/createForOfIteratorHelper.js */ 95106);
/* harmony import */ var _Users_smartcommunitylab_Desktop_newWork_dslab_playgo_mobile_playgo_mobile_node_modules_babel_runtime_helpers_esm_defineProperty_js__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ./node_modules/@babel/runtime/helpers/esm/defineProperty.js */ 77797);
/* harmony import */ var _Users_smartcommunitylab_Desktop_newWork_dslab_playgo_mobile_playgo_mobile_node_modules_babel_runtime_helpers_esm_slicedToArray_js__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! ./node_modules/@babel/runtime/helpers/esm/slicedToArray.js */ 10507);
/* harmony import */ var _Users_smartcommunitylab_Desktop_newWork_dslab_playgo_mobile_playgo_mobile_node_modules_babel_runtime_helpers_esm_classCallCheck_js__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! ./node_modules/@babel/runtime/helpers/esm/classCallCheck.js */ 78069);
/* harmony import */ var _Users_smartcommunitylab_Desktop_newWork_dslab_playgo_mobile_playgo_mobile_node_modules_babel_runtime_helpers_esm_createClass_js__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! ./node_modules/@babel/runtime/helpers/esm/createClass.js */ 48047);
/* harmony import */ var chart_js__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! chart.js */ 73905);
/* harmony import */ var luxon__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! luxon */ 20020);
/* harmony import */ var rxjs__WEBPACK_IMPORTED_MODULE_15__ = __webpack_require__(/*! rxjs */ 80228);
/* harmony import */ var rxjs__WEBPACK_IMPORTED_MODULE_16__ = __webpack_require__(/*! rxjs */ 50635);
/* harmony import */ var rxjs__WEBPACK_IMPORTED_MODULE_17__ = __webpack_require__(/*! rxjs */ 89196);
/* harmony import */ var rxjs__WEBPACK_IMPORTED_MODULE_18__ = __webpack_require__(/*! rxjs */ 44874);
/* harmony import */ var rxjs__WEBPACK_IMPORTED_MODULE_19__ = __webpack_require__(/*! rxjs */ 26562);
/* harmony import */ var rxjs__WEBPACK_IMPORTED_MODULE_20__ = __webpack_require__(/*! rxjs */ 98977);
/* harmony import */ var rxjs__WEBPACK_IMPORTED_MODULE_22__ = __webpack_require__(/*! rxjs */ 60116);
/* harmony import */ var rxjs__WEBPACK_IMPORTED_MODULE_23__ = __webpack_require__(/*! rxjs */ 32673);
/* harmony import */ var lodash_es__WEBPACK_IMPORTED_MODULE_21__ = __webpack_require__(/*! lodash-es */ 63247);
/* harmony import */ var src_app_core_shared_time_utils__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(/*! src/app/core/shared/time.utils */ 93462);
/* harmony import */ var src_app_core_shared_campaigns_campaign_utils__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(/*! src/app/core/shared/campaigns/campaign.utils */ 87725);
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_14__ = __webpack_require__(/*! @angular/core */ 3184);
/* harmony import */ var src_app_core_shared_services_challenge_service__WEBPACK_IMPORTED_MODULE_9__ = __webpack_require__(/*! src/app/core/shared/services/challenge.service */ 66324);
/* harmony import */ var src_app_core_shared_services_user_service__WEBPACK_IMPORTED_MODULE_10__ = __webpack_require__(/*! src/app/core/shared/services/user.service */ 50749);
/* harmony import */ var src_app_core_shared_services_error_service__WEBPACK_IMPORTED_MODULE_11__ = __webpack_require__(/*! src/app/core/shared/services/error.service */ 96204);
/* harmony import */ var _ionic_angular__WEBPACK_IMPORTED_MODULE_24__ = __webpack_require__(/*! @ionic/angular */ 93819);
/* harmony import */ var _angular_common__WEBPACK_IMPORTED_MODULE_25__ = __webpack_require__(/*! @angular/common */ 36362);
/* harmony import */ var _angular_forms__WEBPACK_IMPORTED_MODULE_26__ = __webpack_require__(/*! @angular/forms */ 90587);
/* harmony import */ var _challenge_single_stat_challenge_single_stat_component__WEBPACK_IMPORTED_MODULE_12__ = __webpack_require__(/*! ./challenge-single-stat/challenge-single-stat.component */ 6301);
/* harmony import */ var _ngx_translate_core__WEBPACK_IMPORTED_MODULE_27__ = __webpack_require__(/*! @ngx-translate/core */ 87514);
/* harmony import */ var _core_shared_pipes_languageMap_pipe__WEBPACK_IMPORTED_MODULE_13__ = __webpack_require__(/*! ../../../core/shared/pipes/languageMap.pipe */ 73088);





















var _c0 = ["barCanvas"];

function ChallengesStatComponent_ion_select_6_ion_select_option_2_Template(rf, ctx) {
  if (rf & 1) {
    _angular_core__WEBPACK_IMPORTED_MODULE_14__["ɵɵelementStart"](0, "ion-select-option", 18);
    _angular_core__WEBPACK_IMPORTED_MODULE_14__["ɵɵtext"](1);
    _angular_core__WEBPACK_IMPORTED_MODULE_14__["ɵɵpipe"](2, "languageMap");
    _angular_core__WEBPACK_IMPORTED_MODULE_14__["ɵɵelementEnd"]();
  }

  if (rf & 2) {
    var campaign_r8 = ctx.$implicit;
    _angular_core__WEBPACK_IMPORTED_MODULE_14__["ɵɵproperty"]("value", campaign_r8);
    _angular_core__WEBPACK_IMPORTED_MODULE_14__["ɵɵadvance"](1);
    _angular_core__WEBPACK_IMPORTED_MODULE_14__["ɵɵtextInterpolate1"](" ", _angular_core__WEBPACK_IMPORTED_MODULE_14__["ɵɵpipeBind1"](2, 2, campaign_r8.campaign.name), " ");
  }
}

var _c1 = function _c1() {
  return {
    cssClass: "app-alert"
  };
};

function ChallengesStatComponent_ion_select_6_Template(rf, ctx) {
  if (rf & 1) {
    var _r10 = _angular_core__WEBPACK_IMPORTED_MODULE_14__["ɵɵgetCurrentView"]();

    _angular_core__WEBPACK_IMPORTED_MODULE_14__["ɵɵelementStart"](0, "ion-select", 16);
    _angular_core__WEBPACK_IMPORTED_MODULE_14__["ɵɵlistener"]("ionChange", function ChallengesStatComponent_ion_select_6_Template_ion_select_ionChange_0_listener($event) {
      _angular_core__WEBPACK_IMPORTED_MODULE_14__["ɵɵrestoreView"](_r10);
      var ctx_r9 = _angular_core__WEBPACK_IMPORTED_MODULE_14__["ɵɵnextContext"]();
      return ctx_r9.campaignChangedSubject.next($event);
    });
    _angular_core__WEBPACK_IMPORTED_MODULE_14__["ɵɵpipe"](1, "async");
    _angular_core__WEBPACK_IMPORTED_MODULE_14__["ɵɵtemplate"](2, ChallengesStatComponent_ion_select_6_ion_select_option_2_Template, 3, 4, "ion-select-option", 17);
    _angular_core__WEBPACK_IMPORTED_MODULE_14__["ɵɵelementEnd"]();
  }

  if (rf & 2) {
    var ctx_r0 = _angular_core__WEBPACK_IMPORTED_MODULE_14__["ɵɵnextContext"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_14__["ɵɵproperty"]("interfaceOptions", _angular_core__WEBPACK_IMPORTED_MODULE_14__["ɵɵpureFunction0"](5, _c1))("value", _angular_core__WEBPACK_IMPORTED_MODULE_14__["ɵɵpipeBind1"](1, 3, ctx_r0.selectedCampaign$));
    _angular_core__WEBPACK_IMPORTED_MODULE_14__["ɵɵadvance"](2);
    _angular_core__WEBPACK_IMPORTED_MODULE_14__["ɵɵproperty"]("ngForOf", ctx_r0.campaigns);
  }
}

function ChallengesStatComponent_ng_template_7_Template(rf, ctx) {
  if (rf & 1) {
    _angular_core__WEBPACK_IMPORTED_MODULE_14__["ɵɵelementStart"](0, "ion-label");
    _angular_core__WEBPACK_IMPORTED_MODULE_14__["ɵɵtext"](1);
    _angular_core__WEBPACK_IMPORTED_MODULE_14__["ɵɵpipe"](2, "translate");
    _angular_core__WEBPACK_IMPORTED_MODULE_14__["ɵɵelementEnd"]();
  }

  if (rf & 2) {
    _angular_core__WEBPACK_IMPORTED_MODULE_14__["ɵɵadvance"](1);
    _angular_core__WEBPACK_IMPORTED_MODULE_14__["ɵɵtextInterpolate1"](" ", _angular_core__WEBPACK_IMPORTED_MODULE_14__["ɵɵpipeBind1"](2, 1, "challenges.stats.filter.no_campaigns"), "");
  }
}

function ChallengesStatComponent_ion_segment_button_10_Template(rf, ctx) {
  if (rf & 1) {
    _angular_core__WEBPACK_IMPORTED_MODULE_14__["ɵɵelementStart"](0, "ion-segment-button", 19)(1, "ion-label");
    _angular_core__WEBPACK_IMPORTED_MODULE_14__["ɵɵtext"](2);
    _angular_core__WEBPACK_IMPORTED_MODULE_14__["ɵɵpipe"](3, "translate");
    _angular_core__WEBPACK_IMPORTED_MODULE_14__["ɵɵelementEnd"]()();
  }

  if (rf & 2) {
    var period_r11 = ctx.$implicit;
    _angular_core__WEBPACK_IMPORTED_MODULE_14__["ɵɵstyleProp"]("--color", "white")("--color-checked", "black");
    _angular_core__WEBPACK_IMPORTED_MODULE_14__["ɵɵproperty"]("value", period_r11);
    _angular_core__WEBPACK_IMPORTED_MODULE_14__["ɵɵadvance"](2);
    _angular_core__WEBPACK_IMPORTED_MODULE_14__["ɵɵtextInterpolate"](_angular_core__WEBPACK_IMPORTED_MODULE_14__["ɵɵpipeBind1"](3, 6, period_r11.labelKey));
  }
}

function ChallengesStatComponent_div_27_ion_col_3_Template(rf, ctx) {
  if (rf & 1) {
    _angular_core__WEBPACK_IMPORTED_MODULE_14__["ɵɵelementStart"](0, "ion-col");
    _angular_core__WEBPACK_IMPORTED_MODULE_14__["ɵɵelement"](1, "app-challenge-single-stat", 21);
    _angular_core__WEBPACK_IMPORTED_MODULE_14__["ɵɵpipe"](2, "async");
    _angular_core__WEBPACK_IMPORTED_MODULE_14__["ɵɵelementEnd"]();
  }

  if (rf & 2) {
    var stat_r13 = ctx.$implicit;
    var ctx_r12 = _angular_core__WEBPACK_IMPORTED_MODULE_14__["ɵɵnextContext"](2);
    var tmp_1_0;
    _angular_core__WEBPACK_IMPORTED_MODULE_14__["ɵɵadvance"](1);
    _angular_core__WEBPACK_IMPORTED_MODULE_14__["ɵɵproperty"]("stat", stat_r13)("kind", (tmp_1_0 = _angular_core__WEBPACK_IMPORTED_MODULE_14__["ɵɵpipeBind1"](2, 2, ctx_r12.selectedCampaign$)) == null ? null : tmp_1_0.campaign == null ? null : tmp_1_0.campaign.type);
  }
}

function ChallengesStatComponent_div_27_Template(rf, ctx) {
  if (rf & 1) {
    _angular_core__WEBPACK_IMPORTED_MODULE_14__["ɵɵelementStart"](0, "div")(1, "ion-grid")(2, "ion-row");
    _angular_core__WEBPACK_IMPORTED_MODULE_14__["ɵɵtemplate"](3, ChallengesStatComponent_div_27_ion_col_3_Template, 3, 4, "ion-col", 20);
    _angular_core__WEBPACK_IMPORTED_MODULE_14__["ɵɵelementEnd"]()()();
  }

  if (rf & 2) {
    var ctx_r4 = _angular_core__WEBPACK_IMPORTED_MODULE_14__["ɵɵnextContext"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_14__["ɵɵadvance"](3);
    _angular_core__WEBPACK_IMPORTED_MODULE_14__["ɵɵproperty"]("ngForOf", ctx_r4.stats);
  }
}

function ChallengesStatComponent_ng_template_28_Template(rf, ctx) {
  if (rf & 1) {
    _angular_core__WEBPACK_IMPORTED_MODULE_14__["ɵɵelement"](0, "canvas", 22, 23);
  }
}

var _c2 = function _c2(a0) {
  return {
    borderBottomColor: a0
  };
};

var _c3 = function _c3(a0) {
  return {
    totalChallenges: a0
  };
};

var _c4 = function _c4(a0) {
  return {
    totalWon: a0
  };
};

var ChallengesStatComponent = /*#__PURE__*/function () {
  function ChallengesStatComponent(challengeService, userService, errorService) {
    var _this = this;

    (0,_Users_smartcommunitylab_Desktop_newWork_dslab_playgo_mobile_playgo_mobile_node_modules_babel_runtime_helpers_esm_classCallCheck_js__WEBPACK_IMPORTED_MODULE_3__["default"])(this, ChallengesStatComponent);

    this.challengeService = challengeService;
    this.userService = userService;
    this.errorService = errorService;
    this.campaignChangedSubject = new rxjs__WEBPACK_IMPORTED_MODULE_15__.Subject();
    this.statPeriodChangedSubject = new rxjs__WEBPACK_IMPORTED_MODULE_15__.Subject();
    this.campaigns$ = this.challengeService.campaignsWithChallenges$;
    this.referenceDate = luxon__WEBPACK_IMPORTED_MODULE_6__.DateTime.local().minus({
      weeks: 1
    });
    this.periods = (0,src_app_core_shared_campaigns_campaign_utils__WEBPACK_IMPORTED_MODULE_8__.getPeriods)(this.referenceDate);
    this.totalChallenges = 0;
    this.totalWon = 0;
    this.selectedPeriod = this.periods[0];
    this.playerId$ = this.userService.userProfile$.pipe((0,rxjs__WEBPACK_IMPORTED_MODULE_16__.map)(function (userProfile) {
      return userProfile.playerId;
    }), (0,rxjs__WEBPACK_IMPORTED_MODULE_17__.shareReplay)(1));
    this.selectedCampaign$ = this.campaignChangedSubject.pipe((0,rxjs__WEBPACK_IMPORTED_MODULE_16__.map)(function (event) {
      return event.detail.value;
    }), (0,rxjs__WEBPACK_IMPORTED_MODULE_17__.shareReplay)(1));
    this.selectedPeriod$ = this.statPeriodChangedSubject.pipe((0,rxjs__WEBPACK_IMPORTED_MODULE_16__.map)(function (period) {
      _this.selectedPeriod = period;
      return _this.getPeriodByReference(period);
    }), (0,rxjs__WEBPACK_IMPORTED_MODULE_18__.startWith)(this.periods[0]), (0,rxjs__WEBPACK_IMPORTED_MODULE_17__.shareReplay)(1));
    this.filterOptions$ = (0,rxjs__WEBPACK_IMPORTED_MODULE_19__.combineLatest)([this.selectedCampaign$, this.selectedPeriod$, this.playerId$.pipe((0,rxjs__WEBPACK_IMPORTED_MODULE_20__.distinctUntilChanged)(lodash_es__WEBPACK_IMPORTED_MODULE_21__["default"]))]).pipe((0,rxjs__WEBPACK_IMPORTED_MODULE_16__.map)(function (_ref) {
      var _ref2 = (0,_Users_smartcommunitylab_Desktop_newWork_dslab_playgo_mobile_playgo_mobile_node_modules_babel_runtime_helpers_esm_slicedToArray_js__WEBPACK_IMPORTED_MODULE_2__["default"])(_ref, 3),
          campaign = _ref2[0],
          period = _ref2[1],
          playerId = _ref2[2];

      return {
        campaign: campaign,
        period: period,
        playerId: playerId
      };
    }));
    this.statResponse$ = this.filterOptions$.pipe((0,rxjs__WEBPACK_IMPORTED_MODULE_22__.filter)(function (obj) {
      return obj.campaign != null;
    }), (0,rxjs__WEBPACK_IMPORTED_MODULE_23__.switchMap)(function (_ref3) {
      var campaign = _ref3.campaign,
          period = _ref3.period,
          playerId = _ref3.playerId;

      var _a;

      return _this.challengeService.getChallengeStats({
        campaignId: (_a = campaign === null || campaign === void 0 ? void 0 : campaign.campaign) === null || _a === void 0 ? void 0 : _a.campaignId,
        playerId: playerId,
        groupMode: period.group,
        dateFrom: (0,src_app_core_shared_time_utils__WEBPACK_IMPORTED_MODULE_7__.toServerDateOnly)(period.from),
        dateTo: (0,src_app_core_shared_time_utils__WEBPACK_IMPORTED_MODULE_7__.toServerDateOnly)(period.to)
      }).pipe(_this.errorService.getErrorHandler());
    }));
    this.statsSubs = this.statResponse$.subscribe(function (stats) {
      _this.stats = _this.groupStat(stats);

      _this.setChart(stats);

      _this.setTotal(stats);
    });
    this.campaignsSubs = this.campaigns$.subscribe(function (campaigns) {
      _this.campaigns = campaigns;

      _this.campaignChangedSubject.next({
        detail: {
          value: campaigns[0]
        }
      });
    });
  }

  (0,_Users_smartcommunitylab_Desktop_newWork_dslab_playgo_mobile_playgo_mobile_node_modules_babel_runtime_helpers_esm_createClass_js__WEBPACK_IMPORTED_MODULE_4__["default"])(ChallengesStatComponent, [{
    key: "groupStat",
    value: function groupStat(stats) {
      var holder = {};
      stats.forEach(function (d) {
        //check even the type if is not group or survey put everything in the same
        if ((d === null || d === void 0 ? void 0 : d.type) !== 'groupCooperative' && (d === null || d === void 0 ? void 0 : d.type) !== 'groupCompetitiveTime' && (d === null || d === void 0 ? void 0 : d.type) !== 'groupCompetitivePerformance' && (d === null || d === void 0 ? void 0 : d.type) !== 'survey') {
          d.type = 'single';
        }

        if (holder.hasOwnProperty(d.type)) {
          holder[d.type].completed = holder[d.type].completed + d.completed;
          holder[d.type].failed = holder[d.type].failed + d.failed;
        } else {
          holder[d.type] = {};
          holder[d.type].completed = d.completed;
          holder[d.type].failed = d.failed;
        }
      });
      var obj2 = []; // eslint-disable-next-line guard-for-in

      for (var prop in holder) {
        obj2.push({
          type: prop,
          completed: holder[prop].completed,
          failed: holder[prop].failed
        });
      }

      return obj2; //   //group stat if not know type
      //   let returnStats: ChallengeStatsInfo[] = [];
      //   stats.forEach(stat => {
      //     if (stat.type !== 'groupCooperative' &&
      //       stat?.type !== 'groupCompetitiveTime' &&
      //       stat?.type !== 'groupCompetitivePerformance' && stat?.type!== 'survey') {
      //         returnStats
      //       }
      // })
      // }
      //   return returnStats;
    }
  }, {
    key: "setTotal",
    value: function setTotal(stats) {
      this.totalChallenges = stats.map(function (stat) {
        return (stat === null || stat === void 0 ? void 0 : stat.completed) + (stat === null || stat === void 0 ? void 0 : stat.failed);
      }).reduce(function (prev, next) {
        return prev + next;
      }, 0);
      this.totalWon = stats.map(function (stat) {
        return (stat === null || stat === void 0 ? void 0 : stat.completed) > 0 ? stat.completed : 0;
      }).reduce(function (prev, next) {
        return prev + next;
      }, 0);
    }
  }, {
    key: "ngOnDestroy",
    value: function ngOnDestroy() {
      this.statsSubs.unsubscribe();
      this.campaignsSubs.unsubscribe();
    }
  }, {
    key: "ngOnInit",
    value: function ngOnInit() {
      this.selectedSegment = this.periods[0];
    }
  }, {
    key: "segmentChanged",
    value: function segmentChanged(ev) {// console.log('Segment changed, change the selected period', ev);
    }
  }, {
    key: "backPeriod",
    value: function backPeriod() {
      var _this2 = this;

      //change referenceDate
      this.referenceDate = this.referenceDate.plus((0,_Users_smartcommunitylab_Desktop_newWork_dslab_playgo_mobile_playgo_mobile_node_modules_babel_runtime_helpers_esm_defineProperty_js__WEBPACK_IMPORTED_MODULE_1__["default"])({}, this.selectedPeriod.add, -1)); //only get but it doesn't write on subject

      this.periods = (0,src_app_core_shared_campaigns_campaign_utils__WEBPACK_IMPORTED_MODULE_8__.getPeriods)(this.referenceDate);
      var tabIndex = this.periods.findIndex(function (period) {
        return period.group === _this2.selectedPeriod.group;
      });
      this.selectedSegment = this.periods[tabIndex];
      this.statPeriodChangedSubject.next(this.periods[tabIndex]);
    }
  }, {
    key: "forwardPeriod",
    value: function forwardPeriod() {
      var _this3 = this;

      this.referenceDate = this.referenceDate.plus((0,_Users_smartcommunitylab_Desktop_newWork_dslab_playgo_mobile_playgo_mobile_node_modules_babel_runtime_helpers_esm_defineProperty_js__WEBPACK_IMPORTED_MODULE_1__["default"])({}, this.selectedPeriod.add, 1));
      this.periods = (0,src_app_core_shared_campaigns_campaign_utils__WEBPACK_IMPORTED_MODULE_8__.getPeriods)(this.referenceDate);
      var tabIndex = this.periods.findIndex(function (period) {
        return period.group === _this3.selectedPeriod.group;
      });
      this.selectedSegment = this.periods[tabIndex];
      this.statPeriodChangedSubject.next(this.periods[tabIndex]);
    }
  }, {
    key: "getSelectedPeriod",
    value: function getSelectedPeriod() {
      return this.selectedPeriod.from.toFormat(this.selectedPeriod.label);
    }
  }, {
    key: "getPeriodByReference",
    value: function getPeriodByReference(value) {
      return this.periods.find(function (period) {
        return period.group === value.group;
      });
    }
  }, {
    key: "isWeekSelected",
    value: function isWeekSelected() {
      return this.selectedPeriod.add === 'week';
    }
  }, {
    key: "setChart",
    value: function setChart(stats) {
      var _this4 = this;

      // Now we need to supply a Chart element reference with an
      //object that defines the type of chart we want to use, and the type of data we want to display.
      // console.log('setChart based on selected tab', this.selectedPeriod);
      chart_js__WEBPACK_IMPORTED_MODULE_5__.Chart.register(chart_js__WEBPACK_IMPORTED_MODULE_5__.LineController, chart_js__WEBPACK_IMPORTED_MODULE_5__.BarController, chart_js__WEBPACK_IMPORTED_MODULE_5__.CategoryScale, chart_js__WEBPACK_IMPORTED_MODULE_5__.LinearScale, chart_js__WEBPACK_IMPORTED_MODULE_5__.BarElement, chart_js__WEBPACK_IMPORTED_MODULE_5__.DoughnutController, chart_js__WEBPACK_IMPORTED_MODULE_5__.ArcElement, chart_js__WEBPACK_IMPORTED_MODULE_5__.PointElement, chart_js__WEBPACK_IMPORTED_MODULE_5__.LineElement);

      if (!this.barCanvas) {
        return;
      } else {
        var chartExist = chart_js__WEBPACK_IMPORTED_MODULE_5__.Chart.getChart('statsChart');

        if (chartExist !== undefined) {
          chartExist.destroy();
        }
      } //build using stats and this.selectedPeriod


      var arrOfPeriod = this.daysFromInterval();
      var arrOfValuesCompleted = this.valuesFromStat(arrOfPeriod, stats, 'completed');
      var arrOfValuesFailed = this.valuesFromStat(arrOfPeriod, stats, 'failed'); // if (stats && stats.length) {

      this.barChart = new chart_js__WEBPACK_IMPORTED_MODULE_5__.Chart(this.barCanvas.nativeElement, {
        type: 'bar',
        options: {
          onClick: function onClick(e) {
            var points = _this4.barChart.getElementsAtEventForMode(e, 'nearest', {
              intersect: true
            }, true);

            if (points.length) {
              var firstPoint = points[0];
              var label = _this4.barChart.data.labels[firstPoint.index];

              _this4.changeView(label);
            }
          },
          scales: {
            x: {
              stacked: true
            },
            y: {
              stacked: true,
              ticks: {
                stepSize: 1
              }
            }
          }
        },
        data: {
          labels: arrOfPeriod.map(function (period) {
            return period.toFormat(_this4.selectedPeriod.format);
          }),
          datasets: [{
            data: arrOfValuesCompleted,
            backgroundColor: '#359675',
            borderRadius: 5
          }, {
            data: arrOfValuesFailed,
            backgroundColor: '#C61010',
            borderRadius: 5
          }]
        }
      }); // }
    }
  }, {
    key: "valuesFromStat",
    value: function valuesFromStat(arrOfPeriod, stats, type) {
      var _this5 = this;

      //  check if stats[i] is part of arrOfPeriod
      // const statsArrayDate = stats.map((stat) => {
      //   console.log(stat);
      //   return DateTime.fromObject(this.getObjectDate(stat.period));
      // });
      // console.log(statsArrayDate);
      var retArr = [];

      var _iterator = (0,_Users_smartcommunitylab_Desktop_newWork_dslab_playgo_mobile_playgo_mobile_node_modules_babel_runtime_helpers_esm_createForOfIteratorHelper_js__WEBPACK_IMPORTED_MODULE_0__["default"])(arrOfPeriod),
          _step;

      try {
        var _loop = function _loop() {
          var period = _step.value;
          //check if statsArrayDate has a period
          // const i = statsArrayDate.findIndex(
          //   (statPeriod) => statPeriod.toISO() === period.toISO()
          // );
          //get array filtered by period
          var arrayFiltered = stats.filter(function (stat) {
            return luxon__WEBPACK_IMPORTED_MODULE_6__.DateTime.fromObject(_this5.getObjectDate(stat.period)).toISO() === period.toISO();
          });

          if (arrayFiltered.length > 0) {
            retArr.push(arrayFiltered.reduce(function (prev, next) {
              return prev + next[type];
            }, 0));
          } else {
            retArr.push(0);
          }
        };

        for (_iterator.s(); !(_step = _iterator.n()).done;) {
          _loop();
        }
      } catch (err) {
        _iterator.e(err);
      } finally {
        _iterator.f();
      }

      return retArr;
    }
  }, {
    key: "getObjectDate",
    value: function getObjectDate(statPeriod) {
      //anno - mese o anno numero settimana o anno mese giorno in base alla selezione
      var periodSplitted = statPeriod.split('-');

      switch (this.selectedPeriod.group) {
        case 'day':
          return {
            year: Number(periodSplitted[0]),
            month: Number(periodSplitted[1]),
            day: Number(periodSplitted[2])
          };

        case 'week':
          return {
            weekYear: Number(periodSplitted[0]),
            weekNumber: Number(periodSplitted[1])
          };

        case 'month':
          return {
            year: Number(periodSplitted[0]),
            month: Number(periodSplitted[1])
          };
      }
    }
  }, {
    key: "daysFromInterval",
    value: function daysFromInterval() {
      var retArr = [];
      var start = this.selectedPeriod.from;
      var end = this.selectedPeriod.to;
      var interval = luxon__WEBPACK_IMPORTED_MODULE_6__.Interval.fromDateTimes(start, end);
      var cursor = interval.start;
      cursor = cursor.startOf(this.selectedPeriod.group);

      while (cursor < interval.end) {
        //begin of the element
        retArr.push(cursor);
        cursor = cursor.plus((0,_Users_smartcommunitylab_Desktop_newWork_dslab_playgo_mobile_playgo_mobile_node_modules_babel_runtime_helpers_esm_defineProperty_js__WEBPACK_IMPORTED_MODULE_1__["default"])({}, this.selectedPeriod.group, 1));
      }

      return retArr;
    }
  }, {
    key: "changeView",
    value: function changeView(label) {
      var _this6 = this;

      // segmentChanged($event); statPeriodChangedSubject.next(selectedSegment)
      var switchToPeriod = null;

      switch (this.selectedSegment.group) {
        case 'month':
          label = luxon__WEBPACK_IMPORTED_MODULE_6__.DateTime.fromFormat(label, 'MM-yyyy').toFormat('yyyy-MM-dd');
          break;

        case 'week':
          label = luxon__WEBPACK_IMPORTED_MODULE_6__.DateTime.fromFormat(label, 'dd-MM-yyyy').toFormat('yyyy-WW');
          break;

        case 'day':
          // label = DateTime.fromFormat(label, 'dd-MM').toFormat('yyyy-MM-dd');
          return;

        default:
          break;
      } // change reference date
      //only get but it doesn't write on subject


      this.referenceDate = luxon__WEBPACK_IMPORTED_MODULE_6__.DateTime.fromObject(this.getObjectDate(label));
      this.periods = (0,src_app_core_shared_campaigns_campaign_utils__WEBPACK_IMPORTED_MODULE_8__.getPeriods)(this.referenceDate);
      this.selectedSegment = this.periods.find(function (a) {
        return a.group === _this6.selectedSegment.switchTo;
      });
      this.statPeriodChangedSubject.next(this.selectedSegment);
    }
  }]);

  return ChallengesStatComponent;
}();

ChallengesStatComponent.ɵfac = function ChallengesStatComponent_Factory(t) {
  return new (t || ChallengesStatComponent)(_angular_core__WEBPACK_IMPORTED_MODULE_14__["ɵɵdirectiveInject"](src_app_core_shared_services_challenge_service__WEBPACK_IMPORTED_MODULE_9__.ChallengeService), _angular_core__WEBPACK_IMPORTED_MODULE_14__["ɵɵdirectiveInject"](src_app_core_shared_services_user_service__WEBPACK_IMPORTED_MODULE_10__.UserService), _angular_core__WEBPACK_IMPORTED_MODULE_14__["ɵɵdirectiveInject"](src_app_core_shared_services_error_service__WEBPACK_IMPORTED_MODULE_11__.ErrorService));
};

ChallengesStatComponent.ɵcmp = /*@__PURE__*/_angular_core__WEBPACK_IMPORTED_MODULE_14__["ɵɵdefineComponent"]({
  type: ChallengesStatComponent,
  selectors: [["app-challenges-stat"]],
  viewQuery: function ChallengesStatComponent_Query(rf, ctx) {
    if (rf & 1) {
      _angular_core__WEBPACK_IMPORTED_MODULE_14__["ɵɵviewQuery"](_c0, 5);
    }

    if (rf & 2) {
      var _t;

      _angular_core__WEBPACK_IMPORTED_MODULE_14__["ɵɵqueryRefresh"](_t = _angular_core__WEBPACK_IMPORTED_MODULE_14__["ɵɵloadQuery"]()) && (ctx.barCanvas = _t.first);
    }
  },
  decls: 34,
  vars: 36,
  consts: [[1, "header-margin"], ["color", "playgo", 1, "header-radius", 3, "ngStyle"], [3, "interfaceOptions", "value", "ionChange", 4, "ngIf", "ngIfElse"], ["noCampaigns", ""], ["mode", "md", "scrollable", "", 1, "app-segment", 3, "ngModel", "ngModelChange", "ionChange"], ["checked", "", "mode", "ios", "class", "app-segment-button", 3, "value", "--color", "--color-checked", 4, "ngFor", "ngForOf"], [1, "table-header"], ["size", "2"], ["color", "light", "fill", "clear", 3, "click"], ["name", "chevron-back"], ["size", "8"], [1, "ion-text-center"], ["name", "chevron-forward"], [4, "ngIf", "ngIfElse"], ["barChart", ""], [1, "empty-stats"], [3, "interfaceOptions", "value", "ionChange"], [3, "value", 4, "ngFor", "ngForOf"], [3, "value"], ["checked", "", "mode", "ios", 1, "app-segment-button", 3, "value"], [4, "ngFor", "ngForOf"], [3, "stat", "kind"], ["id", "statsChart", 2, "position", "relative", "height", "20vh", "width", "40vw"], ["barCanvas", ""]],
  template: function ChallengesStatComponent_Template(rf, ctx) {
    if (rf & 1) {
      _angular_core__WEBPACK_IMPORTED_MODULE_14__["ɵɵelementStart"](0, "div", 0)(1, "ion-item", 1);
      _angular_core__WEBPACK_IMPORTED_MODULE_14__["ɵɵpipe"](2, "async");
      _angular_core__WEBPACK_IMPORTED_MODULE_14__["ɵɵelementStart"](3, "ion-label");
      _angular_core__WEBPACK_IMPORTED_MODULE_14__["ɵɵtext"](4);
      _angular_core__WEBPACK_IMPORTED_MODULE_14__["ɵɵpipe"](5, "translate");
      _angular_core__WEBPACK_IMPORTED_MODULE_14__["ɵɵelementEnd"]();
      _angular_core__WEBPACK_IMPORTED_MODULE_14__["ɵɵtemplate"](6, ChallengesStatComponent_ion_select_6_Template, 3, 6, "ion-select", 2);
      _angular_core__WEBPACK_IMPORTED_MODULE_14__["ɵɵtemplate"](7, ChallengesStatComponent_ng_template_7_Template, 3, 3, "ng-template", null, 3, _angular_core__WEBPACK_IMPORTED_MODULE_14__["ɵɵtemplateRefExtractor"]);
      _angular_core__WEBPACK_IMPORTED_MODULE_14__["ɵɵelementEnd"]();
      _angular_core__WEBPACK_IMPORTED_MODULE_14__["ɵɵelementStart"](9, "ion-segment", 4);
      _angular_core__WEBPACK_IMPORTED_MODULE_14__["ɵɵlistener"]("ngModelChange", function ChallengesStatComponent_Template_ion_segment_ngModelChange_9_listener($event) {
        return ctx.selectedSegment = $event;
      })("ionChange", function ChallengesStatComponent_Template_ion_segment_ionChange_9_listener($event) {
        ctx.segmentChanged($event);
        return ctx.statPeriodChangedSubject.next(ctx.selectedSegment);
      });
      _angular_core__WEBPACK_IMPORTED_MODULE_14__["ɵɵtemplate"](10, ChallengesStatComponent_ion_segment_button_10_Template, 4, 8, "ion-segment-button", 5);
      _angular_core__WEBPACK_IMPORTED_MODULE_14__["ɵɵelementEnd"]();
      _angular_core__WEBPACK_IMPORTED_MODULE_14__["ɵɵelementStart"](11, "ion-grid", 6)(12, "ion-row")(13, "ion-col", 7)(14, "ion-button", 8);
      _angular_core__WEBPACK_IMPORTED_MODULE_14__["ɵɵlistener"]("click", function ChallengesStatComponent_Template_ion_button_click_14_listener() {
        return ctx.backPeriod();
      });
      _angular_core__WEBPACK_IMPORTED_MODULE_14__["ɵɵelement"](15, "ion-icon", 9);
      _angular_core__WEBPACK_IMPORTED_MODULE_14__["ɵɵelementEnd"]()();
      _angular_core__WEBPACK_IMPORTED_MODULE_14__["ɵɵelementStart"](16, "ion-col", 10)(17, "p", 11);
      _angular_core__WEBPACK_IMPORTED_MODULE_14__["ɵɵtext"](18);
      _angular_core__WEBPACK_IMPORTED_MODULE_14__["ɵɵelementEnd"]();
      _angular_core__WEBPACK_IMPORTED_MODULE_14__["ɵɵelementStart"](19, "p", 11);
      _angular_core__WEBPACK_IMPORTED_MODULE_14__["ɵɵtext"](20);
      _angular_core__WEBPACK_IMPORTED_MODULE_14__["ɵɵpipe"](21, "translate");
      _angular_core__WEBPACK_IMPORTED_MODULE_14__["ɵɵpipe"](22, "translate");
      _angular_core__WEBPACK_IMPORTED_MODULE_14__["ɵɵelementEnd"]()();
      _angular_core__WEBPACK_IMPORTED_MODULE_14__["ɵɵelementStart"](23, "ion-col", 7)(24, "ion-button", 8);
      _angular_core__WEBPACK_IMPORTED_MODULE_14__["ɵɵlistener"]("click", function ChallengesStatComponent_Template_ion_button_click_24_listener() {
        return ctx.forwardPeriod();
      });
      _angular_core__WEBPACK_IMPORTED_MODULE_14__["ɵɵelement"](25, "ion-icon", 12);
      _angular_core__WEBPACK_IMPORTED_MODULE_14__["ɵɵelementEnd"]()()()();
      _angular_core__WEBPACK_IMPORTED_MODULE_14__["ɵɵelementStart"](26, "div");
      _angular_core__WEBPACK_IMPORTED_MODULE_14__["ɵɵtemplate"](27, ChallengesStatComponent_div_27_Template, 4, 1, "div", 13);
      _angular_core__WEBPACK_IMPORTED_MODULE_14__["ɵɵtemplate"](28, ChallengesStatComponent_ng_template_28_Template, 2, 0, "ng-template", null, 14, _angular_core__WEBPACK_IMPORTED_MODULE_14__["ɵɵtemplateRefExtractor"]);
      _angular_core__WEBPACK_IMPORTED_MODULE_14__["ɵɵelementEnd"]();
      _angular_core__WEBPACK_IMPORTED_MODULE_14__["ɵɵelementStart"](30, "div")(31, "div", 15);
      _angular_core__WEBPACK_IMPORTED_MODULE_14__["ɵɵtext"](32);
      _angular_core__WEBPACK_IMPORTED_MODULE_14__["ɵɵpipe"](33, "translate");
      _angular_core__WEBPACK_IMPORTED_MODULE_14__["ɵɵelementEnd"]()()();
    }

    if (rf & 2) {
      var _r1 = _angular_core__WEBPACK_IMPORTED_MODULE_14__["ɵɵreference"](8);

      var _r5 = _angular_core__WEBPACK_IMPORTED_MODULE_14__["ɵɵreference"](29);

      var tmp_0_0;
      _angular_core__WEBPACK_IMPORTED_MODULE_14__["ɵɵadvance"](1);
      _angular_core__WEBPACK_IMPORTED_MODULE_14__["ɵɵproperty"]("ngStyle", _angular_core__WEBPACK_IMPORTED_MODULE_14__["ɵɵpureFunction1"](30, _c2, " var(--ion-color-" + ((tmp_0_0 = _angular_core__WEBPACK_IMPORTED_MODULE_14__["ɵɵpipeBind1"](2, 18, ctx.selectedCampaign$)) == null ? null : tmp_0_0.campaign == null ? null : tmp_0_0.campaign.type) + ")"));
      _angular_core__WEBPACK_IMPORTED_MODULE_14__["ɵɵadvance"](3);
      _angular_core__WEBPACK_IMPORTED_MODULE_14__["ɵɵtextInterpolate"](_angular_core__WEBPACK_IMPORTED_MODULE_14__["ɵɵpipeBind1"](5, 20, "challenges.stats.filter.campaign"));
      _angular_core__WEBPACK_IMPORTED_MODULE_14__["ɵɵadvance"](2);
      _angular_core__WEBPACK_IMPORTED_MODULE_14__["ɵɵproperty"]("ngIf", ctx.campaigns.length > 0)("ngIfElse", _r1);
      _angular_core__WEBPACK_IMPORTED_MODULE_14__["ɵɵadvance"](3);
      _angular_core__WEBPACK_IMPORTED_MODULE_14__["ɵɵstyleProp"]("--background", "var(--ion-color-playgo)");
      _angular_core__WEBPACK_IMPORTED_MODULE_14__["ɵɵproperty"]("ngModel", ctx.selectedSegment);
      _angular_core__WEBPACK_IMPORTED_MODULE_14__["ɵɵadvance"](1);
      _angular_core__WEBPACK_IMPORTED_MODULE_14__["ɵɵproperty"]("ngForOf", ctx.periods);
      _angular_core__WEBPACK_IMPORTED_MODULE_14__["ɵɵadvance"](8);
      _angular_core__WEBPACK_IMPORTED_MODULE_14__["ɵɵtextInterpolate"](ctx.getSelectedPeriod());
      _angular_core__WEBPACK_IMPORTED_MODULE_14__["ɵɵadvance"](2);
      _angular_core__WEBPACK_IMPORTED_MODULE_14__["ɵɵtextInterpolate2"](" ", _angular_core__WEBPACK_IMPORTED_MODULE_14__["ɵɵpipeBind2"](21, 22, "challenges.stats.totalChallenges", _angular_core__WEBPACK_IMPORTED_MODULE_14__["ɵɵpureFunction1"](32, _c3, ctx.totalChallenges)), " / ", _angular_core__WEBPACK_IMPORTED_MODULE_14__["ɵɵpipeBind2"](22, 25, "challenges.stats.totalWon", _angular_core__WEBPACK_IMPORTED_MODULE_14__["ɵɵpureFunction1"](34, _c4, ctx.totalWon)), " ");
      _angular_core__WEBPACK_IMPORTED_MODULE_14__["ɵɵadvance"](6);
      _angular_core__WEBPACK_IMPORTED_MODULE_14__["ɵɵstyleProp"]("display", ctx.stats && (ctx.stats == null ? null : ctx.stats.length) > 0 ? "block" : "none");
      _angular_core__WEBPACK_IMPORTED_MODULE_14__["ɵɵadvance"](1);
      _angular_core__WEBPACK_IMPORTED_MODULE_14__["ɵɵproperty"]("ngIf", ctx.isWeekSelected())("ngIfElse", _r5);
      _angular_core__WEBPACK_IMPORTED_MODULE_14__["ɵɵadvance"](3);
      _angular_core__WEBPACK_IMPORTED_MODULE_14__["ɵɵstyleProp"]("display", ctx.stats === null || (ctx.stats == null ? null : ctx.stats.length) <= 0 ? "block" : "none");
      _angular_core__WEBPACK_IMPORTED_MODULE_14__["ɵɵadvance"](2);
      _angular_core__WEBPACK_IMPORTED_MODULE_14__["ɵɵtextInterpolate"](_angular_core__WEBPACK_IMPORTED_MODULE_14__["ɵɵpipeBind1"](33, 28, "challenges.stats.empty"));
    }
  },
  directives: [_ionic_angular__WEBPACK_IMPORTED_MODULE_24__.IonItem, _angular_common__WEBPACK_IMPORTED_MODULE_25__.NgStyle, _ionic_angular__WEBPACK_IMPORTED_MODULE_24__.IonLabel, _angular_common__WEBPACK_IMPORTED_MODULE_25__.NgIf, _ionic_angular__WEBPACK_IMPORTED_MODULE_24__.IonSelect, _ionic_angular__WEBPACK_IMPORTED_MODULE_24__.SelectValueAccessor, _angular_common__WEBPACK_IMPORTED_MODULE_25__.NgForOf, _ionic_angular__WEBPACK_IMPORTED_MODULE_24__.IonSelectOption, _ionic_angular__WEBPACK_IMPORTED_MODULE_24__.IonSegment, _angular_forms__WEBPACK_IMPORTED_MODULE_26__.NgControlStatus, _angular_forms__WEBPACK_IMPORTED_MODULE_26__.NgModel, _ionic_angular__WEBPACK_IMPORTED_MODULE_24__.IonSegmentButton, _ionic_angular__WEBPACK_IMPORTED_MODULE_24__.IonGrid, _ionic_angular__WEBPACK_IMPORTED_MODULE_24__.IonRow, _ionic_angular__WEBPACK_IMPORTED_MODULE_24__.IonCol, _ionic_angular__WEBPACK_IMPORTED_MODULE_24__.IonButton, _ionic_angular__WEBPACK_IMPORTED_MODULE_24__.IonIcon, _challenge_single_stat_challenge_single_stat_component__WEBPACK_IMPORTED_MODULE_12__.ChalengeSingleStatComponent],
  pipes: [_angular_common__WEBPACK_IMPORTED_MODULE_25__.AsyncPipe, _ngx_translate_core__WEBPACK_IMPORTED_MODULE_27__.TranslatePipe, _core_shared_pipes_languageMap_pipe__WEBPACK_IMPORTED_MODULE_13__.LanguageMapPipe],
  styles: [".header-margin[_ngcontent-%COMP%] {\n  margin: 8px;\n}\n.header-margin[_ngcontent-%COMP%]   .header-radius[_ngcontent-%COMP%] {\n  border-radius: 8px 8px 0 0;\n  border-bottom: 5px solid;\n}\n.header-margin[_ngcontent-%COMP%]   .table-header[_ngcontent-%COMP%] {\n  background-color: var(--ion-color-playgo);\n  color: white;\n  font-size: 22px;\n}\n.header-margin[_ngcontent-%COMP%]   .empty-stats[_ngcontent-%COMP%] {\n  margin-top: calc(var(--ion-safe-area-top, 0) + 20px);\n  margin-bottom: calc(var(--ion-safe-area-bottom, 0) + 20px);\n  text-align: center;\n  color: var(--ion-color-medium);\n}\n/*# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbImNoYWxsZW5nZXMtc3RhdC5jb21wb25lbnQuc2NzcyJdLCJuYW1lcyI6W10sIm1hcHBpbmdzIjoiQUFBQTtFQUNFLFdBQUE7QUFDRjtBQUNFO0VBQ0UsMEJBQUE7RUFDQSx3QkFBQTtBQUNKO0FBQ0U7RUFDRSx5Q0FBQTtFQUNBLFlBQUE7RUFDQSxlQUFBO0FBQ0o7QUFDRTtFQUNFLG9EQUFBO0VBQ0EsMERBQUE7RUFDQSxrQkFBQTtFQUNBLDhCQUFBO0FBQ0oiLCJmaWxlIjoiY2hhbGxlbmdlcy1zdGF0LmNvbXBvbmVudC5zY3NzIiwic291cmNlc0NvbnRlbnQiOlsiLmhlYWRlci1tYXJnaW4ge1xuICBtYXJnaW46IDhweDtcblxuICAuaGVhZGVyLXJhZGl1cyB7XG4gICAgYm9yZGVyLXJhZGl1czogOHB4IDhweCAwIDA7XG4gICAgYm9yZGVyLWJvdHRvbTogNXB4IHNvbGlkO1xuICB9XG4gIC50YWJsZS1oZWFkZXIge1xuICAgIGJhY2tncm91bmQtY29sb3I6IHZhcigtLWlvbi1jb2xvci1wbGF5Z28pO1xuICAgIGNvbG9yOiB3aGl0ZTtcbiAgICBmb250LXNpemU6IDIycHg7XG4gIH1cbiAgLmVtcHR5LXN0YXRzIHtcbiAgICBtYXJnaW4tdG9wOiBjYWxjKHZhcigtLWlvbi1zYWZlLWFyZWEtdG9wLCAwKSArIDIwcHgpO1xuICAgIG1hcmdpbi1ib3R0b206IGNhbGModmFyKC0taW9uLXNhZmUtYXJlYS1ib3R0b20sIDApICsgMjBweCk7XG4gICAgdGV4dC1hbGlnbjogY2VudGVyO1xuICAgIGNvbG9yOiB2YXIoLS1pb24tY29sb3ItbWVkaXVtKTtcbiAgfVxufVxuIl19 */"]
});

/***/ }),

/***/ 27293:
/*!*******************************************************!*\
  !*** ./src/app/pages/challenges/challenges.module.ts ***!
  \*******************************************************/
/***/ (function(__unused_webpack_module, __webpack_exports__, __webpack_require__) {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "ChallengesPageModule": function() { return /* binding */ ChallengesPageModule; }
/* harmony export */ });
/* harmony import */ var _Users_smartcommunitylab_Desktop_newWork_dslab_playgo_mobile_playgo_mobile_node_modules_babel_runtime_helpers_esm_createClass_js__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./node_modules/@babel/runtime/helpers/esm/createClass.js */ 48047);
/* harmony import */ var _Users_smartcommunitylab_Desktop_newWork_dslab_playgo_mobile_playgo_mobile_node_modules_babel_runtime_helpers_esm_classCallCheck_js__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ./node_modules/@babel/runtime/helpers/esm/classCallCheck.js */ 78069);
/* harmony import */ var src_app_core_shared_shared_module__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! src/app/core/shared/shared.module */ 97205);
/* harmony import */ var _challenge_card_challenge_card_component__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! ./challenge-card/challenge-card.component */ 39729);
/* harmony import */ var _challenge_card_detail_modal_detail_modal__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! ./challenge-card/detail-modal/detail.modal */ 9321);
/* harmony import */ var _challenge_container_challenge_container_component__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! ./challenge-container/challenge-container.component */ 44286);
/* harmony import */ var _challenges_proposed_card_challenges_proposed_card_component__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! ./challenges-proposed-card/challenges-proposed-card.component */ 8256);
/* harmony import */ var _challenges_proposed_card_info_challenge_single_modal_info_challenge_single_modal__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(/*! ./challenges-proposed-card/info-challenge-single-modal/info-challenge-single.modal */ 79107);
/* harmony import */ var _challenges_proposed_card_info_challenge_group_modal_info_challenge_group_modal__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(/*! ./challenges-proposed-card/info-challenge-group-modal/info-challenge-group.modal */ 36014);
/* harmony import */ var _challenges_routing_module__WEBPACK_IMPORTED_MODULE_9__ = __webpack_require__(/*! ./challenges-routing.module */ 92351);
/* harmony import */ var _challenges_stat_challenge_single_stat_challenge_single_stat_component__WEBPACK_IMPORTED_MODULE_10__ = __webpack_require__(/*! ./challenges-stat/challenge-single-stat/challenge-single-stat.component */ 6301);
/* harmony import */ var _challenges_stat_challenges_stat_component__WEBPACK_IMPORTED_MODULE_11__ = __webpack_require__(/*! ./challenges-stat/challenges-stat.component */ 56987);
/* harmony import */ var _challenges_page__WEBPACK_IMPORTED_MODULE_12__ = __webpack_require__(/*! ./challenges.page */ 465);
/* harmony import */ var _couple_challenge_proposed_couple_challenge_proposed_component__WEBPACK_IMPORTED_MODULE_13__ = __webpack_require__(/*! ./couple-challenge-proposed/couple-challenge-proposed.component */ 69537);
/* harmony import */ var _couple_challenge_proposed_invitation_challenge_invitation_challenge_modal__WEBPACK_IMPORTED_MODULE_14__ = __webpack_require__(/*! ./couple-challenge-proposed/invitation-challenge/invitation-challenge.modal */ 44018);
/* harmony import */ var _create_challenge_button_create_challenge_button_component__WEBPACK_IMPORTED_MODULE_15__ = __webpack_require__(/*! ./create-challenge-button/create-challenge-button.component */ 41988);
/* harmony import */ var _create_challenge_sent_invitation_modal_sent_invitation_modal__WEBPACK_IMPORTED_MODULE_16__ = __webpack_require__(/*! ./create-challenge/sent-invitation-modal/sent-invitation.modal */ 29212);
/* harmony import */ var _single_challenge_proposed_single_challenge_proposed_component__WEBPACK_IMPORTED_MODULE_17__ = __webpack_require__(/*! ./single-challenge-proposed/single-challenge-proposed.component */ 53051);
/* harmony import */ var _single_challenge_proposed_single_proposal_accepted_single_proposal_accepted_modal__WEBPACK_IMPORTED_MODULE_18__ = __webpack_require__(/*! ./single-challenge-proposed/single-proposal-accepted/single-proposal-accepted.modal */ 34694);
/* harmony import */ var _single_challenge_proposed_single_proposal_single_proposal_modal__WEBPACK_IMPORTED_MODULE_19__ = __webpack_require__(/*! ./single-challenge-proposed/single-proposal/single-proposal.modal */ 91846);
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_22__ = __webpack_require__(/*! @angular/core */ 3184);
/* harmony import */ var _ionic_angular__WEBPACK_IMPORTED_MODULE_23__ = __webpack_require__(/*! @ionic/angular */ 93819);
/* harmony import */ var _core_shared_layout_header_header_directive__WEBPACK_IMPORTED_MODULE_20__ = __webpack_require__(/*! ../../core/shared/layout/header/header.directive */ 34161);
/* harmony import */ var _core_shared_layout_content_content_directive__WEBPACK_IMPORTED_MODULE_21__ = __webpack_require__(/*! ../../core/shared/layout/content/content.directive */ 69669);
/* harmony import */ var _angular_forms__WEBPACK_IMPORTED_MODULE_24__ = __webpack_require__(/*! @angular/forms */ 90587);
/* harmony import */ var _angular_common__WEBPACK_IMPORTED_MODULE_25__ = __webpack_require__(/*! @angular/common */ 36362);
/* harmony import */ var _ngx_translate_core__WEBPACK_IMPORTED_MODULE_26__ = __webpack_require__(/*! @ngx-translate/core */ 87514);



























var ChallengesPageModule = /*#__PURE__*/(0,_Users_smartcommunitylab_Desktop_newWork_dslab_playgo_mobile_playgo_mobile_node_modules_babel_runtime_helpers_esm_createClass_js__WEBPACK_IMPORTED_MODULE_0__["default"])(function ChallengesPageModule() {
  (0,_Users_smartcommunitylab_Desktop_newWork_dslab_playgo_mobile_playgo_mobile_node_modules_babel_runtime_helpers_esm_classCallCheck_js__WEBPACK_IMPORTED_MODULE_1__["default"])(this, ChallengesPageModule);
});

ChallengesPageModule.ɵfac = function ChallengesPageModule_Factory(t) {
  return new (t || ChallengesPageModule)();
};

ChallengesPageModule.ɵmod = /*@__PURE__*/_angular_core__WEBPACK_IMPORTED_MODULE_22__["ɵɵdefineNgModule"]({
  type: ChallengesPageModule
});
ChallengesPageModule.ɵinj = /*@__PURE__*/_angular_core__WEBPACK_IMPORTED_MODULE_22__["ɵɵdefineInjector"]({
  imports: [[src_app_core_shared_shared_module__WEBPACK_IMPORTED_MODULE_2__.PlayGoSharedModule, _challenges_routing_module__WEBPACK_IMPORTED_MODULE_9__.ChallengesRoutingModule]]
});

(function () {
  (typeof ngJitMode === "undefined" || ngJitMode) && _angular_core__WEBPACK_IMPORTED_MODULE_22__["ɵɵsetNgModuleScope"](ChallengesPageModule, {
    declarations: [_challenges_page__WEBPACK_IMPORTED_MODULE_12__.ChallengesPage, _challenge_card_challenge_card_component__WEBPACK_IMPORTED_MODULE_3__.ChallengeCardComponent, _challenge_container_challenge_container_component__WEBPACK_IMPORTED_MODULE_5__.ChallengeContainerComponent, _challenges_stat_challenges_stat_component__WEBPACK_IMPORTED_MODULE_11__.ChallengesStatComponent, _create_challenge_button_create_challenge_button_component__WEBPACK_IMPORTED_MODULE_15__.CreateChallengeButtonComponent, _challenges_stat_challenge_single_stat_challenge_single_stat_component__WEBPACK_IMPORTED_MODULE_10__.ChalengeSingleStatComponent, _challenges_proposed_card_challenges_proposed_card_component__WEBPACK_IMPORTED_MODULE_6__.ChallengesProposedCardComponent, _couple_challenge_proposed_couple_challenge_proposed_component__WEBPACK_IMPORTED_MODULE_13__.CoupleChallengeProposedComponent, _single_challenge_proposed_single_challenge_proposed_component__WEBPACK_IMPORTED_MODULE_17__.SingleChallengeProposedComponent, _couple_challenge_proposed_invitation_challenge_invitation_challenge_modal__WEBPACK_IMPORTED_MODULE_14__.InvitationlModalPage, _single_challenge_proposed_single_proposal_single_proposal_modal__WEBPACK_IMPORTED_MODULE_19__.SingleProposalModalPage, _create_challenge_sent_invitation_modal_sent_invitation_modal__WEBPACK_IMPORTED_MODULE_16__.SentInvitationlModalPage, _challenges_proposed_card_info_challenge_single_modal_info_challenge_single_modal__WEBPACK_IMPORTED_MODULE_7__.InfoChallengeSingleModalPage, _challenges_proposed_card_info_challenge_group_modal_info_challenge_group_modal__WEBPACK_IMPORTED_MODULE_8__.InfoChallengeGroupModalPage, _challenge_card_detail_modal_detail_modal__WEBPACK_IMPORTED_MODULE_4__.DetailChallengenModalPage, _single_challenge_proposed_single_proposal_accepted_single_proposal_accepted_modal__WEBPACK_IMPORTED_MODULE_18__.SingleProposalAcceptedModalPage],
    imports: [src_app_core_shared_shared_module__WEBPACK_IMPORTED_MODULE_2__.PlayGoSharedModule, _challenges_routing_module__WEBPACK_IMPORTED_MODULE_9__.ChallengesRoutingModule]
  });
})();

_angular_core__WEBPACK_IMPORTED_MODULE_22__["ɵɵsetComponentScope"](_challenges_page__WEBPACK_IMPORTED_MODULE_12__.ChallengesPage, [_ionic_angular__WEBPACK_IMPORTED_MODULE_23__.IonHeader, _core_shared_layout_header_header_directive__WEBPACK_IMPORTED_MODULE_20__.HeaderDirective, _ionic_angular__WEBPACK_IMPORTED_MODULE_23__.IonContent, _core_shared_layout_content_content_directive__WEBPACK_IMPORTED_MODULE_21__.ContentDirective, _ionic_angular__WEBPACK_IMPORTED_MODULE_23__.IonSegment, _ionic_angular__WEBPACK_IMPORTED_MODULE_23__.SelectValueAccessor, _angular_forms__WEBPACK_IMPORTED_MODULE_24__.NgControlStatus, _angular_forms__WEBPACK_IMPORTED_MODULE_24__.NgModel, _ionic_angular__WEBPACK_IMPORTED_MODULE_23__.IonSegmentButton, _ionic_angular__WEBPACK_IMPORTED_MODULE_23__.IonLabel, _angular_common__WEBPACK_IMPORTED_MODULE_25__.NgIf, _challenges_stat_challenges_stat_component__WEBPACK_IMPORTED_MODULE_11__.ChallengesStatComponent, _angular_common__WEBPACK_IMPORTED_MODULE_25__.NgForOf, _challenge_container_challenge_container_component__WEBPACK_IMPORTED_MODULE_5__.ChallengeContainerComponent], [_ngx_translate_core__WEBPACK_IMPORTED_MODULE_26__.TranslatePipe]);
_angular_core__WEBPACK_IMPORTED_MODULE_22__["ɵɵsetComponentScope"](_challenge_container_challenge_container_component__WEBPACK_IMPORTED_MODULE_5__.ChallengeContainerComponent, [_angular_common__WEBPACK_IMPORTED_MODULE_25__.NgForOf, _angular_common__WEBPACK_IMPORTED_MODULE_25__.NgIf, _challenge_card_challenge_card_component__WEBPACK_IMPORTED_MODULE_3__.ChallengeCardComponent, _challenges_proposed_card_challenges_proposed_card_component__WEBPACK_IMPORTED_MODULE_6__.ChallengesProposedCardComponent], []);

/***/ }),

/***/ 465:
/*!*****************************************************!*\
  !*** ./src/app/pages/challenges/challenges.page.ts ***!
  \*****************************************************/
/***/ (function(__unused_webpack_module, __webpack_exports__, __webpack_require__) {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "ChallengesPage": function() { return /* binding */ ChallengesPage; }
/* harmony export */ });
/* harmony import */ var _Users_smartcommunitylab_Desktop_newWork_dslab_playgo_mobile_playgo_mobile_node_modules_babel_runtime_helpers_esm_slicedToArray_js__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./node_modules/@babel/runtime/helpers/esm/slicedToArray.js */ 10507);
/* harmony import */ var _Users_smartcommunitylab_Desktop_newWork_dslab_playgo_mobile_playgo_mobile_node_modules_babel_runtime_helpers_esm_classCallCheck_js__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ./node_modules/@babel/runtime/helpers/esm/classCallCheck.js */ 78069);
/* harmony import */ var _Users_smartcommunitylab_Desktop_newWork_dslab_playgo_mobile_playgo_mobile_node_modules_babel_runtime_helpers_esm_createClass_js__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! ./node_modules/@babel/runtime/helpers/esm/createClass.js */ 48047);
/* harmony import */ var rxjs__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! rxjs */ 26562);
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! @angular/core */ 3184);
/* harmony import */ var src_app_core_shared_services_challenge_service__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! src/app/core/shared/services/challenge.service */ 66324);
/* harmony import */ var src_app_core_shared_services_notifications_notifications_service__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! src/app/core/shared/services/notifications/notifications.service */ 30299);
/* harmony import */ var _angular_router__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(/*! @angular/router */ 52816);








var _c0 = ["active"];
var _c1 = ["future"];

function ChallengesPage_div_15_Template(rf, ctx) {
  if (rf & 1) {
    _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵelementStart"](0, "div");
    _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵelement"](1, "app-challenges-stat");
    _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵelementEnd"]();
  }
}

function ChallengesPage_div_16_ng_container_1_div_1_div_1_Template(rf, ctx) {
  if (rf & 1) {
    _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵelementStart"](0, "div");
    _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵelement"](1, "app-challenge-container", 10, 11);
    _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵelementEnd"]();
  }

  if (rf & 2) {
    var campaign_r7 = _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵnextContext"]().$implicit;
    var ctx_r8 = _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵnextContext"](3);
    _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵadvance"](1);
    _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵproperty"]("campaign", campaign_r7)("challenges", ctx_r8.activeChallenges[campaign_r7 == null ? null : campaign_r7.campaign == null ? null : campaign_r7.campaign.campaignId])("type", "active");
  }
}

function ChallengesPage_div_16_ng_container_1_div_1_div_2_Template(rf, ctx) {
  if (rf & 1) {
    _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵelementStart"](0, "div");
    _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵelement"](1, "app-challenge-container", 12, 11);
    _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵelementEnd"]();
  }

  if (rf & 2) {
    var campaign_r7 = _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵnextContext"]().$implicit;
    var ctx_r9 = _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵnextContext"](3);
    _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵadvance"](1);
    _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵproperty"]("campaign", campaign_r7)("team", true)("challenges", ctx_r9.activeChallengesTeam[campaign_r7 == null ? null : campaign_r7.campaign == null ? null : campaign_r7.campaign.campaignId])("type", "active");
  }
}

function ChallengesPage_div_16_ng_container_1_div_1_Template(rf, ctx) {
  if (rf & 1) {
    _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵelementStart"](0, "div");
    _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵtemplate"](1, ChallengesPage_div_16_ng_container_1_div_1_div_1_Template, 3, 3, "div", 6);
    _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵtemplate"](2, ChallengesPage_div_16_ng_container_1_div_1_div_2_Template, 3, 4, "div", 6);
    _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵelementEnd"]();
  }

  if (rf & 2) {
    var campaign_r7 = ctx.$implicit;
    var ctx_r6 = _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵnextContext"](3);
    _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵadvance"](1);
    _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵproperty"]("ngIf", (ctx_r6.activeChallenges[campaign_r7 == null ? null : campaign_r7.campaign == null ? null : campaign_r7.campaign.campaignId] == null ? null : ctx_r6.activeChallenges[campaign_r7 == null ? null : campaign_r7.campaign == null ? null : campaign_r7.campaign.campaignId].length) > 0);
    _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵadvance"](1);
    _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵproperty"]("ngIf", (ctx_r6.activeChallengesTeam[campaign_r7 == null ? null : campaign_r7.campaign == null ? null : campaign_r7.campaign.campaignId] == null ? null : ctx_r6.activeChallengesTeam[campaign_r7 == null ? null : campaign_r7.campaign == null ? null : campaign_r7.campaign.campaignId].length) > 0);
  }
}

function ChallengesPage_div_16_ng_container_1_Template(rf, ctx) {
  if (rf & 1) {
    _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵelementContainerStart"](0);
    _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵtemplate"](1, ChallengesPage_div_16_ng_container_1_div_1_Template, 3, 2, "div", 9);
    _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵelementContainerEnd"]();
  }

  if (rf & 2) {
    var ctx_r3 = _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵnextContext"](2);
    _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵadvance"](1);
    _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵproperty"]("ngForOf", ctx_r3.campaignsWithChallenges);
  }
}

function ChallengesPage_div_16_ng_template_2_Template(rf, ctx) {
  if (rf & 1) {
    _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵelementStart"](0, "div", 13);
    _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵtext"](1);
    _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵpipe"](2, "translate");
    _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵelementEnd"]();
  }

  if (rf & 2) {
    _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵadvance"](1);
    _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵtextInterpolate"](_angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵpipeBind1"](2, 1, "challenges.empty"));
  }
}

function ChallengesPage_div_16_Template(rf, ctx) {
  if (rf & 1) {
    _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵelementStart"](0, "div");
    _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵtemplate"](1, ChallengesPage_div_16_ng_container_1_Template, 2, 1, "ng-container", 7);
    _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵtemplate"](2, ChallengesPage_div_16_ng_template_2_Template, 3, 3, "ng-template", null, 8, _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵtemplateRefExtractor"]);
    _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵelementEnd"]();
  }

  if (rf & 2) {
    var _r4 = _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵreference"](3);

    var ctx_r1 = _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵnextContext"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵadvance"](1);
    _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵproperty"]("ngIf", ctx_r1.thereAreChallengeActive)("ngIfElse", _r4);
  }
}

function ChallengesPage_div_17_ng_container_1_div_1_div_1_Template(rf, ctx) {
  if (rf & 1) {
    _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵelementStart"](0, "div");
    _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵelement"](1, "app-challenge-container", 15, 16);
    _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵelementEnd"]();
  }

  if (rf & 2) {
    var campaign_r18 = _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵnextContext"]().$implicit;
    var ctx_r19 = _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵnextContext"](3);
    _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵadvance"](1);
    _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵproperty"]("campaign", campaign_r18)("challenges", ctx_r19.futureChallenges[campaign_r18 == null ? null : campaign_r18.campaign == null ? null : campaign_r18.campaign.campaignId])("type", "future")("canInvite", ctx_r19.canInvite[campaign_r18 == null ? null : campaign_r18.campaign == null ? null : campaign_r18.campaign.campaignId]);
  }
}

function ChallengesPage_div_17_ng_container_1_div_1_div_2_Template(rf, ctx) {
  if (rf & 1) {
    _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵelementStart"](0, "div");
    _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵelement"](1, "app-challenge-container", 12, 16);
    _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵelementEnd"]();
  }

  if (rf & 2) {
    var campaign_r18 = _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵnextContext"]().$implicit;
    var ctx_r20 = _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵnextContext"](3);
    _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵadvance"](1);
    _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵproperty"]("campaign", campaign_r18)("team", true)("challenges", ctx_r20.futureChallengesTeam[campaign_r18 == null ? null : campaign_r18.campaign == null ? null : campaign_r18.campaign.campaignId])("type", "future");
  }
}

function ChallengesPage_div_17_ng_container_1_div_1_Template(rf, ctx) {
  if (rf & 1) {
    _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵelementStart"](0, "div");
    _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵtemplate"](1, ChallengesPage_div_17_ng_container_1_div_1_div_1_Template, 3, 4, "div", 6);
    _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵtemplate"](2, ChallengesPage_div_17_ng_container_1_div_1_div_2_Template, 3, 4, "div", 6);
    _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵelementEnd"]();
  }

  if (rf & 2) {
    var campaign_r18 = ctx.$implicit;
    var ctx_r17 = _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵnextContext"](3);
    _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵadvance"](1);
    _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵproperty"]("ngIf", (ctx_r17.futureChallenges[campaign_r18 == null ? null : campaign_r18.campaign == null ? null : campaign_r18.campaign.campaignId] == null ? null : ctx_r17.futureChallenges[campaign_r18 == null ? null : campaign_r18.campaign == null ? null : campaign_r18.campaign.campaignId].length) > 0 || ctx_r17.canInvite[campaign_r18 == null ? null : campaign_r18.campaign == null ? null : campaign_r18.campaign.campaignId]);
    _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵadvance"](1);
    _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵproperty"]("ngIf", (ctx_r17.futureChallengesTeam[campaign_r18 == null ? null : campaign_r18.campaign == null ? null : campaign_r18.campaign.campaignId] == null ? null : ctx_r17.futureChallengesTeam[campaign_r18 == null ? null : campaign_r18.campaign == null ? null : campaign_r18.campaign.campaignId].length) > 0);
  }
}

function ChallengesPage_div_17_ng_container_1_Template(rf, ctx) {
  if (rf & 1) {
    _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵelementContainerStart"](0);
    _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵtemplate"](1, ChallengesPage_div_17_ng_container_1_div_1_Template, 3, 2, "div", 9);
    _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵelementContainerEnd"]();
  }

  if (rf & 2) {
    var ctx_r14 = _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵnextContext"](2);
    _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵadvance"](1);
    _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵproperty"]("ngForOf", ctx_r14.campaignsWithChallenges);
  }
}

function ChallengesPage_div_17_ng_template_2_Template(rf, ctx) {
  if (rf & 1) {
    _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵelementStart"](0, "div", 13);
    _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵtext"](1);
    _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵpipe"](2, "translate");
    _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵelementEnd"]();
  }

  if (rf & 2) {
    _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵadvance"](1);
    _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵtextInterpolate"](_angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵpipeBind1"](2, 1, "challenges.empty"));
  }
}

function ChallengesPage_div_17_Template(rf, ctx) {
  if (rf & 1) {
    _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵelementStart"](0, "div");
    _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵtemplate"](1, ChallengesPage_div_17_ng_container_1_Template, 2, 1, "ng-container", 7);
    _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵtemplate"](2, ChallengesPage_div_17_ng_template_2_Template, 3, 3, "ng-template", null, 14, _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵtemplateRefExtractor"]);
    _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵelementEnd"]();
  }

  if (rf & 2) {
    var _r15 = _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵreference"](3);

    var ctx_r2 = _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵnextContext"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵadvance"](1);
    _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵproperty"]("ngIf", ctx_r2.thereAreChallengeFuture || ctx_r2.userCanInvite)("ngIfElse", _r15);
  }
}

var ChallengesPage = /*#__PURE__*/function () {
  function ChallengesPage(challengeService, notificationService, activatedRoute) {
    (0,_Users_smartcommunitylab_Desktop_newWork_dslab_playgo_mobile_playgo_mobile_node_modules_babel_runtime_helpers_esm_classCallCheck_js__WEBPACK_IMPORTED_MODULE_1__["default"])(this, ChallengesPage);

    this.challengeService = challengeService;
    this.notificationService = notificationService;
    this.activatedRoute = activatedRoute;
    this.campaignsWithChallenges = [];
    this.thereAreChallengeActive = false;
    this.thereAreChallengeFuture = false;
    this.activeChallenges = {};
    this.activeChallengesTeam = {};
    this.futureChallenges = {};
    this.futureChallengesTeam = {};
    this.canInvite = {}; // public pastChallenges$: Observable<Challenge[]> =
    //   this.challengeService.pastChallenges$;

    this.activeChallenges$ = this.challengeService.activeChallenges$;
    this.futureChallenges$ = this.challengeService.futureChallenges$;
  }

  (0,_Users_smartcommunitylab_Desktop_newWork_dslab_playgo_mobile_playgo_mobile_node_modules_babel_runtime_helpers_esm_createClass_js__WEBPACK_IMPORTED_MODULE_2__["default"])(ChallengesPage, [{
    key: "ngOnInit",
    value: function ngOnInit() {}
  }, {
    key: "ionViewWillEnter",
    value: function ionViewWillEnter() {
      var _this = this;

      this.selectedSegment = 'activeChallenges';
      this.subSegment = this.activatedRoute.queryParams.subscribe(function (params) {
        if (params && params.selectedSegment) {
          //store the temp in data
          _this.selectedSegment = params.selectedSegment;
        }
      }); //mark common challenges notification as readed: activated, failed or completed

      this.notificationService.markCommonChallengeNotificationAsRead();
      this.subCampaignChall = this.challengeService.campaignsWithChallenges$.subscribe(function (campaigns) {
        _this.campaignsWithChallenges = campaigns;
      });
      this.subCampaignActiveChall = (0,rxjs__WEBPACK_IMPORTED_MODULE_6__.combineLatest)([this.challengeService.activeChallenges$, this.challengeService.activeChallengesTeam$]).subscribe(function (_ref) {
        var _ref2 = (0,_Users_smartcommunitylab_Desktop_newWork_dslab_playgo_mobile_playgo_mobile_node_modules_babel_runtime_helpers_esm_slicedToArray_js__WEBPACK_IMPORTED_MODULE_0__["default"])(_ref, 2),
            active = _ref2[0],
            team = _ref2[1];

        _this.activeChallenges = active.reduce(function (result, a) {
          return (result[a.campaign.campaignId] = result[a.campaign.campaignId] || []).push(a), result;
        }, {});
        _this.activeChallengesTeam = team.reduce(function (result, a) {
          return (result[a.campaign.campaignId] = result[a.campaign.campaignId] || []).push(a), result;
        }, {});

        if (active.length > 0 || team.length > 0) {
          _this.thereAreChallengeActive = true;
        } else {
          _this.thereAreChallengeActive = false;
        }
      });
      this.subCampaignFutureChall = (0,rxjs__WEBPACK_IMPORTED_MODULE_6__.combineLatest)([this.challengeService.futureChallenges$, this.challengeService.futureChallengesTeam$]).subscribe(function (_ref3) {
        var _ref4 = (0,_Users_smartcommunitylab_Desktop_newWork_dslab_playgo_mobile_playgo_mobile_node_modules_babel_runtime_helpers_esm_slicedToArray_js__WEBPACK_IMPORTED_MODULE_0__["default"])(_ref3, 2),
            future = _ref4[0],
            team = _ref4[1];

        _this.futureChallenges = future.reduce(function (result, a) {
          return (result[a.campaign.campaignId] = result[a.campaign.campaignId] || []).push(a), result;
        }, {});
        _this.futureChallengesTeam = team.reduce(function (result, a) {
          return (result[a.campaign.campaignId] = result[a.campaign.campaignId] || []).push(a), result;
        }, {});

        if (future.length > 0 || team.length > 0) {
          _this.thereAreChallengeFuture = true;
        } else {
          _this.thereAreChallengeFuture = false;
        }
      });
      this.subCampaignCanInvite = this.challengeService.canInvite$.subscribe(function (canInvite) {
        _this.canInvite = canInvite.reduce(function (result, a) {
          return result[a.campaign.campaignId] = a.canInvite || false, result;
        }, {});
        _this.userCanInvite = Object.values(_this.canInvite).some(function (x) {
          return x === true;
        });
      });
    }
  }, {
    key: "ngOnDestroy",
    value: function ngOnDestroy() {}
  }, {
    key: "ionViewDidLeave",
    value: function ionViewDidLeave() {
      var _a, _b, _c, _d, _e;

      (_a = this.subCampaignActiveChall) === null || _a === void 0 ? void 0 : _a.unsubscribe();
      (_b = this.subCampaignCanInvite) === null || _b === void 0 ? void 0 : _b.unsubscribe();
      (_c = this.subCampaignChall) === null || _c === void 0 ? void 0 : _c.unsubscribe();
      (_d = this.subCampaignFutureChall) === null || _d === void 0 ? void 0 : _d.unsubscribe();
      (_e = this.subSegment) === null || _e === void 0 ? void 0 : _e.unsubscribe();
    }
  }]);

  return ChallengesPage;
}();

ChallengesPage.ɵfac = function ChallengesPage_Factory(t) {
  return new (t || ChallengesPage)(_angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵdirectiveInject"](src_app_core_shared_services_challenge_service__WEBPACK_IMPORTED_MODULE_3__.ChallengeService), _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵdirectiveInject"](src_app_core_shared_services_notifications_notifications_service__WEBPACK_IMPORTED_MODULE_4__.NotificationService), _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵdirectiveInject"](_angular_router__WEBPACK_IMPORTED_MODULE_7__.ActivatedRoute));
};

ChallengesPage.ɵcmp = /*@__PURE__*/_angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵdefineComponent"]({
  type: ChallengesPage,
  selectors: [["app-challenges"]],
  viewQuery: function ChallengesPage_Query(rf, ctx) {
    if (rf & 1) {
      _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵviewQuery"](_c0, 5);
      _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵviewQuery"](_c1, 5);
    }

    if (rf & 2) {
      var _t;

      _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵqueryRefresh"](_t = _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵloadQuery"]()) && (ctx.activeChallengeChild = _t.first);
      _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵqueryRefresh"](_t = _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵloadQuery"]()) && (ctx.futureChallengeChild = _t.first);
    }
  },
  decls: 18,
  vars: 28,
  consts: [["appHeader", ""], ["appContent", "", 1, "page", 3, "fullscreen"], ["mode", "md", "scrollable", "", 1, "app-segment", 3, "ngModel", "ngModelChange"], ["value", "pastChallenges", "checked", "", "mode", "ios", 1, "app-segment-button"], ["value", "activeChallenges", "checked", "", "mode", "ios", 1, "app-segment-button"], ["value", "futureChallenges", "mode", "ios", 1, "app-segment-button"], [4, "ngIf"], [4, "ngIf", "ngIfElse"], ["noChallengeActive", ""], [4, "ngFor", "ngForOf"], [3, "campaign", "challenges", "type"], ["active", ""], [3, "campaign", "team", "challenges", "type"], [1, "empty-challenge"], ["noChallengeFuture", ""], [3, "campaign", "challenges", "type", "canInvite"], ["futuri", ""]],
  template: function ChallengesPage_Template(rf, ctx) {
    if (rf & 1) {
      _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵelement"](0, "ion-header", 0);
      _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵelementStart"](1, "ion-content", 1)(2, "ion-segment", 2);
      _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵlistener"]("ngModelChange", function ChallengesPage_Template_ion_segment_ngModelChange_2_listener($event) {
        return ctx.selectedSegment = $event;
      });
      _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵelementStart"](3, "ion-segment-button", 3)(4, "ion-label");
      _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵtext"](5);
      _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵpipe"](6, "translate");
      _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵelementEnd"]()();
      _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵelementStart"](7, "ion-segment-button", 4)(8, "ion-label");
      _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵtext"](9);
      _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵpipe"](10, "translate");
      _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵelementEnd"]()();
      _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵelementStart"](11, "ion-segment-button", 5)(12, "ion-label");
      _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵtext"](13);
      _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵpipe"](14, "translate");
      _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵelementEnd"]()()();
      _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵtemplate"](15, ChallengesPage_div_15_Template, 2, 0, "div", 6);
      _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵtemplate"](16, ChallengesPage_div_16_Template, 4, 2, "div", 6);
      _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵtemplate"](17, ChallengesPage_div_17_Template, 4, 2, "div", 6);
      _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵelementEnd"]();
    }

    if (rf & 2) {
      _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵadvance"](1);
      _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵproperty"]("fullscreen", true);
      _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵadvance"](1);
      _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵstyleProp"]("--background", "var(--ion-color-playgo)");
      _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵproperty"]("ngModel", ctx.selectedSegment);
      _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵadvance"](1);
      _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵstyleProp"]("--color", "white")("--color-checked", "black");
      _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵadvance"](2);
      _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵtextInterpolate"](_angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵpipeBind1"](6, 22, "challenges.past"));
      _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵadvance"](2);
      _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵstyleProp"]("--color", "white")("--color-checked", "black");
      _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵadvance"](2);
      _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵtextInterpolate"](_angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵpipeBind1"](10, 24, "challenges.present"));
      _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵadvance"](2);
      _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵstyleProp"]("--color", "white")("--color-checked", "black");
      _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵadvance"](2);
      _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵtextInterpolate"](_angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵpipeBind1"](14, 26, "challenges.future"));
      _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵadvance"](2);
      _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵproperty"]("ngIf", ctx.selectedSegment === "pastChallenges");
      _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵadvance"](1);
      _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵproperty"]("ngIf", ctx.selectedSegment === "activeChallenges");
      _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵadvance"](1);
      _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵproperty"]("ngIf", ctx.selectedSegment === "futureChallenges");
    }
  },
  styles: [".empty-challenge[_ngcontent-%COMP%] {\n  margin: auto;\n  padding: 8px;\n  font-size: 20px;\n  text-align: center;\n  -ms-transform: translateY(-50%);\n}\n/*# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbImNoYWxsZW5nZXMucGFnZS5zY3NzIl0sIm5hbWVzIjpbXSwibWFwcGluZ3MiOiJBQUFBO0VBQ0UsWUFBQTtFQUNBLFlBQUE7RUFDQSxlQUFBO0VBQ0Esa0JBQUE7RUFDQSwrQkFBQTtBQUNGIiwiZmlsZSI6ImNoYWxsZW5nZXMucGFnZS5zY3NzIiwic291cmNlc0NvbnRlbnQiOlsiLmVtcHR5LWNoYWxsZW5nZSB7XG4gIG1hcmdpbjogYXV0bztcbiAgcGFkZGluZzogOHB4O1xuICBmb250LXNpemU6IDIwcHg7XG4gIHRleHQtYWxpZ246IGNlbnRlcjtcbiAgLW1zLXRyYW5zZm9ybTogdHJhbnNsYXRlWSgtNTAlKTtcbn1cbiJdfQ== */"]
});

/***/ }),

/***/ 69537:
/*!***************************************************************************************************!*\
  !*** ./src/app/pages/challenges/couple-challenge-proposed/couple-challenge-proposed.component.ts ***!
  \***************************************************************************************************/
/***/ (function(__unused_webpack_module, __webpack_exports__, __webpack_require__) {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "CoupleChallengeProposedComponent": function() { return /* binding */ CoupleChallengeProposedComponent; }
/* harmony export */ });
/* harmony import */ var _Users_smartcommunitylab_Desktop_newWork_dslab_playgo_mobile_playgo_mobile_node_modules_babel_runtime_helpers_esm_classCallCheck_js__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./node_modules/@babel/runtime/helpers/esm/classCallCheck.js */ 78069);
/* harmony import */ var _Users_smartcommunitylab_Desktop_newWork_dslab_playgo_mobile_playgo_mobile_node_modules_babel_runtime_helpers_esm_createClass_js__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ./node_modules/@babel/runtime/helpers/esm/createClass.js */ 48047);
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(/*! tslib */ 42321);
/* harmony import */ var rxjs__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! rxjs */ 50635);
/* harmony import */ var _invitation_challenge_invitation_challenge_modal__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! ./invitation-challenge/invitation-challenge.modal */ 44018);
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(/*! @angular/core */ 3184);
/* harmony import */ var src_app_core_shared_services_user_service__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! src/app/core/shared/services/user.service */ 50749);
/* harmony import */ var _ionic_angular__WEBPACK_IMPORTED_MODULE_9__ = __webpack_require__(/*! @ionic/angular */ 93819);
/* harmony import */ var _core_shared_ui_icon_icon_component__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! ../../../core/shared/ui/icon/icon.component */ 71888);
/* harmony import */ var _angular_common__WEBPACK_IMPORTED_MODULE_10__ = __webpack_require__(/*! @angular/common */ 36362);
/* harmony import */ var _ngx_translate_core__WEBPACK_IMPORTED_MODULE_11__ = __webpack_require__(/*! @ngx-translate/core */ 87514);
/* harmony import */ var _core_shared_pipes_languageMap_pipe__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! ../../../core/shared/pipes/languageMap.pipe */ 73088);



function _regeneratorRuntime() { "use strict"; /*! regenerator-runtime -- Copyright (c) 2014-present, Facebook, Inc. -- license (MIT): https://github.com/facebook/regenerator/blob/main/LICENSE */ _regeneratorRuntime = function _regeneratorRuntime() { return e; }; var t, e = {}, r = Object.prototype, n = r.hasOwnProperty, o = Object.defineProperty || function (t, e, r) { t[e] = r.value; }, i = "function" == typeof Symbol ? Symbol : {}, a = i.iterator || "@@iterator", c = i.asyncIterator || "@@asyncIterator", u = i.toStringTag || "@@toStringTag"; function define(t, e, r) { return Object.defineProperty(t, e, { value: r, enumerable: !0, configurable: !0, writable: !0 }), t[e]; } try { define({}, ""); } catch (t) { define = function define(t, e, r) { return t[e] = r; }; } function wrap(t, e, r, n) { var i = e && e.prototype instanceof Generator ? e : Generator, a = Object.create(i.prototype), c = new Context(n || []); return o(a, "_invoke", { value: makeInvokeMethod(t, r, c) }), a; } function tryCatch(t, e, r) { try { return { type: "normal", arg: t.call(e, r) }; } catch (t) { return { type: "throw", arg: t }; } } e.wrap = wrap; var h = "suspendedStart", l = "suspendedYield", f = "executing", s = "completed", y = {}; function Generator() {} function GeneratorFunction() {} function GeneratorFunctionPrototype() {} var p = {}; define(p, a, function () { return this; }); var d = Object.getPrototypeOf, v = d && d(d(values([]))); v && v !== r && n.call(v, a) && (p = v); var g = GeneratorFunctionPrototype.prototype = Generator.prototype = Object.create(p); function defineIteratorMethods(t) { ["next", "throw", "return"].forEach(function (e) { define(t, e, function (t) { return this._invoke(e, t); }); }); } function AsyncIterator(t, e) { function invoke(r, o, i, a) { var c = tryCatch(t[r], t, o); if ("throw" !== c.type) { var u = c.arg, h = u.value; return h && "object" == typeof h && n.call(h, "__await") ? e.resolve(h.__await).then(function (t) { invoke("next", t, i, a); }, function (t) { invoke("throw", t, i, a); }) : e.resolve(h).then(function (t) { u.value = t, i(u); }, function (t) { return invoke("throw", t, i, a); }); } a(c.arg); } var r; o(this, "_invoke", { value: function value(t, n) { function callInvokeWithMethodAndArg() { return new e(function (e, r) { invoke(t, n, e, r); }); } return r = r ? r.then(callInvokeWithMethodAndArg, callInvokeWithMethodAndArg) : callInvokeWithMethodAndArg(); } }); } function makeInvokeMethod(e, r, n) { var o = h; return function (i, a) { if (o === f) throw new Error("Generator is already running"); if (o === s) { if ("throw" === i) throw a; return { value: t, done: !0 }; } for (n.method = i, n.arg = a;;) { var c = n.delegate; if (c) { var u = maybeInvokeDelegate(c, n); if (u) { if (u === y) continue; return u; } } if ("next" === n.method) n.sent = n._sent = n.arg;else if ("throw" === n.method) { if (o === h) throw o = s, n.arg; n.dispatchException(n.arg); } else "return" === n.method && n.abrupt("return", n.arg); o = f; var p = tryCatch(e, r, n); if ("normal" === p.type) { if (o = n.done ? s : l, p.arg === y) continue; return { value: p.arg, done: n.done }; } "throw" === p.type && (o = s, n.method = "throw", n.arg = p.arg); } }; } function maybeInvokeDelegate(e, r) { var n = r.method, o = e.iterator[n]; if (o === t) return r.delegate = null, "throw" === n && e.iterator.return && (r.method = "return", r.arg = t, maybeInvokeDelegate(e, r), "throw" === r.method) || "return" !== n && (r.method = "throw", r.arg = new TypeError("The iterator does not provide a '" + n + "' method")), y; var i = tryCatch(o, e.iterator, r.arg); if ("throw" === i.type) return r.method = "throw", r.arg = i.arg, r.delegate = null, y; var a = i.arg; return a ? a.done ? (r[e.resultName] = a.value, r.next = e.nextLoc, "return" !== r.method && (r.method = "next", r.arg = t), r.delegate = null, y) : a : (r.method = "throw", r.arg = new TypeError("iterator result is not an object"), r.delegate = null, y); } function pushTryEntry(t) { var e = { tryLoc: t[0] }; 1 in t && (e.catchLoc = t[1]), 2 in t && (e.finallyLoc = t[2], e.afterLoc = t[3]), this.tryEntries.push(e); } function resetTryEntry(t) { var e = t.completion || {}; e.type = "normal", delete e.arg, t.completion = e; } function Context(t) { this.tryEntries = [{ tryLoc: "root" }], t.forEach(pushTryEntry, this), this.reset(!0); } function values(e) { if (e || "" === e) { var r = e[a]; if (r) return r.call(e); if ("function" == typeof e.next) return e; if (!isNaN(e.length)) { var o = -1, i = function next() { for (; ++o < e.length;) if (n.call(e, o)) return next.value = e[o], next.done = !1, next; return next.value = t, next.done = !0, next; }; return i.next = i; } } throw new TypeError(typeof e + " is not iterable"); } return GeneratorFunction.prototype = GeneratorFunctionPrototype, o(g, "constructor", { value: GeneratorFunctionPrototype, configurable: !0 }), o(GeneratorFunctionPrototype, "constructor", { value: GeneratorFunction, configurable: !0 }), GeneratorFunction.displayName = define(GeneratorFunctionPrototype, u, "GeneratorFunction"), e.isGeneratorFunction = function (t) { var e = "function" == typeof t && t.constructor; return !!e && (e === GeneratorFunction || "GeneratorFunction" === (e.displayName || e.name)); }, e.mark = function (t) { return Object.setPrototypeOf ? Object.setPrototypeOf(t, GeneratorFunctionPrototype) : (t.__proto__ = GeneratorFunctionPrototype, define(t, u, "GeneratorFunction")), t.prototype = Object.create(g), t; }, e.awrap = function (t) { return { __await: t }; }, defineIteratorMethods(AsyncIterator.prototype), define(AsyncIterator.prototype, c, function () { return this; }), e.AsyncIterator = AsyncIterator, e.async = function (t, r, n, o, i) { void 0 === i && (i = Promise); var a = new AsyncIterator(wrap(t, r, n, o), i); return e.isGeneratorFunction(r) ? a : a.next().then(function (t) { return t.done ? t.value : a.next(); }); }, defineIteratorMethods(g), define(g, u, "Generator"), define(g, a, function () { return this; }), define(g, "toString", function () { return "[object Generator]"; }), e.keys = function (t) { var e = Object(t), r = []; for (var n in e) r.push(n); return r.reverse(), function next() { for (; r.length;) { var t = r.pop(); if (t in e) return next.value = t, next.done = !1, next; } return next.done = !0, next; }; }, e.values = values, Context.prototype = { constructor: Context, reset: function reset(e) { if (this.prev = 0, this.next = 0, this.sent = this._sent = t, this.done = !1, this.delegate = null, this.method = "next", this.arg = t, this.tryEntries.forEach(resetTryEntry), !e) for (var r in this) "t" === r.charAt(0) && n.call(this, r) && !isNaN(+r.slice(1)) && (this[r] = t); }, stop: function stop() { this.done = !0; var t = this.tryEntries[0].completion; if ("throw" === t.type) throw t.arg; return this.rval; }, dispatchException: function dispatchException(e) { if (this.done) throw e; var r = this; function handle(n, o) { return a.type = "throw", a.arg = e, r.next = n, o && (r.method = "next", r.arg = t), !!o; } for (var o = this.tryEntries.length - 1; o >= 0; --o) { var i = this.tryEntries[o], a = i.completion; if ("root" === i.tryLoc) return handle("end"); if (i.tryLoc <= this.prev) { var c = n.call(i, "catchLoc"), u = n.call(i, "finallyLoc"); if (c && u) { if (this.prev < i.catchLoc) return handle(i.catchLoc, !0); if (this.prev < i.finallyLoc) return handle(i.finallyLoc); } else if (c) { if (this.prev < i.catchLoc) return handle(i.catchLoc, !0); } else { if (!u) throw new Error("try statement without catch or finally"); if (this.prev < i.finallyLoc) return handle(i.finallyLoc); } } } }, abrupt: function abrupt(t, e) { for (var r = this.tryEntries.length - 1; r >= 0; --r) { var o = this.tryEntries[r]; if (o.tryLoc <= this.prev && n.call(o, "finallyLoc") && this.prev < o.finallyLoc) { var i = o; break; } } i && ("break" === t || "continue" === t) && i.tryLoc <= e && e <= i.finallyLoc && (i = null); var a = i ? i.completion : {}; return a.type = t, a.arg = e, i ? (this.method = "next", this.next = i.finallyLoc, y) : this.complete(a); }, complete: function complete(t, e) { if ("throw" === t.type) throw t.arg; return "break" === t.type || "continue" === t.type ? this.next = t.arg : "return" === t.type ? (this.rval = this.arg = t.arg, this.method = "return", this.next = "end") : "normal" === t.type && e && (this.next = e), y; }, finish: function finish(t) { for (var e = this.tryEntries.length - 1; e >= 0; --e) { var r = this.tryEntries[e]; if (r.finallyLoc === t) return this.complete(r.completion, r.afterLoc), resetTryEntry(r), y; } }, catch: function _catch(t) { for (var e = this.tryEntries.length - 1; e >= 0; --e) { var r = this.tryEntries[e]; if (r.tryLoc === t) { var n = r.completion; if ("throw" === n.type) { var o = n.arg; resetTryEntry(r); } return o; } } throw new Error("illegal catch attempt"); }, delegateYield: function delegateYield(e, r, n) { return this.delegate = { iterator: values(e), resultName: r, nextLoc: n }, "next" === this.method && (this.arg = t), y; } }, e; }












var _c0 = function _c0(a0) {
  return {
    nickname: a0
  };
};

var CoupleChallengeProposedComponent = /*#__PURE__*/function () {
  function CoupleChallengeProposedComponent(userService, modalController) {
    (0,_Users_smartcommunitylab_Desktop_newWork_dslab_playgo_mobile_playgo_mobile_node_modules_babel_runtime_helpers_esm_classCallCheck_js__WEBPACK_IMPORTED_MODULE_0__["default"])(this, CoupleChallengeProposedComponent);

    this.userService = userService;
    this.modalController = modalController;
    this.playerAvatarUrl$ = this.userService.userProfile$.pipe((0,rxjs__WEBPACK_IMPORTED_MODULE_6__.map)(function (userProfile) {
      return userProfile.avatar.avatarSmallUrl;
    }));
    this.playerId$ = this.userService.userProfile$.pipe((0,rxjs__WEBPACK_IMPORTED_MODULE_6__.map)(function (userProfile) {
      return userProfile.playerId;
    }));
  }

  (0,_Users_smartcommunitylab_Desktop_newWork_dslab_playgo_mobile_playgo_mobile_node_modules_babel_runtime_helpers_esm_createClass_js__WEBPACK_IMPORTED_MODULE_1__["default"])(CoupleChallengeProposedComponent, [{
    key: "ngOnInit",
    value: function ngOnInit() {}
  }, {
    key: "openInvitationPopup",
    value: function openInvitationPopup() {
      return (0,tslib__WEBPACK_IMPORTED_MODULE_7__.__awaiter)(this, void 0, void 0, /*#__PURE__*/_regeneratorRuntime().mark(function _callee() {
        var modal, _yield$modal$onWillDi, data;

        return _regeneratorRuntime().wrap(function _callee$(_context) {
          while (1) switch (_context.prev = _context.next) {
            case 0:
              _context.next = 2;
              return this.modalController.create({
                component: _invitation_challenge_invitation_challenge_modal__WEBPACK_IMPORTED_MODULE_2__.InvitationlModalPage,
                cssClass: 'modal-challenge',
                componentProps: {
                  challenge: this.challenge,
                  campaign: this.campaign
                },
                swipeToClose: true
              });

            case 2:
              modal = _context.sent;
              _context.next = 5;
              return modal.present();

            case 5:
              _context.next = 7;
              return modal.onWillDismiss();

            case 7:
              _yield$modal$onWillDi = _context.sent;
              data = _yield$modal$onWillDi.data;

            case 9:
            case "end":
              return _context.stop();
          }
        }, _callee, this);
      }));
    }
  }]);

  return CoupleChallengeProposedComponent;
}();

CoupleChallengeProposedComponent.ɵfac = function CoupleChallengeProposedComponent_Factory(t) {
  return new (t || CoupleChallengeProposedComponent)(_angular_core__WEBPACK_IMPORTED_MODULE_8__["ɵɵdirectiveInject"](src_app_core_shared_services_user_service__WEBPACK_IMPORTED_MODULE_3__.UserService), _angular_core__WEBPACK_IMPORTED_MODULE_8__["ɵɵdirectiveInject"](_ionic_angular__WEBPACK_IMPORTED_MODULE_9__.ModalController));
};

CoupleChallengeProposedComponent.ɵcmp = /*@__PURE__*/_angular_core__WEBPACK_IMPORTED_MODULE_8__["ɵɵdefineComponent"]({
  type: CoupleChallengeProposedComponent,
  selectors: [["app-couple-challenge-proposed"]],
  inputs: {
    challenge: "challenge",
    campaign: "campaign"
  },
  decls: 20,
  vars: 24,
  consts: [[3, "click"], [1, "header", 3, "color"], [1, "content"], [1, "ion-align-items-center"], ["size", "2"], [1, "avatar"], [3, "src", "title"], [1, "icon-size-medium", 3, "name"], [1, "flex-center"]],
  template: function CoupleChallengeProposedComponent_Template(rf, ctx) {
    if (rf & 1) {
      _angular_core__WEBPACK_IMPORTED_MODULE_8__["ɵɵelementStart"](0, "ion-card", 0);
      _angular_core__WEBPACK_IMPORTED_MODULE_8__["ɵɵlistener"]("click", function CoupleChallengeProposedComponent_Template_ion_card_click_0_listener() {
        return ctx.openInvitationPopup();
      });
      _angular_core__WEBPACK_IMPORTED_MODULE_8__["ɵɵelementStart"](1, "ion-card-header", 1)(2, "span");
      _angular_core__WEBPACK_IMPORTED_MODULE_8__["ɵɵtext"](3);
      _angular_core__WEBPACK_IMPORTED_MODULE_8__["ɵɵpipe"](4, "async");
      _angular_core__WEBPACK_IMPORTED_MODULE_8__["ɵɵpipe"](5, "translate");
      _angular_core__WEBPACK_IMPORTED_MODULE_8__["ɵɵpipe"](6, "translate");
      _angular_core__WEBPACK_IMPORTED_MODULE_8__["ɵɵelementEnd"]()();
      _angular_core__WEBPACK_IMPORTED_MODULE_8__["ɵɵelementStart"](7, "ion-card-content", 2)(8, "ion-grid")(9, "ion-row", 3)(10, "ion-col", 4)(11, "ion-avatar", 5);
      _angular_core__WEBPACK_IMPORTED_MODULE_8__["ɵɵelement"](12, "img", 6);
      _angular_core__WEBPACK_IMPORTED_MODULE_8__["ɵɵpipe"](13, "translate");
      _angular_core__WEBPACK_IMPORTED_MODULE_8__["ɵɵelementEnd"]();
      _angular_core__WEBPACK_IMPORTED_MODULE_8__["ɵɵelement"](14, "app-icon", 7);
      _angular_core__WEBPACK_IMPORTED_MODULE_8__["ɵɵpipe"](15, "async");
      _angular_core__WEBPACK_IMPORTED_MODULE_8__["ɵɵelementEnd"]();
      _angular_core__WEBPACK_IMPORTED_MODULE_8__["ɵɵelementStart"](16, "ion-col", 8)(17, "span");
      _angular_core__WEBPACK_IMPORTED_MODULE_8__["ɵɵtext"](18);
      _angular_core__WEBPACK_IMPORTED_MODULE_8__["ɵɵpipe"](19, "languageMap");
      _angular_core__WEBPACK_IMPORTED_MODULE_8__["ɵɵelementEnd"]()()()()()();
    }

    if (rf & 2) {
      _angular_core__WEBPACK_IMPORTED_MODULE_8__["ɵɵadvance"](1);
      _angular_core__WEBPACK_IMPORTED_MODULE_8__["ɵɵproperty"]("color", ctx.campaign.campaign.type);
      _angular_core__WEBPACK_IMPORTED_MODULE_8__["ɵɵadvance"](2);
      _angular_core__WEBPACK_IMPORTED_MODULE_8__["ɵɵtextInterpolate1"](" ", _angular_core__WEBPACK_IMPORTED_MODULE_8__["ɵɵpipeBind1"](4, 6, ctx.playerId$) === ctx.challenge.proposerId ? _angular_core__WEBPACK_IMPORTED_MODULE_8__["ɵɵpipeBind2"](5, 8, "challenges.sent", _angular_core__WEBPACK_IMPORTED_MODULE_8__["ɵɵpureFunction1"](20, _c0, ctx.challenge.otherAttendeeData.nickname)) : _angular_core__WEBPACK_IMPORTED_MODULE_8__["ɵɵpipeBind2"](6, 11, "challenges.received", _angular_core__WEBPACK_IMPORTED_MODULE_8__["ɵɵpureFunction1"](22, _c0, ctx.challenge.otherAttendeeData.nickname)), " ");
      _angular_core__WEBPACK_IMPORTED_MODULE_8__["ɵɵadvance"](9);
      _angular_core__WEBPACK_IMPORTED_MODULE_8__["ɵɵpropertyInterpolate"]("title", _angular_core__WEBPACK_IMPORTED_MODULE_8__["ɵɵpipeBind1"](13, 14, "registration.avatar.title"));
      _angular_core__WEBPACK_IMPORTED_MODULE_8__["ɵɵproperty"]("src", ctx.challenge.otherAttendeeData.avatar.url, _angular_core__WEBPACK_IMPORTED_MODULE_8__["ɵɵsanitizeUrl"]);
      _angular_core__WEBPACK_IMPORTED_MODULE_8__["ɵɵadvance"](2);
      _angular_core__WEBPACK_IMPORTED_MODULE_8__["ɵɵproperty"]("name", _angular_core__WEBPACK_IMPORTED_MODULE_8__["ɵɵpipeBind1"](15, 16, ctx.playerId$) === ctx.challenge.proposerId ? "invite" : "invitation");
      _angular_core__WEBPACK_IMPORTED_MODULE_8__["ɵɵadvance"](4);
      _angular_core__WEBPACK_IMPORTED_MODULE_8__["ɵɵtextInterpolate"](_angular_core__WEBPACK_IMPORTED_MODULE_8__["ɵɵpipeBind1"](19, 18, ctx.challenge.challDesc));
    }
  },
  directives: [_ionic_angular__WEBPACK_IMPORTED_MODULE_9__.IonCard, _ionic_angular__WEBPACK_IMPORTED_MODULE_9__.IonCardHeader, _ionic_angular__WEBPACK_IMPORTED_MODULE_9__.IonCardContent, _ionic_angular__WEBPACK_IMPORTED_MODULE_9__.IonGrid, _ionic_angular__WEBPACK_IMPORTED_MODULE_9__.IonRow, _ionic_angular__WEBPACK_IMPORTED_MODULE_9__.IonCol, _ionic_angular__WEBPACK_IMPORTED_MODULE_9__.IonAvatar, _core_shared_ui_icon_icon_component__WEBPACK_IMPORTED_MODULE_4__.IconComponent],
  pipes: [_angular_common__WEBPACK_IMPORTED_MODULE_10__.AsyncPipe, _ngx_translate_core__WEBPACK_IMPORTED_MODULE_11__.TranslatePipe, _core_shared_pipes_languageMap_pipe__WEBPACK_IMPORTED_MODULE_5__.LanguageMapPipe],
  styles: [".header[_ngcontent-%COMP%] {\n  text-align: end;\n  padding: 2px;\n  font-style: italic;\n}\n.header[_ngcontent-%COMP%]   span[_ngcontent-%COMP%] {\n  margin: 4px;\n}\n.content[_ngcontent-%COMP%] {\n  padding: 2px 8px;\n  display: flex;\n  align-items: center;\n}\n.content[_ngcontent-%COMP%]   span[_ngcontent-%COMP%] {\n  font-style: normal;\n  font-weight: 300;\n  font-size: 13px;\n  width: 100%;\n  text-align: center;\n  display: -webkit-box;\n  -webkit-line-clamp: 2;\n  -webkit-box-orient: vertical;\n  overflow: hidden;\n  text-overflow: ellipsis;\n}\nion-avatar[_ngcontent-%COMP%] {\n  position: absolute;\n  width: 25px;\n  height: 25px;\n  left: -7px;\n  top: 5px;\n}\n/*# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbImNvdXBsZS1jaGFsbGVuZ2UtcHJvcG9zZWQuY29tcG9uZW50LnNjc3MiXSwibmFtZXMiOltdLCJtYXBwaW5ncyI6IkFBQUE7RUFDRSxlQUFBO0VBQ0EsWUFBQTtFQUNBLGtCQUFBO0FBQ0Y7QUFBRTtFQUNFLFdBQUE7QUFFSjtBQUNBO0VBQ0UsZ0JBQUE7RUFDQSxhQUFBO0VBQ0EsbUJBQUE7QUFFRjtBQURFO0VBQ0Usa0JBQUE7RUFDQSxnQkFBQTtFQUNBLGVBQUE7RUFDQSxXQUFBO0VBQ0Esa0JBQUE7RUFDQSxvQkFBQTtFQUNBLHFCQUFBO0VBQ0EsNEJBQUE7RUFDQSxnQkFBQTtFQUNBLHVCQUFBO0FBR0o7QUFBQTtFQUNFLGtCQUFBO0VBQ0EsV0FBQTtFQUNBLFlBQUE7RUFDQSxVQUFBO0VBQ0EsUUFBQTtBQUdGIiwiZmlsZSI6ImNvdXBsZS1jaGFsbGVuZ2UtcHJvcG9zZWQuY29tcG9uZW50LnNjc3MiLCJzb3VyY2VzQ29udGVudCI6WyIuaGVhZGVyIHtcbiAgdGV4dC1hbGlnbjogZW5kO1xuICBwYWRkaW5nOiAycHg7XG4gIGZvbnQtc3R5bGU6IGl0YWxpYztcbiAgc3BhbiB7XG4gICAgbWFyZ2luOiA0cHg7XG4gIH1cbn1cbi5jb250ZW50IHtcbiAgcGFkZGluZzogMnB4IDhweDtcbiAgZGlzcGxheTogZmxleDtcbiAgYWxpZ24taXRlbXM6IGNlbnRlcjtcbiAgc3BhbiB7XG4gICAgZm9udC1zdHlsZTogbm9ybWFsO1xuICAgIGZvbnQtd2VpZ2h0OiAzMDA7XG4gICAgZm9udC1zaXplOiAxM3B4O1xuICAgIHdpZHRoOiAxMDAlO1xuICAgIHRleHQtYWxpZ246IGNlbnRlcjtcbiAgICBkaXNwbGF5OiAtd2Via2l0LWJveDtcbiAgICAtd2Via2l0LWxpbmUtY2xhbXA6IDI7XG4gICAgLXdlYmtpdC1ib3gtb3JpZW50OiB2ZXJ0aWNhbDtcbiAgICBvdmVyZmxvdzogaGlkZGVuO1xuICAgIHRleHQtb3ZlcmZsb3c6IGVsbGlwc2lzO1xuICB9XG59XG5pb24tYXZhdGFyIHtcbiAgcG9zaXRpb246IGFic29sdXRlO1xuICB3aWR0aDogMjVweDtcbiAgaGVpZ2h0OiAyNXB4O1xuICBsZWZ0OiAtN3B4O1xuICB0b3A6IDVweDtcbn1cbiJdfQ== */"]
});

/***/ }),

/***/ 44018:
/*!***************************************************************************************************************!*\
  !*** ./src/app/pages/challenges/couple-challenge-proposed/invitation-challenge/invitation-challenge.modal.ts ***!
  \***************************************************************************************************************/
/***/ (function(__unused_webpack_module, __webpack_exports__, __webpack_require__) {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "InvitationlModalPage": function() { return /* binding */ InvitationlModalPage; }
/* harmony export */ });
/* harmony import */ var _Users_smartcommunitylab_Desktop_newWork_dslab_playgo_mobile_playgo_mobile_node_modules_babel_runtime_helpers_esm_classCallCheck_js__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./node_modules/@babel/runtime/helpers/esm/classCallCheck.js */ 78069);
/* harmony import */ var _Users_smartcommunitylab_Desktop_newWork_dslab_playgo_mobile_playgo_mobile_node_modules_babel_runtime_helpers_esm_createClass_js__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ./node_modules/@babel/runtime/helpers/esm/createClass.js */ 48047);
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_10__ = __webpack_require__(/*! tslib */ 42321);
/* harmony import */ var rxjs__WEBPACK_IMPORTED_MODULE_9__ = __webpack_require__(/*! rxjs */ 50635);
/* harmony import */ var src_app_core_shared_campaigns_campaign_utils__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! src/app/core/shared/campaigns/campaign.utils */ 87725);
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(/*! @angular/core */ 3184);
/* harmony import */ var _ionic_angular__WEBPACK_IMPORTED_MODULE_11__ = __webpack_require__(/*! @ionic/angular */ 93819);
/* harmony import */ var src_app_core_shared_services_user_service__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! src/app/core/shared/services/user.service */ 50749);
/* harmony import */ var src_app_core_shared_services_challenge_service__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! src/app/core/shared/services/challenge.service */ 66324);
/* harmony import */ var _ngx_translate_core__WEBPACK_IMPORTED_MODULE_12__ = __webpack_require__(/*! @ngx-translate/core */ 87514);
/* harmony import */ var src_app_core_shared_services_error_service__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! src/app/core/shared/services/error.service */ 96204);
/* harmony import */ var _core_shared_ui_icon_icon_component__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! ../../../../core/shared/ui/icon/icon.component */ 71888);
/* harmony import */ var _angular_common__WEBPACK_IMPORTED_MODULE_13__ = __webpack_require__(/*! @angular/common */ 36362);
/* harmony import */ var _core_shared_pipes_languageMap_pipe__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(/*! ../../../../core/shared/pipes/languageMap.pipe */ 73088);



function _regeneratorRuntime() { "use strict"; /*! regenerator-runtime -- Copyright (c) 2014-present, Facebook, Inc. -- license (MIT): https://github.com/facebook/regenerator/blob/main/LICENSE */ _regeneratorRuntime = function _regeneratorRuntime() { return e; }; var t, e = {}, r = Object.prototype, n = r.hasOwnProperty, o = Object.defineProperty || function (t, e, r) { t[e] = r.value; }, i = "function" == typeof Symbol ? Symbol : {}, a = i.iterator || "@@iterator", c = i.asyncIterator || "@@asyncIterator", u = i.toStringTag || "@@toStringTag"; function define(t, e, r) { return Object.defineProperty(t, e, { value: r, enumerable: !0, configurable: !0, writable: !0 }), t[e]; } try { define({}, ""); } catch (t) { define = function define(t, e, r) { return t[e] = r; }; } function wrap(t, e, r, n) { var i = e && e.prototype instanceof Generator ? e : Generator, a = Object.create(i.prototype), c = new Context(n || []); return o(a, "_invoke", { value: makeInvokeMethod(t, r, c) }), a; } function tryCatch(t, e, r) { try { return { type: "normal", arg: t.call(e, r) }; } catch (t) { return { type: "throw", arg: t }; } } e.wrap = wrap; var h = "suspendedStart", l = "suspendedYield", f = "executing", s = "completed", y = {}; function Generator() {} function GeneratorFunction() {} function GeneratorFunctionPrototype() {} var p = {}; define(p, a, function () { return this; }); var d = Object.getPrototypeOf, v = d && d(d(values([]))); v && v !== r && n.call(v, a) && (p = v); var g = GeneratorFunctionPrototype.prototype = Generator.prototype = Object.create(p); function defineIteratorMethods(t) { ["next", "throw", "return"].forEach(function (e) { define(t, e, function (t) { return this._invoke(e, t); }); }); } function AsyncIterator(t, e) { function invoke(r, o, i, a) { var c = tryCatch(t[r], t, o); if ("throw" !== c.type) { var u = c.arg, h = u.value; return h && "object" == typeof h && n.call(h, "__await") ? e.resolve(h.__await).then(function (t) { invoke("next", t, i, a); }, function (t) { invoke("throw", t, i, a); }) : e.resolve(h).then(function (t) { u.value = t, i(u); }, function (t) { return invoke("throw", t, i, a); }); } a(c.arg); } var r; o(this, "_invoke", { value: function value(t, n) { function callInvokeWithMethodAndArg() { return new e(function (e, r) { invoke(t, n, e, r); }); } return r = r ? r.then(callInvokeWithMethodAndArg, callInvokeWithMethodAndArg) : callInvokeWithMethodAndArg(); } }); } function makeInvokeMethod(e, r, n) { var o = h; return function (i, a) { if (o === f) throw new Error("Generator is already running"); if (o === s) { if ("throw" === i) throw a; return { value: t, done: !0 }; } for (n.method = i, n.arg = a;;) { var c = n.delegate; if (c) { var u = maybeInvokeDelegate(c, n); if (u) { if (u === y) continue; return u; } } if ("next" === n.method) n.sent = n._sent = n.arg;else if ("throw" === n.method) { if (o === h) throw o = s, n.arg; n.dispatchException(n.arg); } else "return" === n.method && n.abrupt("return", n.arg); o = f; var p = tryCatch(e, r, n); if ("normal" === p.type) { if (o = n.done ? s : l, p.arg === y) continue; return { value: p.arg, done: n.done }; } "throw" === p.type && (o = s, n.method = "throw", n.arg = p.arg); } }; } function maybeInvokeDelegate(e, r) { var n = r.method, o = e.iterator[n]; if (o === t) return r.delegate = null, "throw" === n && e.iterator.return && (r.method = "return", r.arg = t, maybeInvokeDelegate(e, r), "throw" === r.method) || "return" !== n && (r.method = "throw", r.arg = new TypeError("The iterator does not provide a '" + n + "' method")), y; var i = tryCatch(o, e.iterator, r.arg); if ("throw" === i.type) return r.method = "throw", r.arg = i.arg, r.delegate = null, y; var a = i.arg; return a ? a.done ? (r[e.resultName] = a.value, r.next = e.nextLoc, "return" !== r.method && (r.method = "next", r.arg = t), r.delegate = null, y) : a : (r.method = "throw", r.arg = new TypeError("iterator result is not an object"), r.delegate = null, y); } function pushTryEntry(t) { var e = { tryLoc: t[0] }; 1 in t && (e.catchLoc = t[1]), 2 in t && (e.finallyLoc = t[2], e.afterLoc = t[3]), this.tryEntries.push(e); } function resetTryEntry(t) { var e = t.completion || {}; e.type = "normal", delete e.arg, t.completion = e; } function Context(t) { this.tryEntries = [{ tryLoc: "root" }], t.forEach(pushTryEntry, this), this.reset(!0); } function values(e) { if (e || "" === e) { var r = e[a]; if (r) return r.call(e); if ("function" == typeof e.next) return e; if (!isNaN(e.length)) { var o = -1, i = function next() { for (; ++o < e.length;) if (n.call(e, o)) return next.value = e[o], next.done = !1, next; return next.value = t, next.done = !0, next; }; return i.next = i; } } throw new TypeError(typeof e + " is not iterable"); } return GeneratorFunction.prototype = GeneratorFunctionPrototype, o(g, "constructor", { value: GeneratorFunctionPrototype, configurable: !0 }), o(GeneratorFunctionPrototype, "constructor", { value: GeneratorFunction, configurable: !0 }), GeneratorFunction.displayName = define(GeneratorFunctionPrototype, u, "GeneratorFunction"), e.isGeneratorFunction = function (t) { var e = "function" == typeof t && t.constructor; return !!e && (e === GeneratorFunction || "GeneratorFunction" === (e.displayName || e.name)); }, e.mark = function (t) { return Object.setPrototypeOf ? Object.setPrototypeOf(t, GeneratorFunctionPrototype) : (t.__proto__ = GeneratorFunctionPrototype, define(t, u, "GeneratorFunction")), t.prototype = Object.create(g), t; }, e.awrap = function (t) { return { __await: t }; }, defineIteratorMethods(AsyncIterator.prototype), define(AsyncIterator.prototype, c, function () { return this; }), e.AsyncIterator = AsyncIterator, e.async = function (t, r, n, o, i) { void 0 === i && (i = Promise); var a = new AsyncIterator(wrap(t, r, n, o), i); return e.isGeneratorFunction(r) ? a : a.next().then(function (t) { return t.done ? t.value : a.next(); }); }, defineIteratorMethods(g), define(g, u, "Generator"), define(g, a, function () { return this; }), define(g, "toString", function () { return "[object Generator]"; }), e.keys = function (t) { var e = Object(t), r = []; for (var n in e) r.push(n); return r.reverse(), function next() { for (; r.length;) { var t = r.pop(); if (t in e) return next.value = t, next.done = !1, next; } return next.done = !0, next; }; }, e.values = values, Context.prototype = { constructor: Context, reset: function reset(e) { if (this.prev = 0, this.next = 0, this.sent = this._sent = t, this.done = !1, this.delegate = null, this.method = "next", this.arg = t, this.tryEntries.forEach(resetTryEntry), !e) for (var r in this) "t" === r.charAt(0) && n.call(this, r) && !isNaN(+r.slice(1)) && (this[r] = t); }, stop: function stop() { this.done = !0; var t = this.tryEntries[0].completion; if ("throw" === t.type) throw t.arg; return this.rval; }, dispatchException: function dispatchException(e) { if (this.done) throw e; var r = this; function handle(n, o) { return a.type = "throw", a.arg = e, r.next = n, o && (r.method = "next", r.arg = t), !!o; } for (var o = this.tryEntries.length - 1; o >= 0; --o) { var i = this.tryEntries[o], a = i.completion; if ("root" === i.tryLoc) return handle("end"); if (i.tryLoc <= this.prev) { var c = n.call(i, "catchLoc"), u = n.call(i, "finallyLoc"); if (c && u) { if (this.prev < i.catchLoc) return handle(i.catchLoc, !0); if (this.prev < i.finallyLoc) return handle(i.finallyLoc); } else if (c) { if (this.prev < i.catchLoc) return handle(i.catchLoc, !0); } else { if (!u) throw new Error("try statement without catch or finally"); if (this.prev < i.finallyLoc) return handle(i.finallyLoc); } } } }, abrupt: function abrupt(t, e) { for (var r = this.tryEntries.length - 1; r >= 0; --r) { var o = this.tryEntries[r]; if (o.tryLoc <= this.prev && n.call(o, "finallyLoc") && this.prev < o.finallyLoc) { var i = o; break; } } i && ("break" === t || "continue" === t) && i.tryLoc <= e && e <= i.finallyLoc && (i = null); var a = i ? i.completion : {}; return a.type = t, a.arg = e, i ? (this.method = "next", this.next = i.finallyLoc, y) : this.complete(a); }, complete: function complete(t, e) { if ("throw" === t.type) throw t.arg; return "break" === t.type || "continue" === t.type ? this.next = t.arg : "return" === t.type ? (this.rval = this.arg = t.arg, this.method = "return", this.next = "end") : "normal" === t.type && e && (this.next = e), y; }, finish: function finish(t) { for (var e = this.tryEntries.length - 1; e >= 0; --e) { var r = this.tryEntries[e]; if (r.finallyLoc === t) return this.complete(r.completion, r.afterLoc), resetTryEntry(r), y; } }, catch: function _catch(t) { for (var e = this.tryEntries.length - 1; e >= 0; --e) { var r = this.tryEntries[e]; if (r.tryLoc === t) { var n = r.completion; if ("throw" === n.type) { var o = n.arg; resetTryEntry(r); } return o; } } throw new Error("illegal catch attempt"); }, delegateYield: function delegateYield(e, r, n) { return this.delegate = { iterator: values(e), resultName: r, nextLoc: n }, "next" === this.method && (this.arg = t), y; } }, e; }














function InvitationlModalPage_ion_row_26_Template(rf, ctx) {
  if (rf & 1) {
    var _r4 = _angular_core__WEBPACK_IMPORTED_MODULE_8__["ɵɵgetCurrentView"]();

    _angular_core__WEBPACK_IMPORTED_MODULE_8__["ɵɵelementStart"](0, "ion-row")(1, "ion-col", 15)(2, "ion-button", 16);
    _angular_core__WEBPACK_IMPORTED_MODULE_8__["ɵɵlistener"]("click", function InvitationlModalPage_ion_row_26_Template_ion_button_click_2_listener() {
      _angular_core__WEBPACK_IMPORTED_MODULE_8__["ɵɵrestoreView"](_r4);
      var ctx_r3 = _angular_core__WEBPACK_IMPORTED_MODULE_8__["ɵɵnextContext"]();
      return ctx_r3.activate();
    });
    _angular_core__WEBPACK_IMPORTED_MODULE_8__["ɵɵtext"](3);
    _angular_core__WEBPACK_IMPORTED_MODULE_8__["ɵɵpipe"](4, "translate");
    _angular_core__WEBPACK_IMPORTED_MODULE_8__["ɵɵelementEnd"]()();
    _angular_core__WEBPACK_IMPORTED_MODULE_8__["ɵɵelementStart"](5, "ion-col", 15)(6, "ion-button", 17);
    _angular_core__WEBPACK_IMPORTED_MODULE_8__["ɵɵlistener"]("click", function InvitationlModalPage_ion_row_26_Template_ion_button_click_6_listener() {
      _angular_core__WEBPACK_IMPORTED_MODULE_8__["ɵɵrestoreView"](_r4);
      var ctx_r5 = _angular_core__WEBPACK_IMPORTED_MODULE_8__["ɵɵnextContext"]();
      return ctx_r5.reject();
    });
    _angular_core__WEBPACK_IMPORTED_MODULE_8__["ɵɵtext"](7);
    _angular_core__WEBPACK_IMPORTED_MODULE_8__["ɵɵpipe"](8, "translate");
    _angular_core__WEBPACK_IMPORTED_MODULE_8__["ɵɵelementEnd"]()()();
  }

  if (rf & 2) {
    var ctx_r0 = _angular_core__WEBPACK_IMPORTED_MODULE_8__["ɵɵnextContext"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_8__["ɵɵadvance"](2);
    _angular_core__WEBPACK_IMPORTED_MODULE_8__["ɵɵproperty"]("color", ctx_r0.campaign == null ? null : ctx_r0.campaign.campaign == null ? null : ctx_r0.campaign.campaign.type);
    _angular_core__WEBPACK_IMPORTED_MODULE_8__["ɵɵadvance"](1);
    _angular_core__WEBPACK_IMPORTED_MODULE_8__["ɵɵtextInterpolate1"](" ", _angular_core__WEBPACK_IMPORTED_MODULE_8__["ɵɵpipeBind1"](4, 3, "challenges.activate"), " ");
    _angular_core__WEBPACK_IMPORTED_MODULE_8__["ɵɵadvance"](4);
    _angular_core__WEBPACK_IMPORTED_MODULE_8__["ɵɵtextInterpolate1"](" ", _angular_core__WEBPACK_IMPORTED_MODULE_8__["ɵɵpipeBind1"](8, 5, "challenges.reject"), " ");
  }
}

function InvitationlModalPage_ng_template_28_Template(rf, ctx) {
  if (rf & 1) {
    var _r7 = _angular_core__WEBPACK_IMPORTED_MODULE_8__["ɵɵgetCurrentView"]();

    _angular_core__WEBPACK_IMPORTED_MODULE_8__["ɵɵelementStart"](0, "ion-row")(1, "ion-col", 15)(2, "ion-button", 16);
    _angular_core__WEBPACK_IMPORTED_MODULE_8__["ɵɵlistener"]("click", function InvitationlModalPage_ng_template_28_Template_ion_button_click_2_listener() {
      _angular_core__WEBPACK_IMPORTED_MODULE_8__["ɵɵrestoreView"](_r7);
      var ctx_r6 = _angular_core__WEBPACK_IMPORTED_MODULE_8__["ɵɵnextContext"]();
      return ctx_r6.cancel();
    });
    _angular_core__WEBPACK_IMPORTED_MODULE_8__["ɵɵtext"](3);
    _angular_core__WEBPACK_IMPORTED_MODULE_8__["ɵɵpipe"](4, "translate");
    _angular_core__WEBPACK_IMPORTED_MODULE_8__["ɵɵelementEnd"]()()();
  }

  if (rf & 2) {
    var ctx_r2 = _angular_core__WEBPACK_IMPORTED_MODULE_8__["ɵɵnextContext"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_8__["ɵɵadvance"](2);
    _angular_core__WEBPACK_IMPORTED_MODULE_8__["ɵɵproperty"]("color", ctx_r2.campaign == null ? null : ctx_r2.campaign.campaign == null ? null : ctx_r2.campaign.campaign.type);
    _angular_core__WEBPACK_IMPORTED_MODULE_8__["ɵɵadvance"](1);
    _angular_core__WEBPACK_IMPORTED_MODULE_8__["ɵɵtextInterpolate1"](" ", _angular_core__WEBPACK_IMPORTED_MODULE_8__["ɵɵpipeBind1"](4, 2, "challenges.cancel"), " ");
  }
}

var InvitationlModalPage = /*#__PURE__*/function () {
  function InvitationlModalPage(modalController, userService, challengeService, translateService, errorService) {
    (0,_Users_smartcommunitylab_Desktop_newWork_dslab_playgo_mobile_playgo_mobile_node_modules_babel_runtime_helpers_esm_classCallCheck_js__WEBPACK_IMPORTED_MODULE_0__["default"])(this, InvitationlModalPage);

    this.modalController = modalController;
    this.userService = userService;
    this.challengeService = challengeService;
    this.translateService = translateService;
    this.errorService = errorService;
    this.playerId$ = this.userService.userProfile$.pipe((0,rxjs__WEBPACK_IMPORTED_MODULE_9__.map)(function (userProfile) {
      return userProfile.playerId;
    }));
  }

  (0,_Users_smartcommunitylab_Desktop_newWork_dslab_playgo_mobile_playgo_mobile_node_modules_babel_runtime_helpers_esm_createClass_js__WEBPACK_IMPORTED_MODULE_1__["default"])(InvitationlModalPage, [{
    key: "ngOnInit",
    value: function ngOnInit() {
      this.typeChallenge = this.translateService.instant((0,src_app_core_shared_campaigns_campaign_utils__WEBPACK_IMPORTED_MODULE_2__.getTypeStringChallenge)(this.challenge.type));
    } //computed errorcontrol

  }, {
    key: "close",
    value: function close() {
      this.modalController.dismiss(false);
    }
  }, {
    key: "activate",
    value: function activate() {
      return (0,tslib__WEBPACK_IMPORTED_MODULE_10__.__awaiter)(this, void 0, void 0, /*#__PURE__*/_regeneratorRuntime().mark(function _callee() {
        return _regeneratorRuntime().wrap(function _callee$(_context) {
          while (1) switch (_context.prev = _context.next) {
            case 0:
              _context.prev = 0;
              _context.next = 3;
              return this.challengeService.acceptChallenge(this.campaign, this.challenge);

            case 3:
              _context.next = 8;
              break;

            case 5:
              _context.prev = 5;
              _context.t0 = _context["catch"](0);
              this.errorService.handleError(_context.t0);

            case 8:
              _context.prev = 8;
              this.modalController.dismiss(false);
              return _context.finish(8);

            case 11:
            case "end":
              return _context.stop();
          }
        }, _callee, this, [[0, 5, 8, 11]]);
      }));
    }
  }, {
    key: "reject",
    value: function reject() {
      return (0,tslib__WEBPACK_IMPORTED_MODULE_10__.__awaiter)(this, void 0, void 0, /*#__PURE__*/_regeneratorRuntime().mark(function _callee2() {
        return _regeneratorRuntime().wrap(function _callee2$(_context2) {
          while (1) switch (_context2.prev = _context2.next) {
            case 0:
              _context2.prev = 0;
              _context2.next = 3;
              return this.challengeService.rejectChallenge(this.campaign, this.challenge);

            case 3:
              _context2.next = 8;
              break;

            case 5:
              _context2.prev = 5;
              _context2.t0 = _context2["catch"](0);
              this.errorService.handleError(_context2.t0);

            case 8:
              _context2.prev = 8;
              this.modalController.dismiss(false);
              return _context2.finish(8);

            case 11:
            case "end":
              return _context2.stop();
          }
        }, _callee2, this, [[0, 5, 8, 11]]);
      }));
    }
  }, {
    key: "cancel",
    value: function cancel() {
      return (0,tslib__WEBPACK_IMPORTED_MODULE_10__.__awaiter)(this, void 0, void 0, /*#__PURE__*/_regeneratorRuntime().mark(function _callee3() {
        return _regeneratorRuntime().wrap(function _callee3$(_context3) {
          while (1) switch (_context3.prev = _context3.next) {
            case 0:
              _context3.prev = 0;
              _context3.next = 3;
              return this.challengeService.cancelChallenge(this.campaign, this.challenge);

            case 3:
              _context3.next = 8;
              break;

            case 5:
              _context3.prev = 5;
              _context3.t0 = _context3["catch"](0);
              this.errorService.handleError(_context3.t0);

            case 8:
              _context3.prev = 8;
              this.modalController.dismiss(false);
              return _context3.finish(8);

            case 11:
            case "end":
              return _context3.stop();
          }
        }, _callee3, this, [[0, 5, 8, 11]]);
      }));
    }
  }]);

  return InvitationlModalPage;
}();

InvitationlModalPage.ɵfac = function InvitationlModalPage_Factory(t) {
  return new (t || InvitationlModalPage)(_angular_core__WEBPACK_IMPORTED_MODULE_8__["ɵɵdirectiveInject"](_ionic_angular__WEBPACK_IMPORTED_MODULE_11__.ModalController), _angular_core__WEBPACK_IMPORTED_MODULE_8__["ɵɵdirectiveInject"](src_app_core_shared_services_user_service__WEBPACK_IMPORTED_MODULE_3__.UserService), _angular_core__WEBPACK_IMPORTED_MODULE_8__["ɵɵdirectiveInject"](src_app_core_shared_services_challenge_service__WEBPACK_IMPORTED_MODULE_4__.ChallengeService), _angular_core__WEBPACK_IMPORTED_MODULE_8__["ɵɵdirectiveInject"](_ngx_translate_core__WEBPACK_IMPORTED_MODULE_12__.TranslateService), _angular_core__WEBPACK_IMPORTED_MODULE_8__["ɵɵdirectiveInject"](src_app_core_shared_services_error_service__WEBPACK_IMPORTED_MODULE_5__.ErrorService));
};

InvitationlModalPage.ɵcmp = /*@__PURE__*/_angular_core__WEBPACK_IMPORTED_MODULE_8__["ɵɵdefineComponent"]({
  type: InvitationlModalPage,
  selectors: [["app-invitation-challenge"]],
  decls: 30,
  vars: 19,
  consts: [[3, "color"], ["slot", "end"], [3, "click"], ["name", "close-circle-outline"], [1, "ion-margin"], [1, "ion-align-items-center"], ["size", "2"], [1, "avatar"], [3, "src", "title"], [1, "icon-size-medium", 3, "name"], [1, "flex-center"], [1, "title-challenge"], [1, "desc-challenge"], [4, "ngIf", "ngIfElse"], ["sentTemplate", ""], [1, "ion-text-center"], [3, "color", "click"], ["color", "light", 3, "click"]],
  template: function InvitationlModalPage_Template(rf, ctx) {
    if (rf & 1) {
      _angular_core__WEBPACK_IMPORTED_MODULE_8__["ɵɵelementStart"](0, "ion-header")(1, "ion-toolbar", 0)(2, "ion-title");
      _angular_core__WEBPACK_IMPORTED_MODULE_8__["ɵɵtext"](3);
      _angular_core__WEBPACK_IMPORTED_MODULE_8__["ɵɵpipe"](4, "languageMap");
      _angular_core__WEBPACK_IMPORTED_MODULE_8__["ɵɵelementEnd"]();
      _angular_core__WEBPACK_IMPORTED_MODULE_8__["ɵɵelementStart"](5, "ion-buttons", 1)(6, "ion-button", 2);
      _angular_core__WEBPACK_IMPORTED_MODULE_8__["ɵɵlistener"]("click", function InvitationlModalPage_Template_ion_button_click_6_listener() {
        return ctx.close();
      });
      _angular_core__WEBPACK_IMPORTED_MODULE_8__["ɵɵelement"](7, "ion-icon", 3);
      _angular_core__WEBPACK_IMPORTED_MODULE_8__["ɵɵelementEnd"]()()()();
      _angular_core__WEBPACK_IMPORTED_MODULE_8__["ɵɵelementStart"](8, "ion-content")(9, "ion-grid", 4)(10, "ion-row", 5)(11, "ion-col", 6)(12, "ion-avatar", 7);
      _angular_core__WEBPACK_IMPORTED_MODULE_8__["ɵɵelement"](13, "img", 8);
      _angular_core__WEBPACK_IMPORTED_MODULE_8__["ɵɵpipe"](14, "translate");
      _angular_core__WEBPACK_IMPORTED_MODULE_8__["ɵɵelementEnd"]();
      _angular_core__WEBPACK_IMPORTED_MODULE_8__["ɵɵelement"](15, "app-icon", 9);
      _angular_core__WEBPACK_IMPORTED_MODULE_8__["ɵɵpipe"](16, "async");
      _angular_core__WEBPACK_IMPORTED_MODULE_8__["ɵɵelementEnd"]();
      _angular_core__WEBPACK_IMPORTED_MODULE_8__["ɵɵelementStart"](17, "ion-col", 10)(18, "span", 11);
      _angular_core__WEBPACK_IMPORTED_MODULE_8__["ɵɵtext"](19);
      _angular_core__WEBPACK_IMPORTED_MODULE_8__["ɵɵelementEnd"]()()();
      _angular_core__WEBPACK_IMPORTED_MODULE_8__["ɵɵelementStart"](20, "ion-row")(21, "ion-col")(22, "span", 12);
      _angular_core__WEBPACK_IMPORTED_MODULE_8__["ɵɵtext"](23);
      _angular_core__WEBPACK_IMPORTED_MODULE_8__["ɵɵpipe"](24, "languageMap");
      _angular_core__WEBPACK_IMPORTED_MODULE_8__["ɵɵelementEnd"]()()()()();
      _angular_core__WEBPACK_IMPORTED_MODULE_8__["ɵɵelementStart"](25, "ion-footer");
      _angular_core__WEBPACK_IMPORTED_MODULE_8__["ɵɵtemplate"](26, InvitationlModalPage_ion_row_26_Template, 9, 7, "ion-row", 13);
      _angular_core__WEBPACK_IMPORTED_MODULE_8__["ɵɵpipe"](27, "async");
      _angular_core__WEBPACK_IMPORTED_MODULE_8__["ɵɵtemplate"](28, InvitationlModalPage_ng_template_28_Template, 5, 4, "ng-template", null, 14, _angular_core__WEBPACK_IMPORTED_MODULE_8__["ɵɵtemplateRefExtractor"]);
      _angular_core__WEBPACK_IMPORTED_MODULE_8__["ɵɵelementEnd"]();
    }

    if (rf & 2) {
      var _r1 = _angular_core__WEBPACK_IMPORTED_MODULE_8__["ɵɵreference"](29);

      _angular_core__WEBPACK_IMPORTED_MODULE_8__["ɵɵadvance"](1);
      _angular_core__WEBPACK_IMPORTED_MODULE_8__["ɵɵproperty"]("color", ctx.campaign == null ? null : ctx.campaign.campaign == null ? null : ctx.campaign.campaign.type);
      _angular_core__WEBPACK_IMPORTED_MODULE_8__["ɵɵadvance"](2);
      _angular_core__WEBPACK_IMPORTED_MODULE_8__["ɵɵtextInterpolate1"](" ", _angular_core__WEBPACK_IMPORTED_MODULE_8__["ɵɵpipeBind1"](4, 9, ctx.campaign == null ? null : ctx.campaign.campaign == null ? null : ctx.campaign.campaign.name), " ");
      _angular_core__WEBPACK_IMPORTED_MODULE_8__["ɵɵadvance"](10);
      _angular_core__WEBPACK_IMPORTED_MODULE_8__["ɵɵpropertyInterpolate"]("title", _angular_core__WEBPACK_IMPORTED_MODULE_8__["ɵɵpipeBind1"](14, 11, "registration.avatar.title"));
      _angular_core__WEBPACK_IMPORTED_MODULE_8__["ɵɵproperty"]("src", ctx.challenge.otherAttendeeData.avatar.url, _angular_core__WEBPACK_IMPORTED_MODULE_8__["ɵɵsanitizeUrl"]);
      _angular_core__WEBPACK_IMPORTED_MODULE_8__["ɵɵadvance"](2);
      _angular_core__WEBPACK_IMPORTED_MODULE_8__["ɵɵproperty"]("name", _angular_core__WEBPACK_IMPORTED_MODULE_8__["ɵɵpipeBind1"](16, 13, ctx.playerId$) === ctx.challenge.proposerId ? "invite" : "invitation");
      _angular_core__WEBPACK_IMPORTED_MODULE_8__["ɵɵadvance"](4);
      _angular_core__WEBPACK_IMPORTED_MODULE_8__["ɵɵtextInterpolate"](ctx.typeChallenge);
      _angular_core__WEBPACK_IMPORTED_MODULE_8__["ɵɵadvance"](4);
      _angular_core__WEBPACK_IMPORTED_MODULE_8__["ɵɵtextInterpolate1"]("", _angular_core__WEBPACK_IMPORTED_MODULE_8__["ɵɵpipeBind1"](24, 15, ctx.challenge == null ? null : ctx.challenge.challDesc), " ");
      _angular_core__WEBPACK_IMPORTED_MODULE_8__["ɵɵadvance"](3);
      _angular_core__WEBPACK_IMPORTED_MODULE_8__["ɵɵproperty"]("ngIf", _angular_core__WEBPACK_IMPORTED_MODULE_8__["ɵɵpipeBind1"](27, 17, ctx.playerId$) !== ctx.challenge.proposerId)("ngIfElse", _r1);
    }
  },
  directives: [_ionic_angular__WEBPACK_IMPORTED_MODULE_11__.IonHeader, _ionic_angular__WEBPACK_IMPORTED_MODULE_11__.IonToolbar, _ionic_angular__WEBPACK_IMPORTED_MODULE_11__.IonTitle, _ionic_angular__WEBPACK_IMPORTED_MODULE_11__.IonButtons, _ionic_angular__WEBPACK_IMPORTED_MODULE_11__.IonButton, _ionic_angular__WEBPACK_IMPORTED_MODULE_11__.IonIcon, _ionic_angular__WEBPACK_IMPORTED_MODULE_11__.IonContent, _ionic_angular__WEBPACK_IMPORTED_MODULE_11__.IonGrid, _ionic_angular__WEBPACK_IMPORTED_MODULE_11__.IonRow, _ionic_angular__WEBPACK_IMPORTED_MODULE_11__.IonCol, _ionic_angular__WEBPACK_IMPORTED_MODULE_11__.IonAvatar, _core_shared_ui_icon_icon_component__WEBPACK_IMPORTED_MODULE_6__.IconComponent, _ionic_angular__WEBPACK_IMPORTED_MODULE_11__.IonFooter, _angular_common__WEBPACK_IMPORTED_MODULE_13__.NgIf],
  pipes: [_core_shared_pipes_languageMap_pipe__WEBPACK_IMPORTED_MODULE_7__.LanguageMapPipe, _ngx_translate_core__WEBPACK_IMPORTED_MODULE_12__.TranslatePipe, _angular_common__WEBPACK_IMPORTED_MODULE_13__.AsyncPipe],
  styles: ["ion-footer[_ngcontent-%COMP%] {\n  color: black;\n}\n\n.title-challenge[_ngcontent-%COMP%] {\n  font-style: italic;\n  font-weight: 200;\n  font-size: 16px;\n}\n\n.desc-challenge[_ngcontent-%COMP%] {\n  font-style: normal;\n  font-weight: 300;\n  font-size: 17px;\n}\n\n.date-challenge[_ngcontent-%COMP%] {\n  font-style: italic;\n  font-weight: 300;\n  font-size: 13px;\n}\n\nion-avatar[_ngcontent-%COMP%] {\n  position: absolute;\n  width: 25px;\n  height: 25px;\n  left: -7px;\n  top: 5px;\n}\n/*# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbImludml0YXRpb24tY2hhbGxlbmdlLm1vZGFsLnNjc3MiXSwibmFtZXMiOltdLCJtYXBwaW5ncyI6IkFBQUE7RUFDRSxZQUFBO0FBQ0Y7O0FBQ0E7RUFDRSxrQkFBQTtFQUNBLGdCQUFBO0VBQ0EsZUFBQTtBQUVGOztBQUFBO0VBQ0Usa0JBQUE7RUFDQSxnQkFBQTtFQUNBLGVBQUE7QUFHRjs7QUFEQTtFQUNFLGtCQUFBO0VBQ0EsZ0JBQUE7RUFDQSxlQUFBO0FBSUY7O0FBRkE7RUFDRSxrQkFBQTtFQUNBLFdBQUE7RUFDQSxZQUFBO0VBQ0EsVUFBQTtFQUNBLFFBQUE7QUFLRiIsImZpbGUiOiJpbnZpdGF0aW9uLWNoYWxsZW5nZS5tb2RhbC5zY3NzIiwic291cmNlc0NvbnRlbnQiOlsiaW9uLWZvb3RlciB7XG4gIGNvbG9yOiBibGFjaztcbn1cbi50aXRsZS1jaGFsbGVuZ2Uge1xuICBmb250LXN0eWxlOiBpdGFsaWM7XG4gIGZvbnQtd2VpZ2h0OiAyMDA7XG4gIGZvbnQtc2l6ZTogMTZweDtcbn1cbi5kZXNjLWNoYWxsZW5nZSB7XG4gIGZvbnQtc3R5bGU6IG5vcm1hbDtcbiAgZm9udC13ZWlnaHQ6IDMwMDtcbiAgZm9udC1zaXplOiAxN3B4O1xufVxuLmRhdGUtY2hhbGxlbmdlIHtcbiAgZm9udC1zdHlsZTogaXRhbGljO1xuICBmb250LXdlaWdodDogMzAwO1xuICBmb250LXNpemU6IDEzcHg7XG59XG5pb24tYXZhdGFyIHtcbiAgcG9zaXRpb246IGFic29sdXRlO1xuICB3aWR0aDogMjVweDtcbiAgaGVpZ2h0OiAyNXB4O1xuICBsZWZ0OiAtN3B4O1xuICB0b3A6IDVweDtcbn1cbiJdfQ== */"]
});

/***/ }),

/***/ 41988:
/*!***********************************************************************************************!*\
  !*** ./src/app/pages/challenges/create-challenge-button/create-challenge-button.component.ts ***!
  \***********************************************************************************************/
/***/ (function(__unused_webpack_module, __webpack_exports__, __webpack_require__) {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "CreateChallengeButtonComponent": function() { return /* binding */ CreateChallengeButtonComponent; }
/* harmony export */ });
/* harmony import */ var _Users_smartcommunitylab_Desktop_newWork_dslab_playgo_mobile_playgo_mobile_node_modules_babel_runtime_helpers_esm_classCallCheck_js__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./node_modules/@babel/runtime/helpers/esm/classCallCheck.js */ 78069);
/* harmony import */ var _Users_smartcommunitylab_Desktop_newWork_dslab_playgo_mobile_playgo_mobile_node_modules_babel_runtime_helpers_esm_createClass_js__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ./node_modules/@babel/runtime/helpers/esm/createClass.js */ 48047);
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @angular/core */ 3184);
/* harmony import */ var _ionic_angular__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! @ionic/angular */ 93819);
/* harmony import */ var _core_shared_ui_icon_icon_component__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! ../../../core/shared/ui/icon/icon.component */ 71888);
/* harmony import */ var _ngx_translate_core__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! @ngx-translate/core */ 87514);






var CreateChallengeButtonComponent = /*#__PURE__*/function () {
  function CreateChallengeButtonComponent() {
    (0,_Users_smartcommunitylab_Desktop_newWork_dslab_playgo_mobile_playgo_mobile_node_modules_babel_runtime_helpers_esm_classCallCheck_js__WEBPACK_IMPORTED_MODULE_0__["default"])(this, CreateChallengeButtonComponent);
  }

  (0,_Users_smartcommunitylab_Desktop_newWork_dslab_playgo_mobile_playgo_mobile_node_modules_babel_runtime_helpers_esm_createClass_js__WEBPACK_IMPORTED_MODULE_1__["default"])(CreateChallengeButtonComponent, [{
    key: "ngOnInit",
    value: function ngOnInit() {}
  }]);

  return CreateChallengeButtonComponent;
}();

CreateChallengeButtonComponent.ɵfac = function CreateChallengeButtonComponent_Factory(t) {
  return new (t || CreateChallengeButtonComponent)();
};

CreateChallengeButtonComponent.ɵcmp = /*@__PURE__*/_angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵdefineComponent"]({
  type: CreateChallengeButtonComponent,
  selectors: [["app-create-challenge-button"]],
  inputs: {
    campaign: "campaign"
  },
  decls: 14,
  vars: 7,
  consts: [[1, "header", 3, "color"], [1, "content"], [1, "ion-align-items-center"], ["size", "2"], ["name", "groupCompetitivePerformance", 1, "icon-size-medium"], [1, "flex-center"]],
  template: function CreateChallengeButtonComponent_Template(rf, ctx) {
    if (rf & 1) {
      _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵelementStart"](0, "ion-card")(1, "ion-card-header", 0)(2, "span");
      _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵtext"](3);
      _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵpipe"](4, "translate");
      _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵelementEnd"]()();
      _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵelementStart"](5, "ion-card-content", 1)(6, "ion-grid")(7, "ion-row", 2)(8, "ion-col", 3);
      _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵelement"](9, "app-icon", 4);
      _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵelementEnd"]();
      _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵelementStart"](10, "ion-col", 5)(11, "span");
      _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵtext"](12);
      _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵpipe"](13, "translate");
      _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵelementEnd"]()()()()()();
    }

    if (rf & 2) {
      _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵadvance"](1);
      _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵproperty"]("color", ctx.campaign.campaign.type);
      _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵadvance"](2);
      _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵtextInterpolate1"](" ", _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵpipeBind1"](4, 3, "challenges.create.configure"), " ");
      _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵadvance"](9);
      _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵtextInterpolate"](_angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵpipeBind1"](13, 5, "challenges.create.button_create"));
    }
  },
  directives: [_ionic_angular__WEBPACK_IMPORTED_MODULE_4__.IonCard, _ionic_angular__WEBPACK_IMPORTED_MODULE_4__.IonCardHeader, _ionic_angular__WEBPACK_IMPORTED_MODULE_4__.IonCardContent, _ionic_angular__WEBPACK_IMPORTED_MODULE_4__.IonGrid, _ionic_angular__WEBPACK_IMPORTED_MODULE_4__.IonRow, _ionic_angular__WEBPACK_IMPORTED_MODULE_4__.IonCol, _core_shared_ui_icon_icon_component__WEBPACK_IMPORTED_MODULE_2__.IconComponent],
  pipes: [_ngx_translate_core__WEBPACK_IMPORTED_MODULE_5__.TranslatePipe],
  styles: [".header[_ngcontent-%COMP%] {\n  text-align: end;\n  padding: 2px;\n  font-style: italic;\n}\n\n.content[_ngcontent-%COMP%] {\n  padding: 2px 8px;\n  display: flex;\n  align-items: center;\n}\n\n.content[_ngcontent-%COMP%]   span[_ngcontent-%COMP%] {\n  font-style: normal;\n  font-weight: 300;\n  font-size: 13px;\n}\n/*# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbImNyZWF0ZS1jaGFsbGVuZ2UtYnV0dG9uLmNvbXBvbmVudC5zY3NzIl0sIm5hbWVzIjpbXSwibWFwcGluZ3MiOiJBQUFBO0VBQ0UsZUFBQTtFQUNBLFlBQUE7RUFDQSxrQkFBQTtBQUNGOztBQUNBO0VBQ0UsZ0JBQUE7RUFDQSxhQUFBO0VBQ0EsbUJBQUE7QUFFRjs7QUFERTtFQUNFLGtCQUFBO0VBQ0EsZ0JBQUE7RUFDQSxlQUFBO0FBR0oiLCJmaWxlIjoiY3JlYXRlLWNoYWxsZW5nZS1idXR0b24uY29tcG9uZW50LnNjc3MiLCJzb3VyY2VzQ29udGVudCI6WyIuaGVhZGVyIHtcbiAgdGV4dC1hbGlnbjogZW5kO1xuICBwYWRkaW5nOiAycHg7XG4gIGZvbnQtc3R5bGU6IGl0YWxpYztcbn1cbi5jb250ZW50IHtcbiAgcGFkZGluZzogMnB4IDhweDtcbiAgZGlzcGxheTogZmxleDtcbiAgYWxpZ24taXRlbXM6IGNlbnRlcjtcbiAgc3BhbiB7XG4gICAgZm9udC1zdHlsZTogbm9ybWFsO1xuICAgIGZvbnQtd2VpZ2h0OiAzMDA7XG4gICAgZm9udC1zaXplOiAxM3B4O1xuICB9XG59XG4iXX0= */"]
});

/***/ }),

/***/ 29212:
/*!**************************************************************************************************!*\
  !*** ./src/app/pages/challenges/create-challenge/sent-invitation-modal/sent-invitation.modal.ts ***!
  \**************************************************************************************************/
/***/ (function(__unused_webpack_module, __webpack_exports__, __webpack_require__) {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "SentInvitationlModalPage": function() { return /* binding */ SentInvitationlModalPage; }
/* harmony export */ });
/* harmony import */ var _Users_smartcommunitylab_Desktop_newWork_dslab_playgo_mobile_playgo_mobile_node_modules_babel_runtime_helpers_esm_classCallCheck_js__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./node_modules/@babel/runtime/helpers/esm/classCallCheck.js */ 78069);
/* harmony import */ var _Users_smartcommunitylab_Desktop_newWork_dslab_playgo_mobile_playgo_mobile_node_modules_babel_runtime_helpers_esm_createClass_js__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ./node_modules/@babel/runtime/helpers/esm/createClass.js */ 48047);
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @angular/core */ 3184);
/* harmony import */ var _ionic_angular__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @ionic/angular */ 93819);
/* harmony import */ var _ngx_translate_core__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! @ngx-translate/core */ 87514);






var _c0 = function _c0(a0) {
  return {
    nickname: a0
  };
};

var SentInvitationlModalPage = /*#__PURE__*/function () {
  function SentInvitationlModalPage(modalController) {
    (0,_Users_smartcommunitylab_Desktop_newWork_dslab_playgo_mobile_playgo_mobile_node_modules_babel_runtime_helpers_esm_classCallCheck_js__WEBPACK_IMPORTED_MODULE_0__["default"])(this, SentInvitationlModalPage);

    this.modalController = modalController;
  }

  (0,_Users_smartcommunitylab_Desktop_newWork_dslab_playgo_mobile_playgo_mobile_node_modules_babel_runtime_helpers_esm_createClass_js__WEBPACK_IMPORTED_MODULE_1__["default"])(SentInvitationlModalPage, [{
    key: "ngOnInit",
    value: function ngOnInit() {} //computed errorcontrol

  }, {
    key: "close",
    value: function close() {
      this.modalController.dismiss(false);
    }
  }]);

  return SentInvitationlModalPage;
}();

SentInvitationlModalPage.ɵfac = function SentInvitationlModalPage_Factory(t) {
  return new (t || SentInvitationlModalPage)(_angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵdirectiveInject"](_ionic_angular__WEBPACK_IMPORTED_MODULE_3__.ModalController));
};

SentInvitationlModalPage.ɵcmp = /*@__PURE__*/_angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵdefineComponent"]({
  type: SentInvitationlModalPage,
  selectors: [["app-sent-invitation"]],
  decls: 10,
  vars: 18,
  consts: [["color", "playgo"], [1, "title"], [1, "body"], ["expand", "block", "color", "light", 3, "click"]],
  template: function SentInvitationlModalPage_Template(rf, ctx) {
    if (rf & 1) {
      _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵelementStart"](0, "ion-content", 0)(1, "p", 1);
      _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵtext"](2);
      _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵpipe"](3, "translate");
      _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵelementEnd"]();
      _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵelementStart"](4, "p", 2);
      _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵtext"](5);
      _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵpipe"](6, "translate");
      _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵelementEnd"]();
      _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵelementStart"](7, "ion-button", 3);
      _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵlistener"]("click", function SentInvitationlModalPage_Template_ion_button_click_7_listener() {
        return ctx.close();
      });
      _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵtext"](8);
      _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵpipe"](9, "translate");
      _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵelementEnd"]()();
    }

    if (rf & 2) {
      _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵadvance"](2);
      _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵtextInterpolate1"](" ", _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵpipeBind2"](3, 3, "challenges.create.sent_title", _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵpureFunction1"](12, _c0, ctx.opponentName)), " ");
      _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵadvance"](3);
      _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵtextInterpolate1"](" ", _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵpipeBind2"](6, 6, "challenges.create.sent_body", _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵpureFunction1"](14, _c0, ctx.opponentName)), " ");
      _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵadvance"](3);
      _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵtextInterpolate"](_angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵpipeBind2"](9, 9, "challenges.create.close", _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵpureFunction1"](16, _c0, ctx.opponentName)));
    }
  },
  directives: [_ionic_angular__WEBPACK_IMPORTED_MODULE_3__.IonContent, _ionic_angular__WEBPACK_IMPORTED_MODULE_3__.IonButton],
  pipes: [_ngx_translate_core__WEBPACK_IMPORTED_MODULE_4__.TranslatePipe],
  styles: ["ion-content[_ngcontent-%COMP%]   .title[_ngcontent-%COMP%] {\n  text-align: center;\n  font-weight: bold;\n  padding: 8px;\n}\nion-content[_ngcontent-%COMP%]   .body[_ngcontent-%COMP%] {\n  text-align: justify;\n  padding: 8px;\n}\nion-content[_ngcontent-%COMP%]   ion-button[_ngcontent-%COMP%] {\n  position: absolute;\n  bottom: 0px;\n  left: 50%;\n  width: 60%;\n  margin: 8px;\n  left: 50%;\n  transform: translateX(-50%);\n}\n/*# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbInNlbnQtaW52aXRhdGlvbi5tb2RhbC5zY3NzIl0sIm5hbWVzIjpbXSwibWFwcGluZ3MiOiJBQUNFO0VBQ0Usa0JBQUE7RUFDQSxpQkFBQTtFQUNBLFlBQUE7QUFBSjtBQUVFO0VBQ0UsbUJBQUE7RUFDQSxZQUFBO0FBQUo7QUFFRTtFQUNFLGtCQUFBO0VBQ0EsV0FBQTtFQUNBLFNBQUE7RUFDQSxVQUFBO0VBQ0EsV0FBQTtFQUNBLFNBQUE7RUFDQSwyQkFBQTtBQUFKIiwiZmlsZSI6InNlbnQtaW52aXRhdGlvbi5tb2RhbC5zY3NzIiwic291cmNlc0NvbnRlbnQiOlsiaW9uLWNvbnRlbnQge1xuICAudGl0bGUge1xuICAgIHRleHQtYWxpZ246IGNlbnRlcjtcbiAgICBmb250LXdlaWdodDogYm9sZDtcbiAgICBwYWRkaW5nOiA4cHg7XG4gIH1cbiAgLmJvZHkge1xuICAgIHRleHQtYWxpZ246IGp1c3RpZnk7XG4gICAgcGFkZGluZzogOHB4O1xuICB9XG4gIGlvbi1idXR0b24ge1xuICAgIHBvc2l0aW9uOiBhYnNvbHV0ZTtcbiAgICBib3R0b206IDBweDtcbiAgICBsZWZ0OiA1MCU7XG4gICAgd2lkdGg6IDYwJTtcbiAgICBtYXJnaW46IDhweDtcbiAgICBsZWZ0OiA1MCU7XG4gICAgdHJhbnNmb3JtOiB0cmFuc2xhdGVYKC01MCUpO1xuICB9XG59XG4iXX0= */"]
});

/***/ }),

/***/ 53051:
/*!***************************************************************************************************!*\
  !*** ./src/app/pages/challenges/single-challenge-proposed/single-challenge-proposed.component.ts ***!
  \***************************************************************************************************/
/***/ (function(__unused_webpack_module, __webpack_exports__, __webpack_require__) {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "SingleChallengeProposedComponent": function() { return /* binding */ SingleChallengeProposedComponent; }
/* harmony export */ });
/* harmony import */ var _Users_smartcommunitylab_Desktop_newWork_dslab_playgo_mobile_playgo_mobile_node_modules_babel_runtime_helpers_esm_classCallCheck_js__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./node_modules/@babel/runtime/helpers/esm/classCallCheck.js */ 78069);
/* harmony import */ var _Users_smartcommunitylab_Desktop_newWork_dslab_playgo_mobile_playgo_mobile_node_modules_babel_runtime_helpers_esm_createClass_js__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ./node_modules/@babel/runtime/helpers/esm/createClass.js */ 48047);
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! tslib */ 42321);
/* harmony import */ var _single_proposal_accepted_single_proposal_accepted_modal__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! ./single-proposal-accepted/single-proposal-accepted.modal */ 34694);
/* harmony import */ var _single_proposal_single_proposal_modal__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! ./single-proposal/single-proposal.modal */ 91846);
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(/*! @angular/core */ 3184);
/* harmony import */ var _ionic_angular__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(/*! @ionic/angular */ 93819);
/* harmony import */ var _core_shared_ui_icon_icon_component__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! ../../../core/shared/ui/icon/icon.component */ 71888);
/* harmony import */ var _ngx_translate_core__WEBPACK_IMPORTED_MODULE_9__ = __webpack_require__(/*! @ngx-translate/core */ 87514);
/* harmony import */ var _core_shared_pipes_languageMap_pipe__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! ../../../core/shared/pipes/languageMap.pipe */ 73088);



function _regeneratorRuntime() { "use strict"; /*! regenerator-runtime -- Copyright (c) 2014-present, Facebook, Inc. -- license (MIT): https://github.com/facebook/regenerator/blob/main/LICENSE */ _regeneratorRuntime = function _regeneratorRuntime() { return e; }; var t, e = {}, r = Object.prototype, n = r.hasOwnProperty, o = Object.defineProperty || function (t, e, r) { t[e] = r.value; }, i = "function" == typeof Symbol ? Symbol : {}, a = i.iterator || "@@iterator", c = i.asyncIterator || "@@asyncIterator", u = i.toStringTag || "@@toStringTag"; function define(t, e, r) { return Object.defineProperty(t, e, { value: r, enumerable: !0, configurable: !0, writable: !0 }), t[e]; } try { define({}, ""); } catch (t) { define = function define(t, e, r) { return t[e] = r; }; } function wrap(t, e, r, n) { var i = e && e.prototype instanceof Generator ? e : Generator, a = Object.create(i.prototype), c = new Context(n || []); return o(a, "_invoke", { value: makeInvokeMethod(t, r, c) }), a; } function tryCatch(t, e, r) { try { return { type: "normal", arg: t.call(e, r) }; } catch (t) { return { type: "throw", arg: t }; } } e.wrap = wrap; var h = "suspendedStart", l = "suspendedYield", f = "executing", s = "completed", y = {}; function Generator() {} function GeneratorFunction() {} function GeneratorFunctionPrototype() {} var p = {}; define(p, a, function () { return this; }); var d = Object.getPrototypeOf, v = d && d(d(values([]))); v && v !== r && n.call(v, a) && (p = v); var g = GeneratorFunctionPrototype.prototype = Generator.prototype = Object.create(p); function defineIteratorMethods(t) { ["next", "throw", "return"].forEach(function (e) { define(t, e, function (t) { return this._invoke(e, t); }); }); } function AsyncIterator(t, e) { function invoke(r, o, i, a) { var c = tryCatch(t[r], t, o); if ("throw" !== c.type) { var u = c.arg, h = u.value; return h && "object" == typeof h && n.call(h, "__await") ? e.resolve(h.__await).then(function (t) { invoke("next", t, i, a); }, function (t) { invoke("throw", t, i, a); }) : e.resolve(h).then(function (t) { u.value = t, i(u); }, function (t) { return invoke("throw", t, i, a); }); } a(c.arg); } var r; o(this, "_invoke", { value: function value(t, n) { function callInvokeWithMethodAndArg() { return new e(function (e, r) { invoke(t, n, e, r); }); } return r = r ? r.then(callInvokeWithMethodAndArg, callInvokeWithMethodAndArg) : callInvokeWithMethodAndArg(); } }); } function makeInvokeMethod(e, r, n) { var o = h; return function (i, a) { if (o === f) throw new Error("Generator is already running"); if (o === s) { if ("throw" === i) throw a; return { value: t, done: !0 }; } for (n.method = i, n.arg = a;;) { var c = n.delegate; if (c) { var u = maybeInvokeDelegate(c, n); if (u) { if (u === y) continue; return u; } } if ("next" === n.method) n.sent = n._sent = n.arg;else if ("throw" === n.method) { if (o === h) throw o = s, n.arg; n.dispatchException(n.arg); } else "return" === n.method && n.abrupt("return", n.arg); o = f; var p = tryCatch(e, r, n); if ("normal" === p.type) { if (o = n.done ? s : l, p.arg === y) continue; return { value: p.arg, done: n.done }; } "throw" === p.type && (o = s, n.method = "throw", n.arg = p.arg); } }; } function maybeInvokeDelegate(e, r) { var n = r.method, o = e.iterator[n]; if (o === t) return r.delegate = null, "throw" === n && e.iterator.return && (r.method = "return", r.arg = t, maybeInvokeDelegate(e, r), "throw" === r.method) || "return" !== n && (r.method = "throw", r.arg = new TypeError("The iterator does not provide a '" + n + "' method")), y; var i = tryCatch(o, e.iterator, r.arg); if ("throw" === i.type) return r.method = "throw", r.arg = i.arg, r.delegate = null, y; var a = i.arg; return a ? a.done ? (r[e.resultName] = a.value, r.next = e.nextLoc, "return" !== r.method && (r.method = "next", r.arg = t), r.delegate = null, y) : a : (r.method = "throw", r.arg = new TypeError("iterator result is not an object"), r.delegate = null, y); } function pushTryEntry(t) { var e = { tryLoc: t[0] }; 1 in t && (e.catchLoc = t[1]), 2 in t && (e.finallyLoc = t[2], e.afterLoc = t[3]), this.tryEntries.push(e); } function resetTryEntry(t) { var e = t.completion || {}; e.type = "normal", delete e.arg, t.completion = e; } function Context(t) { this.tryEntries = [{ tryLoc: "root" }], t.forEach(pushTryEntry, this), this.reset(!0); } function values(e) { if (e || "" === e) { var r = e[a]; if (r) return r.call(e); if ("function" == typeof e.next) return e; if (!isNaN(e.length)) { var o = -1, i = function next() { for (; ++o < e.length;) if (n.call(e, o)) return next.value = e[o], next.done = !1, next; return next.value = t, next.done = !0, next; }; return i.next = i; } } throw new TypeError(typeof e + " is not iterable"); } return GeneratorFunction.prototype = GeneratorFunctionPrototype, o(g, "constructor", { value: GeneratorFunctionPrototype, configurable: !0 }), o(GeneratorFunctionPrototype, "constructor", { value: GeneratorFunction, configurable: !0 }), GeneratorFunction.displayName = define(GeneratorFunctionPrototype, u, "GeneratorFunction"), e.isGeneratorFunction = function (t) { var e = "function" == typeof t && t.constructor; return !!e && (e === GeneratorFunction || "GeneratorFunction" === (e.displayName || e.name)); }, e.mark = function (t) { return Object.setPrototypeOf ? Object.setPrototypeOf(t, GeneratorFunctionPrototype) : (t.__proto__ = GeneratorFunctionPrototype, define(t, u, "GeneratorFunction")), t.prototype = Object.create(g), t; }, e.awrap = function (t) { return { __await: t }; }, defineIteratorMethods(AsyncIterator.prototype), define(AsyncIterator.prototype, c, function () { return this; }), e.AsyncIterator = AsyncIterator, e.async = function (t, r, n, o, i) { void 0 === i && (i = Promise); var a = new AsyncIterator(wrap(t, r, n, o), i); return e.isGeneratorFunction(r) ? a : a.next().then(function (t) { return t.done ? t.value : a.next(); }); }, defineIteratorMethods(g), define(g, u, "Generator"), define(g, a, function () { return this; }), define(g, "toString", function () { return "[object Generator]"; }), e.keys = function (t) { var e = Object(t), r = []; for (var n in e) r.push(n); return r.reverse(), function next() { for (; r.length;) { var t = r.pop(); if (t in e) return next.value = t, next.done = !1, next; } return next.done = !0, next; }; }, e.values = values, Context.prototype = { constructor: Context, reset: function reset(e) { if (this.prev = 0, this.next = 0, this.sent = this._sent = t, this.done = !1, this.delegate = null, this.method = "next", this.arg = t, this.tryEntries.forEach(resetTryEntry), !e) for (var r in this) "t" === r.charAt(0) && n.call(this, r) && !isNaN(+r.slice(1)) && (this[r] = t); }, stop: function stop() { this.done = !0; var t = this.tryEntries[0].completion; if ("throw" === t.type) throw t.arg; return this.rval; }, dispatchException: function dispatchException(e) { if (this.done) throw e; var r = this; function handle(n, o) { return a.type = "throw", a.arg = e, r.next = n, o && (r.method = "next", r.arg = t), !!o; } for (var o = this.tryEntries.length - 1; o >= 0; --o) { var i = this.tryEntries[o], a = i.completion; if ("root" === i.tryLoc) return handle("end"); if (i.tryLoc <= this.prev) { var c = n.call(i, "catchLoc"), u = n.call(i, "finallyLoc"); if (c && u) { if (this.prev < i.catchLoc) return handle(i.catchLoc, !0); if (this.prev < i.finallyLoc) return handle(i.finallyLoc); } else if (c) { if (this.prev < i.catchLoc) return handle(i.catchLoc, !0); } else { if (!u) throw new Error("try statement without catch or finally"); if (this.prev < i.finallyLoc) return handle(i.finallyLoc); } } } }, abrupt: function abrupt(t, e) { for (var r = this.tryEntries.length - 1; r >= 0; --r) { var o = this.tryEntries[r]; if (o.tryLoc <= this.prev && n.call(o, "finallyLoc") && this.prev < o.finallyLoc) { var i = o; break; } } i && ("break" === t || "continue" === t) && i.tryLoc <= e && e <= i.finallyLoc && (i = null); var a = i ? i.completion : {}; return a.type = t, a.arg = e, i ? (this.method = "next", this.next = i.finallyLoc, y) : this.complete(a); }, complete: function complete(t, e) { if ("throw" === t.type) throw t.arg; return "break" === t.type || "continue" === t.type ? this.next = t.arg : "return" === t.type ? (this.rval = this.arg = t.arg, this.method = "return", this.next = "end") : "normal" === t.type && e && (this.next = e), y; }, finish: function finish(t) { for (var e = this.tryEntries.length - 1; e >= 0; --e) { var r = this.tryEntries[e]; if (r.finallyLoc === t) return this.complete(r.completion, r.afterLoc), resetTryEntry(r), y; } }, catch: function _catch(t) { for (var e = this.tryEntries.length - 1; e >= 0; --e) { var r = this.tryEntries[e]; if (r.tryLoc === t) { var n = r.completion; if ("throw" === n.type) { var o = n.arg; resetTryEntry(r); } return o; } } throw new Error("illegal catch attempt"); }, delegateYield: function delegateYield(e, r, n) { return this.delegate = { iterator: values(e), resultName: r, nextLoc: n }, "next" === this.method && (this.arg = t), y; } }, e; }









var SingleChallengeProposedComponent = /*#__PURE__*/function () {
  function SingleChallengeProposedComponent(modalController) {
    (0,_Users_smartcommunitylab_Desktop_newWork_dslab_playgo_mobile_playgo_mobile_node_modules_babel_runtime_helpers_esm_classCallCheck_js__WEBPACK_IMPORTED_MODULE_0__["default"])(this, SingleChallengeProposedComponent);

    this.modalController = modalController;
  }

  (0,_Users_smartcommunitylab_Desktop_newWork_dslab_playgo_mobile_playgo_mobile_node_modules_babel_runtime_helpers_esm_createClass_js__WEBPACK_IMPORTED_MODULE_1__["default"])(SingleChallengeProposedComponent, [{
    key: "ngOnInit",
    value: function ngOnInit() {}
  }, {
    key: "openSelectionPopup",
    value: function openSelectionPopup() {
      return (0,tslib__WEBPACK_IMPORTED_MODULE_6__.__awaiter)(this, void 0, void 0, /*#__PURE__*/_regeneratorRuntime().mark(function _callee() {
        var modal, _yield$modal$onWillDi, data;

        return _regeneratorRuntime().wrap(function _callee$(_context) {
          while (1) switch (_context.prev = _context.next) {
            case 0:
              _context.next = 2;
              return this.modalController.create({
                component: _single_proposal_single_proposal_modal__WEBPACK_IMPORTED_MODULE_3__.SingleProposalModalPage,
                cssClass: 'modal-challenge',
                componentProps: {
                  challenge: this.challenge,
                  campaign: this.campaign
                },
                swipeToClose: true
              });

            case 2:
              modal = _context.sent;
              _context.next = 5;
              return modal.present();

            case 5:
              _context.next = 7;
              return modal.onWillDismiss();

            case 7:
              _yield$modal$onWillDi = _context.sent;
              data = _yield$modal$onWillDi.data;

              if (!data) {
                _context.next = 17;
                break;
              }

              _context.next = 12;
              return this.modalController.create({
                component: _single_proposal_accepted_single_proposal_accepted_modal__WEBPACK_IMPORTED_MODULE_2__.SingleProposalAcceptedModalPage,
                cssClass: 'modal-challenge',
                componentProps: {
                  challenge: this.challenge,
                  campaign: this.campaign
                },
                swipeToClose: true
              });

            case 12:
              modal = _context.sent;
              _context.next = 15;
              return modal.present();

            case 15:
              _context.next = 17;
              return modal.onWillDismiss();

            case 17:
            case "end":
              return _context.stop();
          }
        }, _callee, this);
      }));
    }
  }]);

  return SingleChallengeProposedComponent;
}();

SingleChallengeProposedComponent.ɵfac = function SingleChallengeProposedComponent_Factory(t) {
  return new (t || SingleChallengeProposedComponent)(_angular_core__WEBPACK_IMPORTED_MODULE_7__["ɵɵdirectiveInject"](_ionic_angular__WEBPACK_IMPORTED_MODULE_8__.ModalController));
};

SingleChallengeProposedComponent.ɵcmp = /*@__PURE__*/_angular_core__WEBPACK_IMPORTED_MODULE_7__["ɵɵdefineComponent"]({
  type: SingleChallengeProposedComponent,
  selectors: [["app-single-challenge-proposed"]],
  inputs: {
    challenge: "challenge",
    campaign: "campaign"
  },
  decls: 14,
  vars: 7,
  consts: [[3, "click"], [1, "header", 3, "color"], [1, "content"], [1, "ion-align-items-center"], ["size", "2"], ["name", "default", 1, "icon-size-medium"], [1, "flex-center"]],
  template: function SingleChallengeProposedComponent_Template(rf, ctx) {
    if (rf & 1) {
      _angular_core__WEBPACK_IMPORTED_MODULE_7__["ɵɵelementStart"](0, "ion-card", 0);
      _angular_core__WEBPACK_IMPORTED_MODULE_7__["ɵɵlistener"]("click", function SingleChallengeProposedComponent_Template_ion_card_click_0_listener() {
        return ctx.openSelectionPopup();
      });
      _angular_core__WEBPACK_IMPORTED_MODULE_7__["ɵɵelementStart"](1, "ion-card-header", 1)(2, "span");
      _angular_core__WEBPACK_IMPORTED_MODULE_7__["ɵɵtext"](3);
      _angular_core__WEBPACK_IMPORTED_MODULE_7__["ɵɵpipe"](4, "translate");
      _angular_core__WEBPACK_IMPORTED_MODULE_7__["ɵɵelementEnd"]()();
      _angular_core__WEBPACK_IMPORTED_MODULE_7__["ɵɵelementStart"](5, "ion-card-content", 2)(6, "ion-grid")(7, "ion-row", 3)(8, "ion-col", 4);
      _angular_core__WEBPACK_IMPORTED_MODULE_7__["ɵɵelement"](9, "app-icon", 5);
      _angular_core__WEBPACK_IMPORTED_MODULE_7__["ɵɵelementEnd"]();
      _angular_core__WEBPACK_IMPORTED_MODULE_7__["ɵɵelementStart"](10, "ion-col", 6)(11, "span");
      _angular_core__WEBPACK_IMPORTED_MODULE_7__["ɵɵtext"](12);
      _angular_core__WEBPACK_IMPORTED_MODULE_7__["ɵɵpipe"](13, "languageMap");
      _angular_core__WEBPACK_IMPORTED_MODULE_7__["ɵɵelementEnd"]()()()()()();
    }

    if (rf & 2) {
      _angular_core__WEBPACK_IMPORTED_MODULE_7__["ɵɵadvance"](1);
      _angular_core__WEBPACK_IMPORTED_MODULE_7__["ɵɵproperty"]("color", ctx.campaign.campaign.type);
      _angular_core__WEBPACK_IMPORTED_MODULE_7__["ɵɵadvance"](2);
      _angular_core__WEBPACK_IMPORTED_MODULE_7__["ɵɵtextInterpolate1"](" ", _angular_core__WEBPACK_IMPORTED_MODULE_7__["ɵɵpipeBind1"](4, 3, "challenges.singleproposal"), " ");
      _angular_core__WEBPACK_IMPORTED_MODULE_7__["ɵɵadvance"](9);
      _angular_core__WEBPACK_IMPORTED_MODULE_7__["ɵɵtextInterpolate"](_angular_core__WEBPACK_IMPORTED_MODULE_7__["ɵɵpipeBind1"](13, 5, ctx.challenge.challDesc));
    }
  },
  directives: [_ionic_angular__WEBPACK_IMPORTED_MODULE_8__.IonCard, _ionic_angular__WEBPACK_IMPORTED_MODULE_8__.IonCardHeader, _ionic_angular__WEBPACK_IMPORTED_MODULE_8__.IonCardContent, _ionic_angular__WEBPACK_IMPORTED_MODULE_8__.IonGrid, _ionic_angular__WEBPACK_IMPORTED_MODULE_8__.IonRow, _ionic_angular__WEBPACK_IMPORTED_MODULE_8__.IonCol, _core_shared_ui_icon_icon_component__WEBPACK_IMPORTED_MODULE_4__.IconComponent],
  pipes: [_ngx_translate_core__WEBPACK_IMPORTED_MODULE_9__.TranslatePipe, _core_shared_pipes_languageMap_pipe__WEBPACK_IMPORTED_MODULE_5__.LanguageMapPipe],
  styles: [".header[_ngcontent-%COMP%] {\n  padding: 2px;\n  text-align: right;\n  font-style: italic;\n}\n.header[_ngcontent-%COMP%]   span[_ngcontent-%COMP%] {\n  margin: 4px;\n}\nspan[_ngcontent-%COMP%] {\n  font-style: normal;\n  font-weight: 300;\n  font-size: 13px;\n}\n/*# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbInNpbmdsZS1jaGFsbGVuZ2UtcHJvcG9zZWQuY29tcG9uZW50LnNjc3MiXSwibmFtZXMiOltdLCJtYXBwaW5ncyI6IkFBQUE7RUFDRSxZQUFBO0VBQ0EsaUJBQUE7RUFDQSxrQkFBQTtBQUNGO0FBQUU7RUFDRSxXQUFBO0FBRUo7QUFDQTtFQUNFLGtCQUFBO0VBQ0EsZ0JBQUE7RUFDQSxlQUFBO0FBRUYiLCJmaWxlIjoic2luZ2xlLWNoYWxsZW5nZS1wcm9wb3NlZC5jb21wb25lbnQuc2NzcyIsInNvdXJjZXNDb250ZW50IjpbIi5oZWFkZXIge1xuICBwYWRkaW5nOiAycHg7XG4gIHRleHQtYWxpZ246IHJpZ2h0O1xuICBmb250LXN0eWxlOiBpdGFsaWM7XG4gIHNwYW4ge1xuICAgIG1hcmdpbjogNHB4O1xuICB9XG59XG5zcGFuIHtcbiAgZm9udC1zdHlsZTogbm9ybWFsO1xuICBmb250LXdlaWdodDogMzAwO1xuICBmb250LXNpemU6IDEzcHg7XG59XG4iXX0= */"]
});

/***/ }),

/***/ 34694:
/*!***********************************************************************************************************************!*\
  !*** ./src/app/pages/challenges/single-challenge-proposed/single-proposal-accepted/single-proposal-accepted.modal.ts ***!
  \***********************************************************************************************************************/
/***/ (function(__unused_webpack_module, __webpack_exports__, __webpack_require__) {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "SingleProposalAcceptedModalPage": function() { return /* binding */ SingleProposalAcceptedModalPage; }
/* harmony export */ });
/* harmony import */ var _Users_smartcommunitylab_Desktop_newWork_dslab_playgo_mobile_playgo_mobile_node_modules_babel_runtime_helpers_esm_classCallCheck_js__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./node_modules/@babel/runtime/helpers/esm/classCallCheck.js */ 78069);
/* harmony import */ var _Users_smartcommunitylab_Desktop_newWork_dslab_playgo_mobile_playgo_mobile_node_modules_babel_runtime_helpers_esm_createClass_js__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ./node_modules/@babel/runtime/helpers/esm/createClass.js */ 48047);
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! @angular/core */ 3184);
/* harmony import */ var _ionic_angular__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! @ionic/angular */ 93819);
/* harmony import */ var src_app_core_shared_services_campaign_service__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! src/app/core/shared/services/campaign.service */ 23645);
/* harmony import */ var _core_shared_ui_icon_icon_component__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! ../../../../core/shared/ui/icon/icon.component */ 71888);
/* harmony import */ var _ngx_translate_core__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(/*! @ngx-translate/core */ 87514);
/* harmony import */ var _core_shared_pipes_localDate_pipe__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! ../../../../core/shared/pipes/localDate.pipe */ 34489);









var _c0 = function _c0(a0, a1) {
  return {
    from: a0,
    to: a1
  };
};

var SingleProposalAcceptedModalPage = /*#__PURE__*/function () {
  function SingleProposalAcceptedModalPage(modalController, campaignService) {
    (0,_Users_smartcommunitylab_Desktop_newWork_dslab_playgo_mobile_playgo_mobile_node_modules_babel_runtime_helpers_esm_classCallCheck_js__WEBPACK_IMPORTED_MODULE_0__["default"])(this, SingleProposalAcceptedModalPage);

    this.modalController = modalController;
    this.campaignService = campaignService;
  }

  (0,_Users_smartcommunitylab_Desktop_newWork_dslab_playgo_mobile_playgo_mobile_node_modules_babel_runtime_helpers_esm_createClass_js__WEBPACK_IMPORTED_MODULE_1__["default"])(SingleProposalAcceptedModalPage, [{
    key: "ngOnInit",
    value: function ngOnInit() {} //computed errorcontrol

  }, {
    key: "close",
    value: function close() {
      this.modalController.dismiss(false);
    }
  }]);

  return SingleProposalAcceptedModalPage;
}();

SingleProposalAcceptedModalPage.ɵfac = function SingleProposalAcceptedModalPage_Factory(t) {
  return new (t || SingleProposalAcceptedModalPage)(_angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵdirectiveInject"](_ionic_angular__WEBPACK_IMPORTED_MODULE_6__.ModalController), _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵdirectiveInject"](src_app_core_shared_services_campaign_service__WEBPACK_IMPORTED_MODULE_2__.CampaignService));
};

SingleProposalAcceptedModalPage.ɵcmp = /*@__PURE__*/_angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵdefineComponent"]({
  type: SingleProposalAcceptedModalPage,
  selectors: [["app-single-proposal-accepted"]],
  decls: 26,
  vars: 17,
  consts: [["color", "playgo"], [1, "content"], [1, "ion-text-center"], ["name", "checked", 1, "type-notif", "icon-size-normal"], ["name", "default", 1, "type-notif", "icon-size-big"], ["color", "playgo", "mode", "ios"], ["color", "light", "expand", "block", 3, "click"]],
  template: function SingleProposalAcceptedModalPage_Template(rf, ctx) {
    if (rf & 1) {
      _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵelementStart"](0, "ion-content", 0)(1, "ion-grid", 1)(2, "ion-row")(3, "ion-col", 2)(4, "div");
      _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵelement"](5, "app-icon", 3);
      _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵelementEnd"]()()();
      _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵelementStart"](6, "ion-row")(7, "ion-col", 2)(8, "div");
      _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵtext"](9);
      _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵpipe"](10, "translate");
      _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵelementEnd"]()()();
      _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵelementStart"](11, "ion-row")(12, "ion-col", 2)(13, "div");
      _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵelement"](14, "app-icon", 4);
      _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵelementEnd"]()()();
      _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵelementStart"](15, "ion-row")(16, "ion-col", 2)(17, "div");
      _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵtext"](18);
      _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵpipe"](19, "translate");
      _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵpipe"](20, "localDate");
      _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵpipe"](21, "localDate");
      _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵelementEnd"]()()()()();
      _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵelementStart"](22, "ion-footer", 5)(23, "ion-button", 6);
      _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵlistener"]("click", function SingleProposalAcceptedModalPage_Template_ion_button_click_23_listener() {
        return ctx.close();
      });
      _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵtext"](24);
      _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵpipe"](25, "translate");
      _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵelementEnd"]()();
    }

    if (rf & 2) {
      _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵadvance"](9);
      _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵtextInterpolate1"](" ", _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵpipeBind1"](10, 3, "challenges.singleActivated"), "");
      _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵadvance"](9);
      _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵtextInterpolate"](_angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵpipeBind2"](19, 5, "challenges.singleDesc", _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵpureFunction2"](14, _c0, _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵpipeBind1"](20, 8, ctx.challenge.startDate), _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵpipeBind1"](21, 10, ctx.challenge.endDate))));
      _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵadvance"](6);
      _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵtextInterpolate"](_angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵpipeBind1"](25, 12, "notifications.close"));
    }
  },
  directives: [_ionic_angular__WEBPACK_IMPORTED_MODULE_6__.IonContent, _ionic_angular__WEBPACK_IMPORTED_MODULE_6__.IonGrid, _ionic_angular__WEBPACK_IMPORTED_MODULE_6__.IonRow, _ionic_angular__WEBPACK_IMPORTED_MODULE_6__.IonCol, _core_shared_ui_icon_icon_component__WEBPACK_IMPORTED_MODULE_3__.IconComponent, _ionic_angular__WEBPACK_IMPORTED_MODULE_6__.IonFooter, _ionic_angular__WEBPACK_IMPORTED_MODULE_6__.IonButton],
  pipes: [_ngx_translate_core__WEBPACK_IMPORTED_MODULE_7__.TranslatePipe, _core_shared_pipes_localDate_pipe__WEBPACK_IMPORTED_MODULE_4__.LocalDatePipe],
  styles: ["ion-footer[_ngcontent-%COMP%] {\n  color: black;\n}\n\n.title-challenge[_ngcontent-%COMP%] {\n  font-style: italic;\n  font-weight: 200;\n  font-size: 16px;\n}\n\n.desc-challenge[_ngcontent-%COMP%] {\n  font-style: normal;\n  font-weight: 300;\n  font-size: 17px;\n}\n\n.date-challenge[_ngcontent-%COMP%] {\n  font-style: italic;\n  font-weight: 300;\n  font-size: 13px;\n}\n/*# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbInNpbmdsZS1wcm9wb3NhbC1hY2NlcHRlZC5tb2RhbC5zY3NzIl0sIm5hbWVzIjpbXSwibWFwcGluZ3MiOiJBQUFBO0VBQ0UsWUFBQTtBQUNGOztBQUNBO0VBQ0Usa0JBQUE7RUFDQSxnQkFBQTtFQUNBLGVBQUE7QUFFRjs7QUFBQTtFQUNFLGtCQUFBO0VBQ0EsZ0JBQUE7RUFDQSxlQUFBO0FBR0Y7O0FBREE7RUFDRSxrQkFBQTtFQUNBLGdCQUFBO0VBQ0EsZUFBQTtBQUlGIiwiZmlsZSI6InNpbmdsZS1wcm9wb3NhbC1hY2NlcHRlZC5tb2RhbC5zY3NzIiwic291cmNlc0NvbnRlbnQiOlsiaW9uLWZvb3RlciB7XG4gIGNvbG9yOiBibGFjaztcbn1cbi50aXRsZS1jaGFsbGVuZ2Uge1xuICBmb250LXN0eWxlOiBpdGFsaWM7XG4gIGZvbnQtd2VpZ2h0OiAyMDA7XG4gIGZvbnQtc2l6ZTogMTZweDtcbn1cbi5kZXNjLWNoYWxsZW5nZSB7XG4gIGZvbnQtc3R5bGU6IG5vcm1hbDtcbiAgZm9udC13ZWlnaHQ6IDMwMDtcbiAgZm9udC1zaXplOiAxN3B4O1xufVxuLmRhdGUtY2hhbGxlbmdlIHtcbiAgZm9udC1zdHlsZTogaXRhbGljO1xuICBmb250LXdlaWdodDogMzAwO1xuICBmb250LXNpemU6IDEzcHg7XG59XG4iXX0= */"]
});

/***/ }),

/***/ 91846:
/*!*****************************************************************************************************!*\
  !*** ./src/app/pages/challenges/single-challenge-proposed/single-proposal/single-proposal.modal.ts ***!
  \*****************************************************************************************************/
/***/ (function(__unused_webpack_module, __webpack_exports__, __webpack_require__) {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "SingleProposalModalPage": function() { return /* binding */ SingleProposalModalPage; }
/* harmony export */ });
/* harmony import */ var _Users_smartcommunitylab_Desktop_newWork_dslab_playgo_mobile_playgo_mobile_node_modules_babel_runtime_helpers_esm_classCallCheck_js__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./node_modules/@babel/runtime/helpers/esm/classCallCheck.js */ 78069);
/* harmony import */ var _Users_smartcommunitylab_Desktop_newWork_dslab_playgo_mobile_playgo_mobile_node_modules_babel_runtime_helpers_esm_createClass_js__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ./node_modules/@babel/runtime/helpers/esm/createClass.js */ 48047);
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(/*! tslib */ 42321);
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_9__ = __webpack_require__(/*! @angular/core */ 3184);
/* harmony import */ var _ionic_angular__WEBPACK_IMPORTED_MODULE_10__ = __webpack_require__(/*! @ionic/angular */ 93819);
/* harmony import */ var src_app_core_shared_services_challenge_service__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! src/app/core/shared/services/challenge.service */ 66324);
/* harmony import */ var src_app_core_shared_services_campaign_service__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! src/app/core/shared/services/campaign.service */ 23645);
/* harmony import */ var src_app_core_shared_services_error_service__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! src/app/core/shared/services/error.service */ 96204);
/* harmony import */ var _core_shared_ui_icon_icon_component__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! ../../../../core/shared/ui/icon/icon.component */ 71888);
/* harmony import */ var _core_shared_pipes_languageMap_pipe__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! ../../../../core/shared/pipes/languageMap.pipe */ 73088);
/* harmony import */ var _ngx_translate_core__WEBPACK_IMPORTED_MODULE_11__ = __webpack_require__(/*! @ngx-translate/core */ 87514);
/* harmony import */ var _core_shared_pipes_localDate_pipe__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(/*! ../../../../core/shared/pipes/localDate.pipe */ 34489);



function _regeneratorRuntime() { "use strict"; /*! regenerator-runtime -- Copyright (c) 2014-present, Facebook, Inc. -- license (MIT): https://github.com/facebook/regenerator/blob/main/LICENSE */ _regeneratorRuntime = function _regeneratorRuntime() { return e; }; var t, e = {}, r = Object.prototype, n = r.hasOwnProperty, o = Object.defineProperty || function (t, e, r) { t[e] = r.value; }, i = "function" == typeof Symbol ? Symbol : {}, a = i.iterator || "@@iterator", c = i.asyncIterator || "@@asyncIterator", u = i.toStringTag || "@@toStringTag"; function define(t, e, r) { return Object.defineProperty(t, e, { value: r, enumerable: !0, configurable: !0, writable: !0 }), t[e]; } try { define({}, ""); } catch (t) { define = function define(t, e, r) { return t[e] = r; }; } function wrap(t, e, r, n) { var i = e && e.prototype instanceof Generator ? e : Generator, a = Object.create(i.prototype), c = new Context(n || []); return o(a, "_invoke", { value: makeInvokeMethod(t, r, c) }), a; } function tryCatch(t, e, r) { try { return { type: "normal", arg: t.call(e, r) }; } catch (t) { return { type: "throw", arg: t }; } } e.wrap = wrap; var h = "suspendedStart", l = "suspendedYield", f = "executing", s = "completed", y = {}; function Generator() {} function GeneratorFunction() {} function GeneratorFunctionPrototype() {} var p = {}; define(p, a, function () { return this; }); var d = Object.getPrototypeOf, v = d && d(d(values([]))); v && v !== r && n.call(v, a) && (p = v); var g = GeneratorFunctionPrototype.prototype = Generator.prototype = Object.create(p); function defineIteratorMethods(t) { ["next", "throw", "return"].forEach(function (e) { define(t, e, function (t) { return this._invoke(e, t); }); }); } function AsyncIterator(t, e) { function invoke(r, o, i, a) { var c = tryCatch(t[r], t, o); if ("throw" !== c.type) { var u = c.arg, h = u.value; return h && "object" == typeof h && n.call(h, "__await") ? e.resolve(h.__await).then(function (t) { invoke("next", t, i, a); }, function (t) { invoke("throw", t, i, a); }) : e.resolve(h).then(function (t) { u.value = t, i(u); }, function (t) { return invoke("throw", t, i, a); }); } a(c.arg); } var r; o(this, "_invoke", { value: function value(t, n) { function callInvokeWithMethodAndArg() { return new e(function (e, r) { invoke(t, n, e, r); }); } return r = r ? r.then(callInvokeWithMethodAndArg, callInvokeWithMethodAndArg) : callInvokeWithMethodAndArg(); } }); } function makeInvokeMethod(e, r, n) { var o = h; return function (i, a) { if (o === f) throw new Error("Generator is already running"); if (o === s) { if ("throw" === i) throw a; return { value: t, done: !0 }; } for (n.method = i, n.arg = a;;) { var c = n.delegate; if (c) { var u = maybeInvokeDelegate(c, n); if (u) { if (u === y) continue; return u; } } if ("next" === n.method) n.sent = n._sent = n.arg;else if ("throw" === n.method) { if (o === h) throw o = s, n.arg; n.dispatchException(n.arg); } else "return" === n.method && n.abrupt("return", n.arg); o = f; var p = tryCatch(e, r, n); if ("normal" === p.type) { if (o = n.done ? s : l, p.arg === y) continue; return { value: p.arg, done: n.done }; } "throw" === p.type && (o = s, n.method = "throw", n.arg = p.arg); } }; } function maybeInvokeDelegate(e, r) { var n = r.method, o = e.iterator[n]; if (o === t) return r.delegate = null, "throw" === n && e.iterator.return && (r.method = "return", r.arg = t, maybeInvokeDelegate(e, r), "throw" === r.method) || "return" !== n && (r.method = "throw", r.arg = new TypeError("The iterator does not provide a '" + n + "' method")), y; var i = tryCatch(o, e.iterator, r.arg); if ("throw" === i.type) return r.method = "throw", r.arg = i.arg, r.delegate = null, y; var a = i.arg; return a ? a.done ? (r[e.resultName] = a.value, r.next = e.nextLoc, "return" !== r.method && (r.method = "next", r.arg = t), r.delegate = null, y) : a : (r.method = "throw", r.arg = new TypeError("iterator result is not an object"), r.delegate = null, y); } function pushTryEntry(t) { var e = { tryLoc: t[0] }; 1 in t && (e.catchLoc = t[1]), 2 in t && (e.finallyLoc = t[2], e.afterLoc = t[3]), this.tryEntries.push(e); } function resetTryEntry(t) { var e = t.completion || {}; e.type = "normal", delete e.arg, t.completion = e; } function Context(t) { this.tryEntries = [{ tryLoc: "root" }], t.forEach(pushTryEntry, this), this.reset(!0); } function values(e) { if (e || "" === e) { var r = e[a]; if (r) return r.call(e); if ("function" == typeof e.next) return e; if (!isNaN(e.length)) { var o = -1, i = function next() { for (; ++o < e.length;) if (n.call(e, o)) return next.value = e[o], next.done = !1, next; return next.value = t, next.done = !0, next; }; return i.next = i; } } throw new TypeError(typeof e + " is not iterable"); } return GeneratorFunction.prototype = GeneratorFunctionPrototype, o(g, "constructor", { value: GeneratorFunctionPrototype, configurable: !0 }), o(GeneratorFunctionPrototype, "constructor", { value: GeneratorFunction, configurable: !0 }), GeneratorFunction.displayName = define(GeneratorFunctionPrototype, u, "GeneratorFunction"), e.isGeneratorFunction = function (t) { var e = "function" == typeof t && t.constructor; return !!e && (e === GeneratorFunction || "GeneratorFunction" === (e.displayName || e.name)); }, e.mark = function (t) { return Object.setPrototypeOf ? Object.setPrototypeOf(t, GeneratorFunctionPrototype) : (t.__proto__ = GeneratorFunctionPrototype, define(t, u, "GeneratorFunction")), t.prototype = Object.create(g), t; }, e.awrap = function (t) { return { __await: t }; }, defineIteratorMethods(AsyncIterator.prototype), define(AsyncIterator.prototype, c, function () { return this; }), e.AsyncIterator = AsyncIterator, e.async = function (t, r, n, o, i) { void 0 === i && (i = Promise); var a = new AsyncIterator(wrap(t, r, n, o), i); return e.isGeneratorFunction(r) ? a : a.next().then(function (t) { return t.done ? t.value : a.next(); }); }, defineIteratorMethods(g), define(g, u, "Generator"), define(g, a, function () { return this; }), define(g, "toString", function () { return "[object Generator]"; }), e.keys = function (t) { var e = Object(t), r = []; for (var n in e) r.push(n); return r.reverse(), function next() { for (; r.length;) { var t = r.pop(); if (t in e) return next.value = t, next.done = !1, next; } return next.done = !0, next; }; }, e.values = values, Context.prototype = { constructor: Context, reset: function reset(e) { if (this.prev = 0, this.next = 0, this.sent = this._sent = t, this.done = !1, this.delegate = null, this.method = "next", this.arg = t, this.tryEntries.forEach(resetTryEntry), !e) for (var r in this) "t" === r.charAt(0) && n.call(this, r) && !isNaN(+r.slice(1)) && (this[r] = t); }, stop: function stop() { this.done = !0; var t = this.tryEntries[0].completion; if ("throw" === t.type) throw t.arg; return this.rval; }, dispatchException: function dispatchException(e) { if (this.done) throw e; var r = this; function handle(n, o) { return a.type = "throw", a.arg = e, r.next = n, o && (r.method = "next", r.arg = t), !!o; } for (var o = this.tryEntries.length - 1; o >= 0; --o) { var i = this.tryEntries[o], a = i.completion; if ("root" === i.tryLoc) return handle("end"); if (i.tryLoc <= this.prev) { var c = n.call(i, "catchLoc"), u = n.call(i, "finallyLoc"); if (c && u) { if (this.prev < i.catchLoc) return handle(i.catchLoc, !0); if (this.prev < i.finallyLoc) return handle(i.finallyLoc); } else if (c) { if (this.prev < i.catchLoc) return handle(i.catchLoc, !0); } else { if (!u) throw new Error("try statement without catch or finally"); if (this.prev < i.finallyLoc) return handle(i.finallyLoc); } } } }, abrupt: function abrupt(t, e) { for (var r = this.tryEntries.length - 1; r >= 0; --r) { var o = this.tryEntries[r]; if (o.tryLoc <= this.prev && n.call(o, "finallyLoc") && this.prev < o.finallyLoc) { var i = o; break; } } i && ("break" === t || "continue" === t) && i.tryLoc <= e && e <= i.finallyLoc && (i = null); var a = i ? i.completion : {}; return a.type = t, a.arg = e, i ? (this.method = "next", this.next = i.finallyLoc, y) : this.complete(a); }, complete: function complete(t, e) { if ("throw" === t.type) throw t.arg; return "break" === t.type || "continue" === t.type ? this.next = t.arg : "return" === t.type ? (this.rval = this.arg = t.arg, this.method = "return", this.next = "end") : "normal" === t.type && e && (this.next = e), y; }, finish: function finish(t) { for (var e = this.tryEntries.length - 1; e >= 0; --e) { var r = this.tryEntries[e]; if (r.finallyLoc === t) return this.complete(r.completion, r.afterLoc), resetTryEntry(r), y; } }, catch: function _catch(t) { for (var e = this.tryEntries.length - 1; e >= 0; --e) { var r = this.tryEntries[e]; if (r.tryLoc === t) { var n = r.completion; if ("throw" === n.type) { var o = n.arg; resetTryEntry(r); } return o; } } throw new Error("illegal catch attempt"); }, delegateYield: function delegateYield(e, r, n) { return this.delegate = { iterator: values(e), resultName: r, nextLoc: n }, "next" === this.method && (this.arg = t), y; } }, e; }












var _c0 = function _c0(a0, a1) {
  return {
    from: a0,
    to: a1
  };
};

var SingleProposalModalPage = /*#__PURE__*/function () {
  function SingleProposalModalPage(modalController, challengeService, campaignService, errorService) {
    (0,_Users_smartcommunitylab_Desktop_newWork_dslab_playgo_mobile_playgo_mobile_node_modules_babel_runtime_helpers_esm_classCallCheck_js__WEBPACK_IMPORTED_MODULE_0__["default"])(this, SingleProposalModalPage);

    this.modalController = modalController;
    this.challengeService = challengeService;
    this.campaignService = campaignService;
    this.errorService = errorService;
  }

  (0,_Users_smartcommunitylab_Desktop_newWork_dslab_playgo_mobile_playgo_mobile_node_modules_babel_runtime_helpers_esm_createClass_js__WEBPACK_IMPORTED_MODULE_1__["default"])(SingleProposalModalPage, [{
    key: "ngOnInit",
    value: function ngOnInit() {} //computed errorcontrol

  }, {
    key: "close",
    value: function close() {
      this.modalController.dismiss(false);
    }
  }, {
    key: "activate",
    value: function activate() {
      return (0,tslib__WEBPACK_IMPORTED_MODULE_8__.__awaiter)(this, void 0, void 0, /*#__PURE__*/_regeneratorRuntime().mark(function _callee() {
        return _regeneratorRuntime().wrap(function _callee$(_context) {
          while (1) switch (_context.prev = _context.next) {
            case 0:
              _context.prev = 0;
              _context.next = 3;
              return this.challengeService.acceptSingleChallenge(this.campaign, this.challenge);

            case 3:
              _context.next = 8;
              break;

            case 5:
              _context.prev = 5;
              _context.t0 = _context["catch"](0);
              this.errorService.handleError(_context.t0);

            case 8:
              _context.prev = 8;
              this.modalController.dismiss(true);
              return _context.finish(8);

            case 11:
            case "end":
              return _context.stop();
          }
        }, _callee, this, [[0, 5, 8, 11]]);
      }));
    }
  }]);

  return SingleProposalModalPage;
}();

SingleProposalModalPage.ɵfac = function SingleProposalModalPage_Factory(t) {
  return new (t || SingleProposalModalPage)(_angular_core__WEBPACK_IMPORTED_MODULE_9__["ɵɵdirectiveInject"](_ionic_angular__WEBPACK_IMPORTED_MODULE_10__.ModalController), _angular_core__WEBPACK_IMPORTED_MODULE_9__["ɵɵdirectiveInject"](src_app_core_shared_services_challenge_service__WEBPACK_IMPORTED_MODULE_2__.ChallengeService), _angular_core__WEBPACK_IMPORTED_MODULE_9__["ɵɵdirectiveInject"](src_app_core_shared_services_campaign_service__WEBPACK_IMPORTED_MODULE_3__.CampaignService), _angular_core__WEBPACK_IMPORTED_MODULE_9__["ɵɵdirectiveInject"](src_app_core_shared_services_error_service__WEBPACK_IMPORTED_MODULE_4__.ErrorService));
};

SingleProposalModalPage.ɵcmp = /*@__PURE__*/_angular_core__WEBPACK_IMPORTED_MODULE_9__["ɵɵdefineComponent"]({
  type: SingleProposalModalPage,
  selectors: [["app-single-proposal"]],
  decls: 39,
  vars: 27,
  consts: [[3, "color"], ["slot", "end"], [3, "click"], ["name", "close-circle-outline"], ["size", "3", 1, "ion-text-center"], ["name", "default", 1, "icon-size-big"], [1, "flex-center"], [1, "title-challenge"], [1, "desc-challenge"], [1, "ion-text-center"], [3, "color", "click"], ["size", "8", 1, "ion-text-left"], [1, "date-challenge"], [1, "ion-text-end"], [1, "flex-center", "date-challenge"], [3, "name"]],
  template: function SingleProposalModalPage_Template(rf, ctx) {
    if (rf & 1) {
      _angular_core__WEBPACK_IMPORTED_MODULE_9__["ɵɵelementStart"](0, "ion-header")(1, "ion-toolbar", 0)(2, "ion-title");
      _angular_core__WEBPACK_IMPORTED_MODULE_9__["ɵɵtext"](3);
      _angular_core__WEBPACK_IMPORTED_MODULE_9__["ɵɵpipe"](4, "languageMap");
      _angular_core__WEBPACK_IMPORTED_MODULE_9__["ɵɵelementEnd"]();
      _angular_core__WEBPACK_IMPORTED_MODULE_9__["ɵɵelementStart"](5, "ion-buttons", 1)(6, "ion-button", 2);
      _angular_core__WEBPACK_IMPORTED_MODULE_9__["ɵɵlistener"]("click", function SingleProposalModalPage_Template_ion_button_click_6_listener() {
        return ctx.close();
      });
      _angular_core__WEBPACK_IMPORTED_MODULE_9__["ɵɵelement"](7, "ion-icon", 3);
      _angular_core__WEBPACK_IMPORTED_MODULE_9__["ɵɵelementEnd"]()()()();
      _angular_core__WEBPACK_IMPORTED_MODULE_9__["ɵɵelementStart"](8, "ion-content")(9, "ion-grid")(10, "ion-row")(11, "ion-col", 4);
      _angular_core__WEBPACK_IMPORTED_MODULE_9__["ɵɵelement"](12, "app-icon", 5);
      _angular_core__WEBPACK_IMPORTED_MODULE_9__["ɵɵelementEnd"]();
      _angular_core__WEBPACK_IMPORTED_MODULE_9__["ɵɵelementStart"](13, "ion-col", 6)(14, "span", 7);
      _angular_core__WEBPACK_IMPORTED_MODULE_9__["ɵɵtext"](15);
      _angular_core__WEBPACK_IMPORTED_MODULE_9__["ɵɵpipe"](16, "translate");
      _angular_core__WEBPACK_IMPORTED_MODULE_9__["ɵɵelementEnd"]()()();
      _angular_core__WEBPACK_IMPORTED_MODULE_9__["ɵɵelementStart"](17, "ion-row")(18, "ion-col")(19, "span", 8);
      _angular_core__WEBPACK_IMPORTED_MODULE_9__["ɵɵtext"](20);
      _angular_core__WEBPACK_IMPORTED_MODULE_9__["ɵɵpipe"](21, "languageMap");
      _angular_core__WEBPACK_IMPORTED_MODULE_9__["ɵɵelementEnd"]()()()()();
      _angular_core__WEBPACK_IMPORTED_MODULE_9__["ɵɵelementStart"](22, "ion-footer")(23, "ion-row")(24, "ion-col", 9)(25, "ion-button", 10);
      _angular_core__WEBPACK_IMPORTED_MODULE_9__["ɵɵlistener"]("click", function SingleProposalModalPage_Template_ion_button_click_25_listener() {
        return ctx.activate();
      });
      _angular_core__WEBPACK_IMPORTED_MODULE_9__["ɵɵtext"](26);
      _angular_core__WEBPACK_IMPORTED_MODULE_9__["ɵɵpipe"](27, "translate");
      _angular_core__WEBPACK_IMPORTED_MODULE_9__["ɵɵelementEnd"]()()();
      _angular_core__WEBPACK_IMPORTED_MODULE_9__["ɵɵelementStart"](28, "ion-row")(29, "ion-col", 11)(30, "span", 12);
      _angular_core__WEBPACK_IMPORTED_MODULE_9__["ɵɵtext"](31);
      _angular_core__WEBPACK_IMPORTED_MODULE_9__["ɵɵpipe"](32, "translate");
      _angular_core__WEBPACK_IMPORTED_MODULE_9__["ɵɵpipe"](33, "localDate");
      _angular_core__WEBPACK_IMPORTED_MODULE_9__["ɵɵpipe"](34, "localDate");
      _angular_core__WEBPACK_IMPORTED_MODULE_9__["ɵɵelementEnd"]()();
      _angular_core__WEBPACK_IMPORTED_MODULE_9__["ɵɵelementStart"](35, "ion-col", 13)(36, "span", 14);
      _angular_core__WEBPACK_IMPORTED_MODULE_9__["ɵɵtext"](37);
      _angular_core__WEBPACK_IMPORTED_MODULE_9__["ɵɵelement"](38, "app-icon", 15);
      _angular_core__WEBPACK_IMPORTED_MODULE_9__["ɵɵelementEnd"]()()()();
    }

    if (rf & 2) {
      _angular_core__WEBPACK_IMPORTED_MODULE_9__["ɵɵadvance"](1);
      _angular_core__WEBPACK_IMPORTED_MODULE_9__["ɵɵproperty"]("color", ctx.campaign.campaign.type);
      _angular_core__WEBPACK_IMPORTED_MODULE_9__["ɵɵadvance"](2);
      _angular_core__WEBPACK_IMPORTED_MODULE_9__["ɵɵtextInterpolate1"](" ", _angular_core__WEBPACK_IMPORTED_MODULE_9__["ɵɵpipeBind1"](4, 9, ctx.campaign.campaign.name), " ");
      _angular_core__WEBPACK_IMPORTED_MODULE_9__["ɵɵadvance"](12);
      _angular_core__WEBPACK_IMPORTED_MODULE_9__["ɵɵtextInterpolate"](_angular_core__WEBPACK_IMPORTED_MODULE_9__["ɵɵpipeBind1"](16, 11, "challenges.singleproposal"));
      _angular_core__WEBPACK_IMPORTED_MODULE_9__["ɵɵadvance"](5);
      _angular_core__WEBPACK_IMPORTED_MODULE_9__["ɵɵtextInterpolate"](_angular_core__WEBPACK_IMPORTED_MODULE_9__["ɵɵpipeBind1"](21, 13, ctx.challenge.challDesc));
      _angular_core__WEBPACK_IMPORTED_MODULE_9__["ɵɵadvance"](5);
      _angular_core__WEBPACK_IMPORTED_MODULE_9__["ɵɵproperty"]("color", ctx.campaign == null ? null : ctx.campaign.campaign == null ? null : ctx.campaign.campaign.type);
      _angular_core__WEBPACK_IMPORTED_MODULE_9__["ɵɵadvance"](1);
      _angular_core__WEBPACK_IMPORTED_MODULE_9__["ɵɵtextInterpolate1"](" ", _angular_core__WEBPACK_IMPORTED_MODULE_9__["ɵɵpipeBind1"](27, 15, "challenges.activate"), " ");
      _angular_core__WEBPACK_IMPORTED_MODULE_9__["ɵɵadvance"](5);
      _angular_core__WEBPACK_IMPORTED_MODULE_9__["ɵɵtextInterpolate"](_angular_core__WEBPACK_IMPORTED_MODULE_9__["ɵɵpipeBind2"](32, 17, "challenges.fromto", _angular_core__WEBPACK_IMPORTED_MODULE_9__["ɵɵpureFunction2"](24, _c0, _angular_core__WEBPACK_IMPORTED_MODULE_9__["ɵɵpipeBind1"](33, 20, ctx.challenge.startDate), _angular_core__WEBPACK_IMPORTED_MODULE_9__["ɵɵpipeBind1"](34, 22, ctx.challenge.endDate))));
      _angular_core__WEBPACK_IMPORTED_MODULE_9__["ɵɵadvance"](6);
      _angular_core__WEBPACK_IMPORTED_MODULE_9__["ɵɵtextInterpolate1"]("", ctx.challenge.bonus, " ");
      _angular_core__WEBPACK_IMPORTED_MODULE_9__["ɵɵadvance"](1);
      _angular_core__WEBPACK_IMPORTED_MODULE_9__["ɵɵproperty"]("name", ctx.campaignService.getCampaignTypeIcon(ctx.campaign == null ? null : ctx.campaign.campaign));
    }
  },
  directives: [_ionic_angular__WEBPACK_IMPORTED_MODULE_10__.IonHeader, _ionic_angular__WEBPACK_IMPORTED_MODULE_10__.IonToolbar, _ionic_angular__WEBPACK_IMPORTED_MODULE_10__.IonTitle, _ionic_angular__WEBPACK_IMPORTED_MODULE_10__.IonButtons, _ionic_angular__WEBPACK_IMPORTED_MODULE_10__.IonButton, _ionic_angular__WEBPACK_IMPORTED_MODULE_10__.IonIcon, _ionic_angular__WEBPACK_IMPORTED_MODULE_10__.IonContent, _ionic_angular__WEBPACK_IMPORTED_MODULE_10__.IonGrid, _ionic_angular__WEBPACK_IMPORTED_MODULE_10__.IonRow, _ionic_angular__WEBPACK_IMPORTED_MODULE_10__.IonCol, _core_shared_ui_icon_icon_component__WEBPACK_IMPORTED_MODULE_5__.IconComponent, _ionic_angular__WEBPACK_IMPORTED_MODULE_10__.IonFooter],
  pipes: [_core_shared_pipes_languageMap_pipe__WEBPACK_IMPORTED_MODULE_6__.LanguageMapPipe, _ngx_translate_core__WEBPACK_IMPORTED_MODULE_11__.TranslatePipe, _core_shared_pipes_localDate_pipe__WEBPACK_IMPORTED_MODULE_7__.LocalDatePipe],
  styles: ["ion-footer[_ngcontent-%COMP%] {\n  color: black;\n}\n\n.title-challenge[_ngcontent-%COMP%] {\n  font-style: italic;\n  font-weight: 200;\n  font-size: 16px;\n}\n\n.desc-challenge[_ngcontent-%COMP%] {\n  font-style: normal;\n  font-weight: 300;\n  font-size: 17px;\n}\n\n.date-challenge[_ngcontent-%COMP%] {\n  font-style: italic;\n  font-weight: 300;\n  font-size: 13px;\n}\n/*# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbInNpbmdsZS1wcm9wb3NhbC5tb2RhbC5zY3NzIl0sIm5hbWVzIjpbXSwibWFwcGluZ3MiOiJBQUFBO0VBQ0UsWUFBQTtBQUNGOztBQUNBO0VBQ0Usa0JBQUE7RUFDQSxnQkFBQTtFQUNBLGVBQUE7QUFFRjs7QUFBQTtFQUNFLGtCQUFBO0VBQ0EsZ0JBQUE7RUFDQSxlQUFBO0FBR0Y7O0FBREE7RUFDRSxrQkFBQTtFQUNBLGdCQUFBO0VBQ0EsZUFBQTtBQUlGIiwiZmlsZSI6InNpbmdsZS1wcm9wb3NhbC5tb2RhbC5zY3NzIiwic291cmNlc0NvbnRlbnQiOlsiaW9uLWZvb3RlciB7XG4gIGNvbG9yOiBibGFjaztcbn1cbi50aXRsZS1jaGFsbGVuZ2Uge1xuICBmb250LXN0eWxlOiBpdGFsaWM7XG4gIGZvbnQtd2VpZ2h0OiAyMDA7XG4gIGZvbnQtc2l6ZTogMTZweDtcbn1cbi5kZXNjLWNoYWxsZW5nZSB7XG4gIGZvbnQtc3R5bGU6IG5vcm1hbDtcbiAgZm9udC13ZWlnaHQ6IDMwMDtcbiAgZm9udC1zaXplOiAxN3B4O1xufVxuLmRhdGUtY2hhbGxlbmdlIHtcbiAgZm9udC1zdHlsZTogaXRhbGljO1xuICBmb250LXdlaWdodDogMzAwO1xuICBmb250LXNpemU6IDEzcHg7XG59XG4iXX0= */"]
});

/***/ })

}]);
//# sourceMappingURL=src_app_pages_challenges_challenges_module_ts.js.map