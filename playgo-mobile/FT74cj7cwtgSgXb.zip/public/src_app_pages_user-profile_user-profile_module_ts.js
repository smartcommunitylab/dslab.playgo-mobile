"use strict";
(self["webpackChunkapp"] = self["webpackChunkapp"] || []).push([["src_app_pages_user-profile_user-profile_module_ts"],{

/***/ 25373:
/*!*****************************************************************************!*\
  !*** ./src/app/pages/user-profile/campaign-stat/campaign-stat.component.ts ***!
  \*****************************************************************************/
/***/ (function(__unused_webpack_module, __webpack_exports__, __webpack_require__) {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "CampaignStatComponent": function() { return /* binding */ CampaignStatComponent; }
/* harmony export */ });
/* harmony import */ var _Users_smartcommunitylab_Desktop_newWork_dslab_playgo_mobile_playgo_mobile_node_modules_babel_runtime_helpers_esm_classCallCheck_js__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./node_modules/@babel/runtime/helpers/esm/classCallCheck.js */ 78069);
/* harmony import */ var _Users_smartcommunitylab_Desktop_newWork_dslab_playgo_mobile_playgo_mobile_node_modules_babel_runtime_helpers_esm_createClass_js__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ./node_modules/@babel/runtime/helpers/esm/createClass.js */ 48047);
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_19__ = __webpack_require__(/*! tslib */ 42321);
/* harmony import */ var luxon__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! luxon */ 20020);
/* harmony import */ var rxjs__WEBPACK_IMPORTED_MODULE_15__ = __webpack_require__(/*! rxjs */ 26067);
/* harmony import */ var rxjs__WEBPACK_IMPORTED_MODULE_16__ = __webpack_require__(/*! rxjs */ 36646);
/* harmony import */ var rxjs__WEBPACK_IMPORTED_MODULE_17__ = __webpack_require__(/*! rxjs */ 50635);
/* harmony import */ var rxjs__WEBPACK_IMPORTED_MODULE_18__ = __webpack_require__(/*! rxjs */ 32673);
/* harmony import */ var src_app_core_shared_campaigns_campaign_utils__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! src/app/core/shared/campaigns/campaign.utils */ 87725);
/* harmony import */ var src_app_core_shared_time_utils__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! src/app/core/shared/time.utils */ 93462);
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_14__ = __webpack_require__(/*! @angular/core */ 3184);
/* harmony import */ var src_app_core_shared_services_challenge_service__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! src/app/core/shared/services/challenge.service */ 66324);
/* harmony import */ var src_app_core_shared_services_report_service__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! src/app/core/shared/services/report.service */ 93981);
/* harmony import */ var _ngx_translate_core__WEBPACK_IMPORTED_MODULE_20__ = __webpack_require__(/*! @ngx-translate/core */ 87514);
/* harmony import */ var src_app_core_shared_services_campaign_service__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(/*! src/app/core/shared/services/campaign.service */ 23645);
/* harmony import */ var src_app_core_auth_auth_service__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(/*! src/app/core/auth/auth.service */ 88951);
/* harmony import */ var src_app_core_shared_services_error_service__WEBPACK_IMPORTED_MODULE_9__ = __webpack_require__(/*! src/app/core/shared/services/error.service */ 96204);
/* harmony import */ var _ionic_angular__WEBPACK_IMPORTED_MODULE_21__ = __webpack_require__(/*! @ionic/angular */ 93819);
/* harmony import */ var _angular_common__WEBPACK_IMPORTED_MODULE_22__ = __webpack_require__(/*! @angular/common */ 36362);
/* harmony import */ var _core_shared_ui_icon_icon_component__WEBPACK_IMPORTED_MODULE_10__ = __webpack_require__(/*! ../../../core/shared/ui/icon/icon.component */ 71888);
/* harmony import */ var _core_shared_globalization_ordinal_number_ordinal_number_component__WEBPACK_IMPORTED_MODULE_11__ = __webpack_require__(/*! ../../../core/shared/globalization/ordinal-number/ordinal-number.component */ 56032);
/* harmony import */ var _core_shared_pipes_languageMap_pipe__WEBPACK_IMPORTED_MODULE_12__ = __webpack_require__(/*! ../../../core/shared/pipes/languageMap.pipe */ 73088);
/* harmony import */ var _core_shared_pipes_localDate_pipe__WEBPACK_IMPORTED_MODULE_13__ = __webpack_require__(/*! ../../../core/shared/pipes/localDate.pipe */ 34489);



function _regeneratorRuntime() { "use strict"; /*! regenerator-runtime -- Copyright (c) 2014-present, Facebook, Inc. -- license (MIT): https://github.com/facebook/regenerator/blob/main/LICENSE */ _regeneratorRuntime = function _regeneratorRuntime() { return e; }; var t, e = {}, r = Object.prototype, n = r.hasOwnProperty, o = Object.defineProperty || function (t, e, r) { t[e] = r.value; }, i = "function" == typeof Symbol ? Symbol : {}, a = i.iterator || "@@iterator", c = i.asyncIterator || "@@asyncIterator", u = i.toStringTag || "@@toStringTag"; function define(t, e, r) { return Object.defineProperty(t, e, { value: r, enumerable: !0, configurable: !0, writable: !0 }), t[e]; } try { define({}, ""); } catch (t) { define = function define(t, e, r) { return t[e] = r; }; } function wrap(t, e, r, n) { var i = e && e.prototype instanceof Generator ? e : Generator, a = Object.create(i.prototype), c = new Context(n || []); return o(a, "_invoke", { value: makeInvokeMethod(t, r, c) }), a; } function tryCatch(t, e, r) { try { return { type: "normal", arg: t.call(e, r) }; } catch (t) { return { type: "throw", arg: t }; } } e.wrap = wrap; var h = "suspendedStart", l = "suspendedYield", f = "executing", s = "completed", y = {}; function Generator() {} function GeneratorFunction() {} function GeneratorFunctionPrototype() {} var p = {}; define(p, a, function () { return this; }); var d = Object.getPrototypeOf, v = d && d(d(values([]))); v && v !== r && n.call(v, a) && (p = v); var g = GeneratorFunctionPrototype.prototype = Generator.prototype = Object.create(p); function defineIteratorMethods(t) { ["next", "throw", "return"].forEach(function (e) { define(t, e, function (t) { return this._invoke(e, t); }); }); } function AsyncIterator(t, e) { function invoke(r, o, i, a) { var c = tryCatch(t[r], t, o); if ("throw" !== c.type) { var u = c.arg, h = u.value; return h && "object" == typeof h && n.call(h, "__await") ? e.resolve(h.__await).then(function (t) { invoke("next", t, i, a); }, function (t) { invoke("throw", t, i, a); }) : e.resolve(h).then(function (t) { u.value = t, i(u); }, function (t) { return invoke("throw", t, i, a); }); } a(c.arg); } var r; o(this, "_invoke", { value: function value(t, n) { function callInvokeWithMethodAndArg() { return new e(function (e, r) { invoke(t, n, e, r); }); } return r = r ? r.then(callInvokeWithMethodAndArg, callInvokeWithMethodAndArg) : callInvokeWithMethodAndArg(); } }); } function makeInvokeMethod(e, r, n) { var o = h; return function (i, a) { if (o === f) throw new Error("Generator is already running"); if (o === s) { if ("throw" === i) throw a; return { value: t, done: !0 }; } for (n.method = i, n.arg = a;;) { var c = n.delegate; if (c) { var u = maybeInvokeDelegate(c, n); if (u) { if (u === y) continue; return u; } } if ("next" === n.method) n.sent = n._sent = n.arg;else if ("throw" === n.method) { if (o === h) throw o = s, n.arg; n.dispatchException(n.arg); } else "return" === n.method && n.abrupt("return", n.arg); o = f; var p = tryCatch(e, r, n); if ("normal" === p.type) { if (o = n.done ? s : l, p.arg === y) continue; return { value: p.arg, done: n.done }; } "throw" === p.type && (o = s, n.method = "throw", n.arg = p.arg); } }; } function maybeInvokeDelegate(e, r) { var n = r.method, o = e.iterator[n]; if (o === t) return r.delegate = null, "throw" === n && e.iterator.return && (r.method = "return", r.arg = t, maybeInvokeDelegate(e, r), "throw" === r.method) || "return" !== n && (r.method = "throw", r.arg = new TypeError("The iterator does not provide a '" + n + "' method")), y; var i = tryCatch(o, e.iterator, r.arg); if ("throw" === i.type) return r.method = "throw", r.arg = i.arg, r.delegate = null, y; var a = i.arg; return a ? a.done ? (r[e.resultName] = a.value, r.next = e.nextLoc, "return" !== r.method && (r.method = "next", r.arg = t), r.delegate = null, y) : a : (r.method = "throw", r.arg = new TypeError("iterator result is not an object"), r.delegate = null, y); } function pushTryEntry(t) { var e = { tryLoc: t[0] }; 1 in t && (e.catchLoc = t[1]), 2 in t && (e.finallyLoc = t[2], e.afterLoc = t[3]), this.tryEntries.push(e); } function resetTryEntry(t) { var e = t.completion || {}; e.type = "normal", delete e.arg, t.completion = e; } function Context(t) { this.tryEntries = [{ tryLoc: "root" }], t.forEach(pushTryEntry, this), this.reset(!0); } function values(e) { if (e || "" === e) { var r = e[a]; if (r) return r.call(e); if ("function" == typeof e.next) return e; if (!isNaN(e.length)) { var o = -1, i = function next() { for (; ++o < e.length;) if (n.call(e, o)) return next.value = e[o], next.done = !1, next; return next.value = t, next.done = !0, next; }; return i.next = i; } } throw new TypeError(typeof e + " is not iterable"); } return GeneratorFunction.prototype = GeneratorFunctionPrototype, o(g, "constructor", { value: GeneratorFunctionPrototype, configurable: !0 }), o(GeneratorFunctionPrototype, "constructor", { value: GeneratorFunction, configurable: !0 }), GeneratorFunction.displayName = define(GeneratorFunctionPrototype, u, "GeneratorFunction"), e.isGeneratorFunction = function (t) { var e = "function" == typeof t && t.constructor; return !!e && (e === GeneratorFunction || "GeneratorFunction" === (e.displayName || e.name)); }, e.mark = function (t) { return Object.setPrototypeOf ? Object.setPrototypeOf(t, GeneratorFunctionPrototype) : (t.__proto__ = GeneratorFunctionPrototype, define(t, u, "GeneratorFunction")), t.prototype = Object.create(g), t; }, e.awrap = function (t) { return { __await: t }; }, defineIteratorMethods(AsyncIterator.prototype), define(AsyncIterator.prototype, c, function () { return this; }), e.AsyncIterator = AsyncIterator, e.async = function (t, r, n, o, i) { void 0 === i && (i = Promise); var a = new AsyncIterator(wrap(t, r, n, o), i); return e.isGeneratorFunction(r) ? a : a.next().then(function (t) { return t.done ? t.value : a.next(); }); }, defineIteratorMethods(g), define(g, u, "Generator"), define(g, a, function () { return this; }), define(g, "toString", function () { return "[object Generator]"; }), e.keys = function (t) { var e = Object(t), r = []; for (var n in e) r.push(n); return r.reverse(), function next() { for (; r.length;) { var t = r.pop(); if (t in e) return next.value = t, next.done = !1, next; } return next.done = !0, next; }; }, e.values = values, Context.prototype = { constructor: Context, reset: function reset(e) { if (this.prev = 0, this.next = 0, this.sent = this._sent = t, this.done = !1, this.delegate = null, this.method = "next", this.arg = t, this.tryEntries.forEach(resetTryEntry), !e) for (var r in this) "t" === r.charAt(0) && n.call(this, r) && !isNaN(+r.slice(1)) && (this[r] = t); }, stop: function stop() { this.done = !0; var t = this.tryEntries[0].completion; if ("throw" === t.type) throw t.arg; return this.rval; }, dispatchException: function dispatchException(e) { if (this.done) throw e; var r = this; function handle(n, o) { return a.type = "throw", a.arg = e, r.next = n, o && (r.method = "next", r.arg = t), !!o; } for (var o = this.tryEntries.length - 1; o >= 0; --o) { var i = this.tryEntries[o], a = i.completion; if ("root" === i.tryLoc) return handle("end"); if (i.tryLoc <= this.prev) { var c = n.call(i, "catchLoc"), u = n.call(i, "finallyLoc"); if (c && u) { if (this.prev < i.catchLoc) return handle(i.catchLoc, !0); if (this.prev < i.finallyLoc) return handle(i.finallyLoc); } else if (c) { if (this.prev < i.catchLoc) return handle(i.catchLoc, !0); } else { if (!u) throw new Error("try statement without catch or finally"); if (this.prev < i.finallyLoc) return handle(i.finallyLoc); } } } }, abrupt: function abrupt(t, e) { for (var r = this.tryEntries.length - 1; r >= 0; --r) { var o = this.tryEntries[r]; if (o.tryLoc <= this.prev && n.call(o, "finallyLoc") && this.prev < o.finallyLoc) { var i = o; break; } } i && ("break" === t || "continue" === t) && i.tryLoc <= e && e <= i.finallyLoc && (i = null); var a = i ? i.completion : {}; return a.type = t, a.arg = e, i ? (this.method = "next", this.next = i.finallyLoc, y) : this.complete(a); }, complete: function complete(t, e) { if ("throw" === t.type) throw t.arg; return "break" === t.type || "continue" === t.type ? this.next = t.arg : "return" === t.type ? (this.rval = this.arg = t.arg, this.method = "return", this.next = "end") : "normal" === t.type && e && (this.next = e), y; }, finish: function finish(t) { for (var e = this.tryEntries.length - 1; e >= 0; --e) { var r = this.tryEntries[e]; if (r.finallyLoc === t) return this.complete(r.completion, r.afterLoc), resetTryEntry(r), y; } }, catch: function _catch(t) { for (var e = this.tryEntries.length - 1; e >= 0; --e) { var r = this.tryEntries[e]; if (r.tryLoc === t) { var n = r.completion; if ("throw" === n.type) { var o = n.arg; resetTryEntry(r); } return o; } } throw new Error("illegal catch attempt"); }, delegateYield: function delegateYield(e, r, n) { return this.delegate = { iterator: values(e), resultName: r, nextLoc: n }, "next" === this.method && (this.arg = t), y; } }, e; }




















function CampaignStatComponent_div_6_ion_row_2_Template(rf, ctx) {
  if (rf & 1) {
    _angular_core__WEBPACK_IMPORTED_MODULE_14__["ɵɵelementStart"](0, "ion-row")(1, "ion-col", 12);
    _angular_core__WEBPACK_IMPORTED_MODULE_14__["ɵɵelement"](2, "app-icon", 13);
    _angular_core__WEBPACK_IMPORTED_MODULE_14__["ɵɵelementEnd"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_14__["ɵɵelementStart"](3, "ion-col")(4, "span", 14);
    _angular_core__WEBPACK_IMPORTED_MODULE_14__["ɵɵtext"](5);
    _angular_core__WEBPACK_IMPORTED_MODULE_14__["ɵɵpipe"](6, "translate");
    _angular_core__WEBPACK_IMPORTED_MODULE_14__["ɵɵelementEnd"]()()();
  }

  if (rf & 2) {
    _angular_core__WEBPACK_IMPORTED_MODULE_14__["ɵɵadvance"](5);
    _angular_core__WEBPACK_IMPORTED_MODULE_14__["ɵɵtextInterpolate1"](" ", _angular_core__WEBPACK_IMPORTED_MODULE_14__["ɵɵpipeBind1"](6, 1, "userprofile.blacklist_user"), " ");
  }
}

var _c0 = function _c0(a0) {
  return {
    won: a0
  };
};

function CampaignStatComponent_div_6_ion_grid_34_div_13_Template(rf, ctx) {
  if (rf & 1) {
    _angular_core__WEBPACK_IMPORTED_MODULE_14__["ɵɵelementStart"](0, "div")(1, "div", 19);
    _angular_core__WEBPACK_IMPORTED_MODULE_14__["ɵɵelement"](2, "app-icon", 20);
    _angular_core__WEBPACK_IMPORTED_MODULE_14__["ɵɵelementStart"](3, "b");
    _angular_core__WEBPACK_IMPORTED_MODULE_14__["ɵɵtext"](4);
    _angular_core__WEBPACK_IMPORTED_MODULE_14__["ɵɵelementEnd"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_14__["ɵɵtext"](5);
    _angular_core__WEBPACK_IMPORTED_MODULE_14__["ɵɵelementStart"](6, "b");
    _angular_core__WEBPACK_IMPORTED_MODULE_14__["ɵɵtext"](7);
    _angular_core__WEBPACK_IMPORTED_MODULE_14__["ɵɵpipe"](8, "translate");
    _angular_core__WEBPACK_IMPORTED_MODULE_14__["ɵɵelementEnd"]()()();
  }

  if (rf & 2) {
    var challengeType_r9 = ctx.$implicit;
    var ctx_r8 = _angular_core__WEBPACK_IMPORTED_MODULE_14__["ɵɵnextContext"](3);
    _angular_core__WEBPACK_IMPORTED_MODULE_14__["ɵɵadvance"](2);
    _angular_core__WEBPACK_IMPORTED_MODULE_14__["ɵɵproperty"]("name", ctx_r8.imgChallenge(challengeType_r9.type));
    _angular_core__WEBPACK_IMPORTED_MODULE_14__["ɵɵadvance"](2);
    _angular_core__WEBPACK_IMPORTED_MODULE_14__["ɵɵtextInterpolate1"](" ", challengeType_r9.completed + challengeType_r9.failed, " ");
    _angular_core__WEBPACK_IMPORTED_MODULE_14__["ɵɵadvance"](1);
    _angular_core__WEBPACK_IMPORTED_MODULE_14__["ɵɵtextInterpolate1"](" ", ctx_r8.typeChallenge(challengeType_r9.type), ": ");
    _angular_core__WEBPACK_IMPORTED_MODULE_14__["ɵɵadvance"](2);
    _angular_core__WEBPACK_IMPORTED_MODULE_14__["ɵɵtextInterpolate1"](" ", _angular_core__WEBPACK_IMPORTED_MODULE_14__["ɵɵpipeBind2"](8, 4, "userprofile.won", _angular_core__WEBPACK_IMPORTED_MODULE_14__["ɵɵpureFunction1"](7, _c0, challengeType_r9.completed)), "");
  }
}

var _c1 = function _c1(a0, a1) {
  return {
    periodFrom: a0,
    periodTo: a1
  };
};

function CampaignStatComponent_div_6_ion_grid_34_Template(rf, ctx) {
  if (rf & 1) {
    _angular_core__WEBPACK_IMPORTED_MODULE_14__["ɵɵelementStart"](0, "ion-grid")(1, "ion-row")(2, "ion-col")(3, "span", 15);
    _angular_core__WEBPACK_IMPORTED_MODULE_14__["ɵɵtext"](4);
    _angular_core__WEBPACK_IMPORTED_MODULE_14__["ɵɵpipe"](5, "translate");
    _angular_core__WEBPACK_IMPORTED_MODULE_14__["ɵɵpipe"](6, "localDate");
    _angular_core__WEBPACK_IMPORTED_MODULE_14__["ɵɵpipe"](7, "localDate");
    _angular_core__WEBPACK_IMPORTED_MODULE_14__["ɵɵelementEnd"]()()();
    _angular_core__WEBPACK_IMPORTED_MODULE_14__["ɵɵelementStart"](8, "ion-row")(9, "ion-col", 16);
    _angular_core__WEBPACK_IMPORTED_MODULE_14__["ɵɵelement"](10, "app-icon", 17);
    _angular_core__WEBPACK_IMPORTED_MODULE_14__["ɵɵelementEnd"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_14__["ɵɵelementStart"](11, "ion-col")(12, "div", 6);
    _angular_core__WEBPACK_IMPORTED_MODULE_14__["ɵɵtemplate"](13, CampaignStatComponent_div_6_ion_grid_34_div_13_Template, 9, 9, "div", 18);
    _angular_core__WEBPACK_IMPORTED_MODULE_14__["ɵɵpipe"](14, "async");
    _angular_core__WEBPACK_IMPORTED_MODULE_14__["ɵɵelementEnd"]()()()();
  }

  if (rf & 2) {
    var ctx_r4 = _angular_core__WEBPACK_IMPORTED_MODULE_14__["ɵɵnextContext"](2);
    _angular_core__WEBPACK_IMPORTED_MODULE_14__["ɵɵadvance"](4);
    _angular_core__WEBPACK_IMPORTED_MODULE_14__["ɵɵtextInterpolate"](_angular_core__WEBPACK_IMPORTED_MODULE_14__["ɵɵpipeBind2"](5, 3, "userprofile.period_challenge", _angular_core__WEBPACK_IMPORTED_MODULE_14__["ɵɵpureFunction2"](12, _c1, _angular_core__WEBPACK_IMPORTED_MODULE_14__["ɵɵpipeBind1"](6, 6, ctx_r4.getChallengeFrom()), _angular_core__WEBPACK_IMPORTED_MODULE_14__["ɵɵpipeBind1"](7, 8, ctx_r4.getChallengeTo()))));
    _angular_core__WEBPACK_IMPORTED_MODULE_14__["ɵɵadvance"](6);
    _angular_core__WEBPACK_IMPORTED_MODULE_14__["ɵɵproperty"]("color", ctx_r4.campaign.type);
    _angular_core__WEBPACK_IMPORTED_MODULE_14__["ɵɵadvance"](3);
    _angular_core__WEBPACK_IMPORTED_MODULE_14__["ɵɵproperty"]("ngForOf", _angular_core__WEBPACK_IMPORTED_MODULE_14__["ɵɵpipeBind1"](14, 10, ctx_r4.challengeStat$));
  }
}

function CampaignStatComponent_div_6_ng_container_37_Template(rf, ctx) {
  if (rf & 1) {
    var _r11 = _angular_core__WEBPACK_IMPORTED_MODULE_14__["ɵɵgetCurrentView"]();

    _angular_core__WEBPACK_IMPORTED_MODULE_14__["ɵɵelementContainerStart"](0);
    _angular_core__WEBPACK_IMPORTED_MODULE_14__["ɵɵelementStart"](1, "ion-button", 21);
    _angular_core__WEBPACK_IMPORTED_MODULE_14__["ɵɵlistener"]("click", function CampaignStatComponent_div_6_ng_container_37_Template_ion_button_click_1_listener() {
      _angular_core__WEBPACK_IMPORTED_MODULE_14__["ɵɵrestoreView"](_r11);
      var ctx_r10 = _angular_core__WEBPACK_IMPORTED_MODULE_14__["ɵɵnextContext"](2);
      return ctx_r10.removeBlacklist();
    });
    _angular_core__WEBPACK_IMPORTED_MODULE_14__["ɵɵelement"](2, "app-icon", 22);
    _angular_core__WEBPACK_IMPORTED_MODULE_14__["ɵɵtext"](3);
    _angular_core__WEBPACK_IMPORTED_MODULE_14__["ɵɵpipe"](4, "translate");
    _angular_core__WEBPACK_IMPORTED_MODULE_14__["ɵɵelementEnd"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_14__["ɵɵelementContainerEnd"]();
  }

  if (rf & 2) {
    _angular_core__WEBPACK_IMPORTED_MODULE_14__["ɵɵadvance"](3);
    _angular_core__WEBPACK_IMPORTED_MODULE_14__["ɵɵtextInterpolate1"]("", _angular_core__WEBPACK_IMPORTED_MODULE_14__["ɵɵpipeBind1"](4, 1, "userprofile.remove_blacklist"), " ");
  }
}

function CampaignStatComponent_div_6_ng_template_39_Template(rf, ctx) {
  if (rf & 1) {
    var _r13 = _angular_core__WEBPACK_IMPORTED_MODULE_14__["ɵɵgetCurrentView"]();

    _angular_core__WEBPACK_IMPORTED_MODULE_14__["ɵɵelementStart"](0, "ion-button", 23);
    _angular_core__WEBPACK_IMPORTED_MODULE_14__["ɵɵlistener"]("click", function CampaignStatComponent_div_6_ng_template_39_Template_ion_button_click_0_listener() {
      _angular_core__WEBPACK_IMPORTED_MODULE_14__["ɵɵrestoreView"](_r13);
      var ctx_r12 = _angular_core__WEBPACK_IMPORTED_MODULE_14__["ɵɵnextContext"](2);
      return ctx_r12.addBlacklist();
    });
    _angular_core__WEBPACK_IMPORTED_MODULE_14__["ɵɵelement"](1, "app-icon", 24);
    _angular_core__WEBPACK_IMPORTED_MODULE_14__["ɵɵtext"](2);
    _angular_core__WEBPACK_IMPORTED_MODULE_14__["ɵɵpipe"](3, "translate");
    _angular_core__WEBPACK_IMPORTED_MODULE_14__["ɵɵelementEnd"]();
  }

  if (rf & 2) {
    _angular_core__WEBPACK_IMPORTED_MODULE_14__["ɵɵadvance"](2);
    _angular_core__WEBPACK_IMPORTED_MODULE_14__["ɵɵtextInterpolate1"]("", _angular_core__WEBPACK_IMPORTED_MODULE_14__["ɵɵpipeBind1"](3, 1, "userprofile.add_blacklist"), " ");
  }
}

function CampaignStatComponent_div_6_Template(rf, ctx) {
  if (rf & 1) {
    _angular_core__WEBPACK_IMPORTED_MODULE_14__["ɵɵelementStart"](0, "div")(1, "ion-grid");
    _angular_core__WEBPACK_IMPORTED_MODULE_14__["ɵɵtemplate"](2, CampaignStatComponent_div_6_ion_row_2_Template, 7, 3, "ion-row", 3);
    _angular_core__WEBPACK_IMPORTED_MODULE_14__["ɵɵpipe"](3, "async");
    _angular_core__WEBPACK_IMPORTED_MODULE_14__["ɵɵelementStart"](4, "ion-row")(5, "ion-col", 4);
    _angular_core__WEBPACK_IMPORTED_MODULE_14__["ɵɵelement"](6, "app-icon", 5);
    _angular_core__WEBPACK_IMPORTED_MODULE_14__["ɵɵelementEnd"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_14__["ɵɵelementStart"](7, "ion-col")(8, "div", 6)(9, "div");
    _angular_core__WEBPACK_IMPORTED_MODULE_14__["ɵɵelement"](10, "app-ordinal-number", 7);
    _angular_core__WEBPACK_IMPORTED_MODULE_14__["ɵɵpipe"](11, "async");
    _angular_core__WEBPACK_IMPORTED_MODULE_14__["ɵɵtext"](12);
    _angular_core__WEBPACK_IMPORTED_MODULE_14__["ɵɵpipe"](13, "translate");
    _angular_core__WEBPACK_IMPORTED_MODULE_14__["ɵɵelementEnd"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_14__["ɵɵelementStart"](14, "div");
    _angular_core__WEBPACK_IMPORTED_MODULE_14__["ɵɵelement"](15, "app-ordinal-number", 7);
    _angular_core__WEBPACK_IMPORTED_MODULE_14__["ɵɵpipe"](16, "async");
    _angular_core__WEBPACK_IMPORTED_MODULE_14__["ɵɵtext"](17);
    _angular_core__WEBPACK_IMPORTED_MODULE_14__["ɵɵpipe"](18, "translate");
    _angular_core__WEBPACK_IMPORTED_MODULE_14__["ɵɵelementEnd"]()()()()();
    _angular_core__WEBPACK_IMPORTED_MODULE_14__["ɵɵelementStart"](19, "div")(20, "ion-grid")(21, "ion-row")(22, "ion-col", 4);
    _angular_core__WEBPACK_IMPORTED_MODULE_14__["ɵɵelement"](23, "app-icon", 8);
    _angular_core__WEBPACK_IMPORTED_MODULE_14__["ɵɵelementEnd"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_14__["ɵɵelementStart"](24, "ion-col")(25, "div", 6)(26, "div")(27, "span", 9);
    _angular_core__WEBPACK_IMPORTED_MODULE_14__["ɵɵtext"](28);
    _angular_core__WEBPACK_IMPORTED_MODULE_14__["ɵɵpipe"](29, "async");
    _angular_core__WEBPACK_IMPORTED_MODULE_14__["ɵɵelementEnd"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_14__["ɵɵelementStart"](30, "span");
    _angular_core__WEBPACK_IMPORTED_MODULE_14__["ɵɵtext"](31);
    _angular_core__WEBPACK_IMPORTED_MODULE_14__["ɵɵpipe"](32, "translate");
    _angular_core__WEBPACK_IMPORTED_MODULE_14__["ɵɵelementEnd"]()()()()()()();
    _angular_core__WEBPACK_IMPORTED_MODULE_14__["ɵɵelementStart"](33, "div");
    _angular_core__WEBPACK_IMPORTED_MODULE_14__["ɵɵtemplate"](34, CampaignStatComponent_div_6_ion_grid_34_Template, 15, 15, "ion-grid", 3);
    _angular_core__WEBPACK_IMPORTED_MODULE_14__["ɵɵpipe"](35, "async");
    _angular_core__WEBPACK_IMPORTED_MODULE_14__["ɵɵelementEnd"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_14__["ɵɵelementStart"](36, "div", 10);
    _angular_core__WEBPACK_IMPORTED_MODULE_14__["ɵɵtemplate"](37, CampaignStatComponent_div_6_ng_container_37_Template, 5, 3, "ng-container", 1);
    _angular_core__WEBPACK_IMPORTED_MODULE_14__["ɵɵpipe"](38, "async");
    _angular_core__WEBPACK_IMPORTED_MODULE_14__["ɵɵtemplate"](39, CampaignStatComponent_div_6_ng_template_39_Template, 4, 3, "ng-template", null, 11, _angular_core__WEBPACK_IMPORTED_MODULE_14__["ɵɵtemplateRefExtractor"]);
    _angular_core__WEBPACK_IMPORTED_MODULE_14__["ɵɵelementEnd"]()();
  }

  if (rf & 2) {
    var _r6 = _angular_core__WEBPACK_IMPORTED_MODULE_14__["ɵɵreference"](40);

    var ctx_r0 = _angular_core__WEBPACK_IMPORTED_MODULE_14__["ɵɵnextContext"]();
    var tmp_3_0;
    var tmp_5_0;
    var tmp_9_0;
    var tmp_11_0;
    _angular_core__WEBPACK_IMPORTED_MODULE_14__["ɵɵadvance"](2);
    _angular_core__WEBPACK_IMPORTED_MODULE_14__["ɵɵproperty"]("ngIf", _angular_core__WEBPACK_IMPORTED_MODULE_14__["ɵɵpipeBind1"](3, 16, ctx_r0.blacklisted$) === true);
    _angular_core__WEBPACK_IMPORTED_MODULE_14__["ɵɵadvance"](2);
    _angular_core__WEBPACK_IMPORTED_MODULE_14__["ɵɵstyleProp"]("border-bottom", "3px solid var(--ion-color-" + ctx_r0.campaign.type + ")");
    _angular_core__WEBPACK_IMPORTED_MODULE_14__["ɵɵadvance"](2);
    _angular_core__WEBPACK_IMPORTED_MODULE_14__["ɵɵproperty"]("color", ctx_r0.campaign.type);
    _angular_core__WEBPACK_IMPORTED_MODULE_14__["ɵɵadvance"](4);
    _angular_core__WEBPACK_IMPORTED_MODULE_14__["ɵɵproperty"]("value", (tmp_3_0 = _angular_core__WEBPACK_IMPORTED_MODULE_14__["ɵɵpipeBind1"](11, 18, ctx_r0.reportWeek$)) == null ? null : tmp_3_0.position);
    _angular_core__WEBPACK_IMPORTED_MODULE_14__["ɵɵadvance"](2);
    _angular_core__WEBPACK_IMPORTED_MODULE_14__["ɵɵtextInterpolate1"](" ", _angular_core__WEBPACK_IMPORTED_MODULE_14__["ɵɵpipeBind1"](13, 20, "userprofile.last_week_position"), " ");
    _angular_core__WEBPACK_IMPORTED_MODULE_14__["ɵɵadvance"](3);
    _angular_core__WEBPACK_IMPORTED_MODULE_14__["ɵɵproperty"]("value", (tmp_5_0 = _angular_core__WEBPACK_IMPORTED_MODULE_14__["ɵɵpipeBind1"](16, 22, ctx_r0.reportTotal$)) == null ? null : tmp_5_0.position);
    _angular_core__WEBPACK_IMPORTED_MODULE_14__["ɵɵadvance"](2);
    _angular_core__WEBPACK_IMPORTED_MODULE_14__["ɵɵtextInterpolate1"](" ", _angular_core__WEBPACK_IMPORTED_MODULE_14__["ɵɵpipeBind1"](18, 24, "userprofile.general_position"), " ");
    _angular_core__WEBPACK_IMPORTED_MODULE_14__["ɵɵadvance"](4);
    _angular_core__WEBPACK_IMPORTED_MODULE_14__["ɵɵstyleProp"]("border-bottom", "3px solid var(--ion-color-" + ctx_r0.campaign.type + ")");
    _angular_core__WEBPACK_IMPORTED_MODULE_14__["ɵɵadvance"](2);
    _angular_core__WEBPACK_IMPORTED_MODULE_14__["ɵɵproperty"]("name", ctx_r0.campaignService.getCampaignTypeIcon(ctx_r0.campaign));
    _angular_core__WEBPACK_IMPORTED_MODULE_14__["ɵɵadvance"](5);
    _angular_core__WEBPACK_IMPORTED_MODULE_14__["ɵɵtextInterpolate"]((tmp_9_0 = _angular_core__WEBPACK_IMPORTED_MODULE_14__["ɵɵpipeBind1"](29, 26, ctx_r0.reportTotal$)) == null ? null : tmp_9_0.value);
    _angular_core__WEBPACK_IMPORTED_MODULE_14__["ɵɵadvance"](3);
    _angular_core__WEBPACK_IMPORTED_MODULE_14__["ɵɵtextInterpolate"](_angular_core__WEBPACK_IMPORTED_MODULE_14__["ɵɵpipeBind1"](32, 28, "userprofile.total_points"));
    _angular_core__WEBPACK_IMPORTED_MODULE_14__["ɵɵadvance"](3);
    _angular_core__WEBPACK_IMPORTED_MODULE_14__["ɵɵproperty"]("ngIf", ((tmp_11_0 = _angular_core__WEBPACK_IMPORTED_MODULE_14__["ɵɵpipeBind1"](35, 30, ctx_r0.challengeStat$)) == null ? null : tmp_11_0.length) > 0);
    _angular_core__WEBPACK_IMPORTED_MODULE_14__["ɵɵadvance"](3);
    _angular_core__WEBPACK_IMPORTED_MODULE_14__["ɵɵproperty"]("ngIf", _angular_core__WEBPACK_IMPORTED_MODULE_14__["ɵɵpipeBind1"](38, 32, ctx_r0.blacklisted$))("ngIfElse", _r6);
  }
}

function CampaignStatComponent_ng_template_7_Template(rf, ctx) {
  if (rf & 1) {
    _angular_core__WEBPACK_IMPORTED_MODULE_14__["ɵɵelementStart"](0, "ion-grid")(1, "ion-row")(2, "ion-col")(3, "div", 10);
    _angular_core__WEBPACK_IMPORTED_MODULE_14__["ɵɵtext"](4);
    _angular_core__WEBPACK_IMPORTED_MODULE_14__["ɵɵpipe"](5, "translate");
    _angular_core__WEBPACK_IMPORTED_MODULE_14__["ɵɵelementEnd"]()()()();
  }

  if (rf & 2) {
    _angular_core__WEBPACK_IMPORTED_MODULE_14__["ɵɵadvance"](4);
    _angular_core__WEBPACK_IMPORTED_MODULE_14__["ɵɵtextInterpolate"](_angular_core__WEBPACK_IMPORTED_MODULE_14__["ɵɵpipeBind1"](5, 1, "userprofile.user_joined"));
  }
}

var CampaignStatComponent = /*#__PURE__*/function () {
  // public points$
  function CampaignStatComponent(challengeService, reportService, translateService, campaignService, authService, errorService) {
    (0,_Users_smartcommunitylab_Desktop_newWork_dslab_playgo_mobile_playgo_mobile_node_modules_babel_runtime_helpers_esm_classCallCheck_js__WEBPACK_IMPORTED_MODULE_0__["default"])(this, CampaignStatComponent);

    this.challengeService = challengeService;
    this.reportService = reportService;
    this.translateService = translateService;
    this.campaignService = campaignService;
    this.authService = authService;
    this.errorService = errorService;
    this.imgChallenge = src_app_core_shared_campaigns_campaign_utils__WEBPACK_IMPORTED_MODULE_3__.getImgChallenge;
    this.blacklistRefresher$ = new rxjs__WEBPACK_IMPORTED_MODULE_15__.ReplaySubject(1);
    this.blacklistCouldBeChanged$ = (0,rxjs__WEBPACK_IMPORTED_MODULE_16__.merge)(this.authService.isReadyForApi$.pipe((0,rxjs__WEBPACK_IMPORTED_MODULE_17__.map)(function () {
      return {
        isFirst: true
      };
    })), this.blacklistRefresher$.pipe((0,rxjs__WEBPACK_IMPORTED_MODULE_17__.map)(function () {
      return {
        isFirst: false
      };
    })));
  }

  (0,_Users_smartcommunitylab_Desktop_newWork_dslab_playgo_mobile_playgo_mobile_node_modules_babel_runtime_helpers_esm_createClass_js__WEBPACK_IMPORTED_MODULE_1__["default"])(CampaignStatComponent, [{
    key: "getChallengeFrom",
    value: function getChallengeFrom() {
      return (0,src_app_core_shared_time_utils__WEBPACK_IMPORTED_MODULE_4__.toServerDateOnly)(luxon__WEBPACK_IMPORTED_MODULE_2__.DateTime.utc().minus({
        month: 1
      }));
    }
  }, {
    key: "getChallengeTo",
    value: function getChallengeTo() {
      return (0,src_app_core_shared_time_utils__WEBPACK_IMPORTED_MODULE_4__.toServerDateOnly)(luxon__WEBPACK_IMPORTED_MODULE_2__.DateTime.utc());
    }
  }, {
    key: "ngOnInit",
    value: function ngOnInit() {
      var _this = this;

      var _a, _b, _c;

      this.challengeStat$ = this.challengeService.getChallengeStats({
        campaignId: (_a = this.campaign) === null || _a === void 0 ? void 0 : _a.campaignId,
        playerId: this.playerId,
        groupMode: 'month',
        dateFrom: (0,src_app_core_shared_time_utils__WEBPACK_IMPORTED_MODULE_4__.toServerDateOnly)(luxon__WEBPACK_IMPORTED_MODULE_2__.DateTime.utc().minus({
          month: 1
        })),
        dateTo: (0,src_app_core_shared_time_utils__WEBPACK_IMPORTED_MODULE_4__.toServerDateOnly)(luxon__WEBPACK_IMPORTED_MODULE_2__.DateTime.utc())
      }).pipe((0,rxjs__WEBPACK_IMPORTED_MODULE_17__.map)(function (challs) {
        return challs === null || challs === void 0 ? void 0 : challs.filter(function (chall) {
          return (chall === null || chall === void 0 ? void 0 : chall.type) !== 'survey';
        });
      }), (0,rxjs__WEBPACK_IMPORTED_MODULE_17__.map)(function (challs) {
        return challs === null || challs === void 0 ? void 0 : challs.map(function (chall) {
          if ((chall === null || chall === void 0 ? void 0 : chall.type) !== 'groupCooperative' && (chall === null || chall === void 0 ? void 0 : chall.type) !== 'groupCompetitiveTime' && (chall === null || chall === void 0 ? void 0 : chall.type) !== 'groupCompetitivePerformance') {
            chall.type = 'single';
          }

          return chall;
        });
      }), (0,rxjs__WEBPACK_IMPORTED_MODULE_17__.map)(function (challs) {
        return challs.reduce(function (acc, item) {
          var existItem = acc.find(function (_ref) {
            var type = _ref.type;
            return item.type === type;
          });

          if (existItem) {
            existItem.completed += item.completed;
            existItem.failed += item.failed;
          } else {
            acc.push(item);
          }

          return acc;
        }, []);
      }));
      this.reportWeek$ = this.reportService.getGameStats((_b = this.campaign) === null || _b === void 0 ? void 0 : _b.campaignId, this.playerId, (0,src_app_core_shared_time_utils__WEBPACK_IMPORTED_MODULE_4__.toServerDateOnly)(luxon__WEBPACK_IMPORTED_MODULE_2__.DateTime.utc().startOf('week')), (0,src_app_core_shared_time_utils__WEBPACK_IMPORTED_MODULE_4__.toServerDateOnly)(luxon__WEBPACK_IMPORTED_MODULE_2__.DateTime.utc()));
      this.reportTotal$ = this.reportService.getGameStats((_c = this.campaign) === null || _c === void 0 ? void 0 : _c.campaignId, this.playerId);
      this.blacklisted$ = this.blacklistCouldBeChanged$.pipe((0,rxjs__WEBPACK_IMPORTED_MODULE_18__.switchMap)(function () {
        var _a;

        return _this.challengeService.getBlacklistByCampaign((_a = _this.campaign) === null || _a === void 0 ? void 0 : _a.campaignId).pipe((0,rxjs__WEBPACK_IMPORTED_MODULE_17__.map)(function (blacklist) {
          return blacklist.map(function (user) {
            return user.id;
          }).includes(_this.playerId);
        }));
      }));
    }
  }, {
    key: "typeChallenge",
    value: function typeChallenge(type) {
      return this.translateService.instant((0,src_app_core_shared_campaigns_campaign_utils__WEBPACK_IMPORTED_MODULE_3__.getTypeStringChallenge)(type));
    }
  }, {
    key: "removeBlacklist",
    value: function removeBlacklist() {
      return (0,tslib__WEBPACK_IMPORTED_MODULE_19__.__awaiter)(this, void 0, void 0, /*#__PURE__*/_regeneratorRuntime().mark(function _callee() {
        var removed;
        return _regeneratorRuntime().wrap(function _callee$(_context) {
          while (1) switch (_context.prev = _context.next) {
            case 0:
              _context.prev = 0;
              _context.next = 3;
              return this.challengeService.removeBlacklist(this.campaign.campaignId, this.playerId);

            case 3:
              removed = _context.sent;
              this.blacklistRefresher$.next();
              _context.next = 10;
              break;

            case 7:
              _context.prev = 7;
              _context.t0 = _context["catch"](0);
              this.errorService.handleError(_context.t0, 'normal');

            case 10:
            case "end":
              return _context.stop();
          }
        }, _callee, this, [[0, 7]]);
      }));
    }
  }, {
    key: "addBlacklist",
    value: function addBlacklist() {
      return (0,tslib__WEBPACK_IMPORTED_MODULE_19__.__awaiter)(this, void 0, void 0, /*#__PURE__*/_regeneratorRuntime().mark(function _callee2() {
        var removed;
        return _regeneratorRuntime().wrap(function _callee2$(_context2) {
          while (1) switch (_context2.prev = _context2.next) {
            case 0:
              _context2.prev = 0;
              _context2.next = 3;
              return this.challengeService.addBlacklist(this.campaign.campaignId, this.playerId);

            case 3:
              removed = _context2.sent;
              this.blacklistRefresher$.next();
              _context2.next = 10;
              break;

            case 7:
              _context2.prev = 7;
              _context2.t0 = _context2["catch"](0);
              this.errorService.handleError(_context2.t0, 'normal');

            case 10:
            case "end":
              return _context2.stop();
          }
        }, _callee2, this, [[0, 7]]);
      }));
    }
  }]);

  return CampaignStatComponent;
}();

CampaignStatComponent.ɵfac = function CampaignStatComponent_Factory(t) {
  return new (t || CampaignStatComponent)(_angular_core__WEBPACK_IMPORTED_MODULE_14__["ɵɵdirectiveInject"](src_app_core_shared_services_challenge_service__WEBPACK_IMPORTED_MODULE_5__.ChallengeService), _angular_core__WEBPACK_IMPORTED_MODULE_14__["ɵɵdirectiveInject"](src_app_core_shared_services_report_service__WEBPACK_IMPORTED_MODULE_6__.ReportService), _angular_core__WEBPACK_IMPORTED_MODULE_14__["ɵɵdirectiveInject"](_ngx_translate_core__WEBPACK_IMPORTED_MODULE_20__.TranslateService), _angular_core__WEBPACK_IMPORTED_MODULE_14__["ɵɵdirectiveInject"](src_app_core_shared_services_campaign_service__WEBPACK_IMPORTED_MODULE_7__.CampaignService), _angular_core__WEBPACK_IMPORTED_MODULE_14__["ɵɵdirectiveInject"](src_app_core_auth_auth_service__WEBPACK_IMPORTED_MODULE_8__.AuthService), _angular_core__WEBPACK_IMPORTED_MODULE_14__["ɵɵdirectiveInject"](src_app_core_shared_services_error_service__WEBPACK_IMPORTED_MODULE_9__.ErrorService));
};

CampaignStatComponent.ɵcmp = /*@__PURE__*/_angular_core__WEBPACK_IMPORTED_MODULE_14__["ɵɵdefineComponent"]({
  type: CampaignStatComponent,
  selectors: [["app-campaign-stat"]],
  inputs: {
    playerId: "playerId",
    campaign: "campaign"
  },
  decls: 9,
  vars: 6,
  consts: [[3, "color"], [4, "ngIf", "ngIfElse"], ["school", ""], [4, "ngIf"], ["size", "2"], ["name", "leaderboard", 1, "icon-size-medium", 3, "color"], [1, "result"], [3, "value"], [1, "icon-size-medium", 3, "name"], [1, "bolded"], [1, "ion-text-center"], ["addblacklist", ""], ["size", "auto", 1, "chall-line"], ["name", "blockUserColor", 1, "icon-size-normal"], [1, "blockuser-info"], [1, "challe-text"], ["size", "2", 1, "chall-line"], ["name", "cup", 1, "icon-size-medium", 3, "color"], [4, "ngFor", "ngForOf"], [1, "chall-line"], [1, "challenge-icon", "icon-size-normal", 3, "name"], [1, "remove-button", 3, "click"], ["name", "invitation", 1, "icon-size-normal"], [1, "add-button", 3, "click"], ["name", "blacklist", 1, "icon-size-normal"]],
  template: function CampaignStatComponent_Template(rf, ctx) {
    if (rf & 1) {
      _angular_core__WEBPACK_IMPORTED_MODULE_14__["ɵɵelement"](0, "p");
      _angular_core__WEBPACK_IMPORTED_MODULE_14__["ɵɵelementStart"](1, "ion-card")(2, "ion-card-header", 0);
      _angular_core__WEBPACK_IMPORTED_MODULE_14__["ɵɵtext"](3);
      _angular_core__WEBPACK_IMPORTED_MODULE_14__["ɵɵpipe"](4, "languageMap");
      _angular_core__WEBPACK_IMPORTED_MODULE_14__["ɵɵelementEnd"]();
      _angular_core__WEBPACK_IMPORTED_MODULE_14__["ɵɵelementStart"](5, "ion-card-content");
      _angular_core__WEBPACK_IMPORTED_MODULE_14__["ɵɵtemplate"](6, CampaignStatComponent_div_6_Template, 41, 34, "div", 1);
      _angular_core__WEBPACK_IMPORTED_MODULE_14__["ɵɵtemplate"](7, CampaignStatComponent_ng_template_7_Template, 6, 3, "ng-template", null, 2, _angular_core__WEBPACK_IMPORTED_MODULE_14__["ɵɵtemplateRefExtractor"]);
      _angular_core__WEBPACK_IMPORTED_MODULE_14__["ɵɵelementEnd"]()();
    }

    if (rf & 2) {
      var _r1 = _angular_core__WEBPACK_IMPORTED_MODULE_14__["ɵɵreference"](8);

      _angular_core__WEBPACK_IMPORTED_MODULE_14__["ɵɵadvance"](2);
      _angular_core__WEBPACK_IMPORTED_MODULE_14__["ɵɵproperty"]("color", ctx.campaign.type);
      _angular_core__WEBPACK_IMPORTED_MODULE_14__["ɵɵadvance"](1);
      _angular_core__WEBPACK_IMPORTED_MODULE_14__["ɵɵtextInterpolate1"](" ", _angular_core__WEBPACK_IMPORTED_MODULE_14__["ɵɵpipeBind1"](4, 4, ctx.campaign.name), " ");
      _angular_core__WEBPACK_IMPORTED_MODULE_14__["ɵɵadvance"](3);
      _angular_core__WEBPACK_IMPORTED_MODULE_14__["ɵɵproperty"]("ngIf", ctx.campaign.type !== "school")("ngIfElse", _r1);
    }
  },
  directives: [_ionic_angular__WEBPACK_IMPORTED_MODULE_21__.IonCard, _ionic_angular__WEBPACK_IMPORTED_MODULE_21__.IonCardHeader, _ionic_angular__WEBPACK_IMPORTED_MODULE_21__.IonCardContent, _angular_common__WEBPACK_IMPORTED_MODULE_22__.NgIf, _ionic_angular__WEBPACK_IMPORTED_MODULE_21__.IonGrid, _ionic_angular__WEBPACK_IMPORTED_MODULE_21__.IonRow, _ionic_angular__WEBPACK_IMPORTED_MODULE_21__.IonCol, _core_shared_ui_icon_icon_component__WEBPACK_IMPORTED_MODULE_10__.IconComponent, _core_shared_globalization_ordinal_number_ordinal_number_component__WEBPACK_IMPORTED_MODULE_11__.OrdinalNumberComponent, _angular_common__WEBPACK_IMPORTED_MODULE_22__.NgForOf, _ionic_angular__WEBPACK_IMPORTED_MODULE_21__.IonButton],
  pipes: [_core_shared_pipes_languageMap_pipe__WEBPACK_IMPORTED_MODULE_12__.LanguageMapPipe, _angular_common__WEBPACK_IMPORTED_MODULE_22__.AsyncPipe, _ngx_translate_core__WEBPACK_IMPORTED_MODULE_20__.TranslatePipe, _core_shared_pipes_localDate_pipe__WEBPACK_IMPORTED_MODULE_13__.LocalDatePipe],
  styles: ["ion-card[_ngcontent-%COMP%] {\n  color: var(--dark-grey);\n}\nion-card[_ngcontent-%COMP%]   ion-card-header[_ngcontent-%COMP%] {\n  height: 21px;\n  display: flex;\n  justify-content: space-around;\n  flex-direction: column;\n  font-weight: 300;\n  font-size: 13px;\n  font-style: italic;\n}\nion-card[_ngcontent-%COMP%]   .challe-text[_ngcontent-%COMP%] {\n  font-size: 13px;\n  font-style: italic;\n}\nion-card[_ngcontent-%COMP%]   .blockuser-info[_ngcontent-%COMP%] {\n  font-size: 11px;\n  font-style: italic;\n}\nion-card[_ngcontent-%COMP%]   .chall-line[_ngcontent-%COMP%] {\n  display: flex;\n  align-items: center !important;\n}\nion-card[_ngcontent-%COMP%]   .result[_ngcontent-%COMP%] {\n  display: flex;\n  flex-flow: column;\n  height: 100%;\n  justify-content: center;\n  margin-left: 10px;\n  font-style: italic;\n  font-weight: 300;\n  font-size: 13px;\n}\nion-card[_ngcontent-%COMP%]   .result[_ngcontent-%COMP%]   .bolded[_ngcontent-%COMP%] {\n  font-weight: 600;\n}\nion-card[_ngcontent-%COMP%]   app-ordinal-number[_ngcontent-%COMP%] {\n  font-weight: 600;\n}\nion-card[_ngcontent-%COMP%]   .add-button[_ngcontent-%COMP%] {\n  --background: rgba(198, 16, 16, 1);\n}\nion-card[_ngcontent-%COMP%]   .remove-button[_ngcontent-%COMP%] {\n  --background: rgba(53, 150, 117, 1);\n}\nion-card[_ngcontent-%COMP%]   ion-button[_ngcontent-%COMP%]   app-icon[_ngcontent-%COMP%] {\n  padding: 0px 8px 0px 0px;\n}\n/*# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbImNhbXBhaWduLXN0YXQuY29tcG9uZW50LnNjc3MiXSwibmFtZXMiOltdLCJtYXBwaW5ncyI6IkFBQUE7RUFDRSx1QkFBQTtBQUNGO0FBQ0U7RUFDRSxZQUFBO0VBQ0EsYUFBQTtFQUNBLDZCQUFBO0VBQ0Esc0JBQUE7RUFDQSxnQkFBQTtFQUNBLGVBQUE7RUFDQSxrQkFBQTtBQUNKO0FBQ0U7RUFDRSxlQUFBO0VBQ0Esa0JBQUE7QUFDSjtBQUNFO0VBQ0UsZUFBQTtFQUNBLGtCQUFBO0FBQ0o7QUFDRTtFQUNFLGFBQUE7RUFDQSw4QkFBQTtBQUNKO0FBQ0U7RUFDRSxhQUFBO0VBQ0EsaUJBQUE7RUFDQSxZQUFBO0VBQ0EsdUJBQUE7RUFDQSxpQkFBQTtFQUNBLGtCQUFBO0VBQ0EsZ0JBQUE7RUFDQSxlQUFBO0FBQ0o7QUFDSTtFQUNFLGdCQUFBO0FBQ047QUFNRTtFQUNFLGdCQUFBO0FBSko7QUFNRTtFQUNFLGtDQUFBO0FBSko7QUFNRTtFQUNFLG1DQUFBO0FBSko7QUFPSTtFQUNFLHdCQUFBO0FBTE4iLCJmaWxlIjoiY2FtcGFpZ24tc3RhdC5jb21wb25lbnQuc2NzcyIsInNvdXJjZXNDb250ZW50IjpbImlvbi1jYXJkIHtcbiAgY29sb3I6IHZhcigtLWRhcmstZ3JleSk7XG5cbiAgaW9uLWNhcmQtaGVhZGVyIHtcbiAgICBoZWlnaHQ6IDIxcHg7XG4gICAgZGlzcGxheTogZmxleDtcbiAgICBqdXN0aWZ5LWNvbnRlbnQ6IHNwYWNlLWFyb3VuZDtcbiAgICBmbGV4LWRpcmVjdGlvbjogY29sdW1uO1xuICAgIGZvbnQtd2VpZ2h0OiAzMDA7XG4gICAgZm9udC1zaXplOiAxM3B4O1xuICAgIGZvbnQtc3R5bGU6IGl0YWxpYztcbiAgfVxuICAuY2hhbGxlLXRleHQge1xuICAgIGZvbnQtc2l6ZTogMTNweDtcbiAgICBmb250LXN0eWxlOiBpdGFsaWM7XG4gIH1cbiAgLmJsb2NrdXNlci1pbmZvIHtcbiAgICBmb250LXNpemU6IDExcHg7XG4gICAgZm9udC1zdHlsZTogaXRhbGljO1xuICB9XG4gIC5jaGFsbC1saW5lIHtcbiAgICBkaXNwbGF5OiBmbGV4O1xuICAgIGFsaWduLWl0ZW1zOiBjZW50ZXIgIWltcG9ydGFudDtcbiAgfVxuICAucmVzdWx0IHtcbiAgICBkaXNwbGF5OiBmbGV4O1xuICAgIGZsZXgtZmxvdzogY29sdW1uO1xuICAgIGhlaWdodDogMTAwJTtcbiAgICBqdXN0aWZ5LWNvbnRlbnQ6IGNlbnRlcjtcbiAgICBtYXJnaW4tbGVmdDogMTBweDtcbiAgICBmb250LXN0eWxlOiBpdGFsaWM7XG4gICAgZm9udC13ZWlnaHQ6IDMwMDtcbiAgICBmb250LXNpemU6IDEzcHg7XG5cbiAgICAuYm9sZGVkIHtcbiAgICAgIGZvbnQtd2VpZ2h0OiA2MDA7XG4gICAgfVxuICB9XG5cbiAgLy8gLmJvcmRlciB7XG4gIC8vICAgYm9yZGVyLWJvdHRvbTogMnB4IHNvbGlkIGJsYWNrO1xuICAvLyB9XG4gIGFwcC1vcmRpbmFsLW51bWJlciB7XG4gICAgZm9udC13ZWlnaHQ6IDYwMDtcbiAgfVxuICAuYWRkLWJ1dHRvbiB7XG4gICAgLS1iYWNrZ3JvdW5kOiByZ2JhKDE5OCwgMTYsIDE2LCAxKTtcbiAgfVxuICAucmVtb3ZlLWJ1dHRvbiB7XG4gICAgLS1iYWNrZ3JvdW5kOiByZ2JhKDUzLCAxNTAsIDExNywgMSk7XG4gIH1cbiAgaW9uLWJ1dHRvbiB7XG4gICAgYXBwLWljb24ge1xuICAgICAgcGFkZGluZzogMHB4IDhweCAwcHggMHB4O1xuICAgIH1cbiAgfVxufVxuIl19 */"]
});

/***/ }),

/***/ 2731:
/*!*******************************************************************************!*\
  !*** ./src/app/pages/user-profile/transport-stat/transport-stat.component.ts ***!
  \*******************************************************************************/
/***/ (function(__unused_webpack_module, __webpack_exports__, __webpack_require__) {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "TransportStatComponent": function() { return /* binding */ TransportStatComponent; }
/* harmony export */ });
/* harmony import */ var _Users_smartcommunitylab_Desktop_newWork_dslab_playgo_mobile_playgo_mobile_node_modules_babel_runtime_helpers_esm_classCallCheck_js__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./node_modules/@babel/runtime/helpers/esm/classCallCheck.js */ 78069);
/* harmony import */ var _Users_smartcommunitylab_Desktop_newWork_dslab_playgo_mobile_playgo_mobile_node_modules_babel_runtime_helpers_esm_createClass_js__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ./node_modules/@babel/runtime/helpers/esm/createClass.js */ 48047);
/* harmony import */ var rxjs__WEBPACK_IMPORTED_MODULE_9__ = __webpack_require__(/*! rxjs */ 32673);
/* harmony import */ var rxjs__WEBPACK_IMPORTED_MODULE_10__ = __webpack_require__(/*! rxjs */ 89196);
/* harmony import */ var src_app_core_shared_time_utils__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! src/app/core/shared/time.utils */ 93462);
/* harmony import */ var luxon__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! luxon */ 20020);
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(/*! @angular/core */ 3184);
/* harmony import */ var src_app_core_shared_services_campaign_service__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! src/app/core/shared/services/campaign.service */ 23645);
/* harmony import */ var src_app_core_api_generated_controllers_reportController_service__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! src/app/core/api/generated/controllers/reportController.service */ 59730);
/* harmony import */ var _ionic_angular__WEBPACK_IMPORTED_MODULE_11__ = __webpack_require__(/*! @ionic/angular */ 93819);
/* harmony import */ var _angular_common__WEBPACK_IMPORTED_MODULE_12__ = __webpack_require__(/*! @angular/common */ 36362);
/* harmony import */ var _core_shared_ui_icon_icon_component__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! ../../../core/shared/ui/icon/icon.component */ 71888);
/* harmony import */ var _ngx_translate_core__WEBPACK_IMPORTED_MODULE_13__ = __webpack_require__(/*! @ngx-translate/core */ 87514);
/* harmony import */ var _core_shared_pipes_localNumber_pipe__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(/*! ../../../core/shared/pipes/localNumber.pipe */ 89713);














function TransportStatComponent_ng_container_7_ion_col_1_Template(rf, ctx) {
  if (rf & 1) {
    _angular_core__WEBPACK_IMPORTED_MODULE_8__["ɵɵelementStart"](0, "ion-col", 4);
    _angular_core__WEBPACK_IMPORTED_MODULE_8__["ɵɵelement"](1, "app-icon", 5);
    _angular_core__WEBPACK_IMPORTED_MODULE_8__["ɵɵelementStart"](2, "span");
    _angular_core__WEBPACK_IMPORTED_MODULE_8__["ɵɵtext"](3);
    _angular_core__WEBPACK_IMPORTED_MODULE_8__["ɵɵpipe"](4, "localNumber");
    _angular_core__WEBPACK_IMPORTED_MODULE_8__["ɵɵpipe"](5, "translate");
    _angular_core__WEBPACK_IMPORTED_MODULE_8__["ɵɵpipe"](6, "translate");
    _angular_core__WEBPACK_IMPORTED_MODULE_8__["ɵɵelementEnd"]()();
  }

  if (rf & 2) {
    var stat_r4 = ctx.$implicit;
    _angular_core__WEBPACK_IMPORTED_MODULE_8__["ɵɵadvance"](1);
    _angular_core__WEBPACK_IMPORTED_MODULE_8__["ɵɵproperty"]("name", "directions_" + stat_r4.mean);
    _angular_core__WEBPACK_IMPORTED_MODULE_8__["ɵɵadvance"](2);
    _angular_core__WEBPACK_IMPORTED_MODULE_8__["ɵɵtextInterpolate3"](" ", _angular_core__WEBPACK_IMPORTED_MODULE_8__["ɵɵpipeBind2"](4, 4, stat_r4.value / 1000, "0.0-1"), " ", _angular_core__WEBPACK_IMPORTED_MODULE_8__["ɵɵpipeBind1"](5, 7, "km"), " ", _angular_core__WEBPACK_IMPORTED_MODULE_8__["ɵɵpipeBind1"](6, 9, "userprofile.personal_stat_" + stat_r4.mean), " ");
  }
}

function TransportStatComponent_ng_container_7_Template(rf, ctx) {
  if (rf & 1) {
    _angular_core__WEBPACK_IMPORTED_MODULE_8__["ɵɵelementContainerStart"](0);
    _angular_core__WEBPACK_IMPORTED_MODULE_8__["ɵɵtemplate"](1, TransportStatComponent_ng_container_7_ion_col_1_Template, 7, 11, "ion-col", 3);
    _angular_core__WEBPACK_IMPORTED_MODULE_8__["ɵɵpipe"](2, "async");
    _angular_core__WEBPACK_IMPORTED_MODULE_8__["ɵɵelementContainerEnd"]();
  }

  if (rf & 2) {
    var ctx_r0 = _angular_core__WEBPACK_IMPORTED_MODULE_8__["ɵɵnextContext"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_8__["ɵɵadvance"](1);
    _angular_core__WEBPACK_IMPORTED_MODULE_8__["ɵɵproperty"]("ngForOf", _angular_core__WEBPACK_IMPORTED_MODULE_8__["ɵɵpipeBind1"](2, 1, ctx_r0.personalStat$));
  }
}

function TransportStatComponent_ng_template_9_Template(rf, ctx) {
  if (rf & 1) {
    _angular_core__WEBPACK_IMPORTED_MODULE_8__["ɵɵelementStart"](0, "ion-col")(1, "div", 6);
    _angular_core__WEBPACK_IMPORTED_MODULE_8__["ɵɵtext"](2);
    _angular_core__WEBPACK_IMPORTED_MODULE_8__["ɵɵpipe"](3, "translate");
    _angular_core__WEBPACK_IMPORTED_MODULE_8__["ɵɵelementEnd"]()();
  }

  if (rf & 2) {
    _angular_core__WEBPACK_IMPORTED_MODULE_8__["ɵɵadvance"](2);
    _angular_core__WEBPACK_IMPORTED_MODULE_8__["ɵɵtextInterpolate"](_angular_core__WEBPACK_IMPORTED_MODULE_8__["ɵɵpipeBind1"](3, 1, "userprofile.empty"));
  }
}

var TransportStatComponent = /*#__PURE__*/function () {
  function TransportStatComponent(campaignService, reportController) {
    var _this = this;

    (0,_Users_smartcommunitylab_Desktop_newWork_dslab_playgo_mobile_playgo_mobile_node_modules_babel_runtime_helpers_esm_classCallCheck_js__WEBPACK_IMPORTED_MODULE_0__["default"])(this, TransportStatComponent);

    this.campaignService = campaignService;
    this.reportController = reportController;
    this.personalCampaign$ = this.campaignService.getPersonalCampaign();
    this.personalStat$ = this.personalCampaign$.pipe((0,rxjs__WEBPACK_IMPORTED_MODULE_9__.switchMap)(function (personalCampaign) {
      var _a;

      return _this.reportController.getPlayerTransportStatsGroupByMeanUsingGET({
        campaignId: (_a = personalCampaign === null || personalCampaign === void 0 ? void 0 : personalCampaign.campaign) === null || _a === void 0 ? void 0 : _a.campaignId,
        playerId: _this.playerId,
        metric: 'km',
        dateFrom: (0,src_app_core_shared_time_utils__WEBPACK_IMPORTED_MODULE_2__.toServerDateOnly)(luxon__WEBPACK_IMPORTED_MODULE_3__.DateTime.utc().minus({
          month: 1
        })),
        dateTo: (0,src_app_core_shared_time_utils__WEBPACK_IMPORTED_MODULE_2__.toServerDateOnly)(luxon__WEBPACK_IMPORTED_MODULE_3__.DateTime.utc())
      });
    }), (0,rxjs__WEBPACK_IMPORTED_MODULE_10__.shareReplay)(1));
  }

  (0,_Users_smartcommunitylab_Desktop_newWork_dslab_playgo_mobile_playgo_mobile_node_modules_babel_runtime_helpers_esm_createClass_js__WEBPACK_IMPORTED_MODULE_1__["default"])(TransportStatComponent, [{
    key: "ngOnInit",
    value: function ngOnInit() {}
  }]);

  return TransportStatComponent;
}();

TransportStatComponent.ɵfac = function TransportStatComponent_Factory(t) {
  return new (t || TransportStatComponent)(_angular_core__WEBPACK_IMPORTED_MODULE_8__["ɵɵdirectiveInject"](src_app_core_shared_services_campaign_service__WEBPACK_IMPORTED_MODULE_4__.CampaignService), _angular_core__WEBPACK_IMPORTED_MODULE_8__["ɵɵdirectiveInject"](src_app_core_api_generated_controllers_reportController_service__WEBPACK_IMPORTED_MODULE_5__.ReportControllerService));
};

TransportStatComponent.ɵcmp = /*@__PURE__*/_angular_core__WEBPACK_IMPORTED_MODULE_8__["ɵɵdefineComponent"]({
  type: TransportStatComponent,
  selectors: [["app-transport-stat"]],
  inputs: {
    playerId: "playerId"
  },
  decls: 11,
  vars: 7,
  consts: [["color", "personal"], [4, "ngIf", "ngIfElse"], ["emptyStat", ""], ["size", "6", 4, "ngFor", "ngForOf"], ["size", "6"], [1, "icon-size-normal", 3, "name"], [1, "empty-stats"]],
  template: function TransportStatComponent_Template(rf, ctx) {
    if (rf & 1) {
      _angular_core__WEBPACK_IMPORTED_MODULE_8__["ɵɵelementStart"](0, "ion-card")(1, "ion-card-header", 0);
      _angular_core__WEBPACK_IMPORTED_MODULE_8__["ɵɵtext"](2);
      _angular_core__WEBPACK_IMPORTED_MODULE_8__["ɵɵpipe"](3, "translate");
      _angular_core__WEBPACK_IMPORTED_MODULE_8__["ɵɵelementEnd"]();
      _angular_core__WEBPACK_IMPORTED_MODULE_8__["ɵɵelementStart"](4, "ion-card-content")(5, "ion-grid")(6, "ion-row");
      _angular_core__WEBPACK_IMPORTED_MODULE_8__["ɵɵtemplate"](7, TransportStatComponent_ng_container_7_Template, 3, 3, "ng-container", 1);
      _angular_core__WEBPACK_IMPORTED_MODULE_8__["ɵɵpipe"](8, "async");
      _angular_core__WEBPACK_IMPORTED_MODULE_8__["ɵɵtemplate"](9, TransportStatComponent_ng_template_9_Template, 4, 3, "ng-template", null, 2, _angular_core__WEBPACK_IMPORTED_MODULE_8__["ɵɵtemplateRefExtractor"]);
      _angular_core__WEBPACK_IMPORTED_MODULE_8__["ɵɵelementEnd"]()()()();
    }

    if (rf & 2) {
      var _r1 = _angular_core__WEBPACK_IMPORTED_MODULE_8__["ɵɵreference"](10);

      var tmp_1_0;
      _angular_core__WEBPACK_IMPORTED_MODULE_8__["ɵɵadvance"](2);
      _angular_core__WEBPACK_IMPORTED_MODULE_8__["ɵɵtextInterpolate1"](" ", _angular_core__WEBPACK_IMPORTED_MODULE_8__["ɵɵpipeBind1"](3, 3, "userprofile.last_month"), "");
      _angular_core__WEBPACK_IMPORTED_MODULE_8__["ɵɵadvance"](5);
      _angular_core__WEBPACK_IMPORTED_MODULE_8__["ɵɵproperty"]("ngIf", ((tmp_1_0 = _angular_core__WEBPACK_IMPORTED_MODULE_8__["ɵɵpipeBind1"](8, 5, ctx.personalStat$)) == null ? null : tmp_1_0.length) > 0)("ngIfElse", _r1);
    }
  },
  directives: [_ionic_angular__WEBPACK_IMPORTED_MODULE_11__.IonCard, _ionic_angular__WEBPACK_IMPORTED_MODULE_11__.IonCardHeader, _ionic_angular__WEBPACK_IMPORTED_MODULE_11__.IonCardContent, _ionic_angular__WEBPACK_IMPORTED_MODULE_11__.IonGrid, _ionic_angular__WEBPACK_IMPORTED_MODULE_11__.IonRow, _angular_common__WEBPACK_IMPORTED_MODULE_12__.NgIf, _angular_common__WEBPACK_IMPORTED_MODULE_12__.NgForOf, _ionic_angular__WEBPACK_IMPORTED_MODULE_11__.IonCol, _core_shared_ui_icon_icon_component__WEBPACK_IMPORTED_MODULE_6__.IconComponent],
  pipes: [_ngx_translate_core__WEBPACK_IMPORTED_MODULE_13__.TranslatePipe, _angular_common__WEBPACK_IMPORTED_MODULE_12__.AsyncPipe, _core_shared_pipes_localNumber_pipe__WEBPACK_IMPORTED_MODULE_7__.LocalNumberPipe],
  styles: ["ion-card[_ngcontent-%COMP%] {\n  color: var(--dark-grey);\n}\nion-card[_ngcontent-%COMP%]   ion-card-content[_ngcontent-%COMP%] {\n  font-size: 13px;\n}\nion-card[_ngcontent-%COMP%]   ion-card-header[_ngcontent-%COMP%] {\n  height: 21px;\n  display: flex;\n  justify-content: space-around;\n  flex-direction: column;\n  font-weight: 600;\n  font-size: 13px;\n  font-style: italic;\n}\nion-card[_ngcontent-%COMP%]   app-icon[_ngcontent-%COMP%] {\n  margin-right: 11px;\n}\nion-card[_ngcontent-%COMP%]   ion-col[_ngcontent-%COMP%] {\n  display: flex;\n  align-items: center !important;\n}\nion-card[_ngcontent-%COMP%]   .empty-stats[_ngcontent-%COMP%] {\n  margin: auto;\n  padding: 8px;\n  font-size: 20px;\n  text-align: center;\n  -ms-transform: translateY(-50%);\n}\n/*# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbInRyYW5zcG9ydC1zdGF0LmNvbXBvbmVudC5zY3NzIl0sIm5hbWVzIjpbXSwibWFwcGluZ3MiOiJBQUFBO0VBQ0UsdUJBQUE7QUFDRjtBQUFFO0VBQ0UsZUFBQTtBQUVKO0FBQUU7RUFDRSxZQUFBO0VBQ0EsYUFBQTtFQUNBLDZCQUFBO0VBQ0Esc0JBQUE7RUFDQSxnQkFBQTtFQUNBLGVBQUE7RUFDQSxrQkFBQTtBQUVKO0FBQUU7RUFDRSxrQkFBQTtBQUVKO0FBQUU7RUFDRSxhQUFBO0VBQ0EsOEJBQUE7QUFFSjtBQUFFO0VBQ0UsWUFBQTtFQUNBLFlBQUE7RUFDQSxlQUFBO0VBQ0Esa0JBQUE7RUFDQSwrQkFBQTtBQUVKIiwiZmlsZSI6InRyYW5zcG9ydC1zdGF0LmNvbXBvbmVudC5zY3NzIiwic291cmNlc0NvbnRlbnQiOlsiaW9uLWNhcmQge1xuICBjb2xvcjogdmFyKC0tZGFyay1ncmV5KTtcbiAgaW9uLWNhcmQtY29udGVudCB7XG4gICAgZm9udC1zaXplOiAxM3B4O1xuICB9XG4gIGlvbi1jYXJkLWhlYWRlciB7XG4gICAgaGVpZ2h0OiAyMXB4O1xuICAgIGRpc3BsYXk6IGZsZXg7XG4gICAganVzdGlmeS1jb250ZW50OiBzcGFjZS1hcm91bmQ7XG4gICAgZmxleC1kaXJlY3Rpb246IGNvbHVtbjtcbiAgICBmb250LXdlaWdodDogNjAwO1xuICAgIGZvbnQtc2l6ZTogMTNweDtcbiAgICBmb250LXN0eWxlOiBpdGFsaWM7XG4gIH1cbiAgYXBwLWljb24ge1xuICAgIG1hcmdpbi1yaWdodDogMTFweDtcbiAgfVxuICBpb24tY29sIHtcbiAgICBkaXNwbGF5OiBmbGV4O1xuICAgIGFsaWduLWl0ZW1zOiBjZW50ZXIgIWltcG9ydGFudDtcbiAgfVxuICAuZW1wdHktc3RhdHMge1xuICAgIG1hcmdpbjogYXV0bztcbiAgICBwYWRkaW5nOiA4cHg7XG4gICAgZm9udC1zaXplOiAyMHB4O1xuICAgIHRleHQtYWxpZ246IGNlbnRlcjtcbiAgICAtbXMtdHJhbnNmb3JtOiB0cmFuc2xhdGVZKC01MCUpO1xuICB9XG59XG4iXX0= */"]
});

/***/ }),

/***/ 23376:
/*!*******************************************************************!*\
  !*** ./src/app/pages/user-profile/user-profile-routing.module.ts ***!
  \*******************************************************************/
/***/ (function(__unused_webpack_module, __webpack_exports__, __webpack_require__) {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "UserProfilePageRoutingModule": function() { return /* binding */ UserProfilePageRoutingModule; }
/* harmony export */ });
/* harmony import */ var _Users_smartcommunitylab_Desktop_newWork_dslab_playgo_mobile_playgo_mobile_node_modules_babel_runtime_helpers_esm_createClass_js__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./node_modules/@babel/runtime/helpers/esm/createClass.js */ 48047);
/* harmony import */ var _Users_smartcommunitylab_Desktop_newWork_dslab_playgo_mobile_playgo_mobile_node_modules_babel_runtime_helpers_esm_classCallCheck_js__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ./node_modules/@babel/runtime/helpers/esm/classCallCheck.js */ 78069);
/* harmony import */ var _angular_router__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! @angular/router */ 52816);
/* harmony import */ var _user_profile_page__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! ./user-profile.page */ 41553);
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @angular/core */ 3184);






var routes = [{
  path: '',
  component: _user_profile_page__WEBPACK_IMPORTED_MODULE_2__.UserProfilePage,
  data: {
    title: 'userprofile.title',
    customHeader: true
  }
}];
var UserProfilePageRoutingModule = /*#__PURE__*/(0,_Users_smartcommunitylab_Desktop_newWork_dslab_playgo_mobile_playgo_mobile_node_modules_babel_runtime_helpers_esm_createClass_js__WEBPACK_IMPORTED_MODULE_0__["default"])(function UserProfilePageRoutingModule() {
  (0,_Users_smartcommunitylab_Desktop_newWork_dslab_playgo_mobile_playgo_mobile_node_modules_babel_runtime_helpers_esm_classCallCheck_js__WEBPACK_IMPORTED_MODULE_1__["default"])(this, UserProfilePageRoutingModule);
});

UserProfilePageRoutingModule.ɵfac = function UserProfilePageRoutingModule_Factory(t) {
  return new (t || UserProfilePageRoutingModule)();
};

UserProfilePageRoutingModule.ɵmod = /*@__PURE__*/_angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵdefineNgModule"]({
  type: UserProfilePageRoutingModule
});
UserProfilePageRoutingModule.ɵinj = /*@__PURE__*/_angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵdefineInjector"]({
  imports: [[_angular_router__WEBPACK_IMPORTED_MODULE_4__.RouterModule.forChild(routes)], _angular_router__WEBPACK_IMPORTED_MODULE_4__.RouterModule]
});

(function () {
  (typeof ngJitMode === "undefined" || ngJitMode) && _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵsetNgModuleScope"](UserProfilePageRoutingModule, {
    imports: [_angular_router__WEBPACK_IMPORTED_MODULE_4__.RouterModule],
    exports: [_angular_router__WEBPACK_IMPORTED_MODULE_4__.RouterModule]
  });
})();

/***/ }),

/***/ 71749:
/*!***********************************************************!*\
  !*** ./src/app/pages/user-profile/user-profile.module.ts ***!
  \***********************************************************/
/***/ (function(__unused_webpack_module, __webpack_exports__, __webpack_require__) {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "UserProfilePageModule": function() { return /* binding */ UserProfilePageModule; }
/* harmony export */ });
/* harmony import */ var _Users_smartcommunitylab_Desktop_newWork_dslab_playgo_mobile_playgo_mobile_node_modules_babel_runtime_helpers_esm_createClass_js__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./node_modules/@babel/runtime/helpers/esm/createClass.js */ 48047);
/* harmony import */ var _Users_smartcommunitylab_Desktop_newWork_dslab_playgo_mobile_playgo_mobile_node_modules_babel_runtime_helpers_esm_classCallCheck_js__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ./node_modules/@babel/runtime/helpers/esm/classCallCheck.js */ 78069);
/* harmony import */ var _user_profile_routing_module__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! ./user-profile-routing.module */ 23376);
/* harmony import */ var _user_profile_page__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! ./user-profile.page */ 41553);
/* harmony import */ var src_app_core_shared_shared_module__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! src/app/core/shared/shared.module */ 97205);
/* harmony import */ var _transport_stat_transport_stat_component__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! ./transport-stat/transport-stat.component */ 2731);
/* harmony import */ var _campaign_stat_campaign_stat_component__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! ./campaign-stat/campaign-stat.component */ 25373);
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(/*! @angular/core */ 3184);








var UserProfilePageModule = /*#__PURE__*/(0,_Users_smartcommunitylab_Desktop_newWork_dslab_playgo_mobile_playgo_mobile_node_modules_babel_runtime_helpers_esm_createClass_js__WEBPACK_IMPORTED_MODULE_0__["default"])(function UserProfilePageModule() {
  (0,_Users_smartcommunitylab_Desktop_newWork_dslab_playgo_mobile_playgo_mobile_node_modules_babel_runtime_helpers_esm_classCallCheck_js__WEBPACK_IMPORTED_MODULE_1__["default"])(this, UserProfilePageModule);
});

UserProfilePageModule.ɵfac = function UserProfilePageModule_Factory(t) {
  return new (t || UserProfilePageModule)();
};

UserProfilePageModule.ɵmod = /*@__PURE__*/_angular_core__WEBPACK_IMPORTED_MODULE_7__["ɵɵdefineNgModule"]({
  type: UserProfilePageModule
});
UserProfilePageModule.ɵinj = /*@__PURE__*/_angular_core__WEBPACK_IMPORTED_MODULE_7__["ɵɵdefineInjector"]({
  imports: [[src_app_core_shared_shared_module__WEBPACK_IMPORTED_MODULE_4__.PlayGoSharedModule, _user_profile_routing_module__WEBPACK_IMPORTED_MODULE_2__.UserProfilePageRoutingModule]]
});

(function () {
  (typeof ngJitMode === "undefined" || ngJitMode) && _angular_core__WEBPACK_IMPORTED_MODULE_7__["ɵɵsetNgModuleScope"](UserProfilePageModule, {
    declarations: [_user_profile_page__WEBPACK_IMPORTED_MODULE_3__.UserProfilePage, _transport_stat_transport_stat_component__WEBPACK_IMPORTED_MODULE_5__.TransportStatComponent, _campaign_stat_campaign_stat_component__WEBPACK_IMPORTED_MODULE_6__.CampaignStatComponent],
    imports: [src_app_core_shared_shared_module__WEBPACK_IMPORTED_MODULE_4__.PlayGoSharedModule, _user_profile_routing_module__WEBPACK_IMPORTED_MODULE_2__.UserProfilePageRoutingModule]
  });
})();

/***/ }),

/***/ 41553:
/*!*********************************************************!*\
  !*** ./src/app/pages/user-profile/user-profile.page.ts ***!
  \*********************************************************/
/***/ (function(__unused_webpack_module, __webpack_exports__, __webpack_require__) {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "UserProfilePage": function() { return /* binding */ UserProfilePage; }
/* harmony export */ });
/* harmony import */ var _Users_smartcommunitylab_Desktop_newWork_dslab_playgo_mobile_playgo_mobile_node_modules_babel_runtime_helpers_esm_slicedToArray_js__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./node_modules/@babel/runtime/helpers/esm/slicedToArray.js */ 10507);
/* harmony import */ var _Users_smartcommunitylab_Desktop_newWork_dslab_playgo_mobile_playgo_mobile_node_modules_babel_runtime_helpers_esm_classCallCheck_js__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ./node_modules/@babel/runtime/helpers/esm/classCallCheck.js */ 78069);
/* harmony import */ var _Users_smartcommunitylab_Desktop_newWork_dslab_playgo_mobile_playgo_mobile_node_modules_babel_runtime_helpers_esm_createClass_js__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! ./node_modules/@babel/runtime/helpers/esm/createClass.js */ 48047);
/* harmony import */ var rxjs__WEBPACK_IMPORTED_MODULE_12__ = __webpack_require__(/*! rxjs */ 50635);
/* harmony import */ var rxjs__WEBPACK_IMPORTED_MODULE_13__ = __webpack_require__(/*! rxjs */ 98977);
/* harmony import */ var rxjs__WEBPACK_IMPORTED_MODULE_14__ = __webpack_require__(/*! rxjs */ 89196);
/* harmony import */ var rxjs__WEBPACK_IMPORTED_MODULE_15__ = __webpack_require__(/*! rxjs */ 32673);
/* harmony import */ var rxjs__WEBPACK_IMPORTED_MODULE_16__ = __webpack_require__(/*! rxjs */ 26562);
/* harmony import */ var rxjs__WEBPACK_IMPORTED_MODULE_19__ = __webpack_require__(/*! rxjs */ 19337);
/* harmony import */ var lodash_es__WEBPACK_IMPORTED_MODULE_17__ = __webpack_require__(/*! lodash-es */ 71156);
/* harmony import */ var lodash_es__WEBPACK_IMPORTED_MODULE_18__ = __webpack_require__(/*! lodash-es */ 63247);
/* harmony import */ var src_app_core_shared_rxjs_utils__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! src/app/core/shared/rxjs.utils */ 9257);
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_11__ = __webpack_require__(/*! @angular/core */ 3184);
/* harmony import */ var _angular_router__WEBPACK_IMPORTED_MODULE_20__ = __webpack_require__(/*! @angular/router */ 52816);
/* harmony import */ var src_app_core_shared_services_error_service__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! src/app/core/shared/services/error.service */ 96204);
/* harmony import */ var src_app_core_shared_services_user_service__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! src/app/core/shared/services/user.service */ 50749);
/* harmony import */ var src_app_core_shared_services_campaign_service__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! src/app/core/shared/services/campaign.service */ 23645);
/* harmony import */ var _ionic_angular__WEBPACK_IMPORTED_MODULE_21__ = __webpack_require__(/*! @ionic/angular */ 93819);
/* harmony import */ var _core_shared_layout_header_header_directive__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(/*! ../../core/shared/layout/header/header.directive */ 34161);
/* harmony import */ var _core_shared_layout_content_content_directive__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(/*! ../../core/shared/layout/content/content.directive */ 69669);
/* harmony import */ var _transport_stat_transport_stat_component__WEBPACK_IMPORTED_MODULE_9__ = __webpack_require__(/*! ./transport-stat/transport-stat.component */ 2731);
/* harmony import */ var _angular_common__WEBPACK_IMPORTED_MODULE_22__ = __webpack_require__(/*! @angular/common */ 36362);
/* harmony import */ var _campaign_stat_campaign_stat_component__WEBPACK_IMPORTED_MODULE_10__ = __webpack_require__(/*! ./campaign-stat/campaign-stat.component */ 25373);


















function UserProfilePage_ng_container_11_Template(rf, ctx) {
  if (rf & 1) {
    _angular_core__WEBPACK_IMPORTED_MODULE_11__["ɵɵelementContainerStart"](0);
    _angular_core__WEBPACK_IMPORTED_MODULE_11__["ɵɵelement"](1, "app-campaign-stat", 7);
    _angular_core__WEBPACK_IMPORTED_MODULE_11__["ɵɵpipe"](2, "async");
    _angular_core__WEBPACK_IMPORTED_MODULE_11__["ɵɵelementContainerEnd"]();
  }

  if (rf & 2) {
    var campaign_r1 = ctx.$implicit;
    var ctx_r0 = _angular_core__WEBPACK_IMPORTED_MODULE_11__["ɵɵnextContext"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_11__["ɵɵadvance"](1);
    _angular_core__WEBPACK_IMPORTED_MODULE_11__["ɵɵproperty"]("playerId", _angular_core__WEBPACK_IMPORTED_MODULE_11__["ɵɵpipeBind1"](2, 2, ctx_r0.userId$))("campaign", campaign_r1);
  }
}

var UserProfilePage = /*#__PURE__*/function () {
  // public campaigns: PlayerCampaign[] = [];
  function UserProfilePage(route, errorService, userService, campaignService) {
    var _this = this;

    (0,_Users_smartcommunitylab_Desktop_newWork_dslab_playgo_mobile_playgo_mobile_node_modules_babel_runtime_helpers_esm_classCallCheck_js__WEBPACK_IMPORTED_MODULE_1__["default"])(this, UserProfilePage);

    this.route = route;
    this.errorService = errorService;
    this.userService = userService;
    this.campaignService = campaignService;
    this.userId$ = this.route.params.pipe((0,rxjs__WEBPACK_IMPORTED_MODULE_12__.map)(function (params) {
      return params.id;
    }), (0,rxjs__WEBPACK_IMPORTED_MODULE_13__.distinctUntilChanged)(), (0,rxjs__WEBPACK_IMPORTED_MODULE_14__.shareReplay)(1));
    this.userNickname$ = this.route.params.pipe((0,rxjs__WEBPACK_IMPORTED_MODULE_12__.map)(function (params) {
      return params.nickname;
    }), (0,rxjs__WEBPACK_IMPORTED_MODULE_13__.distinctUntilChanged)(), (0,rxjs__WEBPACK_IMPORTED_MODULE_14__.shareReplay)(1));
    this.userAvatar$ = this.userId$.pipe((0,rxjs__WEBPACK_IMPORTED_MODULE_15__.switchMap)(function (userId) {
      return _this.userService.getOtherPlayerAvatar(userId).pipe(_this.errorService.getErrorHandler());
    }), (0,rxjs__WEBPACK_IMPORTED_MODULE_14__.shareReplay)(1));
    this.campaigns$ = (0,rxjs__WEBPACK_IMPORTED_MODULE_16__.combineLatest)([this.userId$, this.campaignService.myCampaigns$]).pipe((0,rxjs__WEBPACK_IMPORTED_MODULE_15__.switchMap)(function (_ref) {
      var _ref2 = (0,_Users_smartcommunitylab_Desktop_newWork_dslab_playgo_mobile_playgo_mobile_node_modules_babel_runtime_helpers_esm_slicedToArray_js__WEBPACK_IMPORTED_MODULE_0__["default"])(_ref, 2),
          userId = _ref2[0],
          myCampaigns = _ref2[1];

      return _this.campaignService.getCampaignByPlayerId(userId).pipe((0,src_app_core_shared_rxjs_utils__WEBPACK_IMPORTED_MODULE_3__.tapLog)('Initial Campaign'), (0,rxjs__WEBPACK_IMPORTED_MODULE_12__.map)( //filter my campaigns in order to have only common campaigns
      function (otherUserCampaigns) {
        var intersection = (0,lodash_es__WEBPACK_IMPORTED_MODULE_17__["default"])(otherUserCampaigns.map(function (campaign) {
          return campaign.campaignId;
        }), myCampaigns.map(function (campaign) {
          return campaign.campaign.campaignId;
        }), lodash_es__WEBPACK_IMPORTED_MODULE_18__["default"]);
        return otherUserCampaigns.filter(function (campaign) {
          return intersection.includes(campaign.campaignId) && campaign.type !== 'personal' && campaign.type !== 'company';
        });
      }), (0,src_app_core_shared_rxjs_utils__WEBPACK_IMPORTED_MODULE_3__.tapLog)('filteredcampaign'), ////filter personal campaign and campaigns without challenge 'personal' && 'company'
      _this.errorService.getErrorHandler());
    }), (0,rxjs__WEBPACK_IMPORTED_MODULE_19__.tap)(function (campaigns) {
      return console.log(campaigns);
    }), (0,rxjs__WEBPACK_IMPORTED_MODULE_14__.shareReplay)(1));
  }

  (0,_Users_smartcommunitylab_Desktop_newWork_dslab_playgo_mobile_playgo_mobile_node_modules_babel_runtime_helpers_esm_createClass_js__WEBPACK_IMPORTED_MODULE_2__["default"])(UserProfilePage, [{
    key: "ngOnInit",
    value: function ngOnInit() {}
  }]);

  return UserProfilePage;
}();

UserProfilePage.ɵfac = function UserProfilePage_Factory(t) {
  return new (t || UserProfilePage)(_angular_core__WEBPACK_IMPORTED_MODULE_11__["ɵɵdirectiveInject"](_angular_router__WEBPACK_IMPORTED_MODULE_20__.ActivatedRoute), _angular_core__WEBPACK_IMPORTED_MODULE_11__["ɵɵdirectiveInject"](src_app_core_shared_services_error_service__WEBPACK_IMPORTED_MODULE_4__.ErrorService), _angular_core__WEBPACK_IMPORTED_MODULE_11__["ɵɵdirectiveInject"](src_app_core_shared_services_user_service__WEBPACK_IMPORTED_MODULE_5__.UserService), _angular_core__WEBPACK_IMPORTED_MODULE_11__["ɵɵdirectiveInject"](src_app_core_shared_services_campaign_service__WEBPACK_IMPORTED_MODULE_6__.CampaignService));
};

UserProfilePage.ɵcmp = /*@__PURE__*/_angular_core__WEBPACK_IMPORTED_MODULE_11__["ɵɵdefineComponent"]({
  type: UserProfilePage,
  selectors: [["app-user-profile"]],
  decls: 13,
  vars: 13,
  consts: [["appHeader", ""], ["appContent", "", 3, "fullscreen"], [1, "user-intro"], [3, "src"], [1, "nickname"], [3, "playerId"], [4, "ngFor", "ngForOf"], [3, "playerId", "campaign"]],
  template: function UserProfilePage_Template(rf, ctx) {
    if (rf & 1) {
      _angular_core__WEBPACK_IMPORTED_MODULE_11__["ɵɵelement"](0, "ion-header", 0);
      _angular_core__WEBPACK_IMPORTED_MODULE_11__["ɵɵelementStart"](1, "ion-content", 1)(2, "div", 2)(3, "ion-avatar");
      _angular_core__WEBPACK_IMPORTED_MODULE_11__["ɵɵelement"](4, "img", 3);
      _angular_core__WEBPACK_IMPORTED_MODULE_11__["ɵɵpipe"](5, "async");
      _angular_core__WEBPACK_IMPORTED_MODULE_11__["ɵɵelementEnd"]();
      _angular_core__WEBPACK_IMPORTED_MODULE_11__["ɵɵelementStart"](6, "div", 4);
      _angular_core__WEBPACK_IMPORTED_MODULE_11__["ɵɵtext"](7);
      _angular_core__WEBPACK_IMPORTED_MODULE_11__["ɵɵpipe"](8, "async");
      _angular_core__WEBPACK_IMPORTED_MODULE_11__["ɵɵelementEnd"]()();
      _angular_core__WEBPACK_IMPORTED_MODULE_11__["ɵɵelement"](9, "app-transport-stat", 5);
      _angular_core__WEBPACK_IMPORTED_MODULE_11__["ɵɵpipe"](10, "async");
      _angular_core__WEBPACK_IMPORTED_MODULE_11__["ɵɵtemplate"](11, UserProfilePage_ng_container_11_Template, 3, 4, "ng-container", 6);
      _angular_core__WEBPACK_IMPORTED_MODULE_11__["ɵɵpipe"](12, "async");
      _angular_core__WEBPACK_IMPORTED_MODULE_11__["ɵɵelementEnd"]();
    }

    if (rf & 2) {
      var tmp_1_0;
      _angular_core__WEBPACK_IMPORTED_MODULE_11__["ɵɵadvance"](1);
      _angular_core__WEBPACK_IMPORTED_MODULE_11__["ɵɵproperty"]("fullscreen", true);
      _angular_core__WEBPACK_IMPORTED_MODULE_11__["ɵɵadvance"](3);
      _angular_core__WEBPACK_IMPORTED_MODULE_11__["ɵɵproperty"]("src", (tmp_1_0 = _angular_core__WEBPACK_IMPORTED_MODULE_11__["ɵɵpipeBind1"](5, 5, ctx.userAvatar$)) == null ? null : tmp_1_0.avatarUrl, _angular_core__WEBPACK_IMPORTED_MODULE_11__["ɵɵsanitizeUrl"]);
      _angular_core__WEBPACK_IMPORTED_MODULE_11__["ɵɵadvance"](3);
      _angular_core__WEBPACK_IMPORTED_MODULE_11__["ɵɵtextInterpolate"](_angular_core__WEBPACK_IMPORTED_MODULE_11__["ɵɵpipeBind1"](8, 7, ctx.userNickname$));
      _angular_core__WEBPACK_IMPORTED_MODULE_11__["ɵɵadvance"](2);
      _angular_core__WEBPACK_IMPORTED_MODULE_11__["ɵɵproperty"]("playerId", _angular_core__WEBPACK_IMPORTED_MODULE_11__["ɵɵpipeBind1"](10, 9, ctx.userId$));
      _angular_core__WEBPACK_IMPORTED_MODULE_11__["ɵɵadvance"](2);
      _angular_core__WEBPACK_IMPORTED_MODULE_11__["ɵɵproperty"]("ngForOf", _angular_core__WEBPACK_IMPORTED_MODULE_11__["ɵɵpipeBind1"](12, 11, ctx.campaigns$));
    }
  },
  directives: [_ionic_angular__WEBPACK_IMPORTED_MODULE_21__.IonHeader, _core_shared_layout_header_header_directive__WEBPACK_IMPORTED_MODULE_7__.HeaderDirective, _ionic_angular__WEBPACK_IMPORTED_MODULE_21__.IonContent, _core_shared_layout_content_content_directive__WEBPACK_IMPORTED_MODULE_8__.ContentDirective, _ionic_angular__WEBPACK_IMPORTED_MODULE_21__.IonAvatar, _transport_stat_transport_stat_component__WEBPACK_IMPORTED_MODULE_9__.TransportStatComponent, _angular_common__WEBPACK_IMPORTED_MODULE_22__.NgForOf, _campaign_stat_campaign_stat_component__WEBPACK_IMPORTED_MODULE_10__.CampaignStatComponent],
  pipes: [_angular_common__WEBPACK_IMPORTED_MODULE_22__.AsyncPipe],
  styles: [".user-intro[_ngcontent-%COMP%] {\n  text-align: center;\n  margin: 52px auto;\n  width: 124px;\n  height: 124px;\n}\n.user-intro[_ngcontent-%COMP%]   ion-avatar[_ngcontent-%COMP%] {\n  margin: auto;\n  height: 102px;\n  width: 102px;\n}\n.user-intro[_ngcontent-%COMP%]   .nickname[_ngcontent-%COMP%] {\n  margin-top: 32px;\n  font-weight: 600;\n  font-size: 18px;\n}\n/*# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbInVzZXItcHJvZmlsZS5wYWdlLnNjc3MiXSwibmFtZXMiOltdLCJtYXBwaW5ncyI6IkFBQUE7RUFDRSxrQkFBQTtFQUNBLGlCQUFBO0VBQ0EsWUFBQTtFQUNBLGFBQUE7QUFDRjtBQUFFO0VBQ0UsWUFBQTtFQUNBLGFBQUE7RUFDQSxZQUFBO0FBRUo7QUFBRTtFQUNFLGdCQUFBO0VBQ0EsZ0JBQUE7RUFDQSxlQUFBO0FBRUoiLCJmaWxlIjoidXNlci1wcm9maWxlLnBhZ2Uuc2NzcyIsInNvdXJjZXNDb250ZW50IjpbIi51c2VyLWludHJvIHtcbiAgdGV4dC1hbGlnbjogY2VudGVyO1xuICBtYXJnaW46IDUycHggYXV0bztcbiAgd2lkdGg6IDEyNHB4O1xuICBoZWlnaHQ6IDEyNHB4O1xuICBpb24tYXZhdGFyIHtcbiAgICBtYXJnaW46IGF1dG87XG4gICAgaGVpZ2h0OiAxMDJweDtcbiAgICB3aWR0aDogMTAycHg7XG4gIH1cbiAgLm5pY2tuYW1lIHtcbiAgICBtYXJnaW4tdG9wOiAzMnB4O1xuICAgIGZvbnQtd2VpZ2h0OiA2MDA7XG4gICAgZm9udC1zaXplOiAxOHB4O1xuICB9XG59XG4iXX0= */"]
});

/***/ }),

/***/ 79637:
/*!**************************************************!*\
  !*** ./node_modules/lodash-es/_arrayIncludes.js ***!
  \**************************************************/
/***/ (function(__unused_webpack___webpack_module__, __webpack_exports__, __webpack_require__) {

__webpack_require__.r(__webpack_exports__);
/* harmony import */ var _baseIndexOf_js__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./_baseIndexOf.js */ 81944);

/**
 * A specialized version of `_.includes` for arrays without support for
 * specifying an index to search from.
 *
 * @private
 * @param {Array} [array] The array to inspect.
 * @param {*} target The value to search for.
 * @returns {boolean} Returns `true` if `target` is found, else `false`.
 */

function arrayIncludes(array, value) {
  var length = array == null ? 0 : array.length;
  return !!length && (0,_baseIndexOf_js__WEBPACK_IMPORTED_MODULE_0__["default"])(array, value, 0) > -1;
}

/* harmony default export */ __webpack_exports__["default"] = (arrayIncludes);

/***/ }),

/***/ 54540:
/*!******************************************************!*\
  !*** ./node_modules/lodash-es/_arrayIncludesWith.js ***!
  \******************************************************/
/***/ (function(__unused_webpack___webpack_module__, __webpack_exports__, __webpack_require__) {

__webpack_require__.r(__webpack_exports__);
/**
 * This function is like `arrayIncludes` except that it accepts a comparator.
 *
 * @private
 * @param {Array} [array] The array to inspect.
 * @param {*} target The value to search for.
 * @param {Function} comparator The comparator invoked per element.
 * @returns {boolean} Returns `true` if `target` is found, else `false`.
 */
function arrayIncludesWith(array, value, comparator) {
  var index = -1,
      length = array == null ? 0 : array.length;

  while (++index < length) {
    if (comparator(value, array[index])) {
      return true;
    }
  }

  return false;
}

/* harmony default export */ __webpack_exports__["default"] = (arrayIncludesWith);

/***/ }),

/***/ 81944:
/*!************************************************!*\
  !*** ./node_modules/lodash-es/_baseIndexOf.js ***!
  \************************************************/
/***/ (function(__unused_webpack___webpack_module__, __webpack_exports__, __webpack_require__) {

__webpack_require__.r(__webpack_exports__);
/* harmony import */ var _baseFindIndex_js__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ./_baseFindIndex.js */ 19402);
/* harmony import */ var _baseIsNaN_js__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! ./_baseIsNaN.js */ 43876);
/* harmony import */ var _strictIndexOf_js__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./_strictIndexOf.js */ 35161);



/**
 * The base implementation of `_.indexOf` without `fromIndex` bounds checks.
 *
 * @private
 * @param {Array} array The array to inspect.
 * @param {*} value The value to search for.
 * @param {number} fromIndex The index to search from.
 * @returns {number} Returns the index of the matched value, else `-1`.
 */

function baseIndexOf(array, value, fromIndex) {
  return value === value ? (0,_strictIndexOf_js__WEBPACK_IMPORTED_MODULE_0__["default"])(array, value, fromIndex) : (0,_baseFindIndex_js__WEBPACK_IMPORTED_MODULE_1__["default"])(array, _baseIsNaN_js__WEBPACK_IMPORTED_MODULE_2__["default"], fromIndex);
}

/* harmony default export */ __webpack_exports__["default"] = (baseIndexOf);

/***/ }),

/***/ 49089:
/*!*****************************************************!*\
  !*** ./node_modules/lodash-es/_baseIntersection.js ***!
  \*****************************************************/
/***/ (function(__unused_webpack___webpack_module__, __webpack_exports__, __webpack_require__) {

__webpack_require__.r(__webpack_exports__);
/* harmony import */ var _SetCache_js__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! ./_SetCache.js */ 85675);
/* harmony import */ var _arrayIncludes_js__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ./_arrayIncludes.js */ 79637);
/* harmony import */ var _arrayIncludesWith_js__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./_arrayIncludesWith.js */ 54540);
/* harmony import */ var _arrayMap_js__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! ./_arrayMap.js */ 66717);
/* harmony import */ var _baseUnary_js__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! ./_baseUnary.js */ 7560);
/* harmony import */ var _cacheHas_js__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! ./_cacheHas.js */ 36149);






/* Built-in method references for those with the same name as other `lodash` methods. */

var nativeMin = Math.min;
/**
 * The base implementation of methods like `_.intersection`, without support
 * for iteratee shorthands, that accepts an array of arrays to inspect.
 *
 * @private
 * @param {Array} arrays The arrays to inspect.
 * @param {Function} [iteratee] The iteratee invoked per element.
 * @param {Function} [comparator] The comparator invoked per element.
 * @returns {Array} Returns the new array of shared values.
 */

function baseIntersection(arrays, iteratee, comparator) {
  var includes = comparator ? _arrayIncludesWith_js__WEBPACK_IMPORTED_MODULE_0__["default"] : _arrayIncludes_js__WEBPACK_IMPORTED_MODULE_1__["default"],
      length = arrays[0].length,
      othLength = arrays.length,
      othIndex = othLength,
      caches = Array(othLength),
      maxLength = Infinity,
      result = [];

  while (othIndex--) {
    var array = arrays[othIndex];

    if (othIndex && iteratee) {
      array = (0,_arrayMap_js__WEBPACK_IMPORTED_MODULE_2__["default"])(array, (0,_baseUnary_js__WEBPACK_IMPORTED_MODULE_3__["default"])(iteratee));
    }

    maxLength = nativeMin(array.length, maxLength);
    caches[othIndex] = !comparator && (iteratee || length >= 120 && array.length >= 120) ? new _SetCache_js__WEBPACK_IMPORTED_MODULE_4__["default"](othIndex && array) : undefined;
  }

  array = arrays[0];
  var index = -1,
      seen = caches[0];

  outer: while (++index < length && result.length < maxLength) {
    var value = array[index],
        computed = iteratee ? iteratee(value) : value;
    value = comparator || value !== 0 ? value : 0;

    if (!(seen ? (0,_cacheHas_js__WEBPACK_IMPORTED_MODULE_5__["default"])(seen, computed) : includes(result, computed, comparator))) {
      othIndex = othLength;

      while (--othIndex) {
        var cache = caches[othIndex];

        if (!(cache ? (0,_cacheHas_js__WEBPACK_IMPORTED_MODULE_5__["default"])(cache, computed) : includes(arrays[othIndex], computed, comparator))) {
          continue outer;
        }
      }

      if (seen) {
        seen.push(computed);
      }

      result.push(value);
    }
  }

  return result;
}

/* harmony default export */ __webpack_exports__["default"] = (baseIntersection);

/***/ }),

/***/ 43876:
/*!**********************************************!*\
  !*** ./node_modules/lodash-es/_baseIsNaN.js ***!
  \**********************************************/
/***/ (function(__unused_webpack___webpack_module__, __webpack_exports__, __webpack_require__) {

__webpack_require__.r(__webpack_exports__);
/**
 * The base implementation of `_.isNaN` without support for number objects.
 *
 * @private
 * @param {*} value The value to check.
 * @returns {boolean} Returns `true` if `value` is `NaN`, else `false`.
 */
function baseIsNaN(value) {
  return value !== value;
}

/* harmony default export */ __webpack_exports__["default"] = (baseIsNaN);

/***/ }),

/***/ 26061:
/*!********************************************************!*\
  !*** ./node_modules/lodash-es/_castArrayLikeObject.js ***!
  \********************************************************/
/***/ (function(__unused_webpack___webpack_module__, __webpack_exports__, __webpack_require__) {

__webpack_require__.r(__webpack_exports__);
/* harmony import */ var _isArrayLikeObject_js__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./isArrayLikeObject.js */ 69275);

/**
 * Casts `value` to an empty array if it's not an array like object.
 *
 * @private
 * @param {*} value The value to inspect.
 * @returns {Array|Object} Returns the cast array-like object.
 */

function castArrayLikeObject(value) {
  return (0,_isArrayLikeObject_js__WEBPACK_IMPORTED_MODULE_0__["default"])(value) ? value : [];
}

/* harmony default export */ __webpack_exports__["default"] = (castArrayLikeObject);

/***/ }),

/***/ 35161:
/*!**************************************************!*\
  !*** ./node_modules/lodash-es/_strictIndexOf.js ***!
  \**************************************************/
/***/ (function(__unused_webpack___webpack_module__, __webpack_exports__, __webpack_require__) {

__webpack_require__.r(__webpack_exports__);
/**
 * A specialized version of `_.indexOf` which performs strict equality
 * comparisons of values, i.e. `===`.
 *
 * @private
 * @param {Array} array The array to inspect.
 * @param {*} value The value to search for.
 * @param {number} fromIndex The index to search from.
 * @returns {number} Returns the index of the matched value, else `-1`.
 */
function strictIndexOf(array, value, fromIndex) {
  var index = fromIndex - 1,
      length = array.length;

  while (++index < length) {
    if (array[index] === value) {
      return index;
    }
  }

  return -1;
}

/* harmony default export */ __webpack_exports__["default"] = (strictIndexOf);

/***/ }),

/***/ 71156:
/*!****************************************************!*\
  !*** ./node_modules/lodash-es/intersectionWith.js ***!
  \****************************************************/
/***/ (function(__unused_webpack___webpack_module__, __webpack_exports__, __webpack_require__) {

__webpack_require__.r(__webpack_exports__);
/* harmony import */ var _arrayMap_js__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! ./_arrayMap.js */ 66717);
/* harmony import */ var _baseIntersection_js__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! ./_baseIntersection.js */ 49089);
/* harmony import */ var _baseRest_js__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./_baseRest.js */ 67269);
/* harmony import */ var _castArrayLikeObject_js__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! ./_castArrayLikeObject.js */ 26061);
/* harmony import */ var _last_js__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ./last.js */ 10757);





/**
 * This method is like `_.intersection` except that it accepts `comparator`
 * which is invoked to compare elements of `arrays`. The order and references
 * of result values are determined by the first array. The comparator is
 * invoked with two arguments: (arrVal, othVal).
 *
 * @static
 * @memberOf _
 * @since 4.0.0
 * @category Array
 * @param {...Array} [arrays] The arrays to inspect.
 * @param {Function} [comparator] The comparator invoked per element.
 * @returns {Array} Returns the new array of intersecting values.
 * @example
 *
 * var objects = [{ 'x': 1, 'y': 2 }, { 'x': 2, 'y': 1 }];
 * var others = [{ 'x': 1, 'y': 1 }, { 'x': 1, 'y': 2 }];
 *
 * _.intersectionWith(objects, others, _.isEqual);
 * // => [{ 'x': 1, 'y': 2 }]
 */

var intersectionWith = (0,_baseRest_js__WEBPACK_IMPORTED_MODULE_0__["default"])(function (arrays) {
  var comparator = (0,_last_js__WEBPACK_IMPORTED_MODULE_1__["default"])(arrays),
      mapped = (0,_arrayMap_js__WEBPACK_IMPORTED_MODULE_2__["default"])(arrays, _castArrayLikeObject_js__WEBPACK_IMPORTED_MODULE_3__["default"]);
  comparator = typeof comparator == 'function' ? comparator : undefined;

  if (comparator) {
    mapped.pop();
  }

  return mapped.length && mapped[0] === arrays[0] ? (0,_baseIntersection_js__WEBPACK_IMPORTED_MODULE_4__["default"])(mapped, undefined, comparator) : [];
});
/* harmony default export */ __webpack_exports__["default"] = (intersectionWith);

/***/ })

}]);
//# sourceMappingURL=src_app_pages_user-profile_user-profile_module_ts.js.map