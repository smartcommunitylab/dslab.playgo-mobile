"use strict";
(self["webpackChunkapp"] = self["webpackChunkapp"] || []).push([["src_app_pages_home_campaign-details_stats-team_stats-team_module_ts"],{

/***/ 45454:
/*!*************************************************************************************!*\
  !*** ./src/app/pages/home/campaign-details/stats-team/stats-team-routing.module.ts ***!
  \*************************************************************************************/
/***/ (function(__unused_webpack_module, __webpack_exports__, __webpack_require__) {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "StatsTeamPageRoutingModule": function() { return /* binding */ StatsTeamPageRoutingModule; }
/* harmony export */ });
/* harmony import */ var _Users_smartcommunitylab_Desktop_newWork_dslab_playgo_mobile_playgo_mobile_node_modules_babel_runtime_helpers_esm_createClass_js__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./node_modules/@babel/runtime/helpers/esm/createClass.js */ 48047);
/* harmony import */ var _Users_smartcommunitylab_Desktop_newWork_dslab_playgo_mobile_playgo_mobile_node_modules_babel_runtime_helpers_esm_classCallCheck_js__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ./node_modules/@babel/runtime/helpers/esm/classCallCheck.js */ 78069);
/* harmony import */ var _angular_router__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! @angular/router */ 52816);
/* harmony import */ var _stats_team_page__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! ./stats-team.page */ 73463);
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @angular/core */ 3184);






var routes = [{
  path: '',
  component: _stats_team_page__WEBPACK_IMPORTED_MODULE_2__.StatsTeamPage,
  data: {
    title: 'report.stats.title_team'
  }
}];
var StatsTeamPageRoutingModule = /*#__PURE__*/(0,_Users_smartcommunitylab_Desktop_newWork_dslab_playgo_mobile_playgo_mobile_node_modules_babel_runtime_helpers_esm_createClass_js__WEBPACK_IMPORTED_MODULE_0__["default"])(function StatsTeamPageRoutingModule() {
  (0,_Users_smartcommunitylab_Desktop_newWork_dslab_playgo_mobile_playgo_mobile_node_modules_babel_runtime_helpers_esm_classCallCheck_js__WEBPACK_IMPORTED_MODULE_1__["default"])(this, StatsTeamPageRoutingModule);
});

StatsTeamPageRoutingModule.ɵfac = function StatsTeamPageRoutingModule_Factory(t) {
  return new (t || StatsTeamPageRoutingModule)();
};

StatsTeamPageRoutingModule.ɵmod = /*@__PURE__*/_angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵdefineNgModule"]({
  type: StatsTeamPageRoutingModule
});
StatsTeamPageRoutingModule.ɵinj = /*@__PURE__*/_angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵdefineInjector"]({
  imports: [[_angular_router__WEBPACK_IMPORTED_MODULE_4__.RouterModule.forChild(routes)], _angular_router__WEBPACK_IMPORTED_MODULE_4__.RouterModule]
});

(function () {
  (typeof ngJitMode === "undefined" || ngJitMode) && _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵsetNgModuleScope"](StatsTeamPageRoutingModule, {
    imports: [_angular_router__WEBPACK_IMPORTED_MODULE_4__.RouterModule],
    exports: [_angular_router__WEBPACK_IMPORTED_MODULE_4__.RouterModule]
  });
})();

/***/ }),

/***/ 1346:
/*!*****************************************************************************!*\
  !*** ./src/app/pages/home/campaign-details/stats-team/stats-team.module.ts ***!
  \*****************************************************************************/
/***/ (function(__unused_webpack_module, __webpack_exports__, __webpack_require__) {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "StatsTeamPageModule": function() { return /* binding */ StatsTeamPageModule; }
/* harmony export */ });
/* harmony import */ var _Users_smartcommunitylab_Desktop_newWork_dslab_playgo_mobile_playgo_mobile_node_modules_babel_runtime_helpers_esm_createClass_js__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./node_modules/@babel/runtime/helpers/esm/createClass.js */ 48047);
/* harmony import */ var _Users_smartcommunitylab_Desktop_newWork_dslab_playgo_mobile_playgo_mobile_node_modules_babel_runtime_helpers_esm_classCallCheck_js__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ./node_modules/@babel/runtime/helpers/esm/classCallCheck.js */ 78069);
/* harmony import */ var _stats_team_routing_module__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! ./stats-team-routing.module */ 45454);
/* harmony import */ var _stats_team_page__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! ./stats-team.page */ 73463);
/* harmony import */ var src_app_core_shared_shared_module__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! src/app/core/shared/shared.module */ 97205);
/* harmony import */ var src_app_core_shared_pipes_localDate_pipe__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! src/app/core/shared/pipes/localDate.pipe */ 34489);
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! @angular/core */ 3184);







var StatsTeamPageModule = /*#__PURE__*/(0,_Users_smartcommunitylab_Desktop_newWork_dslab_playgo_mobile_playgo_mobile_node_modules_babel_runtime_helpers_esm_createClass_js__WEBPACK_IMPORTED_MODULE_0__["default"])(function StatsTeamPageModule() {
  (0,_Users_smartcommunitylab_Desktop_newWork_dslab_playgo_mobile_playgo_mobile_node_modules_babel_runtime_helpers_esm_classCallCheck_js__WEBPACK_IMPORTED_MODULE_1__["default"])(this, StatsTeamPageModule);
});

StatsTeamPageModule.ɵfac = function StatsTeamPageModule_Factory(t) {
  return new (t || StatsTeamPageModule)();
};

StatsTeamPageModule.ɵmod = /*@__PURE__*/_angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵdefineNgModule"]({
  type: StatsTeamPageModule
});
StatsTeamPageModule.ɵinj = /*@__PURE__*/_angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵdefineInjector"]({
  providers: [src_app_core_shared_pipes_localDate_pipe__WEBPACK_IMPORTED_MODULE_5__.LocalDatePipe],
  imports: [[src_app_core_shared_shared_module__WEBPACK_IMPORTED_MODULE_4__.PlayGoSharedModule, _stats_team_routing_module__WEBPACK_IMPORTED_MODULE_2__.StatsTeamPageRoutingModule]]
});

(function () {
  (typeof ngJitMode === "undefined" || ngJitMode) && _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵsetNgModuleScope"](StatsTeamPageModule, {
    declarations: [_stats_team_page__WEBPACK_IMPORTED_MODULE_3__.StatsTeamPage],
    imports: [src_app_core_shared_shared_module__WEBPACK_IMPORTED_MODULE_4__.PlayGoSharedModule, _stats_team_routing_module__WEBPACK_IMPORTED_MODULE_2__.StatsTeamPageRoutingModule]
  });
})();

/***/ }),

/***/ 73463:
/*!***************************************************************************!*\
  !*** ./src/app/pages/home/campaign-details/stats-team/stats-team.page.ts ***!
  \***************************************************************************/
/***/ (function(__unused_webpack_module, __webpack_exports__, __webpack_require__) {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "StatsTeamPage": function() { return /* binding */ StatsTeamPage; }
/* harmony export */ });
/* harmony import */ var _Users_smartcommunitylab_Desktop_newWork_dslab_playgo_mobile_playgo_mobile_node_modules_babel_runtime_helpers_esm_createForOfIteratorHelper_js__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./node_modules/@babel/runtime/helpers/esm/createForOfIteratorHelper.js */ 95106);
/* harmony import */ var _Users_smartcommunitylab_Desktop_newWork_dslab_playgo_mobile_playgo_mobile_node_modules_babel_runtime_helpers_esm_toConsumableArray_js__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ./node_modules/@babel/runtime/helpers/esm/toConsumableArray.js */ 58277);
/* harmony import */ var _Users_smartcommunitylab_Desktop_newWork_dslab_playgo_mobile_playgo_mobile_node_modules_babel_runtime_helpers_esm_defineProperty_js__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! ./node_modules/@babel/runtime/helpers/esm/defineProperty.js */ 77797);
/* harmony import */ var _Users_smartcommunitylab_Desktop_newWork_dslab_playgo_mobile_playgo_mobile_node_modules_babel_runtime_helpers_esm_classCallCheck_js__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! ./node_modules/@babel/runtime/helpers/esm/classCallCheck.js */ 78069);
/* harmony import */ var _Users_smartcommunitylab_Desktop_newWork_dslab_playgo_mobile_playgo_mobile_node_modules_babel_runtime_helpers_esm_createClass_js__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! ./node_modules/@babel/runtime/helpers/esm/createClass.js */ 48047);
/* harmony import */ var _ionic_angular__WEBPACK_IMPORTED_MODULE_30__ = __webpack_require__(/*! @ionic/angular */ 93819);
/* harmony import */ var chart_js__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! chart.js */ 73905);
/* harmony import */ var rxjs__WEBPACK_IMPORTED_MODULE_20__ = __webpack_require__(/*! rxjs */ 80228);
/* harmony import */ var rxjs__WEBPACK_IMPORTED_MODULE_25__ = __webpack_require__(/*! rxjs */ 26562);
/* harmony import */ var rxjs__WEBPACK_IMPORTED_MODULE_27__ = __webpack_require__(/*! rxjs */ 35330);
/* harmony import */ var rxjs__WEBPACK_IMPORTED_MODULE_28__ = __webpack_require__(/*! rxjs */ 10745);
/* harmony import */ var luxon__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! luxon */ 20020);
/* harmony import */ var rxjs_operators__WEBPACK_IMPORTED_MODULE_21__ = __webpack_require__(/*! rxjs/operators */ 50635);
/* harmony import */ var rxjs_operators__WEBPACK_IMPORTED_MODULE_22__ = __webpack_require__(/*! rxjs/operators */ 44874);
/* harmony import */ var rxjs_operators__WEBPACK_IMPORTED_MODULE_23__ = __webpack_require__(/*! rxjs/operators */ 89196);
/* harmony import */ var rxjs_operators__WEBPACK_IMPORTED_MODULE_24__ = __webpack_require__(/*! rxjs/operators */ 19337);
/* harmony import */ var rxjs_operators__WEBPACK_IMPORTED_MODULE_26__ = __webpack_require__(/*! rxjs/operators */ 32673);
/* harmony import */ var src_app_core_shared_time_utils__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(/*! src/app/core/shared/time.utils */ 93462);
/* harmony import */ var src_app_core_shared_campaigns_campaign_utils__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(/*! src/app/core/shared/campaigns/campaign.utils */ 87725);
/* harmony import */ var src_app_core_shared_tracking_trip_model__WEBPACK_IMPORTED_MODULE_9__ = __webpack_require__(/*! src/app/core/shared/tracking/trip.model */ 49110);
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_19__ = __webpack_require__(/*! @angular/core */ 3184);
/* harmony import */ var _angular_router__WEBPACK_IMPORTED_MODULE_29__ = __webpack_require__(/*! @angular/router */ 52816);
/* harmony import */ var src_app_core_shared_services_team_service__WEBPACK_IMPORTED_MODULE_10__ = __webpack_require__(/*! src/app/core/shared/services/team.service */ 86612);
/* harmony import */ var src_app_core_shared_services_user_service__WEBPACK_IMPORTED_MODULE_11__ = __webpack_require__(/*! src/app/core/shared/services/user.service */ 50749);
/* harmony import */ var src_app_core_shared_services_error_service__WEBPACK_IMPORTED_MODULE_12__ = __webpack_require__(/*! src/app/core/shared/services/error.service */ 96204);
/* harmony import */ var src_app_core_shared_services_campaign_service__WEBPACK_IMPORTED_MODULE_13__ = __webpack_require__(/*! src/app/core/shared/services/campaign.service */ 23645);
/* harmony import */ var src_app_core_shared_services_page_settings_service__WEBPACK_IMPORTED_MODULE_14__ = __webpack_require__(/*! src/app/core/shared/services/page-settings.service */ 85294);
/* harmony import */ var src_app_core_shared_pipes_localDate_pipe__WEBPACK_IMPORTED_MODULE_15__ = __webpack_require__(/*! src/app/core/shared/pipes/localDate.pipe */ 34489);
/* harmony import */ var _core_shared_layout_header_header_directive__WEBPACK_IMPORTED_MODULE_16__ = __webpack_require__(/*! ../../../../core/shared/layout/header/header.directive */ 34161);
/* harmony import */ var _core_shared_layout_content_content_directive__WEBPACK_IMPORTED_MODULE_17__ = __webpack_require__(/*! ../../../../core/shared/layout/content/content.directive */ 69669);
/* harmony import */ var _angular_common__WEBPACK_IMPORTED_MODULE_31__ = __webpack_require__(/*! @angular/common */ 36362);
/* harmony import */ var _angular_forms__WEBPACK_IMPORTED_MODULE_32__ = __webpack_require__(/*! @angular/forms */ 90587);
/* harmony import */ var _ngx_translate_core__WEBPACK_IMPORTED_MODULE_33__ = __webpack_require__(/*! @ngx-translate/core */ 87514);
/* harmony import */ var _core_shared_pipes_localNumber_pipe__WEBPACK_IMPORTED_MODULE_18__ = __webpack_require__(/*! ../../../../core/shared/pipes/localNumber.pipe */ 89713);




























var _c0 = ["barCanvas"];
var _c1 = ["refresher"];

function StatsTeamPage_ion_select_option_9_Template(rf, ctx) {
  if (rf & 1) {
    _angular_core__WEBPACK_IMPORTED_MODULE_19__["ɵɵelementStart"](0, "ion-select-option", 21);
    _angular_core__WEBPACK_IMPORTED_MODULE_19__["ɵɵtext"](1);
    _angular_core__WEBPACK_IMPORTED_MODULE_19__["ɵɵpipe"](2, "translate");
    _angular_core__WEBPACK_IMPORTED_MODULE_19__["ɵɵelementEnd"]();
  }

  if (rf & 2) {
    var mean_r9 = ctx.$implicit;
    var ctx_r0 = _angular_core__WEBPACK_IMPORTED_MODULE_19__["ɵɵnextContext"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_19__["ɵɵproperty"]("value", mean_r9);
    _angular_core__WEBPACK_IMPORTED_MODULE_19__["ɵɵadvance"](1);
    _angular_core__WEBPACK_IMPORTED_MODULE_19__["ɵɵtextInterpolate1"](" ", _angular_core__WEBPACK_IMPORTED_MODULE_19__["ɵɵpipeBind1"](2, 2, ctx_r0.meanLabels[mean_r9]), " ");
  }
}

function StatsTeamPage_ion_col_14_ion_select_option_4_Template(rf, ctx) {
  if (rf & 1) {
    _angular_core__WEBPACK_IMPORTED_MODULE_19__["ɵɵelementStart"](0, "ion-select-option", 21);
    _angular_core__WEBPACK_IMPORTED_MODULE_19__["ɵɵtext"](1);
    _angular_core__WEBPACK_IMPORTED_MODULE_19__["ɵɵpipe"](2, "translate");
    _angular_core__WEBPACK_IMPORTED_MODULE_19__["ɵɵelementEnd"]();
  }

  if (rf & 2) {
    var metric_r11 = ctx.$implicit;
    var ctx_r10 = _angular_core__WEBPACK_IMPORTED_MODULE_19__["ɵɵnextContext"](2);
    _angular_core__WEBPACK_IMPORTED_MODULE_19__["ɵɵproperty"]("value", metric_r11);
    _angular_core__WEBPACK_IMPORTED_MODULE_19__["ɵɵadvance"](1);
    _angular_core__WEBPACK_IMPORTED_MODULE_19__["ɵɵtextInterpolate1"](" ", _angular_core__WEBPACK_IMPORTED_MODULE_19__["ɵɵpipeBind1"](2, 2, ctx_r10.metricToSelectLabel[metric_r11]), " ");
  }
}

var _c2 = function _c2() {
  return {
    cssClass: "app-alert"
  };
};

function StatsTeamPage_ion_col_14_Template(rf, ctx) {
  if (rf & 1) {
    var _r13 = _angular_core__WEBPACK_IMPORTED_MODULE_19__["ɵɵgetCurrentView"]();

    _angular_core__WEBPACK_IMPORTED_MODULE_19__["ɵɵelementStart"](0, "ion-col")(1, "ion-item", 22)(2, "ion-select", 23);
    _angular_core__WEBPACK_IMPORTED_MODULE_19__["ɵɵlistener"]("ionChange", function StatsTeamPage_ion_col_14_Template_ion_select_ionChange_2_listener($event) {
      _angular_core__WEBPACK_IMPORTED_MODULE_19__["ɵɵrestoreView"](_r13);
      var ctx_r12 = _angular_core__WEBPACK_IMPORTED_MODULE_19__["ɵɵnextContext"]();
      return ctx_r12.selectedMetricChangedSubject.next($event);
    });
    _angular_core__WEBPACK_IMPORTED_MODULE_19__["ɵɵpipe"](3, "async");
    _angular_core__WEBPACK_IMPORTED_MODULE_19__["ɵɵtemplate"](4, StatsTeamPage_ion_col_14_ion_select_option_4_Template, 3, 4, "ion-select-option", 6);
    _angular_core__WEBPACK_IMPORTED_MODULE_19__["ɵɵelementEnd"]()()();
  }

  if (rf & 2) {
    var ctx_r1 = _angular_core__WEBPACK_IMPORTED_MODULE_19__["ɵɵnextContext"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_19__["ɵɵadvance"](1);
    _angular_core__WEBPACK_IMPORTED_MODULE_19__["ɵɵproperty"]("color", ctx_r1.campaignContainer.campaign.type);
    _angular_core__WEBPACK_IMPORTED_MODULE_19__["ɵɵadvance"](1);
    _angular_core__WEBPACK_IMPORTED_MODULE_19__["ɵɵproperty"]("interfaceOptions", _angular_core__WEBPACK_IMPORTED_MODULE_19__["ɵɵpureFunction0"](6, _c2))("value", _angular_core__WEBPACK_IMPORTED_MODULE_19__["ɵɵpipeBind1"](3, 4, ctx_r1.selectedMetric$));
    _angular_core__WEBPACK_IMPORTED_MODULE_19__["ɵɵadvance"](2);
    _angular_core__WEBPACK_IMPORTED_MODULE_19__["ɵɵproperty"]("ngForOf", ctx_r1.metrics);
  }
}

function StatsTeamPage_ion_col_16_Template(rf, ctx) {
  if (rf & 1) {
    _angular_core__WEBPACK_IMPORTED_MODULE_19__["ɵɵelementStart"](0, "ion-col")(1, "ion-item", 24);
    _angular_core__WEBPACK_IMPORTED_MODULE_19__["ɵɵtext"](2);
    _angular_core__WEBPACK_IMPORTED_MODULE_19__["ɵɵpipe"](3, "translate");
    _angular_core__WEBPACK_IMPORTED_MODULE_19__["ɵɵelementEnd"]()();
  }

  if (rf & 2) {
    var ctx_r2 = _angular_core__WEBPACK_IMPORTED_MODULE_19__["ɵɵnextContext"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_19__["ɵɵadvance"](1);
    _angular_core__WEBPACK_IMPORTED_MODULE_19__["ɵɵproperty"]("color", ctx_r2.campaignContainer == null ? null : ctx_r2.campaignContainer.campaign == null ? null : ctx_r2.campaignContainer.campaign.type);
    _angular_core__WEBPACK_IMPORTED_MODULE_19__["ɵɵadvance"](1);
    _angular_core__WEBPACK_IMPORTED_MODULE_19__["ɵɵtextInterpolate1"](" ", _angular_core__WEBPACK_IMPORTED_MODULE_19__["ɵɵpipeBind1"](3, 2, "campaigns.leaderboard.leaderboard_type.GL"), " ");
  }
}

function StatsTeamPage_ion_segment_button_22_Template(rf, ctx) {
  if (rf & 1) {
    _angular_core__WEBPACK_IMPORTED_MODULE_19__["ɵɵelementStart"](0, "ion-segment-button", 25)(1, "ion-label");
    _angular_core__WEBPACK_IMPORTED_MODULE_19__["ɵɵtext"](2);
    _angular_core__WEBPACK_IMPORTED_MODULE_19__["ɵɵpipe"](3, "translate");
    _angular_core__WEBPACK_IMPORTED_MODULE_19__["ɵɵelementEnd"]()();
  }

  if (rf & 2) {
    var period_r14 = ctx.$implicit;
    var ctx_r3 = _angular_core__WEBPACK_IMPORTED_MODULE_19__["ɵɵnextContext"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_19__["ɵɵstyleProp"]("--radius", "10px")("--color", "var(--ion-color-" + ctx_r3.campaignContainer.campaign.type + "-contrast)")("--color-checked", "black");
    _angular_core__WEBPACK_IMPORTED_MODULE_19__["ɵɵproperty"]("value", period_r14);
    _angular_core__WEBPACK_IMPORTED_MODULE_19__["ɵɵadvance"](2);
    _angular_core__WEBPACK_IMPORTED_MODULE_19__["ɵɵtextInterpolate"](_angular_core__WEBPACK_IMPORTED_MODULE_19__["ɵɵpipeBind1"](3, 8, period_r14.labelKey));
  }
}

function StatsTeamPage_ion_button_26_Template(rf, ctx) {
  if (rf & 1) {
    var _r16 = _angular_core__WEBPACK_IMPORTED_MODULE_19__["ɵɵgetCurrentView"]();

    _angular_core__WEBPACK_IMPORTED_MODULE_19__["ɵɵelementStart"](0, "ion-button", 26);
    _angular_core__WEBPACK_IMPORTED_MODULE_19__["ɵɵlistener"]("click", function StatsTeamPage_ion_button_26_Template_ion_button_click_0_listener() {
      _angular_core__WEBPACK_IMPORTED_MODULE_19__["ɵɵrestoreView"](_r16);
      var ctx_r15 = _angular_core__WEBPACK_IMPORTED_MODULE_19__["ɵɵnextContext"]();
      return ctx_r15.backPeriod();
    });
    _angular_core__WEBPACK_IMPORTED_MODULE_19__["ɵɵelement"](1, "ion-icon", 27);
    _angular_core__WEBPACK_IMPORTED_MODULE_19__["ɵɵelementEnd"]();
  }

  if (rf & 2) {
    var ctx_r4 = _angular_core__WEBPACK_IMPORTED_MODULE_19__["ɵɵnextContext"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_19__["ɵɵstyleProp"]("color", "var(--ion-color-" + ctx_r4.campaignContainer.campaign.type + "-dark-contrast)");
  }
}

function StatsTeamPage_p_30_Template(rf, ctx) {
  if (rf & 1) {
    _angular_core__WEBPACK_IMPORTED_MODULE_19__["ɵɵelementStart"](0, "p", 28);
    _angular_core__WEBPACK_IMPORTED_MODULE_19__["ɵɵtext"](1);
    _angular_core__WEBPACK_IMPORTED_MODULE_19__["ɵɵpipe"](2, "localNumber");
    _angular_core__WEBPACK_IMPORTED_MODULE_19__["ɵɵpipe"](3, "translate");
    _angular_core__WEBPACK_IMPORTED_MODULE_19__["ɵɵpipe"](4, "async");
    _angular_core__WEBPACK_IMPORTED_MODULE_19__["ɵɵelementEnd"]();
  }

  if (rf & 2) {
    var ctx_r5 = _angular_core__WEBPACK_IMPORTED_MODULE_19__["ɵɵnextContext"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_19__["ɵɵstyleProp"]("color", "var(--ion-color-" + ctx_r5.campaignContainer.campaign.type + "-dark-contrast)");
    _angular_core__WEBPACK_IMPORTED_MODULE_19__["ɵɵadvance"](1);
    _angular_core__WEBPACK_IMPORTED_MODULE_19__["ɵɵtextInterpolate2"](" ", _angular_core__WEBPACK_IMPORTED_MODULE_19__["ɵɵpipeBind2"](2, 4, ctx_r5.totalValue, "0.0-1"), " ", _angular_core__WEBPACK_IMPORTED_MODULE_19__["ɵɵpipeBind1"](3, 7, ctx_r5.metricToUnitLabel[_angular_core__WEBPACK_IMPORTED_MODULE_19__["ɵɵpipeBind1"](4, 9, ctx_r5.selectedMetric$)]), " ");
  }
}

function StatsTeamPage_p_32_Template(rf, ctx) {
  if (rf & 1) {
    _angular_core__WEBPACK_IMPORTED_MODULE_19__["ɵɵelementStart"](0, "p", 28);
    _angular_core__WEBPACK_IMPORTED_MODULE_19__["ɵɵtext"](1);
    _angular_core__WEBPACK_IMPORTED_MODULE_19__["ɵɵpipe"](2, "localNumber");
    _angular_core__WEBPACK_IMPORTED_MODULE_19__["ɵɵelementEnd"]();
  }

  if (rf & 2) {
    var ctx_r6 = _angular_core__WEBPACK_IMPORTED_MODULE_19__["ɵɵnextContext"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_19__["ɵɵstyleProp"]("color", "var(--ion-color-" + ctx_r6.campaignContainer.campaign.type + "-dark-contrast)");
    _angular_core__WEBPACK_IMPORTED_MODULE_19__["ɵɵadvance"](1);
    _angular_core__WEBPACK_IMPORTED_MODULE_19__["ɵɵtextInterpolate1"](" ", _angular_core__WEBPACK_IMPORTED_MODULE_19__["ɵɵpipeBind2"](2, 3, ctx_r6.totalValue, "0.0-1"), " ecoLeaves ");
  }
}

function StatsTeamPage_ion_button_35_Template(rf, ctx) {
  if (rf & 1) {
    var _r18 = _angular_core__WEBPACK_IMPORTED_MODULE_19__["ɵɵgetCurrentView"]();

    _angular_core__WEBPACK_IMPORTED_MODULE_19__["ɵɵelementStart"](0, "ion-button", 26);
    _angular_core__WEBPACK_IMPORTED_MODULE_19__["ɵɵlistener"]("click", function StatsTeamPage_ion_button_35_Template_ion_button_click_0_listener() {
      _angular_core__WEBPACK_IMPORTED_MODULE_19__["ɵɵrestoreView"](_r18);
      var ctx_r17 = _angular_core__WEBPACK_IMPORTED_MODULE_19__["ɵɵnextContext"]();
      return ctx_r17.forwardPeriod();
    });
    _angular_core__WEBPACK_IMPORTED_MODULE_19__["ɵɵelement"](1, "ion-icon", 29);
    _angular_core__WEBPACK_IMPORTED_MODULE_19__["ɵɵelementEnd"]();
  }

  if (rf & 2) {
    var ctx_r7 = _angular_core__WEBPACK_IMPORTED_MODULE_19__["ɵɵnextContext"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_19__["ɵɵstyleProp"]("color", "var(--ion-color-" + ctx_r7.campaignContainer.campaign.type + "-dark-contrast)");
  }
}

var StatsTeamPage = /*#__PURE__*/function () {
  function StatsTeamPage(route, teamService, userService, errorService, campaignService, pageSettingsService, localDatePipe) {
    var _Object$assign,
        _this = this;

    (0,_Users_smartcommunitylab_Desktop_newWork_dslab_playgo_mobile_playgo_mobile_node_modules_babel_runtime_helpers_esm_classCallCheck_js__WEBPACK_IMPORTED_MODULE_3__["default"])(this, StatsTeamPage);

    this.route = route;
    this.teamService = teamService;
    this.userService = userService;
    this.errorService = errorService;
    this.campaignService = campaignService;
    this.pageSettingsService = pageSettingsService;
    this.localDatePipe = localDatePipe;
    this.selectedMeanChangedSubject = new rxjs__WEBPACK_IMPORTED_MODULE_20__.Subject();
    this.selectedMetricChangedSubject = new rxjs__WEBPACK_IMPORTED_MODULE_20__.Subject();
    this.meanLabels = Object.assign(Object.assign({}, src_app_core_shared_tracking_trip_model__WEBPACK_IMPORTED_MODULE_9__.transportTypeLabels), (_Object$assign = {}, (0,_Users_smartcommunitylab_Desktop_newWork_dslab_playgo_mobile_playgo_mobile_node_modules_babel_runtime_helpers_esm_defineProperty_js__WEBPACK_IMPORTED_MODULE_2__["default"])(_Object$assign, ALL_MEANS, 'campaigns.leaderboard.all_means'), (0,_Users_smartcommunitylab_Desktop_newWork_dslab_playgo_mobile_playgo_mobile_node_modules_babel_runtime_helpers_esm_defineProperty_js__WEBPACK_IMPORTED_MODULE_2__["default"])(_Object$assign, GL, 'campaigns.leaderboard.gl'), _Object$assign));
    this.metricToNumberWithUnitLabel = {
      co2: 'campaigns.leaderboard.leaderboard_type_unit.co2',
      km: 'campaigns.leaderboard.leaderboard_type_unit.km',
      time: 'campaigns.leaderboard.leaderboard_type_unit.duration',
      tracks: 'campaigns.leaderboard.leaderboard_type_unit.tracks'
    };
    this.metricToSelectLabel = {
      co2: 'campaigns.leaderboard.select.co2',
      km: 'campaigns.leaderboard.select.km',
      time: 'campaigns.leaderboard.select.duration',
      tracks: 'campaigns.leaderboard.select.tracks'
    };
    this.metricToUnitLabel = {
      co2: 'campaigns.leaderboard.unit.co2',
      km: 'campaigns.leaderboard.unit.km',
      time: 'campaigns.leaderboard.unit.duration',
      tracks: 'campaigns.leaderboard.unit.tracks'
    };
    this.selectedMean$ = this.selectedMeanChangedSubject.pipe((0,rxjs_operators__WEBPACK_IMPORTED_MODULE_21__.map)(function (event) {
      return event.detail.value;
    }), (0,rxjs_operators__WEBPACK_IMPORTED_MODULE_22__.startWith)(ALL_MEANS), (0,rxjs_operators__WEBPACK_IMPORTED_MODULE_23__.shareReplay)(1));
    this.selectedMetric$ = this.selectedMetricChangedSubject.pipe((0,rxjs_operators__WEBPACK_IMPORTED_MODULE_21__.map)(function (event) {
      return event.detail.value;
    }), (0,rxjs_operators__WEBPACK_IMPORTED_MODULE_24__.tap)(function (metric) {
      return _this.setDivider(metric);
    }), (0,rxjs_operators__WEBPACK_IMPORTED_MODULE_22__.startWith)( // initial select value
    'km'), (0,rxjs_operators__WEBPACK_IMPORTED_MODULE_23__.shareReplay)(1));
    this.referenceDate = luxon__WEBPACK_IMPORTED_MODULE_6__.DateTime.local();
    this.todayDate = luxon__WEBPACK_IMPORTED_MODULE_6__.DateTime.local();
    this.totalValue = 0;
    this.periods = (0,src_app_core_shared_campaigns_campaign_utils__WEBPACK_IMPORTED_MODULE_8__.getPeriods)(this.referenceDate);
    this.selectedPeriod = this.periods[0];
    this.statPeriodChangedSubject = new rxjs__WEBPACK_IMPORTED_MODULE_20__.Subject();
    this.selectedPeriod$ = this.statPeriodChangedSubject.pipe((0,rxjs_operators__WEBPACK_IMPORTED_MODULE_21__.map)(function (period) {
      _this.selectedPeriod = period;
      return _this.getPeriodByReference(period);
    }), (0,rxjs_operators__WEBPACK_IMPORTED_MODULE_22__.startWith)(this.periods[0]), (0,rxjs_operators__WEBPACK_IMPORTED_MODULE_23__.shareReplay)(1));
    this.campaignId$ = this.route.params.pipe((0,rxjs_operators__WEBPACK_IMPORTED_MODULE_21__.map)(function (params) {
      return params.id;
    }), (0,rxjs_operators__WEBPACK_IMPORTED_MODULE_23__.shareReplay)(1));
    this.teamIdSubject = new rxjs__WEBPACK_IMPORTED_MODULE_20__.Subject();
    this.teamId$ = this.teamIdSubject.pipe((0,rxjs_operators__WEBPACK_IMPORTED_MODULE_24__.tap)(function (id) {
      return console.log(id);
    }), (0,rxjs_operators__WEBPACK_IMPORTED_MODULE_23__.shareReplay)(1)); // teamId$: Observable<string> = this.userService.userProfile$.pipe(
    //   map((userProfile) => userProfile.playerId),
    //   shareReplay(1)
    // );

    this.filterOptions$ = (0,rxjs__WEBPACK_IMPORTED_MODULE_25__.combineLatest)({
      mean: this.selectedMean$,
      metric: this.selectedMetric$,
      period: this.selectedPeriod$,
      campaignId: this.campaignId$,
      teamId: this.teamId$
    });
    this.statResponse$ = this.filterOptions$.pipe((0,rxjs_operators__WEBPACK_IMPORTED_MODULE_26__.switchMap)(function (_ref) {
      var mean = _ref.mean,
          metric = _ref.metric,
          period = _ref.period,
          campaignId = _ref.campaignId,
          teamId = _ref.teamId;
      return (0,rxjs__WEBPACK_IMPORTED_MODULE_27__.iif)(function () {
        return mean !== 'GL';
      }, _this.teamService.getGroupStat(campaignId, teamId, metric, period.group, mean === ALL_MEANS ? null : mean, (0,src_app_core_shared_time_utils__WEBPACK_IMPORTED_MODULE_7__.toServerDateOnly)(period.from), (0,src_app_core_shared_time_utils__WEBPACK_IMPORTED_MODULE_7__.toServerDateOnly)(period.to)), _this.teamService.getGroupGameStats(campaignId, teamId, period.group, (0,src_app_core_shared_time_utils__WEBPACK_IMPORTED_MODULE_7__.toServerDateOnly)(period.from), (0,src_app_core_shared_time_utils__WEBPACK_IMPORTED_MODULE_7__.toServerDateOnly)(period.to)).pipe(_this.errorService.getErrorHandler()));
    }));
    this.divider = 1000;
    this.style = getComputedStyle(document.body);
    this.statsSubs = this.statResponse$.subscribe(function (stats) {
      var convertedStat = stats.map(function (stat) {
        return stat.value >= 0 ? Object.assign(Object.assign({}, stat), {
          value: stat.value / _this.divider
        }) : Object.assign(Object.assign({}, stat), {
          value: 0
        });
      });

      _this.barChartMethod(convertedStat);

      _this.setTotal(convertedStat);
    });
    this.subId = this.route.params.subscribe(function (params) {
      _this.id = params.id;
      _this.subCampaign = _this.campaignService.myCampaigns$.subscribe(function (campaigns) {
        _this.campaignContainer = campaigns.find(function (campaignContainer) {
          return campaignContainer.campaign.campaignId === _this.id;
        });

        if (_this.campaignContainer) {
          _this.initMeanAndMetrics();
        }
      });
    });
  }

  (0,_Users_smartcommunitylab_Desktop_newWork_dslab_playgo_mobile_playgo_mobile_node_modules_babel_runtime_helpers_esm_createClass_js__WEBPACK_IMPORTED_MODULE_4__["default"])(StatsTeamPage, [{
    key: "initMeanAndMetrics",
    value: function initMeanAndMetrics() {
      this.metrics = this.campaignContainer.campaign.type === 'company' ? ['co2', 'km'] : ['co2', 'km', 'time', 'tracks'];
      this.means$ = (0,rxjs__WEBPACK_IMPORTED_MODULE_28__.of)([ALL_MEANS].concat((0,_Users_smartcommunitylab_Desktop_newWork_dslab_playgo_mobile_playgo_mobile_node_modules_babel_runtime_helpers_esm_toConsumableArray_js__WEBPACK_IMPORTED_MODULE_1__["default"])(this.campaignContainer.campaign.validationData.means))); // this.selectedMeanChangedSubject.next({
      //   detail: { value: this.campaignContainer?.campaign?.validationData?.means[0] },
      // } as SelectCustomEvent<TransportType>);
    }
  }, {
    key: "ionViewWillEnter",
    value: function ionViewWillEnter() {
      this.changePageSettings();
    }
  }, {
    key: "setDivider",
    value: function setDivider(metric) {
      switch (metric) {
        case 'co2':
          this.divider = 1;
          break;

        case 'km':
          this.divider = 1000;
          break;

        case 'time':
          this.divider = 3600;
          break;

        case 'tracks':
          this.divider = 1;
          break;

        default:
          this.divider = 1000;
          break;
      }
    }
  }, {
    key: "changePageSettings",
    value: function changePageSettings() {
      var _a, _b;

      this.pageSettingsService.set({
        color: (_b = (_a = this.campaignContainer) === null || _a === void 0 ? void 0 : _a.campaign) === null || _b === void 0 ? void 0 : _b.type
      });
    }
  }, {
    key: "setTotal",
    value: function setTotal(stats) {
      this.totalValue = stats.map(function (stat) {
        return stat.totalScore ? stat.totalScore : stat.value >= 0 ? stat.value : 0;
      }).reduce(function (prev, next) {
        return prev + next;
      }, 0);
    }
  }, {
    key: "ngOnInit",
    value: function ngOnInit() {
      var _this2 = this;

      var _a, _b, _c, _d, _e;

      this.selectedSegment = this.periods[0];
      this.teamService.getMyTeam((_b = (_a = this.campaignContainer) === null || _a === void 0 ? void 0 : _a.campaign) === null || _b === void 0 ? void 0 : _b.campaignId, (_e = (_d = (_c = this.campaignContainer) === null || _c === void 0 ? void 0 : _c.subscription) === null || _d === void 0 ? void 0 : _d.campaignData) === null || _e === void 0 ? void 0 : _e.teamId).pipe((0,rxjs_operators__WEBPACK_IMPORTED_MODULE_21__.map)(function (team) {
        return team.id;
      }), (0,rxjs_operators__WEBPACK_IMPORTED_MODULE_24__.tap)(function (id) {
        return _this2.teamIdSubject.next(id);
      })).subscribe();
    }
  }, {
    key: "ngOnDestroy",
    value: function ngOnDestroy() {}
  }, {
    key: "ionViewDidLeave",
    value: function ionViewDidLeave() {
      this.statsSubs.unsubscribe();
    }
  }, {
    key: "getPeriodByReference",
    value: function getPeriodByReference(value) {
      return this.periods.find(function (period) {
        return period.group === value.group;
      });
    }
  }, {
    key: "segmentChanged",
    value: function segmentChanged(ev) {
      console.log('Segment changed, change the selected period', ev);
    }
  }, {
    key: "thereIsPast",
    value: function thereIsPast() {
      // Check if  is not in actual period
      // get future of the button
      var refDate = this.referenceDate.plus((0,_Users_smartcommunitylab_Desktop_newWork_dslab_playgo_mobile_playgo_mobile_node_modules_babel_runtime_helpers_esm_defineProperty_js__WEBPACK_IMPORTED_MODULE_2__["default"])({}, this.selectedPeriod.add, -1));
      return refDate.startOf(this.selectedPeriod.add) >= luxon__WEBPACK_IMPORTED_MODULE_6__.DateTime.fromMillis(this.campaignContainer.campaign.dateFrom).startOf(this.selectedPeriod.add);
    }
  }, {
    key: "thereIsFuture",
    value: function thereIsFuture() {
      // Check if  is not in actual period
      // get future of the button
      var refDate = this.referenceDate.plus((0,_Users_smartcommunitylab_Desktop_newWork_dslab_playgo_mobile_playgo_mobile_node_modules_babel_runtime_helpers_esm_defineProperty_js__WEBPACK_IMPORTED_MODULE_2__["default"])({}, this.selectedPeriod.add, 1));
      return refDate.startOf(this.selectedPeriod.add) <= this.todayDate.startOf(this.selectedPeriod.add);
    }
  }, {
    key: "backPeriod",
    value: function backPeriod() {
      var _this3 = this;

      //change referenceDate
      this.referenceDate = this.referenceDate.plus((0,_Users_smartcommunitylab_Desktop_newWork_dslab_playgo_mobile_playgo_mobile_node_modules_babel_runtime_helpers_esm_defineProperty_js__WEBPACK_IMPORTED_MODULE_2__["default"])({}, this.selectedPeriod.add, -1)); //only get but it doesn't write on subject

      this.periods = (0,src_app_core_shared_campaigns_campaign_utils__WEBPACK_IMPORTED_MODULE_8__.getPeriods)(this.referenceDate);
      var tabIndex = this.periods.findIndex(function (period) {
        return period.group === _this3.selectedPeriod.group;
      });
      this.selectedSegment = this.periods[tabIndex];
      this.statPeriodChangedSubject.next(this.periods[tabIndex]);
    }
  }, {
    key: "forwardPeriod",
    value: function forwardPeriod() {
      var _this4 = this;

      this.referenceDate = this.referenceDate.plus((0,_Users_smartcommunitylab_Desktop_newWork_dslab_playgo_mobile_playgo_mobile_node_modules_babel_runtime_helpers_esm_defineProperty_js__WEBPACK_IMPORTED_MODULE_2__["default"])({}, this.selectedPeriod.add, 1));
      this.periods = (0,src_app_core_shared_campaigns_campaign_utils__WEBPACK_IMPORTED_MODULE_8__.getPeriods)(this.referenceDate);
      var tabIndex = this.periods.findIndex(function (period) {
        return period.group === _this4.selectedPeriod.group;
      });
      this.selectedSegment = this.periods[tabIndex];
      this.statPeriodChangedSubject.next(this.periods[tabIndex]);
    }
  }, {
    key: "daysFromInterval",
    value: function daysFromInterval() {
      var retArr = [];
      var start = this.selectedPeriod.from;
      var end = this.selectedPeriod.to;
      var interval = luxon__WEBPACK_IMPORTED_MODULE_6__.Interval.fromDateTimes(start, end);
      var cursor = interval.start;
      cursor = cursor.startOf(this.selectedPeriod.group);

      while (cursor < interval.end) {
        //begin of the element
        if (this.selectedPeriod.group !== 'week') {
          retArr.push({
            label: cursor.toFormat(this.selectedPeriod.chartFormat),
            date: cursor
          });
        } else {
          retArr.push({
            label: cursor.toFormat(this.selectedPeriod.chartFormat) + '-' + cursor.endOf('week').toFormat(this.selectedPeriod.chartFormat),
            date: cursor
          });
        }

        cursor = cursor.plus((0,_Users_smartcommunitylab_Desktop_newWork_dslab_playgo_mobile_playgo_mobile_node_modules_babel_runtime_helpers_esm_defineProperty_js__WEBPACK_IMPORTED_MODULE_2__["default"])({}, this.selectedPeriod.group, 1));
      }

      return retArr;
    }
  }, {
    key: "getObjectDate",
    value: function getObjectDate(statPeriod) {
      //anno - mese o anno numero settimana o anno mese giorno in base alla selezione
      var periodSplitted = statPeriod.split('-');

      switch (this.selectedPeriod.group) {
        case 'day':
          return {
            year: Number(periodSplitted[0]),
            month: Number(periodSplitted[1]),
            day: Number(periodSplitted[2])
          };

        case 'week':
          return {
            weekYear: Number(periodSplitted[0]),
            weekNumber: Number(periodSplitted[1])
          };

        case 'month':
          return {
            year: Number(periodSplitted[0]),
            month: Number(periodSplitted[1])
          };
      }
    }
  }, {
    key: "valuesFromStat",
    value: function valuesFromStat(arrOfPeriod, stats) {
      var _this5 = this;

      //  check if stats[i] is part of arrOfPeriod
      var statsArrayDate = stats.map(function (stat) {
        console.log(stat);
        return luxon__WEBPACK_IMPORTED_MODULE_6__.DateTime.fromObject(_this5.getObjectDate(stat.period));
      });
      console.log(statsArrayDate);
      var retArr = [];

      var _iterator = (0,_Users_smartcommunitylab_Desktop_newWork_dslab_playgo_mobile_playgo_mobile_node_modules_babel_runtime_helpers_esm_createForOfIteratorHelper_js__WEBPACK_IMPORTED_MODULE_0__["default"])(arrOfPeriod),
          _step;

      try {
        var _loop = function _loop() {
          var period = _step.value;
          //check if statsArrayDate has a period
          var i = statsArrayDate.findIndex(function (statPeriod) {
            return statPeriod.toISO() === period.toISO();
          });

          if (i !== -1) {
            if (stats[i].hasOwnProperty('totalScore')) {
              retArr.push(stats[i].value >= 0 ? stats[i].totalScore : 0);
            } else {
              retArr.push(stats[i].value >= 0 ? stats[i].value : 0);
            }
          } else {
            retArr.push(0);
          }
        };

        for (_iterator.s(); !(_step = _iterator.n()).done;) {
          _loop();
        }
      } catch (err) {
        _iterator.e(err);
      } finally {
        _iterator.f();
      }

      return retArr;
    }
  }, {
    key: "barChartMethod",
    value: function barChartMethod(stats) {
      var _this6 = this;

      // Now we need to supply a Chart element reference with an
      //object that defines the type of chart we want to use, and the type of data we want to display.
      // eslint-disable-next-line max-len
      chart_js__WEBPACK_IMPORTED_MODULE_5__.Chart.register(chart_js__WEBPACK_IMPORTED_MODULE_5__.LineController, chart_js__WEBPACK_IMPORTED_MODULE_5__.BarController, chart_js__WEBPACK_IMPORTED_MODULE_5__.CategoryScale, chart_js__WEBPACK_IMPORTED_MODULE_5__.LinearScale, chart_js__WEBPACK_IMPORTED_MODULE_5__.BarElement, chart_js__WEBPACK_IMPORTED_MODULE_5__.DoughnutController, chart_js__WEBPACK_IMPORTED_MODULE_5__.ArcElement, chart_js__WEBPACK_IMPORTED_MODULE_5__.PointElement, chart_js__WEBPACK_IMPORTED_MODULE_5__.LineElement);

      if (!this.barCanvas) {
        return;
      } else {
        var chartExist = chart_js__WEBPACK_IMPORTED_MODULE_5__.Chart.getChart('statsChart');

        if (chartExist !== undefined) {
          chartExist.destroy();
        }
      } //build using stats and this.selectedPeriod


      var arrOfPeriod = this.daysFromInterval();
      var arrOfValues = this.valuesFromStat(arrOfPeriod.map(function (period) {
        return period.date;
      }), stats);
      this.barChart = new chart_js__WEBPACK_IMPORTED_MODULE_5__.Chart(this.barCanvas.nativeElement, {
        type: 'bar',
        options: {
          onClick: function onClick(e) {
            var _a;

            var points = _this6.barChart.getElementsAtEventForMode(e, 'nearest', {
              intersect: true
            }, true);

            if (points.length) {
              var firstPoint = points[0];
              var label = (_a = arrOfPeriod.find(function (data) {
                return data.label === _this6.barChart.data.labels[firstPoint.index];
              })) === null || _a === void 0 ? void 0 : _a.date; //const label = this.barChart.data.labels[firstPoint.index];
              //clicked on label x so I have to switch to that view base on what I'm watching

              _this6.changeView(label.toFormat(_this6.selectedPeriod.format)); //const value = this.barChart.data.datasets[firstPoint.datasetIndex].data[firstPoint.index];

            }
          },
          scales: {
            x: {
              grid: {
                display: false
              },
              ticks: {
                font: {
                  size: 17,
                  weight: '500'
                }
              }
            }
          },
          responsive: true,
          maintainAspectRatio: false
        },
        data: {
          labels: arrOfPeriod.map(function (period) {
            return period.label;
          }),
          datasets: [{
            data: arrOfValues,
            backgroundColor: this.style.getPropertyValue('--ion-color-' + this.campaignContainer.campaign.type),
            borderColor: this.style.getPropertyValue('--ion-color-' + this.campaignContainer.campaign.type),
            borderWidth: 1,
            borderRadius: 5
          }]
        }
      });
    }
  }, {
    key: "getSelectedPeriod",
    value: function getSelectedPeriod() {
      var date = this.localDatePipe.transform(this.selectedPeriod.from, this.selectedPeriod.label);

      if (this.selectedSegment.group === 'day') {
        date += ' / ' + this.localDatePipe.transform(this.selectedPeriod.to, this.selectedPeriod.label);
      }

      return date.replace(/(^\w|\s\w)/g, function (m) {
        return m.toUpperCase();
      });
    }
  }, {
    key: "changeView",
    value: function changeView(label) {
      var _this7 = this;

      // segmentChanged($event); statPeriodChangedSubject.next(selectedSegment)
      var switchToPeriod = null;

      switch (this.selectedSegment.group) {
        case 'month':
          label = luxon__WEBPACK_IMPORTED_MODULE_6__.DateTime.fromFormat(label, 'MM-yyyy').toFormat('yyyy-MM-dd');
          break;

        case 'week':
          label = luxon__WEBPACK_IMPORTED_MODULE_6__.DateTime.fromFormat(label, 'dd-MM-yyyy').toFormat('yyyy-WW');
          break;

        case 'day':
          // label = DateTime.fromFormat(label, 'dd-MM').toFormat('yyyy-MM-dd');
          return;

        default:
          break;
      } // change reference date
      //only get but it doesn't write on subject


      this.referenceDate = luxon__WEBPACK_IMPORTED_MODULE_6__.DateTime.fromObject(this.getObjectDate(label));
      this.periods = (0,src_app_core_shared_campaigns_campaign_utils__WEBPACK_IMPORTED_MODULE_8__.getPeriods)(this.referenceDate);
      this.selectedSegment = this.periods.find(function (a) {
        return a.group === _this7.selectedSegment.switchTo;
      });
      this.statPeriodChangedSubject.next(this.selectedSegment);
    }
  }]);

  return StatsTeamPage;
}();

StatsTeamPage.ɵfac = function StatsTeamPage_Factory(t) {
  return new (t || StatsTeamPage)(_angular_core__WEBPACK_IMPORTED_MODULE_19__["ɵɵdirectiveInject"](_angular_router__WEBPACK_IMPORTED_MODULE_29__.ActivatedRoute), _angular_core__WEBPACK_IMPORTED_MODULE_19__["ɵɵdirectiveInject"](src_app_core_shared_services_team_service__WEBPACK_IMPORTED_MODULE_10__.TeamService), _angular_core__WEBPACK_IMPORTED_MODULE_19__["ɵɵdirectiveInject"](src_app_core_shared_services_user_service__WEBPACK_IMPORTED_MODULE_11__.UserService), _angular_core__WEBPACK_IMPORTED_MODULE_19__["ɵɵdirectiveInject"](src_app_core_shared_services_error_service__WEBPACK_IMPORTED_MODULE_12__.ErrorService), _angular_core__WEBPACK_IMPORTED_MODULE_19__["ɵɵdirectiveInject"](src_app_core_shared_services_campaign_service__WEBPACK_IMPORTED_MODULE_13__.CampaignService), _angular_core__WEBPACK_IMPORTED_MODULE_19__["ɵɵdirectiveInject"](src_app_core_shared_services_page_settings_service__WEBPACK_IMPORTED_MODULE_14__.PageSettingsService), _angular_core__WEBPACK_IMPORTED_MODULE_19__["ɵɵdirectiveInject"](src_app_core_shared_pipes_localDate_pipe__WEBPACK_IMPORTED_MODULE_15__.LocalDatePipe));
};

StatsTeamPage.ɵcmp = /*@__PURE__*/_angular_core__WEBPACK_IMPORTED_MODULE_19__["ɵɵdefineComponent"]({
  type: StatsTeamPage,
  selectors: [["app-stats"]],
  viewQuery: function StatsTeamPage_Query(rf, ctx) {
    if (rf & 1) {
      _angular_core__WEBPACK_IMPORTED_MODULE_19__["ɵɵviewQuery"](_c0, 5);
      _angular_core__WEBPACK_IMPORTED_MODULE_19__["ɵɵviewQuery"](_ionic_angular__WEBPACK_IMPORTED_MODULE_30__.IonInfiniteScroll, 5);
      _angular_core__WEBPACK_IMPORTED_MODULE_19__["ɵɵviewQuery"](_c1, 5);
    }

    if (rf & 2) {
      var _t;

      _angular_core__WEBPACK_IMPORTED_MODULE_19__["ɵɵqueryRefresh"](_t = _angular_core__WEBPACK_IMPORTED_MODULE_19__["ɵɵloadQuery"]()) && (ctx.barCanvas = _t.first);
      _angular_core__WEBPACK_IMPORTED_MODULE_19__["ɵɵqueryRefresh"](_t = _angular_core__WEBPACK_IMPORTED_MODULE_19__["ɵɵloadQuery"]()) && (ctx.infiniteScroll = _t.first);
      _angular_core__WEBPACK_IMPORTED_MODULE_19__["ɵɵqueryRefresh"](_t = _angular_core__WEBPACK_IMPORTED_MODULE_19__["ɵɵloadQuery"]()) && (ctx.refresher = _t.first);
    }
  },
  decls: 39,
  vars: 42,
  consts: [["appHeader", ""], ["appContent", "", 3, "fullscreen"], [1, "header-margin"], [1, "header-sticky"], ["lines", "none", 1, "header-radius", 3, "color"], ["interface", "popover", 1, "app-alert", 3, "interfaceOptions", "value", "ionChange"], [3, "value", 4, "ngFor", "ngForOf"], ["value", "GL"], [4, "ngIf"], [1, "white-line"], ["mode", "md", "scrollable", "", 1, "app-segment", 3, "ngModel", "ngModelChange", "ionChange"], ["checked", "", "mode", "ios", "class", "app-segment-button", 3, "value", "--radius", "--color", "--color-checked", 4, "ngFor", "ngForOf"], [1, "table-header"], ["size", "2"], ["fill", "clear", 3, "color", "click", 4, "ngIf"], ["size", "8"], [1, "ion-text-center", "period-value"], ["class", "ion-text-center total-value", 3, "color", 4, "ngIf"], [1, "chart-container"], ["id", "statsChart"], ["barCanvas", ""], [3, "value"], ["lines", "none", 3, "color"], ["interface", "popover", 3, "interfaceOptions", "value", "ionChange"], [3, "color"], ["checked", "", "mode", "ios", 1, "app-segment-button", 3, "value"], ["fill", "clear", 3, "click"], ["name", "chevron-back"], [1, "ion-text-center", "total-value"], ["name", "chevron-forward"]],
  template: function StatsTeamPage_Template(rf, ctx) {
    if (rf & 1) {
      _angular_core__WEBPACK_IMPORTED_MODULE_19__["ɵɵelement"](0, "ion-header", 0);
      _angular_core__WEBPACK_IMPORTED_MODULE_19__["ɵɵelementStart"](1, "ion-content", 1)(2, "div", 2)(3, "div", 3)(4, "ion-row")(5, "ion-col")(6, "ion-item", 4)(7, "ion-select", 5);
      _angular_core__WEBPACK_IMPORTED_MODULE_19__["ɵɵlistener"]("ionChange", function StatsTeamPage_Template_ion_select_ionChange_7_listener($event) {
        return ctx.selectedMeanChangedSubject.next($event);
      });
      _angular_core__WEBPACK_IMPORTED_MODULE_19__["ɵɵpipe"](8, "async");
      _angular_core__WEBPACK_IMPORTED_MODULE_19__["ɵɵtemplate"](9, StatsTeamPage_ion_select_option_9_Template, 3, 4, "ion-select-option", 6);
      _angular_core__WEBPACK_IMPORTED_MODULE_19__["ɵɵpipe"](10, "async");
      _angular_core__WEBPACK_IMPORTED_MODULE_19__["ɵɵelementStart"](11, "ion-select-option", 7);
      _angular_core__WEBPACK_IMPORTED_MODULE_19__["ɵɵtext"](12);
      _angular_core__WEBPACK_IMPORTED_MODULE_19__["ɵɵpipe"](13, "translate");
      _angular_core__WEBPACK_IMPORTED_MODULE_19__["ɵɵelementEnd"]()()()();
      _angular_core__WEBPACK_IMPORTED_MODULE_19__["ɵɵtemplate"](14, StatsTeamPage_ion_col_14_Template, 5, 7, "ion-col", 8);
      _angular_core__WEBPACK_IMPORTED_MODULE_19__["ɵɵpipe"](15, "async");
      _angular_core__WEBPACK_IMPORTED_MODULE_19__["ɵɵtemplate"](16, StatsTeamPage_ion_col_16_Template, 4, 4, "ion-col", 8);
      _angular_core__WEBPACK_IMPORTED_MODULE_19__["ɵɵpipe"](17, "async");
      _angular_core__WEBPACK_IMPORTED_MODULE_19__["ɵɵelementEnd"]();
      _angular_core__WEBPACK_IMPORTED_MODULE_19__["ɵɵelementStart"](18, "ion-row")(19, "ion-col");
      _angular_core__WEBPACK_IMPORTED_MODULE_19__["ɵɵelement"](20, "div", 9);
      _angular_core__WEBPACK_IMPORTED_MODULE_19__["ɵɵelementEnd"]()()();
      _angular_core__WEBPACK_IMPORTED_MODULE_19__["ɵɵelementStart"](21, "ion-segment", 10);
      _angular_core__WEBPACK_IMPORTED_MODULE_19__["ɵɵlistener"]("ngModelChange", function StatsTeamPage_Template_ion_segment_ngModelChange_21_listener($event) {
        return ctx.selectedSegment = $event;
      })("ionChange", function StatsTeamPage_Template_ion_segment_ionChange_21_listener($event) {
        ctx.segmentChanged($event);
        return ctx.statPeriodChangedSubject.next(ctx.selectedSegment);
      });
      _angular_core__WEBPACK_IMPORTED_MODULE_19__["ɵɵtemplate"](22, StatsTeamPage_ion_segment_button_22_Template, 4, 10, "ion-segment-button", 11);
      _angular_core__WEBPACK_IMPORTED_MODULE_19__["ɵɵelementEnd"]();
      _angular_core__WEBPACK_IMPORTED_MODULE_19__["ɵɵelementStart"](23, "ion-grid", 12)(24, "ion-row")(25, "ion-col", 13);
      _angular_core__WEBPACK_IMPORTED_MODULE_19__["ɵɵtemplate"](26, StatsTeamPage_ion_button_26_Template, 2, 2, "ion-button", 14);
      _angular_core__WEBPACK_IMPORTED_MODULE_19__["ɵɵelementEnd"]();
      _angular_core__WEBPACK_IMPORTED_MODULE_19__["ɵɵelementStart"](27, "ion-col", 15)(28, "p", 16);
      _angular_core__WEBPACK_IMPORTED_MODULE_19__["ɵɵtext"](29);
      _angular_core__WEBPACK_IMPORTED_MODULE_19__["ɵɵelementEnd"]();
      _angular_core__WEBPACK_IMPORTED_MODULE_19__["ɵɵtemplate"](30, StatsTeamPage_p_30_Template, 5, 11, "p", 17);
      _angular_core__WEBPACK_IMPORTED_MODULE_19__["ɵɵpipe"](31, "async");
      _angular_core__WEBPACK_IMPORTED_MODULE_19__["ɵɵtemplate"](32, StatsTeamPage_p_32_Template, 3, 6, "p", 17);
      _angular_core__WEBPACK_IMPORTED_MODULE_19__["ɵɵpipe"](33, "async");
      _angular_core__WEBPACK_IMPORTED_MODULE_19__["ɵɵelementEnd"]();
      _angular_core__WEBPACK_IMPORTED_MODULE_19__["ɵɵelementStart"](34, "ion-col", 13);
      _angular_core__WEBPACK_IMPORTED_MODULE_19__["ɵɵtemplate"](35, StatsTeamPage_ion_button_35_Template, 2, 2, "ion-button", 14);
      _angular_core__WEBPACK_IMPORTED_MODULE_19__["ɵɵelementEnd"]()()();
      _angular_core__WEBPACK_IMPORTED_MODULE_19__["ɵɵelementStart"](36, "div", 18);
      _angular_core__WEBPACK_IMPORTED_MODULE_19__["ɵɵelement"](37, "canvas", 19, 20);
      _angular_core__WEBPACK_IMPORTED_MODULE_19__["ɵɵelementEnd"]()()();
    }

    if (rf & 2) {
      _angular_core__WEBPACK_IMPORTED_MODULE_19__["ɵɵadvance"](1);
      _angular_core__WEBPACK_IMPORTED_MODULE_19__["ɵɵproperty"]("fullscreen", true);
      _angular_core__WEBPACK_IMPORTED_MODULE_19__["ɵɵadvance"](2);
      _angular_core__WEBPACK_IMPORTED_MODULE_19__["ɵɵstyleProp"]("color", "var(--ion-color-" + ctx.campaignContainer.campaign.type + "-stat-contrast)")("background-color", "var(--ion-color-" + ctx.campaignContainer.campaign.type + ")");
      _angular_core__WEBPACK_IMPORTED_MODULE_19__["ɵɵadvance"](3);
      _angular_core__WEBPACK_IMPORTED_MODULE_19__["ɵɵproperty"]("color", ctx.campaignContainer.campaign.type);
      _angular_core__WEBPACK_IMPORTED_MODULE_19__["ɵɵadvance"](1);
      _angular_core__WEBPACK_IMPORTED_MODULE_19__["ɵɵproperty"]("interfaceOptions", _angular_core__WEBPACK_IMPORTED_MODULE_19__["ɵɵpureFunction0"](41, _c2))("value", _angular_core__WEBPACK_IMPORTED_MODULE_19__["ɵɵpipeBind1"](8, 27, ctx.selectedMean$));
      _angular_core__WEBPACK_IMPORTED_MODULE_19__["ɵɵadvance"](2);
      _angular_core__WEBPACK_IMPORTED_MODULE_19__["ɵɵproperty"]("ngForOf", _angular_core__WEBPACK_IMPORTED_MODULE_19__["ɵɵpipeBind1"](10, 29, ctx.means$));
      _angular_core__WEBPACK_IMPORTED_MODULE_19__["ɵɵadvance"](3);
      _angular_core__WEBPACK_IMPORTED_MODULE_19__["ɵɵtextInterpolate1"](" ", _angular_core__WEBPACK_IMPORTED_MODULE_19__["ɵɵpipeBind1"](13, 31, ctx.meanLabels["GL"]), " ");
      _angular_core__WEBPACK_IMPORTED_MODULE_19__["ɵɵadvance"](2);
      _angular_core__WEBPACK_IMPORTED_MODULE_19__["ɵɵproperty"]("ngIf", _angular_core__WEBPACK_IMPORTED_MODULE_19__["ɵɵpipeBind1"](15, 33, ctx.selectedMean$) !== "GL");
      _angular_core__WEBPACK_IMPORTED_MODULE_19__["ɵɵadvance"](2);
      _angular_core__WEBPACK_IMPORTED_MODULE_19__["ɵɵproperty"]("ngIf", _angular_core__WEBPACK_IMPORTED_MODULE_19__["ɵɵpipeBind1"](17, 35, ctx.selectedMean$) === "GL");
      _angular_core__WEBPACK_IMPORTED_MODULE_19__["ɵɵadvance"](4);
      _angular_core__WEBPACK_IMPORTED_MODULE_19__["ɵɵstyleProp"]("background-color", "var(--ion-color-" + ctx.campaignContainer.campaign.type + "-stat-contrast)");
      _angular_core__WEBPACK_IMPORTED_MODULE_19__["ɵɵadvance"](1);
      _angular_core__WEBPACK_IMPORTED_MODULE_19__["ɵɵstyleProp"]("--background", "var(--ion-color-" + ctx.campaignContainer.campaign.type + ")");
      _angular_core__WEBPACK_IMPORTED_MODULE_19__["ɵɵproperty"]("ngModel", ctx.selectedSegment);
      _angular_core__WEBPACK_IMPORTED_MODULE_19__["ɵɵadvance"](1);
      _angular_core__WEBPACK_IMPORTED_MODULE_19__["ɵɵproperty"]("ngForOf", ctx.periods);
      _angular_core__WEBPACK_IMPORTED_MODULE_19__["ɵɵadvance"](1);
      _angular_core__WEBPACK_IMPORTED_MODULE_19__["ɵɵstyleProp"]("background-color", "var(--ion-color-" + ctx.campaignContainer.campaign.type + "-dark)");
      _angular_core__WEBPACK_IMPORTED_MODULE_19__["ɵɵadvance"](3);
      _angular_core__WEBPACK_IMPORTED_MODULE_19__["ɵɵproperty"]("ngIf", ctx.thereIsPast());
      _angular_core__WEBPACK_IMPORTED_MODULE_19__["ɵɵadvance"](2);
      _angular_core__WEBPACK_IMPORTED_MODULE_19__["ɵɵstyleProp"]("color", "var(--ion-color-" + ctx.campaignContainer.campaign.type + "-dark-contrast)");
      _angular_core__WEBPACK_IMPORTED_MODULE_19__["ɵɵadvance"](1);
      _angular_core__WEBPACK_IMPORTED_MODULE_19__["ɵɵtextInterpolate1"](" ", ctx.getSelectedPeriod(), " ");
      _angular_core__WEBPACK_IMPORTED_MODULE_19__["ɵɵadvance"](1);
      _angular_core__WEBPACK_IMPORTED_MODULE_19__["ɵɵproperty"]("ngIf", _angular_core__WEBPACK_IMPORTED_MODULE_19__["ɵɵpipeBind1"](31, 37, ctx.selectedMean$) !== "GL");
      _angular_core__WEBPACK_IMPORTED_MODULE_19__["ɵɵadvance"](2);
      _angular_core__WEBPACK_IMPORTED_MODULE_19__["ɵɵproperty"]("ngIf", _angular_core__WEBPACK_IMPORTED_MODULE_19__["ɵɵpipeBind1"](33, 39, ctx.selectedMean$) === "GL");
      _angular_core__WEBPACK_IMPORTED_MODULE_19__["ɵɵadvance"](3);
      _angular_core__WEBPACK_IMPORTED_MODULE_19__["ɵɵproperty"]("ngIf", ctx.thereIsFuture());
    }
  },
  directives: [_ionic_angular__WEBPACK_IMPORTED_MODULE_30__.IonHeader, _core_shared_layout_header_header_directive__WEBPACK_IMPORTED_MODULE_16__.HeaderDirective, _ionic_angular__WEBPACK_IMPORTED_MODULE_30__.IonContent, _core_shared_layout_content_content_directive__WEBPACK_IMPORTED_MODULE_17__.ContentDirective, _ionic_angular__WEBPACK_IMPORTED_MODULE_30__.IonRow, _ionic_angular__WEBPACK_IMPORTED_MODULE_30__.IonCol, _ionic_angular__WEBPACK_IMPORTED_MODULE_30__.IonItem, _ionic_angular__WEBPACK_IMPORTED_MODULE_30__.IonSelect, _ionic_angular__WEBPACK_IMPORTED_MODULE_30__.SelectValueAccessor, _angular_common__WEBPACK_IMPORTED_MODULE_31__.NgForOf, _ionic_angular__WEBPACK_IMPORTED_MODULE_30__.IonSelectOption, _angular_common__WEBPACK_IMPORTED_MODULE_31__.NgIf, _ionic_angular__WEBPACK_IMPORTED_MODULE_30__.IonSegment, _angular_forms__WEBPACK_IMPORTED_MODULE_32__.NgControlStatus, _angular_forms__WEBPACK_IMPORTED_MODULE_32__.NgModel, _ionic_angular__WEBPACK_IMPORTED_MODULE_30__.IonSegmentButton, _ionic_angular__WEBPACK_IMPORTED_MODULE_30__.IonLabel, _ionic_angular__WEBPACK_IMPORTED_MODULE_30__.IonGrid, _ionic_angular__WEBPACK_IMPORTED_MODULE_30__.IonButton, _ionic_angular__WEBPACK_IMPORTED_MODULE_30__.IonIcon],
  pipes: [_angular_common__WEBPACK_IMPORTED_MODULE_31__.AsyncPipe, _ngx_translate_core__WEBPACK_IMPORTED_MODULE_33__.TranslatePipe, _core_shared_pipes_localNumber_pipe__WEBPACK_IMPORTED_MODULE_18__.LocalNumberPipe],
  styles: [".header-margin[_ngcontent-%COMP%] {\n  margin: 8px;\n}\n.header-margin[_ngcontent-%COMP%]   ion-select[_ngcontent-%COMP%] {\n  font-weight: 500;\n  font-size: 17px;\n}\n.header-margin[_ngcontent-%COMP%]   .header-radius[_ngcontent-%COMP%] {\n  border-radius: 8px 8px 0 0;\n}\n.header-margin[_ngcontent-%COMP%]   .table-header[_ngcontent-%COMP%] {\n  font-size: 22px;\n}\n.header-margin[_ngcontent-%COMP%]   .period-value[_ngcontent-%COMP%] {\n  margin: 4px;\n  font-weight: 300;\n  font-size: 17px;\n  line-height: 20px;\n}\n.header-margin[_ngcontent-%COMP%]   .total-value[_ngcontent-%COMP%] {\n  margin: 4px;\n  font-weight: 500;\n  font-size: 14px;\n}\n.header-margin[_ngcontent-%COMP%]   .white-line[_ngcontent-%COMP%] {\n  height: 2px;\n}\n.chart-container[_ngcontent-%COMP%] {\n  position: relative;\n  height: calc(100vh - 400px);\n  width: 100%;\n}\n/*# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbInN0YXRzLnBhZ2Uuc2NzcyJdLCJuYW1lcyI6W10sIm1hcHBpbmdzIjoiQUFBQTtFQUNFLFdBQUE7QUFDRjtBQUFFO0VBQ0UsZ0JBQUE7RUFDQSxlQUFBO0FBRUo7QUFBRTtFQUNFLDBCQUFBO0FBRUo7QUFBRTtFQUNFLGVBQUE7QUFFSjtBQUFFO0VBQ0UsV0FBQTtFQUNBLGdCQUFBO0VBQ0EsZUFBQTtFQUNBLGlCQUFBO0FBRUo7QUFBRTtFQUNFLFdBQUE7RUFDQSxnQkFBQTtFQUNBLGVBQUE7QUFFSjtBQUFFO0VBQ0UsV0FBQTtBQUVKO0FBQ0E7RUFDRSxrQkFBQTtFQUNBLDJCQUFBO0VBQ0EsV0FBQTtBQUVGIiwiZmlsZSI6InN0YXRzLnBhZ2Uuc2NzcyIsInNvdXJjZXNDb250ZW50IjpbIi5oZWFkZXItbWFyZ2luIHtcbiAgbWFyZ2luOiA4cHg7XG4gIGlvbi1zZWxlY3Qge1xuICAgIGZvbnQtd2VpZ2h0OiA1MDA7XG4gICAgZm9udC1zaXplOiAxN3B4O1xuICB9XG4gIC5oZWFkZXItcmFkaXVzIHtcbiAgICBib3JkZXItcmFkaXVzOiA4cHggOHB4IDAgMDtcbiAgfVxuICAudGFibGUtaGVhZGVyIHtcbiAgICBmb250LXNpemU6IDIycHg7XG4gIH1cbiAgLnBlcmlvZC12YWx1ZSB7XG4gICAgbWFyZ2luOiA0cHg7XG4gICAgZm9udC13ZWlnaHQ6IDMwMDtcbiAgICBmb250LXNpemU6IDE3cHg7XG4gICAgbGluZS1oZWlnaHQ6IDIwcHg7XG4gIH1cbiAgLnRvdGFsLXZhbHVlIHtcbiAgICBtYXJnaW46IDRweDtcbiAgICBmb250LXdlaWdodDogNTAwO1xuICAgIGZvbnQtc2l6ZTogMTRweDtcbiAgfVxuICAud2hpdGUtbGluZSB7XG4gICAgaGVpZ2h0OiAycHg7XG4gIH1cbn1cbi5jaGFydC1jb250YWluZXIge1xuICBwb3NpdGlvbjogcmVsYXRpdmU7XG4gIGhlaWdodDogY2FsYygxMDB2aCAtIDQwMHB4KTtcbiAgd2lkdGg6IDEwMCU7XG59XG4iXX0= */"]
});
var ALL_MEANS = 'ALL_MEANS';
var GL = 'GL';

/***/ })

}]);
//# sourceMappingURL=src_app_pages_home_campaign-details_stats-team_stats-team_module_ts.js.map