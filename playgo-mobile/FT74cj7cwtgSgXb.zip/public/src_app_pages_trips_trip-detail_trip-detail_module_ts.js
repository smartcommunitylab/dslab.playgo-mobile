"use strict";
(self["webpackChunkapp"] = self["webpackChunkapp"] || []).push([["src_app_pages_trips_trip-detail_trip-detail_module_ts"],{

/***/ 17785:
/*!**************************************************************************************!*\
  !*** ./src/app/pages/trips/trip-detail/trip-detail-map/trip-detail-map.component.ts ***!
  \**************************************************************************************/
/***/ (function(__unused_webpack_module, __webpack_exports__, __webpack_require__) {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "TripDetailMapComponent": function() { return /* binding */ TripDetailMapComponent; }
/* harmony export */ });
/* harmony import */ var _Users_smartcommunitylab_Desktop_newWork_dslab_playgo_mobile_playgo_mobile_node_modules_babel_runtime_helpers_esm_classCallCheck_js__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./node_modules/@babel/runtime/helpers/esm/classCallCheck.js */ 78069);
/* harmony import */ var _Users_smartcommunitylab_Desktop_newWork_dslab_playgo_mobile_playgo_mobile_node_modules_babel_runtime_helpers_esm_createClass_js__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ./node_modules/@babel/runtime/helpers/esm/createClass.js */ 48047);
/* harmony import */ var leaflet__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! leaflet */ 5836);
/* harmony import */ var leaflet__WEBPACK_IMPORTED_MODULE_2___default = /*#__PURE__*/__webpack_require__.n(leaflet__WEBPACK_IMPORTED_MODULE_2__);
/* harmony import */ var rxjs__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! rxjs */ 26067);
/* harmony import */ var rxjs__WEBPACK_IMPORTED_MODULE_12__ = __webpack_require__(/*! rxjs */ 80228);
/* harmony import */ var rxjs_operators__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(/*! rxjs/operators */ 50635);
/* harmony import */ var rxjs_operators__WEBPACK_IMPORTED_MODULE_9__ = __webpack_require__(/*! rxjs/operators */ 89196);
/* harmony import */ var rxjs_operators__WEBPACK_IMPORTED_MODULE_13__ = __webpack_require__(/*! rxjs/operators */ 68951);
/* harmony import */ var lodash_es__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(/*! lodash-es */ 90112);
/* harmony import */ var lodash_es__WEBPACK_IMPORTED_MODULE_10__ = __webpack_require__(/*! lodash-es */ 36427);
/* harmony import */ var lodash_es__WEBPACK_IMPORTED_MODULE_11__ = __webpack_require__(/*! lodash-es */ 10757);
/* harmony import */ var src_app_core_shared_tracking_trip_model__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! src/app/core/shared/tracking/trip.model */ 49110);
/* harmony import */ var _googlemaps_polyline_codec__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! @googlemaps/polyline-codec */ 59922);
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! @angular/core */ 3184);
/* harmony import */ var _asymmetrik_ngx_leaflet__WEBPACK_IMPORTED_MODULE_14__ = __webpack_require__(/*! @asymmetrik/ngx-leaflet */ 73066);
/* harmony import */ var _angular_common__WEBPACK_IMPORTED_MODULE_15__ = __webpack_require__(/*! @angular/common */ 36362);












function TripDetailMapComponent_ng_container_1_Template(rf, ctx) {
  if (rf & 1) {
    _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵelementContainerStart"](0);
    _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵelement"](1, "div", 2);
    _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵelementContainerEnd"]();
  }

  if (rf & 2) {
    var layer_r1 = ctx.$implicit;
    _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵadvance"](1);
    _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵproperty"]("leafletLayer", layer_r1);
  }
}

var TripDetailMapComponent = /*#__PURE__*/function () {
  function TripDetailMapComponent() {
    (0,_Users_smartcommunitylab_Desktop_newWork_dslab_playgo_mobile_playgo_mobile_node_modules_babel_runtime_helpers_esm_classCallCheck_js__WEBPACK_IMPORTED_MODULE_0__["default"])(this, TripDetailMapComponent);

    this.tripPartsSubject = new rxjs__WEBPACK_IMPORTED_MODULE_6__.ReplaySubject(1);
    this.mapOptions = {
      layers: [(0,leaflet__WEBPACK_IMPORTED_MODULE_2__.tileLayer)('http://{s}.tile.openstreetmap.org/{z}/{x}/{y}.png', {
        maxZoom: 19,
        minZoom: 10,
        attribution: '&copy; <a href="http://www.openstreetmap.org/copyright">OpenStreetMap</a>'
      })]
    };
    this.tripPartsDecoded$ = this.tripPartsSubject.pipe((0,rxjs_operators__WEBPACK_IMPORTED_MODULE_7__.map)(function (tripParts) {
      return (0,lodash_es__WEBPACK_IMPORTED_MODULE_8__["default"])(tripParts, function (tripPart) {
        var decoded = (0,_googlemaps_polyline_codec__WEBPACK_IMPORTED_MODULE_4__.decode)(tripPart.polyline);
        return Object.assign(Object.assign({}, tripPart), {
          polyline: decoded
        });
      });
    }), (0,rxjs_operators__WEBPACK_IMPORTED_MODULE_9__.shareReplay)(1));
    this.fullPolyLineCoords$ = this.tripPartsDecoded$.pipe((0,rxjs_operators__WEBPACK_IMPORTED_MODULE_7__.map)(function (tripParts) {
      var polylines = tripParts.map(function (tripPart) {
        return tripPart.polyline;
      });
      var mergedParts = [].concat.apply([], polylines);
      return mergedParts;
    }));
    this.startMarker$ = this.fullPolyLineCoords$.pipe((0,rxjs_operators__WEBPACK_IMPORTED_MODULE_7__.map)(lodash_es__WEBPACK_IMPORTED_MODULE_10__["default"]), (0,rxjs_operators__WEBPACK_IMPORTED_MODULE_7__.map)(function (coordinate) {
      return (0,leaflet__WEBPACK_IMPORTED_MODULE_2__.marker)((0,leaflet__WEBPACK_IMPORTED_MODULE_2__.latLng)(coordinate), {
        icon: (0,leaflet__WEBPACK_IMPORTED_MODULE_2__.icon)(Object.assign(Object.assign({}, leaflet__WEBPACK_IMPORTED_MODULE_2__.Icon.Default.prototype.options), {
          // TODO: set proper svg icon
          iconUrl: 'assets/images/map/markerStart-icon.png',
          iconRetinaUrl: 'assets/images/map/markerStart-icon-2x.png',
          shadowUrl: 'assets/images/map/marker-shadow.png'
        }))
      });
    }));
    this.endMarker$ = this.fullPolyLineCoords$.pipe((0,rxjs_operators__WEBPACK_IMPORTED_MODULE_7__.map)(lodash_es__WEBPACK_IMPORTED_MODULE_11__["default"]), (0,rxjs_operators__WEBPACK_IMPORTED_MODULE_7__.map)(function (coordinate) {
      return (0,leaflet__WEBPACK_IMPORTED_MODULE_2__.marker)((0,leaflet__WEBPACK_IMPORTED_MODULE_2__.latLng)(coordinate), {
        icon: (0,leaflet__WEBPACK_IMPORTED_MODULE_2__.icon)(Object.assign(Object.assign({}, leaflet__WEBPACK_IMPORTED_MODULE_2__.Icon.Default.prototype.options), {
          // TODO: set proper svg icon
          iconUrl: 'assets/images/map/markerStop-icon.png',
          iconRetinaUrl: 'assets/images/map/markerStop-icon-2x.png',
          shadowUrl: 'assets/images/map/marker-shadow.png'
        }))
      });
    }));
    this.tripPartLineLayers$ = this.tripPartsDecoded$.pipe((0,rxjs_operators__WEBPACK_IMPORTED_MODULE_7__.map)(function (tripParts) {
      return (0,lodash_es__WEBPACK_IMPORTED_MODULE_8__["default"])(tripParts, function (eachPart) {
        return (0,leaflet__WEBPACK_IMPORTED_MODULE_2__.polyline)(eachPart.polyline, {
          color: src_app_core_shared_tracking_trip_model__WEBPACK_IMPORTED_MODULE_3__.transportTypeColors[eachPart.modeType]
        });
      });
    }), (0,rxjs_operators__WEBPACK_IMPORTED_MODULE_9__.shareReplay)(1));
    this.tripBounds$ = this.fullPolyLineCoords$.pipe((0,rxjs_operators__WEBPACK_IMPORTED_MODULE_7__.map)(function (fullPolyLineCoords) {
      var bounds = (0,leaflet__WEBPACK_IMPORTED_MODULE_2__.polyline)(fullPolyLineCoords).getBounds();
      var southNorthDistance = bounds.getNorth() - bounds.getSouth();
      var boundsWithSpaceForDetail = (0,leaflet__WEBPACK_IMPORTED_MODULE_2__.latLngBounds)((0,leaflet__WEBPACK_IMPORTED_MODULE_2__.latLng)(bounds.getNorth() - 2 * southNorthDistance, bounds.getWest()), bounds.getNorthEast());
      return boundsWithSpaceForDetail;
    }));
    this.componentDestroyed$ = new rxjs__WEBPACK_IMPORTED_MODULE_12__.Subject();
  }

  (0,_Users_smartcommunitylab_Desktop_newWork_dslab_playgo_mobile_playgo_mobile_node_modules_babel_runtime_helpers_esm_createClass_js__WEBPACK_IMPORTED_MODULE_1__["default"])(TripDetailMapComponent, [{
    key: "tripParts",
    set: function set(tripParts) {
      console.log('tripParts', tripParts);
      this.tripPartsSubject.next(tripParts);
    }
  }, {
    key: "onMapReady",
    value: function onMapReady(mapInstance) {
      this.initMap(mapInstance);
      mapInstance.invalidateSize();
      setTimeout(function () {
        mapInstance.invalidateSize();
      }, 500);
    }
  }, {
    key: "initMap",
    value: function initMap(mapInstance) {
      this.tripBounds$.pipe((0,rxjs_operators__WEBPACK_IMPORTED_MODULE_13__.takeUntil)(this.componentDestroyed$)).subscribe(function (bounds) {
        mapInstance.fitBounds(bounds);
      });
    }
  }, {
    key: "ngOnInit",
    value: function ngOnInit() {}
  }, {
    key: "ngOnDestroy",
    value: function ngOnDestroy() {}
  }, {
    key: "ionViewDidLeave",
    value: function ionViewDidLeave() {
      this.componentDestroyed$.next(true);
      this.componentDestroyed$.complete();
    }
  }]);

  return TripDetailMapComponent;
}();

TripDetailMapComponent.ɵfac = function TripDetailMapComponent_Factory(t) {
  return new (t || TripDetailMapComponent)();
};

TripDetailMapComponent.ɵcmp = /*@__PURE__*/_angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵdefineComponent"]({
  type: TripDetailMapComponent,
  selectors: [["app-trip-detail-map"]],
  inputs: {
    tripParts: "tripParts"
  },
  decls: 7,
  vars: 10,
  consts: [["leaflet", "", 1, "ngx-leaflet", 3, "leafletOptions", "leafletMapReady"], [4, "ngFor", "ngForOf"], [3, "leafletLayer"]],
  template: function TripDetailMapComponent_Template(rf, ctx) {
    if (rf & 1) {
      _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵelementStart"](0, "div", 0);
      _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵlistener"]("leafletMapReady", function TripDetailMapComponent_Template_div_leafletMapReady_0_listener($event) {
        return ctx.onMapReady($event);
      });
      _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵtemplate"](1, TripDetailMapComponent_ng_container_1_Template, 2, 1, "ng-container", 1);
      _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵpipe"](2, "async");
      _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵelement"](3, "div", 2);
      _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵpipe"](4, "async");
      _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵelement"](5, "div", 2);
      _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵpipe"](6, "async");
      _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵelementEnd"]();
    }

    if (rf & 2) {
      _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵproperty"]("leafletOptions", ctx.mapOptions);
      _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵadvance"](1);
      _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵproperty"]("ngForOf", _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵpipeBind1"](2, 4, ctx.tripPartLineLayers$));
      _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵadvance"](2);
      _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵproperty"]("leafletLayer", _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵpipeBind1"](4, 6, ctx.startMarker$));
      _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵadvance"](2);
      _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵproperty"]("leafletLayer", _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵpipeBind1"](6, 8, ctx.endMarker$));
    }
  },
  directives: [_asymmetrik_ngx_leaflet__WEBPACK_IMPORTED_MODULE_14__.LeafletDirective, _angular_common__WEBPACK_IMPORTED_MODULE_15__.NgForOf, _asymmetrik_ngx_leaflet__WEBPACK_IMPORTED_MODULE_14__.LeafletLayerDirective],
  pipes: [_angular_common__WEBPACK_IMPORTED_MODULE_15__.AsyncPipe],
  styles: ["[_nghost-%COMP%] {\n  display: block;\n  height: 100%;\n  position: relative;\n}\n[_nghost-%COMP%]   .ngx-leaflet[_ngcontent-%COMP%] {\n  height: 100%;\n}\n/*# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbInRyaXAtZGV0YWlsLW1hcC5jb21wb25lbnQuc2NzcyJdLCJuYW1lcyI6W10sIm1hcHBpbmdzIjoiQUFBQTtFQUNFLGNBQUE7RUFDQSxZQUFBO0VBQ0Esa0JBQUE7QUFDRjtBQUFFO0VBQ0UsWUFBQTtBQUVKIiwiZmlsZSI6InRyaXAtZGV0YWlsLW1hcC5jb21wb25lbnQuc2NzcyIsInNvdXJjZXNDb250ZW50IjpbIjpob3N0IHtcbiAgZGlzcGxheTogYmxvY2s7XG4gIGhlaWdodDogMTAwJTtcbiAgcG9zaXRpb246IHJlbGF0aXZlO1xuICAubmd4LWxlYWZsZXQge1xuICAgIGhlaWdodDogMTAwJTtcbiAgfVxufVxuIl19 */"]
});

/***/ }),

/***/ 67113:
/*!***********************************************************************!*\
  !*** ./src/app/pages/trips/trip-detail/trip-detail-routing.module.ts ***!
  \***********************************************************************/
/***/ (function(__unused_webpack_module, __webpack_exports__, __webpack_require__) {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "TripDetailPageRoutingModule": function() { return /* binding */ TripDetailPageRoutingModule; }
/* harmony export */ });
/* harmony import */ var _Users_smartcommunitylab_Desktop_newWork_dslab_playgo_mobile_playgo_mobile_node_modules_babel_runtime_helpers_esm_createClass_js__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./node_modules/@babel/runtime/helpers/esm/createClass.js */ 48047);
/* harmony import */ var _Users_smartcommunitylab_Desktop_newWork_dslab_playgo_mobile_playgo_mobile_node_modules_babel_runtime_helpers_esm_classCallCheck_js__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ./node_modules/@babel/runtime/helpers/esm/classCallCheck.js */ 78069);
/* harmony import */ var _angular_router__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! @angular/router */ 52816);
/* harmony import */ var _trip_detail_page__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! ./trip-detail.page */ 16159);
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @angular/core */ 3184);






var routes = [{
  path: '',
  component: _trip_detail_page__WEBPACK_IMPORTED_MODULE_2__.TripDetailPage,
  data: {
    title: 'tripDetailTitle',
    defaultHref: '/pages/tabs/trips'
  }
}];
var TripDetailPageRoutingModule = /*#__PURE__*/(0,_Users_smartcommunitylab_Desktop_newWork_dslab_playgo_mobile_playgo_mobile_node_modules_babel_runtime_helpers_esm_createClass_js__WEBPACK_IMPORTED_MODULE_0__["default"])(function TripDetailPageRoutingModule() {
  (0,_Users_smartcommunitylab_Desktop_newWork_dslab_playgo_mobile_playgo_mobile_node_modules_babel_runtime_helpers_esm_classCallCheck_js__WEBPACK_IMPORTED_MODULE_1__["default"])(this, TripDetailPageRoutingModule);
});

TripDetailPageRoutingModule.ɵfac = function TripDetailPageRoutingModule_Factory(t) {
  return new (t || TripDetailPageRoutingModule)();
};

TripDetailPageRoutingModule.ɵmod = /*@__PURE__*/_angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵdefineNgModule"]({
  type: TripDetailPageRoutingModule
});
TripDetailPageRoutingModule.ɵinj = /*@__PURE__*/_angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵdefineInjector"]({
  imports: [[_angular_router__WEBPACK_IMPORTED_MODULE_4__.RouterModule.forChild(routes)], _angular_router__WEBPACK_IMPORTED_MODULE_4__.RouterModule]
});

(function () {
  (typeof ngJitMode === "undefined" || ngJitMode) && _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵsetNgModuleScope"](TripDetailPageRoutingModule, {
    imports: [_angular_router__WEBPACK_IMPORTED_MODULE_4__.RouterModule],
    exports: [_angular_router__WEBPACK_IMPORTED_MODULE_4__.RouterModule]
  });
})();

/***/ }),

/***/ 35926:
/*!***************************************************************!*\
  !*** ./src/app/pages/trips/trip-detail/trip-detail.module.ts ***!
  \***************************************************************/
/***/ (function(__unused_webpack_module, __webpack_exports__, __webpack_require__) {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "TripDetailPageModule": function() { return /* binding */ TripDetailPageModule; }
/* harmony export */ });
/* harmony import */ var _Users_smartcommunitylab_Desktop_newWork_dslab_playgo_mobile_playgo_mobile_node_modules_babel_runtime_helpers_esm_createClass_js__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./node_modules/@babel/runtime/helpers/esm/createClass.js */ 48047);
/* harmony import */ var _Users_smartcommunitylab_Desktop_newWork_dslab_playgo_mobile_playgo_mobile_node_modules_babel_runtime_helpers_esm_classCallCheck_js__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ./node_modules/@babel/runtime/helpers/esm/classCallCheck.js */ 78069);
/* harmony import */ var _trip_detail_routing_module__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! ./trip-detail-routing.module */ 67113);
/* harmony import */ var _trip_detail_page__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! ./trip-detail.page */ 16159);
/* harmony import */ var src_app_core_shared_shared_module__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! src/app/core/shared/shared.module */ 97205);
/* harmony import */ var _trip_detail_map_trip_detail_map_component__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! ./trip-detail-map/trip-detail-map.component */ 17785);
/* harmony import */ var _asymmetrik_ngx_leaflet__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(/*! @asymmetrik/ngx-leaflet */ 73066);
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! @angular/core */ 3184);








var TripDetailPageModule = /*#__PURE__*/(0,_Users_smartcommunitylab_Desktop_newWork_dslab_playgo_mobile_playgo_mobile_node_modules_babel_runtime_helpers_esm_createClass_js__WEBPACK_IMPORTED_MODULE_0__["default"])(function TripDetailPageModule() {
  (0,_Users_smartcommunitylab_Desktop_newWork_dslab_playgo_mobile_playgo_mobile_node_modules_babel_runtime_helpers_esm_classCallCheck_js__WEBPACK_IMPORTED_MODULE_1__["default"])(this, TripDetailPageModule);
});

TripDetailPageModule.ɵfac = function TripDetailPageModule_Factory(t) {
  return new (t || TripDetailPageModule)();
};

TripDetailPageModule.ɵmod = /*@__PURE__*/_angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵdefineNgModule"]({
  type: TripDetailPageModule
});
TripDetailPageModule.ɵinj = /*@__PURE__*/_angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵdefineInjector"]({
  imports: [[src_app_core_shared_shared_module__WEBPACK_IMPORTED_MODULE_4__.PlayGoSharedModule, _trip_detail_routing_module__WEBPACK_IMPORTED_MODULE_2__.TripDetailPageRoutingModule, _asymmetrik_ngx_leaflet__WEBPACK_IMPORTED_MODULE_7__.LeafletModule]]
});

(function () {
  (typeof ngJitMode === "undefined" || ngJitMode) && _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵsetNgModuleScope"](TripDetailPageModule, {
    declarations: [_trip_detail_page__WEBPACK_IMPORTED_MODULE_3__.TripDetailPage, _trip_detail_map_trip_detail_map_component__WEBPACK_IMPORTED_MODULE_5__.TripDetailMapComponent],
    imports: [src_app_core_shared_shared_module__WEBPACK_IMPORTED_MODULE_4__.PlayGoSharedModule, _trip_detail_routing_module__WEBPACK_IMPORTED_MODULE_2__.TripDetailPageRoutingModule, _asymmetrik_ngx_leaflet__WEBPACK_IMPORTED_MODULE_7__.LeafletModule]
  });
})();

/***/ }),

/***/ 16159:
/*!*************************************************************!*\
  !*** ./src/app/pages/trips/trip-detail/trip-detail.page.ts ***!
  \*************************************************************/
/***/ (function(__unused_webpack_module, __webpack_exports__, __webpack_require__) {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "TripDetailPage": function() { return /* binding */ TripDetailPage; }
/* harmony export */ });
/* harmony import */ var _Users_smartcommunitylab_Desktop_newWork_dslab_playgo_mobile_playgo_mobile_node_modules_babel_runtime_helpers_esm_classCallCheck_js__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./node_modules/@babel/runtime/helpers/esm/classCallCheck.js */ 78069);
/* harmony import */ var _Users_smartcommunitylab_Desktop_newWork_dslab_playgo_mobile_playgo_mobile_node_modules_babel_runtime_helpers_esm_createClass_js__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ./node_modules/@babel/runtime/helpers/esm/createClass.js */ 48047);
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_16__ = __webpack_require__(/*! tslib */ 42321);
/* harmony import */ var rxjs__WEBPACK_IMPORTED_MODULE_17__ = __webpack_require__(/*! rxjs */ 50635);
/* harmony import */ var src_app_core_shared_tracking_trip_model__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! src/app/core/shared/tracking/trip.model */ 49110);
/* harmony import */ var src_app_core_shared_utils__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! src/app/core/shared/utils */ 68647);
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_15__ = __webpack_require__(/*! @angular/core */ 3184);
/* harmony import */ var _angular_router__WEBPACK_IMPORTED_MODULE_18__ = __webpack_require__(/*! @angular/router */ 52816);
/* harmony import */ var src_app_core_shared_services_error_service__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! src/app/core/shared/services/error.service */ 96204);
/* harmony import */ var src_app_core_shared_tracking_track_api_service__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! src/app/core/shared/tracking/track-api.service */ 17688);
/* harmony import */ var src_app_core_shared_services_campaign_service__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! src/app/core/shared/services/campaign.service */ 23645);
/* harmony import */ var src_app_core_shared_services_alert_service__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(/*! src/app/core/shared/services/alert.service */ 46407);
/* harmony import */ var _ionic_angular__WEBPACK_IMPORTED_MODULE_19__ = __webpack_require__(/*! @ionic/angular */ 93819);
/* harmony import */ var _core_shared_layout_header_header_directive__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(/*! ../../../core/shared/layout/header/header.directive */ 34161);
/* harmony import */ var _core_shared_layout_content_content_directive__WEBPACK_IMPORTED_MODULE_9__ = __webpack_require__(/*! ../../../core/shared/layout/content/content.directive */ 69669);
/* harmony import */ var _angular_common__WEBPACK_IMPORTED_MODULE_20__ = __webpack_require__(/*! @angular/common */ 36362);
/* harmony import */ var _trip_detail_map_trip_detail_map_component__WEBPACK_IMPORTED_MODULE_10__ = __webpack_require__(/*! ./trip-detail-map/trip-detail-map.component */ 17785);
/* harmony import */ var _core_shared_ui_icon_icon_component__WEBPACK_IMPORTED_MODULE_11__ = __webpack_require__(/*! ../../../core/shared/ui/icon/icon.component */ 71888);
/* harmony import */ var _ngx_translate_core__WEBPACK_IMPORTED_MODULE_21__ = __webpack_require__(/*! @ngx-translate/core */ 87514);
/* harmony import */ var _core_shared_pipes_localDate_pipe__WEBPACK_IMPORTED_MODULE_12__ = __webpack_require__(/*! ../../../core/shared/pipes/localDate.pipe */ 34489);
/* harmony import */ var _core_shared_pipes_localNumber_pipe__WEBPACK_IMPORTED_MODULE_13__ = __webpack_require__(/*! ../../../core/shared/pipes/localNumber.pipe */ 89713);
/* harmony import */ var _core_shared_pipes_languageMap_pipe__WEBPACK_IMPORTED_MODULE_14__ = __webpack_require__(/*! ../../../core/shared/pipes/languageMap.pipe */ 73088);



function _regeneratorRuntime() { "use strict"; /*! regenerator-runtime -- Copyright (c) 2014-present, Facebook, Inc. -- license (MIT): https://github.com/facebook/regenerator/blob/main/LICENSE */ _regeneratorRuntime = function _regeneratorRuntime() { return e; }; var t, e = {}, r = Object.prototype, n = r.hasOwnProperty, o = Object.defineProperty || function (t, e, r) { t[e] = r.value; }, i = "function" == typeof Symbol ? Symbol : {}, a = i.iterator || "@@iterator", c = i.asyncIterator || "@@asyncIterator", u = i.toStringTag || "@@toStringTag"; function define(t, e, r) { return Object.defineProperty(t, e, { value: r, enumerable: !0, configurable: !0, writable: !0 }), t[e]; } try { define({}, ""); } catch (t) { define = function define(t, e, r) { return t[e] = r; }; } function wrap(t, e, r, n) { var i = e && e.prototype instanceof Generator ? e : Generator, a = Object.create(i.prototype), c = new Context(n || []); return o(a, "_invoke", { value: makeInvokeMethod(t, r, c) }), a; } function tryCatch(t, e, r) { try { return { type: "normal", arg: t.call(e, r) }; } catch (t) { return { type: "throw", arg: t }; } } e.wrap = wrap; var h = "suspendedStart", l = "suspendedYield", f = "executing", s = "completed", y = {}; function Generator() {} function GeneratorFunction() {} function GeneratorFunctionPrototype() {} var p = {}; define(p, a, function () { return this; }); var d = Object.getPrototypeOf, v = d && d(d(values([]))); v && v !== r && n.call(v, a) && (p = v); var g = GeneratorFunctionPrototype.prototype = Generator.prototype = Object.create(p); function defineIteratorMethods(t) { ["next", "throw", "return"].forEach(function (e) { define(t, e, function (t) { return this._invoke(e, t); }); }); } function AsyncIterator(t, e) { function invoke(r, o, i, a) { var c = tryCatch(t[r], t, o); if ("throw" !== c.type) { var u = c.arg, h = u.value; return h && "object" == typeof h && n.call(h, "__await") ? e.resolve(h.__await).then(function (t) { invoke("next", t, i, a); }, function (t) { invoke("throw", t, i, a); }) : e.resolve(h).then(function (t) { u.value = t, i(u); }, function (t) { return invoke("throw", t, i, a); }); } a(c.arg); } var r; o(this, "_invoke", { value: function value(t, n) { function callInvokeWithMethodAndArg() { return new e(function (e, r) { invoke(t, n, e, r); }); } return r = r ? r.then(callInvokeWithMethodAndArg, callInvokeWithMethodAndArg) : callInvokeWithMethodAndArg(); } }); } function makeInvokeMethod(e, r, n) { var o = h; return function (i, a) { if (o === f) throw new Error("Generator is already running"); if (o === s) { if ("throw" === i) throw a; return { value: t, done: !0 }; } for (n.method = i, n.arg = a;;) { var c = n.delegate; if (c) { var u = maybeInvokeDelegate(c, n); if (u) { if (u === y) continue; return u; } } if ("next" === n.method) n.sent = n._sent = n.arg;else if ("throw" === n.method) { if (o === h) throw o = s, n.arg; n.dispatchException(n.arg); } else "return" === n.method && n.abrupt("return", n.arg); o = f; var p = tryCatch(e, r, n); if ("normal" === p.type) { if (o = n.done ? s : l, p.arg === y) continue; return { value: p.arg, done: n.done }; } "throw" === p.type && (o = s, n.method = "throw", n.arg = p.arg); } }; } function maybeInvokeDelegate(e, r) { var n = r.method, o = e.iterator[n]; if (o === t) return r.delegate = null, "throw" === n && e.iterator.return && (r.method = "return", r.arg = t, maybeInvokeDelegate(e, r), "throw" === r.method) || "return" !== n && (r.method = "throw", r.arg = new TypeError("The iterator does not provide a '" + n + "' method")), y; var i = tryCatch(o, e.iterator, r.arg); if ("throw" === i.type) return r.method = "throw", r.arg = i.arg, r.delegate = null, y; var a = i.arg; return a ? a.done ? (r[e.resultName] = a.value, r.next = e.nextLoc, "return" !== r.method && (r.method = "next", r.arg = t), r.delegate = null, y) : a : (r.method = "throw", r.arg = new TypeError("iterator result is not an object"), r.delegate = null, y); } function pushTryEntry(t) { var e = { tryLoc: t[0] }; 1 in t && (e.catchLoc = t[1]), 2 in t && (e.finallyLoc = t[2], e.afterLoc = t[3]), this.tryEntries.push(e); } function resetTryEntry(t) { var e = t.completion || {}; e.type = "normal", delete e.arg, t.completion = e; } function Context(t) { this.tryEntries = [{ tryLoc: "root" }], t.forEach(pushTryEntry, this), this.reset(!0); } function values(e) { if (e || "" === e) { var r = e[a]; if (r) return r.call(e); if ("function" == typeof e.next) return e; if (!isNaN(e.length)) { var o = -1, i = function next() { for (; ++o < e.length;) if (n.call(e, o)) return next.value = e[o], next.done = !1, next; return next.value = t, next.done = !0, next; }; return i.next = i; } } throw new TypeError(typeof e + " is not iterable"); } return GeneratorFunction.prototype = GeneratorFunctionPrototype, o(g, "constructor", { value: GeneratorFunctionPrototype, configurable: !0 }), o(GeneratorFunctionPrototype, "constructor", { value: GeneratorFunction, configurable: !0 }), GeneratorFunction.displayName = define(GeneratorFunctionPrototype, u, "GeneratorFunction"), e.isGeneratorFunction = function (t) { var e = "function" == typeof t && t.constructor; return !!e && (e === GeneratorFunction || "GeneratorFunction" === (e.displayName || e.name)); }, e.mark = function (t) { return Object.setPrototypeOf ? Object.setPrototypeOf(t, GeneratorFunctionPrototype) : (t.__proto__ = GeneratorFunctionPrototype, define(t, u, "GeneratorFunction")), t.prototype = Object.create(g), t; }, e.awrap = function (t) { return { __await: t }; }, defineIteratorMethods(AsyncIterator.prototype), define(AsyncIterator.prototype, c, function () { return this; }), e.AsyncIterator = AsyncIterator, e.async = function (t, r, n, o, i) { void 0 === i && (i = Promise); var a = new AsyncIterator(wrap(t, r, n, o), i); return e.isGeneratorFunction(r) ? a : a.next().then(function (t) { return t.done ? t.value : a.next(); }); }, defineIteratorMethods(g), define(g, u, "Generator"), define(g, a, function () { return this; }), define(g, "toString", function () { return "[object Generator]"; }), e.keys = function (t) { var e = Object(t), r = []; for (var n in e) r.push(n); return r.reverse(), function next() { for (; r.length;) { var t = r.pop(); if (t in e) return next.value = t, next.done = !1, next; } return next.done = !0, next; }; }, e.values = values, Context.prototype = { constructor: Context, reset: function reset(e) { if (this.prev = 0, this.next = 0, this.sent = this._sent = t, this.done = !1, this.delegate = null, this.method = "next", this.arg = t, this.tryEntries.forEach(resetTryEntry), !e) for (var r in this) "t" === r.charAt(0) && n.call(this, r) && !isNaN(+r.slice(1)) && (this[r] = t); }, stop: function stop() { this.done = !0; var t = this.tryEntries[0].completion; if ("throw" === t.type) throw t.arg; return this.rval; }, dispatchException: function dispatchException(e) { if (this.done) throw e; var r = this; function handle(n, o) { return a.type = "throw", a.arg = e, r.next = n, o && (r.method = "next", r.arg = t), !!o; } for (var o = this.tryEntries.length - 1; o >= 0; --o) { var i = this.tryEntries[o], a = i.completion; if ("root" === i.tryLoc) return handle("end"); if (i.tryLoc <= this.prev) { var c = n.call(i, "catchLoc"), u = n.call(i, "finallyLoc"); if (c && u) { if (this.prev < i.catchLoc) return handle(i.catchLoc, !0); if (this.prev < i.finallyLoc) return handle(i.finallyLoc); } else if (c) { if (this.prev < i.catchLoc) return handle(i.catchLoc, !0); } else { if (!u) throw new Error("try statement without catch or finally"); if (this.prev < i.finallyLoc) return handle(i.finallyLoc); } } } }, abrupt: function abrupt(t, e) { for (var r = this.tryEntries.length - 1; r >= 0; --r) { var o = this.tryEntries[r]; if (o.tryLoc <= this.prev && n.call(o, "finallyLoc") && this.prev < o.finallyLoc) { var i = o; break; } } i && ("break" === t || "continue" === t) && i.tryLoc <= e && e <= i.finallyLoc && (i = null); var a = i ? i.completion : {}; return a.type = t, a.arg = e, i ? (this.method = "next", this.next = i.finallyLoc, y) : this.complete(a); }, complete: function complete(t, e) { if ("throw" === t.type) throw t.arg; return "break" === t.type || "continue" === t.type ? this.next = t.arg : "return" === t.type ? (this.rval = this.arg = t.arg, this.method = "return", this.next = "end") : "normal" === t.type && e && (this.next = e), y; }, finish: function finish(t) { for (var e = this.tryEntries.length - 1; e >= 0; --e) { var r = this.tryEntries[e]; if (r.finallyLoc === t) return this.complete(r.completion, r.afterLoc), resetTryEntry(r), y; } }, catch: function _catch(t) { for (var e = this.tryEntries.length - 1; e >= 0; --e) { var r = this.tryEntries[e]; if (r.tryLoc === t) { var n = r.completion; if ("throw" === n.type) { var o = n.arg; resetTryEntry(r); } return o; } } throw new Error("illegal catch attempt"); }, delegateYield: function delegateYield(e, r, n) { return this.delegate = { iterator: values(e), resultName: r, nextLoc: n }, "next" === this.method && (this.arg = t), y; } }, e; }






















var _c0 = function _c0(a0) {
  return [a0];
};

function TripDetailPage_ng_container_2_app_trip_detail_map_1_Template(rf, ctx) {
  if (rf & 1) {
    _angular_core__WEBPACK_IMPORTED_MODULE_15__["ɵɵelement"](0, "app-trip-detail-map", 14);
  }

  if (rf & 2) {
    var ctx_r1 = _angular_core__WEBPACK_IMPORTED_MODULE_15__["ɵɵnextContext"](2);
    _angular_core__WEBPACK_IMPORTED_MODULE_15__["ɵɵproperty"]("tripParts", _angular_core__WEBPACK_IMPORTED_MODULE_15__["ɵɵpureFunction1"](1, _c0, ctx_r1.tripDetail));
  }
}

function TripDetailPage_ng_container_2_ion_grid_2_Template(rf, ctx) {
  if (rf & 1) {
    _angular_core__WEBPACK_IMPORTED_MODULE_15__["ɵɵelementStart"](0, "ion-grid")(1, "ion-row")(2, "ion-col")(3, "div", 15)(4, "strong");
    _angular_core__WEBPACK_IMPORTED_MODULE_15__["ɵɵtext"](5);
    _angular_core__WEBPACK_IMPORTED_MODULE_15__["ɵɵpipe"](6, "translate");
    _angular_core__WEBPACK_IMPORTED_MODULE_15__["ɵɵelementEnd"]()()()()();
  }

  if (rf & 2) {
    _angular_core__WEBPACK_IMPORTED_MODULE_15__["ɵɵadvance"](5);
    _angular_core__WEBPACK_IMPORTED_MODULE_15__["ɵɵtextInterpolate1"](" ", _angular_core__WEBPACK_IMPORTED_MODULE_15__["ɵɵpipeBind1"](6, 1, "trip_detail.no_track"), "");
  }
}

function TripDetailPage_ng_container_2_span_16_Template(rf, ctx) {
  if (rf & 1) {
    _angular_core__WEBPACK_IMPORTED_MODULE_15__["ɵɵelementStart"](0, "span");
    _angular_core__WEBPACK_IMPORTED_MODULE_15__["ɵɵtext"](1);
    _angular_core__WEBPACK_IMPORTED_MODULE_15__["ɵɵpipe"](2, "localNumber");
    _angular_core__WEBPACK_IMPORTED_MODULE_15__["ɵɵpipe"](3, "translate");
    _angular_core__WEBPACK_IMPORTED_MODULE_15__["ɵɵelementEnd"]();
  }

  if (rf & 2) {
    var ctx_r3 = _angular_core__WEBPACK_IMPORTED_MODULE_15__["ɵɵnextContext"](2);
    _angular_core__WEBPACK_IMPORTED_MODULE_15__["ɵɵadvance"](1);
    _angular_core__WEBPACK_IMPORTED_MODULE_15__["ɵɵtextInterpolate3"]("", _angular_core__WEBPACK_IMPORTED_MODULE_15__["ɵɵpipeBind2"](2, 3, ctx_r3.tripDetail.distance / 1000, "0.0-1"), " ", _angular_core__WEBPACK_IMPORTED_MODULE_15__["ɵɵpipeBind1"](3, 6, "km"), " ", ctx_r3.durationLabel, "");
  }
}

function TripDetailPage_ng_container_2_ng_template_17_Template(rf, ctx) {
  if (rf & 1) {
    _angular_core__WEBPACK_IMPORTED_MODULE_15__["ɵɵelementStart"](0, "span");
    _angular_core__WEBPACK_IMPORTED_MODULE_15__["ɵɵtext"](1);
    _angular_core__WEBPACK_IMPORTED_MODULE_15__["ɵɵpipe"](2, "translate");
    _angular_core__WEBPACK_IMPORTED_MODULE_15__["ɵɵelementEnd"]();
  }

  if (rf & 2) {
    _angular_core__WEBPACK_IMPORTED_MODULE_15__["ɵɵadvance"](1);
    _angular_core__WEBPACK_IMPORTED_MODULE_15__["ɵɵtextInterpolate1"](" - ", _angular_core__WEBPACK_IMPORTED_MODULE_15__["ɵɵpipeBind1"](2, 1, "km"), " / - min ");
  }
}

function TripDetailPage_ng_container_2_ion_row_19_Template(rf, ctx) {
  if (rf & 1) {
    _angular_core__WEBPACK_IMPORTED_MODULE_15__["ɵɵelementStart"](0, "ion-row")(1, "span", 16);
    _angular_core__WEBPACK_IMPORTED_MODULE_15__["ɵɵtext"](2);
    _angular_core__WEBPACK_IMPORTED_MODULE_15__["ɵɵpipe"](3, "translate");
    _angular_core__WEBPACK_IMPORTED_MODULE_15__["ɵɵelementEnd"]()();
  }

  if (rf & 2) {
    _angular_core__WEBPACK_IMPORTED_MODULE_15__["ɵɵadvance"](2);
    _angular_core__WEBPACK_IMPORTED_MODULE_15__["ɵɵtextInterpolate1"](" ", _angular_core__WEBPACK_IMPORTED_MODULE_15__["ɵɵpipeBind1"](3, 1, "trip_detail.no_score"), " ");
  }
}

function TripDetailPage_ng_container_2_ion_row_20_ng_container_1_ng_container_2_Template(rf, ctx) {
  if (rf & 1) {
    _angular_core__WEBPACK_IMPORTED_MODULE_15__["ɵɵelementContainerStart"](0);
    _angular_core__WEBPACK_IMPORTED_MODULE_15__["ɵɵtext"](1);
    _angular_core__WEBPACK_IMPORTED_MODULE_15__["ɵɵpipe"](2, "localNumber");
    _angular_core__WEBPACK_IMPORTED_MODULE_15__["ɵɵpipe"](3, "translate");
    _angular_core__WEBPACK_IMPORTED_MODULE_15__["ɵɵelementContainerEnd"]();
  }

  if (rf & 2) {
    var campaign_r8 = _angular_core__WEBPACK_IMPORTED_MODULE_15__["ɵɵnextContext"](2).$implicit;
    _angular_core__WEBPACK_IMPORTED_MODULE_15__["ɵɵadvance"](1);
    _angular_core__WEBPACK_IMPORTED_MODULE_15__["ɵɵtextInterpolate2"](" ", _angular_core__WEBPACK_IMPORTED_MODULE_15__["ɵɵpipeBind2"](2, 2, campaign_r8.distance / 1000, "0.0-1"), " ", _angular_core__WEBPACK_IMPORTED_MODULE_15__["ɵɵpipeBind1"](3, 5, "km"), " ");
  }
}

function TripDetailPage_ng_container_2_ion_row_20_ng_container_1_ng_container_3_Template(rf, ctx) {
  if (rf & 1) {
    _angular_core__WEBPACK_IMPORTED_MODULE_15__["ɵɵelementContainerStart"](0);
    _angular_core__WEBPACK_IMPORTED_MODULE_15__["ɵɵelement"](1, "app-icon", 23);
    _angular_core__WEBPACK_IMPORTED_MODULE_15__["ɵɵelementStart"](2, "ion-text");
    _angular_core__WEBPACK_IMPORTED_MODULE_15__["ɵɵtext"](3);
    _angular_core__WEBPACK_IMPORTED_MODULE_15__["ɵɵpipe"](4, "localNumber");
    _angular_core__WEBPACK_IMPORTED_MODULE_15__["ɵɵelementEnd"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_15__["ɵɵelementContainerEnd"]();
  }

  if (rf & 2) {
    var campaign_r8 = _angular_core__WEBPACK_IMPORTED_MODULE_15__["ɵɵnextContext"](2).$implicit;
    var ctx_r11 = _angular_core__WEBPACK_IMPORTED_MODULE_15__["ɵɵnextContext"](2);
    _angular_core__WEBPACK_IMPORTED_MODULE_15__["ɵɵadvance"](1);
    _angular_core__WEBPACK_IMPORTED_MODULE_15__["ɵɵproperty"]("color", ctx_r11.campaignService.getCampaignColor(campaign_r8))("name", ctx_r11.campaignService.getCampaignScoreIcon(campaign_r8));
    _angular_core__WEBPACK_IMPORTED_MODULE_15__["ɵɵadvance"](2);
    _angular_core__WEBPACK_IMPORTED_MODULE_15__["ɵɵtextInterpolate"](_angular_core__WEBPACK_IMPORTED_MODULE_15__["ɵɵpipeBind2"](4, 3, campaign_r8.virtualScore, "0.0-1"));
  }
}

function TripDetailPage_ng_container_2_ion_row_20_ng_container_1_ng_container_4_Template(rf, ctx) {
  if (rf & 1) {
    _angular_core__WEBPACK_IMPORTED_MODULE_15__["ɵɵelementContainerStart"](0);
    _angular_core__WEBPACK_IMPORTED_MODULE_15__["ɵɵelement"](1, "app-icon", 23);
    _angular_core__WEBPACK_IMPORTED_MODULE_15__["ɵɵelementStart"](2, "ion-text");
    _angular_core__WEBPACK_IMPORTED_MODULE_15__["ɵɵtext"](3);
    _angular_core__WEBPACK_IMPORTED_MODULE_15__["ɵɵpipe"](4, "localNumber");
    _angular_core__WEBPACK_IMPORTED_MODULE_15__["ɵɵelementEnd"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_15__["ɵɵelementContainerEnd"]();
  }

  if (rf & 2) {
    var campaign_r8 = _angular_core__WEBPACK_IMPORTED_MODULE_15__["ɵɵnextContext"](2).$implicit;
    var ctx_r12 = _angular_core__WEBPACK_IMPORTED_MODULE_15__["ɵɵnextContext"](2);
    _angular_core__WEBPACK_IMPORTED_MODULE_15__["ɵɵadvance"](1);
    _angular_core__WEBPACK_IMPORTED_MODULE_15__["ɵɵproperty"]("color", ctx_r12.campaignService.getCampaignColor(campaign_r8))("name", ctx_r12.campaignService.getCampaignScoreIcon(campaign_r8));
    _angular_core__WEBPACK_IMPORTED_MODULE_15__["ɵɵadvance"](2);
    _angular_core__WEBPACK_IMPORTED_MODULE_15__["ɵɵtextInterpolate"](_angular_core__WEBPACK_IMPORTED_MODULE_15__["ɵɵpipeBind2"](4, 3, campaign_r8.score, "0.0-1"));
  }
}

function TripDetailPage_ng_container_2_ion_row_20_ng_container_1_Template(rf, ctx) {
  if (rf & 1) {
    var _r18 = _angular_core__WEBPACK_IMPORTED_MODULE_15__["ɵɵgetCurrentView"]();

    _angular_core__WEBPACK_IMPORTED_MODULE_15__["ɵɵelementContainerStart"](0);
    _angular_core__WEBPACK_IMPORTED_MODULE_15__["ɵɵelementStart"](1, "ion-col", 18);
    _angular_core__WEBPACK_IMPORTED_MODULE_15__["ɵɵtemplate"](2, TripDetailPage_ng_container_2_ion_row_20_ng_container_1_ng_container_2_Template, 4, 7, "ng-container", 2);
    _angular_core__WEBPACK_IMPORTED_MODULE_15__["ɵɵtemplate"](3, TripDetailPage_ng_container_2_ion_row_20_ng_container_1_ng_container_3_Template, 5, 6, "ng-container", 2);
    _angular_core__WEBPACK_IMPORTED_MODULE_15__["ɵɵtemplate"](4, TripDetailPage_ng_container_2_ion_row_20_ng_container_1_ng_container_4_Template, 5, 6, "ng-container", 2);
    _angular_core__WEBPACK_IMPORTED_MODULE_15__["ɵɵelementEnd"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_15__["ɵɵelementStart"](5, "ion-col", 19)(6, "ion-text");
    _angular_core__WEBPACK_IMPORTED_MODULE_15__["ɵɵtext"](7);
    _angular_core__WEBPACK_IMPORTED_MODULE_15__["ɵɵpipe"](8, "translate");
    _angular_core__WEBPACK_IMPORTED_MODULE_15__["ɵɵelementEnd"]()();
    _angular_core__WEBPACK_IMPORTED_MODULE_15__["ɵɵelementStart"](9, "ion-col", 20)(10, "ion-text", 21)(11, "a", 22);
    _angular_core__WEBPACK_IMPORTED_MODULE_15__["ɵɵlistener"]("click", function TripDetailPage_ng_container_2_ion_row_20_ng_container_1_Template_a_click_11_listener() {
      _angular_core__WEBPACK_IMPORTED_MODULE_15__["ɵɵrestoreView"](_r18);
      var campaign_r8 = _angular_core__WEBPACK_IMPORTED_MODULE_15__["ɵɵnextContext"]().$implicit;
      var ctx_r16 = _angular_core__WEBPACK_IMPORTED_MODULE_15__["ɵɵnextContext"](2);
      return ctx_r16.openCampaign(campaign_r8);
    });
    _angular_core__WEBPACK_IMPORTED_MODULE_15__["ɵɵtext"](12);
    _angular_core__WEBPACK_IMPORTED_MODULE_15__["ɵɵpipe"](13, "languageMap");
    _angular_core__WEBPACK_IMPORTED_MODULE_15__["ɵɵelementEnd"]()()();
    _angular_core__WEBPACK_IMPORTED_MODULE_15__["ɵɵelementContainerEnd"]();
  }

  if (rf & 2) {
    var campaign_r8 = _angular_core__WEBPACK_IMPORTED_MODULE_15__["ɵɵnextContext"]().$implicit;
    var ctx_r9 = _angular_core__WEBPACK_IMPORTED_MODULE_15__["ɵɵnextContext"](2);
    _angular_core__WEBPACK_IMPORTED_MODULE_15__["ɵɵadvance"](2);
    _angular_core__WEBPACK_IMPORTED_MODULE_15__["ɵɵproperty"]("ngIf", campaign_r8.type === "personal");
    _angular_core__WEBPACK_IMPORTED_MODULE_15__["ɵɵadvance"](1);
    _angular_core__WEBPACK_IMPORTED_MODULE_15__["ɵɵproperty"]("ngIf", campaign_r8.type === "company");
    _angular_core__WEBPACK_IMPORTED_MODULE_15__["ɵɵadvance"](1);
    _angular_core__WEBPACK_IMPORTED_MODULE_15__["ɵɵproperty"]("ngIf", campaign_r8.type === "school" || campaign_r8.type === "city");
    _angular_core__WEBPACK_IMPORTED_MODULE_15__["ɵɵadvance"](3);
    _angular_core__WEBPACK_IMPORTED_MODULE_15__["ɵɵtextInterpolate1"]("", _angular_core__WEBPACK_IMPORTED_MODULE_15__["ɵɵpipeBind1"](8, 6, "trip_detail.gl_for"), " ");
    _angular_core__WEBPACK_IMPORTED_MODULE_15__["ɵɵadvance"](3);
    _angular_core__WEBPACK_IMPORTED_MODULE_15__["ɵɵproperty"]("color", ctx_r9.campaignService.getCampaignColor(campaign_r8));
    _angular_core__WEBPACK_IMPORTED_MODULE_15__["ɵɵadvance"](2);
    _angular_core__WEBPACK_IMPORTED_MODULE_15__["ɵɵtextInterpolate"](_angular_core__WEBPACK_IMPORTED_MODULE_15__["ɵɵpipeBind1"](13, 8, campaign_r8.campaignName));
  }
}

function TripDetailPage_ng_container_2_ion_row_20_Template(rf, ctx) {
  if (rf & 1) {
    _angular_core__WEBPACK_IMPORTED_MODULE_15__["ɵɵelementStart"](0, "ion-row", 17);
    _angular_core__WEBPACK_IMPORTED_MODULE_15__["ɵɵtemplate"](1, TripDetailPage_ng_container_2_ion_row_20_ng_container_1_Template, 14, 10, "ng-container", 2);
    _angular_core__WEBPACK_IMPORTED_MODULE_15__["ɵɵelementEnd"]();
  }

  if (rf & 2) {
    var campaign_r8 = ctx.$implicit;
    _angular_core__WEBPACK_IMPORTED_MODULE_15__["ɵɵadvance"](1);
    _angular_core__WEBPACK_IMPORTED_MODULE_15__["ɵɵproperty"]("ngIf", campaign_r8.valid);
  }
}

var _c1 = function _c1() {
  return {
    year: "numeric",
    month: "short",
    day: "numeric",
    hour: "numeric",
    minute: "numeric"
  };
};

function TripDetailPage_ng_container_2_Template(rf, ctx) {
  if (rf & 1) {
    _angular_core__WEBPACK_IMPORTED_MODULE_15__["ɵɵelementContainerStart"](0);
    _angular_core__WEBPACK_IMPORTED_MODULE_15__["ɵɵtemplate"](1, TripDetailPage_ng_container_2_app_trip_detail_map_1_Template, 1, 3, "app-trip-detail-map", 3);
    _angular_core__WEBPACK_IMPORTED_MODULE_15__["ɵɵtemplate"](2, TripDetailPage_ng_container_2_ion_grid_2_Template, 7, 3, "ion-grid", 2);
    _angular_core__WEBPACK_IMPORTED_MODULE_15__["ɵɵelementStart"](3, "ion-card", 4)(4, "ion-grid")(5, "ion-row")(6, "ion-col", 5);
    _angular_core__WEBPACK_IMPORTED_MODULE_15__["ɵɵelement"](7, "app-icon", 6);
    _angular_core__WEBPACK_IMPORTED_MODULE_15__["ɵɵelementEnd"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_15__["ɵɵelementStart"](8, "ion-col", 7)(9, "ion-row", 8);
    _angular_core__WEBPACK_IMPORTED_MODULE_15__["ɵɵtext"](10);
    _angular_core__WEBPACK_IMPORTED_MODULE_15__["ɵɵpipe"](11, "translate");
    _angular_core__WEBPACK_IMPORTED_MODULE_15__["ɵɵelementEnd"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_15__["ɵɵelementStart"](12, "ion-row", 9);
    _angular_core__WEBPACK_IMPORTED_MODULE_15__["ɵɵtext"](13);
    _angular_core__WEBPACK_IMPORTED_MODULE_15__["ɵɵpipe"](14, "localDate");
    _angular_core__WEBPACK_IMPORTED_MODULE_15__["ɵɵelementEnd"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_15__["ɵɵelementStart"](15, "ion-row", 10);
    _angular_core__WEBPACK_IMPORTED_MODULE_15__["ɵɵtemplate"](16, TripDetailPage_ng_container_2_span_16_Template, 4, 8, "span", 11);
    _angular_core__WEBPACK_IMPORTED_MODULE_15__["ɵɵtemplate"](17, TripDetailPage_ng_container_2_ng_template_17_Template, 3, 3, "ng-template", null, 12, _angular_core__WEBPACK_IMPORTED_MODULE_15__["ɵɵtemplateRefExtractor"]);
    _angular_core__WEBPACK_IMPORTED_MODULE_15__["ɵɵelementEnd"]()()();
    _angular_core__WEBPACK_IMPORTED_MODULE_15__["ɵɵtemplate"](19, TripDetailPage_ng_container_2_ion_row_19_Template, 4, 3, "ion-row", 2);
    _angular_core__WEBPACK_IMPORTED_MODULE_15__["ɵɵtemplate"](20, TripDetailPage_ng_container_2_ion_row_20_Template, 2, 1, "ion-row", 13);
    _angular_core__WEBPACK_IMPORTED_MODULE_15__["ɵɵelementEnd"]()();
    _angular_core__WEBPACK_IMPORTED_MODULE_15__["ɵɵelementContainerEnd"]();
  }

  if (rf & 2) {
    var _r4 = _angular_core__WEBPACK_IMPORTED_MODULE_15__["ɵɵreference"](18);

    var ctx_r0 = _angular_core__WEBPACK_IMPORTED_MODULE_15__["ɵɵnextContext"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_15__["ɵɵadvance"](1);
    _angular_core__WEBPACK_IMPORTED_MODULE_15__["ɵɵproperty"]("ngIf", ctx_r0.showMap);
    _angular_core__WEBPACK_IMPORTED_MODULE_15__["ɵɵadvance"](1);
    _angular_core__WEBPACK_IMPORTED_MODULE_15__["ɵɵproperty"]("ngIf", !ctx_r0.showMap);
    _angular_core__WEBPACK_IMPORTED_MODULE_15__["ɵɵadvance"](5);
    _angular_core__WEBPACK_IMPORTED_MODULE_15__["ɵɵproperty"]("name", ctx_r0.getTransportTypeIcon(ctx_r0.tripDetail.modeType));
    _angular_core__WEBPACK_IMPORTED_MODULE_15__["ɵɵadvance"](3);
    _angular_core__WEBPACK_IMPORTED_MODULE_15__["ɵɵtextInterpolate"](_angular_core__WEBPACK_IMPORTED_MODULE_15__["ɵɵpipeBind1"](11, 9, ctx_r0.getTransportTypeLabel(ctx_r0.tripDetail.modeType)));
    _angular_core__WEBPACK_IMPORTED_MODULE_15__["ɵɵadvance"](3);
    _angular_core__WEBPACK_IMPORTED_MODULE_15__["ɵɵtextInterpolate"](_angular_core__WEBPACK_IMPORTED_MODULE_15__["ɵɵpipeBind2"](14, 11, ctx_r0.tripDetail.startTime, _angular_core__WEBPACK_IMPORTED_MODULE_15__["ɵɵpureFunction0"](14, _c1)));
    _angular_core__WEBPACK_IMPORTED_MODULE_15__["ɵɵadvance"](3);
    _angular_core__WEBPACK_IMPORTED_MODULE_15__["ɵɵproperty"]("ngIf", ctx_r0.tripDetail.distance)("ngIfElse", _r4);
    _angular_core__WEBPACK_IMPORTED_MODULE_15__["ɵɵadvance"](3);
    _angular_core__WEBPACK_IMPORTED_MODULE_15__["ɵɵproperty"]("ngIf", ctx_r0.campaigns.length === 0);
    _angular_core__WEBPACK_IMPORTED_MODULE_15__["ɵɵadvance"](1);
    _angular_core__WEBPACK_IMPORTED_MODULE_15__["ɵɵproperty"]("ngForOf", ctx_r0.campaigns);
  }
}

var TripDetailPage = /*#__PURE__*/function () {
  function TripDetailPage(route, router, errorService, trackApiService, campaignService, alertService) {
    (0,_Users_smartcommunitylab_Desktop_newWork_dslab_playgo_mobile_playgo_mobile_node_modules_babel_runtime_helpers_esm_classCallCheck_js__WEBPACK_IMPORTED_MODULE_0__["default"])(this, TripDetailPage);

    this.route = route;
    this.router = router;
    this.errorService = errorService;
    this.trackApiService = trackApiService;
    this.campaignService = campaignService;
    this.alertService = alertService;
    this.tripDetail = null;
    this.getTransportTypeIcon = src_app_core_shared_tracking_trip_model__WEBPACK_IMPORTED_MODULE_2__.getTransportTypeIcon;
    this.getTransportTypeLabel = src_app_core_shared_tracking_trip_model__WEBPACK_IMPORTED_MODULE_2__.getTransportTypeLabel;
  }

  (0,_Users_smartcommunitylab_Desktop_newWork_dslab_playgo_mobile_playgo_mobile_node_modules_babel_runtime_helpers_esm_createClass_js__WEBPACK_IMPORTED_MODULE_1__["default"])(TripDetailPage, [{
    key: "ngOnInit",
    value: function ngOnInit() {
      return (0,tslib__WEBPACK_IMPORTED_MODULE_16__.__awaiter)(this, void 0, void 0, /*#__PURE__*/_regeneratorRuntime().mark(function _callee() {
        var _this = this;

        var tripId;
        return _regeneratorRuntime().wrap(function _callee$(_context) {
          while (1) switch (_context.prev = _context.next) {
            case 0:
              tripId = this.route.snapshot.paramMap.get('id');
              this.subCampaign = this.campaignService.myCampaigns$.subscribe(function (campaigns) {
                _this.campaignAvailability = campaigns.map(function (campaignContainer) {
                  return campaignContainer.campaign.campaignId;
                });
              });
              _context.prev = 2;
              _context.next = 5;
              return this.getTripDetail(tripId);

            case 5:
              this.tripDetail = _context.sent;
              this.showMap = Boolean(this.tripDetail.polyline);
              this.campaigns = this.tripDetail.campaigns.filter(function (campaign) {
                return campaign.valid;
              });
              this.durationLabel = (0,src_app_core_shared_utils__WEBPACK_IMPORTED_MODULE_3__.formatDurationToHoursAndMinutes)(this.tripDetail.endTime - this.tripDetail.startTime);
              _context.next = 14;
              break;

            case 11:
              _context.prev = 11;
              _context.t0 = _context["catch"](2);
              this.errorService.handleError(_context.t0);

            case 14:
            case "end":
              return _context.stop();
          }
        }, _callee, this, [[2, 11]]);
      }));
    }
  }, {
    key: "openCampaign",
    value: function openCampaign(campaign) {
      //check if campaign is valid
      if (!this.campaignAvailability.includes(campaign.campaignId)) {
        return this.alertService.showToast({
          messageTranslateKey: 'campaigns.removed'
        });
      }

      this.router.navigateByUrl('/pages/tabs/trips/campaign-detail/' + campaign.campaignId);
    }
  }, {
    key: "getTripDetail",
    value: function getTripDetail(id) {
      return (0,tslib__WEBPACK_IMPORTED_MODULE_16__.__awaiter)(this, void 0, void 0, /*#__PURE__*/_regeneratorRuntime().mark(function _callee2() {
        return _regeneratorRuntime().wrap(function _callee2$(_context2) {
          while (1) switch (_context2.prev = _context2.next) {
            case 0:
              _context2.next = 2;
              return this.trackApiService.getTrackedInstanceInfoDetail(id);

            case 2:
              return _context2.abrupt("return", _context2.sent);

            case 3:
            case "end":
              return _context2.stop();
          }
        }, _callee2, this);
      }));
    }
  }, {
    key: "getLabelObs",
    value: function getLabelObs(campaign) {
      return this.campaignService.myCampaigns$.pipe((0,rxjs__WEBPACK_IMPORTED_MODULE_17__.map)(function (campaigns) {
        var _a, _b, _c, _d;

        return (_d = (_c = (_b = (_a = campaigns.find(function (campaignContainer) {
          return campaignContainer.campaign.campaignId === campaign.campaignId;
        })) === null || _a === void 0 ? void 0 : _a.campaign) === null || _b === void 0 ? void 0 : _b.specificData) === null || _c === void 0 ? void 0 : _c.virtualScore) === null || _d === void 0 ? void 0 : _d.label;
      }));
    }
  }]);

  return TripDetailPage;
}();

TripDetailPage.ɵfac = function TripDetailPage_Factory(t) {
  return new (t || TripDetailPage)(_angular_core__WEBPACK_IMPORTED_MODULE_15__["ɵɵdirectiveInject"](_angular_router__WEBPACK_IMPORTED_MODULE_18__.ActivatedRoute), _angular_core__WEBPACK_IMPORTED_MODULE_15__["ɵɵdirectiveInject"](_angular_router__WEBPACK_IMPORTED_MODULE_18__.Router), _angular_core__WEBPACK_IMPORTED_MODULE_15__["ɵɵdirectiveInject"](src_app_core_shared_services_error_service__WEBPACK_IMPORTED_MODULE_4__.ErrorService), _angular_core__WEBPACK_IMPORTED_MODULE_15__["ɵɵdirectiveInject"](src_app_core_shared_tracking_track_api_service__WEBPACK_IMPORTED_MODULE_5__.TrackApiService), _angular_core__WEBPACK_IMPORTED_MODULE_15__["ɵɵdirectiveInject"](src_app_core_shared_services_campaign_service__WEBPACK_IMPORTED_MODULE_6__.CampaignService), _angular_core__WEBPACK_IMPORTED_MODULE_15__["ɵɵdirectiveInject"](src_app_core_shared_services_alert_service__WEBPACK_IMPORTED_MODULE_7__.AlertService));
};

TripDetailPage.ɵcmp = /*@__PURE__*/_angular_core__WEBPACK_IMPORTED_MODULE_15__["ɵɵdefineComponent"]({
  type: TripDetailPage,
  selectors: [["app-trip-detail"]],
  decls: 3,
  vars: 1,
  consts: [["appHeader", ""], ["appContent", ""], [4, "ngIf"], [3, "tripParts", 4, "ngIf"], [1, "absolute-wrapper"], ["size", "3", 1, "ion-text-center"], [1, "big-icon", 3, "name"], ["size", "9"], [1, "mean-label"], [1, "mean-date"], [1, "mean-hour"], [4, "ngIf", "ngIfElse"], ["noDistance", ""], ["class", "campaigns-validation", 4, "ngFor", "ngForOf"], [3, "tripParts"], [1, "no-map"], [1, "no-score"], [1, "campaigns-validation"], ["size", "3", 1, "ion-text-right"], ["size", "auto"], [1, "ellipsis"], [3, "color"], ["routerDirection", "forward", 1, "inherit-color", "underline", 3, "click"], [3, "color", "name"]],
  template: function TripDetailPage_Template(rf, ctx) {
    if (rf & 1) {
      _angular_core__WEBPACK_IMPORTED_MODULE_15__["ɵɵelement"](0, "ion-header", 0);
      _angular_core__WEBPACK_IMPORTED_MODULE_15__["ɵɵelementStart"](1, "ion-content", 1);
      _angular_core__WEBPACK_IMPORTED_MODULE_15__["ɵɵtemplate"](2, TripDetailPage_ng_container_2_Template, 21, 15, "ng-container", 2);
      _angular_core__WEBPACK_IMPORTED_MODULE_15__["ɵɵelementEnd"]();
    }

    if (rf & 2) {
      _angular_core__WEBPACK_IMPORTED_MODULE_15__["ɵɵadvance"](2);
      _angular_core__WEBPACK_IMPORTED_MODULE_15__["ɵɵproperty"]("ngIf", ctx.tripDetail);
    }
  },
  directives: [_ionic_angular__WEBPACK_IMPORTED_MODULE_19__.IonHeader, _core_shared_layout_header_header_directive__WEBPACK_IMPORTED_MODULE_8__.HeaderDirective, _ionic_angular__WEBPACK_IMPORTED_MODULE_19__.IonContent, _core_shared_layout_content_content_directive__WEBPACK_IMPORTED_MODULE_9__.ContentDirective, _angular_common__WEBPACK_IMPORTED_MODULE_20__.NgIf, _trip_detail_map_trip_detail_map_component__WEBPACK_IMPORTED_MODULE_10__.TripDetailMapComponent, _ionic_angular__WEBPACK_IMPORTED_MODULE_19__.IonGrid, _ionic_angular__WEBPACK_IMPORTED_MODULE_19__.IonRow, _ionic_angular__WEBPACK_IMPORTED_MODULE_19__.IonCol, _ionic_angular__WEBPACK_IMPORTED_MODULE_19__.IonCard, _core_shared_ui_icon_icon_component__WEBPACK_IMPORTED_MODULE_11__.IconComponent, _angular_common__WEBPACK_IMPORTED_MODULE_20__.NgForOf, _ionic_angular__WEBPACK_IMPORTED_MODULE_19__.IonText],
  pipes: [_ngx_translate_core__WEBPACK_IMPORTED_MODULE_21__.TranslatePipe, _core_shared_pipes_localDate_pipe__WEBPACK_IMPORTED_MODULE_12__.LocalDatePipe, _core_shared_pipes_localNumber_pipe__WEBPACK_IMPORTED_MODULE_13__.LocalNumberPipe, _core_shared_pipes_languageMap_pipe__WEBPACK_IMPORTED_MODULE_14__.LanguageMapPipe],
  styles: ["[_nghost-%COMP%] {\n  height: 100%;\n}\n\nion-grid[_ngcontent-%COMP%] {\n  color: var(--dark-grey);\n}\n\n.inherit-color[_ngcontent-%COMP%] {\n  color: inherit !important;\n}\n\n.big-icon[_ngcontent-%COMP%] {\n  font-size: 64px;\n}\n\n.underline[_ngcontent-%COMP%] {\n  text-decoration: underline;\n  cursor: pointer;\n}\n\n.absolute-wrapper[_ngcontent-%COMP%] {\n  font-size: 18px;\n  position: absolute;\n  bottom: 1em;\n  z-index: 1000;\n  right: 0;\n  left: 0;\n}\n\n.absolute-wrapper[_ngcontent-%COMP%]   ion-row[_ngcontent-%COMP%] {\n  display: flex;\n  align-items: center !important;\n}\n\n.absolute-wrapper[_ngcontent-%COMP%]   ion-row[_ngcontent-%COMP%]   .mean-label[_ngcontent-%COMP%] {\n  font-weight: 500;\n  font-size: 17px;\n  line-height: 25px;\n}\n\n.absolute-wrapper[_ngcontent-%COMP%]   ion-row[_ngcontent-%COMP%]   .mean-date[_ngcontent-%COMP%] {\n  font-weight: 500;\n  font-size: 14px;\n  line-height: 25px;\n}\n\n.absolute-wrapper[_ngcontent-%COMP%]   ion-row[_ngcontent-%COMP%]   .mean-hour[_ngcontent-%COMP%] {\n  font-weight: 500;\n  font-size: 14px;\n  line-height: 25px;\n}\n\n.absolute-wrapper[_ngcontent-%COMP%]   ion-row[_ngcontent-%COMP%]   .no-score[_ngcontent-%COMP%] {\n  margin: 8px;\n}\n\n.ellipsis[_ngcontent-%COMP%] {\n  overflow: hidden;\n  text-overflow: ellipsis;\n  white-space: nowrap;\n}\n\n.campaigns-validation[_ngcontent-%COMP%]    > ion-col[_ngcontent-%COMP%] {\n  display: flex;\n  align-items: center;\n}\n\n.campaigns-validation[_ngcontent-%COMP%]    > ion-col[_ngcontent-%COMP%]:first-child {\n  flex-direction: row-reverse;\n}\n\n.no-map[_ngcontent-%COMP%] {\n  margin: auto;\n  padding: 8px;\n  font-size: 16px;\n  text-align: center;\n}\n/*# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbInRyaXAtZGV0YWlsLnBhZ2Uuc2NzcyJdLCJuYW1lcyI6W10sIm1hcHBpbmdzIjoiQUFBQTtFQUNFLFlBQUE7QUFDRjs7QUFDQTtFQUNFLHVCQUFBO0FBRUY7O0FBQUE7RUFDRSx5QkFBQTtBQUdGOztBQURBO0VBQ0UsZUFBQTtBQUlGOztBQUZBO0VBQ0UsMEJBQUE7RUFDQSxlQUFBO0FBS0Y7O0FBSEE7RUFDRSxlQUFBO0VBQ0Esa0JBQUE7RUFDQSxXQUFBO0VBQ0EsYUFBQTtFQUNBLFFBQUE7RUFDQSxPQUFBO0FBTUY7O0FBTEU7RUFDRSxhQUFBO0VBQ0EsOEJBQUE7QUFPSjs7QUFOSTtFQUNFLGdCQUFBO0VBQ0EsZUFBQTtFQUNBLGlCQUFBO0FBUU47O0FBTkk7RUFDRSxnQkFBQTtFQUNBLGVBQUE7RUFDQSxpQkFBQTtBQVFOOztBQU5JO0VBQ0UsZ0JBQUE7RUFDQSxlQUFBO0VBQ0EsaUJBQUE7QUFRTjs7QUFOSTtFQUNFLFdBQUE7QUFRTjs7QUFKQTtFQUNFLGdCQUFBO0VBQ0EsdUJBQUE7RUFDQSxtQkFBQTtBQU9GOztBQUpBO0VBQ0UsYUFBQTtFQUNBLG1CQUFBO0FBT0Y7O0FBTEE7RUFDRSwyQkFBQTtBQVFGOztBQU5BO0VBQ0UsWUFBQTtFQUNBLFlBQUE7RUFDQSxlQUFBO0VBQ0Esa0JBQUE7QUFTRiIsImZpbGUiOiJ0cmlwLWRldGFpbC5wYWdlLnNjc3MiLCJzb3VyY2VzQ29udGVudCI6WyI6aG9zdCB7XG4gIGhlaWdodDogMTAwJTtcbn1cbmlvbi1ncmlkIHtcbiAgY29sb3I6IHZhcigtLWRhcmstZ3JleSk7XG59XG4uaW5oZXJpdC1jb2xvciB7XG4gIGNvbG9yOiBpbmhlcml0ICFpbXBvcnRhbnQ7XG59XG4uYmlnLWljb24ge1xuICBmb250LXNpemU6IDY0cHg7XG59XG4udW5kZXJsaW5lIHtcbiAgdGV4dC1kZWNvcmF0aW9uOiB1bmRlcmxpbmU7XG4gIGN1cnNvcjogcG9pbnRlcjtcbn1cbi5hYnNvbHV0ZS13cmFwcGVyIHtcbiAgZm9udC1zaXplOiAxOHB4O1xuICBwb3NpdGlvbjogYWJzb2x1dGU7XG4gIGJvdHRvbTogMWVtO1xuICB6LWluZGV4OiAxMDAwO1xuICByaWdodDogMDtcbiAgbGVmdDogMDtcbiAgaW9uLXJvdyB7XG4gICAgZGlzcGxheTogZmxleDtcbiAgICBhbGlnbi1pdGVtczogY2VudGVyICFpbXBvcnRhbnQ7XG4gICAgLm1lYW4tbGFiZWwge1xuICAgICAgZm9udC13ZWlnaHQ6IDUwMDtcbiAgICAgIGZvbnQtc2l6ZTogMTdweDtcbiAgICAgIGxpbmUtaGVpZ2h0OiAyNXB4O1xuICAgIH1cbiAgICAubWVhbi1kYXRlIHtcbiAgICAgIGZvbnQtd2VpZ2h0OiA1MDA7XG4gICAgICBmb250LXNpemU6IDE0cHg7XG4gICAgICBsaW5lLWhlaWdodDogMjVweDtcbiAgICB9XG4gICAgLm1lYW4taG91ciB7XG4gICAgICBmb250LXdlaWdodDogNTAwO1xuICAgICAgZm9udC1zaXplOiAxNHB4O1xuICAgICAgbGluZS1oZWlnaHQ6IDI1cHg7XG4gICAgfVxuICAgIC5uby1zY29yZSB7XG4gICAgICBtYXJnaW46IDhweDtcbiAgICB9XG4gIH1cbn1cbi5lbGxpcHNpcyB7XG4gIG92ZXJmbG93OiBoaWRkZW47XG4gIHRleHQtb3ZlcmZsb3c6IGVsbGlwc2lzO1xuICB3aGl0ZS1zcGFjZTogbm93cmFwO1xufVxuXG4uY2FtcGFpZ25zLXZhbGlkYXRpb24gPiBpb24tY29sIHtcbiAgZGlzcGxheTogZmxleDtcbiAgYWxpZ24taXRlbXM6IGNlbnRlcjtcbn1cbi5jYW1wYWlnbnMtdmFsaWRhdGlvbiA+IGlvbi1jb2w6Zmlyc3QtY2hpbGQge1xuICBmbGV4LWRpcmVjdGlvbjogcm93LXJldmVyc2U7XG59XG4ubm8tbWFwIHtcbiAgbWFyZ2luOiBhdXRvO1xuICBwYWRkaW5nOiA4cHg7XG4gIGZvbnQtc2l6ZTogMTZweDtcbiAgdGV4dC1hbGlnbjogY2VudGVyO1xufVxuIl19 */"]
});

/***/ }),

/***/ 59922:
/*!*******************************************************************!*\
  !*** ./node_modules/@googlemaps/polyline-codec/dist/index.esm.js ***!
  \*******************************************************************/
/***/ (function(__unused_webpack_module, __webpack_exports__, __webpack_require__) {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "decode": function() { return /* binding */ decode; },
/* harmony export */   "encode": function() { return /* binding */ encode; },
/* harmony export */   "polylineEncodeLine": function() { return /* binding */ polylineEncodeLine; }
/* harmony export */ });
/**
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *      http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */

/**
 * Decodes an encoded path string into a sequence of LatLngs.
 *
 * See {@link https://developers.google.com/maps/documentation/utilities/polylinealgorithm}
 *
 *  #### Example
 *
 * ```js
 * import { decode } from "@googlemaps/polyline-codec";
 *
 * const encoded = "_p~iF~ps|U_ulLnnqC_mqNvxq`@";
 * console.log(decode(encoded, 5));
 * // [
 * //   [38.5, -120.2],
 * //   [40.7, -120.95],
 * //   [43.252, -126.453],
 * // ]
 * ```
 */
var decode = function decode(encodedPath, precision) {
  if (precision === void 0) {
    precision = 5;
  }

  var factor = Math.pow(10, precision);
  var len = encodedPath.length; // For speed we preallocate to an upper bound on the final length, then
  // truncate the array before returning.

  var path = new Array(Math.floor(encodedPath.length / 2));
  var index = 0;
  var lat = 0;
  var lng = 0;
  var pointIndex = 0; // This code has been profiled and optimized, so don't modify it without
  // measuring its performance.

  for (; index < len; ++pointIndex) {
    // Fully unrolling the following loops speeds things up about 5%.
    var result = 1;
    var shift = 0;
    var b = void 0;

    do {
      // Invariant: "result" is current partial result plus (1 << shift).
      // The following line effectively clears this bit by decrementing "b".
      b = encodedPath.charCodeAt(index++) - 63 - 1;
      result += b << shift;
      shift += 5;
    } while (b >= 0x1f); // See note above.


    lat += result & 1 ? ~(result >> 1) : result >> 1;
    result = 1;
    shift = 0;

    do {
      b = encodedPath.charCodeAt(index++) - 63 - 1;
      result += b << shift;
      shift += 5;
    } while (b >= 0x1f);

    lng += result & 1 ? ~(result >> 1) : result >> 1;
    path[pointIndex] = [lat / factor, lng / factor];
  } // truncate array


  path.length = pointIndex;
  return path;
};
/**
 * Polyline encodes an array of objects having lat and lng properties.
 *
 * See {@link https://developers.google.com/maps/documentation/utilities/polylinealgorithm}
 *
 * #### Example
 *
 * ```js
 * import { encode } from "@googlemaps/polyline-codec";
 *
 * const path = [
 *   [38.5, -120.2],
 *   [40.7, -120.95],
 *   [43.252, -126.453],
 * ];
 * console.log(encode(path, 5));
 * // "_p~iF~ps|U_ulLnnqC_mqNvxq`@"
 * ```
 */


var encode = function encode(path, precision) {
  if (precision === void 0) {
    precision = 5;
  }

  var factor = Math.pow(10, precision);

  var transform = function latLngToFixed(latLng) {
    if (!Array.isArray(latLng)) {
      latLng = [latLng.lat, latLng.lng];
    }

    return [round(latLng[0] * factor), round(latLng[1] * factor)];
  };

  return polylineEncodeLine(path, transform);
};
/**
 * Encodes a generic polyline; optionally performing a transform on each point
 * before encoding it.
 *
 * @ignore
 */


var polylineEncodeLine = function polylineEncodeLine(array, transform) {
  var v = [];
  var start = [0, 0];
  var end;

  for (var i = 0, I = array.length; i < I; ++i) {
    // In order to prevent drift (from quantizing deltas), we explicitly convert
    // coordinates to fixed-precision to obtain integer deltas.
    end = transform(array[i]); // Push the next edge

    polylineEncodeSigned(round(end[0]) - round(start[0]), v); // lat

    polylineEncodeSigned(round(end[1]) - round(start[1]), v); // lng

    start = end;
  }

  return v.join("");
};
/**
 * Encodes the given value in our compact polyline format, appending the
 * encoded value to the given array of strings.
 *
 * @ignore
 */


var polylineEncodeSigned = function polylineEncodeSigned(value, array) {
  return polylineEncodeUnsigned(value < 0 ? ~(value << 1) : value << 1, array);
};
/**
 * Helper function for encodeSigned.
 *
 * @ignore
 */


var polylineEncodeUnsigned = function polylineEncodeUnsigned(value, array) {
  while (value >= 0x20) {
    array.push(String.fromCharCode((0x20 | value & 0x1f) + 63));
    value >>= 5;
  }

  array.push(String.fromCharCode(value + 63));
  return array;
};
/**
 * @ignore
 */


var round = function round(v) {
  return Math.floor(Math.abs(v) + 0.5) * (v >= 0 ? 1 : -1);
};



/***/ })

}]);
//# sourceMappingURL=src_app_pages_trips_trip-detail_trip-detail_module_ts.js.map