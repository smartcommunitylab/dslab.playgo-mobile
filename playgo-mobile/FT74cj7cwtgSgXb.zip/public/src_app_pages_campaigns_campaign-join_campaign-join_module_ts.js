"use strict";
(self["webpackChunkapp"] = self["webpackChunkapp"] || []).push([["src_app_pages_campaigns_campaign-join_campaign-join_module_ts"],{

/***/ 87905:
/*!*******************************************************************************!*\
  !*** ./src/app/pages/campaigns/campaign-join/campaign-join-routing.module.ts ***!
  \*******************************************************************************/
/***/ (function(__unused_webpack_module, __webpack_exports__, __webpack_require__) {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "CampaignJoinPageRoutingModule": function() { return /* binding */ CampaignJoinPageRoutingModule; }
/* harmony export */ });
/* harmony import */ var _Users_smartcommunitylab_Desktop_newWork_dslab_playgo_mobile_playgo_mobile_node_modules_babel_runtime_helpers_esm_createClass_js__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./node_modules/@babel/runtime/helpers/esm/createClass.js */ 48047);
/* harmony import */ var _Users_smartcommunitylab_Desktop_newWork_dslab_playgo_mobile_playgo_mobile_node_modules_babel_runtime_helpers_esm_classCallCheck_js__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ./node_modules/@babel/runtime/helpers/esm/classCallCheck.js */ 78069);
/* harmony import */ var _angular_router__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! @angular/router */ 52816);
/* harmony import */ var _campaign_join_page__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! ./campaign-join.page */ 25041);
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @angular/core */ 3184);






var routes = [{
  path: '',
  component: _campaign_join_page__WEBPACK_IMPORTED_MODULE_2__.CampaignJoinPage,
  data: {
    title: '',
    defaultHref: '/pages/tabs/campaigns'
  }
}];
var CampaignJoinPageRoutingModule = /*#__PURE__*/(0,_Users_smartcommunitylab_Desktop_newWork_dslab_playgo_mobile_playgo_mobile_node_modules_babel_runtime_helpers_esm_createClass_js__WEBPACK_IMPORTED_MODULE_0__["default"])(function CampaignJoinPageRoutingModule() {
  (0,_Users_smartcommunitylab_Desktop_newWork_dslab_playgo_mobile_playgo_mobile_node_modules_babel_runtime_helpers_esm_classCallCheck_js__WEBPACK_IMPORTED_MODULE_1__["default"])(this, CampaignJoinPageRoutingModule);
});

CampaignJoinPageRoutingModule.ɵfac = function CampaignJoinPageRoutingModule_Factory(t) {
  return new (t || CampaignJoinPageRoutingModule)();
};

CampaignJoinPageRoutingModule.ɵmod = /*@__PURE__*/_angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵdefineNgModule"]({
  type: CampaignJoinPageRoutingModule
});
CampaignJoinPageRoutingModule.ɵinj = /*@__PURE__*/_angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵdefineInjector"]({
  imports: [[_angular_router__WEBPACK_IMPORTED_MODULE_4__.RouterModule.forChild(routes)], _angular_router__WEBPACK_IMPORTED_MODULE_4__.RouterModule]
});

(function () {
  (typeof ngJitMode === "undefined" || ngJitMode) && _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵsetNgModuleScope"](CampaignJoinPageRoutingModule, {
    imports: [_angular_router__WEBPACK_IMPORTED_MODULE_4__.RouterModule],
    exports: [_angular_router__WEBPACK_IMPORTED_MODULE_4__.RouterModule]
  });
})();

/***/ }),

/***/ 33309:
/*!***********************************************************************!*\
  !*** ./src/app/pages/campaigns/campaign-join/campaign-join.module.ts ***!
  \***********************************************************************/
/***/ (function(__unused_webpack_module, __webpack_exports__, __webpack_require__) {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "CampaignJoinPageModule": function() { return /* binding */ CampaignJoinPageModule; }
/* harmony export */ });
/* harmony import */ var _Users_smartcommunitylab_Desktop_newWork_dslab_playgo_mobile_playgo_mobile_node_modules_babel_runtime_helpers_esm_createClass_js__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./node_modules/@babel/runtime/helpers/esm/createClass.js */ 48047);
/* harmony import */ var _Users_smartcommunitylab_Desktop_newWork_dslab_playgo_mobile_playgo_mobile_node_modules_babel_runtime_helpers_esm_classCallCheck_js__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ./node_modules/@babel/runtime/helpers/esm/classCallCheck.js */ 78069);
/* harmony import */ var _campaign_join_routing_module__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! ./campaign-join-routing.module */ 87905);
/* harmony import */ var _campaign_join_page__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! ./campaign-join.page */ 25041);
/* harmony import */ var src_app_core_shared_shared_module__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! src/app/core/shared/shared.module */ 97205);
/* harmony import */ var _join_company_join_company_modal__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! ./join-company/join-company.modal */ 95305);
/* harmony import */ var _join_city_join_city_modal__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! ./join-city/join-city.modal */ 39899);
/* harmony import */ var _join_school_join_school_modal__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(/*! ./join-school/join-school.modal */ 65244);
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(/*! @angular/core */ 3184);









var CampaignJoinPageModule = /*#__PURE__*/(0,_Users_smartcommunitylab_Desktop_newWork_dslab_playgo_mobile_playgo_mobile_node_modules_babel_runtime_helpers_esm_createClass_js__WEBPACK_IMPORTED_MODULE_0__["default"])(function CampaignJoinPageModule() {
  (0,_Users_smartcommunitylab_Desktop_newWork_dslab_playgo_mobile_playgo_mobile_node_modules_babel_runtime_helpers_esm_classCallCheck_js__WEBPACK_IMPORTED_MODULE_1__["default"])(this, CampaignJoinPageModule);
});

CampaignJoinPageModule.ɵfac = function CampaignJoinPageModule_Factory(t) {
  return new (t || CampaignJoinPageModule)();
};

CampaignJoinPageModule.ɵmod = /*@__PURE__*/_angular_core__WEBPACK_IMPORTED_MODULE_8__["ɵɵdefineNgModule"]({
  type: CampaignJoinPageModule
});
CampaignJoinPageModule.ɵinj = /*@__PURE__*/_angular_core__WEBPACK_IMPORTED_MODULE_8__["ɵɵdefineInjector"]({
  imports: [[_campaign_join_routing_module__WEBPACK_IMPORTED_MODULE_2__.CampaignJoinPageRoutingModule, src_app_core_shared_shared_module__WEBPACK_IMPORTED_MODULE_4__.PlayGoSharedModule]]
});

(function () {
  (typeof ngJitMode === "undefined" || ngJitMode) && _angular_core__WEBPACK_IMPORTED_MODULE_8__["ɵɵsetNgModuleScope"](CampaignJoinPageModule, {
    declarations: [_campaign_join_page__WEBPACK_IMPORTED_MODULE_3__.CampaignJoinPage, _join_company_join_company_modal__WEBPACK_IMPORTED_MODULE_5__.JoinCompanyModalPage, _join_city_join_city_modal__WEBPACK_IMPORTED_MODULE_6__.JoinCityModalPage, _join_school_join_school_modal__WEBPACK_IMPORTED_MODULE_7__.JoinSchoolModalPage],
    imports: [_campaign_join_routing_module__WEBPACK_IMPORTED_MODULE_2__.CampaignJoinPageRoutingModule, src_app_core_shared_shared_module__WEBPACK_IMPORTED_MODULE_4__.PlayGoSharedModule]
  });
})();

/***/ }),

/***/ 25041:
/*!*********************************************************************!*\
  !*** ./src/app/pages/campaigns/campaign-join/campaign-join.page.ts ***!
  \*********************************************************************/
/***/ (function(__unused_webpack_module, __webpack_exports__, __webpack_require__) {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "CampaignJoinPage": function() { return /* binding */ CampaignJoinPage; }
/* harmony export */ });
/* harmony import */ var _Users_smartcommunitylab_Desktop_newWork_dslab_playgo_mobile_playgo_mobile_node_modules_babel_runtime_helpers_esm_slicedToArray_js__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./node_modules/@babel/runtime/helpers/esm/slicedToArray.js */ 10507);
/* harmony import */ var _Users_smartcommunitylab_Desktop_newWork_dslab_playgo_mobile_playgo_mobile_node_modules_babel_runtime_helpers_esm_classCallCheck_js__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ./node_modules/@babel/runtime/helpers/esm/classCallCheck.js */ 78069);
/* harmony import */ var _Users_smartcommunitylab_Desktop_newWork_dslab_playgo_mobile_playgo_mobile_node_modules_babel_runtime_helpers_esm_createClass_js__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! ./node_modules/@babel/runtime/helpers/esm/createClass.js */ 48047);
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_21__ = __webpack_require__(/*! tslib */ 42321);
/* harmony import */ var luxon__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! luxon */ 20020);
/* harmony import */ var rxjs__WEBPACK_IMPORTED_MODULE_20__ = __webpack_require__(/*! rxjs */ 26562);
/* harmony import */ var _home_campaign_details_companies_modal_companies_modal__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! ../../home/campaign-details/companies-modal/companies.modal */ 88043);
/* harmony import */ var _home_campaign_details_detail_modal_detail_modal__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! ../../home/campaign-details/detail-modal/detail.modal */ 30451);
/* harmony import */ var _join_city_join_city_modal__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! ./join-city/join-city.modal */ 39899);
/* harmony import */ var _join_company_join_company_modal__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(/*! ./join-company/join-company.modal */ 95305);
/* harmony import */ var _join_school_join_school_modal__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(/*! ./join-school/join-school.modal */ 65244);
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_19__ = __webpack_require__(/*! @angular/core */ 3184);
/* harmony import */ var _angular_router__WEBPACK_IMPORTED_MODULE_22__ = __webpack_require__(/*! @angular/router */ 52816);
/* harmony import */ var src_app_core_shared_services_campaign_service__WEBPACK_IMPORTED_MODULE_9__ = __webpack_require__(/*! src/app/core/shared/services/campaign.service */ 23645);
/* harmony import */ var src_app_core_shared_services_alert_service__WEBPACK_IMPORTED_MODULE_10__ = __webpack_require__(/*! src/app/core/shared/services/alert.service */ 46407);
/* harmony import */ var _ionic_angular__WEBPACK_IMPORTED_MODULE_23__ = __webpack_require__(/*! @ionic/angular */ 93819);
/* harmony import */ var src_app_core_shared_services_user_service__WEBPACK_IMPORTED_MODULE_11__ = __webpack_require__(/*! src/app/core/shared/services/user.service */ 50749);
/* harmony import */ var src_app_core_shared_services_page_settings_service__WEBPACK_IMPORTED_MODULE_12__ = __webpack_require__(/*! src/app/core/shared/services/page-settings.service */ 85294);
/* harmony import */ var src_app_core_api_generated_hsc_controllers_playerTeamController_service__WEBPACK_IMPORTED_MODULE_13__ = __webpack_require__(/*! src/app/core/api/generated-hsc/controllers/playerTeamController.service */ 75617);
/* harmony import */ var _angular_common__WEBPACK_IMPORTED_MODULE_24__ = __webpack_require__(/*! @angular/common */ 36362);
/* harmony import */ var _core_shared_directives_parallax_header_directive__WEBPACK_IMPORTED_MODULE_14__ = __webpack_require__(/*! ../../../core/shared/directives/parallax-header.directive */ 2773);
/* harmony import */ var _core_shared_layout_header_header_directive__WEBPACK_IMPORTED_MODULE_15__ = __webpack_require__(/*! ../../../core/shared/layout/header/header.directive */ 34161);
/* harmony import */ var _core_shared_layout_content_content_directive__WEBPACK_IMPORTED_MODULE_16__ = __webpack_require__(/*! ../../../core/shared/layout/content/content.directive */ 69669);
/* harmony import */ var _core_shared_pipes_localDate_pipe__WEBPACK_IMPORTED_MODULE_17__ = __webpack_require__(/*! ../../../core/shared/pipes/localDate.pipe */ 34489);
/* harmony import */ var _ngx_translate_core__WEBPACK_IMPORTED_MODULE_25__ = __webpack_require__(/*! @ngx-translate/core */ 87514);
/* harmony import */ var _core_shared_pipes_languageMap_pipe__WEBPACK_IMPORTED_MODULE_18__ = __webpack_require__(/*! ../../../core/shared/pipes/languageMap.pipe */ 73088);




function _regeneratorRuntime() { "use strict"; /*! regenerator-runtime -- Copyright (c) 2014-present, Facebook, Inc. -- license (MIT): https://github.com/facebook/regenerator/blob/main/LICENSE */ _regeneratorRuntime = function _regeneratorRuntime() { return e; }; var t, e = {}, r = Object.prototype, n = r.hasOwnProperty, o = Object.defineProperty || function (t, e, r) { t[e] = r.value; }, i = "function" == typeof Symbol ? Symbol : {}, a = i.iterator || "@@iterator", c = i.asyncIterator || "@@asyncIterator", u = i.toStringTag || "@@toStringTag"; function define(t, e, r) { return Object.defineProperty(t, e, { value: r, enumerable: !0, configurable: !0, writable: !0 }), t[e]; } try { define({}, ""); } catch (t) { define = function define(t, e, r) { return t[e] = r; }; } function wrap(t, e, r, n) { var i = e && e.prototype instanceof Generator ? e : Generator, a = Object.create(i.prototype), c = new Context(n || []); return o(a, "_invoke", { value: makeInvokeMethod(t, r, c) }), a; } function tryCatch(t, e, r) { try { return { type: "normal", arg: t.call(e, r) }; } catch (t) { return { type: "throw", arg: t }; } } e.wrap = wrap; var h = "suspendedStart", l = "suspendedYield", f = "executing", s = "completed", y = {}; function Generator() {} function GeneratorFunction() {} function GeneratorFunctionPrototype() {} var p = {}; define(p, a, function () { return this; }); var d = Object.getPrototypeOf, v = d && d(d(values([]))); v && v !== r && n.call(v, a) && (p = v); var g = GeneratorFunctionPrototype.prototype = Generator.prototype = Object.create(p); function defineIteratorMethods(t) { ["next", "throw", "return"].forEach(function (e) { define(t, e, function (t) { return this._invoke(e, t); }); }); } function AsyncIterator(t, e) { function invoke(r, o, i, a) { var c = tryCatch(t[r], t, o); if ("throw" !== c.type) { var u = c.arg, h = u.value; return h && "object" == typeof h && n.call(h, "__await") ? e.resolve(h.__await).then(function (t) { invoke("next", t, i, a); }, function (t) { invoke("throw", t, i, a); }) : e.resolve(h).then(function (t) { u.value = t, i(u); }, function (t) { return invoke("throw", t, i, a); }); } a(c.arg); } var r; o(this, "_invoke", { value: function value(t, n) { function callInvokeWithMethodAndArg() { return new e(function (e, r) { invoke(t, n, e, r); }); } return r = r ? r.then(callInvokeWithMethodAndArg, callInvokeWithMethodAndArg) : callInvokeWithMethodAndArg(); } }); } function makeInvokeMethod(e, r, n) { var o = h; return function (i, a) { if (o === f) throw new Error("Generator is already running"); if (o === s) { if ("throw" === i) throw a; return { value: t, done: !0 }; } for (n.method = i, n.arg = a;;) { var c = n.delegate; if (c) { var u = maybeInvokeDelegate(c, n); if (u) { if (u === y) continue; return u; } } if ("next" === n.method) n.sent = n._sent = n.arg;else if ("throw" === n.method) { if (o === h) throw o = s, n.arg; n.dispatchException(n.arg); } else "return" === n.method && n.abrupt("return", n.arg); o = f; var p = tryCatch(e, r, n); if ("normal" === p.type) { if (o = n.done ? s : l, p.arg === y) continue; return { value: p.arg, done: n.done }; } "throw" === p.type && (o = s, n.method = "throw", n.arg = p.arg); } }; } function maybeInvokeDelegate(e, r) { var n = r.method, o = e.iterator[n]; if (o === t) return r.delegate = null, "throw" === n && e.iterator.return && (r.method = "return", r.arg = t, maybeInvokeDelegate(e, r), "throw" === r.method) || "return" !== n && (r.method = "throw", r.arg = new TypeError("The iterator does not provide a '" + n + "' method")), y; var i = tryCatch(o, e.iterator, r.arg); if ("throw" === i.type) return r.method = "throw", r.arg = i.arg, r.delegate = null, y; var a = i.arg; return a ? a.done ? (r[e.resultName] = a.value, r.next = e.nextLoc, "return" !== r.method && (r.method = "next", r.arg = t), r.delegate = null, y) : a : (r.method = "throw", r.arg = new TypeError("iterator result is not an object"), r.delegate = null, y); } function pushTryEntry(t) { var e = { tryLoc: t[0] }; 1 in t && (e.catchLoc = t[1]), 2 in t && (e.finallyLoc = t[2], e.afterLoc = t[3]), this.tryEntries.push(e); } function resetTryEntry(t) { var e = t.completion || {}; e.type = "normal", delete e.arg, t.completion = e; } function Context(t) { this.tryEntries = [{ tryLoc: "root" }], t.forEach(pushTryEntry, this), this.reset(!0); } function values(e) { if (e || "" === e) { var r = e[a]; if (r) return r.call(e); if ("function" == typeof e.next) return e; if (!isNaN(e.length)) { var o = -1, i = function next() { for (; ++o < e.length;) if (n.call(e, o)) return next.value = e[o], next.done = !1, next; return next.value = t, next.done = !0, next; }; return i.next = i; } } throw new TypeError(typeof e + " is not iterable"); } return GeneratorFunction.prototype = GeneratorFunctionPrototype, o(g, "constructor", { value: GeneratorFunctionPrototype, configurable: !0 }), o(GeneratorFunctionPrototype, "constructor", { value: GeneratorFunction, configurable: !0 }), GeneratorFunction.displayName = define(GeneratorFunctionPrototype, u, "GeneratorFunction"), e.isGeneratorFunction = function (t) { var e = "function" == typeof t && t.constructor; return !!e && (e === GeneratorFunction || "GeneratorFunction" === (e.displayName || e.name)); }, e.mark = function (t) { return Object.setPrototypeOf ? Object.setPrototypeOf(t, GeneratorFunctionPrototype) : (t.__proto__ = GeneratorFunctionPrototype, define(t, u, "GeneratorFunction")), t.prototype = Object.create(g), t; }, e.awrap = function (t) { return { __await: t }; }, defineIteratorMethods(AsyncIterator.prototype), define(AsyncIterator.prototype, c, function () { return this; }), e.AsyncIterator = AsyncIterator, e.async = function (t, r, n, o, i) { void 0 === i && (i = Promise); var a = new AsyncIterator(wrap(t, r, n, o), i); return e.isGeneratorFunction(r) ? a : a.next().then(function (t) { return t.done ? t.value : a.next(); }); }, defineIteratorMethods(g), define(g, u, "Generator"), define(g, a, function () { return this; }), define(g, "toString", function () { return "[object Generator]"; }), e.keys = function (t) { var e = Object(t), r = []; for (var n in e) r.push(n); return r.reverse(), function next() { for (; r.length;) { var t = r.pop(); if (t in e) return next.value = t, next.done = !1, next; } return next.done = !0, next; }; }, e.values = values, Context.prototype = { constructor: Context, reset: function reset(e) { if (this.prev = 0, this.next = 0, this.sent = this._sent = t, this.done = !1, this.delegate = null, this.method = "next", this.arg = t, this.tryEntries.forEach(resetTryEntry), !e) for (var r in this) "t" === r.charAt(0) && n.call(this, r) && !isNaN(+r.slice(1)) && (this[r] = t); }, stop: function stop() { this.done = !0; var t = this.tryEntries[0].completion; if ("throw" === t.type) throw t.arg; return this.rval; }, dispatchException: function dispatchException(e) { if (this.done) throw e; var r = this; function handle(n, o) { return a.type = "throw", a.arg = e, r.next = n, o && (r.method = "next", r.arg = t), !!o; } for (var o = this.tryEntries.length - 1; o >= 0; --o) { var i = this.tryEntries[o], a = i.completion; if ("root" === i.tryLoc) return handle("end"); if (i.tryLoc <= this.prev) { var c = n.call(i, "catchLoc"), u = n.call(i, "finallyLoc"); if (c && u) { if (this.prev < i.catchLoc) return handle(i.catchLoc, !0); if (this.prev < i.finallyLoc) return handle(i.finallyLoc); } else if (c) { if (this.prev < i.catchLoc) return handle(i.catchLoc, !0); } else { if (!u) throw new Error("try statement without catch or finally"); if (this.prev < i.finallyLoc) return handle(i.finallyLoc); } } } }, abrupt: function abrupt(t, e) { for (var r = this.tryEntries.length - 1; r >= 0; --r) { var o = this.tryEntries[r]; if (o.tryLoc <= this.prev && n.call(o, "finallyLoc") && this.prev < o.finallyLoc) { var i = o; break; } } i && ("break" === t || "continue" === t) && i.tryLoc <= e && e <= i.finallyLoc && (i = null); var a = i ? i.completion : {}; return a.type = t, a.arg = e, i ? (this.method = "next", this.next = i.finallyLoc, y) : this.complete(a); }, complete: function complete(t, e) { if ("throw" === t.type) throw t.arg; return "break" === t.type || "continue" === t.type ? this.next = t.arg : "return" === t.type ? (this.rval = this.arg = t.arg, this.method = "return", this.next = "end") : "normal" === t.type && e && (this.next = e), y; }, finish: function finish(t) { for (var e = this.tryEntries.length - 1; e >= 0; --e) { var r = this.tryEntries[e]; if (r.finallyLoc === t) return this.complete(r.completion, r.afterLoc), resetTryEntry(r), y; } }, catch: function _catch(t) { for (var e = this.tryEntries.length - 1; e >= 0; --e) { var r = this.tryEntries[e]; if (r.tryLoc === t) { var n = r.completion; if ("throw" === n.type) { var o = n.arg; resetTryEntry(r); } return o; } } throw new Error("illegal catch attempt"); }, delegateYield: function delegateYield(e, r, n) { return this.delegate = { iterator: values(e), resultName: r, nextLoc: n }, "next" === this.method && (this.arg = t), y; } }, e; }

























function CampaignJoinPage_ng_container_0_ion_button_8_Template(rf, ctx) {
  if (rf & 1) {
    var _r10 = _angular_core__WEBPACK_IMPORTED_MODULE_19__["ɵɵgetCurrentView"]();

    _angular_core__WEBPACK_IMPORTED_MODULE_19__["ɵɵelementStart"](0, "ion-button", 17);
    _angular_core__WEBPACK_IMPORTED_MODULE_19__["ɵɵlistener"]("click", function CampaignJoinPage_ng_container_0_ion_button_8_Template_ion_button_click_0_listener() {
      _angular_core__WEBPACK_IMPORTED_MODULE_19__["ɵɵrestoreView"](_r10);
      var ctx_r9 = _angular_core__WEBPACK_IMPORTED_MODULE_19__["ɵɵnextContext"](2);
      return ctx_r9.joinCampaign(ctx_r9.campaign);
    });
    _angular_core__WEBPACK_IMPORTED_MODULE_19__["ɵɵtext"](1);
    _angular_core__WEBPACK_IMPORTED_MODULE_19__["ɵɵpipe"](2, "translate");
    _angular_core__WEBPACK_IMPORTED_MODULE_19__["ɵɵelementEnd"]();
  }

  if (rf & 2) {
    var ctx_r1 = _angular_core__WEBPACK_IMPORTED_MODULE_19__["ɵɵnextContext"](2);
    _angular_core__WEBPACK_IMPORTED_MODULE_19__["ɵɵproperty"]("disabled", ctx_r1.campaignNotStarted(ctx_r1.campaign) || !ctx_r1.canSubscribe);
    _angular_core__WEBPACK_IMPORTED_MODULE_19__["ɵɵadvance"](1);
    _angular_core__WEBPACK_IMPORTED_MODULE_19__["ɵɵtextInterpolate1"](" ", _angular_core__WEBPACK_IMPORTED_MODULE_19__["ɵɵpipeBind1"](2, 2, "campaigns.join"), " ");
  }
}

function CampaignJoinPage_ng_container_0_div_10_span_1_Template(rf, ctx) {
  if (rf & 1) {
    _angular_core__WEBPACK_IMPORTED_MODULE_19__["ɵɵelementStart"](0, "span");
    _angular_core__WEBPACK_IMPORTED_MODULE_19__["ɵɵtext"](1);
    _angular_core__WEBPACK_IMPORTED_MODULE_19__["ɵɵpipe"](2, "translate");
    _angular_core__WEBPACK_IMPORTED_MODULE_19__["ɵɵelementEnd"]();
  }

  if (rf & 2) {
    _angular_core__WEBPACK_IMPORTED_MODULE_19__["ɵɵadvance"](1);
    _angular_core__WEBPACK_IMPORTED_MODULE_19__["ɵɵtextInterpolate"](_angular_core__WEBPACK_IMPORTED_MODULE_19__["ɵɵpipeBind1"](2, 1, "campaigns.notStartedHSC"));
  }
}

function CampaignJoinPage_ng_container_0_div_10_ng_template_2_Template(rf, ctx) {
  if (rf & 1) {
    _angular_core__WEBPACK_IMPORTED_MODULE_19__["ɵɵelementStart"](0, "span");
    _angular_core__WEBPACK_IMPORTED_MODULE_19__["ɵɵtext"](1);
    _angular_core__WEBPACK_IMPORTED_MODULE_19__["ɵɵpipe"](2, "translate");
    _angular_core__WEBPACK_IMPORTED_MODULE_19__["ɵɵelementEnd"]();
  }

  if (rf & 2) {
    _angular_core__WEBPACK_IMPORTED_MODULE_19__["ɵɵadvance"](1);
    _angular_core__WEBPACK_IMPORTED_MODULE_19__["ɵɵtextInterpolate"](_angular_core__WEBPACK_IMPORTED_MODULE_19__["ɵɵpipeBind1"](2, 1, "campaigns.notStarted"));
  }
}

function CampaignJoinPage_ng_container_0_div_10_Template(rf, ctx) {
  if (rf & 1) {
    _angular_core__WEBPACK_IMPORTED_MODULE_19__["ɵɵelementStart"](0, "div");
    _angular_core__WEBPACK_IMPORTED_MODULE_19__["ɵɵtemplate"](1, CampaignJoinPage_ng_container_0_div_10_span_1_Template, 3, 3, "span", 8);
    _angular_core__WEBPACK_IMPORTED_MODULE_19__["ɵɵtemplate"](2, CampaignJoinPage_ng_container_0_div_10_ng_template_2_Template, 3, 3, "ng-template", null, 18, _angular_core__WEBPACK_IMPORTED_MODULE_19__["ɵɵtemplateRefExtractor"]);
    _angular_core__WEBPACK_IMPORTED_MODULE_19__["ɵɵelementEnd"]();
  }

  if (rf & 2) {
    var _r12 = _angular_core__WEBPACK_IMPORTED_MODULE_19__["ɵɵreference"](3);

    var ctx_r2 = _angular_core__WEBPACK_IMPORTED_MODULE_19__["ɵɵnextContext"](2);
    _angular_core__WEBPACK_IMPORTED_MODULE_19__["ɵɵadvance"](1);
    _angular_core__WEBPACK_IMPORTED_MODULE_19__["ɵɵproperty"]("ngIf", ctx_r2.isSchool())("ngIfElse", _r12);
  }
}

function CampaignJoinPage_ng_container_0_ng_template_11_span_0_Template(rf, ctx) {
  if (rf & 1) {
    _angular_core__WEBPACK_IMPORTED_MODULE_19__["ɵɵelement"](0, "span", 20);
    _angular_core__WEBPACK_IMPORTED_MODULE_19__["ɵɵpipe"](1, "translate");
  }

  if (rf & 2) {
    _angular_core__WEBPACK_IMPORTED_MODULE_19__["ɵɵproperty"]("innerHTML", _angular_core__WEBPACK_IMPORTED_MODULE_19__["ɵɵpipeBind1"](1, 1, "campaigns.cantSubscribe"), _angular_core__WEBPACK_IMPORTED_MODULE_19__["ɵɵsanitizeHtml"]);
  }
}

function CampaignJoinPage_ng_container_0_ng_template_11_Template(rf, ctx) {
  if (rf & 1) {
    _angular_core__WEBPACK_IMPORTED_MODULE_19__["ɵɵtemplate"](0, CampaignJoinPage_ng_container_0_ng_template_11_span_0_Template, 2, 3, "span", 19);
  }

  if (rf & 2) {
    var ctx_r4 = _angular_core__WEBPACK_IMPORTED_MODULE_19__["ɵɵnextContext"](2);
    _angular_core__WEBPACK_IMPORTED_MODULE_19__["ɵɵproperty"]("ngIf", !ctx_r4.canSubscribe);
  }
}

function CampaignJoinPage_ng_container_0_div_15_Template(rf, ctx) {
  if (rf & 1) {
    _angular_core__WEBPACK_IMPORTED_MODULE_19__["ɵɵelementStart"](0, "div");
    _angular_core__WEBPACK_IMPORTED_MODULE_19__["ɵɵelement"](1, "div", 20);
    _angular_core__WEBPACK_IMPORTED_MODULE_19__["ɵɵpipe"](2, "languageMap");
    _angular_core__WEBPACK_IMPORTED_MODULE_19__["ɵɵelementEnd"]();
  }

  if (rf & 2) {
    var ctx_r5 = _angular_core__WEBPACK_IMPORTED_MODULE_19__["ɵɵnextContext"](2);
    var tmp_0_0;
    _angular_core__WEBPACK_IMPORTED_MODULE_19__["ɵɵadvance"](1);
    _angular_core__WEBPACK_IMPORTED_MODULE_19__["ɵɵproperty"]("innerHTML", (tmp_0_0 = ctx_r5.getCampaignSponsor(_angular_core__WEBPACK_IMPORTED_MODULE_19__["ɵɵpipeBind1"](2, 1, ctx_r5.campaign == null ? null : ctx_r5.campaign.details))) == null ? null : tmp_0_0.content, _angular_core__WEBPACK_IMPORTED_MODULE_19__["ɵɵsanitizeHtml"]);
  }
}

function CampaignJoinPage_ng_container_0_ion_icon_35_Template(rf, ctx) {
  if (rf & 1) {
    _angular_core__WEBPACK_IMPORTED_MODULE_19__["ɵɵelement"](0, "ion-icon", 21);
  }
}

function CampaignJoinPage_ng_container_0_ion_icon_36_Template(rf, ctx) {
  if (rf & 1) {
    _angular_core__WEBPACK_IMPORTED_MODULE_19__["ɵɵelement"](0, "ion-icon", 22);
  }
}

function CampaignJoinPage_ng_container_0_div_37_ng_container_1_div_1_Template(rf, ctx) {
  if (rf & 1) {
    var _r22 = _angular_core__WEBPACK_IMPORTED_MODULE_19__["ɵɵgetCurrentView"]();

    _angular_core__WEBPACK_IMPORTED_MODULE_19__["ɵɵelementStart"](0, "div", 25);
    _angular_core__WEBPACK_IMPORTED_MODULE_19__["ɵɵlistener"]("click", function CampaignJoinPage_ng_container_0_div_37_ng_container_1_div_1_Template_div_click_0_listener() {
      _angular_core__WEBPACK_IMPORTED_MODULE_19__["ɵɵrestoreView"](_r22);
      var detail_r18 = _angular_core__WEBPACK_IMPORTED_MODULE_19__["ɵɵnextContext"]().$implicit;
      var ctx_r20 = _angular_core__WEBPACK_IMPORTED_MODULE_19__["ɵɵnextContext"](3);
      return ctx_r20.openDetail(detail_r18);
    });
    _angular_core__WEBPACK_IMPORTED_MODULE_19__["ɵɵelementStart"](1, "ion-item", 26)(2, "ion-label")(3, "span", 27);
    _angular_core__WEBPACK_IMPORTED_MODULE_19__["ɵɵtext"](4);
    _angular_core__WEBPACK_IMPORTED_MODULE_19__["ɵɵelementEnd"]()();
    _angular_core__WEBPACK_IMPORTED_MODULE_19__["ɵɵelement"](5, "ion-icon", 28);
    _angular_core__WEBPACK_IMPORTED_MODULE_19__["ɵɵelementEnd"]()();
  }

  if (rf & 2) {
    var detail_r18 = _angular_core__WEBPACK_IMPORTED_MODULE_19__["ɵɵnextContext"]().$implicit;
    _angular_core__WEBPACK_IMPORTED_MODULE_19__["ɵɵadvance"](4);
    _angular_core__WEBPACK_IMPORTED_MODULE_19__["ɵɵtextInterpolate1"](" ", detail_r18.name, "");
  }
}

function CampaignJoinPage_ng_container_0_div_37_ng_container_1_Template(rf, ctx) {
  if (rf & 1) {
    _angular_core__WEBPACK_IMPORTED_MODULE_19__["ɵɵelementContainerStart"](0);
    _angular_core__WEBPACK_IMPORTED_MODULE_19__["ɵɵtemplate"](1, CampaignJoinPage_ng_container_0_div_37_ng_container_1_div_1_Template, 6, 1, "div", 24);
    _angular_core__WEBPACK_IMPORTED_MODULE_19__["ɵɵelementContainerEnd"]();
  }

  if (rf & 2) {
    var detail_r18 = ctx.$implicit;
    _angular_core__WEBPACK_IMPORTED_MODULE_19__["ɵɵadvance"](1);
    _angular_core__WEBPACK_IMPORTED_MODULE_19__["ɵɵproperty"]("ngIf", detail_r18.type !== "sponsor");
  }
}

function CampaignJoinPage_ng_container_0_div_37_div_2_Template(rf, ctx) {
  if (rf & 1) {
    var _r25 = _angular_core__WEBPACK_IMPORTED_MODULE_19__["ɵɵgetCurrentView"]();

    _angular_core__WEBPACK_IMPORTED_MODULE_19__["ɵɵelementStart"](0, "div")(1, "ion-item", 29);
    _angular_core__WEBPACK_IMPORTED_MODULE_19__["ɵɵlistener"]("click", function CampaignJoinPage_ng_container_0_div_37_div_2_Template_ion_item_click_1_listener() {
      _angular_core__WEBPACK_IMPORTED_MODULE_19__["ɵɵrestoreView"](_r25);
      var ctx_r24 = _angular_core__WEBPACK_IMPORTED_MODULE_19__["ɵɵnextContext"](3);
      return ctx_r24.openCompanies();
    });
    _angular_core__WEBPACK_IMPORTED_MODULE_19__["ɵɵelementStart"](2, "ion-label")(3, "span", 27);
    _angular_core__WEBPACK_IMPORTED_MODULE_19__["ɵɵtext"](4);
    _angular_core__WEBPACK_IMPORTED_MODULE_19__["ɵɵpipe"](5, "translate");
    _angular_core__WEBPACK_IMPORTED_MODULE_19__["ɵɵelementEnd"]()();
    _angular_core__WEBPACK_IMPORTED_MODULE_19__["ɵɵelement"](6, "ion-icon", 28);
    _angular_core__WEBPACK_IMPORTED_MODULE_19__["ɵɵelementEnd"]()();
  }

  if (rf & 2) {
    _angular_core__WEBPACK_IMPORTED_MODULE_19__["ɵɵadvance"](4);
    _angular_core__WEBPACK_IMPORTED_MODULE_19__["ɵɵtextInterpolate1"](" ", _angular_core__WEBPACK_IMPORTED_MODULE_19__["ɵɵpipeBind1"](5, 1, "campaigns.detail.companies"), " ");
  }
}

function CampaignJoinPage_ng_container_0_div_37_Template(rf, ctx) {
  if (rf & 1) {
    _angular_core__WEBPACK_IMPORTED_MODULE_19__["ɵɵelementStart"](0, "div");
    _angular_core__WEBPACK_IMPORTED_MODULE_19__["ɵɵtemplate"](1, CampaignJoinPage_ng_container_0_div_37_ng_container_1_Template, 2, 1, "ng-container", 23);
    _angular_core__WEBPACK_IMPORTED_MODULE_19__["ɵɵtemplate"](2, CampaignJoinPage_ng_container_0_div_37_div_2_Template, 7, 3, "div", 0);
    _angular_core__WEBPACK_IMPORTED_MODULE_19__["ɵɵelementEnd"]();
  }

  if (rf & 2) {
    var details_r15 = ctx.ngIf;
    var ctx_r8 = _angular_core__WEBPACK_IMPORTED_MODULE_19__["ɵɵnextContext"](2);
    _angular_core__WEBPACK_IMPORTED_MODULE_19__["ɵɵadvance"](1);
    _angular_core__WEBPACK_IMPORTED_MODULE_19__["ɵɵproperty"]("ngForOf", details_r15);
    _angular_core__WEBPACK_IMPORTED_MODULE_19__["ɵɵadvance"](1);
    _angular_core__WEBPACK_IMPORTED_MODULE_19__["ɵɵproperty"]("ngIf", ctx_r8.isCompany() && (ctx_r8.campaign == null ? null : ctx_r8.campaign.specificData == null ? null : ctx_r8.campaign.specificData.hideCompanyDesc) !== true);
  }
}

function CampaignJoinPage_ng_container_0_Template(rf, ctx) {
  if (rf & 1) {
    var _r27 = _angular_core__WEBPACK_IMPORTED_MODULE_19__["ɵɵgetCurrentView"]();

    _angular_core__WEBPACK_IMPORTED_MODULE_19__["ɵɵelementContainerStart"](0);
    _angular_core__WEBPACK_IMPORTED_MODULE_19__["ɵɵelement"](1, "ion-header", 1);
    _angular_core__WEBPACK_IMPORTED_MODULE_19__["ɵɵpipe"](2, "localDate");
    _angular_core__WEBPACK_IMPORTED_MODULE_19__["ɵɵpipe"](3, "localDate");
    _angular_core__WEBPACK_IMPORTED_MODULE_19__["ɵɵelementStart"](4, "ion-content", 2)(5, "div", 3)(6, "ion-avatar", 4);
    _angular_core__WEBPACK_IMPORTED_MODULE_19__["ɵɵelement"](7, "img", 5);
    _angular_core__WEBPACK_IMPORTED_MODULE_19__["ɵɵelementEnd"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_19__["ɵɵtemplate"](8, CampaignJoinPage_ng_container_0_ion_button_8_Template, 3, 4, "ion-button", 6);
    _angular_core__WEBPACK_IMPORTED_MODULE_19__["ɵɵelementStart"](9, "div", 7);
    _angular_core__WEBPACK_IMPORTED_MODULE_19__["ɵɵtemplate"](10, CampaignJoinPage_ng_container_0_div_10_Template, 4, 2, "div", 8);
    _angular_core__WEBPACK_IMPORTED_MODULE_19__["ɵɵtemplate"](11, CampaignJoinPage_ng_container_0_ng_template_11_Template, 1, 1, "ng-template", null, 9, _angular_core__WEBPACK_IMPORTED_MODULE_19__["ɵɵtemplateRefExtractor"]);
    _angular_core__WEBPACK_IMPORTED_MODULE_19__["ɵɵelementEnd"]()();
    _angular_core__WEBPACK_IMPORTED_MODULE_19__["ɵɵelementStart"](13, "ion-card")(14, "ion-card-content");
    _angular_core__WEBPACK_IMPORTED_MODULE_19__["ɵɵtemplate"](15, CampaignJoinPage_ng_container_0_div_15_Template, 3, 3, "div", 0);
    _angular_core__WEBPACK_IMPORTED_MODULE_19__["ɵɵpipe"](16, "languageMap");
    _angular_core__WEBPACK_IMPORTED_MODULE_19__["ɵɵelementStart"](17, "ion-item", 10)(18, "ion-label");
    _angular_core__WEBPACK_IMPORTED_MODULE_19__["ɵɵtext"](19);
    _angular_core__WEBPACK_IMPORTED_MODULE_19__["ɵɵpipe"](20, "translate");
    _angular_core__WEBPACK_IMPORTED_MODULE_19__["ɵɵelementStart"](21, "span", 11);
    _angular_core__WEBPACK_IMPORTED_MODULE_19__["ɵɵtext"](22);
    _angular_core__WEBPACK_IMPORTED_MODULE_19__["ɵɵpipe"](23, "localDate");
    _angular_core__WEBPACK_IMPORTED_MODULE_19__["ɵɵelementEnd"]()()();
    _angular_core__WEBPACK_IMPORTED_MODULE_19__["ɵɵelementStart"](24, "ion-item", 10)(25, "ion-label");
    _angular_core__WEBPACK_IMPORTED_MODULE_19__["ɵɵtext"](26);
    _angular_core__WEBPACK_IMPORTED_MODULE_19__["ɵɵpipe"](27, "translate");
    _angular_core__WEBPACK_IMPORTED_MODULE_19__["ɵɵelementStart"](28, "span", 11);
    _angular_core__WEBPACK_IMPORTED_MODULE_19__["ɵɵtext"](29);
    _angular_core__WEBPACK_IMPORTED_MODULE_19__["ɵɵpipe"](30, "localDate");
    _angular_core__WEBPACK_IMPORTED_MODULE_19__["ɵɵelementEnd"]()()();
    _angular_core__WEBPACK_IMPORTED_MODULE_19__["ɵɵelementStart"](31, "div", 12);
    _angular_core__WEBPACK_IMPORTED_MODULE_19__["ɵɵlistener"]("click", function CampaignJoinPage_ng_container_0_Template_div_click_31_listener() {
      _angular_core__WEBPACK_IMPORTED_MODULE_19__["ɵɵrestoreView"](_r27);
      var ctx_r26 = _angular_core__WEBPACK_IMPORTED_MODULE_19__["ɵɵnextContext"]();
      return ctx_r26.clickDescription();
    });
    _angular_core__WEBPACK_IMPORTED_MODULE_19__["ɵɵelement"](32, "div", 13);
    _angular_core__WEBPACK_IMPORTED_MODULE_19__["ɵɵpipe"](33, "languageMap");
    _angular_core__WEBPACK_IMPORTED_MODULE_19__["ɵɵelementEnd"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_19__["ɵɵelementStart"](34, "div", 14);
    _angular_core__WEBPACK_IMPORTED_MODULE_19__["ɵɵlistener"]("click", function CampaignJoinPage_ng_container_0_Template_div_click_34_listener() {
      _angular_core__WEBPACK_IMPORTED_MODULE_19__["ɵɵrestoreView"](_r27);
      var ctx_r28 = _angular_core__WEBPACK_IMPORTED_MODULE_19__["ɵɵnextContext"]();
      return ctx_r28.clickDescription();
    });
    _angular_core__WEBPACK_IMPORTED_MODULE_19__["ɵɵtemplate"](35, CampaignJoinPage_ng_container_0_ion_icon_35_Template, 1, 0, "ion-icon", 15);
    _angular_core__WEBPACK_IMPORTED_MODULE_19__["ɵɵtemplate"](36, CampaignJoinPage_ng_container_0_ion_icon_36_Template, 1, 0, "ion-icon", 16);
    _angular_core__WEBPACK_IMPORTED_MODULE_19__["ɵɵelementEnd"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_19__["ɵɵtemplate"](37, CampaignJoinPage_ng_container_0_div_37_Template, 3, 2, "div", 0);
    _angular_core__WEBPACK_IMPORTED_MODULE_19__["ɵɵpipe"](38, "languageMap");
    _angular_core__WEBPACK_IMPORTED_MODULE_19__["ɵɵelementEnd"]()()();
    _angular_core__WEBPACK_IMPORTED_MODULE_19__["ɵɵelementContainerEnd"]();
  }

  if (rf & 2) {
    var _r3 = _angular_core__WEBPACK_IMPORTED_MODULE_19__["ɵɵreference"](12);

    var ctx_r0 = _angular_core__WEBPACK_IMPORTED_MODULE_19__["ɵɵnextContext"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_19__["ɵɵadvance"](1);
    _angular_core__WEBPACK_IMPORTED_MODULE_19__["ɵɵpropertyInterpolate2"]("text", "", _angular_core__WEBPACK_IMPORTED_MODULE_19__["ɵɵpipeBind2"](2, 20, ctx_r0.campaign == null ? null : ctx_r0.campaign.dateFrom, "dd MMMM y"), " - ", _angular_core__WEBPACK_IMPORTED_MODULE_19__["ɵɵpipeBind2"](3, 23, ctx_r0.campaign == null ? null : ctx_r0.campaign.dateTo, "dd MMMM y"), "");
    _angular_core__WEBPACK_IMPORTED_MODULE_19__["ɵɵproperty"]("imageUrl", ctx_r0.campaign == null ? null : ctx_r0.campaign.banner == null ? null : ctx_r0.campaign.banner.url)("logo", ctx_r0.imagePath);
    _angular_core__WEBPACK_IMPORTED_MODULE_19__["ɵɵadvance"](3);
    _angular_core__WEBPACK_IMPORTED_MODULE_19__["ɵɵproperty"]("fullscreen", true);
    _angular_core__WEBPACK_IMPORTED_MODULE_19__["ɵɵadvance"](2);
    _angular_core__WEBPACK_IMPORTED_MODULE_19__["ɵɵproperty"]("ngClass", ctx_r0.campaign.type);
    _angular_core__WEBPACK_IMPORTED_MODULE_19__["ɵɵadvance"](1);
    _angular_core__WEBPACK_IMPORTED_MODULE_19__["ɵɵproperty"]("src", ctx_r0.imagePath, _angular_core__WEBPACK_IMPORTED_MODULE_19__["ɵɵsanitizeUrl"]);
    _angular_core__WEBPACK_IMPORTED_MODULE_19__["ɵɵadvance"](1);
    _angular_core__WEBPACK_IMPORTED_MODULE_19__["ɵɵproperty"]("ngIf", ctx_r0.joinIsVisible(ctx_r0.campaign));
    _angular_core__WEBPACK_IMPORTED_MODULE_19__["ɵɵadvance"](2);
    _angular_core__WEBPACK_IMPORTED_MODULE_19__["ɵɵproperty"]("ngIf", ctx_r0.campaignNotStarted(ctx_r0.campaign))("ngIfElse", _r3);
    _angular_core__WEBPACK_IMPORTED_MODULE_19__["ɵɵadvance"](5);
    _angular_core__WEBPACK_IMPORTED_MODULE_19__["ɵɵproperty"]("ngIf", ctx_r0.campaignHasSponsor(_angular_core__WEBPACK_IMPORTED_MODULE_19__["ɵɵpipeBind1"](16, 26, ctx_r0.campaign == null ? null : ctx_r0.campaign.details)));
    _angular_core__WEBPACK_IMPORTED_MODULE_19__["ɵɵadvance"](4);
    _angular_core__WEBPACK_IMPORTED_MODULE_19__["ɵɵtextInterpolate"](_angular_core__WEBPACK_IMPORTED_MODULE_19__["ɵɵpipeBind1"](20, 28, "campaigns.detail.dateFrom"));
    _angular_core__WEBPACK_IMPORTED_MODULE_19__["ɵɵadvance"](3);
    _angular_core__WEBPACK_IMPORTED_MODULE_19__["ɵɵtextInterpolate"](_angular_core__WEBPACK_IMPORTED_MODULE_19__["ɵɵpipeBind1"](23, 30, ctx_r0.campaign.dateFrom));
    _angular_core__WEBPACK_IMPORTED_MODULE_19__["ɵɵadvance"](4);
    _angular_core__WEBPACK_IMPORTED_MODULE_19__["ɵɵtextInterpolate"](_angular_core__WEBPACK_IMPORTED_MODULE_19__["ɵɵpipeBind1"](27, 32, "campaigns.detail.dateTo"));
    _angular_core__WEBPACK_IMPORTED_MODULE_19__["ɵɵadvance"](3);
    _angular_core__WEBPACK_IMPORTED_MODULE_19__["ɵɵtextInterpolate"](_angular_core__WEBPACK_IMPORTED_MODULE_19__["ɵɵpipeBind1"](30, 34, ctx_r0.campaign.dateTo));
    _angular_core__WEBPACK_IMPORTED_MODULE_19__["ɵɵadvance"](2);
    _angular_core__WEBPACK_IMPORTED_MODULE_19__["ɵɵproperty"]("ngClass", ctx_r0.descriptionExpanded ? "open" : "");
    _angular_core__WEBPACK_IMPORTED_MODULE_19__["ɵɵadvance"](1);
    _angular_core__WEBPACK_IMPORTED_MODULE_19__["ɵɵproperty"]("innerHTML", _angular_core__WEBPACK_IMPORTED_MODULE_19__["ɵɵpipeBind1"](33, 36, ctx_r0.campaign.description), _angular_core__WEBPACK_IMPORTED_MODULE_19__["ɵɵsanitizeHtml"]);
    _angular_core__WEBPACK_IMPORTED_MODULE_19__["ɵɵadvance"](3);
    _angular_core__WEBPACK_IMPORTED_MODULE_19__["ɵɵproperty"]("ngIf", ctx_r0.descriptionExpanded);
    _angular_core__WEBPACK_IMPORTED_MODULE_19__["ɵɵadvance"](1);
    _angular_core__WEBPACK_IMPORTED_MODULE_19__["ɵɵproperty"]("ngIf", !ctx_r0.descriptionExpanded);
    _angular_core__WEBPACK_IMPORTED_MODULE_19__["ɵɵadvance"](1);
    _angular_core__WEBPACK_IMPORTED_MODULE_19__["ɵɵproperty"]("ngIf", _angular_core__WEBPACK_IMPORTED_MODULE_19__["ɵɵpipeBind1"](38, 38, ctx_r0.campaign.details));
  }
}

var CampaignJoinPage = /*#__PURE__*/function () {
  function CampaignJoinPage(route, campaignService, alertService, navCtrl, modalController, userService, pageSettingsService, playerTeamControllerService) {
    var _this = this;

    (0,_Users_smartcommunitylab_Desktop_newWork_dslab_playgo_mobile_playgo_mobile_node_modules_babel_runtime_helpers_esm_classCallCheck_js__WEBPACK_IMPORTED_MODULE_1__["default"])(this, CampaignJoinPage);

    this.route = route;
    this.campaignService = campaignService;
    this.alertService = alertService;
    this.navCtrl = navCtrl;
    this.modalController = modalController;
    this.userService = userService;
    this.pageSettingsService = pageSettingsService;
    this.playerTeamControllerService = playerTeamControllerService;
    this.descriptionExpanded = false;
    this.canSubscribe = false;
    this.route.params.subscribe(function (params) {
      return _this.id = params.id;
    });
  }

  (0,_Users_smartcommunitylab_Desktop_newWork_dslab_playgo_mobile_playgo_mobile_node_modules_babel_runtime_helpers_esm_createClass_js__WEBPACK_IMPORTED_MODULE_2__["default"])(CampaignJoinPage, [{
    key: "ngOnInit",
    value: function ngOnInit() {
      var _this2 = this;

      // combineLatest tra profile e campaign per chiamare manageSpecificDetail
      this.sub = (0,rxjs__WEBPACK_IMPORTED_MODULE_20__.combineLatest)([this.userService.userProfile$, this.campaignService.getCampaignDetailsById(this.id)]).subscribe(function (_ref) {
        var _ref2 = (0,_Users_smartcommunitylab_Desktop_newWork_dslab_playgo_mobile_playgo_mobile_node_modules_babel_runtime_helpers_esm_slicedToArray_js__WEBPACK_IMPORTED_MODULE_0__["default"])(_ref, 2),
            profile = _ref2[0],
            campaign = _ref2[1];

        var _a;

        _this2.profile = profile;

        if (campaign) {
          _this2.campaign = campaign;
          _this2.imagePath = _this2.campaign.logo.url ? _this2.campaign.logo.url : 'data:image/jpg;base64,' + _this2.campaign.logo.image;

          _this2.changePageSettings();

          _this2.manageSpecificDetail(_this2.campaign, (_a = _this2.profile) === null || _a === void 0 ? void 0 : _a.nickname);
        }
      }); // this.subProf = this.userService.userProfile$.subscribe((profile) => {
      //   this.profile = profile;
      // });
      // this.sub = this.campaignService
      //   .getCampaignDetailsById(this.id)
      //   .subscribe((result) => {
      //     if (result) {
      //       this.campaign = result;
      //       this.imagePath = this.campaign.logo.url
      //         ? this.campaign.logo.url
      //         : 'data:image/jpg;base64,' + this.campaign.logo.image;
      //       this.changePageSettings();
      //       this.manageSpecificDetail(this.campaign);
      //     }
      //   });
    }
  }, {
    key: "manageSpecificDetail",
    value: function manageSpecificDetail(campaign, nickname) {
      var _this3 = this;

      switch (campaign.type) {
        case 'city':
          this.canSubscribe = true;
          break;

        case 'school':
          this.subSchool = this.playerTeamControllerService.checkSubscribeTeamMemberUsingGET({
            initiativeId: this.id,
            nickname: nickname
          }).subscribe(function (res) {
            return _this3.canSubscribe = res;
          });
          break;

        case 'company':
          this.canSubscribe = true;
          break;

        default:
          break;
      }
    }
  }, {
    key: "ionViewWillEnter",
    value: function ionViewWillEnter() {
      this.changePageSettings();
    }
  }, {
    key: "clickDescription",
    value: function clickDescription() {
      this.descriptionExpanded = !this.descriptionExpanded;
    }
  }, {
    key: "ngOnDestroy",
    value: function ngOnDestroy() {}
  }, {
    key: "ionViewDidLeave",
    value: function ionViewDidLeave() {
      var _a, _b;

      (_a = this.sub) === null || _a === void 0 ? void 0 : _a.unsubscribe();
      (_b = this.subSchool) === null || _b === void 0 ? void 0 : _b.unsubscribe();
    }
  }, {
    key: "changePageSettings",
    value: function changePageSettings() {
      var _a, _b;

      var language = this.userService.getLanguage();
      this.pageSettingsService.set({
        color: (_a = this.campaign) === null || _a === void 0 ? void 0 : _a.type,
        // FIXME: ! title is already translated!
        title: (_b = this.campaign) === null || _b === void 0 ? void 0 : _b.name[language]
      });
    } //based on the type, change interaction

  }, {
    key: "joinCampaign",
    value: function joinCampaign(campaign) {
      if (!this.campaignNotStarted(campaign)) {
        switch (campaign.type) {
          case 'city':
            this.registerToCity(campaign);
            break;

          case 'school':
            this.openRegisterSchool(campaign);
            break;

          case 'company':
            this.openRegisterCompany(campaign);
            break;

          default:
            break;
        }
      } else {
        this.alertService.showToast({
          messageString: 'campaigns.novaliddate'
        });
      }
    }
  }, {
    key: "openRegisterSchool",
    value: function openRegisterSchool(campaign) {
      return (0,tslib__WEBPACK_IMPORTED_MODULE_21__.__awaiter)(this, void 0, void 0, /*#__PURE__*/_regeneratorRuntime().mark(function _callee() {
        var language, modal, _yield$modal$onWillDi, data;

        return _regeneratorRuntime().wrap(function _callee$(_context) {
          while (1) switch (_context.prev = _context.next) {
            case 0:
              language = this.userService.getLanguage();
              _context.next = 3;
              return this.modalController.create({
                component: _join_school_join_school_modal__WEBPACK_IMPORTED_MODULE_8__.JoinSchoolModalPage,
                componentProps: {
                  campaign: campaign,
                  language: language
                },
                cssClass: 'modalConfirm',
                swipeToClose: true
              });

            case 3:
              modal = _context.sent;
              _context.next = 6;
              return modal.present();

            case 6:
              _context.next = 8;
              return modal.onWillDismiss();

            case 8:
              _yield$modal$onWillDi = _context.sent;
              data = _yield$modal$onWillDi.data;

              if (data) {
                this.navCtrl.navigateRoot('/pages/tabs/home');
              }

            case 11:
            case "end":
              return _context.stop();
          }
        }, _callee, this);
      }));
    }
  }, {
    key: "openRegisterCompany",
    value: function openRegisterCompany(campaign) {
      return (0,tslib__WEBPACK_IMPORTED_MODULE_21__.__awaiter)(this, void 0, void 0, /*#__PURE__*/_regeneratorRuntime().mark(function _callee2() {
        var language, modal, _yield$modal$onWillDi2, data;

        return _regeneratorRuntime().wrap(function _callee2$(_context2) {
          while (1) switch (_context2.prev = _context2.next) {
            case 0:
              language = this.userService.getLanguage();
              _context2.next = 3;
              return this.modalController.create({
                component: _join_company_join_company_modal__WEBPACK_IMPORTED_MODULE_7__.JoinCompanyModalPage,
                componentProps: {
                  campaign: campaign,
                  language: language
                },
                cssClass: 'modalConfirm',
                swipeToClose: true
              });

            case 3:
              modal = _context2.sent;
              _context2.next = 6;
              return modal.present();

            case 6:
              _context2.next = 8;
              return modal.onWillDismiss();

            case 8:
              _yield$modal$onWillDi2 = _context2.sent;
              data = _yield$modal$onWillDi2.data;

              if (data) {
                //update list of campaign
                this.navCtrl.navigateRoot('/pages/tabs/home');
              }

            case 11:
            case "end":
              return _context2.stop();
          }
        }, _callee2, this);
      }));
    }
  }, {
    key: "getCampaignSponsor",
    value: function getCampaignSponsor(details) {
      return details.filter(function (detail) {
        return detail.type === 'sponsor';
      })[0];
    }
  }, {
    key: "campaignHasSponsor",
    value: function campaignHasSponsor(details) {
      return details.filter(function (detail) {
        return detail.type === 'sponsor';
      }).length > 0;
    }
  }, {
    key: "isCompany",
    value: function isCompany() {
      return this.campaign.type === 'company';
    }
  }, {
    key: "isSchool",
    value: function isSchool() {
      return this.campaign.type === 'school';
    }
  }, {
    key: "openCompanies",
    value: function openCompanies() {
      return (0,tslib__WEBPACK_IMPORTED_MODULE_21__.__awaiter)(this, void 0, void 0, /*#__PURE__*/_regeneratorRuntime().mark(function _callee3() {
        var modal;
        return _regeneratorRuntime().wrap(function _callee3$(_context3) {
          while (1) switch (_context3.prev = _context3.next) {
            case 0:
              _context3.next = 2;
              return this.modalController.create({
                component: _home_campaign_details_companies_modal_companies_modal__WEBPACK_IMPORTED_MODULE_4__.CompaniesCampaignModalPage,
                cssClass: 'modalConfirm',
                componentProps: {
                  campaign: this.campaign
                }
              });

            case 2:
              modal = _context3.sent;
              _context3.next = 5;
              return modal.present();

            case 5:
              _context3.next = 7;
              return modal.onWillDismiss();

            case 7:
            case "end":
              return _context3.stop();
          }
        }, _callee3, this);
      }));
    } // registerToCompany(campaign: any, data: any) {
    //   this.sub = this.campaignService
    //     .subscribeToCampaign(campaign.campaignId, data)
    //     .subscribe((result) => {
    //       if (result) {
    //         this.alertService.showToast(
    //           this.translateService.instant('campaigns.registered')
    //         );
    //       }
    //     });
    // }

  }, {
    key: "campaignNotStarted",
    value: function campaignNotStarted(campaign) {
      // compare campaign.dateFrom and dateTo with now
      var now = luxon__WEBPACK_IMPORTED_MODULE_3__.DateTime.utc().toMillis();

      if (now > campaign.dateFrom && now < campaign.dateTo) {
        return false;
      }

      return true;
    }
  }, {
    key: "joinIsVisible",
    value: function joinIsVisible(campaign) {
      var joinable = false;

      switch (campaign.type) {
        case 'city':
          joinable = true;
          break;

        case 'school':
          joinable = true;
          break;

        case 'company':
          joinable = true;
          break;

        default:
          break;
      }

      return joinable;
    }
  }, {
    key: "registerToCity",
    value: function registerToCity(campaign) {
      return (0,tslib__WEBPACK_IMPORTED_MODULE_21__.__awaiter)(this, void 0, void 0, /*#__PURE__*/_regeneratorRuntime().mark(function _callee4() {
        var language, modal, _yield$modal$onWillDi3, data;

        return _regeneratorRuntime().wrap(function _callee4$(_context4) {
          while (1) switch (_context4.prev = _context4.next) {
            case 0:
              language = this.userService.getLanguage();
              _context4.next = 3;
              return this.modalController.create({
                component: _join_city_join_city_modal__WEBPACK_IMPORTED_MODULE_6__.JoinCityModalPage,
                componentProps: {
                  campaign: campaign,
                  language: language,
                  profile: this.profile
                },
                cssClass: 'modalConfirm',
                swipeToClose: true
              });

            case 3:
              modal = _context4.sent;
              _context4.next = 6;
              return modal.present();

            case 6:
              _context4.next = 8;
              return modal.onWillDismiss();

            case 8:
              _yield$modal$onWillDi3 = _context4.sent;
              data = _yield$modal$onWillDi3.data;

              //this.registerToCompany(campaign, data);
              if (data) {
                //update list of campaign
                this.navCtrl.navigateRoot('/pages/tabs/home');
              } // this.sub = this.campaignService
              //   .subscribeToCampaign(campaign.campaignId)
              //   .subscribe((result) => {
              //     if (result) {
              //       this.alertService.showToast({
              //         messageTranslateKey: 'campaigns.registered',
              //       });
              //     }
              //   });


            case 11:
            case "end":
              return _context4.stop();
          }
        }, _callee4, this);
      }));
    }
  }, {
    key: "back",
    value: function back() {
      this.navCtrl.back();
    }
  }, {
    key: "openDetail",
    value: function openDetail(detail) {
      return (0,tslib__WEBPACK_IMPORTED_MODULE_21__.__awaiter)(this, void 0, void 0, /*#__PURE__*/_regeneratorRuntime().mark(function _callee5() {
        var modal;
        return _regeneratorRuntime().wrap(function _callee5$(_context5) {
          while (1) switch (_context5.prev = _context5.next) {
            case 0:
              _context5.next = 2;
              return this.modalController.create({
                component: _home_campaign_details_detail_modal_detail_modal__WEBPACK_IMPORTED_MODULE_5__.DetailCampaignModalPage,
                cssClass: 'modalInfo',
                componentProps: {
                  detail: detail
                }
              });

            case 2:
              modal = _context5.sent;
              _context5.next = 5;
              return modal.present();

            case 5:
              _context5.next = 7;
              return modal.onWillDismiss();

            case 7:
            case "end":
              return _context5.stop();
          }
        }, _callee5, this);
      }));
    }
  }]);

  return CampaignJoinPage;
}();

CampaignJoinPage.ɵfac = function CampaignJoinPage_Factory(t) {
  return new (t || CampaignJoinPage)(_angular_core__WEBPACK_IMPORTED_MODULE_19__["ɵɵdirectiveInject"](_angular_router__WEBPACK_IMPORTED_MODULE_22__.ActivatedRoute), _angular_core__WEBPACK_IMPORTED_MODULE_19__["ɵɵdirectiveInject"](src_app_core_shared_services_campaign_service__WEBPACK_IMPORTED_MODULE_9__.CampaignService), _angular_core__WEBPACK_IMPORTED_MODULE_19__["ɵɵdirectiveInject"](src_app_core_shared_services_alert_service__WEBPACK_IMPORTED_MODULE_10__.AlertService), _angular_core__WEBPACK_IMPORTED_MODULE_19__["ɵɵdirectiveInject"](_ionic_angular__WEBPACK_IMPORTED_MODULE_23__.NavController), _angular_core__WEBPACK_IMPORTED_MODULE_19__["ɵɵdirectiveInject"](_ionic_angular__WEBPACK_IMPORTED_MODULE_23__.ModalController), _angular_core__WEBPACK_IMPORTED_MODULE_19__["ɵɵdirectiveInject"](src_app_core_shared_services_user_service__WEBPACK_IMPORTED_MODULE_11__.UserService), _angular_core__WEBPACK_IMPORTED_MODULE_19__["ɵɵdirectiveInject"](src_app_core_shared_services_page_settings_service__WEBPACK_IMPORTED_MODULE_12__.PageSettingsService), _angular_core__WEBPACK_IMPORTED_MODULE_19__["ɵɵdirectiveInject"](src_app_core_api_generated_hsc_controllers_playerTeamController_service__WEBPACK_IMPORTED_MODULE_13__.PlayerTeamControllerService));
};

CampaignJoinPage.ɵcmp = /*@__PURE__*/_angular_core__WEBPACK_IMPORTED_MODULE_19__["ɵɵdefineComponent"]({
  type: CampaignJoinPage,
  selectors: [["app-campaign-join"]],
  decls: 1,
  vars: 1,
  consts: [[4, "ngIf"], ["mode", "ios", "appHeader", "", "parallax", "", "height", "30vh", 3, "imageUrl", "text", "logo"], ["appContent", "", 1, "page", 3, "fullscreen"], [1, "ion-padding"], [1, "avatar-campaign", 3, "ngClass"], ["title", "campaign avatar", 3, "src"], ["class", "ion-margin-start ion-margin-end", "expand", "block", "color", "playgo", 3, "disabled", "click", 4, "ngIf"], [1, "ion-text-center"], [4, "ngIf", "ngIfElse"], ["started", ""], ["lines", "none", 1, "ion-no-padding", "ion-no-margin"], [1, "text-bold"], [1, "box", 3, "ngClass", "click"], [1, "text", 3, "innerHTML"], [1, "expansion", 3, "click"], ["name", "chevron-up-outline", 4, "ngIf"], ["name", "chevron-down-outline", 4, "ngIf"], ["expand", "block", "color", "playgo", 1, "ion-margin-start", "ion-margin-end", 3, "disabled", "click"], ["notHsc", ""], [3, "innerHTML", 4, "ngIf"], [3, "innerHTML"], ["name", "chevron-up-outline"], ["name", "chevron-down-outline"], [4, "ngFor", "ngForOf"], [3, "click", 4, "ngIf"], [3, "click"], ["lines", "none"], [1, "text-bold", "text-underlined"], ["name", "information-circle-outline", "end", ""], ["lines", "none", 3, "click"]],
  template: function CampaignJoinPage_Template(rf, ctx) {
    if (rf & 1) {
      _angular_core__WEBPACK_IMPORTED_MODULE_19__["ɵɵtemplate"](0, CampaignJoinPage_ng_container_0_Template, 39, 40, "ng-container", 0);
    }

    if (rf & 2) {
      _angular_core__WEBPACK_IMPORTED_MODULE_19__["ɵɵproperty"]("ngIf", ctx.campaign);
    }
  },
  directives: [_angular_common__WEBPACK_IMPORTED_MODULE_24__.NgIf, _ionic_angular__WEBPACK_IMPORTED_MODULE_23__.IonHeader, _core_shared_directives_parallax_header_directive__WEBPACK_IMPORTED_MODULE_14__.ParallaxDirective, _core_shared_layout_header_header_directive__WEBPACK_IMPORTED_MODULE_15__.HeaderDirective, _ionic_angular__WEBPACK_IMPORTED_MODULE_23__.IonContent, _core_shared_layout_content_content_directive__WEBPACK_IMPORTED_MODULE_16__.ContentDirective, _ionic_angular__WEBPACK_IMPORTED_MODULE_23__.IonAvatar, _angular_common__WEBPACK_IMPORTED_MODULE_24__.NgClass, _ionic_angular__WEBPACK_IMPORTED_MODULE_23__.IonButton, _ionic_angular__WEBPACK_IMPORTED_MODULE_23__.IonCard, _ionic_angular__WEBPACK_IMPORTED_MODULE_23__.IonCardContent, _ionic_angular__WEBPACK_IMPORTED_MODULE_23__.IonItem, _ionic_angular__WEBPACK_IMPORTED_MODULE_23__.IonLabel, _ionic_angular__WEBPACK_IMPORTED_MODULE_23__.IonIcon, _angular_common__WEBPACK_IMPORTED_MODULE_24__.NgForOf],
  pipes: [_core_shared_pipes_localDate_pipe__WEBPACK_IMPORTED_MODULE_17__.LocalDatePipe, _ngx_translate_core__WEBPACK_IMPORTED_MODULE_25__.TranslatePipe, _core_shared_pipes_languageMap_pipe__WEBPACK_IMPORTED_MODULE_18__.LanguageMapPipe],
  styles: [".avatar-campaign[_ngcontent-%COMP%] {\n  margin: 16px auto;\n}\n\n.company[_ngcontent-%COMP%] {\n  border: 3px solid var(--ion-color-company);\n}\n\n.school[_ngcontent-%COMP%] {\n  border: 3px solid var(--ion-color-school);\n}\n\n.city[_ngcontent-%COMP%] {\n  border: 3px solid var(--ion-color-city);\n}\n\n\n\n.box[_ngcontent-%COMP%] {\n  max-height: 162px;\n  overflow: hidden;\n  transition: max-height 0.3s cubic-bezier(0, 1, 0, 1);\n}\n\n.box.open[_ngcontent-%COMP%] {\n  max-height: 100rem;\n  transition: max-height 0.3s cubic-bezier(0.9, 0, 0.8, 0.2);\n}\n\n.expansion[_ngcontent-%COMP%] {\n  text-align: center;\n  font-size: xx-large;\n}\n\n.text[_ngcontent-%COMP%] {\n  display: -webkit-box;\n  -webkit-box-orient: vertical;\n  padding: 2px;\n  text-overflow: ellipsis;\n  overflow: hidden;\n  margin: 12px 0;\n  animation: close 0.1s linear 0.1s forwards;\n}\n\n.open[_ngcontent-%COMP%]   .text[_ngcontent-%COMP%] {\n  animation: open 0.1s linear 0s forwards;\n}\n\n\n\n@keyframes open {\n  from {\n    display: -webkit-box;\n    line-clamp: 3;\n    -webkit-line-clamp: 3;\n    -webkit-box-orient: vertical;\n  }\n  to {\n    display: -webkit-box;\n    line-clamp: initial;\n    -webkit-line-clamp: initial;\n    -webkit-box-orient: vertical;\n  }\n}\n\n@keyframes close {\n  from {\n    display: -webkit-box;\n    line-clamp: initial;\n    -webkit-line-clamp: initial;\n    -webkit-box-orient: vertical;\n  }\n  to {\n    display: -webkit-box;\n    line-clamp: 3;\n    -webkit-line-clamp: 3;\n    -webkit-box-orient: vertical;\n  }\n}\n/*# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbImNhbXBhaWduLWpvaW4ucGFnZS5zY3NzIl0sIm5hbWVzIjpbXSwibWFwcGluZ3MiOiJBQUFBO0VBQ0UsaUJBQUE7QUFDRjs7QUFDQTtFQUNFLDBDQUFBO0FBRUY7O0FBQUE7RUFDRSx5Q0FBQTtBQUdGOztBQURBO0VBQ0UsdUNBQUE7QUFJRjs7QUFGQSxRQUFBOztBQUNBO0VBSUUsaUJBQUE7RUFDQSxnQkFBQTtFQUNBLG9EQUFBO0FBRUY7O0FBQ0E7RUFDRSxrQkFBQTtFQUNBLDBEQUFBO0FBRUY7O0FBQUE7RUFDRSxrQkFBQTtFQUNBLG1CQUFBO0FBR0Y7O0FBREE7RUFDRSxvQkFBQTtFQUNBLDRCQUFBO0VBQ0EsWUFBQTtFQUNBLHVCQUFBO0VBQ0EsZ0JBQUE7RUFDQSxjQUFBO0VBQ0EsMENBQUE7QUFJRjs7QUFGQTtFQUNFLHVDQUFBO0FBS0Y7O0FBRkEsU0FBQTs7QUFDQTtFQUNFO0lBQ0Usb0JBQUE7SUFDQSxhQUFBO0lBQ0EscUJBQUE7SUFDQSw0QkFBQTtFQUtGO0VBSEE7SUFDRSxvQkFBQTtJQUNBLG1CQUFBO0lBQ0EsMkJBQUE7SUFDQSw0QkFBQTtFQUtGO0FBQ0Y7O0FBRkE7RUFDRTtJQUNFLG9CQUFBO0lBQ0EsbUJBQUE7SUFDQSwyQkFBQTtJQUNBLDRCQUFBO0VBSUY7RUFGQTtJQUNFLG9CQUFBO0lBQ0EsYUFBQTtJQUNBLHFCQUFBO0lBQ0EsNEJBQUE7RUFJRjtBQUNGIiwiZmlsZSI6ImNhbXBhaWduLWpvaW4ucGFnZS5zY3NzIiwic291cmNlc0NvbnRlbnQiOlsiLmF2YXRhci1jYW1wYWlnbiB7XG4gIG1hcmdpbjogMTZweCBhdXRvO1xufVxuLmNvbXBhbnkge1xuICBib3JkZXI6IDNweCBzb2xpZCB2YXIoLS1pb24tY29sb3ItY29tcGFueSk7XG59XG4uc2Nob29sIHtcbiAgYm9yZGVyOiAzcHggc29saWQgdmFyKC0taW9uLWNvbG9yLXNjaG9vbCk7XG59XG4uY2l0eSB7XG4gIGJvcmRlcjogM3B4IHNvbGlkIHZhcigtLWlvbi1jb2xvci1jaXR5KTtcbn1cbi8qIEJveCAqL1xuLmJveCB7XG4gIC8vIG1hcmdpbjogMjJweCBhdXRvO1xuICAvLyB3aWR0aDogMzIwcHg7XG4gIC8vIHBhZGRpbmc6IDEycHggMzJweCA2NHB4O1xuICBtYXgtaGVpZ2h0OiAxNjJweDtcbiAgb3ZlcmZsb3c6IGhpZGRlbjtcbiAgdHJhbnNpdGlvbjogbWF4LWhlaWdodCAwLjNzIGN1YmljLWJlemllcigwLCAxLCAwLCAxKTtcbn1cblxuLmJveC5vcGVuIHtcbiAgbWF4LWhlaWdodDogMTAwcmVtO1xuICB0cmFuc2l0aW9uOiBtYXgtaGVpZ2h0IDAuM3MgY3ViaWMtYmV6aWVyKDAuOSwgMCwgMC44LCAwLjIpO1xufVxuLmV4cGFuc2lvbiB7XG4gIHRleHQtYWxpZ246IGNlbnRlcjtcbiAgZm9udC1zaXplOiB4eC1sYXJnZTtcbn1cbi50ZXh0IHtcbiAgZGlzcGxheTogLXdlYmtpdC1ib3g7XG4gIC13ZWJraXQtYm94LW9yaWVudDogdmVydGljYWw7XG4gIHBhZGRpbmc6IDJweDtcbiAgdGV4dC1vdmVyZmxvdzogZWxsaXBzaXM7XG4gIG92ZXJmbG93OiBoaWRkZW47XG4gIG1hcmdpbjogMTJweCAwO1xuICBhbmltYXRpb246IGNsb3NlIDAuMXMgbGluZWFyIDAuMXMgZm9yd2FyZHM7XG59XG4ub3BlbiAudGV4dCB7XG4gIGFuaW1hdGlvbjogb3BlbiAwLjFzIGxpbmVhciAwcyBmb3J3YXJkcztcbn1cblxuLyogVGV4dCAqL1xuQGtleWZyYW1lcyBvcGVuIHtcbiAgZnJvbSB7XG4gICAgZGlzcGxheTogLXdlYmtpdC1ib3g7XG4gICAgbGluZS1jbGFtcDogMztcbiAgICAtd2Via2l0LWxpbmUtY2xhbXA6IDM7XG4gICAgLXdlYmtpdC1ib3gtb3JpZW50OiB2ZXJ0aWNhbDtcbiAgfVxuICB0byB7XG4gICAgZGlzcGxheTogLXdlYmtpdC1ib3g7XG4gICAgbGluZS1jbGFtcDogaW5pdGlhbDtcbiAgICAtd2Via2l0LWxpbmUtY2xhbXA6IGluaXRpYWw7XG4gICAgLXdlYmtpdC1ib3gtb3JpZW50OiB2ZXJ0aWNhbDtcbiAgfVxufVxuXG5Aa2V5ZnJhbWVzIGNsb3NlIHtcbiAgZnJvbSB7XG4gICAgZGlzcGxheTogLXdlYmtpdC1ib3g7XG4gICAgbGluZS1jbGFtcDogaW5pdGlhbDtcbiAgICAtd2Via2l0LWxpbmUtY2xhbXA6IGluaXRpYWw7XG4gICAgLXdlYmtpdC1ib3gtb3JpZW50OiB2ZXJ0aWNhbDtcbiAgfVxuICB0byB7XG4gICAgZGlzcGxheTogLXdlYmtpdC1ib3g7XG4gICAgbGluZS1jbGFtcDogMztcbiAgICAtd2Via2l0LWxpbmUtY2xhbXA6IDM7XG4gICAgLXdlYmtpdC1ib3gtb3JpZW50OiB2ZXJ0aWNhbDtcbiAgfVxufVxuIl19 */"]
});

/***/ }),

/***/ 39899:
/*!****************************************************************************!*\
  !*** ./src/app/pages/campaigns/campaign-join/join-city/join-city.modal.ts ***!
  \****************************************************************************/
/***/ (function(__unused_webpack_module, __webpack_exports__, __webpack_require__) {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "JoinCityModalPage": function() { return /* binding */ JoinCityModalPage; }
/* harmony export */ });
/* harmony import */ var _Users_smartcommunitylab_Desktop_newWork_dslab_playgo_mobile_playgo_mobile_node_modules_babel_runtime_helpers_esm_classCallCheck_js__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./node_modules/@babel/runtime/helpers/esm/classCallCheck.js */ 78069);
/* harmony import */ var _Users_smartcommunitylab_Desktop_newWork_dslab_playgo_mobile_playgo_mobile_node_modules_babel_runtime_helpers_esm_createClass_js__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ./node_modules/@babel/runtime/helpers/esm/createClass.js */ 48047);
/* harmony import */ var _angular_forms__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(/*! @angular/forms */ 90587);
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(/*! @angular/core */ 3184);
/* harmony import */ var _ionic_angular__WEBPACK_IMPORTED_MODULE_9__ = __webpack_require__(/*! @ionic/angular */ 93819);
/* harmony import */ var src_app_core_shared_services_alert_service__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! src/app/core/shared/services/alert.service */ 46407);
/* harmony import */ var src_app_core_shared_services_error_service__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! src/app/core/shared/services/error.service */ 96204);
/* harmony import */ var src_app_core_shared_services_campaign_service__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! src/app/core/shared/services/campaign.service */ 23645);
/* harmony import */ var src_app_core_shared_services_user_service__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! src/app/core/shared/services/user.service */ 50749);
/* harmony import */ var _angular_common__WEBPACK_IMPORTED_MODULE_10__ = __webpack_require__(/*! @angular/common */ 36362);
/* harmony import */ var _ngx_translate_core__WEBPACK_IMPORTED_MODULE_11__ = __webpack_require__(/*! @ngx-translate/core */ 87514);
/* harmony import */ var _core_shared_pipes_languageMap_pipe__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! ../../../../core/shared/pipes/languageMap.pipe */ 73088);














function JoinCityModalPage_ion_row_12_Template(rf, ctx) {
  if (rf & 1) {
    _angular_core__WEBPACK_IMPORTED_MODULE_7__["ɵɵelementStart"](0, "ion-row", 8)(1, "ion-col")(2, "ion-item", 9)(3, "ion-label", 10);
    _angular_core__WEBPACK_IMPORTED_MODULE_7__["ɵɵtext"](4);
    _angular_core__WEBPACK_IMPORTED_MODULE_7__["ɵɵpipe"](5, "translate");
    _angular_core__WEBPACK_IMPORTED_MODULE_7__["ɵɵelementEnd"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_7__["ɵɵelement"](6, "ion-input", 11);
    _angular_core__WEBPACK_IMPORTED_MODULE_7__["ɵɵpipe"](7, "translate");
    _angular_core__WEBPACK_IMPORTED_MODULE_7__["ɵɵelementEnd"]()()();
  }

  if (rf & 2) {
    _angular_core__WEBPACK_IMPORTED_MODULE_7__["ɵɵadvance"](4);
    _angular_core__WEBPACK_IMPORTED_MODULE_7__["ɵɵtextInterpolate"](_angular_core__WEBPACK_IMPORTED_MODULE_7__["ɵɵpipeBind1"](5, 2, "campaigns.joinmodal.raccomandation"));
    _angular_core__WEBPACK_IMPORTED_MODULE_7__["ɵɵadvance"](2);
    _angular_core__WEBPACK_IMPORTED_MODULE_7__["ɵɵpropertyInterpolate"]("placeholder", _angular_core__WEBPACK_IMPORTED_MODULE_7__["ɵɵpipeBind1"](7, 4, "campaigns.joinmodal.nickname"));
  }
}

function JoinCityModalPage_ion_row_13_Template(rf, ctx) {
  if (rf & 1) {
    var _r8 = _angular_core__WEBPACK_IMPORTED_MODULE_7__["ɵɵgetCurrentView"]();

    _angular_core__WEBPACK_IMPORTED_MODULE_7__["ɵɵelementStart"](0, "ion-row", 8)(1, "ion-col", 12)(2, "ion-label", 13);
    _angular_core__WEBPACK_IMPORTED_MODULE_7__["ɵɵtext"](3);
    _angular_core__WEBPACK_IMPORTED_MODULE_7__["ɵɵpipe"](4, "translate");
    _angular_core__WEBPACK_IMPORTED_MODULE_7__["ɵɵelementEnd"]()();
    _angular_core__WEBPACK_IMPORTED_MODULE_7__["ɵɵelementStart"](5, "ion-col", 14);
    _angular_core__WEBPACK_IMPORTED_MODULE_7__["ɵɵlistener"]("click", function JoinCityModalPage_ion_row_13_Template_ion_col_click_5_listener() {
      _angular_core__WEBPACK_IMPORTED_MODULE_7__["ɵɵrestoreView"](_r8);
      var ctx_r7 = _angular_core__WEBPACK_IMPORTED_MODULE_7__["ɵɵnextContext"]();
      return ctx_r7.openPrivacyPopup();
    });
    _angular_core__WEBPACK_IMPORTED_MODULE_7__["ɵɵelement"](6, "ion-icon", 15);
    _angular_core__WEBPACK_IMPORTED_MODULE_7__["ɵɵelementEnd"]()();
  }

  if (rf & 2) {
    _angular_core__WEBPACK_IMPORTED_MODULE_7__["ɵɵadvance"](3);
    _angular_core__WEBPACK_IMPORTED_MODULE_7__["ɵɵtextInterpolate"](_angular_core__WEBPACK_IMPORTED_MODULE_7__["ɵɵpipeBind1"](4, 1, "campaigns.joinmodal.privacyLink"));
  }
}

function JoinCityModalPage_ion_row_14_Template(rf, ctx) {
  if (rf & 1) {
    _angular_core__WEBPACK_IMPORTED_MODULE_7__["ɵɵelementStart"](0, "ion-row", 8)(1, "ion-col")(2, "ion-item", 0);
    _angular_core__WEBPACK_IMPORTED_MODULE_7__["ɵɵelement"](3, "ion-checkbox", 16);
    _angular_core__WEBPACK_IMPORTED_MODULE_7__["ɵɵelementStart"](4, "ion-label", 17);
    _angular_core__WEBPACK_IMPORTED_MODULE_7__["ɵɵtext"](5);
    _angular_core__WEBPACK_IMPORTED_MODULE_7__["ɵɵpipe"](6, "translate");
    _angular_core__WEBPACK_IMPORTED_MODULE_7__["ɵɵelementEnd"]()()()();
  }

  if (rf & 2) {
    _angular_core__WEBPACK_IMPORTED_MODULE_7__["ɵɵadvance"](5);
    _angular_core__WEBPACK_IMPORTED_MODULE_7__["ɵɵtextInterpolate"](_angular_core__WEBPACK_IMPORTED_MODULE_7__["ɵɵpipeBind1"](6, 1, "campaigns.joinmodal.privacy"));
  }
}

function JoinCityModalPage_div_15_Template(rf, ctx) {
  if (rf & 1) {
    _angular_core__WEBPACK_IMPORTED_MODULE_7__["ɵɵelementStart"](0, "div", 18)(1, "span");
    _angular_core__WEBPACK_IMPORTED_MODULE_7__["ɵɵtext"](2);
    _angular_core__WEBPACK_IMPORTED_MODULE_7__["ɵɵpipe"](3, "translate");
    _angular_core__WEBPACK_IMPORTED_MODULE_7__["ɵɵelementEnd"]()();
  }

  if (rf & 2) {
    _angular_core__WEBPACK_IMPORTED_MODULE_7__["ɵɵadvance"](2);
    _angular_core__WEBPACK_IMPORTED_MODULE_7__["ɵɵtextInterpolate"](_angular_core__WEBPACK_IMPORTED_MODULE_7__["ɵɵpipeBind1"](3, 1, "campaigns.joinmodal.privacyRequired"));
  }
}

function JoinCityModalPage_ion_row_16_Template(rf, ctx) {
  if (rf & 1) {
    var _r10 = _angular_core__WEBPACK_IMPORTED_MODULE_7__["ɵɵgetCurrentView"]();

    _angular_core__WEBPACK_IMPORTED_MODULE_7__["ɵɵelementStart"](0, "ion-row", 8)(1, "ion-col", 12)(2, "ion-label", 13);
    _angular_core__WEBPACK_IMPORTED_MODULE_7__["ɵɵtext"](3);
    _angular_core__WEBPACK_IMPORTED_MODULE_7__["ɵɵpipe"](4, "translate");
    _angular_core__WEBPACK_IMPORTED_MODULE_7__["ɵɵelementEnd"]()();
    _angular_core__WEBPACK_IMPORTED_MODULE_7__["ɵɵelementStart"](5, "ion-col", 14);
    _angular_core__WEBPACK_IMPORTED_MODULE_7__["ɵɵlistener"]("click", function JoinCityModalPage_ion_row_16_Template_ion_col_click_5_listener() {
      _angular_core__WEBPACK_IMPORTED_MODULE_7__["ɵɵrestoreView"](_r10);
      var ctx_r9 = _angular_core__WEBPACK_IMPORTED_MODULE_7__["ɵɵnextContext"]();
      return ctx_r9.openRulesPopup();
    });
    _angular_core__WEBPACK_IMPORTED_MODULE_7__["ɵɵelement"](6, "ion-icon", 15);
    _angular_core__WEBPACK_IMPORTED_MODULE_7__["ɵɵelementEnd"]()();
  }

  if (rf & 2) {
    _angular_core__WEBPACK_IMPORTED_MODULE_7__["ɵɵadvance"](3);
    _angular_core__WEBPACK_IMPORTED_MODULE_7__["ɵɵtextInterpolate"](_angular_core__WEBPACK_IMPORTED_MODULE_7__["ɵɵpipeBind1"](4, 1, "campaigns.joinmodal.rulesLink"));
  }
}

function JoinCityModalPage_ion_row_17_Template(rf, ctx) {
  if (rf & 1) {
    _angular_core__WEBPACK_IMPORTED_MODULE_7__["ɵɵelementStart"](0, "ion-row", 8)(1, "ion-col")(2, "ion-item", 0);
    _angular_core__WEBPACK_IMPORTED_MODULE_7__["ɵɵelement"](3, "ion-checkbox", 19);
    _angular_core__WEBPACK_IMPORTED_MODULE_7__["ɵɵelementStart"](4, "ion-label", 17);
    _angular_core__WEBPACK_IMPORTED_MODULE_7__["ɵɵtext"](5);
    _angular_core__WEBPACK_IMPORTED_MODULE_7__["ɵɵpipe"](6, "translate");
    _angular_core__WEBPACK_IMPORTED_MODULE_7__["ɵɵelementEnd"]()()()();
  }

  if (rf & 2) {
    _angular_core__WEBPACK_IMPORTED_MODULE_7__["ɵɵadvance"](5);
    _angular_core__WEBPACK_IMPORTED_MODULE_7__["ɵɵtextInterpolate"](_angular_core__WEBPACK_IMPORTED_MODULE_7__["ɵɵpipeBind1"](6, 1, "campaigns.joinmodal.rules"));
  }
}

function JoinCityModalPage_div_18_Template(rf, ctx) {
  if (rf & 1) {
    _angular_core__WEBPACK_IMPORTED_MODULE_7__["ɵɵelementStart"](0, "div", 18)(1, "span");
    _angular_core__WEBPACK_IMPORTED_MODULE_7__["ɵɵtext"](2);
    _angular_core__WEBPACK_IMPORTED_MODULE_7__["ɵɵpipe"](3, "translate");
    _angular_core__WEBPACK_IMPORTED_MODULE_7__["ɵɵelementEnd"]()();
  }

  if (rf & 2) {
    _angular_core__WEBPACK_IMPORTED_MODULE_7__["ɵɵadvance"](2);
    _angular_core__WEBPACK_IMPORTED_MODULE_7__["ɵɵtextInterpolate"](_angular_core__WEBPACK_IMPORTED_MODULE_7__["ɵɵpipeBind1"](3, 1, "campaigns.joinmodal.rulesRequired"));
  }
}

var _c0 = function _c0(a0) {
  return {
    campaignTitle: a0
  };
};

var JoinCityModalPage = /*#__PURE__*/function () {
  function JoinCityModalPage(modalController, alertService, errorService, campaignService, formBuilder, userService, navCtrl) {
    (0,_Users_smartcommunitylab_Desktop_newWork_dslab_playgo_mobile_playgo_mobile_node_modules_babel_runtime_helpers_esm_classCallCheck_js__WEBPACK_IMPORTED_MODULE_0__["default"])(this, JoinCityModalPage);

    this.modalController = modalController;
    this.alertService = alertService;
    this.errorService = errorService;
    this.campaignService = campaignService;
    this.formBuilder = formBuilder;
    this.userService = userService;
    this.navCtrl = navCtrl;
    this.isSubmitted = false;
  }

  (0,_Users_smartcommunitylab_Desktop_newWork_dslab_playgo_mobile_playgo_mobile_node_modules_babel_runtime_helpers_esm_createClass_js__WEBPACK_IMPORTED_MODULE_1__["default"])(JoinCityModalPage, [{
    key: "ngOnInit",
    value: function ngOnInit() {
      this.language = this.userService.getLanguage();
      var rules = this.campaign.details[this.language];
      this.rules = rules === null || rules === void 0 ? void 0 : rules.find(function (detail) {
        return detail.type === 'rules';
      });
      this.privacy = rules === null || rules === void 0 ? void 0 : rules.find(function (detail) {
        return detail.type === 'privacy';
      });
      this.joinCityForm = this.formBuilder.group(Object.assign(Object.assign({
        name: ['']
      }, this.privacy && {
        privacy: [false, _angular_forms__WEBPACK_IMPORTED_MODULE_8__.Validators.requiredTrue]
      }), this.rules && {
        rules: [false, _angular_forms__WEBPACK_IMPORTED_MODULE_8__.Validators.requiredTrue]
      }));
    } //computed errorcontrol

  }, {
    key: "errorControl",
    get: function get() {
      return this.joinCityForm.controls;
    }
  }, {
    key: "close",
    value: function close() {
      this.modalController.dismiss(false);
    }
  }, {
    key: "isAlreadySubscribed",
    value: function isAlreadySubscribed() {
      var _a, _b, _c, _d;

      return (_c = (_b = (_a = this.profile) === null || _a === void 0 ? void 0 : _a.personalData) === null || _b === void 0 ? void 0 : _b.registeredIds) === null || _c === void 0 ? void 0 : _c.includes((_d = this.campaign) === null || _d === void 0 ? void 0 : _d.campaignId);
    }
  }, {
    key: "openPrivacyPopup",
    value: function openPrivacyPopup() {
      this.alertService.presentAlert({
        headerTranslateKey: 'campaigns.joinmodal.privacyPopup.header',
        messageString: this.privacy.content,
        cssClass: 'modalJoin'
      });
    }
  }, {
    key: "openRulesPopup",
    value: function openRulesPopup() {
      this.alertService.presentAlert({
        headerTranslateKey: 'campaigns.joinmodal.rulesPopup.header',
        messageString: this.rules.content,
        cssClass: 'modalJoin'
      });
    }
  }, {
    key: "openCodeInfoPopup",
    value: function openCodeInfoPopup() {
      this.alertService.presentAlert({
        headerTranslateKey: 'campaigns.joinmodal.codeInfo.header',
        messageString: 'campaigns.joinmodal.codeInfo.message',
        cssClass: 'modalConfirm'
      });
    }
  }, {
    key: "joinCitySubmit",
    value: function joinCitySubmit() {
      var _this = this;

      // call join with all params
      this.isSubmitted = true;

      if (!this.joinCityForm.valid) {
        return false;
      } else {
        var body = {
          // eslint-disable-next-line @typescript-eslint/naming-convention
          nick_recommandation: this.joinCityForm.value.name
        };
        this.campaignService.subscribeToCampaign(this.campaign.campaignId, body).subscribe(function (result) {
          if (result) {
            _this.alertService.showToast({
              messageTranslateKey: 'campaigns.registered'
            });

            _this.modalController.dismiss(true);
          }
        }, function (err) {
          _this.errorService.handleError(err);
        });
      }
    }
  }]);

  return JoinCityModalPage;
}();

JoinCityModalPage.ɵfac = function JoinCityModalPage_Factory(t) {
  return new (t || JoinCityModalPage)(_angular_core__WEBPACK_IMPORTED_MODULE_7__["ɵɵdirectiveInject"](_ionic_angular__WEBPACK_IMPORTED_MODULE_9__.ModalController), _angular_core__WEBPACK_IMPORTED_MODULE_7__["ɵɵdirectiveInject"](src_app_core_shared_services_alert_service__WEBPACK_IMPORTED_MODULE_2__.AlertService), _angular_core__WEBPACK_IMPORTED_MODULE_7__["ɵɵdirectiveInject"](src_app_core_shared_services_error_service__WEBPACK_IMPORTED_MODULE_3__.ErrorService), _angular_core__WEBPACK_IMPORTED_MODULE_7__["ɵɵdirectiveInject"](src_app_core_shared_services_campaign_service__WEBPACK_IMPORTED_MODULE_4__.CampaignService), _angular_core__WEBPACK_IMPORTED_MODULE_7__["ɵɵdirectiveInject"](_angular_forms__WEBPACK_IMPORTED_MODULE_8__.FormBuilder), _angular_core__WEBPACK_IMPORTED_MODULE_7__["ɵɵdirectiveInject"](src_app_core_shared_services_user_service__WEBPACK_IMPORTED_MODULE_5__.UserService), _angular_core__WEBPACK_IMPORTED_MODULE_7__["ɵɵdirectiveInject"](_ionic_angular__WEBPACK_IMPORTED_MODULE_9__.NavController));
};

JoinCityModalPage.ɵcmp = /*@__PURE__*/_angular_core__WEBPACK_IMPORTED_MODULE_7__["ɵɵdefineComponent"]({
  type: JoinCityModalPage,
  selectors: [["app-join-city"]],
  decls: 24,
  vars: 19,
  consts: [["color", "playgo"], ["slot", "end"], [3, "click"], ["name", "close-circle-outline"], [3, "formGroup", "ngSubmit"], ["class", "ion-margin-top", 4, "ngIf"], ["class", "error-message ion-padding", 4, "ngIf"], ["color", "light", "type", "submit", "expand", "block"], [1, "ion-margin-top"], ["lines", "full", "color", "playgo"], ["position", "floating"], ["type", "text", "formControlName", "name", "clearInput", "", 3, "placeholder"], ["size", "10"], [1, "privacy-info"], [1, "ion-text-center", 3, "click"], ["name", "information-circle-outline", 1, "popup-icon"], ["slot", "start", "color", "playgo", "formControlName", "privacy"], [1, "ion-text-wrap"], [1, "error-message", "ion-padding"], ["slot", "start", "color", "playgo", "formControlName", "rules"]],
  template: function JoinCityModalPage_Template(rf, ctx) {
    if (rf & 1) {
      _angular_core__WEBPACK_IMPORTED_MODULE_7__["ɵɵelementStart"](0, "ion-header")(1, "ion-toolbar", 0)(2, "ion-title");
      _angular_core__WEBPACK_IMPORTED_MODULE_7__["ɵɵtext"](3);
      _angular_core__WEBPACK_IMPORTED_MODULE_7__["ɵɵpipe"](4, "translate");
      _angular_core__WEBPACK_IMPORTED_MODULE_7__["ɵɵpipe"](5, "languageMap");
      _angular_core__WEBPACK_IMPORTED_MODULE_7__["ɵɵelementEnd"]();
      _angular_core__WEBPACK_IMPORTED_MODULE_7__["ɵɵelementStart"](6, "ion-buttons", 1)(7, "ion-button", 2);
      _angular_core__WEBPACK_IMPORTED_MODULE_7__["ɵɵlistener"]("click", function JoinCityModalPage_Template_ion_button_click_7_listener() {
        return ctx.close();
      });
      _angular_core__WEBPACK_IMPORTED_MODULE_7__["ɵɵelement"](8, "ion-icon", 3);
      _angular_core__WEBPACK_IMPORTED_MODULE_7__["ɵɵelementEnd"]()()()();
      _angular_core__WEBPACK_IMPORTED_MODULE_7__["ɵɵelementStart"](9, "ion-content", 0)(10, "form", 4);
      _angular_core__WEBPACK_IMPORTED_MODULE_7__["ɵɵlistener"]("ngSubmit", function JoinCityModalPage_Template_form_ngSubmit_10_listener() {
        return ctx.joinCitySubmit();
      });
      _angular_core__WEBPACK_IMPORTED_MODULE_7__["ɵɵelementStart"](11, "ion-grid");
      _angular_core__WEBPACK_IMPORTED_MODULE_7__["ɵɵtemplate"](12, JoinCityModalPage_ion_row_12_Template, 8, 6, "ion-row", 5);
      _angular_core__WEBPACK_IMPORTED_MODULE_7__["ɵɵtemplate"](13, JoinCityModalPage_ion_row_13_Template, 7, 3, "ion-row", 5);
      _angular_core__WEBPACK_IMPORTED_MODULE_7__["ɵɵtemplate"](14, JoinCityModalPage_ion_row_14_Template, 7, 3, "ion-row", 5);
      _angular_core__WEBPACK_IMPORTED_MODULE_7__["ɵɵtemplate"](15, JoinCityModalPage_div_15_Template, 4, 3, "div", 6);
      _angular_core__WEBPACK_IMPORTED_MODULE_7__["ɵɵtemplate"](16, JoinCityModalPage_ion_row_16_Template, 7, 3, "ion-row", 5);
      _angular_core__WEBPACK_IMPORTED_MODULE_7__["ɵɵtemplate"](17, JoinCityModalPage_ion_row_17_Template, 7, 3, "ion-row", 5);
      _angular_core__WEBPACK_IMPORTED_MODULE_7__["ɵɵtemplate"](18, JoinCityModalPage_div_18_Template, 4, 3, "div", 6);
      _angular_core__WEBPACK_IMPORTED_MODULE_7__["ɵɵelementStart"](19, "ion-row")(20, "ion-col")(21, "ion-button", 7);
      _angular_core__WEBPACK_IMPORTED_MODULE_7__["ɵɵtext"](22);
      _angular_core__WEBPACK_IMPORTED_MODULE_7__["ɵɵpipe"](23, "translate");
      _angular_core__WEBPACK_IMPORTED_MODULE_7__["ɵɵelementEnd"]()()()()()();
    }

    if (rf & 2) {
      _angular_core__WEBPACK_IMPORTED_MODULE_7__["ɵɵadvance"](3);
      _angular_core__WEBPACK_IMPORTED_MODULE_7__["ɵɵtextInterpolate"](_angular_core__WEBPACK_IMPORTED_MODULE_7__["ɵɵpipeBind2"](4, 10, "campaigns.joinmodal.modalTitle", _angular_core__WEBPACK_IMPORTED_MODULE_7__["ɵɵpureFunction1"](17, _c0, _angular_core__WEBPACK_IMPORTED_MODULE_7__["ɵɵpipeBind1"](5, 13, ctx.campaign == null ? null : ctx.campaign.name))));
      _angular_core__WEBPACK_IMPORTED_MODULE_7__["ɵɵadvance"](7);
      _angular_core__WEBPACK_IMPORTED_MODULE_7__["ɵɵproperty"]("formGroup", ctx.joinCityForm);
      _angular_core__WEBPACK_IMPORTED_MODULE_7__["ɵɵadvance"](2);
      _angular_core__WEBPACK_IMPORTED_MODULE_7__["ɵɵproperty"]("ngIf", !ctx.isAlreadySubscribed());
      _angular_core__WEBPACK_IMPORTED_MODULE_7__["ɵɵadvance"](1);
      _angular_core__WEBPACK_IMPORTED_MODULE_7__["ɵɵproperty"]("ngIf", ctx.privacy);
      _angular_core__WEBPACK_IMPORTED_MODULE_7__["ɵɵadvance"](1);
      _angular_core__WEBPACK_IMPORTED_MODULE_7__["ɵɵproperty"]("ngIf", ctx.privacy);
      _angular_core__WEBPACK_IMPORTED_MODULE_7__["ɵɵadvance"](1);
      _angular_core__WEBPACK_IMPORTED_MODULE_7__["ɵɵproperty"]("ngIf", ctx.isSubmitted && (ctx.errorControl == null ? null : ctx.errorControl.privacy == null ? null : ctx.errorControl.privacy.errors));
      _angular_core__WEBPACK_IMPORTED_MODULE_7__["ɵɵadvance"](1);
      _angular_core__WEBPACK_IMPORTED_MODULE_7__["ɵɵproperty"]("ngIf", ctx.rules);
      _angular_core__WEBPACK_IMPORTED_MODULE_7__["ɵɵadvance"](1);
      _angular_core__WEBPACK_IMPORTED_MODULE_7__["ɵɵproperty"]("ngIf", ctx.rules);
      _angular_core__WEBPACK_IMPORTED_MODULE_7__["ɵɵadvance"](1);
      _angular_core__WEBPACK_IMPORTED_MODULE_7__["ɵɵproperty"]("ngIf", ctx.isSubmitted && (ctx.errorControl == null ? null : ctx.errorControl.rules == null ? null : ctx.errorControl.rules.errors));
      _angular_core__WEBPACK_IMPORTED_MODULE_7__["ɵɵadvance"](4);
      _angular_core__WEBPACK_IMPORTED_MODULE_7__["ɵɵtextInterpolate1"]("", _angular_core__WEBPACK_IMPORTED_MODULE_7__["ɵɵpipeBind1"](23, 15, "campaigns.joinmodal.confirm"), " ");
    }
  },
  directives: [_ionic_angular__WEBPACK_IMPORTED_MODULE_9__.IonHeader, _ionic_angular__WEBPACK_IMPORTED_MODULE_9__.IonToolbar, _ionic_angular__WEBPACK_IMPORTED_MODULE_9__.IonTitle, _ionic_angular__WEBPACK_IMPORTED_MODULE_9__.IonButtons, _ionic_angular__WEBPACK_IMPORTED_MODULE_9__.IonButton, _ionic_angular__WEBPACK_IMPORTED_MODULE_9__.IonIcon, _ionic_angular__WEBPACK_IMPORTED_MODULE_9__.IonContent, _angular_forms__WEBPACK_IMPORTED_MODULE_8__["ɵNgNoValidate"], _angular_forms__WEBPACK_IMPORTED_MODULE_8__.NgControlStatusGroup, _angular_forms__WEBPACK_IMPORTED_MODULE_8__.FormGroupDirective, _ionic_angular__WEBPACK_IMPORTED_MODULE_9__.IonGrid, _angular_common__WEBPACK_IMPORTED_MODULE_10__.NgIf, _ionic_angular__WEBPACK_IMPORTED_MODULE_9__.IonRow, _ionic_angular__WEBPACK_IMPORTED_MODULE_9__.IonCol, _ionic_angular__WEBPACK_IMPORTED_MODULE_9__.IonItem, _ionic_angular__WEBPACK_IMPORTED_MODULE_9__.IonLabel, _ionic_angular__WEBPACK_IMPORTED_MODULE_9__.IonInput, _ionic_angular__WEBPACK_IMPORTED_MODULE_9__.TextValueAccessor, _angular_forms__WEBPACK_IMPORTED_MODULE_8__.NgControlStatus, _angular_forms__WEBPACK_IMPORTED_MODULE_8__.FormControlName, _ionic_angular__WEBPACK_IMPORTED_MODULE_9__.IonCheckbox, _ionic_angular__WEBPACK_IMPORTED_MODULE_9__.BooleanValueAccessor],
  pipes: [_ngx_translate_core__WEBPACK_IMPORTED_MODULE_11__.TranslatePipe, _core_shared_pipes_languageMap_pipe__WEBPACK_IMPORTED_MODULE_6__.LanguageMapPipe],
  styles: ["\n/*# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbXSwibmFtZXMiOltdLCJtYXBwaW5ncyI6IiIsImZpbGUiOiJqb2luLWNpdHkubW9kYWwuc2NzcyJ9 */"]
});

/***/ }),

/***/ 95305:
/*!**********************************************************************************!*\
  !*** ./src/app/pages/campaigns/campaign-join/join-company/join-company.modal.ts ***!
  \**********************************************************************************/
/***/ (function(__unused_webpack_module, __webpack_exports__, __webpack_require__) {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "JoinCompanyModalPage": function() { return /* binding */ JoinCompanyModalPage; }
/* harmony export */ });
/* harmony import */ var _Users_smartcommunitylab_Desktop_newWork_dslab_playgo_mobile_playgo_mobile_node_modules_babel_runtime_helpers_esm_classCallCheck_js__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./node_modules/@babel/runtime/helpers/esm/classCallCheck.js */ 78069);
/* harmony import */ var _Users_smartcommunitylab_Desktop_newWork_dslab_playgo_mobile_playgo_mobile_node_modules_babel_runtime_helpers_esm_createClass_js__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ./node_modules/@babel/runtime/helpers/esm/createClass.js */ 48047);
/* harmony import */ var _angular_forms__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(/*! @angular/forms */ 90587);
/* harmony import */ var src_app_core_shared_pipes_languageMap_pipe__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! ../../../../core/shared/pipes/languageMap.pipe */ 73088);
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(/*! @angular/core */ 3184);
/* harmony import */ var _ionic_angular__WEBPACK_IMPORTED_MODULE_9__ = __webpack_require__(/*! @ionic/angular */ 93819);
/* harmony import */ var src_app_core_shared_services_error_service__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! src/app/core/shared/services/error.service */ 96204);
/* harmony import */ var src_app_core_shared_services_alert_service__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! src/app/core/shared/services/alert.service */ 46407);
/* harmony import */ var src_app_core_shared_services_campaign_service__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! src/app/core/shared/services/campaign.service */ 23645);
/* harmony import */ var src_app_core_shared_services_user_service__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! src/app/core/shared/services/user.service */ 50749);
/* harmony import */ var _angular_common__WEBPACK_IMPORTED_MODULE_10__ = __webpack_require__(/*! @angular/common */ 36362);
/* harmony import */ var ionic_selectable__WEBPACK_IMPORTED_MODULE_11__ = __webpack_require__(/*! ionic-selectable */ 47123);
/* harmony import */ var ionic_selectable__WEBPACK_IMPORTED_MODULE_12__ = __webpack_require__(/*! ionic-selectable */ 99359);
/* harmony import */ var ionic_selectable__WEBPACK_IMPORTED_MODULE_13__ = __webpack_require__(/*! ionic-selectable */ 25260);
/* harmony import */ var ionic_selectable__WEBPACK_IMPORTED_MODULE_14__ = __webpack_require__(/*! ionic-selectable */ 85646);
/* harmony import */ var _ngx_translate_core__WEBPACK_IMPORTED_MODULE_15__ = __webpack_require__(/*! @ngx-translate/core */ 87514);

















function JoinCompanyModalPage_ng_template_21_Template(rf, ctx) {
  if (rf & 1) {
    _angular_core__WEBPACK_IMPORTED_MODULE_7__["ɵɵtext"](0);
    _angular_core__WEBPACK_IMPORTED_MODULE_7__["ɵɵpipe"](1, "translate");
  }

  if (rf & 2) {
    _angular_core__WEBPACK_IMPORTED_MODULE_7__["ɵɵtextInterpolate1"](" ", _angular_core__WEBPACK_IMPORTED_MODULE_7__["ɵɵpipeBind1"](1, 1, "campaigns.detail.companies"), " ");
  }
}

function JoinCompanyModalPage_ng_template_22_Template(rf, ctx) {
  if (rf & 1) {
    _angular_core__WEBPACK_IMPORTED_MODULE_7__["ɵɵelement"](0, "ion-icon", 19);
  }
}

function JoinCompanyModalPage_ng_template_23_Template(rf, ctx) {
  if (rf & 1) {
    _angular_core__WEBPACK_IMPORTED_MODULE_7__["ɵɵelement"](0, "ion-icon", 20);
  }

  if (rf & 2) {
    var isPortSelected_r12 = ctx.isItemSelected;
    _angular_core__WEBPACK_IMPORTED_MODULE_7__["ɵɵproperty"]("name", isPortSelected_r12 ? "checkmark-circle" : "radio-button-off")("color", isPortSelected_r12 ? "light" : null);
  }
}

function JoinCompanyModalPage_div_24_Template(rf, ctx) {
  if (rf & 1) {
    _angular_core__WEBPACK_IMPORTED_MODULE_7__["ɵɵelementStart"](0, "div", 21);
    _angular_core__WEBPACK_IMPORTED_MODULE_7__["ɵɵtext"](1);
    _angular_core__WEBPACK_IMPORTED_MODULE_7__["ɵɵpipe"](2, "translate");
    _angular_core__WEBPACK_IMPORTED_MODULE_7__["ɵɵelementEnd"]();
  }

  if (rf & 2) {
    _angular_core__WEBPACK_IMPORTED_MODULE_7__["ɵɵadvance"](1);
    _angular_core__WEBPACK_IMPORTED_MODULE_7__["ɵɵtextInterpolate1"](" ", _angular_core__WEBPACK_IMPORTED_MODULE_7__["ɵɵpipeBind1"](2, 1, "campaigns.joinmodal.companyRequired"), " ");
  }
}

function JoinCompanyModalPage_div_34_Template(rf, ctx) {
  if (rf & 1) {
    _angular_core__WEBPACK_IMPORTED_MODULE_7__["ɵɵelementStart"](0, "div", 21);
    _angular_core__WEBPACK_IMPORTED_MODULE_7__["ɵɵtext"](1);
    _angular_core__WEBPACK_IMPORTED_MODULE_7__["ɵɵpipe"](2, "translate");
    _angular_core__WEBPACK_IMPORTED_MODULE_7__["ɵɵelementEnd"]();
  }

  if (rf & 2) {
    _angular_core__WEBPACK_IMPORTED_MODULE_7__["ɵɵadvance"](1);
    _angular_core__WEBPACK_IMPORTED_MODULE_7__["ɵɵtextInterpolate1"](" ", _angular_core__WEBPACK_IMPORTED_MODULE_7__["ɵɵpipeBind1"](2, 1, "campaigns.joinmodal.pinRequired"), " ");
  }
}

function JoinCompanyModalPage_ion_row_35_Template(rf, ctx) {
  if (rf & 1) {
    var _r14 = _angular_core__WEBPACK_IMPORTED_MODULE_7__["ɵɵgetCurrentView"]();

    _angular_core__WEBPACK_IMPORTED_MODULE_7__["ɵɵelementStart"](0, "ion-row", 11)(1, "ion-col", 12)(2, "ion-label", 22);
    _angular_core__WEBPACK_IMPORTED_MODULE_7__["ɵɵtext"](3);
    _angular_core__WEBPACK_IMPORTED_MODULE_7__["ɵɵpipe"](4, "translate");
    _angular_core__WEBPACK_IMPORTED_MODULE_7__["ɵɵelementEnd"]()();
    _angular_core__WEBPACK_IMPORTED_MODULE_7__["ɵɵelementStart"](5, "ion-col", 23);
    _angular_core__WEBPACK_IMPORTED_MODULE_7__["ɵɵlistener"]("click", function JoinCompanyModalPage_ion_row_35_Template_ion_col_click_5_listener() {
      _angular_core__WEBPACK_IMPORTED_MODULE_7__["ɵɵrestoreView"](_r14);
      var ctx_r13 = _angular_core__WEBPACK_IMPORTED_MODULE_7__["ɵɵnextContext"]();
      return ctx_r13.openPrivacyPopup();
    });
    _angular_core__WEBPACK_IMPORTED_MODULE_7__["ɵɵelement"](6, "ion-icon", 24);
    _angular_core__WEBPACK_IMPORTED_MODULE_7__["ɵɵelementEnd"]()();
  }

  if (rf & 2) {
    _angular_core__WEBPACK_IMPORTED_MODULE_7__["ɵɵadvance"](3);
    _angular_core__WEBPACK_IMPORTED_MODULE_7__["ɵɵtextInterpolate"](_angular_core__WEBPACK_IMPORTED_MODULE_7__["ɵɵpipeBind1"](4, 1, "campaigns.joinmodal.privacyLink"));
  }
}

function JoinCompanyModalPage_ion_row_36_Template(rf, ctx) {
  if (rf & 1) {
    _angular_core__WEBPACK_IMPORTED_MODULE_7__["ɵɵelementStart"](0, "ion-row", 11)(1, "ion-col")(2, "ion-item", 0);
    _angular_core__WEBPACK_IMPORTED_MODULE_7__["ɵɵelement"](3, "ion-checkbox", 25);
    _angular_core__WEBPACK_IMPORTED_MODULE_7__["ɵɵelementStart"](4, "ion-label", 26);
    _angular_core__WEBPACK_IMPORTED_MODULE_7__["ɵɵtext"](5);
    _angular_core__WEBPACK_IMPORTED_MODULE_7__["ɵɵpipe"](6, "translate");
    _angular_core__WEBPACK_IMPORTED_MODULE_7__["ɵɵelementEnd"]()()()();
  }

  if (rf & 2) {
    _angular_core__WEBPACK_IMPORTED_MODULE_7__["ɵɵadvance"](5);
    _angular_core__WEBPACK_IMPORTED_MODULE_7__["ɵɵtextInterpolate"](_angular_core__WEBPACK_IMPORTED_MODULE_7__["ɵɵpipeBind1"](6, 1, "campaigns.joinmodal.privacy"));
  }
}

function JoinCompanyModalPage_div_37_Template(rf, ctx) {
  if (rf & 1) {
    _angular_core__WEBPACK_IMPORTED_MODULE_7__["ɵɵelementStart"](0, "div", 21);
    _angular_core__WEBPACK_IMPORTED_MODULE_7__["ɵɵtext"](1);
    _angular_core__WEBPACK_IMPORTED_MODULE_7__["ɵɵpipe"](2, "translate");
    _angular_core__WEBPACK_IMPORTED_MODULE_7__["ɵɵelementEnd"]();
  }

  if (rf & 2) {
    _angular_core__WEBPACK_IMPORTED_MODULE_7__["ɵɵadvance"](1);
    _angular_core__WEBPACK_IMPORTED_MODULE_7__["ɵɵtextInterpolate1"](" ", _angular_core__WEBPACK_IMPORTED_MODULE_7__["ɵɵpipeBind1"](2, 1, "campaigns.joinmodal.privacyRequired"), " ");
  }
}

function JoinCompanyModalPage_ion_row_38_Template(rf, ctx) {
  if (rf & 1) {
    var _r16 = _angular_core__WEBPACK_IMPORTED_MODULE_7__["ɵɵgetCurrentView"]();

    _angular_core__WEBPACK_IMPORTED_MODULE_7__["ɵɵelementStart"](0, "ion-row", 11)(1, "ion-col", 12)(2, "ion-label", 22);
    _angular_core__WEBPACK_IMPORTED_MODULE_7__["ɵɵtext"](3);
    _angular_core__WEBPACK_IMPORTED_MODULE_7__["ɵɵpipe"](4, "translate");
    _angular_core__WEBPACK_IMPORTED_MODULE_7__["ɵɵelementEnd"]()();
    _angular_core__WEBPACK_IMPORTED_MODULE_7__["ɵɵelementStart"](5, "ion-col", 23);
    _angular_core__WEBPACK_IMPORTED_MODULE_7__["ɵɵlistener"]("click", function JoinCompanyModalPage_ion_row_38_Template_ion_col_click_5_listener() {
      _angular_core__WEBPACK_IMPORTED_MODULE_7__["ɵɵrestoreView"](_r16);
      var ctx_r15 = _angular_core__WEBPACK_IMPORTED_MODULE_7__["ɵɵnextContext"]();
      return ctx_r15.openRulesPopup();
    });
    _angular_core__WEBPACK_IMPORTED_MODULE_7__["ɵɵelement"](6, "ion-icon", 24);
    _angular_core__WEBPACK_IMPORTED_MODULE_7__["ɵɵelementEnd"]()();
  }

  if (rf & 2) {
    _angular_core__WEBPACK_IMPORTED_MODULE_7__["ɵɵadvance"](3);
    _angular_core__WEBPACK_IMPORTED_MODULE_7__["ɵɵtextInterpolate"](_angular_core__WEBPACK_IMPORTED_MODULE_7__["ɵɵpipeBind1"](4, 1, "campaigns.joinmodal.rulesLink"));
  }
}

function JoinCompanyModalPage_ion_row_39_Template(rf, ctx) {
  if (rf & 1) {
    _angular_core__WEBPACK_IMPORTED_MODULE_7__["ɵɵelementStart"](0, "ion-row", 11)(1, "ion-col")(2, "ion-item", 0);
    _angular_core__WEBPACK_IMPORTED_MODULE_7__["ɵɵelement"](3, "ion-checkbox", 27);
    _angular_core__WEBPACK_IMPORTED_MODULE_7__["ɵɵelementStart"](4, "ion-label", 26);
    _angular_core__WEBPACK_IMPORTED_MODULE_7__["ɵɵtext"](5);
    _angular_core__WEBPACK_IMPORTED_MODULE_7__["ɵɵpipe"](6, "translate");
    _angular_core__WEBPACK_IMPORTED_MODULE_7__["ɵɵelementEnd"]()()()();
  }

  if (rf & 2) {
    _angular_core__WEBPACK_IMPORTED_MODULE_7__["ɵɵadvance"](5);
    _angular_core__WEBPACK_IMPORTED_MODULE_7__["ɵɵtextInterpolate"](_angular_core__WEBPACK_IMPORTED_MODULE_7__["ɵɵpipeBind1"](6, 1, "campaigns.joinmodal.rules"));
  }
}

function JoinCompanyModalPage_div_40_Template(rf, ctx) {
  if (rf & 1) {
    _angular_core__WEBPACK_IMPORTED_MODULE_7__["ɵɵelementStart"](0, "div", 21);
    _angular_core__WEBPACK_IMPORTED_MODULE_7__["ɵɵtext"](1);
    _angular_core__WEBPACK_IMPORTED_MODULE_7__["ɵɵpipe"](2, "translate");
    _angular_core__WEBPACK_IMPORTED_MODULE_7__["ɵɵelementEnd"]();
  }

  if (rf & 2) {
    _angular_core__WEBPACK_IMPORTED_MODULE_7__["ɵɵadvance"](1);
    _angular_core__WEBPACK_IMPORTED_MODULE_7__["ɵɵtextInterpolate1"](" ", _angular_core__WEBPACK_IMPORTED_MODULE_7__["ɵɵpipeBind1"](2, 1, "campaigns.joinmodal.rulesRequired"), " ");
  }
}

var _c0 = function _c0(a0) {
  return {
    campaignTitle: a0
  };
};

var _c1 = function _c1(a0) {
  return {
    "hide-company-selection": a0
  };
};

var JoinCompanyModalPage = /*#__PURE__*/function () {
  function JoinCompanyModalPage(modalController, errorService, alertService, campaignService, formBuilder, userService, navCtrl, languageMap) {
    (0,_Users_smartcommunitylab_Desktop_newWork_dslab_playgo_mobile_playgo_mobile_node_modules_babel_runtime_helpers_esm_classCallCheck_js__WEBPACK_IMPORTED_MODULE_0__["default"])(this, JoinCompanyModalPage);

    this.modalController = modalController;
    this.errorService = errorService;
    this.alertService = alertService;
    this.campaignService = campaignService;
    this.formBuilder = formBuilder;
    this.userService = userService;
    this.navCtrl = navCtrl;
    this.languageMap = languageMap;
    this.isSubmitted = false;
    this.hasOnlyOne = false;
  }

  (0,_Users_smartcommunitylab_Desktop_newWork_dslab_playgo_mobile_playgo_mobile_node_modules_babel_runtime_helpers_esm_createClass_js__WEBPACK_IMPORTED_MODULE_1__["default"])(JoinCompanyModalPage, [{
    key: "ngOnInit",
    value: function ngOnInit() {
      var _this = this;

      this.language = this.userService.getLanguage();
      var rules = this.campaign.details[this.language];
      this.rules = rules === null || rules === void 0 ? void 0 : rules.find(function (detail) {
        return detail.type === 'rules';
      });
      this.privacy = rules === null || rules === void 0 ? void 0 : rules.find(function (detail) {
        return detail.type === 'privacy';
      });
      this.joinCompanyForm = this.formBuilder.group(Object.assign(Object.assign({
        companySelected: ['', [_angular_forms__WEBPACK_IMPORTED_MODULE_8__.Validators.required]],
        companyPIN: ['', [_angular_forms__WEBPACK_IMPORTED_MODULE_8__.Validators.required]]
      }, this.privacy && {
        privacy: [false, _angular_forms__WEBPACK_IMPORTED_MODULE_8__.Validators.requiredTrue]
      }), this.rules && {
        rules: [false, _angular_forms__WEBPACK_IMPORTED_MODULE_8__.Validators.requiredTrue]
      }));
      this.sub = this.campaignService.getCompaniesForSubscription(this.campaign.campaignId).subscribe(function (result) {
        if (result) {
          _this.companies = result;

          if (_this.companies.length === 1) {
            _this.companySelected = _this.companies[0];
            _this.hasOnlyOne = true;
          }
        }
      });
    }
  }, {
    key: "ngOnDestroy",
    value: function ngOnDestroy() {
      this.sub.unsubscribe();
    } //computed errorcontrol

  }, {
    key: "errorControl",
    get: function get() {
      return this.joinCompanyForm.controls;
    }
  }, {
    key: "close",
    value: function close() {
      this.modalController.dismiss(false);
    }
  }, {
    key: "openPrivacyPopup",
    value: function openPrivacyPopup() {
      this.alertService.presentAlert({
        headerTranslateKey: 'campaigns.joinmodal.privacyPopup.header',
        messageString: this.privacy.content,
        cssClass: 'modalJoin'
      });
    }
  }, {
    key: "openRulesPopup",
    value: function openRulesPopup() {
      this.alertService.presentAlert({
        headerTranslateKey: 'campaigns.joinmodal.rulesPopup.header',
        messageString: this.rules.content,
        cssClass: 'modalJoin'
      });
    }
  }, {
    key: "openCodeInfoPopup",
    value: function openCodeInfoPopup(event) {
      this.alertService.presentAlert({
        headerTranslateKey: 'campaigns.joinmodal.codeInfo.header',
        messageTranslateKey: this.campaign.specificData.registrationCompanyDesc ? this.languageMap.transform(this.campaign.specificData.registrationCompanyDesc) : 'campaigns.joinmodal.companyPIN',
        cssClass: 'modalConfirm'
      });
    }
  }, {
    key: "joinCompanySubmit",
    value: function joinCompanySubmit() {
      var _this2 = this;

      var _a, _b, _c; // call join with all params


      this.isSubmitted = true;

      if (!this.joinCompanyForm.valid) {
        return false;
      } else {
        // console.log('employeeCode' + this.joinCompanyForm.value?.companyPIN + 'companyKey' + );
        var body = {
          companyKey: (_b = (_a = this.joinCompanyForm.value) === null || _a === void 0 ? void 0 : _a.companySelected) === null || _b === void 0 ? void 0 : _b.code,
          employeeCode: (_c = this.joinCompanyForm.value) === null || _c === void 0 ? void 0 : _c.companyPIN
        };
        this.sub = this.campaignService.subscribeToCampaign(this.campaign.campaignId, body).subscribe(function (result) {
          if (result) {
            _this2.alertService.showToast({
              messageTranslateKey: 'campaigns.registered'
            });

            _this2.modalController.dismiss(true);

            _this2.navCtrl.navigateRoot('/pages/tabs/home');
          }
        }, function (err) {
          _this2.errorService.handleError(err);
        });
      }
    }
  }, {
    key: "onSelect",
    value: function onSelect(event) {
      console.log('item' + JSON.stringify(event.item) + 'isSelected' + event.isSelected);
    }
  }]);

  return JoinCompanyModalPage;
}();

JoinCompanyModalPage.ɵfac = function JoinCompanyModalPage_Factory(t) {
  return new (t || JoinCompanyModalPage)(_angular_core__WEBPACK_IMPORTED_MODULE_7__["ɵɵdirectiveInject"](_ionic_angular__WEBPACK_IMPORTED_MODULE_9__.ModalController), _angular_core__WEBPACK_IMPORTED_MODULE_7__["ɵɵdirectiveInject"](src_app_core_shared_services_error_service__WEBPACK_IMPORTED_MODULE_3__.ErrorService), _angular_core__WEBPACK_IMPORTED_MODULE_7__["ɵɵdirectiveInject"](src_app_core_shared_services_alert_service__WEBPACK_IMPORTED_MODULE_4__.AlertService), _angular_core__WEBPACK_IMPORTED_MODULE_7__["ɵɵdirectiveInject"](src_app_core_shared_services_campaign_service__WEBPACK_IMPORTED_MODULE_5__.CampaignService), _angular_core__WEBPACK_IMPORTED_MODULE_7__["ɵɵdirectiveInject"](_angular_forms__WEBPACK_IMPORTED_MODULE_8__.FormBuilder), _angular_core__WEBPACK_IMPORTED_MODULE_7__["ɵɵdirectiveInject"](src_app_core_shared_services_user_service__WEBPACK_IMPORTED_MODULE_6__.UserService), _angular_core__WEBPACK_IMPORTED_MODULE_7__["ɵɵdirectiveInject"](_ionic_angular__WEBPACK_IMPORTED_MODULE_9__.NavController), _angular_core__WEBPACK_IMPORTED_MODULE_7__["ɵɵdirectiveInject"](src_app_core_shared_pipes_languageMap_pipe__WEBPACK_IMPORTED_MODULE_2__.LanguageMapPipe));
};

JoinCompanyModalPage.ɵcmp = /*@__PURE__*/_angular_core__WEBPACK_IMPORTED_MODULE_7__["ɵɵdefineComponent"]({
  type: JoinCompanyModalPage,
  selectors: [["app-join-company"]],
  features: [_angular_core__WEBPACK_IMPORTED_MODULE_7__["ɵɵProvidersFeature"]([src_app_core_shared_pipes_languageMap_pipe__WEBPACK_IMPORTED_MODULE_2__.LanguageMapPipe])],
  decls: 46,
  vars: 39,
  consts: [["color", "playgo"], ["slot", "end"], [3, "click"], ["name", "close-circle-outline"], [3, "formGroup", "ngSubmit"], [1, "ion-margin-top", 3, "ngClass"], ["itemValueField", "code", "itemTextField", "name", "formControlName", "companySelected", "hasSearchText", "false", "headerColor", "playgo", "groupColor", "playgo", "modalCssClass", "modal-search-playgo", 3, "ngModel", "items", "searchFailText", "canSearch", "searchPlaceholder", "ngModelChange", "onSelect"], ["ionicSelectableTitleTemplate", ""], ["ionicSelectableCloseButtonTemplate", ""], ["ionicSelectableItemIconTemplate", ""], ["class", "error-message ion-padding", 4, "ngIf"], [1, "ion-margin-top"], ["size", "10"], ["position", "floating"], ["formControlName", "companyPIN", 3, "ngModel", "ngModelChange"], ["size", "2", 1, "info"], ["name", "information-circle-outline", 1, "popup-icon", 3, "click"], ["class", "ion-margin-top", 4, "ngIf"], ["color", "light", "type", "submit", "expand", "block"], ["name", "close-circle", 2, "font-size", "24px"], [3, "name", "color"], [1, "error-message", "ion-padding"], [1, "privacy-info"], [1, "ion-text-center", 3, "click"], ["name", "information-circle-outline", 1, "popup-icon"], ["slot", "start", "color", "playgo", "formControlName", "privacy"], [1, "ion-text-wrap"], ["slot", "start", "color", "playgo", "formControlName", "rules"]],
  template: function JoinCompanyModalPage_Template(rf, ctx) {
    if (rf & 1) {
      _angular_core__WEBPACK_IMPORTED_MODULE_7__["ɵɵelementStart"](0, "ion-header")(1, "ion-toolbar", 0)(2, "ion-title");
      _angular_core__WEBPACK_IMPORTED_MODULE_7__["ɵɵtext"](3);
      _angular_core__WEBPACK_IMPORTED_MODULE_7__["ɵɵpipe"](4, "translate");
      _angular_core__WEBPACK_IMPORTED_MODULE_7__["ɵɵpipe"](5, "languageMap");
      _angular_core__WEBPACK_IMPORTED_MODULE_7__["ɵɵelementEnd"]();
      _angular_core__WEBPACK_IMPORTED_MODULE_7__["ɵɵelementStart"](6, "ion-buttons", 1)(7, "ion-button", 2);
      _angular_core__WEBPACK_IMPORTED_MODULE_7__["ɵɵlistener"]("click", function JoinCompanyModalPage_Template_ion_button_click_7_listener() {
        return ctx.close();
      });
      _angular_core__WEBPACK_IMPORTED_MODULE_7__["ɵɵelement"](8, "ion-icon", 3);
      _angular_core__WEBPACK_IMPORTED_MODULE_7__["ɵɵelementEnd"]()()()();
      _angular_core__WEBPACK_IMPORTED_MODULE_7__["ɵɵelementStart"](9, "ion-content", 0)(10, "form", 4);
      _angular_core__WEBPACK_IMPORTED_MODULE_7__["ɵɵlistener"]("ngSubmit", function JoinCompanyModalPage_Template_form_ngSubmit_10_listener() {
        return ctx.joinCompanySubmit();
      });
      _angular_core__WEBPACK_IMPORTED_MODULE_7__["ɵɵelementStart"](11, "ion-grid")(12, "ion-row", 5)(13, "ion-col")(14, "ion-item", 0)(15, "ion-label");
      _angular_core__WEBPACK_IMPORTED_MODULE_7__["ɵɵtext"](16);
      _angular_core__WEBPACK_IMPORTED_MODULE_7__["ɵɵpipe"](17, "translate");
      _angular_core__WEBPACK_IMPORTED_MODULE_7__["ɵɵelementEnd"]();
      _angular_core__WEBPACK_IMPORTED_MODULE_7__["ɵɵelementStart"](18, "ionic-selectable", 6);
      _angular_core__WEBPACK_IMPORTED_MODULE_7__["ɵɵlistener"]("ngModelChange", function JoinCompanyModalPage_Template_ionic_selectable_ngModelChange_18_listener($event) {
        return ctx.companySelected = $event;
      })("onSelect", function JoinCompanyModalPage_Template_ionic_selectable_onSelect_18_listener($event) {
        return ctx.onSelect($event);
      });
      _angular_core__WEBPACK_IMPORTED_MODULE_7__["ɵɵpipe"](19, "translate");
      _angular_core__WEBPACK_IMPORTED_MODULE_7__["ɵɵpipe"](20, "translate");
      _angular_core__WEBPACK_IMPORTED_MODULE_7__["ɵɵtemplate"](21, JoinCompanyModalPage_ng_template_21_Template, 2, 3, "ng-template", 7);
      _angular_core__WEBPACK_IMPORTED_MODULE_7__["ɵɵtemplate"](22, JoinCompanyModalPage_ng_template_22_Template, 1, 0, "ng-template", 8);
      _angular_core__WEBPACK_IMPORTED_MODULE_7__["ɵɵtemplate"](23, JoinCompanyModalPage_ng_template_23_Template, 1, 2, "ng-template", 9);
      _angular_core__WEBPACK_IMPORTED_MODULE_7__["ɵɵelementEnd"]()()()();
      _angular_core__WEBPACK_IMPORTED_MODULE_7__["ɵɵtemplate"](24, JoinCompanyModalPage_div_24_Template, 3, 3, "div", 10);
      _angular_core__WEBPACK_IMPORTED_MODULE_7__["ɵɵelementStart"](25, "ion-row", 11)(26, "ion-col", 12)(27, "ion-item", 0)(28, "ion-label", 13);
      _angular_core__WEBPACK_IMPORTED_MODULE_7__["ɵɵtext"](29);
      _angular_core__WEBPACK_IMPORTED_MODULE_7__["ɵɵpipe"](30, "translate");
      _angular_core__WEBPACK_IMPORTED_MODULE_7__["ɵɵelementEnd"]();
      _angular_core__WEBPACK_IMPORTED_MODULE_7__["ɵɵelementStart"](31, "ion-input", 14);
      _angular_core__WEBPACK_IMPORTED_MODULE_7__["ɵɵlistener"]("ngModelChange", function JoinCompanyModalPage_Template_ion_input_ngModelChange_31_listener($event) {
        return ctx.companyPIN = $event;
      });
      _angular_core__WEBPACK_IMPORTED_MODULE_7__["ɵɵelementEnd"]()()();
      _angular_core__WEBPACK_IMPORTED_MODULE_7__["ɵɵelementStart"](32, "ion-col", 15)(33, "ion-icon", 16);
      _angular_core__WEBPACK_IMPORTED_MODULE_7__["ɵɵlistener"]("click", function JoinCompanyModalPage_Template_ion_icon_click_33_listener($event) {
        return ctx.openCodeInfoPopup($event);
      });
      _angular_core__WEBPACK_IMPORTED_MODULE_7__["ɵɵelementEnd"]()()();
      _angular_core__WEBPACK_IMPORTED_MODULE_7__["ɵɵtemplate"](34, JoinCompanyModalPage_div_34_Template, 3, 3, "div", 10);
      _angular_core__WEBPACK_IMPORTED_MODULE_7__["ɵɵtemplate"](35, JoinCompanyModalPage_ion_row_35_Template, 7, 3, "ion-row", 17);
      _angular_core__WEBPACK_IMPORTED_MODULE_7__["ɵɵtemplate"](36, JoinCompanyModalPage_ion_row_36_Template, 7, 3, "ion-row", 17);
      _angular_core__WEBPACK_IMPORTED_MODULE_7__["ɵɵtemplate"](37, JoinCompanyModalPage_div_37_Template, 3, 3, "div", 10);
      _angular_core__WEBPACK_IMPORTED_MODULE_7__["ɵɵtemplate"](38, JoinCompanyModalPage_ion_row_38_Template, 7, 3, "ion-row", 17);
      _angular_core__WEBPACK_IMPORTED_MODULE_7__["ɵɵtemplate"](39, JoinCompanyModalPage_ion_row_39_Template, 7, 3, "ion-row", 17);
      _angular_core__WEBPACK_IMPORTED_MODULE_7__["ɵɵtemplate"](40, JoinCompanyModalPage_div_40_Template, 3, 3, "div", 10);
      _angular_core__WEBPACK_IMPORTED_MODULE_7__["ɵɵelementStart"](41, "ion-row")(42, "ion-col")(43, "ion-button", 18);
      _angular_core__WEBPACK_IMPORTED_MODULE_7__["ɵɵtext"](44);
      _angular_core__WEBPACK_IMPORTED_MODULE_7__["ɵɵpipe"](45, "translate");
      _angular_core__WEBPACK_IMPORTED_MODULE_7__["ɵɵelementEnd"]()()()()()();
    }

    if (rf & 2) {
      _angular_core__WEBPACK_IMPORTED_MODULE_7__["ɵɵadvance"](3);
      _angular_core__WEBPACK_IMPORTED_MODULE_7__["ɵɵtextInterpolate"](_angular_core__WEBPACK_IMPORTED_MODULE_7__["ɵɵpipeBind2"](4, 20, "campaigns.joinmodal.modalTitle", _angular_core__WEBPACK_IMPORTED_MODULE_7__["ɵɵpureFunction1"](35, _c0, _angular_core__WEBPACK_IMPORTED_MODULE_7__["ɵɵpipeBind1"](5, 23, ctx.campaign == null ? null : ctx.campaign.name))));
      _angular_core__WEBPACK_IMPORTED_MODULE_7__["ɵɵadvance"](7);
      _angular_core__WEBPACK_IMPORTED_MODULE_7__["ɵɵproperty"]("formGroup", ctx.joinCompanyForm);
      _angular_core__WEBPACK_IMPORTED_MODULE_7__["ɵɵadvance"](2);
      _angular_core__WEBPACK_IMPORTED_MODULE_7__["ɵɵproperty"]("ngClass", _angular_core__WEBPACK_IMPORTED_MODULE_7__["ɵɵpureFunction1"](37, _c1, ctx.hasOnlyOne));
      _angular_core__WEBPACK_IMPORTED_MODULE_7__["ɵɵadvance"](4);
      _angular_core__WEBPACK_IMPORTED_MODULE_7__["ɵɵtextInterpolate"](_angular_core__WEBPACK_IMPORTED_MODULE_7__["ɵɵpipeBind1"](17, 25, "campaigns.joinmodal.companyselection"));
      _angular_core__WEBPACK_IMPORTED_MODULE_7__["ɵɵadvance"](2);
      _angular_core__WEBPACK_IMPORTED_MODULE_7__["ɵɵproperty"]("ngModel", ctx.companySelected)("items", ctx.companies)("searchFailText", _angular_core__WEBPACK_IMPORTED_MODULE_7__["ɵɵpipeBind1"](19, 27, "campaigns.joinmodal.noItems"))("canSearch", true)("searchPlaceholder", _angular_core__WEBPACK_IMPORTED_MODULE_7__["ɵɵpipeBind1"](20, 29, "campaigns.joinmodal.search"));
      _angular_core__WEBPACK_IMPORTED_MODULE_7__["ɵɵadvance"](6);
      _angular_core__WEBPACK_IMPORTED_MODULE_7__["ɵɵproperty"]("ngIf", ctx.isSubmitted && (ctx.errorControl == null ? null : ctx.errorControl.companySelected == null ? null : ctx.errorControl.companySelected.errors));
      _angular_core__WEBPACK_IMPORTED_MODULE_7__["ɵɵadvance"](5);
      _angular_core__WEBPACK_IMPORTED_MODULE_7__["ɵɵtextInterpolate1"](" ", _angular_core__WEBPACK_IMPORTED_MODULE_7__["ɵɵpipeBind1"](30, 31, "campaigns.detail.companySubscribe"), " ");
      _angular_core__WEBPACK_IMPORTED_MODULE_7__["ɵɵadvance"](2);
      _angular_core__WEBPACK_IMPORTED_MODULE_7__["ɵɵproperty"]("ngModel", ctx.companyPIN);
      _angular_core__WEBPACK_IMPORTED_MODULE_7__["ɵɵadvance"](3);
      _angular_core__WEBPACK_IMPORTED_MODULE_7__["ɵɵproperty"]("ngIf", ctx.isSubmitted && ctx.isSubmitted && (ctx.errorControl == null ? null : ctx.errorControl.companyPIN == null ? null : ctx.errorControl.companyPIN.errors));
      _angular_core__WEBPACK_IMPORTED_MODULE_7__["ɵɵadvance"](1);
      _angular_core__WEBPACK_IMPORTED_MODULE_7__["ɵɵproperty"]("ngIf", ctx.privacy);
      _angular_core__WEBPACK_IMPORTED_MODULE_7__["ɵɵadvance"](1);
      _angular_core__WEBPACK_IMPORTED_MODULE_7__["ɵɵproperty"]("ngIf", ctx.privacy);
      _angular_core__WEBPACK_IMPORTED_MODULE_7__["ɵɵadvance"](1);
      _angular_core__WEBPACK_IMPORTED_MODULE_7__["ɵɵproperty"]("ngIf", ctx.isSubmitted && (ctx.errorControl == null ? null : ctx.errorControl.privacy == null ? null : ctx.errorControl.privacy.errors));
      _angular_core__WEBPACK_IMPORTED_MODULE_7__["ɵɵadvance"](1);
      _angular_core__WEBPACK_IMPORTED_MODULE_7__["ɵɵproperty"]("ngIf", ctx.rules);
      _angular_core__WEBPACK_IMPORTED_MODULE_7__["ɵɵadvance"](1);
      _angular_core__WEBPACK_IMPORTED_MODULE_7__["ɵɵproperty"]("ngIf", ctx.rules);
      _angular_core__WEBPACK_IMPORTED_MODULE_7__["ɵɵadvance"](1);
      _angular_core__WEBPACK_IMPORTED_MODULE_7__["ɵɵproperty"]("ngIf", ctx.isSubmitted && (ctx.errorControl == null ? null : ctx.errorControl.rules == null ? null : ctx.errorControl.rules.errors));
      _angular_core__WEBPACK_IMPORTED_MODULE_7__["ɵɵadvance"](4);
      _angular_core__WEBPACK_IMPORTED_MODULE_7__["ɵɵtextInterpolate1"]("", _angular_core__WEBPACK_IMPORTED_MODULE_7__["ɵɵpipeBind1"](45, 33, "campaigns.joinmodal.confirm"), " ");
    }
  },
  directives: [_ionic_angular__WEBPACK_IMPORTED_MODULE_9__.IonHeader, _ionic_angular__WEBPACK_IMPORTED_MODULE_9__.IonToolbar, _ionic_angular__WEBPACK_IMPORTED_MODULE_9__.IonTitle, _ionic_angular__WEBPACK_IMPORTED_MODULE_9__.IonButtons, _ionic_angular__WEBPACK_IMPORTED_MODULE_9__.IonButton, _ionic_angular__WEBPACK_IMPORTED_MODULE_9__.IonIcon, _ionic_angular__WEBPACK_IMPORTED_MODULE_9__.IonContent, _angular_forms__WEBPACK_IMPORTED_MODULE_8__["ɵNgNoValidate"], _angular_forms__WEBPACK_IMPORTED_MODULE_8__.NgControlStatusGroup, _angular_forms__WEBPACK_IMPORTED_MODULE_8__.FormGroupDirective, _ionic_angular__WEBPACK_IMPORTED_MODULE_9__.IonGrid, _ionic_angular__WEBPACK_IMPORTED_MODULE_9__.IonRow, _angular_common__WEBPACK_IMPORTED_MODULE_10__.NgClass, _ionic_angular__WEBPACK_IMPORTED_MODULE_9__.IonCol, _ionic_angular__WEBPACK_IMPORTED_MODULE_9__.IonItem, _ionic_angular__WEBPACK_IMPORTED_MODULE_9__.IonLabel, ionic_selectable__WEBPACK_IMPORTED_MODULE_11__.IonicSelectableComponent, _angular_forms__WEBPACK_IMPORTED_MODULE_8__.NgControlStatus, _angular_forms__WEBPACK_IMPORTED_MODULE_8__.FormControlName, ionic_selectable__WEBPACK_IMPORTED_MODULE_12__.IonicSelectableTitleTemplateDirective, ionic_selectable__WEBPACK_IMPORTED_MODULE_13__.IonicSelectableCloseButtonTemplateDirective, ionic_selectable__WEBPACK_IMPORTED_MODULE_14__.IonicSelectableItemIconTemplateDirective, _angular_common__WEBPACK_IMPORTED_MODULE_10__.NgIf, _ionic_angular__WEBPACK_IMPORTED_MODULE_9__.IonInput, _ionic_angular__WEBPACK_IMPORTED_MODULE_9__.TextValueAccessor, _ionic_angular__WEBPACK_IMPORTED_MODULE_9__.IonCheckbox, _ionic_angular__WEBPACK_IMPORTED_MODULE_9__.BooleanValueAccessor],
  pipes: [_ngx_translate_core__WEBPACK_IMPORTED_MODULE_15__.TranslatePipe, src_app_core_shared_pipes_languageMap_pipe__WEBPACK_IMPORTED_MODULE_2__.LanguageMapPipe],
  styles: [".hide-company-selection[_ngcontent-%COMP%] {\n  height: 0px;\n  overflow: hidden;\n}\n\n.info[_ngcontent-%COMP%] {\n  display: flex;\n  align-items: center;\n  justify-content: center;\n  font-size: 26px;\n}\n/*# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbImpvaW4tY29tcGFueS5tb2RhbC5zY3NzIl0sIm5hbWVzIjpbXSwibWFwcGluZ3MiOiJBQUFBO0VBQ0UsV0FBQTtFQUNBLGdCQUFBO0FBQ0Y7O0FBQ0E7RUFDRSxhQUFBO0VBQ0EsbUJBQUE7RUFDQSx1QkFBQTtFQUNBLGVBQUE7QUFFRiIsImZpbGUiOiJqb2luLWNvbXBhbnkubW9kYWwuc2NzcyIsInNvdXJjZXNDb250ZW50IjpbIi5oaWRlLWNvbXBhbnktc2VsZWN0aW9uIHtcbiAgaGVpZ2h0OiAwcHg7XG4gIG92ZXJmbG93OiBoaWRkZW47XG59XG4uaW5mbyB7XG4gIGRpc3BsYXk6IGZsZXg7XG4gIGFsaWduLWl0ZW1zOiBjZW50ZXI7XG4gIGp1c3RpZnktY29udGVudDogY2VudGVyO1xuICBmb250LXNpemU6IDI2cHg7XG59XG4vLyAubW9kYWwtc2VsZWN0YWJsZSB7XG4vLyAgIC5zZWFyY2hiYXItaW5wdXQge1xuLy8gICAgIGNvbG9yOiB3aGl0ZTtcbi8vICAgfVxuLy8gfVxuIl19 */"]
});

/***/ }),

/***/ 65244:
/*!********************************************************************************!*\
  !*** ./src/app/pages/campaigns/campaign-join/join-school/join-school.modal.ts ***!
  \********************************************************************************/
/***/ (function(__unused_webpack_module, __webpack_exports__, __webpack_require__) {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "JoinSchoolModalPage": function() { return /* binding */ JoinSchoolModalPage; }
/* harmony export */ });
/* harmony import */ var _Users_smartcommunitylab_Desktop_newWork_dslab_playgo_mobile_playgo_mobile_node_modules_babel_runtime_helpers_esm_classCallCheck_js__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./node_modules/@babel/runtime/helpers/esm/classCallCheck.js */ 78069);
/* harmony import */ var _Users_smartcommunitylab_Desktop_newWork_dslab_playgo_mobile_playgo_mobile_node_modules_babel_runtime_helpers_esm_createClass_js__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ./node_modules/@babel/runtime/helpers/esm/createClass.js */ 48047);
/* harmony import */ var _angular_forms__WEBPACK_IMPORTED_MODULE_9__ = __webpack_require__(/*! @angular/forms */ 90587);
/* harmony import */ var src_app_core_shared_services_error_service__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! src/app/core/shared/services/error.service */ 96204);
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(/*! @angular/core */ 3184);
/* harmony import */ var _ionic_angular__WEBPACK_IMPORTED_MODULE_10__ = __webpack_require__(/*! @ionic/angular */ 93819);
/* harmony import */ var src_app_core_shared_services_team_service__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! src/app/core/shared/services/team.service */ 86612);
/* harmony import */ var src_app_core_shared_services_alert_service__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! src/app/core/shared/services/alert.service */ 46407);
/* harmony import */ var src_app_core_shared_services_campaign_service__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! src/app/core/shared/services/campaign.service */ 23645);
/* harmony import */ var src_app_core_shared_services_user_service__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! src/app/core/shared/services/user.service */ 50749);
/* harmony import */ var ionic_selectable__WEBPACK_IMPORTED_MODULE_11__ = __webpack_require__(/*! ionic-selectable */ 47123);
/* harmony import */ var ionic_selectable__WEBPACK_IMPORTED_MODULE_12__ = __webpack_require__(/*! ionic-selectable */ 99359);
/* harmony import */ var ionic_selectable__WEBPACK_IMPORTED_MODULE_13__ = __webpack_require__(/*! ionic-selectable */ 25260);
/* harmony import */ var ionic_selectable__WEBPACK_IMPORTED_MODULE_14__ = __webpack_require__(/*! ionic-selectable */ 85646);
/* harmony import */ var ionic_selectable__WEBPACK_IMPORTED_MODULE_15__ = __webpack_require__(/*! ionic-selectable */ 62933);
/* harmony import */ var ionic_selectable__WEBPACK_IMPORTED_MODULE_16__ = __webpack_require__(/*! ionic-selectable */ 41357);
/* harmony import */ var _angular_common__WEBPACK_IMPORTED_MODULE_17__ = __webpack_require__(/*! @angular/common */ 36362);
/* harmony import */ var _ngx_translate_core__WEBPACK_IMPORTED_MODULE_18__ = __webpack_require__(/*! @ngx-translate/core */ 87514);
/* harmony import */ var _core_shared_pipes_languageMap_pipe__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(/*! ../../../../core/shared/pipes/languageMap.pipe */ 73088);

















function JoinSchoolModalPage_ng_template_20_Template(rf, ctx) {
  if (rf & 1) {
    _angular_core__WEBPACK_IMPORTED_MODULE_8__["ɵɵtext"](0);
    _angular_core__WEBPACK_IMPORTED_MODULE_8__["ɵɵpipe"](1, "translate");
  }

  if (rf & 2) {
    _angular_core__WEBPACK_IMPORTED_MODULE_8__["ɵɵtextInterpolate1"](" ", _angular_core__WEBPACK_IMPORTED_MODULE_8__["ɵɵpipeBind1"](1, 1, "campaigns.joinmodal.teams"), " ");
  }
}

function JoinSchoolModalPage_ng_template_21_Template(rf, ctx) {
  if (rf & 1) {
    _angular_core__WEBPACK_IMPORTED_MODULE_8__["ɵɵelement"](0, "ion-icon", 15);
  }
}

function JoinSchoolModalPage_ng_template_22_Template(rf, ctx) {
  if (rf & 1) {
    _angular_core__WEBPACK_IMPORTED_MODULE_8__["ɵɵelement"](0, "ion-icon", 16);
  }

  if (rf & 2) {
    var isPortSelected_r13 = ctx.isItemSelected;
    _angular_core__WEBPACK_IMPORTED_MODULE_8__["ɵɵproperty"]("name", isPortSelected_r13 ? "checkmark-circle" : "radio-button-off")("color", isPortSelected_r13 ? "light" : null);
  }
}

function JoinSchoolModalPage_ng_template_23_Template(rf, ctx) {
  if (rf & 1) {
    _angular_core__WEBPACK_IMPORTED_MODULE_8__["ɵɵelementStart"](0, "span", 17);
    _angular_core__WEBPACK_IMPORTED_MODULE_8__["ɵɵtext"](1);
    _angular_core__WEBPACK_IMPORTED_MODULE_8__["ɵɵelementEnd"]();
  }

  if (rf & 2) {
    var port_r14 = ctx.item;
    _angular_core__WEBPACK_IMPORTED_MODULE_8__["ɵɵadvance"](1);
    _angular_core__WEBPACK_IMPORTED_MODULE_8__["ɵɵtextInterpolate"](port_r14.customData.name);
  }
}

function JoinSchoolModalPage_ng_template_24_Template(rf, ctx) {
  if (rf & 1) {
    _angular_core__WEBPACK_IMPORTED_MODULE_8__["ɵɵelementStart"](0, "span");
    _angular_core__WEBPACK_IMPORTED_MODULE_8__["ɵɵtext"](1);
    _angular_core__WEBPACK_IMPORTED_MODULE_8__["ɵɵelementEnd"]();
  }

  if (rf & 2) {
    var port_r16 = ctx.value;
    _angular_core__WEBPACK_IMPORTED_MODULE_8__["ɵɵadvance"](1);
    _angular_core__WEBPACK_IMPORTED_MODULE_8__["ɵɵtextInterpolate"](port_r16.customData.name);
  }
}

function JoinSchoolModalPage_div_25_Template(rf, ctx) {
  if (rf & 1) {
    _angular_core__WEBPACK_IMPORTED_MODULE_8__["ɵɵelementStart"](0, "div", 18);
    _angular_core__WEBPACK_IMPORTED_MODULE_8__["ɵɵtext"](1);
    _angular_core__WEBPACK_IMPORTED_MODULE_8__["ɵɵpipe"](2, "translate");
    _angular_core__WEBPACK_IMPORTED_MODULE_8__["ɵɵelementEnd"]();
  }

  if (rf & 2) {
    _angular_core__WEBPACK_IMPORTED_MODULE_8__["ɵɵadvance"](1);
    _angular_core__WEBPACK_IMPORTED_MODULE_8__["ɵɵtextInterpolate1"](" ", _angular_core__WEBPACK_IMPORTED_MODULE_8__["ɵɵpipeBind1"](2, 1, "campaigns.joinmodal.companyRequired"), " ");
  }
}

function JoinSchoolModalPage_ion_row_26_Template(rf, ctx) {
  if (rf & 1) {
    var _r18 = _angular_core__WEBPACK_IMPORTED_MODULE_8__["ɵɵgetCurrentView"]();

    _angular_core__WEBPACK_IMPORTED_MODULE_8__["ɵɵelementStart"](0, "ion-row", 5)(1, "ion-col", 19)(2, "ion-label", 20);
    _angular_core__WEBPACK_IMPORTED_MODULE_8__["ɵɵtext"](3);
    _angular_core__WEBPACK_IMPORTED_MODULE_8__["ɵɵpipe"](4, "translate");
    _angular_core__WEBPACK_IMPORTED_MODULE_8__["ɵɵelementEnd"]()();
    _angular_core__WEBPACK_IMPORTED_MODULE_8__["ɵɵelementStart"](5, "ion-col", 21);
    _angular_core__WEBPACK_IMPORTED_MODULE_8__["ɵɵlistener"]("click", function JoinSchoolModalPage_ion_row_26_Template_ion_col_click_5_listener() {
      _angular_core__WEBPACK_IMPORTED_MODULE_8__["ɵɵrestoreView"](_r18);
      var ctx_r17 = _angular_core__WEBPACK_IMPORTED_MODULE_8__["ɵɵnextContext"]();
      return ctx_r17.openPrivacyPopup();
    });
    _angular_core__WEBPACK_IMPORTED_MODULE_8__["ɵɵelement"](6, "ion-icon", 22);
    _angular_core__WEBPACK_IMPORTED_MODULE_8__["ɵɵelementEnd"]()();
  }

  if (rf & 2) {
    _angular_core__WEBPACK_IMPORTED_MODULE_8__["ɵɵadvance"](3);
    _angular_core__WEBPACK_IMPORTED_MODULE_8__["ɵɵtextInterpolate"](_angular_core__WEBPACK_IMPORTED_MODULE_8__["ɵɵpipeBind1"](4, 1, "campaigns.joinmodal.privacyLink"));
  }
}

function JoinSchoolModalPage_ion_row_27_Template(rf, ctx) {
  if (rf & 1) {
    _angular_core__WEBPACK_IMPORTED_MODULE_8__["ɵɵelementStart"](0, "ion-row", 5)(1, "ion-col")(2, "ion-item", 0);
    _angular_core__WEBPACK_IMPORTED_MODULE_8__["ɵɵelement"](3, "ion-checkbox", 23);
    _angular_core__WEBPACK_IMPORTED_MODULE_8__["ɵɵelementStart"](4, "ion-label", 24);
    _angular_core__WEBPACK_IMPORTED_MODULE_8__["ɵɵtext"](5);
    _angular_core__WEBPACK_IMPORTED_MODULE_8__["ɵɵpipe"](6, "translate");
    _angular_core__WEBPACK_IMPORTED_MODULE_8__["ɵɵelementEnd"]()()()();
  }

  if (rf & 2) {
    _angular_core__WEBPACK_IMPORTED_MODULE_8__["ɵɵadvance"](5);
    _angular_core__WEBPACK_IMPORTED_MODULE_8__["ɵɵtextInterpolate"](_angular_core__WEBPACK_IMPORTED_MODULE_8__["ɵɵpipeBind1"](6, 1, "campaigns.joinmodal.privacy"));
  }
}

function JoinSchoolModalPage_div_28_Template(rf, ctx) {
  if (rf & 1) {
    _angular_core__WEBPACK_IMPORTED_MODULE_8__["ɵɵelementStart"](0, "div", 18)(1, "span");
    _angular_core__WEBPACK_IMPORTED_MODULE_8__["ɵɵtext"](2);
    _angular_core__WEBPACK_IMPORTED_MODULE_8__["ɵɵpipe"](3, "translate");
    _angular_core__WEBPACK_IMPORTED_MODULE_8__["ɵɵelementEnd"]()();
  }

  if (rf & 2) {
    _angular_core__WEBPACK_IMPORTED_MODULE_8__["ɵɵadvance"](2);
    _angular_core__WEBPACK_IMPORTED_MODULE_8__["ɵɵtextInterpolate"](_angular_core__WEBPACK_IMPORTED_MODULE_8__["ɵɵpipeBind1"](3, 1, "campaigns.joinmodal.privacyRequired"));
  }
}

function JoinSchoolModalPage_ion_row_29_Template(rf, ctx) {
  if (rf & 1) {
    var _r20 = _angular_core__WEBPACK_IMPORTED_MODULE_8__["ɵɵgetCurrentView"]();

    _angular_core__WEBPACK_IMPORTED_MODULE_8__["ɵɵelementStart"](0, "ion-row", 5)(1, "ion-col", 19)(2, "ion-label", 20);
    _angular_core__WEBPACK_IMPORTED_MODULE_8__["ɵɵtext"](3);
    _angular_core__WEBPACK_IMPORTED_MODULE_8__["ɵɵpipe"](4, "translate");
    _angular_core__WEBPACK_IMPORTED_MODULE_8__["ɵɵelementEnd"]()();
    _angular_core__WEBPACK_IMPORTED_MODULE_8__["ɵɵelementStart"](5, "ion-col", 21);
    _angular_core__WEBPACK_IMPORTED_MODULE_8__["ɵɵlistener"]("click", function JoinSchoolModalPage_ion_row_29_Template_ion_col_click_5_listener() {
      _angular_core__WEBPACK_IMPORTED_MODULE_8__["ɵɵrestoreView"](_r20);
      var ctx_r19 = _angular_core__WEBPACK_IMPORTED_MODULE_8__["ɵɵnextContext"]();
      return ctx_r19.openRulesPopup();
    });
    _angular_core__WEBPACK_IMPORTED_MODULE_8__["ɵɵelement"](6, "ion-icon", 22);
    _angular_core__WEBPACK_IMPORTED_MODULE_8__["ɵɵelementEnd"]()();
  }

  if (rf & 2) {
    _angular_core__WEBPACK_IMPORTED_MODULE_8__["ɵɵadvance"](3);
    _angular_core__WEBPACK_IMPORTED_MODULE_8__["ɵɵtextInterpolate"](_angular_core__WEBPACK_IMPORTED_MODULE_8__["ɵɵpipeBind1"](4, 1, "campaigns.joinmodal.rulesLink"));
  }
}

function JoinSchoolModalPage_ion_row_30_Template(rf, ctx) {
  if (rf & 1) {
    _angular_core__WEBPACK_IMPORTED_MODULE_8__["ɵɵelementStart"](0, "ion-row", 5)(1, "ion-col")(2, "ion-item", 0);
    _angular_core__WEBPACK_IMPORTED_MODULE_8__["ɵɵelement"](3, "ion-checkbox", 25);
    _angular_core__WEBPACK_IMPORTED_MODULE_8__["ɵɵelementStart"](4, "ion-label", 24);
    _angular_core__WEBPACK_IMPORTED_MODULE_8__["ɵɵtext"](5);
    _angular_core__WEBPACK_IMPORTED_MODULE_8__["ɵɵpipe"](6, "translate");
    _angular_core__WEBPACK_IMPORTED_MODULE_8__["ɵɵelementEnd"]()()()();
  }

  if (rf & 2) {
    _angular_core__WEBPACK_IMPORTED_MODULE_8__["ɵɵadvance"](5);
    _angular_core__WEBPACK_IMPORTED_MODULE_8__["ɵɵtextInterpolate"](_angular_core__WEBPACK_IMPORTED_MODULE_8__["ɵɵpipeBind1"](6, 1, "campaigns.joinmodal.rules"));
  }
}

function JoinSchoolModalPage_div_31_Template(rf, ctx) {
  if (rf & 1) {
    _angular_core__WEBPACK_IMPORTED_MODULE_8__["ɵɵelementStart"](0, "div", 18)(1, "span");
    _angular_core__WEBPACK_IMPORTED_MODULE_8__["ɵɵtext"](2);
    _angular_core__WEBPACK_IMPORTED_MODULE_8__["ɵɵpipe"](3, "translate");
    _angular_core__WEBPACK_IMPORTED_MODULE_8__["ɵɵelementEnd"]()();
  }

  if (rf & 2) {
    _angular_core__WEBPACK_IMPORTED_MODULE_8__["ɵɵadvance"](2);
    _angular_core__WEBPACK_IMPORTED_MODULE_8__["ɵɵtextInterpolate"](_angular_core__WEBPACK_IMPORTED_MODULE_8__["ɵɵpipeBind1"](3, 1, "campaigns.joinmodal.rulesRequired"));
  }
}

var _c0 = function _c0(a0) {
  return {
    campaignTitle: a0
  };
};

var JoinSchoolModalPage = /*#__PURE__*/function () {
  function JoinSchoolModalPage(modalController, teamService, errorService, alertService, campaignService, formBuilder, userService, navCtrl, elementRef) {
    (0,_Users_smartcommunitylab_Desktop_newWork_dslab_playgo_mobile_playgo_mobile_node_modules_babel_runtime_helpers_esm_classCallCheck_js__WEBPACK_IMPORTED_MODULE_0__["default"])(this, JoinSchoolModalPage);

    this.modalController = modalController;
    this.teamService = teamService;
    this.errorService = errorService;
    this.alertService = alertService;
    this.campaignService = campaignService;
    this.formBuilder = formBuilder;
    this.userService = userService;
    this.navCtrl = navCtrl;
    this.elementRef = elementRef;
    this.isSubmitted = false;
  }

  (0,_Users_smartcommunitylab_Desktop_newWork_dslab_playgo_mobile_playgo_mobile_node_modules_babel_runtime_helpers_esm_createClass_js__WEBPACK_IMPORTED_MODULE_1__["default"])(JoinSchoolModalPage, [{
    key: "ngOnInit",
    value: function ngOnInit() {
      var _this = this;

      this.language = this.userService.getLanguage();
      var rules = this.campaign.details[this.language];
      this.rules = rules === null || rules === void 0 ? void 0 : rules.find(function (detail) {
        return detail.type === 'rules';
      });
      this.privacy = rules === null || rules === void 0 ? void 0 : rules.find(function (detail) {
        return detail.type === 'privacy';
      });
      this.joinSchoolForm = this.formBuilder.group(Object.assign(Object.assign({
        teamSelected: ['', [_angular_forms__WEBPACK_IMPORTED_MODULE_9__.Validators.required]]
      }, this.privacy && {
        privacy: [false, _angular_forms__WEBPACK_IMPORTED_MODULE_9__.Validators.requiredTrue]
      }), this.rules && {
        rules: [false, _angular_forms__WEBPACK_IMPORTED_MODULE_9__.Validators.requiredTrue]
      }));
      this.sub = this.teamService.getTeamsForSubscription(this.campaign.campaignId).subscribe(function (result) {
        if (result) {
          _this.teams = result;
        }
      });
    }
  }, {
    key: "ngOnDestroy",
    value: function ngOnDestroy() {
      this.sub.unsubscribe();
    } //computed errorcontrol

  }, {
    key: "errorControl",
    get: function get() {
      return this.joinSchoolForm.controls;
    }
  }, {
    key: "close",
    value: function close() {
      this.modalController.dismiss(false);
    }
  }, {
    key: "openPrivacyPopup",
    value: function openPrivacyPopup() {
      this.alertService.presentAlert({
        headerTranslateKey: 'campaigns.joinmodal.privacyPopup.header',
        messageString: this.privacy.content,
        cssClass: 'modalJoin'
      });
    }
  }, {
    key: "openRulesPopup",
    value: function openRulesPopup() {
      this.alertService.presentAlert({
        headerTranslateKey: 'campaigns.joinmodal.rulesPopup.header',
        messageString: this.rules.content,
        cssClass: 'modalJoin'
      });
    }
  }, {
    key: "openCodeInfoPopup",
    value: function openCodeInfoPopup() {
      this.alertService.presentAlert({
        headerTranslateKey: 'campaigns.joinmodal.codeInfo.header',
        messageString: 'campaigns.joinmodal.codeInfo.message',
        cssClass: 'modalConfirm'
      });
    }
  }, {
    key: "joinSchoolSubmit",
    value: function joinSchoolSubmit() {
      var _this2 = this;

      // call join with all params
      this.isSubmitted = true;

      if (!this.joinSchoolForm.valid) {
        return false;
      } else {
        var body = {
          teamId: this.teamSelected.id
        };
        this.campaignService.subscribeToCampaign(this.campaign.campaignId, body).subscribe(function (result) {
          if (result) {
            _this2.alertService.showToast({
              messageTranslateKey: 'campaigns.registered'
            });

            _this2.modalController.dismiss(true);

            _this2.navCtrl.navigateRoot('/pages/tabs/home');
          }
        }, function (err) {
          var error = new src_app_core_shared_services_error_service__WEBPACK_IMPORTED_MODULE_2__.UserError({
            id: 'ERROR_TEAM',
            message: 'campaigns.joinmodal.error.ERROR_TEAM'
          });

          _this2.errorService.handleError(error);
        });
      }
    }
  }, {
    key: "onSelect",
    value: function onSelect(event) {
      console.log('item' + JSON.stringify(event.item) + 'isSelected' + event.isSelected);
    }
  }]);

  return JoinSchoolModalPage;
}();

JoinSchoolModalPage.ɵfac = function JoinSchoolModalPage_Factory(t) {
  return new (t || JoinSchoolModalPage)(_angular_core__WEBPACK_IMPORTED_MODULE_8__["ɵɵdirectiveInject"](_ionic_angular__WEBPACK_IMPORTED_MODULE_10__.ModalController), _angular_core__WEBPACK_IMPORTED_MODULE_8__["ɵɵdirectiveInject"](src_app_core_shared_services_team_service__WEBPACK_IMPORTED_MODULE_3__.TeamService), _angular_core__WEBPACK_IMPORTED_MODULE_8__["ɵɵdirectiveInject"](src_app_core_shared_services_error_service__WEBPACK_IMPORTED_MODULE_2__.ErrorService), _angular_core__WEBPACK_IMPORTED_MODULE_8__["ɵɵdirectiveInject"](src_app_core_shared_services_alert_service__WEBPACK_IMPORTED_MODULE_4__.AlertService), _angular_core__WEBPACK_IMPORTED_MODULE_8__["ɵɵdirectiveInject"](src_app_core_shared_services_campaign_service__WEBPACK_IMPORTED_MODULE_5__.CampaignService), _angular_core__WEBPACK_IMPORTED_MODULE_8__["ɵɵdirectiveInject"](_angular_forms__WEBPACK_IMPORTED_MODULE_9__.FormBuilder), _angular_core__WEBPACK_IMPORTED_MODULE_8__["ɵɵdirectiveInject"](src_app_core_shared_services_user_service__WEBPACK_IMPORTED_MODULE_6__.UserService), _angular_core__WEBPACK_IMPORTED_MODULE_8__["ɵɵdirectiveInject"](_ionic_angular__WEBPACK_IMPORTED_MODULE_10__.NavController), _angular_core__WEBPACK_IMPORTED_MODULE_8__["ɵɵdirectiveInject"](_angular_core__WEBPACK_IMPORTED_MODULE_8__.ElementRef));
};

JoinSchoolModalPage.ɵcmp = /*@__PURE__*/_angular_core__WEBPACK_IMPORTED_MODULE_8__["ɵɵdefineComponent"]({
  type: JoinSchoolModalPage,
  selectors: [["app-join-school"]],
  decls: 37,
  vars: 28,
  consts: [["color", "playgo"], ["slot", "end"], [3, "click"], ["name", "close-circle-outline"], [3, "formGroup", "ngSubmit"], [1, "ion-margin-top"], ["itemValueField", "id", "itemTextField", "name", "formControlName", "teamSelected", "hasSearchText", "false", "headerColor", "playgo", "groupColor", "playgo", "modalCssClass", "modal-search-playgo", 3, "ngModel", "items", "searchFailText", "canSearch", "ngModelChange", "onSelect"], ["ionicSelectableTitleTemplate", ""], ["ionicSelectableCloseButtonTemplate", ""], ["ionicSelectableItemIconTemplate", ""], ["ionicSelectableItemTemplate", ""], ["ionicSelectableValueTemplate", ""], ["class", "error-message ion-padding", 4, "ngIf"], ["class", "ion-margin-top", 4, "ngIf"], ["color", "light", "type", "submit", "expand", "block"], ["name", "close-circle", 2, "font-size", "24px"], [3, "name", "color"], [2, "width", "100%"], [1, "error-message", "ion-padding"], ["size", "10"], [1, "privacy-info"], [1, "ion-text-center", 3, "click"], ["name", "information-circle-outline", 1, "popup-icon"], ["slot", "start", "color", "playgo", "formControlName", "privacy"], [1, "ion-text-wrap"], ["slot", "start", "color", "playgo", "formControlName", "rules"]],
  template: function JoinSchoolModalPage_Template(rf, ctx) {
    if (rf & 1) {
      _angular_core__WEBPACK_IMPORTED_MODULE_8__["ɵɵelementStart"](0, "ion-header")(1, "ion-toolbar", 0)(2, "ion-title");
      _angular_core__WEBPACK_IMPORTED_MODULE_8__["ɵɵtext"](3);
      _angular_core__WEBPACK_IMPORTED_MODULE_8__["ɵɵpipe"](4, "translate");
      _angular_core__WEBPACK_IMPORTED_MODULE_8__["ɵɵpipe"](5, "languageMap");
      _angular_core__WEBPACK_IMPORTED_MODULE_8__["ɵɵelementEnd"]();
      _angular_core__WEBPACK_IMPORTED_MODULE_8__["ɵɵelementStart"](6, "ion-buttons", 1)(7, "ion-button", 2);
      _angular_core__WEBPACK_IMPORTED_MODULE_8__["ɵɵlistener"]("click", function JoinSchoolModalPage_Template_ion_button_click_7_listener() {
        return ctx.close();
      });
      _angular_core__WEBPACK_IMPORTED_MODULE_8__["ɵɵelement"](8, "ion-icon", 3);
      _angular_core__WEBPACK_IMPORTED_MODULE_8__["ɵɵelementEnd"]()()()();
      _angular_core__WEBPACK_IMPORTED_MODULE_8__["ɵɵelementStart"](9, "ion-content", 0)(10, "form", 4);
      _angular_core__WEBPACK_IMPORTED_MODULE_8__["ɵɵlistener"]("ngSubmit", function JoinSchoolModalPage_Template_form_ngSubmit_10_listener() {
        return ctx.joinSchoolSubmit();
      });
      _angular_core__WEBPACK_IMPORTED_MODULE_8__["ɵɵelementStart"](11, "ion-grid")(12, "ion-row", 5)(13, "ion-col")(14, "ion-item", 0)(15, "ion-label");
      _angular_core__WEBPACK_IMPORTED_MODULE_8__["ɵɵtext"](16);
      _angular_core__WEBPACK_IMPORTED_MODULE_8__["ɵɵpipe"](17, "translate");
      _angular_core__WEBPACK_IMPORTED_MODULE_8__["ɵɵelementEnd"]();
      _angular_core__WEBPACK_IMPORTED_MODULE_8__["ɵɵelementStart"](18, "ionic-selectable", 6);
      _angular_core__WEBPACK_IMPORTED_MODULE_8__["ɵɵlistener"]("ngModelChange", function JoinSchoolModalPage_Template_ionic_selectable_ngModelChange_18_listener($event) {
        return ctx.teamSelected = $event;
      })("onSelect", function JoinSchoolModalPage_Template_ionic_selectable_onSelect_18_listener($event) {
        return ctx.onSelect($event);
      });
      _angular_core__WEBPACK_IMPORTED_MODULE_8__["ɵɵpipe"](19, "translate");
      _angular_core__WEBPACK_IMPORTED_MODULE_8__["ɵɵtemplate"](20, JoinSchoolModalPage_ng_template_20_Template, 2, 3, "ng-template", 7);
      _angular_core__WEBPACK_IMPORTED_MODULE_8__["ɵɵtemplate"](21, JoinSchoolModalPage_ng_template_21_Template, 1, 0, "ng-template", 8);
      _angular_core__WEBPACK_IMPORTED_MODULE_8__["ɵɵtemplate"](22, JoinSchoolModalPage_ng_template_22_Template, 1, 2, "ng-template", 9);
      _angular_core__WEBPACK_IMPORTED_MODULE_8__["ɵɵtemplate"](23, JoinSchoolModalPage_ng_template_23_Template, 2, 1, "ng-template", 10);
      _angular_core__WEBPACK_IMPORTED_MODULE_8__["ɵɵtemplate"](24, JoinSchoolModalPage_ng_template_24_Template, 2, 1, "ng-template", 11);
      _angular_core__WEBPACK_IMPORTED_MODULE_8__["ɵɵelementEnd"]()()()();
      _angular_core__WEBPACK_IMPORTED_MODULE_8__["ɵɵtemplate"](25, JoinSchoolModalPage_div_25_Template, 3, 3, "div", 12);
      _angular_core__WEBPACK_IMPORTED_MODULE_8__["ɵɵtemplate"](26, JoinSchoolModalPage_ion_row_26_Template, 7, 3, "ion-row", 13);
      _angular_core__WEBPACK_IMPORTED_MODULE_8__["ɵɵtemplate"](27, JoinSchoolModalPage_ion_row_27_Template, 7, 3, "ion-row", 13);
      _angular_core__WEBPACK_IMPORTED_MODULE_8__["ɵɵtemplate"](28, JoinSchoolModalPage_div_28_Template, 4, 3, "div", 12);
      _angular_core__WEBPACK_IMPORTED_MODULE_8__["ɵɵtemplate"](29, JoinSchoolModalPage_ion_row_29_Template, 7, 3, "ion-row", 13);
      _angular_core__WEBPACK_IMPORTED_MODULE_8__["ɵɵtemplate"](30, JoinSchoolModalPage_ion_row_30_Template, 7, 3, "ion-row", 13);
      _angular_core__WEBPACK_IMPORTED_MODULE_8__["ɵɵtemplate"](31, JoinSchoolModalPage_div_31_Template, 4, 3, "div", 12);
      _angular_core__WEBPACK_IMPORTED_MODULE_8__["ɵɵelementStart"](32, "ion-row")(33, "ion-col")(34, "ion-button", 14);
      _angular_core__WEBPACK_IMPORTED_MODULE_8__["ɵɵtext"](35);
      _angular_core__WEBPACK_IMPORTED_MODULE_8__["ɵɵpipe"](36, "translate");
      _angular_core__WEBPACK_IMPORTED_MODULE_8__["ɵɵelementEnd"]()()()()()();
    }

    if (rf & 2) {
      _angular_core__WEBPACK_IMPORTED_MODULE_8__["ɵɵadvance"](3);
      _angular_core__WEBPACK_IMPORTED_MODULE_8__["ɵɵtextInterpolate"](_angular_core__WEBPACK_IMPORTED_MODULE_8__["ɵɵpipeBind2"](4, 15, "campaigns.joinmodal.modalTitle", _angular_core__WEBPACK_IMPORTED_MODULE_8__["ɵɵpureFunction1"](26, _c0, _angular_core__WEBPACK_IMPORTED_MODULE_8__["ɵɵpipeBind1"](5, 18, ctx.campaign == null ? null : ctx.campaign.name))));
      _angular_core__WEBPACK_IMPORTED_MODULE_8__["ɵɵadvance"](7);
      _angular_core__WEBPACK_IMPORTED_MODULE_8__["ɵɵproperty"]("formGroup", ctx.joinSchoolForm);
      _angular_core__WEBPACK_IMPORTED_MODULE_8__["ɵɵadvance"](6);
      _angular_core__WEBPACK_IMPORTED_MODULE_8__["ɵɵtextInterpolate"](_angular_core__WEBPACK_IMPORTED_MODULE_8__["ɵɵpipeBind1"](17, 20, "campaigns.joinmodal.teamselection"));
      _angular_core__WEBPACK_IMPORTED_MODULE_8__["ɵɵadvance"](2);
      _angular_core__WEBPACK_IMPORTED_MODULE_8__["ɵɵproperty"]("ngModel", ctx.teamSelected)("items", ctx.teams)("searchFailText", _angular_core__WEBPACK_IMPORTED_MODULE_8__["ɵɵpipeBind1"](19, 22, "campaigns.joinmodal.noItems"))("canSearch", true);
      _angular_core__WEBPACK_IMPORTED_MODULE_8__["ɵɵadvance"](7);
      _angular_core__WEBPACK_IMPORTED_MODULE_8__["ɵɵproperty"]("ngIf", ctx.isSubmitted && (ctx.errorControl == null ? null : ctx.errorControl.teamSelected == null ? null : ctx.errorControl.teamSelected.errors));
      _angular_core__WEBPACK_IMPORTED_MODULE_8__["ɵɵadvance"](1);
      _angular_core__WEBPACK_IMPORTED_MODULE_8__["ɵɵproperty"]("ngIf", ctx.privacy);
      _angular_core__WEBPACK_IMPORTED_MODULE_8__["ɵɵadvance"](1);
      _angular_core__WEBPACK_IMPORTED_MODULE_8__["ɵɵproperty"]("ngIf", ctx.privacy);
      _angular_core__WEBPACK_IMPORTED_MODULE_8__["ɵɵadvance"](1);
      _angular_core__WEBPACK_IMPORTED_MODULE_8__["ɵɵproperty"]("ngIf", ctx.isSubmitted && (ctx.errorControl == null ? null : ctx.errorControl.privacy == null ? null : ctx.errorControl.privacy.errors));
      _angular_core__WEBPACK_IMPORTED_MODULE_8__["ɵɵadvance"](1);
      _angular_core__WEBPACK_IMPORTED_MODULE_8__["ɵɵproperty"]("ngIf", ctx.rules);
      _angular_core__WEBPACK_IMPORTED_MODULE_8__["ɵɵadvance"](1);
      _angular_core__WEBPACK_IMPORTED_MODULE_8__["ɵɵproperty"]("ngIf", ctx.rules);
      _angular_core__WEBPACK_IMPORTED_MODULE_8__["ɵɵadvance"](1);
      _angular_core__WEBPACK_IMPORTED_MODULE_8__["ɵɵproperty"]("ngIf", ctx.isSubmitted && (ctx.errorControl == null ? null : ctx.errorControl.rules == null ? null : ctx.errorControl.rules.errors));
      _angular_core__WEBPACK_IMPORTED_MODULE_8__["ɵɵadvance"](4);
      _angular_core__WEBPACK_IMPORTED_MODULE_8__["ɵɵtextInterpolate1"]("", _angular_core__WEBPACK_IMPORTED_MODULE_8__["ɵɵpipeBind1"](36, 24, "campaigns.joinmodal.confirm"), " ");
    }
  },
  directives: [_ionic_angular__WEBPACK_IMPORTED_MODULE_10__.IonHeader, _ionic_angular__WEBPACK_IMPORTED_MODULE_10__.IonToolbar, _ionic_angular__WEBPACK_IMPORTED_MODULE_10__.IonTitle, _ionic_angular__WEBPACK_IMPORTED_MODULE_10__.IonButtons, _ionic_angular__WEBPACK_IMPORTED_MODULE_10__.IonButton, _ionic_angular__WEBPACK_IMPORTED_MODULE_10__.IonIcon, _ionic_angular__WEBPACK_IMPORTED_MODULE_10__.IonContent, _angular_forms__WEBPACK_IMPORTED_MODULE_9__["ɵNgNoValidate"], _angular_forms__WEBPACK_IMPORTED_MODULE_9__.NgControlStatusGroup, _angular_forms__WEBPACK_IMPORTED_MODULE_9__.FormGroupDirective, _ionic_angular__WEBPACK_IMPORTED_MODULE_10__.IonGrid, _ionic_angular__WEBPACK_IMPORTED_MODULE_10__.IonRow, _ionic_angular__WEBPACK_IMPORTED_MODULE_10__.IonCol, _ionic_angular__WEBPACK_IMPORTED_MODULE_10__.IonItem, _ionic_angular__WEBPACK_IMPORTED_MODULE_10__.IonLabel, ionic_selectable__WEBPACK_IMPORTED_MODULE_11__.IonicSelectableComponent, _angular_forms__WEBPACK_IMPORTED_MODULE_9__.NgControlStatus, _angular_forms__WEBPACK_IMPORTED_MODULE_9__.FormControlName, ionic_selectable__WEBPACK_IMPORTED_MODULE_12__.IonicSelectableTitleTemplateDirective, ionic_selectable__WEBPACK_IMPORTED_MODULE_13__.IonicSelectableCloseButtonTemplateDirective, ionic_selectable__WEBPACK_IMPORTED_MODULE_14__.IonicSelectableItemIconTemplateDirective, ionic_selectable__WEBPACK_IMPORTED_MODULE_15__.IonicSelectableItemTemplateDirective, ionic_selectable__WEBPACK_IMPORTED_MODULE_16__.IonicSelectableValueTemplateDirective, _angular_common__WEBPACK_IMPORTED_MODULE_17__.NgIf, _ionic_angular__WEBPACK_IMPORTED_MODULE_10__.IonCheckbox, _ionic_angular__WEBPACK_IMPORTED_MODULE_10__.BooleanValueAccessor],
  pipes: [_ngx_translate_core__WEBPACK_IMPORTED_MODULE_18__.TranslatePipe, _core_shared_pipes_languageMap_pipe__WEBPACK_IMPORTED_MODULE_7__.LanguageMapPipe],
  styles: ["\n/*# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbXSwibmFtZXMiOltdLCJtYXBwaW5ncyI6IiIsImZpbGUiOiJqb2luLXNjaG9vbC5tb2RhbC5zY3NzIn0= */"]
});

/***/ }),

/***/ 88043:
/*!********************************************************************************!*\
  !*** ./src/app/pages/home/campaign-details/companies-modal/companies.modal.ts ***!
  \********************************************************************************/
/***/ (function(__unused_webpack_module, __webpack_exports__, __webpack_require__) {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "CompaniesCampaignModalPage": function() { return /* binding */ CompaniesCampaignModalPage; }
/* harmony export */ });
/* harmony import */ var _Users_smartcommunitylab_Desktop_newWork_dslab_playgo_mobile_playgo_mobile_node_modules_babel_runtime_helpers_esm_classCallCheck_js__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./node_modules/@babel/runtime/helpers/esm/classCallCheck.js */ 78069);
/* harmony import */ var _Users_smartcommunitylab_Desktop_newWork_dslab_playgo_mobile_playgo_mobile_node_modules_babel_runtime_helpers_esm_createClass_js__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ./node_modules/@babel/runtime/helpers/esm/createClass.js */ 48047);
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @angular/core */ 3184);
/* harmony import */ var _ionic_angular__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! @ionic/angular */ 93819);
/* harmony import */ var src_app_core_shared_services_campaign_service__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! src/app/core/shared/services/campaign.service */ 23645);
/* harmony import */ var _angular_common__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! @angular/common */ 36362);
/* harmony import */ var _ngx_translate_core__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! @ngx-translate/core */ 87514);








function CompaniesCampaignModalPage_div_10_Template(rf, ctx) {
  if (rf & 1) {
    _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵelementStart"](0, "div")(1, "ion-item")(2, "ion-label");
    _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵtext"](3);
    _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵelementEnd"]()()();
  }

  if (rf & 2) {
    var company_r1 = ctx.$implicit;
    _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵadvance"](3);
    _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵtextInterpolate"](company_r1.name);
  }
}

var CompaniesCampaignModalPage = /*#__PURE__*/function () {
  function CompaniesCampaignModalPage(modalController, campaignService) {
    (0,_Users_smartcommunitylab_Desktop_newWork_dslab_playgo_mobile_playgo_mobile_node_modules_babel_runtime_helpers_esm_classCallCheck_js__WEBPACK_IMPORTED_MODULE_0__["default"])(this, CompaniesCampaignModalPage);

    this.modalController = modalController;
    this.campaignService = campaignService;
  }

  (0,_Users_smartcommunitylab_Desktop_newWork_dslab_playgo_mobile_playgo_mobile_node_modules_babel_runtime_helpers_esm_createClass_js__WEBPACK_IMPORTED_MODULE_1__["default"])(CompaniesCampaignModalPage, [{
    key: "ngOnInit",
    value: function ngOnInit() {
      var _this = this;

      var _a;

      this.sub = this.campaignService.getCompaniesForSubscription((_a = this === null || this === void 0 ? void 0 : this.campaign) === null || _a === void 0 ? void 0 : _a.campaignId).subscribe(function (result) {
        if (result) {
          _this.companies = result;
        }
      });
    }
  }, {
    key: "close",
    value: function close() {
      this.modalController.dismiss(false);
    }
  }]);

  return CompaniesCampaignModalPage;
}();

CompaniesCampaignModalPage.ɵfac = function CompaniesCampaignModalPage_Factory(t) {
  return new (t || CompaniesCampaignModalPage)(_angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵdirectiveInject"](_ionic_angular__WEBPACK_IMPORTED_MODULE_4__.ModalController), _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵdirectiveInject"](src_app_core_shared_services_campaign_service__WEBPACK_IMPORTED_MODULE_2__.CampaignService));
};

CompaniesCampaignModalPage.ɵcmp = /*@__PURE__*/_angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵdefineComponent"]({
  type: CompaniesCampaignModalPage,
  selectors: [["app-detail-modal"]],
  decls: 11,
  vars: 7,
  consts: [["color", "playgo"], ["slot", "end"], [3, "click"], [1, "ion-padding"], [4, "ngFor", "ngForOf"]],
  template: function CompaniesCampaignModalPage_Template(rf, ctx) {
    if (rf & 1) {
      _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵelementStart"](0, "ion-header")(1, "ion-toolbar", 0)(2, "ion-title");
      _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵtext"](3);
      _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵpipe"](4, "translate");
      _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵelementEnd"]();
      _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵelementStart"](5, "ion-buttons", 1)(6, "ion-button", 2);
      _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵlistener"]("click", function CompaniesCampaignModalPage_Template_ion_button_click_6_listener() {
        return ctx.close();
      });
      _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵtext"](7);
      _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵpipe"](8, "translate");
      _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵelementEnd"]()()()();
      _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵelementStart"](9, "ion-content", 3);
      _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵtemplate"](10, CompaniesCampaignModalPage_div_10_Template, 4, 1, "div", 4);
      _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵelementEnd"]();
    }

    if (rf & 2) {
      _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵadvance"](3);
      _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵtextInterpolate"](_angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵpipeBind1"](4, 3, "campaigns.campaignmodal.title"));
      _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵadvance"](4);
      _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵtextInterpolate"](_angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵpipeBind1"](8, 5, "campaigns.campaignmodal.close"));
      _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵadvance"](3);
      _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵproperty"]("ngForOf", ctx.companies);
    }
  },
  directives: [_ionic_angular__WEBPACK_IMPORTED_MODULE_4__.IonHeader, _ionic_angular__WEBPACK_IMPORTED_MODULE_4__.IonToolbar, _ionic_angular__WEBPACK_IMPORTED_MODULE_4__.IonTitle, _ionic_angular__WEBPACK_IMPORTED_MODULE_4__.IonButtons, _ionic_angular__WEBPACK_IMPORTED_MODULE_4__.IonButton, _ionic_angular__WEBPACK_IMPORTED_MODULE_4__.IonContent, _angular_common__WEBPACK_IMPORTED_MODULE_5__.NgForOf, _ionic_angular__WEBPACK_IMPORTED_MODULE_4__.IonItem, _ionic_angular__WEBPACK_IMPORTED_MODULE_4__.IonLabel],
  pipes: [_ngx_translate_core__WEBPACK_IMPORTED_MODULE_6__.TranslatePipe],
  styles: ["\n/*# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbXSwibmFtZXMiOltdLCJtYXBwaW5ncyI6IiIsImZpbGUiOiJjb21wYW5pZXMubW9kYWwuc2NzcyJ9 */"]
});

/***/ }),

/***/ 30451:
/*!**************************************************************************!*\
  !*** ./src/app/pages/home/campaign-details/detail-modal/detail.modal.ts ***!
  \**************************************************************************/
/***/ (function(__unused_webpack_module, __webpack_exports__, __webpack_require__) {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "DetailCampaignModalPage": function() { return /* binding */ DetailCampaignModalPage; }
/* harmony export */ });
/* harmony import */ var _Users_smartcommunitylab_Desktop_newWork_dslab_playgo_mobile_playgo_mobile_node_modules_babel_runtime_helpers_esm_classCallCheck_js__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./node_modules/@babel/runtime/helpers/esm/classCallCheck.js */ 78069);
/* harmony import */ var _Users_smartcommunitylab_Desktop_newWork_dslab_playgo_mobile_playgo_mobile_node_modules_babel_runtime_helpers_esm_createClass_js__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ./node_modules/@babel/runtime/helpers/esm/createClass.js */ 48047);
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @angular/core */ 3184);
/* harmony import */ var _ionic_angular__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @ionic/angular */ 93819);




var DetailCampaignModalPage = /*#__PURE__*/function () {
  function DetailCampaignModalPage(modalController) {
    (0,_Users_smartcommunitylab_Desktop_newWork_dslab_playgo_mobile_playgo_mobile_node_modules_babel_runtime_helpers_esm_classCallCheck_js__WEBPACK_IMPORTED_MODULE_0__["default"])(this, DetailCampaignModalPage);

    this.modalController = modalController;
    this.type = 'playgo';
  }

  (0,_Users_smartcommunitylab_Desktop_newWork_dslab_playgo_mobile_playgo_mobile_node_modules_babel_runtime_helpers_esm_createClass_js__WEBPACK_IMPORTED_MODULE_1__["default"])(DetailCampaignModalPage, [{
    key: "ngOnInit",
    value: function ngOnInit() {}
  }, {
    key: "close",
    value: function close() {
      this.modalController.dismiss(false);
    }
  }]);

  return DetailCampaignModalPage;
}();

DetailCampaignModalPage.ɵfac = function DetailCampaignModalPage_Factory(t) {
  return new (t || DetailCampaignModalPage)(_angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵdirectiveInject"](_ionic_angular__WEBPACK_IMPORTED_MODULE_3__.ModalController));
};

DetailCampaignModalPage.ɵcmp = /*@__PURE__*/_angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵdefineComponent"]({
  type: DetailCampaignModalPage,
  selectors: [["app-detail-modal"]],
  decls: 9,
  vars: 3,
  consts: [[3, "color"], ["slot", "end"], [3, "click"], ["name", "close-circle-outline"], [1, "ion-padding"], [3, "innerHTML"]],
  template: function DetailCampaignModalPage_Template(rf, ctx) {
    if (rf & 1) {
      _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵelementStart"](0, "ion-header")(1, "ion-toolbar", 0)(2, "ion-title");
      _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵtext"](3);
      _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵelementEnd"]();
      _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵelementStart"](4, "ion-buttons", 1)(5, "ion-button", 2);
      _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵlistener"]("click", function DetailCampaignModalPage_Template_ion_button_click_5_listener() {
        return ctx.close();
      });
      _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵelement"](6, "ion-icon", 3);
      _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵelementEnd"]()()()();
      _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵelementStart"](7, "ion-content", 4);
      _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵelement"](8, "div", 5);
      _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵelementEnd"]();
    }

    if (rf & 2) {
      _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵadvance"](1);
      _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵproperty"]("color", ctx.type);
      _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵadvance"](2);
      _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵtextInterpolate"](ctx.detail == null ? null : ctx.detail.name);
      _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵadvance"](5);
      _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵproperty"]("innerHTML", ctx.detail == null ? null : ctx.detail.content, _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵsanitizeHtml"]);
    }
  },
  directives: [_ionic_angular__WEBPACK_IMPORTED_MODULE_3__.IonHeader, _ionic_angular__WEBPACK_IMPORTED_MODULE_3__.IonToolbar, _ionic_angular__WEBPACK_IMPORTED_MODULE_3__.IonTitle, _ionic_angular__WEBPACK_IMPORTED_MODULE_3__.IonButtons, _ionic_angular__WEBPACK_IMPORTED_MODULE_3__.IonButton, _ionic_angular__WEBPACK_IMPORTED_MODULE_3__.IonIcon, _ionic_angular__WEBPACK_IMPORTED_MODULE_3__.IonContent],
  styles: ["\n/*# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbXSwibmFtZXMiOltdLCJtYXBwaW5ncyI6IiIsImZpbGUiOiJkZXRhaWwubW9kYWwuc2NzcyJ9 */"]
});

/***/ })

}]);
//# sourceMappingURL=src_app_pages_campaigns_campaign-join_campaign-join_module_ts.js.map