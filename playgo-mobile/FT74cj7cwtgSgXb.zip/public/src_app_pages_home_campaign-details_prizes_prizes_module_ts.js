"use strict";
(self["webpackChunkapp"] = self["webpackChunkapp"] || []).push([["src_app_pages_home_campaign-details_prizes_prizes_module_ts"],{

/***/ 74397:
/*!*********************************************************************************!*\
  !*** ./src/app/pages/home/campaign-details/prizes/detail-modal/detail.modal.ts ***!
  \*********************************************************************************/
/***/ (function(__unused_webpack_module, __webpack_exports__, __webpack_require__) {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "DetailPrizeModalPage": function() { return /* binding */ DetailPrizeModalPage; }
/* harmony export */ });
/* harmony import */ var _Users_smartcommunitylab_Desktop_newWork_dslab_playgo_mobile_playgo_mobile_node_modules_babel_runtime_helpers_esm_classCallCheck_js__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./node_modules/@babel/runtime/helpers/esm/classCallCheck.js */ 78069);
/* harmony import */ var _Users_smartcommunitylab_Desktop_newWork_dslab_playgo_mobile_playgo_mobile_node_modules_babel_runtime_helpers_esm_createClass_js__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ./node_modules/@babel/runtime/helpers/esm/createClass.js */ 48047);
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @angular/core */ 3184);
/* harmony import */ var _ionic_angular__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! @ionic/angular */ 93819);
/* harmony import */ var _core_shared_pipes_languageMap_pipe__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! ../../../../../core/shared/pipes/languageMap.pipe */ 73088);
/* harmony import */ var _ngx_translate_core__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! @ngx-translate/core */ 87514);






var DetailPrizeModalPage = /*#__PURE__*/function () {
  function DetailPrizeModalPage(modalController) {
    (0,_Users_smartcommunitylab_Desktop_newWork_dslab_playgo_mobile_playgo_mobile_node_modules_babel_runtime_helpers_esm_classCallCheck_js__WEBPACK_IMPORTED_MODULE_0__["default"])(this, DetailPrizeModalPage);

    this.modalController = modalController;
    this.type = 'playgo';
  }

  (0,_Users_smartcommunitylab_Desktop_newWork_dslab_playgo_mobile_playgo_mobile_node_modules_babel_runtime_helpers_esm_createClass_js__WEBPACK_IMPORTED_MODULE_1__["default"])(DetailPrizeModalPage, [{
    key: "ngOnInit",
    value: function ngOnInit() {}
  }, {
    key: "close",
    value: function close() {
      this.modalController.dismiss(false);
    }
  }]);

  return DetailPrizeModalPage;
}();

DetailPrizeModalPage.ɵfac = function DetailPrizeModalPage_Factory(t) {
  return new (t || DetailPrizeModalPage)(_angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵdirectiveInject"](_ionic_angular__WEBPACK_IMPORTED_MODULE_4__.ModalController));
};

DetailPrizeModalPage.ɵcmp = /*@__PURE__*/_angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵdefineComponent"]({
  type: DetailPrizeModalPage,
  selectors: [["app-detail-modal"]],
  decls: 14,
  vars: 9,
  consts: [[3, "color"], ["mode", "md"], ["slot", " end"], [3, "click"], ["name", "close-circle-outline"], [1, "ion-padding", 3, "color"], [3, "innerHTML"], ["color", "playgo", 1, "ion-text-center"], ["expand", "block", "color", "light", 3, "click"]],
  template: function DetailPrizeModalPage_Template(rf, ctx) {
    if (rf & 1) {
      _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵelementStart"](0, "ion-header")(1, "ion-toolbar", 0)(2, "ion-title", 1);
      _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵtext"](3);
      _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵelementEnd"]();
      _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵelementStart"](4, "ion-buttons", 2)(5, "ion-button", 3);
      _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵlistener"]("click", function DetailPrizeModalPage_Template_ion_button_click_5_listener() {
        return ctx.close();
      });
      _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵelement"](6, "ion-icon", 4);
      _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵelementEnd"]()()()();
      _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵelementStart"](7, "ion-content", 5);
      _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵelement"](8, "div", 6);
      _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵpipe"](9, "languageMap");
      _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵelementEnd"]();
      _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵelementStart"](10, "ion-footer", 7)(11, "ion-button", 8);
      _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵlistener"]("click", function DetailPrizeModalPage_Template_ion_button_click_11_listener() {
        return ctx.close();
      });
      _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵtext"](12);
      _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵpipe"](13, "translate");
      _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵelementEnd"]()();
    }

    if (rf & 2) {
      _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵadvance"](1);
      _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵproperty"]("color", ctx.type);
      _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵadvance"](2);
      _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵtextInterpolate"](ctx.title);
      _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵadvance"](4);
      _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵproperty"]("color", ctx.type);
      _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵadvance"](1);
      _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵproperty"]("innerHTML", _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵpipeBind1"](9, 5, ctx.detail), _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵsanitizeHtml"]);
      _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵadvance"](4);
      _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵtextInterpolate"](_angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵpipeBind1"](13, 7, "modal.ok"));
    }
  },
  directives: [_ionic_angular__WEBPACK_IMPORTED_MODULE_4__.IonHeader, _ionic_angular__WEBPACK_IMPORTED_MODULE_4__.IonToolbar, _ionic_angular__WEBPACK_IMPORTED_MODULE_4__.IonTitle, _ionic_angular__WEBPACK_IMPORTED_MODULE_4__.IonButtons, _ionic_angular__WEBPACK_IMPORTED_MODULE_4__.IonButton, _ionic_angular__WEBPACK_IMPORTED_MODULE_4__.IonIcon, _ionic_angular__WEBPACK_IMPORTED_MODULE_4__.IonContent, _ionic_angular__WEBPACK_IMPORTED_MODULE_4__.IonFooter],
  pipes: [_core_shared_pipes_languageMap_pipe__WEBPACK_IMPORTED_MODULE_2__.LanguageMapPipe, _ngx_translate_core__WEBPACK_IMPORTED_MODULE_5__.TranslatePipe],
  styles: ["\n/*# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbXSwibmFtZXMiOltdLCJtYXBwaW5ncyI6IiIsImZpbGUiOiJkZXRhaWwubW9kYWwuc2NzcyJ9 */"]
});

/***/ }),

/***/ 96989:
/*!*******************************************************************************!*\
  !*** ./src/app/pages/home/campaign-details/prizes/prize-modal/prize.modal.ts ***!
  \*******************************************************************************/
/***/ (function(__unused_webpack_module, __webpack_exports__, __webpack_require__) {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "PrizeModalPage": function() { return /* binding */ PrizeModalPage; }
/* harmony export */ });
/* harmony import */ var _Users_smartcommunitylab_Desktop_newWork_dslab_playgo_mobile_playgo_mobile_node_modules_babel_runtime_helpers_esm_classCallCheck_js__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./node_modules/@babel/runtime/helpers/esm/classCallCheck.js */ 78069);
/* harmony import */ var _Users_smartcommunitylab_Desktop_newWork_dslab_playgo_mobile_playgo_mobile_node_modules_babel_runtime_helpers_esm_createClass_js__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ./node_modules/@babel/runtime/helpers/esm/createClass.js */ 48047);
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @angular/core */ 3184);
/* harmony import */ var _ionic_angular__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @ionic/angular */ 93819);
/* harmony import */ var _ngx_translate_core__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! @ngx-translate/core */ 87514);





var PrizeModalPage = /*#__PURE__*/function () {
  function PrizeModalPage(modalController) {
    (0,_Users_smartcommunitylab_Desktop_newWork_dslab_playgo_mobile_playgo_mobile_node_modules_babel_runtime_helpers_esm_classCallCheck_js__WEBPACK_IMPORTED_MODULE_0__["default"])(this, PrizeModalPage);

    this.modalController = modalController;
  }

  (0,_Users_smartcommunitylab_Desktop_newWork_dslab_playgo_mobile_playgo_mobile_node_modules_babel_runtime_helpers_esm_createClass_js__WEBPACK_IMPORTED_MODULE_1__["default"])(PrizeModalPage, [{
    key: "ngOnInit",
    value: function ngOnInit() {}
  }, {
    key: "close",
    value: function close() {
      this.modalController.dismiss(false);
    }
  }]);

  return PrizeModalPage;
}();

PrizeModalPage.ɵfac = function PrizeModalPage_Factory(t) {
  return new (t || PrizeModalPage)(_angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵdirectiveInject"](_ionic_angular__WEBPACK_IMPORTED_MODULE_3__.ModalController));
};

PrizeModalPage.ɵcmp = /*@__PURE__*/_angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵdefineComponent"]({
  type: PrizeModalPage,
  selectors: [["app-prize-modal"]],
  decls: 15,
  vars: 9,
  consts: [["color", "playgo"], ["slot", "end"], [3, "click"], ["name", "close-circle-outline"], ["color", "playgo", 1, "ion-padding"], [3, "innerHTML"], ["color", "playgo", 1, "ion-text-center"], ["expand", "block", "color", "light", 3, "click"]],
  template: function PrizeModalPage_Template(rf, ctx) {
    if (rf & 1) {
      _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵelementStart"](0, "ion-header")(1, "ion-toolbar", 0)(2, "ion-title");
      _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵtext"](3);
      _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵpipe"](4, "translate");
      _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵelementEnd"]();
      _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵelementStart"](5, "ion-buttons", 1)(6, "ion-button", 2);
      _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵlistener"]("click", function PrizeModalPage_Template_ion_button_click_6_listener() {
        return ctx.close();
      });
      _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵelement"](7, "ion-icon", 3);
      _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵelementEnd"]()()()();
      _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵelementStart"](8, "ion-content", 4);
      _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵelement"](9, "div", 5);
      _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵpipe"](10, "translate");
      _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵelementEnd"]();
      _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵelementStart"](11, "ion-footer", 6)(12, "ion-button", 7);
      _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵlistener"]("click", function PrizeModalPage_Template_ion_button_click_12_listener() {
        return ctx.close();
      });
      _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵtext"](13);
      _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵpipe"](14, "translate");
      _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵelementEnd"]()();
    }

    if (rf & 2) {
      _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵadvance"](3);
      _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵtextInterpolate"](_angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵpipeBind1"](4, 3, "campaigns.detail.prize.title"));
      _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵadvance"](6);
      _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵproperty"]("innerHTML", _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵpipeBind1"](10, 5, "campaigns.detail.prize.desc"), _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵsanitizeHtml"]);
      _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵadvance"](4);
      _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵtextInterpolate"](_angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵpipeBind1"](14, 7, "modal.ok"));
    }
  },
  directives: [_ionic_angular__WEBPACK_IMPORTED_MODULE_3__.IonHeader, _ionic_angular__WEBPACK_IMPORTED_MODULE_3__.IonToolbar, _ionic_angular__WEBPACK_IMPORTED_MODULE_3__.IonTitle, _ionic_angular__WEBPACK_IMPORTED_MODULE_3__.IonButtons, _ionic_angular__WEBPACK_IMPORTED_MODULE_3__.IonButton, _ionic_angular__WEBPACK_IMPORTED_MODULE_3__.IonIcon, _ionic_angular__WEBPACK_IMPORTED_MODULE_3__.IonContent, _ionic_angular__WEBPACK_IMPORTED_MODULE_3__.IonFooter],
  pipes: [_ngx_translate_core__WEBPACK_IMPORTED_MODULE_4__.TranslatePipe],
  styles: ["ion-footer[_ngcontent-%COMP%] {\n  background: var(--ion-color-playgo);\n}\n/*# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbInByaXplLm1vZGFsLnNjc3MiXSwibmFtZXMiOltdLCJtYXBwaW5ncyI6IkFBQUE7RUFDRSxtQ0FBQTtBQUNGIiwiZmlsZSI6InByaXplLm1vZGFsLnNjc3MiLCJzb3VyY2VzQ29udGVudCI6WyJpb24tZm9vdGVyIHtcbiAgYmFja2dyb3VuZDogdmFyKC0taW9uLWNvbG9yLXBsYXlnbyk7XG59XG4iXX0= */"]
});

/***/ }),

/***/ 43060:
/*!*****************************************************************************!*\
  !*** ./src/app/pages/home/campaign-details/prizes/prizes-routing.module.ts ***!
  \*****************************************************************************/
/***/ (function(__unused_webpack_module, __webpack_exports__, __webpack_require__) {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "PrizesPageRoutingModule": function() { return /* binding */ PrizesPageRoutingModule; }
/* harmony export */ });
/* harmony import */ var _Users_smartcommunitylab_Desktop_newWork_dslab_playgo_mobile_playgo_mobile_node_modules_babel_runtime_helpers_esm_createClass_js__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./node_modules/@babel/runtime/helpers/esm/createClass.js */ 48047);
/* harmony import */ var _Users_smartcommunitylab_Desktop_newWork_dslab_playgo_mobile_playgo_mobile_node_modules_babel_runtime_helpers_esm_classCallCheck_js__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ./node_modules/@babel/runtime/helpers/esm/classCallCheck.js */ 78069);
/* harmony import */ var _angular_router__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! @angular/router */ 52816);
/* harmony import */ var _prizes_page__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! ./prizes.page */ 61191);
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @angular/core */ 3184);






var routes = [{
  path: '',
  component: _prizes_page__WEBPACK_IMPORTED_MODULE_2__.PrizesPage,
  data: {
    title: 'campaigns.detail.prizes'
  }
}];
var PrizesPageRoutingModule = /*#__PURE__*/(0,_Users_smartcommunitylab_Desktop_newWork_dslab_playgo_mobile_playgo_mobile_node_modules_babel_runtime_helpers_esm_createClass_js__WEBPACK_IMPORTED_MODULE_0__["default"])(function PrizesPageRoutingModule() {
  (0,_Users_smartcommunitylab_Desktop_newWork_dslab_playgo_mobile_playgo_mobile_node_modules_babel_runtime_helpers_esm_classCallCheck_js__WEBPACK_IMPORTED_MODULE_1__["default"])(this, PrizesPageRoutingModule);
});

PrizesPageRoutingModule.ɵfac = function PrizesPageRoutingModule_Factory(t) {
  return new (t || PrizesPageRoutingModule)();
};

PrizesPageRoutingModule.ɵmod = /*@__PURE__*/_angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵdefineNgModule"]({
  type: PrizesPageRoutingModule
});
PrizesPageRoutingModule.ɵinj = /*@__PURE__*/_angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵdefineInjector"]({
  imports: [[_angular_router__WEBPACK_IMPORTED_MODULE_4__.RouterModule.forChild(routes)], _angular_router__WEBPACK_IMPORTED_MODULE_4__.RouterModule]
});

(function () {
  (typeof ngJitMode === "undefined" || ngJitMode) && _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵsetNgModuleScope"](PrizesPageRoutingModule, {
    imports: [_angular_router__WEBPACK_IMPORTED_MODULE_4__.RouterModule],
    exports: [_angular_router__WEBPACK_IMPORTED_MODULE_4__.RouterModule]
  });
})();

/***/ }),

/***/ 91775:
/*!*********************************************************************!*\
  !*** ./src/app/pages/home/campaign-details/prizes/prizes.module.ts ***!
  \*********************************************************************/
/***/ (function(__unused_webpack_module, __webpack_exports__, __webpack_require__) {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "PrizesPageModule": function() { return /* binding */ PrizesPageModule; }
/* harmony export */ });
/* harmony import */ var _Users_smartcommunitylab_Desktop_newWork_dslab_playgo_mobile_playgo_mobile_node_modules_babel_runtime_helpers_esm_createClass_js__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./node_modules/@babel/runtime/helpers/esm/createClass.js */ 48047);
/* harmony import */ var _Users_smartcommunitylab_Desktop_newWork_dslab_playgo_mobile_playgo_mobile_node_modules_babel_runtime_helpers_esm_classCallCheck_js__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ./node_modules/@babel/runtime/helpers/esm/classCallCheck.js */ 78069);
/* harmony import */ var _prizes_routing_module__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! ./prizes-routing.module */ 43060);
/* harmony import */ var _prizes_page__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! ./prizes.page */ 61191);
/* harmony import */ var src_app_core_shared_shared_module__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! src/app/core/shared/shared.module */ 97205);
/* harmony import */ var src_app_core_shared_pipes_localDate_pipe__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! src/app/core/shared/pipes/localDate.pipe */ 34489);
/* harmony import */ var _prize_modal_prize_modal__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! ./prize-modal/prize.modal */ 96989);
/* harmony import */ var _detail_modal_detail_modal__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(/*! ./detail-modal/detail.modal */ 74397);
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(/*! @angular/core */ 3184);









var PrizesPageModule = /*#__PURE__*/(0,_Users_smartcommunitylab_Desktop_newWork_dslab_playgo_mobile_playgo_mobile_node_modules_babel_runtime_helpers_esm_createClass_js__WEBPACK_IMPORTED_MODULE_0__["default"])(function PrizesPageModule() {
  (0,_Users_smartcommunitylab_Desktop_newWork_dslab_playgo_mobile_playgo_mobile_node_modules_babel_runtime_helpers_esm_classCallCheck_js__WEBPACK_IMPORTED_MODULE_1__["default"])(this, PrizesPageModule);
});

PrizesPageModule.ɵfac = function PrizesPageModule_Factory(t) {
  return new (t || PrizesPageModule)();
};

PrizesPageModule.ɵmod = /*@__PURE__*/_angular_core__WEBPACK_IMPORTED_MODULE_8__["ɵɵdefineNgModule"]({
  type: PrizesPageModule
});
PrizesPageModule.ɵinj = /*@__PURE__*/_angular_core__WEBPACK_IMPORTED_MODULE_8__["ɵɵdefineInjector"]({
  providers: [src_app_core_shared_pipes_localDate_pipe__WEBPACK_IMPORTED_MODULE_5__.LocalDatePipe],
  imports: [[src_app_core_shared_shared_module__WEBPACK_IMPORTED_MODULE_4__.PlayGoSharedModule, _prizes_routing_module__WEBPACK_IMPORTED_MODULE_2__.PrizesPageRoutingModule]]
});

(function () {
  (typeof ngJitMode === "undefined" || ngJitMode) && _angular_core__WEBPACK_IMPORTED_MODULE_8__["ɵɵsetNgModuleScope"](PrizesPageModule, {
    declarations: [_prizes_page__WEBPACK_IMPORTED_MODULE_3__.PrizesPage, _prize_modal_prize_modal__WEBPACK_IMPORTED_MODULE_6__.PrizeModalPage, _detail_modal_detail_modal__WEBPACK_IMPORTED_MODULE_7__.DetailPrizeModalPage],
    imports: [src_app_core_shared_shared_module__WEBPACK_IMPORTED_MODULE_4__.PlayGoSharedModule, _prizes_routing_module__WEBPACK_IMPORTED_MODULE_2__.PrizesPageRoutingModule]
  });
})();

/***/ }),

/***/ 61191:
/*!*******************************************************************!*\
  !*** ./src/app/pages/home/campaign-details/prizes/prizes.page.ts ***!
  \*******************************************************************/
/***/ (function(__unused_webpack_module, __webpack_exports__, __webpack_require__) {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "PrizesPage": function() { return /* binding */ PrizesPage; }
/* harmony export */ });
/* harmony import */ var _Users_smartcommunitylab_Desktop_newWork_dslab_playgo_mobile_playgo_mobile_node_modules_babel_runtime_helpers_esm_classCallCheck_js__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./node_modules/@babel/runtime/helpers/esm/classCallCheck.js */ 78069);
/* harmony import */ var _Users_smartcommunitylab_Desktop_newWork_dslab_playgo_mobile_playgo_mobile_node_modules_babel_runtime_helpers_esm_createClass_js__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ./node_modules/@babel/runtime/helpers/esm/createClass.js */ 48047);
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_16__ = __webpack_require__(/*! tslib */ 42321);
/* harmony import */ var luxon__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! luxon */ 20020);
/* harmony import */ var rxjs__WEBPACK_IMPORTED_MODULE_14__ = __webpack_require__(/*! rxjs */ 50635);
/* harmony import */ var rxjs__WEBPACK_IMPORTED_MODULE_15__ = __webpack_require__(/*! rxjs */ 89196);
/* harmony import */ var rxjs__WEBPACK_IMPORTED_MODULE_17__ = __webpack_require__(/*! rxjs */ 54363);
/* harmony import */ var _prize_modal_prize_modal__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! ./prize-modal/prize.modal */ 96989);
/* harmony import */ var _capacitor_browser__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! @capacitor/browser */ 18313);
/* harmony import */ var _detail_modal_detail_modal__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! ./detail-modal/detail.modal */ 74397);
/* harmony import */ var _ionic_angular__WEBPACK_IMPORTED_MODULE_19__ = __webpack_require__(/*! @ionic/angular */ 93819);
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_13__ = __webpack_require__(/*! @angular/core */ 3184);
/* harmony import */ var _angular_router__WEBPACK_IMPORTED_MODULE_18__ = __webpack_require__(/*! @angular/router */ 52816);
/* harmony import */ var src_app_core_shared_services_page_settings_service__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! src/app/core/shared/services/page-settings.service */ 85294);
/* harmony import */ var src_app_core_shared_services_campaign_service__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(/*! src/app/core/shared/services/campaign.service */ 23645);
/* harmony import */ var _ngx_translate_core__WEBPACK_IMPORTED_MODULE_20__ = __webpack_require__(/*! @ngx-translate/core */ 87514);
/* harmony import */ var _core_shared_layout_header_header_directive__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(/*! ../../../../core/shared/layout/header/header.directive */ 34161);
/* harmony import */ var _core_shared_layout_content_content_directive__WEBPACK_IMPORTED_MODULE_9__ = __webpack_require__(/*! ../../../../core/shared/layout/content/content.directive */ 69669);
/* harmony import */ var _angular_forms__WEBPACK_IMPORTED_MODULE_21__ = __webpack_require__(/*! @angular/forms */ 90587);
/* harmony import */ var _angular_common__WEBPACK_IMPORTED_MODULE_22__ = __webpack_require__(/*! @angular/common */ 36362);
/* harmony import */ var _core_shared_globalization_ordinal_number_ordinal_number_component__WEBPACK_IMPORTED_MODULE_10__ = __webpack_require__(/*! ../../../../core/shared/globalization/ordinal-number/ordinal-number.component */ 56032);
/* harmony import */ var _core_shared_pipes_localDate_pipe__WEBPACK_IMPORTED_MODULE_11__ = __webpack_require__(/*! ../../../../core/shared/pipes/localDate.pipe */ 34489);
/* harmony import */ var _core_shared_pipes_languageMap_pipe__WEBPACK_IMPORTED_MODULE_12__ = __webpack_require__(/*! ../../../../core/shared/pipes/languageMap.pipe */ 73088);



function _regeneratorRuntime() { "use strict"; /*! regenerator-runtime -- Copyright (c) 2014-present, Facebook, Inc. -- license (MIT): https://github.com/facebook/regenerator/blob/main/LICENSE */ _regeneratorRuntime = function _regeneratorRuntime() { return e; }; var t, e = {}, r = Object.prototype, n = r.hasOwnProperty, o = Object.defineProperty || function (t, e, r) { t[e] = r.value; }, i = "function" == typeof Symbol ? Symbol : {}, a = i.iterator || "@@iterator", c = i.asyncIterator || "@@asyncIterator", u = i.toStringTag || "@@toStringTag"; function define(t, e, r) { return Object.defineProperty(t, e, { value: r, enumerable: !0, configurable: !0, writable: !0 }), t[e]; } try { define({}, ""); } catch (t) { define = function define(t, e, r) { return t[e] = r; }; } function wrap(t, e, r, n) { var i = e && e.prototype instanceof Generator ? e : Generator, a = Object.create(i.prototype), c = new Context(n || []); return o(a, "_invoke", { value: makeInvokeMethod(t, r, c) }), a; } function tryCatch(t, e, r) { try { return { type: "normal", arg: t.call(e, r) }; } catch (t) { return { type: "throw", arg: t }; } } e.wrap = wrap; var h = "suspendedStart", l = "suspendedYield", f = "executing", s = "completed", y = {}; function Generator() {} function GeneratorFunction() {} function GeneratorFunctionPrototype() {} var p = {}; define(p, a, function () { return this; }); var d = Object.getPrototypeOf, v = d && d(d(values([]))); v && v !== r && n.call(v, a) && (p = v); var g = GeneratorFunctionPrototype.prototype = Generator.prototype = Object.create(p); function defineIteratorMethods(t) { ["next", "throw", "return"].forEach(function (e) { define(t, e, function (t) { return this._invoke(e, t); }); }); } function AsyncIterator(t, e) { function invoke(r, o, i, a) { var c = tryCatch(t[r], t, o); if ("throw" !== c.type) { var u = c.arg, h = u.value; return h && "object" == typeof h && n.call(h, "__await") ? e.resolve(h.__await).then(function (t) { invoke("next", t, i, a); }, function (t) { invoke("throw", t, i, a); }) : e.resolve(h).then(function (t) { u.value = t, i(u); }, function (t) { return invoke("throw", t, i, a); }); } a(c.arg); } var r; o(this, "_invoke", { value: function value(t, n) { function callInvokeWithMethodAndArg() { return new e(function (e, r) { invoke(t, n, e, r); }); } return r = r ? r.then(callInvokeWithMethodAndArg, callInvokeWithMethodAndArg) : callInvokeWithMethodAndArg(); } }); } function makeInvokeMethod(e, r, n) { var o = h; return function (i, a) { if (o === f) throw new Error("Generator is already running"); if (o === s) { if ("throw" === i) throw a; return { value: t, done: !0 }; } for (n.method = i, n.arg = a;;) { var c = n.delegate; if (c) { var u = maybeInvokeDelegate(c, n); if (u) { if (u === y) continue; return u; } } if ("next" === n.method) n.sent = n._sent = n.arg;else if ("throw" === n.method) { if (o === h) throw o = s, n.arg; n.dispatchException(n.arg); } else "return" === n.method && n.abrupt("return", n.arg); o = f; var p = tryCatch(e, r, n); if ("normal" === p.type) { if (o = n.done ? s : l, p.arg === y) continue; return { value: p.arg, done: n.done }; } "throw" === p.type && (o = s, n.method = "throw", n.arg = p.arg); } }; } function maybeInvokeDelegate(e, r) { var n = r.method, o = e.iterator[n]; if (o === t) return r.delegate = null, "throw" === n && e.iterator.return && (r.method = "return", r.arg = t, maybeInvokeDelegate(e, r), "throw" === r.method) || "return" !== n && (r.method = "throw", r.arg = new TypeError("The iterator does not provide a '" + n + "' method")), y; var i = tryCatch(o, e.iterator, r.arg); if ("throw" === i.type) return r.method = "throw", r.arg = i.arg, r.delegate = null, y; var a = i.arg; return a ? a.done ? (r[e.resultName] = a.value, r.next = e.nextLoc, "return" !== r.method && (r.method = "next", r.arg = t), r.delegate = null, y) : a : (r.method = "throw", r.arg = new TypeError("iterator result is not an object"), r.delegate = null, y); } function pushTryEntry(t) { var e = { tryLoc: t[0] }; 1 in t && (e.catchLoc = t[1]), 2 in t && (e.finallyLoc = t[2], e.afterLoc = t[3]), this.tryEntries.push(e); } function resetTryEntry(t) { var e = t.completion || {}; e.type = "normal", delete e.arg, t.completion = e; } function Context(t) { this.tryEntries = [{ tryLoc: "root" }], t.forEach(pushTryEntry, this), this.reset(!0); } function values(e) { if (e || "" === e) { var r = e[a]; if (r) return r.call(e); if ("function" == typeof e.next) return e; if (!isNaN(e.length)) { var o = -1, i = function next() { for (; ++o < e.length;) if (n.call(e, o)) return next.value = e[o], next.done = !1, next; return next.value = t, next.done = !0, next; }; return i.next = i; } } throw new TypeError(typeof e + " is not iterable"); } return GeneratorFunction.prototype = GeneratorFunctionPrototype, o(g, "constructor", { value: GeneratorFunctionPrototype, configurable: !0 }), o(GeneratorFunctionPrototype, "constructor", { value: GeneratorFunction, configurable: !0 }), GeneratorFunction.displayName = define(GeneratorFunctionPrototype, u, "GeneratorFunction"), e.isGeneratorFunction = function (t) { var e = "function" == typeof t && t.constructor; return !!e && (e === GeneratorFunction || "GeneratorFunction" === (e.displayName || e.name)); }, e.mark = function (t) { return Object.setPrototypeOf ? Object.setPrototypeOf(t, GeneratorFunctionPrototype) : (t.__proto__ = GeneratorFunctionPrototype, define(t, u, "GeneratorFunction")), t.prototype = Object.create(g), t; }, e.awrap = function (t) { return { __await: t }; }, defineIteratorMethods(AsyncIterator.prototype), define(AsyncIterator.prototype, c, function () { return this; }), e.AsyncIterator = AsyncIterator, e.async = function (t, r, n, o, i) { void 0 === i && (i = Promise); var a = new AsyncIterator(wrap(t, r, n, o), i); return e.isGeneratorFunction(r) ? a : a.next().then(function (t) { return t.done ? t.value : a.next(); }); }, defineIteratorMethods(g), define(g, u, "Generator"), define(g, a, function () { return this; }), define(g, "toString", function () { return "[object Generator]"; }), e.keys = function (t) { var e = Object(t), r = []; for (var n in e) r.push(n); return r.reverse(), function next() { for (; r.length;) { var t = r.pop(); if (t in e) return next.value = t, next.done = !1, next; } return next.done = !0, next; }; }, e.values = values, Context.prototype = { constructor: Context, reset: function reset(e) { if (this.prev = 0, this.next = 0, this.sent = this._sent = t, this.done = !1, this.delegate = null, this.method = "next", this.arg = t, this.tryEntries.forEach(resetTryEntry), !e) for (var r in this) "t" === r.charAt(0) && n.call(this, r) && !isNaN(+r.slice(1)) && (this[r] = t); }, stop: function stop() { this.done = !0; var t = this.tryEntries[0].completion; if ("throw" === t.type) throw t.arg; return this.rval; }, dispatchException: function dispatchException(e) { if (this.done) throw e; var r = this; function handle(n, o) { return a.type = "throw", a.arg = e, r.next = n, o && (r.method = "next", r.arg = t), !!o; } for (var o = this.tryEntries.length - 1; o >= 0; --o) { var i = this.tryEntries[o], a = i.completion; if ("root" === i.tryLoc) return handle("end"); if (i.tryLoc <= this.prev) { var c = n.call(i, "catchLoc"), u = n.call(i, "finallyLoc"); if (c && u) { if (this.prev < i.catchLoc) return handle(i.catchLoc, !0); if (this.prev < i.finallyLoc) return handle(i.finallyLoc); } else if (c) { if (this.prev < i.catchLoc) return handle(i.catchLoc, !0); } else { if (!u) throw new Error("try statement without catch or finally"); if (this.prev < i.finallyLoc) return handle(i.finallyLoc); } } } }, abrupt: function abrupt(t, e) { for (var r = this.tryEntries.length - 1; r >= 0; --r) { var o = this.tryEntries[r]; if (o.tryLoc <= this.prev && n.call(o, "finallyLoc") && this.prev < o.finallyLoc) { var i = o; break; } } i && ("break" === t || "continue" === t) && i.tryLoc <= e && e <= i.finallyLoc && (i = null); var a = i ? i.completion : {}; return a.type = t, a.arg = e, i ? (this.method = "next", this.next = i.finallyLoc, y) : this.complete(a); }, complete: function complete(t, e) { if ("throw" === t.type) throw t.arg; return "break" === t.type || "continue" === t.type ? this.next = t.arg : "return" === t.type ? (this.rval = this.arg = t.arg, this.method = "return", this.next = "end") : "normal" === t.type && e && (this.next = e), y; }, finish: function finish(t) { for (var e = this.tryEntries.length - 1; e >= 0; --e) { var r = this.tryEntries[e]; if (r.finallyLoc === t) return this.complete(r.completion, r.afterLoc), resetTryEntry(r), y; } }, catch: function _catch(t) { for (var e = this.tryEntries.length - 1; e >= 0; --e) { var r = this.tryEntries[e]; if (r.tryLoc === t) { var n = r.completion; if ("throw" === n.type) { var o = n.arg; resetTryEntry(r); } return o; } } throw new Error("illegal catch attempt"); }, delegateYield: function delegateYield(e, r, n) { return this.delegate = { iterator: values(e), resultName: r, nextLoc: n }, "next" === this.method && (this.arg = t), y; } }, e; }






















function PrizesPage_div_11_ng_container_1_ng_container_13_ion_card_1_ng_container_5_Template(rf, ctx) {
  if (rf & 1) {
    _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵelementContainerStart"](0);
    _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵtext"](1);
    _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵpipe"](2, "languageMap");
    _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵelementContainerEnd"]();
  }

  if (rf & 2) {
    var reward_r11 = _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵnextContext"]().$implicit;
    _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵadvance"](1);
    _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵtextInterpolate1"](" ", _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵpipeBind1"](2, 1, reward_r11.label), " ");
  }
}

function PrizesPage_div_11_ng_container_1_ng_container_13_ion_card_1_ng_template_7_Template(rf, ctx) {
  if (rf & 1) {
    _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵelement"](0, "app-ordinal-number", 18);
  }

  if (rf & 2) {
    var i_r12 = _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵnextContext"]().index;
    _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵproperty"]("value", i_r12 + 1);
  }
}

function PrizesPage_div_11_ng_container_1_ng_container_13_ion_card_1_ion_grid_13_ion_row_6_div_6_Template(rf, ctx) {
  if (rf & 1) {
    _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵelementStart"](0, "div", 20)(1, "b");
    _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵtext"](2);
    _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵelementEnd"]()();
  }

  if (rf & 2) {
    var reward_r11 = _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵnextContext"](3).$implicit;
    _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵadvance"](2);
    _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵtextInterpolate"](reward_r11.sponsor);
  }
}

function PrizesPage_div_11_ng_container_1_ng_container_13_ion_card_1_ion_grid_13_ion_row_6_div_7_Template(rf, ctx) {
  if (rf & 1) {
    _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵelement"](0, "div", 27);
    _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵpipe"](1, "languageMap");
  }

  if (rf & 2) {
    var reward_r11 = _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵnextContext"](3).$implicit;
    _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵproperty"]("innerHTML", _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵpipeBind1"](1, 1, reward_r11.sponsorDesc), _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵsanitizeHtml"]);
  }
}

function PrizesPage_div_11_ng_container_1_ng_container_13_ion_card_1_ion_grid_13_ion_row_6_div_8_Template(rf, ctx) {
  if (rf & 1) {
    var _r27 = _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵgetCurrentView"]();

    _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵelementStart"](0, "div", 28);
    _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵlistener"]("click", function PrizesPage_div_11_ng_container_1_ng_container_13_ion_card_1_ion_grid_13_ion_row_6_div_8_Template_div_click_0_listener() {
      _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵrestoreView"](_r27);
      var reward_r11 = _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵnextContext"](3).$implicit;
      var ctx_r25 = _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵnextContext"](4);
      return ctx_r25.openLink(reward_r11.sponsorWebsite);
    });
    _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵtext"](1);
    _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵpipe"](2, "translate");
    _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵelementEnd"]();
  }

  if (rf & 2) {
    _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵadvance"](1);
    _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵtextInterpolate1"](" ", _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵpipeBind1"](2, 1, "campaigns.detail.prize.website"), "");
  }
}

function PrizesPage_div_11_ng_container_1_ng_container_13_ion_card_1_ion_grid_13_ion_row_6_Template(rf, ctx) {
  if (rf & 1) {
    _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵelementStart"](0, "ion-row", 22)(1, "ion-col")(2, "div", 23);
    _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵtext"](3);
    _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵpipe"](4, "uppercase");
    _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵpipe"](5, "translate");
    _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵelementEnd"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵtemplate"](6, PrizesPage_div_11_ng_container_1_ng_container_13_ion_card_1_ion_grid_13_ion_row_6_div_6_Template, 3, 1, "div", 24);
    _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵtemplate"](7, PrizesPage_div_11_ng_container_1_ng_container_13_ion_card_1_ion_grid_13_ion_row_6_div_7_Template, 2, 3, "div", 25);
    _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵtemplate"](8, PrizesPage_div_11_ng_container_1_ng_container_13_ion_card_1_ion_grid_13_ion_row_6_div_8_Template, 3, 3, "div", 26);
    _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵelementEnd"]()();
  }

  if (rf & 2) {
    var reward_r11 = _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵnextContext"](2).$implicit;
    _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵadvance"](3);
    _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵtextInterpolate1"]("", _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵpipeBind1"](4, 4, _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵpipeBind1"](5, 6, "campaigns.detail.prize.sponsorBy")), " ");
    _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵadvance"](3);
    _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵproperty"]("ngIf", reward_r11.sponsor);
    _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵadvance"](1);
    _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵproperty"]("ngIf", reward_r11.sponsorDesc);
    _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵadvance"](1);
    _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵproperty"]("ngIf", reward_r11.sponsorWebsite);
  }
}

function PrizesPage_div_11_ng_container_1_ng_container_13_ion_card_1_ion_grid_13_Template(rf, ctx) {
  if (rf & 1) {
    _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵelementStart"](0, "ion-grid")(1, "ion-row", 19)(2, "ion-col", 20)(3, "b");
    _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵtext"](4);
    _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵpipe"](5, "languageMap");
    _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵelementEnd"]()()();
    _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵtemplate"](6, PrizesPage_div_11_ng_container_1_ng_container_13_ion_card_1_ion_grid_13_ion_row_6_Template, 9, 8, "ion-row", 21);
    _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵpipe"](7, "languageMap");
    _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵelementEnd"]();
  }

  if (rf & 2) {
    var reward_r11 = _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵnextContext"]().$implicit;
    _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵadvance"](4);
    _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵtextInterpolate"](_angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵpipeBind1"](5, 2, reward_r11.desc));
    _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵadvance"](2);
    _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵproperty"]("ngIf", _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵpipeBind1"](7, 4, reward_r11.sponsorDesc) || reward_r11.sponsor || reward_r11.sponsorWebsite);
  }
}

function PrizesPage_div_11_ng_container_1_ng_container_13_ion_card_1_Template(rf, ctx) {
  if (rf & 1) {
    var _r31 = _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵgetCurrentView"]();

    _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵelementStart"](0, "ion-card")(1, "ion-card-header", 12)(2, "ion-card-title")(3, "span");
    _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵelement"](4, "ion-icon", 13);
    _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵtemplate"](5, PrizesPage_div_11_ng_container_1_ng_container_13_ion_card_1_ng_container_5_Template, 3, 3, "ng-container", 6);
    _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵpipe"](6, "languageMap");
    _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵtemplate"](7, PrizesPage_div_11_ng_container_1_ng_container_13_ion_card_1_ng_template_7_Template, 1, 1, "ng-template", null, 14, _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵtemplateRefExtractor"]);
    _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵelementEnd"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵelementStart"](9, "ion-icon", 15);
    _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵlistener"]("click", function PrizesPage_div_11_ng_container_1_ng_container_13_ion_card_1_Template_ion_icon_click_9_listener() {
      var restoredCtx = _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵrestoreView"](_r31);
      var i_r12 = restoredCtx.index;
      var ctx_r30 = _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵnextContext"](4);
      return ctx_r30.openRewardDescActual(ctx_r30.actualPrize, i_r12);
    });
    _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵelementEnd"]()()();
    _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵelementStart"](10, "ion-card-content")(11, "div", 16)(12, "div", 17);
    _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵtemplate"](13, PrizesPage_div_11_ng_container_1_ng_container_13_ion_card_1_ion_grid_13_Template, 8, 6, "ion-grid", 5);
    _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵelementEnd"]()()()();
  }

  if (rf & 2) {
    var reward_r11 = ctx.$implicit;

    var _r14 = _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵreference"](8);

    var ctx_r10 = _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵnextContext"](4);
    _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵadvance"](1);
    _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵproperty"]("ngClass", ctx_r10.getPostion(reward_r11.position - 1));
    _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵadvance"](4);
    _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵproperty"]("ngIf", _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵpipeBind1"](6, 4, reward_r11.label))("ngIfElse", _r14);
    _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵadvance"](8);
    _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵproperty"]("ngIf", reward_r11.desc);
  }
}

function PrizesPage_div_11_ng_container_1_ng_container_13_Template(rf, ctx) {
  if (rf & 1) {
    _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵelementContainerStart"](0);
    _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵtemplate"](1, PrizesPage_div_11_ng_container_1_ng_container_13_ion_card_1_Template, 14, 6, "ion-card", 11);
    _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵelementContainerEnd"]();
  }

  if (rf & 2) {
    var ctx_r8 = _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵnextContext"](3);
    _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵadvance"](1);
    _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵproperty"]("ngForOf", ctx_r8.actualPrize.rewards);
  }
}

function PrizesPage_div_11_ng_container_1_ng_container_14_ion_button_1_Template(rf, ctx) {
  if (rf & 1) {
    var _r34 = _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵgetCurrentView"]();

    _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵelementStart"](0, "ion-button", 30);
    _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵlistener"]("click", function PrizesPage_div_11_ng_container_1_ng_container_14_ion_button_1_Template_ion_button_click_0_listener() {
      _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵrestoreView"](_r34);
      var ctx_r33 = _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵnextContext"](4);
      return ctx_r33.expandPrizes();
    });
    _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵtext"](1);
    _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵpipe"](2, "translate");
    _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵelementEnd"]();
  }

  if (rf & 2) {
    var ctx_r32 = _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵnextContext"](4);
    _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵproperty"]("color", ctx_r32.campaignContainer == null ? null : ctx_r32.campaignContainer.campaign == null ? null : ctx_r32.campaignContainer.campaign.type);
    _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵadvance"](1);
    _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵtextInterpolate"](_angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵpipeBind1"](2, 2, "campaigns.detail.prize.expand"));
  }
}

function PrizesPage_div_11_ng_container_1_ng_container_14_Template(rf, ctx) {
  if (rf & 1) {
    _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵelementContainerStart"](0);
    _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵtemplate"](1, PrizesPage_div_11_ng_container_1_ng_container_14_ion_button_1_Template, 3, 4, "ion-button", 29);
    _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵelementContainerEnd"]();
  }

  if (rf & 2) {
    _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵnextContext"](2);

    var _r5 = _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵreference"](5);

    var ctx_r9 = _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵnextContext"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵadvance"](1);
    _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵproperty"]("ngIf", ctx_r9.notExpanded)("ngIfElse", _r5);
  }
}

function PrizesPage_div_11_ng_container_1_Template(rf, ctx) {
  if (rf & 1) {
    var _r36 = _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵgetCurrentView"]();

    _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵelementContainerStart"](0);
    _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵelementStart"](1, "div", 9)(2, "p")(3, "b");
    _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵtext"](4);
    _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵpipe"](5, "translate");
    _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵelementEnd"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵelementStart"](6, "ion-icon", 10);
    _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵlistener"]("click", function PrizesPage_div_11_ng_container_1_Template_ion_icon_click_6_listener() {
      _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵrestoreView"](_r36);
      var ctx_r35 = _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵnextContext"](2);
      return ctx_r35.openWeekDescActual(ctx_r35.actualPrize);
    });
    _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵelementEnd"]()();
    _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵelementStart"](7, "p");
    _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵtext"](8);
    _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵpipe"](9, "translate");
    _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵpipe"](10, "localDate");
    _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵpipe"](11, "translate");
    _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵpipe"](12, "localDate");
    _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵelementEnd"]()();
    _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵtemplate"](13, PrizesPage_div_11_ng_container_1_ng_container_13_Template, 2, 1, "ng-container", 6);
    _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵtemplate"](14, PrizesPage_div_11_ng_container_1_ng_container_14_Template, 2, 2, "ng-container", 5);
    _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵelementContainerEnd"]();
  }

  if (rf & 2) {
    _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵnextContext"]();

    var _r3 = _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵreference"](3);

    var ctx_r2 = _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵnextContext"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵadvance"](4);
    _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵtextInterpolate"](_angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵpipeBind1"](5, 8, "campaigns.detail.prize.prizeactual"));
    _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵadvance"](4);
    _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵtextInterpolate4"]("", _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵpipeBind1"](9, 10, "campaigns.detail.from"), "", _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵpipeBind2"](10, 12, ctx_r2.actualPrize.dateFrom, "d MMMM "), " \xA0", _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵpipeBind1"](11, 15, "campaigns.detail.to"), "", _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵpipeBind2"](12, 17, ctx_r2.actualPrize.dateTo, " d MMMM y"), "");
    _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵadvance"](5);
    _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵproperty"]("ngIf", ctx_r2.prizePresent)("ngIfElse", _r3);
    _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵadvance"](1);
    _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵproperty"]("ngIf", ctx_r2.pastprizes());
  }
}

function PrizesPage_div_11_ng_template_2_Template(rf, ctx) {
  if (rf & 1) {
    _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵelementStart"](0, "div", 31);
    _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵtext"](1);
    _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵpipe"](2, "translate");
    _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵelementEnd"]();
  }

  if (rf & 2) {
    _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵadvance"](1);
    _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵtextInterpolate"](_angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵpipeBind1"](2, 1, "campaigns.detail.prize.noActual"));
  }
}

function PrizesPage_div_11_ng_template_4_Template(rf, ctx) {
  if (rf & 1) {
    _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵelementStart"](0, "div", 32)(1, "p")(2, "b");
    _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵtext"](3);
    _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵpipe"](4, "translate");
    _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵelementEnd"]()()();
  }

  if (rf & 2) {
    _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵadvance"](3);
    _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵtextInterpolate"](_angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵpipeBind1"](4, 1, "campaigns.detail.prize.expanded"));
  }
}

function PrizesPage_div_11_ng_container_6_ng_container_1_ion_card_1_span_9_Template(rf, ctx) {
  if (rf & 1) {
    _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵelementStart"](0, "span", 35);
    _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵtext"](1);
    _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵpipe"](2, "translate");
    _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵelementEnd"]();
  }

  if (rf & 2) {
    _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵadvance"](1);
    _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵtextInterpolate"](_angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵpipeBind1"](2, 1, "campaigns.detail.current"));
  }
}

function PrizesPage_div_11_ng_container_6_ng_container_1_ion_card_1_ion_accordion_13_div_12_div_6_Template(rf, ctx) {
  if (rf & 1) {
    _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵelementStart"](0, "div", 20)(1, "b");
    _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵtext"](2);
    _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵelementEnd"]()();
  }

  if (rf & 2) {
    var reward_r43 = _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵnextContext"](2).$implicit;
    _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵadvance"](2);
    _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵtextInterpolate"](reward_r43.sponsor);
  }
}

function PrizesPage_div_11_ng_container_6_ng_container_1_ion_card_1_ion_accordion_13_div_12_div_7_Template(rf, ctx) {
  if (rf & 1) {
    _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵelement"](0, "div", 27);
    _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵpipe"](1, "languageMap");
  }

  if (rf & 2) {
    var reward_r43 = _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵnextContext"](2).$implicit;
    _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵproperty"]("innerHTML", _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵpipeBind1"](1, 1, reward_r43.sponsorDesc), _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵsanitizeHtml"]);
  }
}

function PrizesPage_div_11_ng_container_6_ng_container_1_ion_card_1_ion_accordion_13_div_12_div_8_Template(rf, ctx) {
  if (rf & 1) {
    var _r52 = _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵgetCurrentView"]();

    _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵelementStart"](0, "div", 28);
    _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵlistener"]("click", function PrizesPage_div_11_ng_container_6_ng_container_1_ion_card_1_ion_accordion_13_div_12_div_8_Template_div_click_0_listener() {
      _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵrestoreView"](_r52);
      var reward_r43 = _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵnextContext"](2).$implicit;
      var ctx_r50 = _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵnextContext"](5);
      return ctx_r50.openLink(reward_r43.sponsorWebsite);
    });
    _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵtext"](1);
    _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵpipe"](2, "translate");
    _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵelementEnd"]();
  }

  if (rf & 2) {
    _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵadvance"](1);
    _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵtextInterpolate1"](" ", _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵpipeBind1"](2, 1, "campaigns.detail.prize.website"), "");
  }
}

function PrizesPage_div_11_ng_container_6_ng_container_1_ion_card_1_ion_accordion_13_div_12_Template(rf, ctx) {
  if (rf & 1) {
    _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵelementStart"](0, "div", 43)(1, "div", 44)(2, "div", 23);
    _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵtext"](3);
    _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵpipe"](4, "uppercase");
    _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵpipe"](5, "translate");
    _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵelementEnd"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵtemplate"](6, PrizesPage_div_11_ng_container_6_ng_container_1_ion_card_1_ion_accordion_13_div_12_div_6_Template, 3, 1, "div", 24);
    _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵtemplate"](7, PrizesPage_div_11_ng_container_6_ng_container_1_ion_card_1_ion_accordion_13_div_12_div_7_Template, 2, 3, "div", 25);
    _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵtemplate"](8, PrizesPage_div_11_ng_container_6_ng_container_1_ion_card_1_ion_accordion_13_div_12_div_8_Template, 3, 3, "div", 26);
    _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵelementEnd"]()();
  }

  if (rf & 2) {
    var reward_r43 = _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵnextContext"]().$implicit;
    _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵadvance"](3);
    _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵtextInterpolate1"]("", _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵpipeBind1"](4, 4, _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵpipeBind1"](5, 6, "campaigns.detail.prize.sponsorBy")), " ");
    _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵadvance"](3);
    _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵproperty"]("ngIf", reward_r43.sponsor);
    _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵadvance"](1);
    _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵproperty"]("ngIf", reward_r43.sponsorDesc);
    _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵadvance"](1);
    _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵproperty"]("ngIf", reward_r43.sponsorWebsite);
  }
}

function PrizesPage_div_11_ng_container_6_ng_container_1_ion_card_1_ion_accordion_13_Template(rf, ctx) {
  if (rf & 1) {
    _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵelementStart"](0, "ion-accordion")(1, "ion-item", 36)(2, "div", 37)(3, "ion-grid")(4, "ion-row")(5, "ion-col", 38);
    _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵelement"](6, "ion-icon", 39)(7, "app-ordinal-number", 40);
    _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵelementEnd"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵelementStart"](8, "ion-col")(9, "span", 41);
    _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵtext"](10);
    _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵpipe"](11, "languageMap");
    _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵelementEnd"]()()()()()();
    _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵtemplate"](12, PrizesPage_div_11_ng_container_6_ng_container_1_ion_card_1_ion_accordion_13_div_12_Template, 9, 8, "div", 42);
    _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵpipe"](13, "languageMap");
    _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵelementEnd"]();
  }

  if (rf & 2) {
    var reward_r43 = ctx.$implicit;
    var ctx_r42 = _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵnextContext"](5);
    _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵadvance"](6);
    _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵproperty"]("ngClass", "packet-" + ctx_r42.getPostion((reward_r43 == null ? null : reward_r43.position) - 1));
    _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵadvance"](1);
    _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵproperty"]("value", reward_r43 == null ? null : reward_r43.position)("ngClass", "packet-" + ctx_r42.getPostion((reward_r43 == null ? null : reward_r43.position) - 1));
    _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵadvance"](3);
    _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵtextInterpolate"](_angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵpipeBind1"](11, 5, reward_r43.desc));
    _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵadvance"](2);
    _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵproperty"]("ngIf", _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵpipeBind1"](13, 7, reward_r43.sponsorDesc) || reward_r43.sponsor || reward_r43.sponsorWebsite);
  }
}

function PrizesPage_div_11_ng_container_6_ng_container_1_ion_card_1_Template(rf, ctx) {
  if (rf & 1) {
    var _r56 = _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵgetCurrentView"]();

    _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵelementStart"](0, "ion-card")(1, "ion-card-header")(2, "ion-card-title")(3, "span", 33);
    _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵtext"](4);
    _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵpipe"](5, "translate");
    _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵpipe"](6, "localDate");
    _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵpipe"](7, "translate");
    _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵpipe"](8, "localDate");
    _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵelementEnd"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵtemplate"](9, PrizesPage_div_11_ng_container_6_ng_container_1_ion_card_1_span_9_Template, 3, 3, "span", 34);
    _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵelementStart"](10, "ion-icon", 15);
    _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵlistener"]("click", function PrizesPage_div_11_ng_container_6_ng_container_1_ion_card_1_Template_ion_icon_click_10_listener() {
      _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵrestoreView"](_r56);
      var conf_r38 = _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵnextContext"]().$implicit;
      var ctx_r54 = _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵnextContext"](3);
      return ctx_r54.openWeekDescPast(conf_r38);
    });
    _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵelementEnd"]()()();
    _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵelementStart"](11, "ion-card-content", 16)(12, "ion-accordion-group");
    _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵtemplate"](13, PrizesPage_div_11_ng_container_6_ng_container_1_ion_card_1_ion_accordion_13_Template, 14, 9, "ion-accordion", 11);
    _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵelementEnd"]()()();
  }

  if (rf & 2) {
    var conf_r38 = _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵnextContext"]().$implicit;
    var ctx_r40 = _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵnextContext"](3);
    _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵadvance"](1);
    _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵstyleProp"]("--background", "var(--ion-color-" + ctx_r40.campaignContainer.campaign.type + ")");
    _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵadvance"](3);
    _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵtextInterpolate4"]("", _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵpipeBind1"](5, 8, "campaigns.detail.from"), "", _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵpipeBind1"](6, 10, conf_r38.dateFrom), " ", _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵpipeBind1"](7, 12, "campaigns.detail.to"), " ", _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵpipeBind1"](8, 14, conf_r38.dateTo), "");
    _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵadvance"](5);
    _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵproperty"]("ngIf", ctx_r40.isThisPeriod(conf_r38 == null ? null : conf_r38.dateFrom, conf_r38 == null ? null : conf_r38.dateTo));
    _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵadvance"](4);
    _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵproperty"]("ngForOf", conf_r38.rewards);
  }
}

function PrizesPage_div_11_ng_container_6_ng_container_1_Template(rf, ctx) {
  if (rf & 1) {
    _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵelementContainerStart"](0);
    _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵtemplate"](1, PrizesPage_div_11_ng_container_6_ng_container_1_ion_card_1_Template, 14, 16, "ion-card", 5);
    _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵelementContainerEnd"]();
  }

  if (rf & 2) {
    var conf_r38 = ctx.$implicit;
    var ctx_r37 = _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵnextContext"](3);
    _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵadvance"](1);
    _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵproperty"]("ngIf", (conf_r38 == null ? null : conf_r38.rewards == null ? null : conf_r38.rewards.length) > 0 && (conf_r38 == null ? null : conf_r38.dateFrom) && (conf_r38 == null ? null : conf_r38.dateTo) && ctx_r37.isBeforeNow(conf_r38));
  }
}

function PrizesPage_div_11_ng_container_6_Template(rf, ctx) {
  if (rf & 1) {
    _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵelementContainerStart"](0);
    _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵtemplate"](1, PrizesPage_div_11_ng_container_6_ng_container_1_Template, 2, 1, "ng-container", 11);
    _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵelementContainerEnd"]();
  }

  if (rf & 2) {
    var ctx_r7 = _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵnextContext"](2);
    _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵadvance"](1);
    _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵproperty"]("ngForOf", ctx_r7.campaignContainer == null ? null : ctx_r7.campaignContainer.campaign == null ? null : ctx_r7.campaignContainer.campaign.weekConfs);
  }
}

function PrizesPage_div_11_Template(rf, ctx) {
  if (rf & 1) {
    _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵelementStart"](0, "div");
    _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵtemplate"](1, PrizesPage_div_11_ng_container_1_Template, 15, 20, "ng-container", 6);
    _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵtemplate"](2, PrizesPage_div_11_ng_template_2_Template, 3, 3, "ng-template", null, 7, _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵtemplateRefExtractor"]);
    _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵtemplate"](4, PrizesPage_div_11_ng_template_4_Template, 5, 3, "ng-template", null, 8, _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵtemplateRefExtractor"]);
    _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵtemplate"](6, PrizesPage_div_11_ng_container_6_Template, 2, 1, "ng-container", 5);
    _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵelementEnd"]();
  }

  if (rf & 2) {
    var _r3 = _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵreference"](3);

    var ctx_r0 = _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵnextContext"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵadvance"](1);
    _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵproperty"]("ngIf", ctx_r0.pastprizes() || ctx_r0.prizePresent)("ngIfElse", _r3);
    _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵadvance"](5);
    _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵproperty"]("ngIf", !ctx_r0.notExpanded);
  }
}

function PrizesPage_div_12_ng_container_1_ion_card_6_ng_container_5_Template(rf, ctx) {
  if (rf & 1) {
    _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵelementContainerStart"](0);
    _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵelementStart"](1, "b");
    _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵtext"](2);
    _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵpipe"](3, "languageMap");
    _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵelementEnd"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵelementContainerEnd"]();
  }

  if (rf & 2) {
    var reward_r63 = _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵnextContext"]().$implicit;
    _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵadvance"](2);
    _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵtextInterpolate"](_angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵpipeBind1"](3, 1, reward_r63.label));
  }
}

function PrizesPage_div_12_ng_container_1_ion_card_6_ng_template_7_Template(rf, ctx) {
  if (rf & 1) {
    _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵelementStart"](0, "b");
    _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵelement"](1, "app-ordinal-number", 18);
    _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵelementEnd"]();
  }

  if (rf & 2) {
    var i_r64 = _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵnextContext"]().index;
    _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵadvance"](1);
    _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵproperty"]("value", i_r64 + 1);
  }
}

function PrizesPage_div_12_ng_container_1_ion_card_6_ion_grid_13_ion_row_5_div_6_Template(rf, ctx) {
  if (rf & 1) {
    _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵelementStart"](0, "div", 20)(1, "b");
    _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵtext"](2);
    _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵelementEnd"]()();
  }

  if (rf & 2) {
    var reward_r63 = _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵnextContext"](3).$implicit;
    _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵadvance"](2);
    _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵtextInterpolate"](reward_r63.sponsor);
  }
}

function PrizesPage_div_12_ng_container_1_ion_card_6_ion_grid_13_ion_row_5_div_7_Template(rf, ctx) {
  if (rf & 1) {
    _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵelement"](0, "div", 27);
    _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵpipe"](1, "languageMap");
  }

  if (rf & 2) {
    var reward_r63 = _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵnextContext"](3).$implicit;
    _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵproperty"]("innerHTML", _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵpipeBind1"](1, 1, reward_r63.sponsorDesc), _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵsanitizeHtml"]);
  }
}

function PrizesPage_div_12_ng_container_1_ion_card_6_ion_grid_13_ion_row_5_div_8_Template(rf, ctx) {
  if (rf & 1) {
    var _r79 = _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵgetCurrentView"]();

    _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵelementStart"](0, "div", 28);
    _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵlistener"]("click", function PrizesPage_div_12_ng_container_1_ion_card_6_ion_grid_13_ion_row_5_div_8_Template_div_click_0_listener() {
      _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵrestoreView"](_r79);
      var reward_r63 = _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵnextContext"](3).$implicit;
      var ctx_r77 = _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵnextContext"](3);
      return ctx_r77.openLink(reward_r63.sponsorWebsite);
    });
    _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵtext"](1);
    _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵpipe"](2, "translate");
    _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵelementEnd"]();
  }

  if (rf & 2) {
    _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵadvance"](1);
    _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵtextInterpolate1"](" ", _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵpipeBind1"](2, 1, "campaigns.detail.prize.website"), "");
  }
}

function PrizesPage_div_12_ng_container_1_ion_card_6_ion_grid_13_ion_row_5_Template(rf, ctx) {
  if (rf & 1) {
    _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵelementStart"](0, "ion-row", 22)(1, "ion-col")(2, "div", 23);
    _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵtext"](3);
    _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵpipe"](4, "uppercase");
    _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵpipe"](5, "translate");
    _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵelementEnd"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵtemplate"](6, PrizesPage_div_12_ng_container_1_ion_card_6_ion_grid_13_ion_row_5_div_6_Template, 3, 1, "div", 24);
    _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵtemplate"](7, PrizesPage_div_12_ng_container_1_ion_card_6_ion_grid_13_ion_row_5_div_7_Template, 2, 3, "div", 25);
    _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵtemplate"](8, PrizesPage_div_12_ng_container_1_ion_card_6_ion_grid_13_ion_row_5_div_8_Template, 3, 3, "div", 26);
    _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵelementEnd"]()();
  }

  if (rf & 2) {
    var reward_r63 = _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵnextContext"](2).$implicit;
    _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵadvance"](3);
    _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵtextInterpolate1"]("", _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵpipeBind1"](4, 4, _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵpipeBind1"](5, 6, "campaigns.detail.prize.sponsorBy")), " ");
    _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵadvance"](3);
    _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵproperty"]("ngIf", reward_r63.sponsor);
    _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵadvance"](1);
    _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵproperty"]("ngIf", reward_r63.sponsorDesc);
    _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵadvance"](1);
    _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵproperty"]("ngIf", reward_r63.sponsorWebsite);
  }
}

function PrizesPage_div_12_ng_container_1_ion_card_6_ion_grid_13_Template(rf, ctx) {
  if (rf & 1) {
    _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵelementStart"](0, "ion-grid")(1, "ion-row", 19)(2, "ion-col", 20);
    _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵtext"](3);
    _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵpipe"](4, "languageMap");
    _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵelementEnd"]()();
    _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵtemplate"](5, PrizesPage_div_12_ng_container_1_ion_card_6_ion_grid_13_ion_row_5_Template, 9, 8, "ion-row", 21);
    _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵpipe"](6, "languageMap");
    _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵelementEnd"]();
  }

  if (rf & 2) {
    var reward_r63 = _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵnextContext"]().$implicit;
    _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵadvance"](3);
    _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵtextInterpolate1"]("", _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵpipeBind1"](4, 2, reward_r63.desc), " ");
    _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵadvance"](2);
    _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵproperty"]("ngIf", _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵpipeBind1"](6, 4, reward_r63.sponsorDesc) || reward_r63.sponsor || reward_r63.sponsorWebsite);
  }
}

function PrizesPage_div_12_ng_container_1_ion_card_6_Template(rf, ctx) {
  if (rf & 1) {
    var _r84 = _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵgetCurrentView"]();

    _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵelementStart"](0, "ion-card")(1, "ion-card-header", 12)(2, "ion-card-title")(3, "span");
    _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵelement"](4, "ion-icon", 13);
    _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵtemplate"](5, PrizesPage_div_12_ng_container_1_ion_card_6_ng_container_5_Template, 4, 3, "ng-container", 6);
    _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵpipe"](6, "languageMap");
    _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵtemplate"](7, PrizesPage_div_12_ng_container_1_ion_card_6_ng_template_7_Template, 2, 1, "ng-template", null, 14, _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵtemplateRefExtractor"]);
    _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵelementEnd"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵelementStart"](9, "ion-icon", 15);
    _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵlistener"]("click", function PrizesPage_div_12_ng_container_1_ion_card_6_Template_ion_icon_click_9_listener() {
      var restoredCtx = _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵrestoreView"](_r84);
      var i_r64 = restoredCtx.index;
      var finalPrize_r61 = _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵnextContext"]().ngIf;
      var ctx_r82 = _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵnextContext"](2);
      return ctx_r82.openRewardDescFinal(finalPrize_r61, i_r64);
    });
    _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵelementEnd"]()()();
    _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵelementStart"](10, "ion-card-content")(11, "div", 16)(12, "div", 17);
    _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵtemplate"](13, PrizesPage_div_12_ng_container_1_ion_card_6_ion_grid_13_Template, 7, 6, "ion-grid", 5);
    _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵelementEnd"]()()()();
  }

  if (rf & 2) {
    var reward_r63 = ctx.$implicit;

    var _r66 = _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵreference"](8);

    var ctx_r62 = _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵnextContext"](3);
    _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵadvance"](1);
    _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵproperty"]("ngClass", ctx_r62.getPostion(reward_r63.position - 1));
    _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵadvance"](4);
    _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵproperty"]("ngIf", _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵpipeBind1"](6, 4, reward_r63.label))("ngIfElse", _r66);
    _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵadvance"](8);
    _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵproperty"]("ngIf", reward_r63.desc);
  }
}

function PrizesPage_div_12_ng_container_1_Template(rf, ctx) {
  if (rf & 1) {
    var _r86 = _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵgetCurrentView"]();

    _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵelementContainerStart"](0);
    _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵelementStart"](1, "div", 46)(2, "span");
    _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵtext"](3);
    _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵpipe"](4, "translate");
    _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵelementStart"](5, "ion-icon", 10);
    _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵlistener"]("click", function PrizesPage_div_12_ng_container_1_Template_ion_icon_click_5_listener() {
      var restoredCtx = _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵrestoreView"](_r86);
      var finalPrize_r61 = restoredCtx.ngIf;
      var ctx_r85 = _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵnextContext"](2);
      return ctx_r85.openWeekDescFinal(finalPrize_r61);
    });
    _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵelementEnd"]()()();
    _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵtemplate"](6, PrizesPage_div_12_ng_container_1_ion_card_6_Template, 14, 6, "ion-card", 11);
    _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵelementContainerEnd"]();
  }

  if (rf & 2) {
    var finalPrize_r61 = ctx.ngIf;
    _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵadvance"](3);
    _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵtextInterpolate"](_angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵpipeBind1"](4, 2, "campaigns.detail.prize.prizefinal"));
    _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵadvance"](3);
    _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵproperty"]("ngForOf", finalPrize_r61.rewards);
  }
}

function PrizesPage_div_12_ng_template_2_Template(rf, ctx) {
  if (rf & 1) {
    _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵelementStart"](0, "div", 31);
    _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵtext"](1);
    _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵpipe"](2, "translate");
    _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵelementEnd"]();
  }

  if (rf & 2) {
    _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵadvance"](1);
    _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵtextInterpolate"](_angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵpipeBind1"](2, 1, "campaigns.detail.prize.noFinal"));
  }
}

function PrizesPage_div_12_Template(rf, ctx) {
  if (rf & 1) {
    _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵelementStart"](0, "div");
    _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵtemplate"](1, PrizesPage_div_12_ng_container_1_Template, 7, 4, "ng-container", 6);
    _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵtemplate"](2, PrizesPage_div_12_ng_template_2_Template, 3, 3, "ng-template", null, 45, _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵtemplateRefExtractor"]);
    _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵelementEnd"]();
  }

  if (rf & 2) {
    var _r59 = _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵreference"](3);

    var ctx_r1 = _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵnextContext"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵadvance"](1);
    _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵproperty"]("ngIf", ctx_r1.getFinalPrize())("ngIfElse", _r59);
  }
}

var PrizesPage = /*#__PURE__*/function () {
  function PrizesPage(route, pageSettingsService, campaignService, modalController, translateService) {
    var _this = this;

    (0,_Users_smartcommunitylab_Desktop_newWork_dslab_playgo_mobile_playgo_mobile_node_modules_babel_runtime_helpers_esm_classCallCheck_js__WEBPACK_IMPORTED_MODULE_0__["default"])(this, PrizesPage);

    this.route = route;
    this.pageSettingsService = pageSettingsService;
    this.campaignService = campaignService;
    this.modalController = modalController;
    this.translateService = translateService;
    this.notExpanded = true;
    this.campaignId$ = this.route.params.pipe((0,rxjs__WEBPACK_IMPORTED_MODULE_14__.map)(function (params) {
      return params.id;
    }), (0,rxjs__WEBPACK_IMPORTED_MODULE_15__.shareReplay)(1));
    this.dateTimeToCheck = luxon__WEBPACK_IMPORTED_MODULE_2__.DateTime.utc();
    this.prizePresent = false;
    this.subId = this.route.params.subscribe(function (params) {
      _this.id = params.id;
      _this.subCampaign = _this.campaignService.myCampaigns$.subscribe(function (campaigns) {
        _this.campaignContainer = campaigns.find(function (campaignContainer) {
          return campaignContainer.campaign.campaignId === _this.id;
        });

        _this.campaignContainer.campaign.weekConfs.sort(function (a, b) {
          return b.dateFrom - a.dateFrom;
        });
      });
    });
  }

  (0,_Users_smartcommunitylab_Desktop_newWork_dslab_playgo_mobile_playgo_mobile_node_modules_babel_runtime_helpers_esm_createClass_js__WEBPACK_IMPORTED_MODULE_1__["default"])(PrizesPage, [{
    key: "ngOnInit",
    value: function ngOnInit() {}
  }, {
    key: "ionViewWillEnter",
    value: function ionViewWillEnter() {
      this.changePageSettings();
      var pastPrizes = this.pastprizes();
      this.actualPrize = this.getActualPrize();

      if (!pastPrizes && !this.prizePresent) {
        this.selectedSegment = 'finalPrizes';
        return;
      } else {
        this.selectedSegment = 'periodicPrizes';
      }

      if (!this.prizePresent) {
        this.notExpanded = false;
      }

      console.log('actualPrizes', this.actualPrize);
    }
  }, {
    key: "getFinalPrize",
    value: function getFinalPrize() {
      var _a;

      var prize = this.campaignContainer.campaign.weekConfs.find(function (x) {
        return x.weekNumber === 0;
      });

      if (((_a = prize === null || prize === void 0 ? void 0 : prize.rewards) === null || _a === void 0 ? void 0 : _a.length) > 0) {
        return prize;
      }

      return null;
    }
  }, {
    key: "getActualPrize",
    value: function getActualPrize() {
      var _this2 = this;

      var _a, _b, _c;

      var prize = (_b = (_a = this.campaignContainer.campaign) === null || _a === void 0 ? void 0 : _a.weekConfs) === null || _b === void 0 ? void 0 : _b.find(function (x) {
        return _this2.isThisPeriod(x.dateFrom, x.dateTo) && x.weekNumber !== 0;
      });

      if (((_c = prize === null || prize === void 0 ? void 0 : prize.rewards) === null || _c === void 0 ? void 0 : _c.length) > 0) {
        this.prizePresent = true;
      }

      return prize;
    }
  }, {
    key: "openWeekDescActual",
    value: function openWeekDescActual(finalPrize) {
      return (0,tslib__WEBPACK_IMPORTED_MODULE_16__.__awaiter)(this, void 0, void 0, /*#__PURE__*/_regeneratorRuntime().mark(function _callee() {
        var titlePrize, modal, _yield$modal$onWillDi, data;

        return _regeneratorRuntime().wrap(function _callee$(_context) {
          while (1) switch (_context.prev = _context.next) {
            case 0:
              _context.next = 2;
              return (0,rxjs__WEBPACK_IMPORTED_MODULE_17__.firstValueFrom)(this.translateService.get('campaigns.detail.prize.actualWeekTitle'));

            case 2:
              titlePrize = _context.sent;
              _context.next = 5;
              return this.modalController.create({
                component: _detail_modal_detail_modal__WEBPACK_IMPORTED_MODULE_5__.DetailPrizeModalPage,
                componentProps: {
                  title: titlePrize,
                  detail: finalPrize.desc
                },
                cssClass: 'challenge-info'
              });

            case 5:
              modal = _context.sent;
              _context.next = 8;
              return modal.present();

            case 8:
              _context.next = 10;
              return modal.onWillDismiss();

            case 10:
              _yield$modal$onWillDi = _context.sent;
              data = _yield$modal$onWillDi.data;

            case 12:
            case "end":
              return _context.stop();
          }
        }, _callee, this);
      }));
    }
  }, {
    key: "scrollTo",
    value: function scrollTo(elementId) {
      var id = document.getElementById('subprizes');
      this.content.scrollToPoint(0, id.offsetTop, 1000);
    }
  }, {
    key: "pastprizes",
    value: function pastprizes() {
      var _this3 = this;

      var _a, _b; //get all the confs and check if there are confs before dateTimetocheck
      // eslint-disable-next-line arrow-body-style


      return (_b = (_a = this.campaignContainer.campaign) === null || _a === void 0 ? void 0 : _a.weekConfs) === null || _b === void 0 ? void 0 : _b.find(function (x) {
        var _a;

        return luxon__WEBPACK_IMPORTED_MODULE_2__.DateTime.fromMillis(x.dateTo) < _this3.dateTimeToCheck && ((_a = x.rewards) === null || _a === void 0 ? void 0 : _a.length) > 0;
      });
    }
  }, {
    key: "openWeekDescPast",
    value: function openWeekDescPast(confPrize) {
      return (0,tslib__WEBPACK_IMPORTED_MODULE_16__.__awaiter)(this, void 0, void 0, /*#__PURE__*/_regeneratorRuntime().mark(function _callee2() {
        var titlePrize, modal, _yield$modal$onWillDi2, data;

        return _regeneratorRuntime().wrap(function _callee2$(_context2) {
          while (1) switch (_context2.prev = _context2.next) {
            case 0:
              _context2.next = 2;
              return (0,rxjs__WEBPACK_IMPORTED_MODULE_17__.firstValueFrom)(this.translateService.get('campaigns.detail.prize.actualWeekTitle'));

            case 2:
              titlePrize = _context2.sent;
              _context2.next = 5;
              return this.modalController.create({
                component: _detail_modal_detail_modal__WEBPACK_IMPORTED_MODULE_5__.DetailPrizeModalPage,
                componentProps: {
                  title: titlePrize,
                  detail: confPrize.desc
                },
                cssClass: 'challenge-info'
              });

            case 5:
              modal = _context2.sent;
              _context2.next = 8;
              return modal.present();

            case 8:
              _context2.next = 10;
              return modal.onWillDismiss();

            case 10:
              _yield$modal$onWillDi2 = _context2.sent;
              data = _yield$modal$onWillDi2.data;

            case 12:
            case "end":
              return _context2.stop();
          }
        }, _callee2, this);
      }));
    }
  }, {
    key: "openRewardDescActual",
    value: function openRewardDescActual(actualPrize, index) {
      return (0,tslib__WEBPACK_IMPORTED_MODULE_16__.__awaiter)(this, void 0, void 0, /*#__PURE__*/_regeneratorRuntime().mark(function _callee3() {
        var titlePrize, modal, _yield$modal$onWillDi3, data;

        return _regeneratorRuntime().wrap(function _callee3$(_context3) {
          while (1) switch (_context3.prev = _context3.next) {
            case 0:
              _context3.next = 2;
              return (0,rxjs__WEBPACK_IMPORTED_MODULE_17__.firstValueFrom)(this.translateService.get('campaigns.detail.prize.periodicWeekTitle'));

            case 2:
              titlePrize = _context3.sent;
              _context3.next = 5;
              return this.modalController.create({
                component: _detail_modal_detail_modal__WEBPACK_IMPORTED_MODULE_5__.DetailPrizeModalPage,
                componentProps: {
                  title: titlePrize,
                  detail: actualPrize === null || actualPrize === void 0 ? void 0 : actualPrize.rewards[index].rewardNote
                },
                cssClass: 'challenge-info'
              });

            case 5:
              modal = _context3.sent;
              _context3.next = 8;
              return modal.present();

            case 8:
              _context3.next = 10;
              return modal.onWillDismiss();

            case 10:
              _yield$modal$onWillDi3 = _context3.sent;
              data = _yield$modal$onWillDi3.data;

            case 12:
            case "end":
              return _context3.stop();
          }
        }, _callee3, this);
      }));
    }
  }, {
    key: "openWeekDescFinal",
    value: function openWeekDescFinal(actualPrize) {
      return (0,tslib__WEBPACK_IMPORTED_MODULE_16__.__awaiter)(this, void 0, void 0, /*#__PURE__*/_regeneratorRuntime().mark(function _callee4() {
        var titlePrize, modal, _yield$modal$onWillDi4, data;

        return _regeneratorRuntime().wrap(function _callee4$(_context4) {
          while (1) switch (_context4.prev = _context4.next) {
            case 0:
              _context4.next = 2;
              return (0,rxjs__WEBPACK_IMPORTED_MODULE_17__.firstValueFrom)(this.translateService.get('campaigns.detail.prize.finalWeekTitle'));

            case 2:
              titlePrize = _context4.sent;
              _context4.next = 5;
              return this.modalController.create({
                component: _detail_modal_detail_modal__WEBPACK_IMPORTED_MODULE_5__.DetailPrizeModalPage,
                componentProps: {
                  title: titlePrize,
                  detail: actualPrize.desc
                },
                cssClass: 'challenge-info'
              });

            case 5:
              modal = _context4.sent;
              _context4.next = 8;
              return modal.present();

            case 8:
              _context4.next = 10;
              return modal.onWillDismiss();

            case 10:
              _yield$modal$onWillDi4 = _context4.sent;
              data = _yield$modal$onWillDi4.data;

            case 12:
            case "end":
              return _context4.stop();
          }
        }, _callee4, this);
      }));
    }
  }, {
    key: "openRewardDescFinal",
    value: function openRewardDescFinal(finalPrize, index) {
      return (0,tslib__WEBPACK_IMPORTED_MODULE_16__.__awaiter)(this, void 0, void 0, /*#__PURE__*/_regeneratorRuntime().mark(function _callee5() {
        var titlePrize, modal, _yield$modal$onWillDi5, data;

        return _regeneratorRuntime().wrap(function _callee5$(_context5) {
          while (1) switch (_context5.prev = _context5.next) {
            case 0:
              _context5.next = 2;
              return (0,rxjs__WEBPACK_IMPORTED_MODULE_17__.firstValueFrom)(this.translateService.get('campaigns.detail.prize.finalRewardTitle'));

            case 2:
              titlePrize = _context5.sent;
              _context5.next = 5;
              return this.modalController.create({
                component: _detail_modal_detail_modal__WEBPACK_IMPORTED_MODULE_5__.DetailPrizeModalPage,
                componentProps: {
                  title: titlePrize,
                  detail: finalPrize === null || finalPrize === void 0 ? void 0 : finalPrize.rewards[index].rewardNote
                },
                cssClass: 'challenge-info'
              });

            case 5:
              modal = _context5.sent;
              _context5.next = 8;
              return modal.present();

            case 8:
              _context5.next = 10;
              return modal.onWillDismiss();

            case 10:
              _yield$modal$onWillDi5 = _context5.sent;
              data = _yield$modal$onWillDi5.data;

            case 12:
            case "end":
              return _context5.stop();
          }
        }, _callee5, this);
      }));
    }
  }, {
    key: "ngAfterViewInit",
    value: function ngAfterViewInit() {// //change the behaviour of _blank arrived with editor, adding a new listener and opening a browser
      // this.anchors = this.elementRef.nativeElement.querySelectorAll('a');
      // this.anchors.forEach((anchor: HTMLAnchorElement) => {
      //   anchor.addEventListener('click', this.handleAnchorClick);
      // });
    }
  }, {
    key: "expandPrizes",
    value: function expandPrizes() {
      this.notExpanded = false;
      this.scrollTo('subprizes');
    }
  }, {
    key: "openLink",
    value: function openLink(link) {
      _capacitor_browser__WEBPACK_IMPORTED_MODULE_4__.Browser.open({
        url: link,
        windowName: '_system',
        presentationStyle: 'popover'
      });
    }
  }, {
    key: "getPostion",
    value: function getPostion(arg0) {
      switch (arg0) {
        case 0:
          return 'gold';

        case 1:
          return 'silver';

        case 2:
          return 'bronze';

        default:
          return '';
      }
    }
  }, {
    key: "isThisPeriod",
    value: function isThisPeriod(dateFrom, dateTo) {
      var interval = luxon__WEBPACK_IMPORTED_MODULE_2__.Interval.fromDateTimes(luxon__WEBPACK_IMPORTED_MODULE_2__.DateTime.fromMillis(dateFrom), luxon__WEBPACK_IMPORTED_MODULE_2__.DateTime.fromMillis(dateTo));
      return interval.contains(this.dateTimeToCheck);
    }
  }, {
    key: "changePageSettings",
    value: function changePageSettings() {
      var _a, _b;

      this.pageSettingsService.set({
        color: (_b = (_a = this.campaignContainer) === null || _a === void 0 ? void 0 : _a.campaign) === null || _b === void 0 ? void 0 : _b.type
      });
    }
  }, {
    key: "ngOnDestroy",
    value: function ngOnDestroy() {
      this.subCampaign.unsubscribe();
      this.subId.unsubscribe();
    }
  }, {
    key: "openPrize",
    value: function openPrize() {
      return (0,tslib__WEBPACK_IMPORTED_MODULE_16__.__awaiter)(this, void 0, void 0, /*#__PURE__*/_regeneratorRuntime().mark(function _callee6() {
        var modal;
        return _regeneratorRuntime().wrap(function _callee6$(_context6) {
          while (1) switch (_context6.prev = _context6.next) {
            case 0:
              _context6.next = 2;
              return this.modalController.create({
                component: _prize_modal_prize_modal__WEBPACK_IMPORTED_MODULE_3__.PrizeModalPage,
                cssClass: 'challenge-info'
              });

            case 2:
              modal = _context6.sent;
              _context6.next = 5;
              return modal.present();

            case 5:
              _context6.next = 7;
              return modal.onWillDismiss();

            case 7:
            case "end":
              return _context6.stop();
          }
        }, _callee6, this);
      }));
    }
  }, {
    key: "isBeforeNow",
    value: function isBeforeNow(conf) {
      return luxon__WEBPACK_IMPORTED_MODULE_2__.DateTime.fromMillis(conf === null || conf === void 0 ? void 0 : conf.dateTo) < this.dateTimeToCheck;
    }
  }]);

  return PrizesPage;
}();

PrizesPage.ɵfac = function PrizesPage_Factory(t) {
  return new (t || PrizesPage)(_angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵdirectiveInject"](_angular_router__WEBPACK_IMPORTED_MODULE_18__.ActivatedRoute), _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵdirectiveInject"](src_app_core_shared_services_page_settings_service__WEBPACK_IMPORTED_MODULE_6__.PageSettingsService), _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵdirectiveInject"](src_app_core_shared_services_campaign_service__WEBPACK_IMPORTED_MODULE_7__.CampaignService), _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵdirectiveInject"](_ionic_angular__WEBPACK_IMPORTED_MODULE_19__.ModalController), _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵdirectiveInject"](_ngx_translate_core__WEBPACK_IMPORTED_MODULE_20__.TranslateService));
};

PrizesPage.ɵcmp = /*@__PURE__*/_angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵdefineComponent"]({
  type: PrizesPage,
  selectors: [["app-stats"]],
  viewQuery: function PrizesPage_Query(rf, ctx) {
    if (rf & 1) {
      _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵviewQuery"](_ionic_angular__WEBPACK_IMPORTED_MODULE_19__.IonContent, 5);
    }

    if (rf & 2) {
      var _t;

      _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵqueryRefresh"](_t = _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵloadQuery"]()) && (ctx.content = _t.first);
    }
  },
  decls: 13,
  vars: 20,
  consts: [["appHeader", ""], ["appContent", "", 3, "fullscreen"], ["mode", "md", "scrollable", "", 1, "app-segment", 3, "ngModel", "ngModelChange"], ["value", "periodicPrizes", "checked", "", "mode", "ios", 1, "app-segment-button"], ["value", "finalPrizes", "checked", "", "mode", "ios", 1, "app-segment-button"], [4, "ngIf"], [4, "ngIf", "ngIfElse"], ["noRewards", ""], ["expanded", ""], [1, "actual-header"], ["name", "information-circle", 3, "click"], [4, "ngFor", "ngForOf"], [3, "ngClass"], ["name", "gift"], ["ordinaryNumber", ""], ["name", "information-circle", 1, "information", 3, "click"], [1, "ion-no-padding"], [1, "sponsor"], [3, "value"], [1, "desc"], [1, "ion-text-start"], ["class", "detail", 4, "ngIf"], [1, "detail"], [1, "ion-text-start", "sponsorby"], ["class", "ion-text-start", 4, "ngIf"], ["class", "ion-text-start", 3, "innerHTML", 4, "ngIf"], ["class", "ion-text-end website", 3, "click", 4, "ngIf"], [1, "ion-text-start", 3, "innerHTML"], [1, "ion-text-end", "website", 3, "click"], ["id", "subprizes", "class", "ion-margin", "expand", "block", 3, "color", "click", 4, "ngIf", "ngIfElse"], ["id", "subprizes", "expand", "block", 1, "ion-margin", 3, "color", "click"], [1, "no-prizes"], [1, "sub-header"], [1, "date-prize"], ["class", "on-going", 4, "ngIf"], [1, "on-going"], ["slot", "header"], [1, "ion-no-padding", "container"], ["size", "2"], ["name", "gift", 3, "ngClass"], [3, "value", "ngClass"], [1, "prize"], ["class", "ion-padding sponsor", "slot", "content", 4, "ngIf"], ["slot", "content", 1, "ion-padding", "sponsor"], [1, "detail", "ion-padding"], ["noFinal", ""], [1, "final-header"]],
  template: function PrizesPage_Template(rf, ctx) {
    if (rf & 1) {
      _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵelement"](0, "ion-header", 0);
      _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵelementStart"](1, "ion-content", 1)(2, "ion-segment", 2);
      _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵlistener"]("ngModelChange", function PrizesPage_Template_ion_segment_ngModelChange_2_listener($event) {
        return ctx.selectedSegment = $event;
      });
      _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵelementStart"](3, "ion-segment-button", 3)(4, "ion-label");
      _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵtext"](5);
      _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵpipe"](6, "translate");
      _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵelementEnd"]()();
      _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵelementStart"](7, "ion-segment-button", 4)(8, "ion-label");
      _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵtext"](9);
      _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵpipe"](10, "translate");
      _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵelementEnd"]()()();
      _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵtemplate"](11, PrizesPage_div_11_Template, 7, 3, "div", 5);
      _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵtemplate"](12, PrizesPage_div_12_Template, 4, 2, "div", 5);
      _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵelementEnd"]();
    }

    if (rf & 2) {
      _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵadvance"](1);
      _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵproperty"]("fullscreen", true);
      _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵadvance"](1);
      _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵstyleProp"]("--background", "var(--ion-color-" + ctx.campaignContainer.campaign.type + ")");
      _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵproperty"]("ngModel", ctx.selectedSegment);
      _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵadvance"](1);
      _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵstyleProp"]("--color", "var(--ion-color-" + ctx.campaignContainer.campaign.type + "-contrast)")("--color-checked", "black");
      _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵadvance"](2);
      _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵtextInterpolate"](_angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵpipeBind1"](6, 16, "campaigns.detail.prize.periodic"));
      _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵadvance"](2);
      _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵstyleProp"]("--color", "var(--ion-color-" + ctx.campaignContainer.campaign.type + "-contrast)")("--color-checked", "black");
      _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵadvance"](2);
      _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵtextInterpolate"](_angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵpipeBind1"](10, 18, "campaigns.detail.prize.final"));
      _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵadvance"](2);
      _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵproperty"]("ngIf", ctx.selectedSegment === "periodicPrizes");
      _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵadvance"](1);
      _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵproperty"]("ngIf", ctx.selectedSegment === "finalPrizes");
    }
  },
  directives: [_ionic_angular__WEBPACK_IMPORTED_MODULE_19__.IonHeader, _core_shared_layout_header_header_directive__WEBPACK_IMPORTED_MODULE_8__.HeaderDirective, _ionic_angular__WEBPACK_IMPORTED_MODULE_19__.IonContent, _core_shared_layout_content_content_directive__WEBPACK_IMPORTED_MODULE_9__.ContentDirective, _ionic_angular__WEBPACK_IMPORTED_MODULE_19__.IonSegment, _ionic_angular__WEBPACK_IMPORTED_MODULE_19__.SelectValueAccessor, _angular_forms__WEBPACK_IMPORTED_MODULE_21__.NgControlStatus, _angular_forms__WEBPACK_IMPORTED_MODULE_21__.NgModel, _ionic_angular__WEBPACK_IMPORTED_MODULE_19__.IonSegmentButton, _ionic_angular__WEBPACK_IMPORTED_MODULE_19__.IonLabel, _angular_common__WEBPACK_IMPORTED_MODULE_22__.NgIf, _ionic_angular__WEBPACK_IMPORTED_MODULE_19__.IonIcon, _angular_common__WEBPACK_IMPORTED_MODULE_22__.NgForOf, _ionic_angular__WEBPACK_IMPORTED_MODULE_19__.IonCard, _ionic_angular__WEBPACK_IMPORTED_MODULE_19__.IonCardHeader, _angular_common__WEBPACK_IMPORTED_MODULE_22__.NgClass, _ionic_angular__WEBPACK_IMPORTED_MODULE_19__.IonCardTitle, _core_shared_globalization_ordinal_number_ordinal_number_component__WEBPACK_IMPORTED_MODULE_10__.OrdinalNumberComponent, _ionic_angular__WEBPACK_IMPORTED_MODULE_19__.IonCardContent, _ionic_angular__WEBPACK_IMPORTED_MODULE_19__.IonGrid, _ionic_angular__WEBPACK_IMPORTED_MODULE_19__.IonRow, _ionic_angular__WEBPACK_IMPORTED_MODULE_19__.IonCol, _ionic_angular__WEBPACK_IMPORTED_MODULE_19__.IonButton, _ionic_angular__WEBPACK_IMPORTED_MODULE_19__.IonAccordionGroup, _ionic_angular__WEBPACK_IMPORTED_MODULE_19__.IonAccordion, _ionic_angular__WEBPACK_IMPORTED_MODULE_19__.IonItem],
  pipes: [_ngx_translate_core__WEBPACK_IMPORTED_MODULE_20__.TranslatePipe, _core_shared_pipes_localDate_pipe__WEBPACK_IMPORTED_MODULE_11__.LocalDatePipe, _core_shared_pipes_languageMap_pipe__WEBPACK_IMPORTED_MODULE_12__.LanguageMapPipe, _angular_common__WEBPACK_IMPORTED_MODULE_22__.UpperCasePipe],
  styles: ["ion-card-title[_ngcontent-%COMP%] {\n  font-size: 16px;\n  font-weight: 300;\n  display: flex;\n  justify-content: space-between;\n}\n\nion-card[_ngcontent-%COMP%] {\n  color: black;\n}\n\nion-card-content[_ngcontent-%COMP%]   .prize[_ngcontent-%COMP%] {\n  font-weight: 700;\n}\n\nion-card-content[_ngcontent-%COMP%]   .info-prize[_ngcontent-%COMP%] {\n  display: flex;\n  align-items: center;\n  justify-content: flex-end;\n}\n\nion-card-content[_ngcontent-%COMP%]   .info-prize[_ngcontent-%COMP%]   ion-icon[_ngcontent-%COMP%] {\n  font-size: 22px;\n  margin: 6px;\n}\n\nion-card-content[_ngcontent-%COMP%]   ion-grid[_ngcontent-%COMP%]   ion-row[_ngcontent-%COMP%]   ion-col[_ngcontent-%COMP%] {\n  display: flex;\n  justify-content: center;\n  flex-direction: column;\n}\n\nion-card-content[_ngcontent-%COMP%]   ion-grid[_ngcontent-%COMP%]   ion-row[_ngcontent-%COMP%]   ion-col[_ngcontent-%COMP%]   ion-icon[_ngcontent-%COMP%] {\n  margin: auto;\n  font-size: 30px;\n}\n\nion-card-content[_ngcontent-%COMP%]   ion-grid[_ngcontent-%COMP%]   ion-row[_ngcontent-%COMP%]   ion-col[_ngcontent-%COMP%]:first-child {\n  text-align: center;\n}\n\n.gold[_ngcontent-%COMP%] {\n  background-color: gold;\n}\n\n.silver[_ngcontent-%COMP%] {\n  background-color: silver;\n}\n\n.bronze[_ngcontent-%COMP%] {\n  background-color: chocolate;\n  color: white;\n}\n\n.packet-gold[_ngcontent-%COMP%] {\n  color: gold;\n}\n\n.packet-silver[_ngcontent-%COMP%] {\n  color: silver;\n}\n\n.packet-bronze[_ngcontent-%COMP%] {\n  color: chocolate;\n}\n\n.active[_ngcontent-%COMP%] {\n  background-color: gold;\n}\n\n.not-active[_ngcontent-%COMP%] {\n  background-color: silver;\n}\n\n.on-going[_ngcontent-%COMP%] {\n  font-style: italic;\n}\n\nion-card-header[_ngcontent-%COMP%] {\n  border-bottom: 1px solid #e0e0e0;\n}\n\n.final-header[_ngcontent-%COMP%] {\n  text-align: center;\n  height: 70px;\n  display: flex;\n  justify-content: center;\n  margin-bottom: -20px;\n}\n\n.final-header[_ngcontent-%COMP%]   span[_ngcontent-%COMP%] {\n  font-size: 18px;\n  font-weight: bold;\n  display: flex;\n  justify-content: center;\n  align-items: center;\n}\n\n.final-header[_ngcontent-%COMP%]   span[_ngcontent-%COMP%]   ion-icon[_ngcontent-%COMP%] {\n  color: #00000042;\n  margin-left: 8px;\n}\n\n.actual-header[_ngcontent-%COMP%] {\n  text-align: center;\n  height: 70px;\n  justify-content: center;\n}\n\n.actual-header[_ngcontent-%COMP%]   p[_ngcontent-%COMP%] {\n  font-size: 20px;\n  display: flex;\n  justify-content: center;\n  align-items: center;\n}\n\n.actual-header[_ngcontent-%COMP%]   p[_ngcontent-%COMP%]   ion-icon[_ngcontent-%COMP%] {\n  color: #00000042;\n  margin-left: 8px;\n}\n\n.sub-header[_ngcontent-%COMP%] {\n  text-align: center;\n  justify-content: center;\n  padding: 8px;\n}\n\n.sub-header[_ngcontent-%COMP%]   p[_ngcontent-%COMP%] {\n  font-size: 20px;\n  display: flex;\n  justify-content: center;\n  align-items: center;\n}\n\n.sub-header[_ngcontent-%COMP%]   p[_ngcontent-%COMP%]   ion-icon[_ngcontent-%COMP%] {\n  color: #00000042;\n  margin-left: 8px;\n}\n\n.information[_ngcontent-%COMP%] {\n  opacity: 50%;\n}\n\n.date-prize[_ngcontent-%COMP%] {\n  font-weight: 300;\n}\n\n.sponsor[_ngcontent-%COMP%]   .desc[_ngcontent-%COMP%] {\n  font-size: 17px;\n}\n\n.sponsor[_ngcontent-%COMP%]   .detail[_ngcontent-%COMP%] {\n  background-color: #b6b6b61a;\n  color: #666666;\n}\n\n.sponsor[_ngcontent-%COMP%]   .detail[_ngcontent-%COMP%]   .sponsorby[_ngcontent-%COMP%] {\n  color: #00000026;\n}\n\n.sponsor[_ngcontent-%COMP%]   .detail[_ngcontent-%COMP%]   .website[_ngcontent-%COMP%] {\n  color: #ecd56c;\n  text-decoration: underline;\n}\n\n.no-prizes[_ngcontent-%COMP%] {\n  text-align: center;\n  margin: 40px;\n  font-weight: 700;\n}\n\nion-accordion-group[_ngcontent-%COMP%]   ion-accordion[_ngcontent-%COMP%]   .container[_ngcontent-%COMP%] {\n  width: 100%;\n}\n/*# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbInByaXplcy5wYWdlLnNjc3MiXSwibmFtZXMiOltdLCJtYXBwaW5ncyI6IkFBQUE7RUFDRSxlQUFBO0VBQ0EsZ0JBQUE7RUFDQSxhQUFBO0VBQ0EsOEJBQUE7QUFDRjs7QUFDQTtFQUNFLFlBQUE7QUFFRjs7QUFDRTtFQUNFLGdCQUFBO0FBRUo7O0FBQUU7RUFDRSxhQUFBO0VBQ0EsbUJBQUE7RUFDQSx5QkFBQTtBQUVKOztBQURJO0VBQ0UsZUFBQTtFQUNBLFdBQUE7QUFHTjs7QUFFTTtFQUNFLGFBQUE7RUFDQSx1QkFBQTtFQUNBLHNCQUFBO0FBQVI7O0FBQ1E7RUFDRSxZQUFBO0VBQ0EsZUFBQTtBQUNWOztBQUVNO0VBQ0Usa0JBQUE7QUFBUjs7QUFNQTtFQUNFLHNCQUFBO0FBSEY7O0FBS0E7RUFDRSx3QkFBQTtBQUZGOztBQUlBO0VBQ0UsMkJBQUE7RUFDQSxZQUFBO0FBREY7O0FBR0E7RUFDRSxXQUFBO0FBQUY7O0FBRUE7RUFDRSxhQUFBO0FBQ0Y7O0FBQ0E7RUFDRSxnQkFBQTtBQUVGOztBQUFBO0VBQ0Usc0JBQUE7QUFHRjs7QUFEQTtFQUNFLHdCQUFBO0FBSUY7O0FBRkE7RUFDRSxrQkFBQTtBQUtGOztBQUhBO0VBQ0UsZ0NBQUE7QUFNRjs7QUFKQTtFQUNFLGtCQUFBO0VBQ0EsWUFBQTtFQUNBLGFBQUE7RUFDQSx1QkFBQTtFQUNBLG9CQUFBO0FBT0Y7O0FBTkU7RUFDRSxlQUFBO0VBQ0EsaUJBQUE7RUFDQSxhQUFBO0VBQ0EsdUJBQUE7RUFDQSxtQkFBQTtBQVFKOztBQVBJO0VBQ0UsZ0JBQUE7RUFDQSxnQkFBQTtBQVNOOztBQUxBO0VBQ0Usa0JBQUE7RUFDQSxZQUFBO0VBQ0EsdUJBQUE7QUFRRjs7QUFQRTtFQUNFLGVBQUE7RUFDQSxhQUFBO0VBQ0EsdUJBQUE7RUFDQSxtQkFBQTtBQVNKOztBQVJJO0VBQ0UsZ0JBQUE7RUFDQSxnQkFBQTtBQVVOOztBQU5BO0VBQ0Usa0JBQUE7RUFDQSx1QkFBQTtFQUNBLFlBQUE7QUFTRjs7QUFSRTtFQUNFLGVBQUE7RUFDQSxhQUFBO0VBQ0EsdUJBQUE7RUFDQSxtQkFBQTtBQVVKOztBQVRJO0VBQ0UsZ0JBQUE7RUFDQSxnQkFBQTtBQVdOOztBQVBBO0VBQ0UsWUFBQTtBQVVGOztBQVJBO0VBQ0UsZ0JBQUE7QUFXRjs7QUFSRTtFQUNFLGVBQUE7QUFXSjs7QUFURTtFQUNFLDJCQUFBO0VBQ0EsY0FBQTtBQVdKOztBQVZJO0VBQ0UsZ0JBQUE7QUFZTjs7QUFWSTtFQUNFLGNBQUE7RUFDQSwwQkFBQTtBQVlOOztBQVJBO0VBQ0Usa0JBQUE7RUFDQSxZQUFBO0VBQ0EsZ0JBQUE7QUFXRjs7QUFQSTtFQUNFLFdBQUE7QUFVTiIsImZpbGUiOiJwcml6ZXMucGFnZS5zY3NzIiwic291cmNlc0NvbnRlbnQiOlsiaW9uLWNhcmQtdGl0bGUge1xuICBmb250LXNpemU6IDE2cHg7XG4gIGZvbnQtd2VpZ2h0OiAzMDA7XG4gIGRpc3BsYXk6IGZsZXg7XG4gIGp1c3RpZnktY29udGVudDogc3BhY2UtYmV0d2Vlbjtcbn1cbmlvbi1jYXJkIHtcbiAgY29sb3I6IGJsYWNrO1xufVxuaW9uLWNhcmQtY29udGVudCB7XG4gIC5wcml6ZSB7XG4gICAgZm9udC13ZWlnaHQ6IDcwMDtcbiAgfVxuICAuaW5mby1wcml6ZSB7XG4gICAgZGlzcGxheTogZmxleDtcbiAgICBhbGlnbi1pdGVtczogY2VudGVyO1xuICAgIGp1c3RpZnktY29udGVudDogZmxleC1lbmQ7XG4gICAgaW9uLWljb24ge1xuICAgICAgZm9udC1zaXplOiAyMnB4O1xuICAgICAgbWFyZ2luOiA2cHg7XG4gICAgfVxuICB9XG4gIGlvbi1ncmlkIHtcbiAgICBpb24tcm93IHtcbiAgICAgIGlvbi1jb2wge1xuICAgICAgICBkaXNwbGF5OiBmbGV4O1xuICAgICAgICBqdXN0aWZ5LWNvbnRlbnQ6IGNlbnRlcjtcbiAgICAgICAgZmxleC1kaXJlY3Rpb246IGNvbHVtbjtcbiAgICAgICAgaW9uLWljb24ge1xuICAgICAgICAgIG1hcmdpbjogYXV0bztcbiAgICAgICAgICBmb250LXNpemU6IDMwcHg7XG4gICAgICAgIH1cbiAgICAgIH1cbiAgICAgIGlvbi1jb2w6Zmlyc3QtY2hpbGQge1xuICAgICAgICB0ZXh0LWFsaWduOiBjZW50ZXI7XG4gICAgICB9XG4gICAgfVxuICB9XG59XG5cbi5nb2xkIHtcbiAgYmFja2dyb3VuZC1jb2xvcjogZ29sZDtcbn1cbi5zaWx2ZXIge1xuICBiYWNrZ3JvdW5kLWNvbG9yOiBzaWx2ZXI7XG59XG4uYnJvbnplIHtcbiAgYmFja2dyb3VuZC1jb2xvcjogY2hvY29sYXRlO1xuICBjb2xvcjogd2hpdGU7XG59XG4ucGFja2V0LWdvbGQge1xuICBjb2xvcjogZ29sZDtcbn1cbi5wYWNrZXQtc2lsdmVyIHtcbiAgY29sb3I6IHNpbHZlcjtcbn1cbi5wYWNrZXQtYnJvbnplIHtcbiAgY29sb3I6IGNob2NvbGF0ZTtcbn1cbi5hY3RpdmUge1xuICBiYWNrZ3JvdW5kLWNvbG9yOiBnb2xkO1xufVxuLm5vdC1hY3RpdmUge1xuICBiYWNrZ3JvdW5kLWNvbG9yOiBzaWx2ZXI7XG59XG4ub24tZ29pbmcge1xuICBmb250LXN0eWxlOiBpdGFsaWM7XG59XG5pb24tY2FyZC1oZWFkZXIge1xuICBib3JkZXItYm90dG9tOiAxcHggc29saWQgI2UwZTBlMDtcbn1cbi5maW5hbC1oZWFkZXIge1xuICB0ZXh0LWFsaWduOiBjZW50ZXI7XG4gIGhlaWdodDogNzBweDtcbiAgZGlzcGxheTogZmxleDtcbiAganVzdGlmeS1jb250ZW50OiBjZW50ZXI7XG4gIG1hcmdpbi1ib3R0b206IC0yMHB4O1xuICBzcGFuIHtcbiAgICBmb250LXNpemU6IDE4cHg7XG4gICAgZm9udC13ZWlnaHQ6IGJvbGQ7XG4gICAgZGlzcGxheTogZmxleDtcbiAgICBqdXN0aWZ5LWNvbnRlbnQ6IGNlbnRlcjtcbiAgICBhbGlnbi1pdGVtczogY2VudGVyO1xuICAgIGlvbi1pY29uIHtcbiAgICAgIGNvbG9yOiAjMDAwMDAwNDI7XG4gICAgICBtYXJnaW4tbGVmdDogOHB4O1xuICAgIH1cbiAgfVxufVxuLmFjdHVhbC1oZWFkZXIge1xuICB0ZXh0LWFsaWduOiBjZW50ZXI7XG4gIGhlaWdodDogNzBweDtcbiAganVzdGlmeS1jb250ZW50OiBjZW50ZXI7XG4gIHAge1xuICAgIGZvbnQtc2l6ZTogMjBweDtcbiAgICBkaXNwbGF5OiBmbGV4O1xuICAgIGp1c3RpZnktY29udGVudDogY2VudGVyO1xuICAgIGFsaWduLWl0ZW1zOiBjZW50ZXI7XG4gICAgaW9uLWljb24ge1xuICAgICAgY29sb3I6ICMwMDAwMDA0MjtcbiAgICAgIG1hcmdpbi1sZWZ0OiA4cHg7XG4gICAgfVxuICB9XG59XG4uc3ViLWhlYWRlciB7XG4gIHRleHQtYWxpZ246IGNlbnRlcjtcbiAganVzdGlmeS1jb250ZW50OiBjZW50ZXI7XG4gIHBhZGRpbmc6IDhweDtcbiAgcCB7XG4gICAgZm9udC1zaXplOiAyMHB4O1xuICAgIGRpc3BsYXk6IGZsZXg7XG4gICAganVzdGlmeS1jb250ZW50OiBjZW50ZXI7XG4gICAgYWxpZ24taXRlbXM6IGNlbnRlcjtcbiAgICBpb24taWNvbiB7XG4gICAgICBjb2xvcjogIzAwMDAwMDQyO1xuICAgICAgbWFyZ2luLWxlZnQ6IDhweDtcbiAgICB9XG4gIH1cbn1cbi5pbmZvcm1hdGlvbiB7XG4gIG9wYWNpdHk6IDUwJTtcbn1cbi5kYXRlLXByaXplIHtcbiAgZm9udC13ZWlnaHQ6IDMwMDtcbn1cbi5zcG9uc29yIHtcbiAgLmRlc2Mge1xuICAgIGZvbnQtc2l6ZTogMTdweDtcbiAgfVxuICAuZGV0YWlsIHtcbiAgICBiYWNrZ3JvdW5kLWNvbG9yOiAjYjZiNmI2MWE7XG4gICAgY29sb3I6ICM2NjY2NjY7XG4gICAgLnNwb25zb3JieSB7XG4gICAgICBjb2xvcjogIzAwMDAwMDI2O1xuICAgIH1cbiAgICAud2Vic2l0ZSB7XG4gICAgICBjb2xvcjogI2VjZDU2YztcbiAgICAgIHRleHQtZGVjb3JhdGlvbjogdW5kZXJsaW5lO1xuICAgIH1cbiAgfVxufVxuLm5vLXByaXplcyB7XG4gIHRleHQtYWxpZ246IGNlbnRlcjtcbiAgbWFyZ2luOiA0MHB4O1xuICBmb250LXdlaWdodDogNzAwO1xufVxuaW9uLWFjY29yZGlvbi1ncm91cCB7XG4gIGlvbi1hY2NvcmRpb24ge1xuICAgIC5jb250YWluZXIge1xuICAgICAgd2lkdGg6IDEwMCU7XG4gICAgfVxuICB9XG59XG4iXX0= */"]
});

/***/ })

}]);
//# sourceMappingURL=src_app_pages_home_campaign-details_prizes_prizes_module_ts.js.map