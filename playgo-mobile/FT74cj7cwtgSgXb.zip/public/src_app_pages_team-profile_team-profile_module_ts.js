"use strict";
(self["webpackChunkapp"] = self["webpackChunkapp"] || []).push([["src_app_pages_team-profile_team-profile_module_ts"],{

/***/ 39572:
/*!*******************************************************************!*\
  !*** ./src/app/pages/team-profile/team-profile-routing.module.ts ***!
  \*******************************************************************/
/***/ (function(__unused_webpack_module, __webpack_exports__, __webpack_require__) {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "TeamProfilePageRoutingModule": function() { return /* binding */ TeamProfilePageRoutingModule; }
/* harmony export */ });
/* harmony import */ var _Users_smartcommunitylab_Desktop_newWork_dslab_playgo_mobile_playgo_mobile_node_modules_babel_runtime_helpers_esm_createClass_js__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./node_modules/@babel/runtime/helpers/esm/createClass.js */ 48047);
/* harmony import */ var _Users_smartcommunitylab_Desktop_newWork_dslab_playgo_mobile_playgo_mobile_node_modules_babel_runtime_helpers_esm_classCallCheck_js__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ./node_modules/@babel/runtime/helpers/esm/classCallCheck.js */ 78069);
/* harmony import */ var _angular_router__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! @angular/router */ 52816);
/* harmony import */ var _team_profile_page__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! ./team-profile.page */ 9743);
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @angular/core */ 3184);






var routes = [{
  path: '',
  component: _team_profile_page__WEBPACK_IMPORTED_MODULE_2__.TeamProfilePage,
  data: {
    title: 'teamprofile.title',
    backButton: true,
    showPlayButton: true,
    color: 'school'
  }
}];
var TeamProfilePageRoutingModule = /*#__PURE__*/(0,_Users_smartcommunitylab_Desktop_newWork_dslab_playgo_mobile_playgo_mobile_node_modules_babel_runtime_helpers_esm_createClass_js__WEBPACK_IMPORTED_MODULE_0__["default"])(function TeamProfilePageRoutingModule() {
  (0,_Users_smartcommunitylab_Desktop_newWork_dslab_playgo_mobile_playgo_mobile_node_modules_babel_runtime_helpers_esm_classCallCheck_js__WEBPACK_IMPORTED_MODULE_1__["default"])(this, TeamProfilePageRoutingModule);
});

TeamProfilePageRoutingModule.ɵfac = function TeamProfilePageRoutingModule_Factory(t) {
  return new (t || TeamProfilePageRoutingModule)();
};

TeamProfilePageRoutingModule.ɵmod = /*@__PURE__*/_angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵdefineNgModule"]({
  type: TeamProfilePageRoutingModule
});
TeamProfilePageRoutingModule.ɵinj = /*@__PURE__*/_angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵdefineInjector"]({
  imports: [[_angular_router__WEBPACK_IMPORTED_MODULE_4__.RouterModule.forChild(routes)], _angular_router__WEBPACK_IMPORTED_MODULE_4__.RouterModule]
});

(function () {
  (typeof ngJitMode === "undefined" || ngJitMode) && _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵsetNgModuleScope"](TeamProfilePageRoutingModule, {
    imports: [_angular_router__WEBPACK_IMPORTED_MODULE_4__.RouterModule],
    exports: [_angular_router__WEBPACK_IMPORTED_MODULE_4__.RouterModule]
  });
})();

/***/ }),

/***/ 11290:
/*!***********************************************************!*\
  !*** ./src/app/pages/team-profile/team-profile.module.ts ***!
  \***********************************************************/
/***/ (function(__unused_webpack_module, __webpack_exports__, __webpack_require__) {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "TeamProfilePageModule": function() { return /* binding */ TeamProfilePageModule; }
/* harmony export */ });
/* harmony import */ var _Users_smartcommunitylab_Desktop_newWork_dslab_playgo_mobile_playgo_mobile_node_modules_babel_runtime_helpers_esm_createClass_js__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./node_modules/@babel/runtime/helpers/esm/createClass.js */ 48047);
/* harmony import */ var _Users_smartcommunitylab_Desktop_newWork_dslab_playgo_mobile_playgo_mobile_node_modules_babel_runtime_helpers_esm_classCallCheck_js__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ./node_modules/@babel/runtime/helpers/esm/classCallCheck.js */ 78069);
/* harmony import */ var _team_profile_routing_module__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! ./team-profile-routing.module */ 39572);
/* harmony import */ var _team_profile_page__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! ./team-profile.page */ 9743);
/* harmony import */ var src_app_core_shared_shared_module__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! src/app/core/shared/shared.module */ 97205);
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! @angular/core */ 3184);






var TeamProfilePageModule = /*#__PURE__*/(0,_Users_smartcommunitylab_Desktop_newWork_dslab_playgo_mobile_playgo_mobile_node_modules_babel_runtime_helpers_esm_createClass_js__WEBPACK_IMPORTED_MODULE_0__["default"])(function TeamProfilePageModule() {
  (0,_Users_smartcommunitylab_Desktop_newWork_dslab_playgo_mobile_playgo_mobile_node_modules_babel_runtime_helpers_esm_classCallCheck_js__WEBPACK_IMPORTED_MODULE_1__["default"])(this, TeamProfilePageModule);
});

TeamProfilePageModule.ɵfac = function TeamProfilePageModule_Factory(t) {
  return new (t || TeamProfilePageModule)();
};

TeamProfilePageModule.ɵmod = /*@__PURE__*/_angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵdefineNgModule"]({
  type: TeamProfilePageModule
});
TeamProfilePageModule.ɵinj = /*@__PURE__*/_angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵdefineInjector"]({
  imports: [[src_app_core_shared_shared_module__WEBPACK_IMPORTED_MODULE_4__.PlayGoSharedModule, _team_profile_routing_module__WEBPACK_IMPORTED_MODULE_2__.TeamProfilePageRoutingModule]]
});

(function () {
  (typeof ngJitMode === "undefined" || ngJitMode) && _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵsetNgModuleScope"](TeamProfilePageModule, {
    declarations: [_team_profile_page__WEBPACK_IMPORTED_MODULE_3__.TeamProfilePage],
    imports: [src_app_core_shared_shared_module__WEBPACK_IMPORTED_MODULE_4__.PlayGoSharedModule, _team_profile_routing_module__WEBPACK_IMPORTED_MODULE_2__.TeamProfilePageRoutingModule]
  });
})();

/***/ }),

/***/ 9743:
/*!*********************************************************!*\
  !*** ./src/app/pages/team-profile/team-profile.page.ts ***!
  \*********************************************************/
/***/ (function(__unused_webpack_module, __webpack_exports__, __webpack_require__) {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "TeamProfilePage": function() { return /* binding */ TeamProfilePage; }
/* harmony export */ });
/* harmony import */ var _Users_smartcommunitylab_Desktop_newWork_dslab_playgo_mobile_playgo_mobile_node_modules_babel_runtime_helpers_esm_slicedToArray_js__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./node_modules/@babel/runtime/helpers/esm/slicedToArray.js */ 10507);
/* harmony import */ var _Users_smartcommunitylab_Desktop_newWork_dslab_playgo_mobile_playgo_mobile_node_modules_babel_runtime_helpers_esm_classCallCheck_js__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ./node_modules/@babel/runtime/helpers/esm/classCallCheck.js */ 78069);
/* harmony import */ var _Users_smartcommunitylab_Desktop_newWork_dslab_playgo_mobile_playgo_mobile_node_modules_babel_runtime_helpers_esm_createClass_js__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! ./node_modules/@babel/runtime/helpers/esm/createClass.js */ 48047);
/* harmony import */ var rxjs__WEBPACK_IMPORTED_MODULE_16__ = __webpack_require__(/*! rxjs */ 89196);
/* harmony import */ var rxjs__WEBPACK_IMPORTED_MODULE_17__ = __webpack_require__(/*! rxjs */ 50635);
/* harmony import */ var rxjs__WEBPACK_IMPORTED_MODULE_18__ = __webpack_require__(/*! rxjs */ 98977);
/* harmony import */ var rxjs__WEBPACK_IMPORTED_MODULE_19__ = __webpack_require__(/*! rxjs */ 32673);
/* harmony import */ var rxjs__WEBPACK_IMPORTED_MODULE_20__ = __webpack_require__(/*! rxjs */ 26562);
/* harmony import */ var src_app_core_shared_tracking_trip_model__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! src/app/core/shared/tracking/trip.model */ 49110);
/* harmony import */ var src_app_core_shared_time_utils__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! src/app/core/shared/time.utils */ 93462);
/* harmony import */ var luxon__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! luxon */ 20020);
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_15__ = __webpack_require__(/*! @angular/core */ 3184);
/* harmony import */ var _angular_router__WEBPACK_IMPORTED_MODULE_21__ = __webpack_require__(/*! @angular/router */ 52816);
/* harmony import */ var src_app_core_shared_services_error_service__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! src/app/core/shared/services/error.service */ 96204);
/* harmony import */ var src_app_core_shared_services_team_service__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(/*! src/app/core/shared/services/team.service */ 86612);
/* harmony import */ var src_app_core_shared_services_user_service__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(/*! src/app/core/shared/services/user.service */ 50749);
/* harmony import */ var src_app_core_shared_services_report_service__WEBPACK_IMPORTED_MODULE_9__ = __webpack_require__(/*! src/app/core/shared/services/report.service */ 93981);
/* harmony import */ var _ionic_angular__WEBPACK_IMPORTED_MODULE_22__ = __webpack_require__(/*! @ionic/angular */ 93819);
/* harmony import */ var _core_shared_layout_header_header_directive__WEBPACK_IMPORTED_MODULE_10__ = __webpack_require__(/*! ../../core/shared/layout/header/header.directive */ 34161);
/* harmony import */ var _core_shared_layout_content_content_directive__WEBPACK_IMPORTED_MODULE_11__ = __webpack_require__(/*! ../../core/shared/layout/content/content.directive */ 69669);
/* harmony import */ var _angular_common__WEBPACK_IMPORTED_MODULE_23__ = __webpack_require__(/*! @angular/common */ 36362);
/* harmony import */ var _core_shared_globalization_ordinal_number_ordinal_number_component__WEBPACK_IMPORTED_MODULE_12__ = __webpack_require__(/*! ../../core/shared/globalization/ordinal-number/ordinal-number.component */ 56032);
/* harmony import */ var _core_shared_ui_icon_icon_component__WEBPACK_IMPORTED_MODULE_13__ = __webpack_require__(/*! ../../core/shared/ui/icon/icon.component */ 71888);
/* harmony import */ var _ngx_translate_core__WEBPACK_IMPORTED_MODULE_24__ = __webpack_require__(/*! @ngx-translate/core */ 87514);
/* harmony import */ var _core_shared_pipes_localNumber_pipe__WEBPACK_IMPORTED_MODULE_14__ = __webpack_require__(/*! ../../core/shared/pipes/localNumber.pipe */ 89713);






















function TeamProfilePage_div_7_ion_row_2_Template(rf, ctx) {
  if (rf & 1) {
    _angular_core__WEBPACK_IMPORTED_MODULE_15__["ɵɵelementStart"](0, "ion-row")(1, "ion-col", 11)(2, "span", 12);
    _angular_core__WEBPACK_IMPORTED_MODULE_15__["ɵɵtext"](3);
    _angular_core__WEBPACK_IMPORTED_MODULE_15__["ɵɵpipe"](4, "async");
    _angular_core__WEBPACK_IMPORTED_MODULE_15__["ɵɵelementEnd"]()()();
  }

  if (rf & 2) {
    var ctx_r4 = _angular_core__WEBPACK_IMPORTED_MODULE_15__["ɵɵnextContext"](2);
    var tmp_0_0;
    _angular_core__WEBPACK_IMPORTED_MODULE_15__["ɵɵadvance"](3);
    _angular_core__WEBPACK_IMPORTED_MODULE_15__["ɵɵtextInterpolate"]((tmp_0_0 = _angular_core__WEBPACK_IMPORTED_MODULE_15__["ɵɵpipeBind1"](4, 1, ctx_r4.team$)) == null ? null : tmp_0_0.customData == null ? null : tmp_0_0.customData.name);
  }
}

function TeamProfilePage_div_7_ion_row_4_Template(rf, ctx) {
  if (rf & 1) {
    _angular_core__WEBPACK_IMPORTED_MODULE_15__["ɵɵelementStart"](0, "ion-row")(1, "ion-col", 11)(2, "span", 13);
    _angular_core__WEBPACK_IMPORTED_MODULE_15__["ɵɵtext"](3);
    _angular_core__WEBPACK_IMPORTED_MODULE_15__["ɵɵpipe"](4, "async");
    _angular_core__WEBPACK_IMPORTED_MODULE_15__["ɵɵelementEnd"]()()();
  }

  if (rf & 2) {
    var ctx_r5 = _angular_core__WEBPACK_IMPORTED_MODULE_15__["ɵɵnextContext"](2);
    var tmp_0_0;
    _angular_core__WEBPACK_IMPORTED_MODULE_15__["ɵɵadvance"](3);
    _angular_core__WEBPACK_IMPORTED_MODULE_15__["ɵɵtextInterpolate"]((tmp_0_0 = _angular_core__WEBPACK_IMPORTED_MODULE_15__["ɵɵpipeBind1"](4, 1, ctx_r5.team$)) == null ? null : tmp_0_0.customData == null ? null : tmp_0_0.customData.desc);
  }
}

function TeamProfilePage_div_7_ion_row_6_ion_col_1_Template(rf, ctx) {
  if (rf & 1) {
    _angular_core__WEBPACK_IMPORTED_MODULE_15__["ɵɵelementStart"](0, "ion-col", 11)(1, "span", 15);
    _angular_core__WEBPACK_IMPORTED_MODULE_15__["ɵɵtext"](2);
    _angular_core__WEBPACK_IMPORTED_MODULE_15__["ɵɵpipe"](3, "translate");
    _angular_core__WEBPACK_IMPORTED_MODULE_15__["ɵɵelementStart"](4, "b");
    _angular_core__WEBPACK_IMPORTED_MODULE_15__["ɵɵtext"](5);
    _angular_core__WEBPACK_IMPORTED_MODULE_15__["ɵɵpipe"](6, "async");
    _angular_core__WEBPACK_IMPORTED_MODULE_15__["ɵɵelementEnd"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_15__["ɵɵtext"](7);
    _angular_core__WEBPACK_IMPORTED_MODULE_15__["ɵɵpipe"](8, "translate");
    _angular_core__WEBPACK_IMPORTED_MODULE_15__["ɵɵelementStart"](9, "b");
    _angular_core__WEBPACK_IMPORTED_MODULE_15__["ɵɵtext"](10);
    _angular_core__WEBPACK_IMPORTED_MODULE_15__["ɵɵpipe"](11, "async");
    _angular_core__WEBPACK_IMPORTED_MODULE_15__["ɵɵelementEnd"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_15__["ɵɵtext"](12);
    _angular_core__WEBPACK_IMPORTED_MODULE_15__["ɵɵpipe"](13, "translate");
    _angular_core__WEBPACK_IMPORTED_MODULE_15__["ɵɵelementStart"](14, "b");
    _angular_core__WEBPACK_IMPORTED_MODULE_15__["ɵɵtext"](15);
    _angular_core__WEBPACK_IMPORTED_MODULE_15__["ɵɵpipe"](16, "async");
    _angular_core__WEBPACK_IMPORTED_MODULE_15__["ɵɵelementEnd"]()()();
  }

  if (rf & 2) {
    var ctx_r7 = _angular_core__WEBPACK_IMPORTED_MODULE_15__["ɵɵnextContext"](3);
    var tmp_1_0;
    var tmp_3_0;
    var tmp_5_0;
    _angular_core__WEBPACK_IMPORTED_MODULE_15__["ɵɵadvance"](2);
    _angular_core__WEBPACK_IMPORTED_MODULE_15__["ɵɵtextInterpolate1"]("", _angular_core__WEBPACK_IMPORTED_MODULE_15__["ɵɵpipeBind1"](3, 6, "campaigns.detail.nMembersActive"), " ");
    _angular_core__WEBPACK_IMPORTED_MODULE_15__["ɵɵadvance"](3);
    _angular_core__WEBPACK_IMPORTED_MODULE_15__["ɵɵtextInterpolate"](ctx_r7.getMembers((tmp_1_0 = _angular_core__WEBPACK_IMPORTED_MODULE_15__["ɵɵpipeBind1"](6, 8, ctx_r7.team$)) == null ? null : tmp_1_0.members));
    _angular_core__WEBPACK_IMPORTED_MODULE_15__["ɵɵadvance"](2);
    _angular_core__WEBPACK_IMPORTED_MODULE_15__["ɵɵtextInterpolate1"](" \xA0", _angular_core__WEBPACK_IMPORTED_MODULE_15__["ɵɵpipeBind1"](8, 10, "campaigns.detail.nMembersInvited"), " ");
    _angular_core__WEBPACK_IMPORTED_MODULE_15__["ɵɵadvance"](3);
    _angular_core__WEBPACK_IMPORTED_MODULE_15__["ɵɵtextInterpolate"]((tmp_3_0 = _angular_core__WEBPACK_IMPORTED_MODULE_15__["ɵɵpipeBind1"](11, 12, ctx_r7.team$)) == null ? null : tmp_3_0.members == null ? null : tmp_3_0.members.length);
    _angular_core__WEBPACK_IMPORTED_MODULE_15__["ɵɵadvance"](2);
    _angular_core__WEBPACK_IMPORTED_MODULE_15__["ɵɵtextInterpolate1"](" \xA0", _angular_core__WEBPACK_IMPORTED_MODULE_15__["ɵɵpipeBind1"](13, 14, "campaigns.detail.nMembersMax"), " ");
    _angular_core__WEBPACK_IMPORTED_MODULE_15__["ɵɵadvance"](3);
    _angular_core__WEBPACK_IMPORTED_MODULE_15__["ɵɵtextInterpolate"]((tmp_5_0 = _angular_core__WEBPACK_IMPORTED_MODULE_15__["ɵɵpipeBind1"](16, 16, ctx_r7.team$)) == null ? null : tmp_5_0.expected);
  }
}

function TeamProfilePage_div_7_ion_row_6_Template(rf, ctx) {
  if (rf & 1) {
    _angular_core__WEBPACK_IMPORTED_MODULE_15__["ɵɵelementStart"](0, "ion-row");
    _angular_core__WEBPACK_IMPORTED_MODULE_15__["ɵɵtemplate"](1, TeamProfilePage_div_7_ion_row_6_ion_col_1_Template, 17, 18, "ion-col", 14);
    _angular_core__WEBPACK_IMPORTED_MODULE_15__["ɵɵpipe"](2, "async");
    _angular_core__WEBPACK_IMPORTED_MODULE_15__["ɵɵelementEnd"]();
  }

  if (rf & 2) {
    var ctx_r6 = _angular_core__WEBPACK_IMPORTED_MODULE_15__["ɵɵnextContext"](2);
    var tmp_0_0;
    _angular_core__WEBPACK_IMPORTED_MODULE_15__["ɵɵadvance"](1);
    _angular_core__WEBPACK_IMPORTED_MODULE_15__["ɵɵproperty"]("ngIf", (tmp_0_0 = _angular_core__WEBPACK_IMPORTED_MODULE_15__["ɵɵpipeBind1"](2, 1, ctx_r6.team$)) == null ? null : tmp_0_0.members);
  }
}

function TeamProfilePage_div_7_Template(rf, ctx) {
  if (rf & 1) {
    _angular_core__WEBPACK_IMPORTED_MODULE_15__["ɵɵelementStart"](0, "div")(1, "ion-grid");
    _angular_core__WEBPACK_IMPORTED_MODULE_15__["ɵɵtemplate"](2, TeamProfilePage_div_7_ion_row_2_Template, 5, 3, "ion-row", 5);
    _angular_core__WEBPACK_IMPORTED_MODULE_15__["ɵɵpipe"](3, "async");
    _angular_core__WEBPACK_IMPORTED_MODULE_15__["ɵɵtemplate"](4, TeamProfilePage_div_7_ion_row_4_Template, 5, 3, "ion-row", 5);
    _angular_core__WEBPACK_IMPORTED_MODULE_15__["ɵɵpipe"](5, "async");
    _angular_core__WEBPACK_IMPORTED_MODULE_15__["ɵɵtemplate"](6, TeamProfilePage_div_7_ion_row_6_Template, 3, 3, "ion-row", 5);
    _angular_core__WEBPACK_IMPORTED_MODULE_15__["ɵɵpipe"](7, "async");
    _angular_core__WEBPACK_IMPORTED_MODULE_15__["ɵɵelementStart"](8, "ion-row")(9, "ion-col")(10, "p", 8)(11, "b");
    _angular_core__WEBPACK_IMPORTED_MODULE_15__["ɵɵtext"](12);
    _angular_core__WEBPACK_IMPORTED_MODULE_15__["ɵɵpipe"](13, "translate");
    _angular_core__WEBPACK_IMPORTED_MODULE_15__["ɵɵelement"](14, "app-ordinal-number", 9);
    _angular_core__WEBPACK_IMPORTED_MODULE_15__["ɵɵpipe"](15, "async");
    _angular_core__WEBPACK_IMPORTED_MODULE_15__["ɵɵtext"](16);
    _angular_core__WEBPACK_IMPORTED_MODULE_15__["ɵɵpipe"](17, "localNumber");
    _angular_core__WEBPACK_IMPORTED_MODULE_15__["ɵɵpipe"](18, "async");
    _angular_core__WEBPACK_IMPORTED_MODULE_15__["ɵɵelementEnd"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_15__["ɵɵelement"](19, "app-icon", 10);
    _angular_core__WEBPACK_IMPORTED_MODULE_15__["ɵɵelementEnd"]()()()()();
  }

  if (rf & 2) {
    var ctx_r0 = _angular_core__WEBPACK_IMPORTED_MODULE_15__["ɵɵnextContext"]();
    var tmp_0_0;
    var tmp_1_0;
    var tmp_4_0;
    var tmp_5_0;
    _angular_core__WEBPACK_IMPORTED_MODULE_15__["ɵɵadvance"](2);
    _angular_core__WEBPACK_IMPORTED_MODULE_15__["ɵɵproperty"]("ngIf", (tmp_0_0 = _angular_core__WEBPACK_IMPORTED_MODULE_15__["ɵɵpipeBind1"](3, 6, ctx_r0.team$)) == null ? null : tmp_0_0.customData == null ? null : tmp_0_0.customData.name);
    _angular_core__WEBPACK_IMPORTED_MODULE_15__["ɵɵadvance"](2);
    _angular_core__WEBPACK_IMPORTED_MODULE_15__["ɵɵproperty"]("ngIf", (tmp_1_0 = _angular_core__WEBPACK_IMPORTED_MODULE_15__["ɵɵpipeBind1"](5, 8, ctx_r0.team$)) == null ? null : tmp_1_0.customData == null ? null : tmp_1_0.customData.desc);
    _angular_core__WEBPACK_IMPORTED_MODULE_15__["ɵɵadvance"](2);
    _angular_core__WEBPACK_IMPORTED_MODULE_15__["ɵɵproperty"]("ngIf", _angular_core__WEBPACK_IMPORTED_MODULE_15__["ɵɵpipeBind1"](7, 10, ctx_r0.type$) === "my");
    _angular_core__WEBPACK_IMPORTED_MODULE_15__["ɵɵadvance"](6);
    _angular_core__WEBPACK_IMPORTED_MODULE_15__["ɵɵtextInterpolate"](_angular_core__WEBPACK_IMPORTED_MODULE_15__["ɵɵpipeBind1"](13, 12, "campaigns.detail.teamDetailRanking"));
    _angular_core__WEBPACK_IMPORTED_MODULE_15__["ɵɵadvance"](2);
    _angular_core__WEBPACK_IMPORTED_MODULE_15__["ɵɵproperty"]("value", (tmp_4_0 = _angular_core__WEBPACK_IMPORTED_MODULE_15__["ɵɵpipeBind1"](15, 14, ctx_r0.status$)) == null ? null : tmp_4_0.position);
    _angular_core__WEBPACK_IMPORTED_MODULE_15__["ɵɵadvance"](2);
    _angular_core__WEBPACK_IMPORTED_MODULE_15__["ɵɵtextInterpolate1"]("- ", _angular_core__WEBPACK_IMPORTED_MODULE_15__["ɵɵpipeBind2"](17, 16, (tmp_5_0 = _angular_core__WEBPACK_IMPORTED_MODULE_15__["ɵɵpipeBind1"](18, 19, ctx_r0.status$)) == null ? null : tmp_5_0.value, "0.0-1"), "");
  }
}

function TeamProfilePage_div_8_ion_avatar_4_Template(rf, ctx) {
  if (rf & 1) {
    _angular_core__WEBPACK_IMPORTED_MODULE_15__["ɵɵelementStart"](0, "ion-avatar");
    _angular_core__WEBPACK_IMPORTED_MODULE_15__["ɵɵelement"](1, "img", 4);
    _angular_core__WEBPACK_IMPORTED_MODULE_15__["ɵɵpipe"](2, "async");
    _angular_core__WEBPACK_IMPORTED_MODULE_15__["ɵɵelementEnd"]();
  }

  if (rf & 2) {
    var ctx_r8 = _angular_core__WEBPACK_IMPORTED_MODULE_15__["ɵɵnextContext"](2);
    _angular_core__WEBPACK_IMPORTED_MODULE_15__["ɵɵadvance"](1);
    _angular_core__WEBPACK_IMPORTED_MODULE_15__["ɵɵproperty"]("src", _angular_core__WEBPACK_IMPORTED_MODULE_15__["ɵɵpipeBind1"](2, 1, ctx_r8.userProfile$).avatar == null ? null : _angular_core__WEBPACK_IMPORTED_MODULE_15__["ɵɵpipeBind1"](2, 1, ctx_r8.userProfile$).avatar.avatarSmallUrl, _angular_core__WEBPACK_IMPORTED_MODULE_15__["ɵɵsanitizeUrl"]);
  }
}

function TeamProfilePage_div_8_ng_template_6_Template(rf, ctx) {
  if (rf & 1) {
    _angular_core__WEBPACK_IMPORTED_MODULE_15__["ɵɵelementStart"](0, "ion-avatar");
    _angular_core__WEBPACK_IMPORTED_MODULE_15__["ɵɵelement"](1, "ion-icon", 22);
    _angular_core__WEBPACK_IMPORTED_MODULE_15__["ɵɵelementEnd"]();
  }
}

function TeamProfilePage_div_8_ng_container_18_ion_row_1_ion_avatar_2_Template(rf, ctx) {
  if (rf & 1) {
    _angular_core__WEBPACK_IMPORTED_MODULE_15__["ɵɵelementStart"](0, "ion-avatar");
    _angular_core__WEBPACK_IMPORTED_MODULE_15__["ɵɵelement"](1, "img", 4);
    _angular_core__WEBPACK_IMPORTED_MODULE_15__["ɵɵelementEnd"]();
  }

  if (rf & 2) {
    var student_r14 = _angular_core__WEBPACK_IMPORTED_MODULE_15__["ɵɵnextContext"](2).$implicit;
    _angular_core__WEBPACK_IMPORTED_MODULE_15__["ɵɵadvance"](1);
    _angular_core__WEBPACK_IMPORTED_MODULE_15__["ɵɵproperty"]("src", student_r14.avatar == null ? null : student_r14.avatar.url, _angular_core__WEBPACK_IMPORTED_MODULE_15__["ɵɵsanitizeUrl"]);
  }
}

function TeamProfilePage_div_8_ng_container_18_ion_row_1_ng_template_3_Template(rf, ctx) {
  if (rf & 1) {
    _angular_core__WEBPACK_IMPORTED_MODULE_15__["ɵɵelementStart"](0, "ion-avatar");
    _angular_core__WEBPACK_IMPORTED_MODULE_15__["ɵɵelement"](1, "ion-icon", 22);
    _angular_core__WEBPACK_IMPORTED_MODULE_15__["ɵɵelementEnd"]();
  }
}

function TeamProfilePage_div_8_ng_container_18_ion_row_1_Template(rf, ctx) {
  if (rf & 1) {
    _angular_core__WEBPACK_IMPORTED_MODULE_15__["ɵɵelementStart"](0, "ion-row")(1, "ion-col", 17);
    _angular_core__WEBPACK_IMPORTED_MODULE_15__["ɵɵtemplate"](2, TeamProfilePage_div_8_ng_container_18_ion_row_1_ion_avatar_2_Template, 2, 1, "ion-avatar", 18);
    _angular_core__WEBPACK_IMPORTED_MODULE_15__["ɵɵtemplate"](3, TeamProfilePage_div_8_ng_container_18_ion_row_1_ng_template_3_Template, 2, 0, "ng-template", null, 19, _angular_core__WEBPACK_IMPORTED_MODULE_15__["ɵɵtemplateRefExtractor"]);
    _angular_core__WEBPACK_IMPORTED_MODULE_15__["ɵɵelementEnd"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_15__["ɵɵelementStart"](5, "ion-col");
    _angular_core__WEBPACK_IMPORTED_MODULE_15__["ɵɵtext"](6);
    _angular_core__WEBPACK_IMPORTED_MODULE_15__["ɵɵelementEnd"]()();
  }

  if (rf & 2) {
    var _r17 = _angular_core__WEBPACK_IMPORTED_MODULE_15__["ɵɵreference"](4);

    var student_r14 = _angular_core__WEBPACK_IMPORTED_MODULE_15__["ɵɵnextContext"]().$implicit;
    _angular_core__WEBPACK_IMPORTED_MODULE_15__["ɵɵadvance"](2);
    _angular_core__WEBPACK_IMPORTED_MODULE_15__["ɵɵproperty"]("ngIf", student_r14.avatar == null ? null : student_r14.avatar.url)("ngIfElse", _r17);
    _angular_core__WEBPACK_IMPORTED_MODULE_15__["ɵɵadvance"](4);
    _angular_core__WEBPACK_IMPORTED_MODULE_15__["ɵɵtextInterpolate1"](" ", student_r14.nickname, " ");
  }
}

function TeamProfilePage_div_8_ng_container_18_Template(rf, ctx) {
  if (rf & 1) {
    _angular_core__WEBPACK_IMPORTED_MODULE_15__["ɵɵelementContainerStart"](0);
    _angular_core__WEBPACK_IMPORTED_MODULE_15__["ɵɵtemplate"](1, TeamProfilePage_div_8_ng_container_18_ion_row_1_Template, 7, 3, "ion-row", 5);
    _angular_core__WEBPACK_IMPORTED_MODULE_15__["ɵɵpipe"](2, "async");
    _angular_core__WEBPACK_IMPORTED_MODULE_15__["ɵɵelementContainerEnd"]();
  }

  if (rf & 2) {
    var student_r14 = ctx.$implicit;
    var ctx_r11 = _angular_core__WEBPACK_IMPORTED_MODULE_15__["ɵɵnextContext"](2);
    _angular_core__WEBPACK_IMPORTED_MODULE_15__["ɵɵadvance"](1);
    _angular_core__WEBPACK_IMPORTED_MODULE_15__["ɵɵproperty"]("ngIf", _angular_core__WEBPACK_IMPORTED_MODULE_15__["ɵɵpipeBind1"](2, 1, ctx_r11.playerId$) !== (student_r14 == null ? null : student_r14.playerId) && (student_r14 == null ? null : student_r14.subscribed) && !(student_r14 == null ? null : student_r14.unregistered));
  }
}

function TeamProfilePage_div_8_ng_container_20_ion_row_1_ion_avatar_2_Template(rf, ctx) {
  if (rf & 1) {
    _angular_core__WEBPACK_IMPORTED_MODULE_15__["ɵɵelementStart"](0, "ion-avatar");
    _angular_core__WEBPACK_IMPORTED_MODULE_15__["ɵɵelement"](1, "img", 4);
    _angular_core__WEBPACK_IMPORTED_MODULE_15__["ɵɵelementEnd"]();
  }

  if (rf & 2) {
    var student_r21 = _angular_core__WEBPACK_IMPORTED_MODULE_15__["ɵɵnextContext"](2).$implicit;
    _angular_core__WEBPACK_IMPORTED_MODULE_15__["ɵɵadvance"](1);
    _angular_core__WEBPACK_IMPORTED_MODULE_15__["ɵɵproperty"]("src", student_r21.avatar == null ? null : student_r21.avatar.url, _angular_core__WEBPACK_IMPORTED_MODULE_15__["ɵɵsanitizeUrl"]);
  }
}

function TeamProfilePage_div_8_ng_container_20_ion_row_1_ng_template_3_Template(rf, ctx) {
  if (rf & 1) {
    _angular_core__WEBPACK_IMPORTED_MODULE_15__["ɵɵelementStart"](0, "ion-avatar", 25);
    _angular_core__WEBPACK_IMPORTED_MODULE_15__["ɵɵelement"](1, "ion-icon", 22);
    _angular_core__WEBPACK_IMPORTED_MODULE_15__["ɵɵelementEnd"]();
  }
}

function TeamProfilePage_div_8_ng_container_20_ion_row_1_Template(rf, ctx) {
  if (rf & 1) {
    _angular_core__WEBPACK_IMPORTED_MODULE_15__["ɵɵelementStart"](0, "ion-row", 24)(1, "ion-col", 17);
    _angular_core__WEBPACK_IMPORTED_MODULE_15__["ɵɵtemplate"](2, TeamProfilePage_div_8_ng_container_20_ion_row_1_ion_avatar_2_Template, 2, 1, "ion-avatar", 18);
    _angular_core__WEBPACK_IMPORTED_MODULE_15__["ɵɵtemplate"](3, TeamProfilePage_div_8_ng_container_20_ion_row_1_ng_template_3_Template, 2, 0, "ng-template", null, 19, _angular_core__WEBPACK_IMPORTED_MODULE_15__["ɵɵtemplateRefExtractor"]);
    _angular_core__WEBPACK_IMPORTED_MODULE_15__["ɵɵelementEnd"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_15__["ɵɵelementStart"](5, "ion-col", 25);
    _angular_core__WEBPACK_IMPORTED_MODULE_15__["ɵɵtext"](6);
    _angular_core__WEBPACK_IMPORTED_MODULE_15__["ɵɵelementEnd"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_15__["ɵɵelementStart"](7, "ion-col", 26)(8, "span", 27);
    _angular_core__WEBPACK_IMPORTED_MODULE_15__["ɵɵtext"](9);
    _angular_core__WEBPACK_IMPORTED_MODULE_15__["ɵɵpipe"](10, "translate");
    _angular_core__WEBPACK_IMPORTED_MODULE_15__["ɵɵelementEnd"]()()();
  }

  if (rf & 2) {
    var _r24 = _angular_core__WEBPACK_IMPORTED_MODULE_15__["ɵɵreference"](4);

    var student_r21 = _angular_core__WEBPACK_IMPORTED_MODULE_15__["ɵɵnextContext"]().$implicit;
    _angular_core__WEBPACK_IMPORTED_MODULE_15__["ɵɵadvance"](2);
    _angular_core__WEBPACK_IMPORTED_MODULE_15__["ɵɵproperty"]("ngIf", student_r21.avatar == null ? null : student_r21.avatar.url)("ngIfElse", _r24);
    _angular_core__WEBPACK_IMPORTED_MODULE_15__["ɵɵadvance"](4);
    _angular_core__WEBPACK_IMPORTED_MODULE_15__["ɵɵtextInterpolate1"](" ", student_r21.nickname, " ");
    _angular_core__WEBPACK_IMPORTED_MODULE_15__["ɵɵadvance"](3);
    _angular_core__WEBPACK_IMPORTED_MODULE_15__["ɵɵtextInterpolate"](_angular_core__WEBPACK_IMPORTED_MODULE_15__["ɵɵpipeBind1"](10, 4, "campaigns.detail.not_subscribed"));
  }
}

function TeamProfilePage_div_8_ng_container_20_Template(rf, ctx) {
  if (rf & 1) {
    _angular_core__WEBPACK_IMPORTED_MODULE_15__["ɵɵelementContainerStart"](0);
    _angular_core__WEBPACK_IMPORTED_MODULE_15__["ɵɵtemplate"](1, TeamProfilePage_div_8_ng_container_20_ion_row_1_Template, 11, 6, "ion-row", 23);
    _angular_core__WEBPACK_IMPORTED_MODULE_15__["ɵɵpipe"](2, "async");
    _angular_core__WEBPACK_IMPORTED_MODULE_15__["ɵɵelementContainerEnd"]();
  }

  if (rf & 2) {
    var student_r21 = ctx.$implicit;
    var ctx_r12 = _angular_core__WEBPACK_IMPORTED_MODULE_15__["ɵɵnextContext"](2);
    _angular_core__WEBPACK_IMPORTED_MODULE_15__["ɵɵadvance"](1);
    _angular_core__WEBPACK_IMPORTED_MODULE_15__["ɵɵproperty"]("ngIf", _angular_core__WEBPACK_IMPORTED_MODULE_15__["ɵɵpipeBind1"](2, 1, ctx_r12.playerId$) !== student_r21.playerId && !student_r21.subscribed && !student_r21.unregistered);
  }
}

function TeamProfilePage_div_8_ng_container_22_ion_row_1_Template(rf, ctx) {
  if (rf & 1) {
    _angular_core__WEBPACK_IMPORTED_MODULE_15__["ɵɵelementStart"](0, "ion-row", 24)(1, "ion-col", 17)(2, "ion-avatar", 25);
    _angular_core__WEBPACK_IMPORTED_MODULE_15__["ɵɵelement"](3, "ion-icon", 22);
    _angular_core__WEBPACK_IMPORTED_MODULE_15__["ɵɵelementEnd"]()();
    _angular_core__WEBPACK_IMPORTED_MODULE_15__["ɵɵelementStart"](4, "ion-col", 25);
    _angular_core__WEBPACK_IMPORTED_MODULE_15__["ɵɵtext"](5, " ******** ");
    _angular_core__WEBPACK_IMPORTED_MODULE_15__["ɵɵelementEnd"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_15__["ɵɵelementStart"](6, "ion-col", 26)(7, "span", 27);
    _angular_core__WEBPACK_IMPORTED_MODULE_15__["ɵɵtext"](8);
    _angular_core__WEBPACK_IMPORTED_MODULE_15__["ɵɵpipe"](9, "translate");
    _angular_core__WEBPACK_IMPORTED_MODULE_15__["ɵɵelementEnd"]()()();
  }

  if (rf & 2) {
    _angular_core__WEBPACK_IMPORTED_MODULE_15__["ɵɵadvance"](8);
    _angular_core__WEBPACK_IMPORTED_MODULE_15__["ɵɵtextInterpolate"](_angular_core__WEBPACK_IMPORTED_MODULE_15__["ɵɵpipeBind1"](9, 1, "campaigns.detail.unregistered"));
  }
}

function TeamProfilePage_div_8_ng_container_22_Template(rf, ctx) {
  if (rf & 1) {
    _angular_core__WEBPACK_IMPORTED_MODULE_15__["ɵɵelementContainerStart"](0);
    _angular_core__WEBPACK_IMPORTED_MODULE_15__["ɵɵtemplate"](1, TeamProfilePage_div_8_ng_container_22_ion_row_1_Template, 10, 3, "ion-row", 23);
    _angular_core__WEBPACK_IMPORTED_MODULE_15__["ɵɵpipe"](2, "async");
    _angular_core__WEBPACK_IMPORTED_MODULE_15__["ɵɵelementContainerEnd"]();
  }

  if (rf & 2) {
    var student_r28 = ctx.$implicit;
    var ctx_r13 = _angular_core__WEBPACK_IMPORTED_MODULE_15__["ɵɵnextContext"](2);
    _angular_core__WEBPACK_IMPORTED_MODULE_15__["ɵɵadvance"](1);
    _angular_core__WEBPACK_IMPORTED_MODULE_15__["ɵɵproperty"]("ngIf", _angular_core__WEBPACK_IMPORTED_MODULE_15__["ɵɵpipeBind1"](2, 1, ctx_r13.playerId$) !== student_r28.playerId && student_r28.unregistered);
  }
}

function TeamProfilePage_div_8_Template(rf, ctx) {
  if (rf & 1) {
    _angular_core__WEBPACK_IMPORTED_MODULE_15__["ɵɵelementStart"](0, "div", 16)(1, "ion-grid")(2, "ion-row")(3, "ion-col", 17);
    _angular_core__WEBPACK_IMPORTED_MODULE_15__["ɵɵtemplate"](4, TeamProfilePage_div_8_ion_avatar_4_Template, 3, 3, "ion-avatar", 18);
    _angular_core__WEBPACK_IMPORTED_MODULE_15__["ɵɵpipe"](5, "async");
    _angular_core__WEBPACK_IMPORTED_MODULE_15__["ɵɵtemplate"](6, TeamProfilePage_div_8_ng_template_6_Template, 2, 0, "ng-template", null, 19, _angular_core__WEBPACK_IMPORTED_MODULE_15__["ɵɵtemplateRefExtractor"]);
    _angular_core__WEBPACK_IMPORTED_MODULE_15__["ɵɵelementEnd"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_15__["ɵɵelementStart"](8, "ion-col");
    _angular_core__WEBPACK_IMPORTED_MODULE_15__["ɵɵtext"](9);
    _angular_core__WEBPACK_IMPORTED_MODULE_15__["ɵɵpipe"](10, "async");
    _angular_core__WEBPACK_IMPORTED_MODULE_15__["ɵɵelementEnd"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_15__["ɵɵelementStart"](11, "ion-col")(12, "p", 20);
    _angular_core__WEBPACK_IMPORTED_MODULE_15__["ɵɵtext"](13);
    _angular_core__WEBPACK_IMPORTED_MODULE_15__["ɵɵpipe"](14, "async");
    _angular_core__WEBPACK_IMPORTED_MODULE_15__["ɵɵpipe"](15, "async");
    _angular_core__WEBPACK_IMPORTED_MODULE_15__["ɵɵpipe"](16, "localNumber");
    _angular_core__WEBPACK_IMPORTED_MODULE_15__["ɵɵelement"](17, "app-icon", 10);
    _angular_core__WEBPACK_IMPORTED_MODULE_15__["ɵɵelementEnd"]()()();
    _angular_core__WEBPACK_IMPORTED_MODULE_15__["ɵɵtemplate"](18, TeamProfilePage_div_8_ng_container_18_Template, 3, 3, "ng-container", 21);
    _angular_core__WEBPACK_IMPORTED_MODULE_15__["ɵɵpipe"](19, "async");
    _angular_core__WEBPACK_IMPORTED_MODULE_15__["ɵɵtemplate"](20, TeamProfilePage_div_8_ng_container_20_Template, 3, 3, "ng-container", 21);
    _angular_core__WEBPACK_IMPORTED_MODULE_15__["ɵɵpipe"](21, "async");
    _angular_core__WEBPACK_IMPORTED_MODULE_15__["ɵɵtemplate"](22, TeamProfilePage_div_8_ng_container_22_Template, 3, 3, "ng-container", 21);
    _angular_core__WEBPACK_IMPORTED_MODULE_15__["ɵɵpipe"](23, "async");
    _angular_core__WEBPACK_IMPORTED_MODULE_15__["ɵɵelementEnd"]()();
  }

  if (rf & 2) {
    var _r9 = _angular_core__WEBPACK_IMPORTED_MODULE_15__["ɵɵreference"](7);

    var ctx_r1 = _angular_core__WEBPACK_IMPORTED_MODULE_15__["ɵɵnextContext"]();
    var tmp_0_0;
    var tmp_2_0;
    var tmp_3_0;
    var tmp_4_0;
    var tmp_5_0;
    var tmp_6_0;
    _angular_core__WEBPACK_IMPORTED_MODULE_15__["ɵɵadvance"](4);
    _angular_core__WEBPACK_IMPORTED_MODULE_15__["ɵɵproperty"]("ngIf", (tmp_0_0 = _angular_core__WEBPACK_IMPORTED_MODULE_15__["ɵɵpipeBind1"](5, 7, ctx_r1.userProfile$)) == null ? null : tmp_0_0.avatar == null ? null : tmp_0_0.avatar.avatarSmallUrl)("ngIfElse", _r9);
    _angular_core__WEBPACK_IMPORTED_MODULE_15__["ɵɵadvance"](5);
    _angular_core__WEBPACK_IMPORTED_MODULE_15__["ɵɵtextInterpolate1"](" ", (tmp_2_0 = _angular_core__WEBPACK_IMPORTED_MODULE_15__["ɵɵpipeBind1"](10, 9, ctx_r1.userProfile$)) == null ? null : tmp_2_0.nickname, " ");
    _angular_core__WEBPACK_IMPORTED_MODULE_15__["ɵɵadvance"](4);
    _angular_core__WEBPACK_IMPORTED_MODULE_15__["ɵɵtextInterpolate1"]("", ((tmp_3_0 = _angular_core__WEBPACK_IMPORTED_MODULE_15__["ɵɵpipeBind1"](14, 11, ctx_r1.myStatus$)) == null ? null : tmp_3_0.score) ? (tmp_3_0 = _angular_core__WEBPACK_IMPORTED_MODULE_15__["ɵɵpipeBind1"](15, 13, ctx_r1.myStatus$)) == null ? null : tmp_3_0.score : _angular_core__WEBPACK_IMPORTED_MODULE_15__["ɵɵpipeBind2"](16, 15, 0, "0.0-1"), " ");
    _angular_core__WEBPACK_IMPORTED_MODULE_15__["ɵɵadvance"](5);
    _angular_core__WEBPACK_IMPORTED_MODULE_15__["ɵɵproperty"]("ngForOf", (tmp_4_0 = _angular_core__WEBPACK_IMPORTED_MODULE_15__["ɵɵpipeBind1"](19, 18, ctx_r1.team$)) == null ? null : tmp_4_0.members);
    _angular_core__WEBPACK_IMPORTED_MODULE_15__["ɵɵadvance"](2);
    _angular_core__WEBPACK_IMPORTED_MODULE_15__["ɵɵproperty"]("ngForOf", (tmp_5_0 = _angular_core__WEBPACK_IMPORTED_MODULE_15__["ɵɵpipeBind1"](21, 20, ctx_r1.team$)) == null ? null : tmp_5_0.members);
    _angular_core__WEBPACK_IMPORTED_MODULE_15__["ɵɵadvance"](2);
    _angular_core__WEBPACK_IMPORTED_MODULE_15__["ɵɵproperty"]("ngForOf", (tmp_6_0 = _angular_core__WEBPACK_IMPORTED_MODULE_15__["ɵɵpipeBind1"](23, 22, ctx_r1.team$)) == null ? null : tmp_6_0.members);
  }
}

var _c0 = function _c0(a0) {
  return {
    value: a0
  };
};

function TeamProfilePage_ng_template_10_div_0_ion_row_2_Template(rf, ctx) {
  if (rf & 1) {
    _angular_core__WEBPACK_IMPORTED_MODULE_15__["ɵɵelementStart"](0, "ion-row")(1, "ion-col", 28);
    _angular_core__WEBPACK_IMPORTED_MODULE_15__["ɵɵelement"](2, "app-icon", 29);
    _angular_core__WEBPACK_IMPORTED_MODULE_15__["ɵɵelementEnd"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_15__["ɵɵelementStart"](3, "ion-col")(4, "div")(5, "span");
    _angular_core__WEBPACK_IMPORTED_MODULE_15__["ɵɵtext"](6);
    _angular_core__WEBPACK_IMPORTED_MODULE_15__["ɵɵpipe"](7, "translate");
    _angular_core__WEBPACK_IMPORTED_MODULE_15__["ɵɵelementEnd"]()();
    _angular_core__WEBPACK_IMPORTED_MODULE_15__["ɵɵelementStart"](8, "div");
    _angular_core__WEBPACK_IMPORTED_MODULE_15__["ɵɵtext"](9);
    _angular_core__WEBPACK_IMPORTED_MODULE_15__["ɵɵpipe"](10, "translate");
    _angular_core__WEBPACK_IMPORTED_MODULE_15__["ɵɵpipe"](11, "localNumber");
    _angular_core__WEBPACK_IMPORTED_MODULE_15__["ɵɵelementEnd"]()()();
  }

  if (rf & 2) {
    var avg_r32 = ctx.$implicit;
    var ctx_r31 = _angular_core__WEBPACK_IMPORTED_MODULE_15__["ɵɵnextContext"](3);
    _angular_core__WEBPACK_IMPORTED_MODULE_15__["ɵɵadvance"](2);
    _angular_core__WEBPACK_IMPORTED_MODULE_15__["ɵɵproperty"]("name", ctx_r31.getTransportTypeIcon(avg_r32.mean));
    _angular_core__WEBPACK_IMPORTED_MODULE_15__["ɵɵadvance"](4);
    _angular_core__WEBPACK_IMPORTED_MODULE_15__["ɵɵtextInterpolate1"](" ", _angular_core__WEBPACK_IMPORTED_MODULE_15__["ɵɵpipeBind1"](7, 3, ctx_r31.getTransportTypeLabel(avg_r32.mean)), " ");
    _angular_core__WEBPACK_IMPORTED_MODULE_15__["ɵɵadvance"](3);
    _angular_core__WEBPACK_IMPORTED_MODULE_15__["ɵɵtextInterpolate"](_angular_core__WEBPACK_IMPORTED_MODULE_15__["ɵɵpipeBind2"](10, 5, "campaigns.detail.teamAvg", _angular_core__WEBPACK_IMPORTED_MODULE_15__["ɵɵpureFunction1"](11, _c0, _angular_core__WEBPACK_IMPORTED_MODULE_15__["ɵɵpipeBind2"](11, 8, avg_r32.value / 1000, "0.0-1"))));
  }
}

function TeamProfilePage_ng_template_10_div_0_Template(rf, ctx) {
  if (rf & 1) {
    _angular_core__WEBPACK_IMPORTED_MODULE_15__["ɵɵelementStart"](0, "div")(1, "ion-grid");
    _angular_core__WEBPACK_IMPORTED_MODULE_15__["ɵɵtemplate"](2, TeamProfilePage_ng_template_10_div_0_ion_row_2_Template, 12, 13, "ion-row", 21);
    _angular_core__WEBPACK_IMPORTED_MODULE_15__["ɵɵpipe"](3, "async");
    _angular_core__WEBPACK_IMPORTED_MODULE_15__["ɵɵelementEnd"]()();
  }

  if (rf & 2) {
    var ctx_r30 = _angular_core__WEBPACK_IMPORTED_MODULE_15__["ɵɵnextContext"](2);
    _angular_core__WEBPACK_IMPORTED_MODULE_15__["ɵɵadvance"](2);
    _angular_core__WEBPACK_IMPORTED_MODULE_15__["ɵɵproperty"]("ngForOf", _angular_core__WEBPACK_IMPORTED_MODULE_15__["ɵɵpipeBind1"](3, 1, ctx_r30.stat$));
  }
}

function TeamProfilePage_ng_template_10_Template(rf, ctx) {
  if (rf & 1) {
    _angular_core__WEBPACK_IMPORTED_MODULE_15__["ɵɵtemplate"](0, TeamProfilePage_ng_template_10_div_0_Template, 4, 3, "div", 5);
    _angular_core__WEBPACK_IMPORTED_MODULE_15__["ɵɵpipe"](1, "async");
  }

  if (rf & 2) {
    var ctx_r3 = _angular_core__WEBPACK_IMPORTED_MODULE_15__["ɵɵnextContext"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_15__["ɵɵproperty"]("ngIf", _angular_core__WEBPACK_IMPORTED_MODULE_15__["ɵɵpipeBind1"](1, 1, ctx_r3.stat$));
  }
}

var TeamProfilePage = /*#__PURE__*/function () {
  function TeamProfilePage(route, errorService, teamService, userService, reportService) {
    var _this = this;

    (0,_Users_smartcommunitylab_Desktop_newWork_dslab_playgo_mobile_playgo_mobile_node_modules_babel_runtime_helpers_esm_classCallCheck_js__WEBPACK_IMPORTED_MODULE_1__["default"])(this, TeamProfilePage);

    this.route = route;
    this.errorService = errorService;
    this.teamService = teamService;
    this.userService = userService;
    this.reportService = reportService;
    this.getTransportTypeIcon = src_app_core_shared_tracking_trip_model__WEBPACK_IMPORTED_MODULE_3__.getTransportTypeIcon;
    this.getTransportTypeLabel = src_app_core_shared_tracking_trip_model__WEBPACK_IMPORTED_MODULE_3__.getTransportTypeLabel;
    this.userProfile$ = this.userService.userProfile$.pipe((0,rxjs__WEBPACK_IMPORTED_MODULE_16__.shareReplay)(1));
    this.playerId$ = this.userProfile$.pipe((0,rxjs__WEBPACK_IMPORTED_MODULE_17__.map)(function (userProfile) {
      return userProfile.playerId;
    }), (0,rxjs__WEBPACK_IMPORTED_MODULE_16__.shareReplay)(1));
    this.teamId$ = this.route.params.pipe((0,rxjs__WEBPACK_IMPORTED_MODULE_17__.map)(function (params) {
      return params.teamId;
    }), (0,rxjs__WEBPACK_IMPORTED_MODULE_18__.distinctUntilChanged)(), (0,rxjs__WEBPACK_IMPORTED_MODULE_16__.shareReplay)(1));
    this.type$ = this.route.params.pipe((0,rxjs__WEBPACK_IMPORTED_MODULE_17__.map)(function (params) {
      return params.type;
    }), (0,rxjs__WEBPACK_IMPORTED_MODULE_18__.distinctUntilChanged)(), (0,rxjs__WEBPACK_IMPORTED_MODULE_16__.shareReplay)(1));
    this.initiativeId$ = this.route.params.pipe((0,rxjs__WEBPACK_IMPORTED_MODULE_17__.map)(function (params) {
      return params.initiativeId;
    }), (0,rxjs__WEBPACK_IMPORTED_MODULE_18__.distinctUntilChanged)(), (0,rxjs__WEBPACK_IMPORTED_MODULE_16__.shareReplay)(1));
    this.teamAvatar$ = this.teamId$.pipe((0,rxjs__WEBPACK_IMPORTED_MODULE_19__.switchMap)(function (teamId) {
      return _this.teamService.getTeamAvatar(teamId).pipe(_this.errorService.getErrorHandler());
    }), (0,rxjs__WEBPACK_IMPORTED_MODULE_16__.shareReplay)(1));
    this.team$ = (0,rxjs__WEBPACK_IMPORTED_MODULE_20__.combineLatest)([this.teamId$, this.initiativeId$, this.type$]).pipe((0,rxjs__WEBPACK_IMPORTED_MODULE_19__.switchMap)(function (_ref) {
      var _ref2 = (0,_Users_smartcommunitylab_Desktop_newWork_dslab_playgo_mobile_playgo_mobile_node_modules_babel_runtime_helpers_esm_slicedToArray_js__WEBPACK_IMPORTED_MODULE_0__["default"])(_ref, 3),
          teamId = _ref2[0],
          initiativeId = _ref2[1],
          type = _ref2[2];

      if (type === 'public') {
        return _this.teamService.getPublicTeam(initiativeId, teamId);
      } else {
        return _this.teamService.getMyTeam(initiativeId, teamId);
      }
    }), (0,rxjs__WEBPACK_IMPORTED_MODULE_16__.shareReplay)(1));
    this.status$ = (0,rxjs__WEBPACK_IMPORTED_MODULE_20__.combineLatest)([this.teamId$, this.initiativeId$]).pipe((0,rxjs__WEBPACK_IMPORTED_MODULE_19__.switchMap)(function (_ref3) {
      var _ref4 = (0,_Users_smartcommunitylab_Desktop_newWork_dslab_playgo_mobile_playgo_mobile_node_modules_babel_runtime_helpers_esm_slicedToArray_js__WEBPACK_IMPORTED_MODULE_0__["default"])(_ref3, 2),
          teamId = _ref4[0],
          initiativeId = _ref4[1];

      return _this.teamService.getTeamPlacing(initiativeId, teamId);
    }));
    this.myStatus$ = this.initiativeId$.pipe((0,rxjs__WEBPACK_IMPORTED_MODULE_19__.switchMap)(function (initiativeID) {
      return _this.reportService.getGameStatus(initiativeID);
    }));
    this.stat$ = (0,rxjs__WEBPACK_IMPORTED_MODULE_20__.combineLatest)([this.teamId$, this.initiativeId$]).pipe((0,rxjs__WEBPACK_IMPORTED_MODULE_19__.switchMap)(function (_ref5) {
      var _ref6 = (0,_Users_smartcommunitylab_Desktop_newWork_dslab_playgo_mobile_playgo_mobile_node_modules_babel_runtime_helpers_esm_slicedToArray_js__WEBPACK_IMPORTED_MODULE_0__["default"])(_ref5, 2),
          teamId = _ref6[0],
          initiativeId = _ref6[1];

      return _this.teamService.getTeamAvg(initiativeId, teamId, 'km', true, (0,src_app_core_shared_time_utils__WEBPACK_IMPORTED_MODULE_4__.toServerDateOnly)(luxon__WEBPACK_IMPORTED_MODULE_5__.DateTime.utc().minus({
        month: 1
      })), (0,src_app_core_shared_time_utils__WEBPACK_IMPORTED_MODULE_4__.toServerDateOnly)(luxon__WEBPACK_IMPORTED_MODULE_5__.DateTime.utc()));
    }));
  }

  (0,_Users_smartcommunitylab_Desktop_newWork_dslab_playgo_mobile_playgo_mobile_node_modules_babel_runtime_helpers_esm_createClass_js__WEBPACK_IMPORTED_MODULE_2__["default"])(TeamProfilePage, [{
    key: "ngOnInit",
    value: function ngOnInit() {}
  }, {
    key: "getMembers",
    value: function getMembers(members) {
      return members === null || members === void 0 ? void 0 : members.filter(function (x) {
        return x.subscribed === true;
      }).length;
    }
  }]);

  return TeamProfilePage;
}();

TeamProfilePage.ɵfac = function TeamProfilePage_Factory(t) {
  return new (t || TeamProfilePage)(_angular_core__WEBPACK_IMPORTED_MODULE_15__["ɵɵdirectiveInject"](_angular_router__WEBPACK_IMPORTED_MODULE_21__.ActivatedRoute), _angular_core__WEBPACK_IMPORTED_MODULE_15__["ɵɵdirectiveInject"](src_app_core_shared_services_error_service__WEBPACK_IMPORTED_MODULE_6__.ErrorService), _angular_core__WEBPACK_IMPORTED_MODULE_15__["ɵɵdirectiveInject"](src_app_core_shared_services_team_service__WEBPACK_IMPORTED_MODULE_7__.TeamService), _angular_core__WEBPACK_IMPORTED_MODULE_15__["ɵɵdirectiveInject"](src_app_core_shared_services_user_service__WEBPACK_IMPORTED_MODULE_8__.UserService), _angular_core__WEBPACK_IMPORTED_MODULE_15__["ɵɵdirectiveInject"](src_app_core_shared_services_report_service__WEBPACK_IMPORTED_MODULE_9__.ReportService));
};

TeamProfilePage.ɵcmp = /*@__PURE__*/_angular_core__WEBPACK_IMPORTED_MODULE_15__["ɵɵdefineComponent"]({
  type: TeamProfilePage,
  selectors: [["app-team-profile"]],
  decls: 13,
  vars: 9,
  consts: [["appHeader", ""], ["appContent", "", 1, "ion-padding", 3, "fullscreen"], [1, "user-intro"], [1, "team"], [3, "src"], [4, "ngIf"], ["class", "myTeam", 4, "ngIf", "ngIfElse"], ["publicProfile", ""], [1, "team-detail"], [3, "value"], ["name", "ecoLeavesHsc"], [1, "ion-text-start"], [1, "name"], [1, "institute"], ["class", "ion-text-start", 4, "ngIf"], [1, "members"], [1, "myTeam"], ["size", "2"], [4, "ngIf", "ngIfElse"], ["alternativeAvatar", ""], [1, "player-detail"], [4, "ngFor", "ngForOf"], ["name", "person-circle-outline"], ["class", "player-not-subscribed", 4, "ngIf"], [1, "player-not-subscribed"], [1, "opaque"], ["size", "auto"], [1, "label-not-subscribed", "opaque"], ["size", "3", 1, "ion-text-center"], [1, "big-icon", 3, "name"]],
  template: function TeamProfilePage_Template(rf, ctx) {
    if (rf & 1) {
      _angular_core__WEBPACK_IMPORTED_MODULE_15__["ɵɵelement"](0, "ion-header", 0);
      _angular_core__WEBPACK_IMPORTED_MODULE_15__["ɵɵelementStart"](1, "ion-content", 1)(2, "div", 2)(3, "ion-avatar", 3);
      _angular_core__WEBPACK_IMPORTED_MODULE_15__["ɵɵelement"](4, "img", 4);
      _angular_core__WEBPACK_IMPORTED_MODULE_15__["ɵɵpipe"](5, "async");
      _angular_core__WEBPACK_IMPORTED_MODULE_15__["ɵɵelementEnd"]()();
      _angular_core__WEBPACK_IMPORTED_MODULE_15__["ɵɵelementStart"](6, "div", 3);
      _angular_core__WEBPACK_IMPORTED_MODULE_15__["ɵɵtemplate"](7, TeamProfilePage_div_7_Template, 20, 21, "div", 5);
      _angular_core__WEBPACK_IMPORTED_MODULE_15__["ɵɵtemplate"](8, TeamProfilePage_div_8_Template, 24, 24, "div", 6);
      _angular_core__WEBPACK_IMPORTED_MODULE_15__["ɵɵpipe"](9, "async");
      _angular_core__WEBPACK_IMPORTED_MODULE_15__["ɵɵtemplate"](10, TeamProfilePage_ng_template_10_Template, 2, 3, "ng-template", null, 7, _angular_core__WEBPACK_IMPORTED_MODULE_15__["ɵɵtemplateRefExtractor"]);
      _angular_core__WEBPACK_IMPORTED_MODULE_15__["ɵɵelement"](12, "div");
      _angular_core__WEBPACK_IMPORTED_MODULE_15__["ɵɵelementEnd"]()();
    }

    if (rf & 2) {
      var _r2 = _angular_core__WEBPACK_IMPORTED_MODULE_15__["ɵɵreference"](11);

      var tmp_1_0;
      _angular_core__WEBPACK_IMPORTED_MODULE_15__["ɵɵadvance"](1);
      _angular_core__WEBPACK_IMPORTED_MODULE_15__["ɵɵproperty"]("fullscreen", true);
      _angular_core__WEBPACK_IMPORTED_MODULE_15__["ɵɵadvance"](3);
      _angular_core__WEBPACK_IMPORTED_MODULE_15__["ɵɵproperty"]("src", (tmp_1_0 = _angular_core__WEBPACK_IMPORTED_MODULE_15__["ɵɵpipeBind1"](5, 5, ctx.teamAvatar$)) == null ? null : tmp_1_0.avatarUrl, _angular_core__WEBPACK_IMPORTED_MODULE_15__["ɵɵsanitizeUrl"]);
      _angular_core__WEBPACK_IMPORTED_MODULE_15__["ɵɵadvance"](3);
      _angular_core__WEBPACK_IMPORTED_MODULE_15__["ɵɵproperty"]("ngIf", ctx.team$);
      _angular_core__WEBPACK_IMPORTED_MODULE_15__["ɵɵadvance"](1);
      _angular_core__WEBPACK_IMPORTED_MODULE_15__["ɵɵproperty"]("ngIf", _angular_core__WEBPACK_IMPORTED_MODULE_15__["ɵɵpipeBind1"](9, 7, ctx.type$) === "my")("ngIfElse", _r2);
    }
  },
  directives: [_ionic_angular__WEBPACK_IMPORTED_MODULE_22__.IonHeader, _core_shared_layout_header_header_directive__WEBPACK_IMPORTED_MODULE_10__.HeaderDirective, _ionic_angular__WEBPACK_IMPORTED_MODULE_22__.IonContent, _core_shared_layout_content_content_directive__WEBPACK_IMPORTED_MODULE_11__.ContentDirective, _ionic_angular__WEBPACK_IMPORTED_MODULE_22__.IonAvatar, _angular_common__WEBPACK_IMPORTED_MODULE_23__.NgIf, _ionic_angular__WEBPACK_IMPORTED_MODULE_22__.IonGrid, _ionic_angular__WEBPACK_IMPORTED_MODULE_22__.IonRow, _ionic_angular__WEBPACK_IMPORTED_MODULE_22__.IonCol, _core_shared_globalization_ordinal_number_ordinal_number_component__WEBPACK_IMPORTED_MODULE_12__.OrdinalNumberComponent, _core_shared_ui_icon_icon_component__WEBPACK_IMPORTED_MODULE_13__.IconComponent, _ionic_angular__WEBPACK_IMPORTED_MODULE_22__.IonIcon, _angular_common__WEBPACK_IMPORTED_MODULE_23__.NgForOf],
  pipes: [_angular_common__WEBPACK_IMPORTED_MODULE_23__.AsyncPipe, _ngx_translate_core__WEBPACK_IMPORTED_MODULE_24__.TranslatePipe, _core_shared_pipes_localNumber_pipe__WEBPACK_IMPORTED_MODULE_14__.LocalNumberPipe],
  styles: [".user-intro[_ngcontent-%COMP%] {\n  padding: 30px;\n}\n.user-intro[_ngcontent-%COMP%]   .team[_ngcontent-%COMP%] {\n  width: 150px;\n  height: 150px;\n  margin: auto;\n  border: solid 2px var(--ion-color-school);\n}\n.user-intro[_ngcontent-%COMP%]   .nickname[_ngcontent-%COMP%] {\n  margin-top: 32px;\n}\n.team[_ngcontent-%COMP%]   .myTeam[_ngcontent-%COMP%]   ion-row[_ngcontent-%COMP%] {\n  border-bottom: solid grey;\n}\n.team[_ngcontent-%COMP%]   .myTeam[_ngcontent-%COMP%]   .player-not-subscribed[_ngcontent-%COMP%] {\n  background-color: #f3f3f3;\n}\n.team[_ngcontent-%COMP%]   .myTeam[_ngcontent-%COMP%]   .player-not-subscribed[_ngcontent-%COMP%]   .opaque[_ngcontent-%COMP%] {\n  opacity: 0.5;\n}\n.team[_ngcontent-%COMP%]   .myTeam[_ngcontent-%COMP%]   .player-not-subscribed[_ngcontent-%COMP%]   .label-not-subscribed[_ngcontent-%COMP%] {\n  font-size: 13px;\n  font-weight: 300;\n  font-style: italic;\n  color: var(--dark-grey);\n}\n.team[_ngcontent-%COMP%]   .team-detail[_ngcontent-%COMP%] {\n  line-height: 15px;\n  display: flex;\n  justify-content: normal;\n  align-items: center;\n}\n.team[_ngcontent-%COMP%]   .player-detail[_ngcontent-%COMP%] {\n  line-height: 15px;\n  display: flex;\n  justify-content: flex-end;\n  align-items: center;\n}\n.team[_ngcontent-%COMP%]   .institute[_ngcontent-%COMP%] {\n  font-size: 13px;\n  font-style: italic;\n  font-weight: 300;\n  line-height: 15px;\n  letter-spacing: 0px;\n  text-align: left;\n}\n.team[_ngcontent-%COMP%]   .members[_ngcontent-%COMP%] {\n  font-size: 13px;\n  font-weight: 300;\n  line-height: 15px;\n  letter-spacing: 0px;\n  text-align: left;\n}\n.team[_ngcontent-%COMP%]   .name[_ngcontent-%COMP%] {\n  font-size: 18px;\n  font-weight: 600;\n  line-height: 21px;\n  letter-spacing: 0px;\n  text-align: left;\n}\n.team[_ngcontent-%COMP%]   .nickname[_ngcontent-%COMP%] {\n  text-overflow: ellipsis;\n  white-space: nowrap;\n  overflow: hidden;\n}\n.team[_ngcontent-%COMP%]   ion-row[_ngcontent-%COMP%] {\n  align-items: center;\n}\n.team[_ngcontent-%COMP%]   ion-avatar[_ngcontent-%COMP%] {\n  max-width: 40px;\n  max-height: 40px;\n}\n.team[_ngcontent-%COMP%]   ion-icon[_ngcontent-%COMP%] {\n  width: 45px;\n  height: 45px;\n}\n.big-icon[_ngcontent-%COMP%] {\n  font-size: 64px;\n}\napp-icon[_ngcontent-%COMP%] {\n  margin: 0px 4px;\n}\n/*# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbInRlYW0tcHJvZmlsZS5wYWdlLnNjc3MiXSwibmFtZXMiOltdLCJtYXBwaW5ncyI6IkFBQUE7RUFDRSxhQUFBO0FBQ0Y7QUFBRTtFQUNFLFlBQUE7RUFDQSxhQUFBO0VBQ0EsWUFBQTtFQUNBLHlDQUFBO0FBRUo7QUFBRTtFQUNFLGdCQUFBO0FBRUo7QUFHSTtFQUNFLHlCQUFBO0FBQU47QUFFSTtFQUNFLHlCQUFBO0FBQU47QUFDTTtFQUNFLFlBQUE7QUFDUjtBQUNNO0VBQ0UsZUFBQTtFQUNBLGdCQUFBO0VBQ0Esa0JBQUE7RUFDQSx1QkFBQTtBQUNSO0FBR0U7RUFDRSxpQkFBQTtFQUNBLGFBQUE7RUFDQSx1QkFBQTtFQUNBLG1CQUFBO0FBREo7QUFHRTtFQUNFLGlCQUFBO0VBQ0EsYUFBQTtFQUNBLHlCQUFBO0VBQ0EsbUJBQUE7QUFESjtBQUdFO0VBQ0UsZUFBQTtFQUNBLGtCQUFBO0VBQ0EsZ0JBQUE7RUFDQSxpQkFBQTtFQUNBLG1CQUFBO0VBQ0EsZ0JBQUE7QUFESjtBQUdFO0VBQ0UsZUFBQTtFQUNBLGdCQUFBO0VBQ0EsaUJBQUE7RUFDQSxtQkFBQTtFQUNBLGdCQUFBO0FBREo7QUFHRTtFQUNFLGVBQUE7RUFDQSxnQkFBQTtFQUNBLGlCQUFBO0VBQ0EsbUJBQUE7RUFDQSxnQkFBQTtBQURKO0FBSUU7RUFDRSx1QkFBQTtFQUNBLG1CQUFBO0VBQ0EsZ0JBQUE7QUFGSjtBQUlFO0VBQ0UsbUJBQUE7QUFGSjtBQUlFO0VBQ0UsZUFBQTtFQUNBLGdCQUFBO0FBRko7QUFJRTtFQUNFLFdBQUE7RUFDQSxZQUFBO0FBRko7QUFLQTtFQUNFLGVBQUE7QUFGRjtBQUlBO0VBQ0UsZUFBQTtBQURGIiwiZmlsZSI6InRlYW0tcHJvZmlsZS5wYWdlLnNjc3MiLCJzb3VyY2VzQ29udGVudCI6WyIudXNlci1pbnRybyB7XG4gIHBhZGRpbmc6IDMwcHg7XG4gIC50ZWFtIHtcbiAgICB3aWR0aDogMTUwcHg7XG4gICAgaGVpZ2h0OiAxNTBweDtcbiAgICBtYXJnaW46IGF1dG87XG4gICAgYm9yZGVyOiBzb2xpZCAycHggdmFyKC0taW9uLWNvbG9yLXNjaG9vbCk7XG4gIH1cbiAgLm5pY2tuYW1lIHtcbiAgICBtYXJnaW4tdG9wOiAzMnB4O1xuICB9XG59XG4udGVhbSB7XG4gIC5teVRlYW0ge1xuICAgIGlvbi1yb3cge1xuICAgICAgYm9yZGVyLWJvdHRvbTogc29saWQgZ3JleTtcbiAgICB9XG4gICAgLnBsYXllci1ub3Qtc3Vic2NyaWJlZCB7XG4gICAgICBiYWNrZ3JvdW5kLWNvbG9yOiAjZjNmM2YzO1xuICAgICAgLm9wYXF1ZSB7XG4gICAgICAgIG9wYWNpdHk6IDAuNTtcbiAgICAgIH1cbiAgICAgIC5sYWJlbC1ub3Qtc3Vic2NyaWJlZCB7XG4gICAgICAgIGZvbnQtc2l6ZTogMTNweDtcbiAgICAgICAgZm9udC13ZWlnaHQ6IDMwMDtcbiAgICAgICAgZm9udC1zdHlsZTogaXRhbGljO1xuICAgICAgICBjb2xvcjogdmFyKC0tZGFyay1ncmV5KTtcbiAgICAgIH1cbiAgICB9XG4gIH1cbiAgLnRlYW0tZGV0YWlsIHtcbiAgICBsaW5lLWhlaWdodDogMTVweDtcbiAgICBkaXNwbGF5OiBmbGV4O1xuICAgIGp1c3RpZnktY29udGVudDogbm9ybWFsO1xuICAgIGFsaWduLWl0ZW1zOiBjZW50ZXI7XG4gIH1cbiAgLnBsYXllci1kZXRhaWwge1xuICAgIGxpbmUtaGVpZ2h0OiAxNXB4O1xuICAgIGRpc3BsYXk6IGZsZXg7XG4gICAganVzdGlmeS1jb250ZW50OiBmbGV4LWVuZDtcbiAgICBhbGlnbi1pdGVtczogY2VudGVyO1xuICB9XG4gIC5pbnN0aXR1dGUge1xuICAgIGZvbnQtc2l6ZTogMTNweDtcbiAgICBmb250LXN0eWxlOiBpdGFsaWM7XG4gICAgZm9udC13ZWlnaHQ6IDMwMDtcbiAgICBsaW5lLWhlaWdodDogMTVweDtcbiAgICBsZXR0ZXItc3BhY2luZzogMHB4O1xuICAgIHRleHQtYWxpZ246IGxlZnQ7XG4gIH1cbiAgLm1lbWJlcnMge1xuICAgIGZvbnQtc2l6ZTogMTNweDtcbiAgICBmb250LXdlaWdodDogMzAwO1xuICAgIGxpbmUtaGVpZ2h0OiAxNXB4O1xuICAgIGxldHRlci1zcGFjaW5nOiAwcHg7XG4gICAgdGV4dC1hbGlnbjogbGVmdDtcbiAgfVxuICAubmFtZSB7XG4gICAgZm9udC1zaXplOiAxOHB4O1xuICAgIGZvbnQtd2VpZ2h0OiA2MDA7XG4gICAgbGluZS1oZWlnaHQ6IDIxcHg7XG4gICAgbGV0dGVyLXNwYWNpbmc6IDBweDtcbiAgICB0ZXh0LWFsaWduOiBsZWZ0O1xuICB9XG5cbiAgLm5pY2tuYW1lIHtcbiAgICB0ZXh0LW92ZXJmbG93OiBlbGxpcHNpcztcbiAgICB3aGl0ZS1zcGFjZTogbm93cmFwO1xuICAgIG92ZXJmbG93OiBoaWRkZW47XG4gIH1cbiAgaW9uLXJvdyB7XG4gICAgYWxpZ24taXRlbXM6IGNlbnRlcjtcbiAgfVxuICBpb24tYXZhdGFyIHtcbiAgICBtYXgtd2lkdGg6IDQwcHg7XG4gICAgbWF4LWhlaWdodDogNDBweDtcbiAgfVxuICBpb24taWNvbiB7XG4gICAgd2lkdGg6IDQ1cHg7XG4gICAgaGVpZ2h0OiA0NXB4O1xuICB9XG59XG4uYmlnLWljb24ge1xuICBmb250LXNpemU6IDY0cHg7XG59XG5hcHAtaWNvbiB7XG4gIG1hcmdpbjogMHB4IDRweDtcbn1cbiJdfQ== */"]
});

/***/ })

}]);
//# sourceMappingURL=src_app_pages_team-profile_team-profile_module_ts.js.map