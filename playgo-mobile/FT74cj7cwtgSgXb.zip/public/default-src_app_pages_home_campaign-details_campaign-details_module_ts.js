"use strict";
(self["webpackChunkapp"] = self["webpackChunkapp"] || []).push([["default-src_app_pages_home_campaign-details_campaign-details_module_ts"],{

/***/ 92310:
/*!********************************************************************************!*\
  !*** ./src/app/pages/home/campaign-details/campaign-details-routing.module.ts ***!
  \********************************************************************************/
/***/ (function(__unused_webpack_module, __webpack_exports__, __webpack_require__) {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "CampaignDetailsPageRoutingModule": function() { return /* binding */ CampaignDetailsPageRoutingModule; }
/* harmony export */ });
/* harmony import */ var _Users_smartcommunitylab_Desktop_newWork_dslab_playgo_mobile_playgo_mobile_node_modules_babel_runtime_helpers_esm_createClass_js__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./node_modules/@babel/runtime/helpers/esm/createClass.js */ 48047);
/* harmony import */ var _Users_smartcommunitylab_Desktop_newWork_dslab_playgo_mobile_playgo_mobile_node_modules_babel_runtime_helpers_esm_classCallCheck_js__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ./node_modules/@babel/runtime/helpers/esm/classCallCheck.js */ 78069);
/* harmony import */ var _angular_router__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! @angular/router */ 52816);
/* harmony import */ var _campaign_details_page__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! ./campaign-details.page */ 69003);
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @angular/core */ 3184);






var routes = [{
  path: '',
  component: _campaign_details_page__WEBPACK_IMPORTED_MODULE_2__.CampaignDetailsPage,
  data: {
    title: '',
    customHeader: true,
    showPlayButton: true,
    backButton: true
  }
}, {
  path: 'leaderboard',
  loadChildren: function loadChildren() {
    return __webpack_require__.e(/*! import() */ "src_app_pages_home_campaign-details_leaderboard_leaderboard_module_ts").then(__webpack_require__.bind(__webpack_require__, /*! ./leaderboard/leaderboard.module */ 28285)).then(function (m) {
      return m.LeaderboardModule;
    });
  }
}, {
  path: 'school-leaderboard',
  loadChildren: function loadChildren() {
    return __webpack_require__.e(/*! import() */ "src_app_pages_home_campaign-details_school-leaderboard_school-leaderboard_module_ts").then(__webpack_require__.bind(__webpack_require__, /*! ./school-leaderboard/school-leaderboard.module */ 67379)).then(function (m) {
      return m.SchoolLeaderboardPageModule;
    });
  }
}, {
  path: 'prizes',
  loadChildren: function loadChildren() {
    return __webpack_require__.e(/*! import() */ "src_app_pages_home_campaign-details_prizes_prizes_module_ts").then(__webpack_require__.bind(__webpack_require__, /*! ./prizes/prizes.module */ 91775)).then(function (m) {
      return m.PrizesPageModule;
    });
  }
}, {
  path: 'stats',
  loadChildren: function loadChildren() {
    return Promise.all(/*! import() */[__webpack_require__.e("default-node_modules_chart_js_dist_chart_mjs"), __webpack_require__.e("src_app_pages_home_campaign-details_stats_stats_module_ts")]).then(__webpack_require__.bind(__webpack_require__, /*! ./stats/stats.module */ 18533)).then(function (m) {
      return m.StatsPageModule;
    });
  }
}, {
  path: 'stats-team',
  loadChildren: function loadChildren() {
    return Promise.all(/*! import() */[__webpack_require__.e("default-node_modules_chart_js_dist_chart_mjs"), __webpack_require__.e("common"), __webpack_require__.e("src_app_pages_home_campaign-details_stats-team_stats-team_module_ts")]).then(__webpack_require__.bind(__webpack_require__, /*! ./stats-team/stats-team.module */ 1346)).then(function (m) {
      return m.StatsTeamPageModule;
    });
  }
}, {
  path: 'faq',
  loadChildren: function loadChildren() {
    return __webpack_require__.e(/*! import() */ "src_app_pages_home_campaign-details_faq_faq_module_ts").then(__webpack_require__.bind(__webpack_require__, /*! ./faq/faq.module */ 35959)).then(function (m) {
      return m.FaqPageModule;
    });
  }
}, {
  path: 'badges',
  loadChildren: function loadChildren() {
    return __webpack_require__.e(/*! import() */ "src_app_pages_home_campaign-details_badges_badges_module_ts").then(__webpack_require__.bind(__webpack_require__, /*! ./badges/badges.module */ 31573)).then(function (m) {
      return m.BadgesPageModule;
    });
  }
}, {
  path: 'companies',
  loadChildren: function loadChildren() {
    return __webpack_require__.e(/*! import() */ "src_app_pages_home_campaign-details_companies_companies_module_ts").then(__webpack_require__.bind(__webpack_require__, /*! ./companies/companies.module */ 95177)).then(function (m) {
      return m.CompaniesPageModule;
    });
  }
}];
var CampaignDetailsPageRoutingModule = /*#__PURE__*/(0,_Users_smartcommunitylab_Desktop_newWork_dslab_playgo_mobile_playgo_mobile_node_modules_babel_runtime_helpers_esm_createClass_js__WEBPACK_IMPORTED_MODULE_0__["default"])(function CampaignDetailsPageRoutingModule() {
  (0,_Users_smartcommunitylab_Desktop_newWork_dslab_playgo_mobile_playgo_mobile_node_modules_babel_runtime_helpers_esm_classCallCheck_js__WEBPACK_IMPORTED_MODULE_1__["default"])(this, CampaignDetailsPageRoutingModule);
});

CampaignDetailsPageRoutingModule.ɵfac = function CampaignDetailsPageRoutingModule_Factory(t) {
  return new (t || CampaignDetailsPageRoutingModule)();
};

CampaignDetailsPageRoutingModule.ɵmod = /*@__PURE__*/_angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵdefineNgModule"]({
  type: CampaignDetailsPageRoutingModule
});
CampaignDetailsPageRoutingModule.ɵinj = /*@__PURE__*/_angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵdefineInjector"]({
  imports: [[_angular_router__WEBPACK_IMPORTED_MODULE_4__.RouterModule.forChild(routes)], _angular_router__WEBPACK_IMPORTED_MODULE_4__.RouterModule]
});

(function () {
  (typeof ngJitMode === "undefined" || ngJitMode) && _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵsetNgModuleScope"](CampaignDetailsPageRoutingModule, {
    imports: [_angular_router__WEBPACK_IMPORTED_MODULE_4__.RouterModule],
    exports: [_angular_router__WEBPACK_IMPORTED_MODULE_4__.RouterModule]
  });
})();

/***/ }),

/***/ 51818:
/*!************************************************************************!*\
  !*** ./src/app/pages/home/campaign-details/campaign-details.module.ts ***!
  \************************************************************************/
/***/ (function(__unused_webpack_module, __webpack_exports__, __webpack_require__) {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "CampaignDetailsPageModule": function() { return /* binding */ CampaignDetailsPageModule; }
/* harmony export */ });
/* harmony import */ var _Users_smartcommunitylab_Desktop_newWork_dslab_playgo_mobile_playgo_mobile_node_modules_babel_runtime_helpers_esm_createClass_js__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./node_modules/@babel/runtime/helpers/esm/createClass.js */ 48047);
/* harmony import */ var _Users_smartcommunitylab_Desktop_newWork_dslab_playgo_mobile_playgo_mobile_node_modules_babel_runtime_helpers_esm_classCallCheck_js__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ./node_modules/@babel/runtime/helpers/esm/classCallCheck.js */ 78069);
/* harmony import */ var _campaign_details_routing_module__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! ./campaign-details-routing.module */ 92310);
/* harmony import */ var _campaign_details_page__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! ./campaign-details.page */ 69003);
/* harmony import */ var src_app_core_shared_shared_module__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! src/app/core/shared/shared.module */ 97205);
/* harmony import */ var _detail_modal_detail_modal__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! ./detail-modal/detail.modal */ 30451);
/* harmony import */ var _campaign_notification_campaign_notification_component__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! ./campaign-notification/campaign-notification.component */ 48058);
/* harmony import */ var _unsubscribe_modal_unsubscribe_modal__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(/*! ./unsubscribe-modal/unsubscribe.modal */ 57164);
/* harmony import */ var _companies_modal_companies_modal__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(/*! ./companies-modal/companies.modal */ 88043);
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_9__ = __webpack_require__(/*! @angular/core */ 3184);










var CampaignDetailsPageModule = /*#__PURE__*/(0,_Users_smartcommunitylab_Desktop_newWork_dslab_playgo_mobile_playgo_mobile_node_modules_babel_runtime_helpers_esm_createClass_js__WEBPACK_IMPORTED_MODULE_0__["default"])(function CampaignDetailsPageModule() {
  (0,_Users_smartcommunitylab_Desktop_newWork_dslab_playgo_mobile_playgo_mobile_node_modules_babel_runtime_helpers_esm_classCallCheck_js__WEBPACK_IMPORTED_MODULE_1__["default"])(this, CampaignDetailsPageModule);
});

CampaignDetailsPageModule.ɵfac = function CampaignDetailsPageModule_Factory(t) {
  return new (t || CampaignDetailsPageModule)();
};

CampaignDetailsPageModule.ɵmod = /*@__PURE__*/_angular_core__WEBPACK_IMPORTED_MODULE_9__["ɵɵdefineNgModule"]({
  type: CampaignDetailsPageModule
});
CampaignDetailsPageModule.ɵinj = /*@__PURE__*/_angular_core__WEBPACK_IMPORTED_MODULE_9__["ɵɵdefineInjector"]({
  imports: [[_campaign_details_routing_module__WEBPACK_IMPORTED_MODULE_2__.CampaignDetailsPageRoutingModule, src_app_core_shared_shared_module__WEBPACK_IMPORTED_MODULE_4__.PlayGoSharedModule]]
});

(function () {
  (typeof ngJitMode === "undefined" || ngJitMode) && _angular_core__WEBPACK_IMPORTED_MODULE_9__["ɵɵsetNgModuleScope"](CampaignDetailsPageModule, {
    declarations: [_campaign_details_page__WEBPACK_IMPORTED_MODULE_3__.CampaignDetailsPage, _detail_modal_detail_modal__WEBPACK_IMPORTED_MODULE_5__.DetailCampaignModalPage, _companies_modal_companies_modal__WEBPACK_IMPORTED_MODULE_8__.CompaniesCampaignModalPage, _campaign_notification_campaign_notification_component__WEBPACK_IMPORTED_MODULE_6__.CampaignNotificationComponent, _unsubscribe_modal_unsubscribe_modal__WEBPACK_IMPORTED_MODULE_7__.UnsubscribeModalPage],
    imports: [_campaign_details_routing_module__WEBPACK_IMPORTED_MODULE_2__.CampaignDetailsPageRoutingModule, src_app_core_shared_shared_module__WEBPACK_IMPORTED_MODULE_4__.PlayGoSharedModule]
  });
})();

/***/ }),

/***/ 69003:
/*!**********************************************************************!*\
  !*** ./src/app/pages/home/campaign-details/campaign-details.page.ts ***!
  \**********************************************************************/
/***/ (function(__unused_webpack_module, __webpack_exports__, __webpack_require__) {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "CampaignDetailsPage": function() { return /* binding */ CampaignDetailsPage; }
/* harmony export */ });
/* harmony import */ var _Users_smartcommunitylab_Desktop_newWork_dslab_playgo_mobile_playgo_mobile_node_modules_babel_runtime_helpers_esm_slicedToArray_js__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./node_modules/@babel/runtime/helpers/esm/slicedToArray.js */ 10507);
/* harmony import */ var _Users_smartcommunitylab_Desktop_newWork_dslab_playgo_mobile_playgo_mobile_node_modules_babel_runtime_helpers_esm_classCallCheck_js__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ./node_modules/@babel/runtime/helpers/esm/classCallCheck.js */ 78069);
/* harmony import */ var _Users_smartcommunitylab_Desktop_newWork_dslab_playgo_mobile_playgo_mobile_node_modules_babel_runtime_helpers_esm_createClass_js__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! ./node_modules/@babel/runtime/helpers/esm/createClass.js */ 48047);
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_35__ = __webpack_require__(/*! tslib */ 42321);
/* harmony import */ var _detail_modal_detail_modal__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! ./detail-modal/detail.modal */ 30451);
/* harmony import */ var rxjs__WEBPACK_IMPORTED_MODULE_24__ = __webpack_require__(/*! rxjs */ 80228);
/* harmony import */ var rxjs__WEBPACK_IMPORTED_MODULE_25__ = __webpack_require__(/*! rxjs */ 50635);
/* harmony import */ var rxjs__WEBPACK_IMPORTED_MODULE_26__ = __webpack_require__(/*! rxjs */ 98977);
/* harmony import */ var rxjs__WEBPACK_IMPORTED_MODULE_27__ = __webpack_require__(/*! rxjs */ 89196);
/* harmony import */ var rxjs__WEBPACK_IMPORTED_MODULE_28__ = __webpack_require__(/*! rxjs */ 32673);
/* harmony import */ var rxjs__WEBPACK_IMPORTED_MODULE_30__ = __webpack_require__(/*! rxjs */ 19337);
/* harmony import */ var rxjs__WEBPACK_IMPORTED_MODULE_31__ = __webpack_require__(/*! rxjs */ 26562);
/* harmony import */ var rxjs__WEBPACK_IMPORTED_MODULE_32__ = __webpack_require__(/*! rxjs */ 20591);
/* harmony import */ var rxjs__WEBPACK_IMPORTED_MODULE_33__ = __webpack_require__(/*! rxjs */ 68951);
/* harmony import */ var rxjs__WEBPACK_IMPORTED_MODULE_34__ = __webpack_require__(/*! rxjs */ 10745);
/* harmony import */ var _unsubscribe_modal_unsubscribe_modal__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! ./unsubscribe-modal/unsubscribe.modal */ 57164);
/* harmony import */ var src_app_core_shared_rxjs_utils__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! src/app/core/shared/rxjs.utils */ 9257);
/* harmony import */ var src_environments_environment__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! src/environments/environment */ 92340);
/* harmony import */ var src_app_core_shared_services_error_service__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(/*! src/app/core/shared/services/error.service */ 96204);
/* harmony import */ var _companies_modal_companies_modal__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(/*! ./companies-modal/companies.modal */ 88043);
/* harmony import */ var lodash_es__WEBPACK_IMPORTED_MODULE_29__ = __webpack_require__(/*! lodash-es */ 97732);
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_23__ = __webpack_require__(/*! @angular/core */ 3184);
/* harmony import */ var _angular_router__WEBPACK_IMPORTED_MODULE_36__ = __webpack_require__(/*! @angular/router */ 52816);
/* harmony import */ var src_app_core_shared_services_campaign_service__WEBPACK_IMPORTED_MODULE_9__ = __webpack_require__(/*! src/app/core/shared/services/campaign.service */ 23645);
/* harmony import */ var src_app_core_shared_services_alert_service__WEBPACK_IMPORTED_MODULE_10__ = __webpack_require__(/*! src/app/core/shared/services/alert.service */ 46407);
/* harmony import */ var src_app_core_shared_services_user_service__WEBPACK_IMPORTED_MODULE_11__ = __webpack_require__(/*! src/app/core/shared/services/user.service */ 50749);
/* harmony import */ var _ionic_angular__WEBPACK_IMPORTED_MODULE_37__ = __webpack_require__(/*! @ionic/angular */ 93819);
/* harmony import */ var src_app_core_shared_services_notifications_notifications_service__WEBPACK_IMPORTED_MODULE_12__ = __webpack_require__(/*! src/app/core/shared/services/notifications/notifications.service */ 30299);
/* harmony import */ var src_app_core_shared_services_page_settings_service__WEBPACK_IMPORTED_MODULE_13__ = __webpack_require__(/*! src/app/core/shared/services/page-settings.service */ 85294);
/* harmony import */ var src_app_core_shared_services_team_service__WEBPACK_IMPORTED_MODULE_14__ = __webpack_require__(/*! src/app/core/shared/services/team.service */ 86612);
/* harmony import */ var _angular_common__WEBPACK_IMPORTED_MODULE_38__ = __webpack_require__(/*! @angular/common */ 36362);
/* harmony import */ var _core_shared_directives_parallax_header_directive__WEBPACK_IMPORTED_MODULE_15__ = __webpack_require__(/*! ../../../core/shared/directives/parallax-header.directive */ 2773);
/* harmony import */ var _core_shared_layout_header_header_directive__WEBPACK_IMPORTED_MODULE_16__ = __webpack_require__(/*! ../../../core/shared/layout/header/header.directive */ 34161);
/* harmony import */ var _core_shared_layout_content_content_directive__WEBPACK_IMPORTED_MODULE_17__ = __webpack_require__(/*! ../../../core/shared/layout/content/content.directive */ 69669);
/* harmony import */ var _core_shared_campaigns_app_widget_campaign_app_widget_campaign_component__WEBPACK_IMPORTED_MODULE_18__ = __webpack_require__(/*! ../../../core/shared/campaigns/app-widget-campaign/app-widget-campaign.component */ 519);
/* harmony import */ var _campaign_notification_campaign_notification_component__WEBPACK_IMPORTED_MODULE_19__ = __webpack_require__(/*! ./campaign-notification/campaign-notification.component */ 48058);
/* harmony import */ var _core_shared_ui_icon_icon_component__WEBPACK_IMPORTED_MODULE_20__ = __webpack_require__(/*! ../../../core/shared/ui/icon/icon.component */ 71888);
/* harmony import */ var _core_shared_pipes_localDate_pipe__WEBPACK_IMPORTED_MODULE_21__ = __webpack_require__(/*! ../../../core/shared/pipes/localDate.pipe */ 34489);
/* harmony import */ var _ngx_translate_core__WEBPACK_IMPORTED_MODULE_39__ = __webpack_require__(/*! @ngx-translate/core */ 87514);
/* harmony import */ var _core_shared_pipes_languageMap_pipe__WEBPACK_IMPORTED_MODULE_22__ = __webpack_require__(/*! ../../../core/shared/pipes/languageMap.pipe */ 73088);




function _regeneratorRuntime() { "use strict"; /*! regenerator-runtime -- Copyright (c) 2014-present, Facebook, Inc. -- license (MIT): https://github.com/facebook/regenerator/blob/main/LICENSE */ _regeneratorRuntime = function _regeneratorRuntime() { return e; }; var t, e = {}, r = Object.prototype, n = r.hasOwnProperty, o = Object.defineProperty || function (t, e, r) { t[e] = r.value; }, i = "function" == typeof Symbol ? Symbol : {}, a = i.iterator || "@@iterator", c = i.asyncIterator || "@@asyncIterator", u = i.toStringTag || "@@toStringTag"; function define(t, e, r) { return Object.defineProperty(t, e, { value: r, enumerable: !0, configurable: !0, writable: !0 }), t[e]; } try { define({}, ""); } catch (t) { define = function define(t, e, r) { return t[e] = r; }; } function wrap(t, e, r, n) { var i = e && e.prototype instanceof Generator ? e : Generator, a = Object.create(i.prototype), c = new Context(n || []); return o(a, "_invoke", { value: makeInvokeMethod(t, r, c) }), a; } function tryCatch(t, e, r) { try { return { type: "normal", arg: t.call(e, r) }; } catch (t) { return { type: "throw", arg: t }; } } e.wrap = wrap; var h = "suspendedStart", l = "suspendedYield", f = "executing", s = "completed", y = {}; function Generator() {} function GeneratorFunction() {} function GeneratorFunctionPrototype() {} var p = {}; define(p, a, function () { return this; }); var d = Object.getPrototypeOf, v = d && d(d(values([]))); v && v !== r && n.call(v, a) && (p = v); var g = GeneratorFunctionPrototype.prototype = Generator.prototype = Object.create(p); function defineIteratorMethods(t) { ["next", "throw", "return"].forEach(function (e) { define(t, e, function (t) { return this._invoke(e, t); }); }); } function AsyncIterator(t, e) { function invoke(r, o, i, a) { var c = tryCatch(t[r], t, o); if ("throw" !== c.type) { var u = c.arg, h = u.value; return h && "object" == typeof h && n.call(h, "__await") ? e.resolve(h.__await).then(function (t) { invoke("next", t, i, a); }, function (t) { invoke("throw", t, i, a); }) : e.resolve(h).then(function (t) { u.value = t, i(u); }, function (t) { return invoke("throw", t, i, a); }); } a(c.arg); } var r; o(this, "_invoke", { value: function value(t, n) { function callInvokeWithMethodAndArg() { return new e(function (e, r) { invoke(t, n, e, r); }); } return r = r ? r.then(callInvokeWithMethodAndArg, callInvokeWithMethodAndArg) : callInvokeWithMethodAndArg(); } }); } function makeInvokeMethod(e, r, n) { var o = h; return function (i, a) { if (o === f) throw new Error("Generator is already running"); if (o === s) { if ("throw" === i) throw a; return { value: t, done: !0 }; } for (n.method = i, n.arg = a;;) { var c = n.delegate; if (c) { var u = maybeInvokeDelegate(c, n); if (u) { if (u === y) continue; return u; } } if ("next" === n.method) n.sent = n._sent = n.arg;else if ("throw" === n.method) { if (o === h) throw o = s, n.arg; n.dispatchException(n.arg); } else "return" === n.method && n.abrupt("return", n.arg); o = f; var p = tryCatch(e, r, n); if ("normal" === p.type) { if (o = n.done ? s : l, p.arg === y) continue; return { value: p.arg, done: n.done }; } "throw" === p.type && (o = s, n.method = "throw", n.arg = p.arg); } }; } function maybeInvokeDelegate(e, r) { var n = r.method, o = e.iterator[n]; if (o === t) return r.delegate = null, "throw" === n && e.iterator.return && (r.method = "return", r.arg = t, maybeInvokeDelegate(e, r), "throw" === r.method) || "return" !== n && (r.method = "throw", r.arg = new TypeError("The iterator does not provide a '" + n + "' method")), y; var i = tryCatch(o, e.iterator, r.arg); if ("throw" === i.type) return r.method = "throw", r.arg = i.arg, r.delegate = null, y; var a = i.arg; return a ? a.done ? (r[e.resultName] = a.value, r.next = e.nextLoc, "return" !== r.method && (r.method = "next", r.arg = t), r.delegate = null, y) : a : (r.method = "throw", r.arg = new TypeError("iterator result is not an object"), r.delegate = null, y); } function pushTryEntry(t) { var e = { tryLoc: t[0] }; 1 in t && (e.catchLoc = t[1]), 2 in t && (e.finallyLoc = t[2], e.afterLoc = t[3]), this.tryEntries.push(e); } function resetTryEntry(t) { var e = t.completion || {}; e.type = "normal", delete e.arg, t.completion = e; } function Context(t) { this.tryEntries = [{ tryLoc: "root" }], t.forEach(pushTryEntry, this), this.reset(!0); } function values(e) { if (e || "" === e) { var r = e[a]; if (r) return r.call(e); if ("function" == typeof e.next) return e; if (!isNaN(e.length)) { var o = -1, i = function next() { for (; ++o < e.length;) if (n.call(e, o)) return next.value = e[o], next.done = !1, next; return next.value = t, next.done = !0, next; }; return i.next = i; } } throw new TypeError(typeof e + " is not iterable"); } return GeneratorFunction.prototype = GeneratorFunctionPrototype, o(g, "constructor", { value: GeneratorFunctionPrototype, configurable: !0 }), o(GeneratorFunctionPrototype, "constructor", { value: GeneratorFunction, configurable: !0 }), GeneratorFunction.displayName = define(GeneratorFunctionPrototype, u, "GeneratorFunction"), e.isGeneratorFunction = function (t) { var e = "function" == typeof t && t.constructor; return !!e && (e === GeneratorFunction || "GeneratorFunction" === (e.displayName || e.name)); }, e.mark = function (t) { return Object.setPrototypeOf ? Object.setPrototypeOf(t, GeneratorFunctionPrototype) : (t.__proto__ = GeneratorFunctionPrototype, define(t, u, "GeneratorFunction")), t.prototype = Object.create(g), t; }, e.awrap = function (t) { return { __await: t }; }, defineIteratorMethods(AsyncIterator.prototype), define(AsyncIterator.prototype, c, function () { return this; }), e.AsyncIterator = AsyncIterator, e.async = function (t, r, n, o, i) { void 0 === i && (i = Promise); var a = new AsyncIterator(wrap(t, r, n, o), i); return e.isGeneratorFunction(r) ? a : a.next().then(function (t) { return t.done ? t.value : a.next(); }); }, defineIteratorMethods(g), define(g, u, "Generator"), define(g, a, function () { return this; }), define(g, "toString", function () { return "[object Generator]"; }), e.keys = function (t) { var e = Object(t), r = []; for (var n in e) r.push(n); return r.reverse(), function next() { for (; r.length;) { var t = r.pop(); if (t in e) return next.value = t, next.done = !1, next; } return next.done = !0, next; }; }, e.values = values, Context.prototype = { constructor: Context, reset: function reset(e) { if (this.prev = 0, this.next = 0, this.sent = this._sent = t, this.done = !1, this.delegate = null, this.method = "next", this.arg = t, this.tryEntries.forEach(resetTryEntry), !e) for (var r in this) "t" === r.charAt(0) && n.call(this, r) && !isNaN(+r.slice(1)) && (this[r] = t); }, stop: function stop() { this.done = !0; var t = this.tryEntries[0].completion; if ("throw" === t.type) throw t.arg; return this.rval; }, dispatchException: function dispatchException(e) { if (this.done) throw e; var r = this; function handle(n, o) { return a.type = "throw", a.arg = e, r.next = n, o && (r.method = "next", r.arg = t), !!o; } for (var o = this.tryEntries.length - 1; o >= 0; --o) { var i = this.tryEntries[o], a = i.completion; if ("root" === i.tryLoc) return handle("end"); if (i.tryLoc <= this.prev) { var c = n.call(i, "catchLoc"), u = n.call(i, "finallyLoc"); if (c && u) { if (this.prev < i.catchLoc) return handle(i.catchLoc, !0); if (this.prev < i.finallyLoc) return handle(i.finallyLoc); } else if (c) { if (this.prev < i.catchLoc) return handle(i.catchLoc, !0); } else { if (!u) throw new Error("try statement without catch or finally"); if (this.prev < i.finallyLoc) return handle(i.finallyLoc); } } } }, abrupt: function abrupt(t, e) { for (var r = this.tryEntries.length - 1; r >= 0; --r) { var o = this.tryEntries[r]; if (o.tryLoc <= this.prev && n.call(o, "finallyLoc") && this.prev < o.finallyLoc) { var i = o; break; } } i && ("break" === t || "continue" === t) && i.tryLoc <= e && e <= i.finallyLoc && (i = null); var a = i ? i.completion : {}; return a.type = t, a.arg = e, i ? (this.method = "next", this.next = i.finallyLoc, y) : this.complete(a); }, complete: function complete(t, e) { if ("throw" === t.type) throw t.arg; return "break" === t.type || "continue" === t.type ? this.next = t.arg : "return" === t.type ? (this.rval = this.arg = t.arg, this.method = "return", this.next = "end") : "normal" === t.type && e && (this.next = e), y; }, finish: function finish(t) { for (var e = this.tryEntries.length - 1; e >= 0; --e) { var r = this.tryEntries[e]; if (r.finallyLoc === t) return this.complete(r.completion, r.afterLoc), resetTryEntry(r), y; } }, catch: function _catch(t) { for (var e = this.tryEntries.length - 1; e >= 0; --e) { var r = this.tryEntries[e]; if (r.tryLoc === t) { var n = r.completion; if ("throw" === n.type) { var o = n.arg; resetTryEntry(r); } return o; } } throw new Error("illegal catch attempt"); }, delegateYield: function delegateYield(e, r, n) { return this.delegate = { iterator: values(e), resultName: r, nextLoc: n }, "next" === this.method && (this.arg = t), y; } }, e; }






























var _c0 = ["ionContent"];
var _c1 = ["descText"];

function CampaignDetailsPage_ng_container_0_ion_content_4_ng_container_2_Template(rf, ctx) {
  if (rf & 1) {
    _angular_core__WEBPACK_IMPORTED_MODULE_23__["ɵɵelementContainerStart"](0);
    _angular_core__WEBPACK_IMPORTED_MODULE_23__["ɵɵelement"](1, "app-campaign-notification", 16);
    _angular_core__WEBPACK_IMPORTED_MODULE_23__["ɵɵelementContainerEnd"]();
  }

  if (rf & 2) {
    var notification_r16 = ctx.$implicit;
    var ctx_r2 = _angular_core__WEBPACK_IMPORTED_MODULE_23__["ɵɵnextContext"](3);
    _angular_core__WEBPACK_IMPORTED_MODULE_23__["ɵɵadvance"](1);
    _angular_core__WEBPACK_IMPORTED_MODULE_23__["ɵɵproperty"]("campaign", ctx_r2.campaignContainer)("notification", notification_r16);
  }
}

function CampaignDetailsPage_ng_container_0_ion_content_4_ion_card_3_Template(rf, ctx) {
  if (rf & 1) {
    _angular_core__WEBPACK_IMPORTED_MODULE_23__["ɵɵelementStart"](0, "ion-card", 7)(1, "ion-item", 8)(2, "ion-label");
    _angular_core__WEBPACK_IMPORTED_MODULE_23__["ɵɵtext"](3);
    _angular_core__WEBPACK_IMPORTED_MODULE_23__["ɵɵpipe"](4, "translate");
    _angular_core__WEBPACK_IMPORTED_MODULE_23__["ɵɵelementEnd"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_23__["ɵɵelement"](5, "app-icon", 17);
    _angular_core__WEBPACK_IMPORTED_MODULE_23__["ɵɵelementEnd"]()();
  }

  if (rf & 2) {
    var ctx_r3 = _angular_core__WEBPACK_IMPORTED_MODULE_23__["ɵɵnextContext"](3);
    _angular_core__WEBPACK_IMPORTED_MODULE_23__["ɵɵproperty"]("routerLink", ctx_r3.getLeaderboardLink());
    _angular_core__WEBPACK_IMPORTED_MODULE_23__["ɵɵadvance"](1);
    _angular_core__WEBPACK_IMPORTED_MODULE_23__["ɵɵproperty"]("color", ctx_r3.campaignContainer == null ? null : ctx_r3.campaignContainer.campaign == null ? null : ctx_r3.campaignContainer.campaign.type);
    _angular_core__WEBPACK_IMPORTED_MODULE_23__["ɵɵadvance"](2);
    _angular_core__WEBPACK_IMPORTED_MODULE_23__["ɵɵtextInterpolate1"]("", _angular_core__WEBPACK_IMPORTED_MODULE_23__["ɵɵpipeBind1"](4, 3, "campaigns.detail.leaderboard"), " ");
  }
}

var _c2 = function _c2(a0) {
  return [a0];
};

function CampaignDetailsPage_ng_container_0_ion_content_4_ion_card_4_Template(rf, ctx) {
  if (rf & 1) {
    _angular_core__WEBPACK_IMPORTED_MODULE_23__["ɵɵelementStart"](0, "ion-card", 7)(1, "ion-item", 8)(2, "ion-label");
    _angular_core__WEBPACK_IMPORTED_MODULE_23__["ɵɵtext"](3);
    _angular_core__WEBPACK_IMPORTED_MODULE_23__["ɵɵpipe"](4, "translate");
    _angular_core__WEBPACK_IMPORTED_MODULE_23__["ɵɵelementEnd"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_23__["ɵɵelement"](5, "app-icon", 18);
    _angular_core__WEBPACK_IMPORTED_MODULE_23__["ɵɵelementEnd"]()();
  }

  if (rf & 2) {
    var ctx_r4 = _angular_core__WEBPACK_IMPORTED_MODULE_23__["ɵɵnextContext"](3);
    _angular_core__WEBPACK_IMPORTED_MODULE_23__["ɵɵproperty"]("routerLink", _angular_core__WEBPACK_IMPORTED_MODULE_23__["ɵɵpureFunction1"](5, _c2, "/pages/tabs/home/details/" + ctx_r4.campaignContainer.campaign.campaignId + "/stats"));
    _angular_core__WEBPACK_IMPORTED_MODULE_23__["ɵɵadvance"](1);
    _angular_core__WEBPACK_IMPORTED_MODULE_23__["ɵɵproperty"]("color", ctx_r4.campaignContainer == null ? null : ctx_r4.campaignContainer.campaign == null ? null : ctx_r4.campaignContainer.campaign.type);
    _angular_core__WEBPACK_IMPORTED_MODULE_23__["ɵɵadvance"](2);
    _angular_core__WEBPACK_IMPORTED_MODULE_23__["ɵɵtextInterpolate1"]("", _angular_core__WEBPACK_IMPORTED_MODULE_23__["ɵɵpipeBind1"](4, 3, "campaigns.detail.stats"), " ");
  }
}

function CampaignDetailsPage_ng_container_0_ion_content_4_ion_card_5_Template(rf, ctx) {
  if (rf & 1) {
    _angular_core__WEBPACK_IMPORTED_MODULE_23__["ɵɵelementStart"](0, "ion-card", 7)(1, "ion-item", 8)(2, "ion-label");
    _angular_core__WEBPACK_IMPORTED_MODULE_23__["ɵɵtext"](3);
    _angular_core__WEBPACK_IMPORTED_MODULE_23__["ɵɵpipe"](4, "translate");
    _angular_core__WEBPACK_IMPORTED_MODULE_23__["ɵɵelementEnd"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_23__["ɵɵelement"](5, "app-icon", 18);
    _angular_core__WEBPACK_IMPORTED_MODULE_23__["ɵɵelementEnd"]()();
  }

  if (rf & 2) {
    var ctx_r5 = _angular_core__WEBPACK_IMPORTED_MODULE_23__["ɵɵnextContext"](3);
    _angular_core__WEBPACK_IMPORTED_MODULE_23__["ɵɵproperty"]("routerLink", _angular_core__WEBPACK_IMPORTED_MODULE_23__["ɵɵpureFunction1"](5, _c2, "/pages/tabs/home/details/" + ctx_r5.campaignContainer.campaign.campaignId + "/stats-team"));
    _angular_core__WEBPACK_IMPORTED_MODULE_23__["ɵɵadvance"](1);
    _angular_core__WEBPACK_IMPORTED_MODULE_23__["ɵɵproperty"]("color", ctx_r5.campaignContainer == null ? null : ctx_r5.campaignContainer.campaign == null ? null : ctx_r5.campaignContainer.campaign.type);
    _angular_core__WEBPACK_IMPORTED_MODULE_23__["ɵɵadvance"](2);
    _angular_core__WEBPACK_IMPORTED_MODULE_23__["ɵɵtextInterpolate1"]("", _angular_core__WEBPACK_IMPORTED_MODULE_23__["ɵɵpipeBind1"](4, 3, "campaigns.detail.statsTeam"), " ");
  }
}

var _c3 = function _c3() {
  return ["/pages/tabs/challenges"];
};

function CampaignDetailsPage_ng_container_0_ion_content_4_ion_card_6_Template(rf, ctx) {
  if (rf & 1) {
    _angular_core__WEBPACK_IMPORTED_MODULE_23__["ɵɵelementStart"](0, "ion-card", 7)(1, "ion-item", 8)(2, "ion-label");
    _angular_core__WEBPACK_IMPORTED_MODULE_23__["ɵɵtext"](3);
    _angular_core__WEBPACK_IMPORTED_MODULE_23__["ɵɵpipe"](4, "translate");
    _angular_core__WEBPACK_IMPORTED_MODULE_23__["ɵɵelementEnd"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_23__["ɵɵelement"](5, "app-icon", 19);
    _angular_core__WEBPACK_IMPORTED_MODULE_23__["ɵɵelementEnd"]()();
  }

  if (rf & 2) {
    var ctx_r6 = _angular_core__WEBPACK_IMPORTED_MODULE_23__["ɵɵnextContext"](3);
    _angular_core__WEBPACK_IMPORTED_MODULE_23__["ɵɵproperty"]("routerLink", _angular_core__WEBPACK_IMPORTED_MODULE_23__["ɵɵpureFunction0"](5, _c3));
    _angular_core__WEBPACK_IMPORTED_MODULE_23__["ɵɵadvance"](1);
    _angular_core__WEBPACK_IMPORTED_MODULE_23__["ɵɵproperty"]("color", ctx_r6.campaignContainer == null ? null : ctx_r6.campaignContainer.campaign == null ? null : ctx_r6.campaignContainer.campaign.type);
    _angular_core__WEBPACK_IMPORTED_MODULE_23__["ɵɵadvance"](2);
    _angular_core__WEBPACK_IMPORTED_MODULE_23__["ɵɵtextInterpolate1"]("", _angular_core__WEBPACK_IMPORTED_MODULE_23__["ɵɵpipeBind1"](4, 3, "campaigns.detail.challenges"), " ");
  }
}

function CampaignDetailsPage_ng_container_0_ion_content_4_ion_card_7_Template(rf, ctx) {
  if (rf & 1) {
    _angular_core__WEBPACK_IMPORTED_MODULE_23__["ɵɵelementStart"](0, "ion-card", 7)(1, "ion-item", 8)(2, "ion-label");
    _angular_core__WEBPACK_IMPORTED_MODULE_23__["ɵɵtext"](3);
    _angular_core__WEBPACK_IMPORTED_MODULE_23__["ɵɵpipe"](4, "translate");
    _angular_core__WEBPACK_IMPORTED_MODULE_23__["ɵɵelementEnd"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_23__["ɵɵelement"](5, "app-icon", 20);
    _angular_core__WEBPACK_IMPORTED_MODULE_23__["ɵɵelementEnd"]()();
  }

  if (rf & 2) {
    var ctx_r7 = _angular_core__WEBPACK_IMPORTED_MODULE_23__["ɵɵnextContext"](3);
    _angular_core__WEBPACK_IMPORTED_MODULE_23__["ɵɵproperty"]("routerLink", _angular_core__WEBPACK_IMPORTED_MODULE_23__["ɵɵpureFunction1"](5, _c2, "/pages/tabs/home/details/" + ctx_r7.campaignContainer.campaign.campaignId + "/badges"));
    _angular_core__WEBPACK_IMPORTED_MODULE_23__["ɵɵadvance"](1);
    _angular_core__WEBPACK_IMPORTED_MODULE_23__["ɵɵproperty"]("color", ctx_r7.campaignContainer == null ? null : ctx_r7.campaignContainer.campaign == null ? null : ctx_r7.campaignContainer.campaign.type);
    _angular_core__WEBPACK_IMPORTED_MODULE_23__["ɵɵadvance"](2);
    _angular_core__WEBPACK_IMPORTED_MODULE_23__["ɵɵtextInterpolate1"]("", _angular_core__WEBPACK_IMPORTED_MODULE_23__["ɵɵpipeBind1"](4, 3, "campaigns.detail.badges"), " ");
  }
}

function CampaignDetailsPage_ng_container_0_ion_content_4_ion_card_8_Template(rf, ctx) {
  if (rf & 1) {
    _angular_core__WEBPACK_IMPORTED_MODULE_23__["ɵɵelementStart"](0, "ion-card", 7)(1, "ion-item", 8)(2, "ion-label");
    _angular_core__WEBPACK_IMPORTED_MODULE_23__["ɵɵtext"](3);
    _angular_core__WEBPACK_IMPORTED_MODULE_23__["ɵɵpipe"](4, "translate");
    _angular_core__WEBPACK_IMPORTED_MODULE_23__["ɵɵelementEnd"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_23__["ɵɵelement"](5, "ion-icon", 21);
    _angular_core__WEBPACK_IMPORTED_MODULE_23__["ɵɵelementEnd"]()();
  }

  if (rf & 2) {
    var ctx_r8 = _angular_core__WEBPACK_IMPORTED_MODULE_23__["ɵɵnextContext"](3);
    _angular_core__WEBPACK_IMPORTED_MODULE_23__["ɵɵproperty"]("routerLink", _angular_core__WEBPACK_IMPORTED_MODULE_23__["ɵɵpureFunction1"](5, _c2, "/pages/tabs/home/details/" + ctx_r8.campaignContainer.campaign.campaignId + "/prizes"));
    _angular_core__WEBPACK_IMPORTED_MODULE_23__["ɵɵadvance"](1);
    _angular_core__WEBPACK_IMPORTED_MODULE_23__["ɵɵproperty"]("color", ctx_r8.campaignContainer == null ? null : ctx_r8.campaignContainer.campaign == null ? null : ctx_r8.campaignContainer.campaign.type);
    _angular_core__WEBPACK_IMPORTED_MODULE_23__["ɵɵadvance"](2);
    _angular_core__WEBPACK_IMPORTED_MODULE_23__["ɵɵtextInterpolate1"]("", _angular_core__WEBPACK_IMPORTED_MODULE_23__["ɵɵpipeBind1"](4, 3, "campaigns.detail.prizes"), " ");
  }
}

function CampaignDetailsPage_ng_container_0_ion_content_4_ion_card_15_Template(rf, ctx) {
  if (rf & 1) {
    _angular_core__WEBPACK_IMPORTED_MODULE_23__["ɵɵelementStart"](0, "ion-card", 7)(1, "ion-item", 8)(2, "ion-label");
    _angular_core__WEBPACK_IMPORTED_MODULE_23__["ɵɵtext"](3);
    _angular_core__WEBPACK_IMPORTED_MODULE_23__["ɵɵpipe"](4, "translate");
    _angular_core__WEBPACK_IMPORTED_MODULE_23__["ɵɵelementEnd"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_23__["ɵɵelement"](5, "app-icon", 22);
    _angular_core__WEBPACK_IMPORTED_MODULE_23__["ɵɵelementEnd"]()();
  }

  if (rf & 2) {
    var ctx_r9 = _angular_core__WEBPACK_IMPORTED_MODULE_23__["ɵɵnextContext"](3);
    _angular_core__WEBPACK_IMPORTED_MODULE_23__["ɵɵproperty"]("routerLink", _angular_core__WEBPACK_IMPORTED_MODULE_23__["ɵɵpureFunction1"](5, _c2, "/pages/blacklist/" + ctx_r9.campaignContainer.campaign.campaignId));
    _angular_core__WEBPACK_IMPORTED_MODULE_23__["ɵɵadvance"](1);
    _angular_core__WEBPACK_IMPORTED_MODULE_23__["ɵɵproperty"]("color", ctx_r9.campaignContainer == null ? null : ctx_r9.campaignContainer.campaign == null ? null : ctx_r9.campaignContainer.campaign.type);
    _angular_core__WEBPACK_IMPORTED_MODULE_23__["ɵɵadvance"](2);
    _angular_core__WEBPACK_IMPORTED_MODULE_23__["ɵɵtextInterpolate1"]("", _angular_core__WEBPACK_IMPORTED_MODULE_23__["ɵɵpipeBind1"](4, 3, "campaigns.detail.blacklist"), " ");
  }
}

function CampaignDetailsPage_ng_container_0_ion_content_4_div_26_ion_icon_1_Template(rf, ctx) {
  if (rf & 1) {
    _angular_core__WEBPACK_IMPORTED_MODULE_23__["ɵɵelement"](0, "ion-icon", 26);
  }
}

function CampaignDetailsPage_ng_container_0_ion_content_4_div_26_ion_icon_2_Template(rf, ctx) {
  if (rf & 1) {
    _angular_core__WEBPACK_IMPORTED_MODULE_23__["ɵɵelement"](0, "ion-icon", 27);
  }
}

function CampaignDetailsPage_ng_container_0_ion_content_4_div_26_Template(rf, ctx) {
  if (rf & 1) {
    var _r20 = _angular_core__WEBPACK_IMPORTED_MODULE_23__["ɵɵgetCurrentView"]();

    _angular_core__WEBPACK_IMPORTED_MODULE_23__["ɵɵelementStart"](0, "div", 23);
    _angular_core__WEBPACK_IMPORTED_MODULE_23__["ɵɵlistener"]("click", function CampaignDetailsPage_ng_container_0_ion_content_4_div_26_Template_div_click_0_listener() {
      _angular_core__WEBPACK_IMPORTED_MODULE_23__["ɵɵrestoreView"](_r20);
      var ctx_r19 = _angular_core__WEBPACK_IMPORTED_MODULE_23__["ɵɵnextContext"](3);
      return ctx_r19.clickDescription();
    });
    _angular_core__WEBPACK_IMPORTED_MODULE_23__["ɵɵtemplate"](1, CampaignDetailsPage_ng_container_0_ion_content_4_div_26_ion_icon_1_Template, 1, 0, "ion-icon", 24);
    _angular_core__WEBPACK_IMPORTED_MODULE_23__["ɵɵtemplate"](2, CampaignDetailsPage_ng_container_0_ion_content_4_div_26_ion_icon_2_Template, 1, 0, "ion-icon", 25);
    _angular_core__WEBPACK_IMPORTED_MODULE_23__["ɵɵelementEnd"]();
  }

  if (rf & 2) {
    var ctx_r10 = _angular_core__WEBPACK_IMPORTED_MODULE_23__["ɵɵnextContext"](3);
    _angular_core__WEBPACK_IMPORTED_MODULE_23__["ɵɵadvance"](1);
    _angular_core__WEBPACK_IMPORTED_MODULE_23__["ɵɵproperty"]("ngIf", ctx_r10.descriptionExpanded);
    _angular_core__WEBPACK_IMPORTED_MODULE_23__["ɵɵadvance"](1);
    _angular_core__WEBPACK_IMPORTED_MODULE_23__["ɵɵproperty"]("ngIf", !ctx_r10.descriptionExpanded);
  }
}

function CampaignDetailsPage_ng_container_0_ion_content_4_div_27_ng_container_1_div_1_Template(rf, ctx) {
  if (rf & 1) {
    var _r27 = _angular_core__WEBPACK_IMPORTED_MODULE_23__["ɵɵgetCurrentView"]();

    _angular_core__WEBPACK_IMPORTED_MODULE_23__["ɵɵelementStart"](0, "div", 28);
    _angular_core__WEBPACK_IMPORTED_MODULE_23__["ɵɵlistener"]("click", function CampaignDetailsPage_ng_container_0_ion_content_4_div_27_ng_container_1_div_1_Template_div_click_0_listener() {
      _angular_core__WEBPACK_IMPORTED_MODULE_23__["ɵɵrestoreView"](_r27);
      var detail_r23 = _angular_core__WEBPACK_IMPORTED_MODULE_23__["ɵɵnextContext"]().$implicit;
      var ctx_r25 = _angular_core__WEBPACK_IMPORTED_MODULE_23__["ɵɵnextContext"](4);
      return ctx_r25.openDetail(detail_r23);
    });
    _angular_core__WEBPACK_IMPORTED_MODULE_23__["ɵɵelementStart"](1, "ion-item", 29)(2, "ion-label")(3, "span", 30);
    _angular_core__WEBPACK_IMPORTED_MODULE_23__["ɵɵtext"](4);
    _angular_core__WEBPACK_IMPORTED_MODULE_23__["ɵɵelementEnd"]()();
    _angular_core__WEBPACK_IMPORTED_MODULE_23__["ɵɵelement"](5, "ion-icon", 31);
    _angular_core__WEBPACK_IMPORTED_MODULE_23__["ɵɵelementEnd"]()();
  }

  if (rf & 2) {
    var detail_r23 = _angular_core__WEBPACK_IMPORTED_MODULE_23__["ɵɵnextContext"]().$implicit;
    _angular_core__WEBPACK_IMPORTED_MODULE_23__["ɵɵadvance"](4);
    _angular_core__WEBPACK_IMPORTED_MODULE_23__["ɵɵtextInterpolate1"](" ", detail_r23.name, "");
  }
}

function CampaignDetailsPage_ng_container_0_ion_content_4_div_27_ng_container_1_Template(rf, ctx) {
  if (rf & 1) {
    _angular_core__WEBPACK_IMPORTED_MODULE_23__["ɵɵelementContainerStart"](0);
    _angular_core__WEBPACK_IMPORTED_MODULE_23__["ɵɵtemplate"](1, CampaignDetailsPage_ng_container_0_ion_content_4_div_27_ng_container_1_div_1_Template, 6, 1, "div", 15);
    _angular_core__WEBPACK_IMPORTED_MODULE_23__["ɵɵelementContainerEnd"]();
  }

  if (rf & 2) {
    var detail_r23 = ctx.$implicit;
    _angular_core__WEBPACK_IMPORTED_MODULE_23__["ɵɵadvance"](1);
    _angular_core__WEBPACK_IMPORTED_MODULE_23__["ɵɵproperty"]("ngIf", detail_r23.type !== "sponsor" && detail_r23.type !== "faq");
  }
}

function CampaignDetailsPage_ng_container_0_ion_content_4_div_27_Template(rf, ctx) {
  if (rf & 1) {
    _angular_core__WEBPACK_IMPORTED_MODULE_23__["ɵɵelementStart"](0, "div");
    _angular_core__WEBPACK_IMPORTED_MODULE_23__["ɵɵtemplate"](1, CampaignDetailsPage_ng_container_0_ion_content_4_div_27_ng_container_1_Template, 2, 1, "ng-container", 5);
    _angular_core__WEBPACK_IMPORTED_MODULE_23__["ɵɵelementEnd"]();
  }

  if (rf & 2) {
    var details_r21 = ctx.ngIf;
    _angular_core__WEBPACK_IMPORTED_MODULE_23__["ɵɵadvance"](1);
    _angular_core__WEBPACK_IMPORTED_MODULE_23__["ɵɵproperty"]("ngForOf", details_r21);
  }
}

function CampaignDetailsPage_ng_container_0_ion_content_4_ion_card_29_Template(rf, ctx) {
  if (rf & 1) {
    _angular_core__WEBPACK_IMPORTED_MODULE_23__["ɵɵelementStart"](0, "ion-card", 7)(1, "ion-item", 8)(2, "ion-label");
    _angular_core__WEBPACK_IMPORTED_MODULE_23__["ɵɵtext"](3);
    _angular_core__WEBPACK_IMPORTED_MODULE_23__["ɵɵpipe"](4, "translate");
    _angular_core__WEBPACK_IMPORTED_MODULE_23__["ɵɵelementEnd"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_23__["ɵɵelement"](5, "ion-icon", 32);
    _angular_core__WEBPACK_IMPORTED_MODULE_23__["ɵɵelementEnd"]()();
  }

  if (rf & 2) {
    var ctx_r12 = _angular_core__WEBPACK_IMPORTED_MODULE_23__["ɵɵnextContext"](3);
    _angular_core__WEBPACK_IMPORTED_MODULE_23__["ɵɵproperty"]("routerLink", _angular_core__WEBPACK_IMPORTED_MODULE_23__["ɵɵpureFunction1"](5, _c2, "/pages/tabs/home/details/" + ctx_r12.campaignContainer.campaign.campaignId + "/companies"));
    _angular_core__WEBPACK_IMPORTED_MODULE_23__["ɵɵadvance"](1);
    _angular_core__WEBPACK_IMPORTED_MODULE_23__["ɵɵproperty"]("color", ctx_r12.campaignContainer == null ? null : ctx_r12.campaignContainer.campaign == null ? null : ctx_r12.campaignContainer.campaign.type);
    _angular_core__WEBPACK_IMPORTED_MODULE_23__["ɵɵadvance"](2);
    _angular_core__WEBPACK_IMPORTED_MODULE_23__["ɵɵtextInterpolate1"](" ", _angular_core__WEBPACK_IMPORTED_MODULE_23__["ɵɵpipeBind1"](4, 3, "campaigns.detail.companies"), "");
  }
}

function CampaignDetailsPage_ng_container_0_ion_content_4_ion_card_30_Template(rf, ctx) {
  if (rf & 1) {
    _angular_core__WEBPACK_IMPORTED_MODULE_23__["ɵɵelementStart"](0, "ion-card", 7)(1, "ion-item", 8)(2, "ion-label");
    _angular_core__WEBPACK_IMPORTED_MODULE_23__["ɵɵtext"](3);
    _angular_core__WEBPACK_IMPORTED_MODULE_23__["ɵɵpipe"](4, "translate");
    _angular_core__WEBPACK_IMPORTED_MODULE_23__["ɵɵelementEnd"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_23__["ɵɵelement"](5, "ion-icon", 33);
    _angular_core__WEBPACK_IMPORTED_MODULE_23__["ɵɵelementEnd"]()();
  }

  if (rf & 2) {
    var ctx_r13 = _angular_core__WEBPACK_IMPORTED_MODULE_23__["ɵɵnextContext"](3);
    _angular_core__WEBPACK_IMPORTED_MODULE_23__["ɵɵproperty"]("routerLink", _angular_core__WEBPACK_IMPORTED_MODULE_23__["ɵɵpureFunction1"](5, _c2, "/pages/tabs/home/details/" + ctx_r13.campaignContainer.campaign.campaignId + "/faq"));
    _angular_core__WEBPACK_IMPORTED_MODULE_23__["ɵɵadvance"](1);
    _angular_core__WEBPACK_IMPORTED_MODULE_23__["ɵɵproperty"]("color", ctx_r13.campaignContainer == null ? null : ctx_r13.campaignContainer.campaign == null ? null : ctx_r13.campaignContainer.campaign.type);
    _angular_core__WEBPACK_IMPORTED_MODULE_23__["ɵɵadvance"](2);
    _angular_core__WEBPACK_IMPORTED_MODULE_23__["ɵɵtextInterpolate1"](" ", _angular_core__WEBPACK_IMPORTED_MODULE_23__["ɵɵpipeBind1"](4, 3, "campaigns.detail.faq"), "");
  }
}

function CampaignDetailsPage_ng_container_0_ion_content_4_ion_card_38_Template(rf, ctx) {
  if (rf & 1) {
    _angular_core__WEBPACK_IMPORTED_MODULE_23__["ɵɵelementStart"](0, "ion-card")(1, "ion-card-title")(2, "ion-item", 8)(3, "ion-label");
    _angular_core__WEBPACK_IMPORTED_MODULE_23__["ɵɵtext"](4);
    _angular_core__WEBPACK_IMPORTED_MODULE_23__["ɵɵpipe"](5, "translate");
    _angular_core__WEBPACK_IMPORTED_MODULE_23__["ɵɵelementEnd"]()()();
    _angular_core__WEBPACK_IMPORTED_MODULE_23__["ɵɵelementStart"](6, "ion-card-content");
    _angular_core__WEBPACK_IMPORTED_MODULE_23__["ɵɵelement"](7, "div", 34);
    _angular_core__WEBPACK_IMPORTED_MODULE_23__["ɵɵpipe"](8, "languageMap");
    _angular_core__WEBPACK_IMPORTED_MODULE_23__["ɵɵelementEnd"]()();
  }

  if (rf & 2) {
    var ctx_r14 = _angular_core__WEBPACK_IMPORTED_MODULE_23__["ɵɵnextContext"](3);
    var tmp_2_0;
    _angular_core__WEBPACK_IMPORTED_MODULE_23__["ɵɵadvance"](2);
    _angular_core__WEBPACK_IMPORTED_MODULE_23__["ɵɵproperty"]("color", ctx_r14.campaignContainer == null ? null : ctx_r14.campaignContainer.campaign == null ? null : ctx_r14.campaignContainer.campaign.type);
    _angular_core__WEBPACK_IMPORTED_MODULE_23__["ɵɵadvance"](2);
    _angular_core__WEBPACK_IMPORTED_MODULE_23__["ɵɵtextInterpolate"](_angular_core__WEBPACK_IMPORTED_MODULE_23__["ɵɵpipeBind1"](5, 3, "campaigns.detail.sponsor"));
    _angular_core__WEBPACK_IMPORTED_MODULE_23__["ɵɵadvance"](3);
    _angular_core__WEBPACK_IMPORTED_MODULE_23__["ɵɵproperty"]("innerHTML", (tmp_2_0 = ctx_r14.getCampaignSponsor(_angular_core__WEBPACK_IMPORTED_MODULE_23__["ɵɵpipeBind1"](8, 5, ctx_r14.campaignContainer == null ? null : ctx_r14.campaignContainer.campaign == null ? null : ctx_r14.campaignContainer.campaign.details))) == null ? null : tmp_2_0.content, _angular_core__WEBPACK_IMPORTED_MODULE_23__["ɵɵsanitizeHtml"]);
  }
}

function CampaignDetailsPage_ng_container_0_ion_content_4_ion_card_40_Template(rf, ctx) {
  if (rf & 1) {
    var _r30 = _angular_core__WEBPACK_IMPORTED_MODULE_23__["ɵɵgetCurrentView"]();

    _angular_core__WEBPACK_IMPORTED_MODULE_23__["ɵɵelementStart"](0, "ion-card", 28);
    _angular_core__WEBPACK_IMPORTED_MODULE_23__["ɵɵlistener"]("click", function CampaignDetailsPage_ng_container_0_ion_content_4_ion_card_40_Template_ion_card_click_0_listener() {
      _angular_core__WEBPACK_IMPORTED_MODULE_23__["ɵɵrestoreView"](_r30);
      var ctx_r29 = _angular_core__WEBPACK_IMPORTED_MODULE_23__["ɵɵnextContext"](3);
      return ctx_r29.unsubscribeCampaign();
    });
    _angular_core__WEBPACK_IMPORTED_MODULE_23__["ɵɵelementStart"](1, "ion-item", 35)(2, "ion-label");
    _angular_core__WEBPACK_IMPORTED_MODULE_23__["ɵɵtext"](3);
    _angular_core__WEBPACK_IMPORTED_MODULE_23__["ɵɵpipe"](4, "translate");
    _angular_core__WEBPACK_IMPORTED_MODULE_23__["ɵɵelementEnd"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_23__["ɵɵelement"](5, "app-icon", 36);
    _angular_core__WEBPACK_IMPORTED_MODULE_23__["ɵɵelementEnd"]()();
  }

  if (rf & 2) {
    _angular_core__WEBPACK_IMPORTED_MODULE_23__["ɵɵadvance"](3);
    _angular_core__WEBPACK_IMPORTED_MODULE_23__["ɵɵtextInterpolate1"]("", _angular_core__WEBPACK_IMPORTED_MODULE_23__["ɵɵpipeBind1"](4, 1, "campaigns.detail.unsubscribe"), " ");
  }
}

var _c4 = function _c4(a1) {
  return ["/pages/tabs/trips/campaign", a1];
};

function CampaignDetailsPage_ng_container_0_ion_content_4_Template(rf, ctx) {
  if (rf & 1) {
    var _r32 = _angular_core__WEBPACK_IMPORTED_MODULE_23__["ɵɵgetCurrentView"]();

    _angular_core__WEBPACK_IMPORTED_MODULE_23__["ɵɵelementStart"](0, "ion-content", 3);
    _angular_core__WEBPACK_IMPORTED_MODULE_23__["ɵɵelement"](1, "app-widget-campaign", 4);
    _angular_core__WEBPACK_IMPORTED_MODULE_23__["ɵɵtemplate"](2, CampaignDetailsPage_ng_container_0_ion_content_4_ng_container_2_Template, 2, 2, "ng-container", 5);
    _angular_core__WEBPACK_IMPORTED_MODULE_23__["ɵɵtemplate"](3, CampaignDetailsPage_ng_container_0_ion_content_4_ion_card_3_Template, 6, 5, "ion-card", 6);
    _angular_core__WEBPACK_IMPORTED_MODULE_23__["ɵɵtemplate"](4, CampaignDetailsPage_ng_container_0_ion_content_4_ion_card_4_Template, 6, 7, "ion-card", 6);
    _angular_core__WEBPACK_IMPORTED_MODULE_23__["ɵɵtemplate"](5, CampaignDetailsPage_ng_container_0_ion_content_4_ion_card_5_Template, 6, 7, "ion-card", 6);
    _angular_core__WEBPACK_IMPORTED_MODULE_23__["ɵɵtemplate"](6, CampaignDetailsPage_ng_container_0_ion_content_4_ion_card_6_Template, 6, 6, "ion-card", 6);
    _angular_core__WEBPACK_IMPORTED_MODULE_23__["ɵɵtemplate"](7, CampaignDetailsPage_ng_container_0_ion_content_4_ion_card_7_Template, 6, 7, "ion-card", 6);
    _angular_core__WEBPACK_IMPORTED_MODULE_23__["ɵɵtemplate"](8, CampaignDetailsPage_ng_container_0_ion_content_4_ion_card_8_Template, 6, 7, "ion-card", 6);
    _angular_core__WEBPACK_IMPORTED_MODULE_23__["ɵɵelementStart"](9, "ion-card", 7)(10, "ion-item", 8)(11, "ion-label");
    _angular_core__WEBPACK_IMPORTED_MODULE_23__["ɵɵtext"](12);
    _angular_core__WEBPACK_IMPORTED_MODULE_23__["ɵɵpipe"](13, "translate");
    _angular_core__WEBPACK_IMPORTED_MODULE_23__["ɵɵelementEnd"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_23__["ɵɵelement"](14, "app-icon", 9);
    _angular_core__WEBPACK_IMPORTED_MODULE_23__["ɵɵelementEnd"]()();
    _angular_core__WEBPACK_IMPORTED_MODULE_23__["ɵɵtemplate"](15, CampaignDetailsPage_ng_container_0_ion_content_4_ion_card_15_Template, 6, 7, "ion-card", 6);
    _angular_core__WEBPACK_IMPORTED_MODULE_23__["ɵɵelementStart"](16, "ion-card")(17, "ion-card-title")(18, "ion-item", 8)(19, "ion-label");
    _angular_core__WEBPACK_IMPORTED_MODULE_23__["ɵɵtext"](20);
    _angular_core__WEBPACK_IMPORTED_MODULE_23__["ɵɵpipe"](21, "translate");
    _angular_core__WEBPACK_IMPORTED_MODULE_23__["ɵɵelementEnd"]()()();
    _angular_core__WEBPACK_IMPORTED_MODULE_23__["ɵɵelementStart"](22, "ion-card-content")(23, "div", 10);
    _angular_core__WEBPACK_IMPORTED_MODULE_23__["ɵɵlistener"]("click", function CampaignDetailsPage_ng_container_0_ion_content_4_Template_div_click_23_listener() {
      _angular_core__WEBPACK_IMPORTED_MODULE_23__["ɵɵrestoreView"](_r32);
      var ctx_r31 = _angular_core__WEBPACK_IMPORTED_MODULE_23__["ɵɵnextContext"](2);
      return ctx_r31.clickDescription();
    });
    _angular_core__WEBPACK_IMPORTED_MODULE_23__["ɵɵelement"](24, "div", 11);
    _angular_core__WEBPACK_IMPORTED_MODULE_23__["ɵɵpipe"](25, "languageMap");
    _angular_core__WEBPACK_IMPORTED_MODULE_23__["ɵɵelementEnd"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_23__["ɵɵtemplate"](26, CampaignDetailsPage_ng_container_0_ion_content_4_div_26_Template, 3, 2, "div", 12);
    _angular_core__WEBPACK_IMPORTED_MODULE_23__["ɵɵtemplate"](27, CampaignDetailsPage_ng_container_0_ion_content_4_div_27_Template, 2, 1, "div", 0);
    _angular_core__WEBPACK_IMPORTED_MODULE_23__["ɵɵpipe"](28, "languageMap");
    _angular_core__WEBPACK_IMPORTED_MODULE_23__["ɵɵelementEnd"]()();
    _angular_core__WEBPACK_IMPORTED_MODULE_23__["ɵɵtemplate"](29, CampaignDetailsPage_ng_container_0_ion_content_4_ion_card_29_Template, 6, 7, "ion-card", 6);
    _angular_core__WEBPACK_IMPORTED_MODULE_23__["ɵɵtemplate"](30, CampaignDetailsPage_ng_container_0_ion_content_4_ion_card_30_Template, 6, 7, "ion-card", 6);
    _angular_core__WEBPACK_IMPORTED_MODULE_23__["ɵɵpipe"](31, "languageMap");
    _angular_core__WEBPACK_IMPORTED_MODULE_23__["ɵɵelementStart"](32, "ion-card")(33, "ion-item", 13);
    _angular_core__WEBPACK_IMPORTED_MODULE_23__["ɵɵlistener"]("click", function CampaignDetailsPage_ng_container_0_ion_content_4_Template_ion_item_click_33_listener() {
      _angular_core__WEBPACK_IMPORTED_MODULE_23__["ɵɵrestoreView"](_r32);
      var ctx_r33 = _angular_core__WEBPACK_IMPORTED_MODULE_23__["ɵɵnextContext"](2);
      return ctx_r33.openSupport();
    });
    _angular_core__WEBPACK_IMPORTED_MODULE_23__["ɵɵelementStart"](34, "ion-label");
    _angular_core__WEBPACK_IMPORTED_MODULE_23__["ɵɵtext"](35);
    _angular_core__WEBPACK_IMPORTED_MODULE_23__["ɵɵpipe"](36, "translate");
    _angular_core__WEBPACK_IMPORTED_MODULE_23__["ɵɵelementEnd"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_23__["ɵɵelement"](37, "ion-icon", 14);
    _angular_core__WEBPACK_IMPORTED_MODULE_23__["ɵɵelementEnd"]()();
    _angular_core__WEBPACK_IMPORTED_MODULE_23__["ɵɵtemplate"](38, CampaignDetailsPage_ng_container_0_ion_content_4_ion_card_38_Template, 9, 7, "ion-card", 0);
    _angular_core__WEBPACK_IMPORTED_MODULE_23__["ɵɵpipe"](39, "languageMap");
    _angular_core__WEBPACK_IMPORTED_MODULE_23__["ɵɵtemplate"](40, CampaignDetailsPage_ng_container_0_ion_content_4_ion_card_40_Template, 6, 3, "ion-card", 15);
    _angular_core__WEBPACK_IMPORTED_MODULE_23__["ɵɵelementEnd"]();
  }

  if (rf & 2) {
    var ctx_r1 = _angular_core__WEBPACK_IMPORTED_MODULE_23__["ɵɵnextContext"](2);
    _angular_core__WEBPACK_IMPORTED_MODULE_23__["ɵɵproperty"]("fullscreen", true)("scrollEvents", true);
    _angular_core__WEBPACK_IMPORTED_MODULE_23__["ɵɵadvance"](1);
    _angular_core__WEBPACK_IMPORTED_MODULE_23__["ɵɵproperty"]("campaign", ctx_r1.campaignContainer)("header", false);
    _angular_core__WEBPACK_IMPORTED_MODULE_23__["ɵɵadvance"](1);
    _angular_core__WEBPACK_IMPORTED_MODULE_23__["ɵɵproperty"]("ngForOf", ctx_r1.unreadNotifications);
    _angular_core__WEBPACK_IMPORTED_MODULE_23__["ɵɵadvance"](1);
    _angular_core__WEBPACK_IMPORTED_MODULE_23__["ɵɵproperty"]("ngIf", ctx_r1.campaignHas("leaderboard"));
    _angular_core__WEBPACK_IMPORTED_MODULE_23__["ɵɵadvance"](1);
    _angular_core__WEBPACK_IMPORTED_MODULE_23__["ɵɵproperty"]("ngIf", ctx_r1.campaignHas("stats"));
    _angular_core__WEBPACK_IMPORTED_MODULE_23__["ɵɵadvance"](1);
    _angular_core__WEBPACK_IMPORTED_MODULE_23__["ɵɵproperty"]("ngIf", ctx_r1.campaignHas("statsTeam"));
    _angular_core__WEBPACK_IMPORTED_MODULE_23__["ɵɵadvance"](1);
    _angular_core__WEBPACK_IMPORTED_MODULE_23__["ɵɵproperty"]("ngIf", ctx_r1.campaignHas("challenge"));
    _angular_core__WEBPACK_IMPORTED_MODULE_23__["ɵɵadvance"](1);
    _angular_core__WEBPACK_IMPORTED_MODULE_23__["ɵɵproperty"]("ngIf", ctx_r1.campaignHas("badges"));
    _angular_core__WEBPACK_IMPORTED_MODULE_23__["ɵɵadvance"](1);
    _angular_core__WEBPACK_IMPORTED_MODULE_23__["ɵɵproperty"]("ngIf", ctx_r1.campaignHas("prizes") && (ctx_r1.campaignContainer == null ? null : ctx_r1.campaignContainer.campaign == null ? null : ctx_r1.campaignContainer.campaign.weekConfs));
    _angular_core__WEBPACK_IMPORTED_MODULE_23__["ɵɵadvance"](1);
    _angular_core__WEBPACK_IMPORTED_MODULE_23__["ɵɵproperty"]("routerLink", _angular_core__WEBPACK_IMPORTED_MODULE_23__["ɵɵpureFunction1"](41, _c4, ctx_r1.campaignContainer == null ? null : ctx_r1.campaignContainer.campaign == null ? null : ctx_r1.campaignContainer.campaign.campaignId));
    _angular_core__WEBPACK_IMPORTED_MODULE_23__["ɵɵadvance"](1);
    _angular_core__WEBPACK_IMPORTED_MODULE_23__["ɵɵproperty"]("color", ctx_r1.campaignContainer == null ? null : ctx_r1.campaignContainer.campaign == null ? null : ctx_r1.campaignContainer.campaign.type);
    _angular_core__WEBPACK_IMPORTED_MODULE_23__["ɵɵadvance"](2);
    _angular_core__WEBPACK_IMPORTED_MODULE_23__["ɵɵtextInterpolate1"]("", _angular_core__WEBPACK_IMPORTED_MODULE_23__["ɵɵpipeBind1"](13, 27, "campaigns.detail.journeys"), " ");
    _angular_core__WEBPACK_IMPORTED_MODULE_23__["ɵɵadvance"](3);
    _angular_core__WEBPACK_IMPORTED_MODULE_23__["ɵɵproperty"]("ngIf", ctx_r1.campaignHas("blacklist"));
    _angular_core__WEBPACK_IMPORTED_MODULE_23__["ɵɵadvance"](3);
    _angular_core__WEBPACK_IMPORTED_MODULE_23__["ɵɵproperty"]("color", ctx_r1.campaignContainer == null ? null : ctx_r1.campaignContainer.campaign == null ? null : ctx_r1.campaignContainer.campaign.type);
    _angular_core__WEBPACK_IMPORTED_MODULE_23__["ɵɵadvance"](2);
    _angular_core__WEBPACK_IMPORTED_MODULE_23__["ɵɵtextInterpolate"](_angular_core__WEBPACK_IMPORTED_MODULE_23__["ɵɵpipeBind1"](21, 29, "campaigns.detail.details"));
    _angular_core__WEBPACK_IMPORTED_MODULE_23__["ɵɵadvance"](3);
    _angular_core__WEBPACK_IMPORTED_MODULE_23__["ɵɵproperty"]("ngClass", ctx_r1.descriptionExpanded ? "open" : "");
    _angular_core__WEBPACK_IMPORTED_MODULE_23__["ɵɵadvance"](1);
    _angular_core__WEBPACK_IMPORTED_MODULE_23__["ɵɵproperty"]("innerHTML", _angular_core__WEBPACK_IMPORTED_MODULE_23__["ɵɵpipeBind1"](25, 31, ctx_r1.campaignContainer == null ? null : ctx_r1.campaignContainer.campaign == null ? null : ctx_r1.campaignContainer.campaign.description), _angular_core__WEBPACK_IMPORTED_MODULE_23__["ɵɵsanitizeHtml"]);
    _angular_core__WEBPACK_IMPORTED_MODULE_23__["ɵɵadvance"](2);
    _angular_core__WEBPACK_IMPORTED_MODULE_23__["ɵɵproperty"]("ngIf", ctx_r1.descriptionExpanded || ctx_r1.isTextOverflow("descText"));
    _angular_core__WEBPACK_IMPORTED_MODULE_23__["ɵɵadvance"](1);
    _angular_core__WEBPACK_IMPORTED_MODULE_23__["ɵɵproperty"]("ngIf", _angular_core__WEBPACK_IMPORTED_MODULE_23__["ɵɵpipeBind1"](28, 33, ctx_r1.campaignContainer == null ? null : ctx_r1.campaignContainer.campaign == null ? null : ctx_r1.campaignContainer.campaign.details));
    _angular_core__WEBPACK_IMPORTED_MODULE_23__["ɵɵadvance"](2);
    _angular_core__WEBPACK_IMPORTED_MODULE_23__["ɵɵproperty"]("ngIf", ctx_r1.campaignHas("companies") && (ctx_r1.campaignContainer == null ? null : ctx_r1.campaignContainer.campaign == null ? null : ctx_r1.campaignContainer.campaign.specificData.hideCompanyDesc) !== true);
    _angular_core__WEBPACK_IMPORTED_MODULE_23__["ɵɵadvance"](1);
    _angular_core__WEBPACK_IMPORTED_MODULE_23__["ɵɵproperty"]("ngIf", ctx_r1.campaignHasFAQ(_angular_core__WEBPACK_IMPORTED_MODULE_23__["ɵɵpipeBind1"](31, 35, ctx_r1.campaignContainer == null ? null : ctx_r1.campaignContainer.campaign == null ? null : ctx_r1.campaignContainer.campaign.details)));
    _angular_core__WEBPACK_IMPORTED_MODULE_23__["ɵɵadvance"](3);
    _angular_core__WEBPACK_IMPORTED_MODULE_23__["ɵɵproperty"]("color", ctx_r1.campaignContainer == null ? null : ctx_r1.campaignContainer.campaign == null ? null : ctx_r1.campaignContainer.campaign.type);
    _angular_core__WEBPACK_IMPORTED_MODULE_23__["ɵɵadvance"](2);
    _angular_core__WEBPACK_IMPORTED_MODULE_23__["ɵɵtextInterpolate1"]("", _angular_core__WEBPACK_IMPORTED_MODULE_23__["ɵɵpipeBind1"](36, 37, "campaigns.detail.signal"), " ");
    _angular_core__WEBPACK_IMPORTED_MODULE_23__["ɵɵadvance"](3);
    _angular_core__WEBPACK_IMPORTED_MODULE_23__["ɵɵproperty"]("ngIf", ctx_r1.campaignHasSponsor(_angular_core__WEBPACK_IMPORTED_MODULE_23__["ɵɵpipeBind1"](39, 39, ctx_r1.campaignContainer == null ? null : ctx_r1.campaignContainer.campaign == null ? null : ctx_r1.campaignContainer.campaign.details)));
    _angular_core__WEBPACK_IMPORTED_MODULE_23__["ɵɵadvance"](2);
    _angular_core__WEBPACK_IMPORTED_MODULE_23__["ɵɵproperty"]("ngIf", !ctx_r1.isPersonal() && !ctx_r1.isSchool());
  }
}

function CampaignDetailsPage_ng_container_0_Template(rf, ctx) {
  if (rf & 1) {
    _angular_core__WEBPACK_IMPORTED_MODULE_23__["ɵɵelementContainerStart"](0);
    _angular_core__WEBPACK_IMPORTED_MODULE_23__["ɵɵelement"](1, "ion-header", 1);
    _angular_core__WEBPACK_IMPORTED_MODULE_23__["ɵɵpipe"](2, "localDate");
    _angular_core__WEBPACK_IMPORTED_MODULE_23__["ɵɵpipe"](3, "localDate");
    _angular_core__WEBPACK_IMPORTED_MODULE_23__["ɵɵtemplate"](4, CampaignDetailsPage_ng_container_0_ion_content_4_Template, 41, 43, "ion-content", 2);
    _angular_core__WEBPACK_IMPORTED_MODULE_23__["ɵɵelementContainerEnd"]();
  }

  if (rf & 2) {
    var ctx_r0 = _angular_core__WEBPACK_IMPORTED_MODULE_23__["ɵɵnextContext"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_23__["ɵɵadvance"](1);
    _angular_core__WEBPACK_IMPORTED_MODULE_23__["ɵɵpropertyInterpolate2"]("text", "", _angular_core__WEBPACK_IMPORTED_MODULE_23__["ɵɵpipeBind2"](2, 5, ctx_r0.campaignContainer == null ? null : ctx_r0.campaignContainer.campaign == null ? null : ctx_r0.campaignContainer.campaign.dateFrom, "dd MMMM y"), " - ", _angular_core__WEBPACK_IMPORTED_MODULE_23__["ɵɵpipeBind2"](3, 8, ctx_r0.campaignContainer == null ? null : ctx_r0.campaignContainer.campaign == null ? null : ctx_r0.campaignContainer.campaign.dateTo, "dd MMMM y"), "");
    _angular_core__WEBPACK_IMPORTED_MODULE_23__["ɵɵproperty"]("imageUrl", ctx_r0.campaignContainer == null ? null : ctx_r0.campaignContainer.campaign == null ? null : ctx_r0.campaignContainer.campaign.banner == null ? null : ctx_r0.campaignContainer.campaign.banner.url)("logo", ctx_r0.imagePath);
    _angular_core__WEBPACK_IMPORTED_MODULE_23__["ɵɵadvance"](3);
    _angular_core__WEBPACK_IMPORTED_MODULE_23__["ɵɵproperty"]("ngIf", ctx_r0.campaignContainer);
  }
}

var CampaignDetailsPage = /*#__PURE__*/function () {
  function CampaignDetailsPage(route, campaignService, alertService, userService, navCtrl, modalController, notificationService, pageSettingsService, errorService, teamService) {
    var _this = this;

    (0,_Users_smartcommunitylab_Desktop_newWork_dslab_playgo_mobile_playgo_mobile_node_modules_babel_runtime_helpers_esm_classCallCheck_js__WEBPACK_IMPORTED_MODULE_1__["default"])(this, CampaignDetailsPage);

    this.route = route;
    this.campaignService = campaignService;
    this.alertService = alertService;
    this.userService = userService;
    this.navCtrl = navCtrl;
    this.modalController = modalController;
    this.notificationService = notificationService;
    this.pageSettingsService = pageSettingsService;
    this.errorService = errorService;
    this.teamService = teamService;
    this.titlePage = '';
    this.colorCampaign = null;
    this.isDestroyed$ = new rxjs__WEBPACK_IMPORTED_MODULE_24__.Subject();
    this.unreadNotifications = [];
    this.descriptionExpanded = false;
    this.campaignId$ = this.route.params.pipe((0,rxjs__WEBPACK_IMPORTED_MODULE_25__.map)(function (params) {
      return params.id;
    }), (0,rxjs__WEBPACK_IMPORTED_MODULE_26__.distinctUntilChanged)(), (0,rxjs__WEBPACK_IMPORTED_MODULE_27__.shareReplay)(1));
    this.playerCampaign$ = this.campaignId$.pipe((0,rxjs__WEBPACK_IMPORTED_MODULE_28__.switchMap)(function (campaignId) {
      return _this.campaignService.myCampaigns$.pipe((0,rxjs__WEBPACK_IMPORTED_MODULE_25__.map)(function (campaigns) {
        return (0,lodash_es__WEBPACK_IMPORTED_MODULE_29__["default"])(campaigns, function (playercampaign) {
          return playercampaign.subscription.campaignId === campaignId;
        });
      }), (0,rxjs__WEBPACK_IMPORTED_MODULE_30__.tap)(function (campaigns) {
        return console.log(campaigns);
      }), // throwIfNil(() => new Error('Campaign not found')),
      _this.errorService.getErrorHandler());
    }), (0,rxjs__WEBPACK_IMPORTED_MODULE_30__.tap)(function (campaign) {
      return console.log('playercampaign' + campaign);
    }), (0,rxjs__WEBPACK_IMPORTED_MODULE_27__.shareReplay)(1));
    this.teamId$ = this.playerCampaign$.pipe((0,rxjs__WEBPACK_IMPORTED_MODULE_25__.map)(function (campaign) {
      var _a, _b;

      console.log(campaign);
      return (_b = (_a = campaign === null || campaign === void 0 ? void 0 : campaign.subscription) === null || _a === void 0 ? void 0 : _a.campaignData) === null || _b === void 0 ? void 0 : _b.teamId;
    }), (0,rxjs__WEBPACK_IMPORTED_MODULE_30__.tap)(function (team) {
      return console.log(team);
    }), (0,rxjs__WEBPACK_IMPORTED_MODULE_27__.shareReplay)(1));
    this.route.params.subscribe(function (params) {
      return _this.id = params.id;
    });
  }

  (0,_Users_smartcommunitylab_Desktop_newWork_dslab_playgo_mobile_playgo_mobile_node_modules_babel_runtime_helpers_esm_createClass_js__WEBPACK_IMPORTED_MODULE_2__["default"])(CampaignDetailsPage, [{
    key: "ngOnDestroy",
    value: function ngOnDestroy() {
      this.isDestroyed$.next();
      this.isDestroyed$.complete();
    }
  }, {
    key: "ionViewDidLeave",
    value: function ionViewDidLeave() {
      var _a, _b;

      (_a = this.subStat) === null || _a === void 0 ? void 0 : _a.unsubscribe();
      (_b = this.myCampaignSub) === null || _b === void 0 ? void 0 : _b.unsubscribe();
    }
  }, {
    key: "ngAfterViewChecked",
    value: function ngAfterViewChecked() {
      var _a;

      if ((_a = this.descText) === null || _a === void 0 ? void 0 : _a.nativeElement) {
        console.log(this.descText.nativeElement.offsetHeight < this.descText.nativeElement.scrollHeight || this.descText.nativeElement.offsetWidth < this.descText.nativeElement.scrollWidth);
        return this.descText.nativeElement.offsetHeight < this.descText.nativeElement.scrollHeight || this.descText.nativeElement.offsetWidth < this.descText.nativeElement.scrollWidth;
      }

      return false;
    }
  }, {
    key: "ngOnInit",
    value: function ngOnInit() {
      var _this2 = this;

      this.subTeam = (0,rxjs__WEBPACK_IMPORTED_MODULE_31__.combineLatest)([this.campaignId$, this.teamId$]).pipe((0,rxjs__WEBPACK_IMPORTED_MODULE_28__.switchMap)(function (_ref) {
        var _ref2 = (0,_Users_smartcommunitylab_Desktop_newWork_dslab_playgo_mobile_playgo_mobile_node_modules_babel_runtime_helpers_esm_slicedToArray_js__WEBPACK_IMPORTED_MODULE_0__["default"])(_ref, 2),
            campaignId = _ref2[0],
            teamId = _ref2[1];

        return teamId ? _this2.teamService.getMyTeam(campaignId, teamId) : rxjs__WEBPACK_IMPORTED_MODULE_32__.EMPTY;
      }), this.errorService.getErrorHandler()).subscribe(function (team) {
        return _this2.team = team;
      });
      this.subStat = this.userService.userProfile$.subscribe(function (profile) {
        _this2.profile = profile;
      });
      this.language = this.userService.getLanguage();
      this.notificationService.getUnreadCampaignNotifications(this.id).pipe((0,rxjs__WEBPACK_IMPORTED_MODULE_33__.takeUntil)(this.isDestroyed$)).subscribe(function (notifications) {
        _this2.unreadNotifications = notifications;
      });
      this.myCampaignSub = this.campaignService.myCampaigns$.pipe((0,rxjs__WEBPACK_IMPORTED_MODULE_33__.takeUntil)(this.isDestroyed$), (0,rxjs__WEBPACK_IMPORTED_MODULE_28__.switchMap)(function (campaigns) {
        var campaignContainer = campaigns.find(function (eachCampaignContainer) {
          return eachCampaignContainer.campaign.campaignId === _this2.id;
        });

        if (campaignContainer) {
          return (0,rxjs__WEBPACK_IMPORTED_MODULE_34__.of)(campaignContainer);
        } else {
          return _this2.campaignService.getCampaignDetailsById(_this2.id).pipe((0,src_app_core_shared_rxjs_utils__WEBPACK_IMPORTED_MODULE_5__.throwIfNil)(function () {
            return new src_app_core_shared_services_error_service__WEBPACK_IMPORTED_MODULE_7__.UserError({
              id: 'campaign-not-found',
              message: 'campaigns.detail.not_found'
            });
          }), (0,rxjs__WEBPACK_IMPORTED_MODULE_25__.map)(function (campaign) {
            return {
              campaign: campaign,
              player: null
            };
          }), _this2.errorService.getErrorHandler('normal'));
        }
      })).subscribe(function (campaignContainer) {
        var _a, _b, _c, _d, _e, _f, _g, _h, _j, _k;

        _this2.campaignContainer = campaignContainer;
        _this2.titlePage = (_b = (_a = _this2.campaignContainer) === null || _a === void 0 ? void 0 : _a.campaign) === null || _b === void 0 ? void 0 : _b.name[_this2.language];
        _this2.colorCampaign = (_d = (_c = _this2.campaignContainer) === null || _c === void 0 ? void 0 : _c.campaign) === null || _d === void 0 ? void 0 : _d.type;
        _this2.imagePath = ((_f = (_e = _this2.campaignContainer) === null || _e === void 0 ? void 0 : _e.campaign) === null || _f === void 0 ? void 0 : _f.logo.url) ? (_h = (_g = _this2.campaignContainer) === null || _g === void 0 ? void 0 : _g.campaign) === null || _h === void 0 ? void 0 : _h.logo.url : 'data:image/jpg;base64,' + ((_k = (_j = _this2.campaignContainer) === null || _j === void 0 ? void 0 : _j.campaign) === null || _k === void 0 ? void 0 : _k.logo.image);

        _this2.changePageSettings();
      });
    }
  }, {
    key: "ionViewWillEnter",
    value: function ionViewWillEnter() {
      this.changePageSettings();
    }
  }, {
    key: "changePageSettings",
    value: function changePageSettings() {
      this.pageSettingsService.set({
        color: this.colorCampaign,
        // FIXME: ! title is already translated!
        title: this.titlePage
      });
    }
  }, {
    key: "openDetail",
    value: function openDetail(detail) {
      var _a, _b;

      return (0,tslib__WEBPACK_IMPORTED_MODULE_35__.__awaiter)(this, void 0, void 0, /*#__PURE__*/_regeneratorRuntime().mark(function _callee() {
        var modal;
        return _regeneratorRuntime().wrap(function _callee$(_context) {
          while (1) switch (_context.prev = _context.next) {
            case 0:
              _context.next = 2;
              return this.modalController.create({
                component: _detail_modal_detail_modal__WEBPACK_IMPORTED_MODULE_3__.DetailCampaignModalPage,
                cssClass: 'modalInfo',
                componentProps: {
                  detail: detail,
                  type: (_b = (_a = this.campaignContainer) === null || _a === void 0 ? void 0 : _a.campaign) === null || _b === void 0 ? void 0 : _b.type
                }
              });

            case 2:
              modal = _context.sent;
              _context.next = 5;
              return modal.present();

            case 5:
              _context.next = 7;
              return modal.onWillDismiss();

            case 7:
            case "end":
              return _context.stop();
          }
        }, _callee, this);
      }));
    }
  }, {
    key: "openCompanies",
    value: function openCompanies() {
      return (0,tslib__WEBPACK_IMPORTED_MODULE_35__.__awaiter)(this, void 0, void 0, /*#__PURE__*/_regeneratorRuntime().mark(function _callee2() {
        var modal;
        return _regeneratorRuntime().wrap(function _callee2$(_context2) {
          while (1) switch (_context2.prev = _context2.next) {
            case 0:
              _context2.next = 2;
              return this.modalController.create({
                component: _companies_modal_companies_modal__WEBPACK_IMPORTED_MODULE_8__.CompaniesCampaignModalPage,
                cssClass: 'modalConfirm',
                componentProps: {
                  campaign: this.campaignContainer.campaign
                }
              });

            case 2:
              modal = _context2.sent;
              _context2.next = 5;
              return modal.present();

            case 5:
              _context2.next = 7;
              return modal.onWillDismiss();

            case 7:
            case "end":
              return _context2.stop();
          }
        }, _callee2, this);
      }));
    }
  }, {
    key: "getCampaignSponsor",
    value: function getCampaignSponsor(details) {
      return details.filter(function (detail) {
        return detail.type === 'sponsor';
      })[0];
    }
  }, {
    key: "campaignHasSponsor",
    value: function campaignHasSponsor(details) {
      return details.filter(function (detail) {
        return detail.type === 'sponsor';
      }).length > 0;
    }
  }, {
    key: "getCampaignFAQ",
    value: function getCampaignFAQ(details) {
      return details.filter(function (detail) {
        return detail.type === 'faq';
      })[0];
    }
  }, {
    key: "campaignHasFAQ",
    value: function campaignHasFAQ(details) {
      return details.filter(function (detail) {
        return detail.type === 'faq';
      }).length > 0;
    }
  }, {
    key: "clickDescription",
    value: function clickDescription() {
      if (this.isTextOverflow('descText') || this.descriptionExpanded) {
        this.descriptionExpanded = !this.descriptionExpanded;
      }
    }
  }, {
    key: "getCampaign",
    value: function getCampaign() {
      return JSON.stringify(this.campaignContainer.campaign);
    }
  }, {
    key: "isPersonal",
    value: function isPersonal() {
      return this.campaignContainer.campaign.type === 'personal';
    }
  }, {
    key: "isCompany",
    value: function isCompany() {
      return this.campaignContainer.campaign.type === 'company';
    }
  }, {
    key: "isSchool",
    value: function isSchool() {
      return this.campaignContainer.campaign.type === 'school';
    }
  }, {
    key: "getLeaderboardLink",
    value: function getLeaderboardLink() {
      var isSchool = this.campaignContainer.campaign.type === 'school';
      var page = isSchool ? 'school-leaderboard' : 'leaderboard';
      var campaignId = this.campaignContainer.campaign.campaignId;
      return ["/pages/tabs/home/details/".concat(campaignId, "/").concat(page)];
    }
  }, {
    key: "campaignHas",
    value: function campaignHas(what) {
      var _a;

      return ((_a = this.campaignService.getFunctionalityByType(what, this.campaignContainer.campaign.type)) === null || _a === void 0 ? void 0 : _a.present) || false || what === 'leaderboard' && this.campaignHasPlacement(this.campaignContainer.campaign);
    }
  }, {
    key: "campaignHasPlacement",
    value: function campaignHasPlacement(campaign) {
      var _a;

      return campaign.type === 'company' && ((_a = campaign.campaignPlacement) === null || _a === void 0 ? void 0 : _a.active);
    }
  }, {
    key: "unsubscribeCampaign",
    value: function unsubscribeCampaign() {
      return (0,tslib__WEBPACK_IMPORTED_MODULE_35__.__awaiter)(this, void 0, void 0, /*#__PURE__*/_regeneratorRuntime().mark(function _callee3() {
        var _this3 = this;

        var modal, _yield$modal$onWillDi, data;

        return _regeneratorRuntime().wrap(function _callee3$(_context3) {
          while (1) switch (_context3.prev = _context3.next) {
            case 0:
              _context3.next = 2;
              return this.modalController.create({
                component: _unsubscribe_modal_unsubscribe_modal__WEBPACK_IMPORTED_MODULE_4__.UnsubscribeModalPage,
                cssClass: 'modal-challenge',
                swipeToClose: true
              });

            case 2:
              modal = _context3.sent;
              _context3.next = 5;
              return modal.present();

            case 5:
              _context3.next = 7;
              return modal.onWillDismiss();

            case 7:
              _yield$modal$onWillDi = _context3.sent;
              data = _yield$modal$onWillDi.data;

              if (data) {
                this.unsubSub = this.campaignService.unsubscribeCampaign(this.campaignContainer.campaign.campaignId).subscribe(function (result) {
                  var _a, _b;

                  _this3.alertService.showToast({
                    messageTranslateKey: 'campaigns.unregistered'
                  });

                  (_a = _this3.subStat) === null || _a === void 0 ? void 0 : _a.unsubscribe();
                  (_b = _this3.myCampaignSub) === null || _b === void 0 ? void 0 : _b.unsubscribe();

                  _this3.navCtrl.navigateRoot('/pages/tabs/home');
                });
              }

            case 10:
            case "end":
              return _context3.stop();
          }
        }, _callee3, this);
      }));
    }
  }, {
    key: "back",
    value: function back() {
      this.navCtrl.back();
    }
  }, {
    key: "isTextOverflow",
    value: function isTextOverflow(elementId) {
      var elem = document.getElementById(elementId);

      if (elem) {
        return elem.offsetHeight < elem.scrollHeight;
      } else {
        return false;
      }
    }
  }, {
    key: "openSupport",
    value: function openSupport() {
      var _a, _b, _c, _d, _e, _f, _g, _h;

      window.open('mailto:' + src_environments_environment__WEBPACK_IMPORTED_MODULE_6__.environment.support.email + '?subject=Play%26go%20' + ((_b = (_a = this.campaignContainer) === null || _a === void 0 ? void 0 : _a.campaign) === null || _b === void 0 ? void 0 : _b.name.it) + '%20Supporto&body=-----------NON CANCELLARE-----------%0D%0A%0D%0A' + 'territoryId: ' + this.profile.territoryId + '%0D%0Acampagna: ' + ((_d = (_c = this.campaignContainer) === null || _c === void 0 ? void 0 : _c.campaign) === null || _d === void 0 ? void 0 : _d.campaignId) + (((_f = (_e = this.campaignContainer) === null || _e === void 0 ? void 0 : _e.campaign) === null || _f === void 0 ? void 0 : _f.type) === 'school' ? '%0D%0Ateam: ' + ((_h = (_g = this.team) === null || _g === void 0 ? void 0 : _g.customData) === null || _h === void 0 ? void 0 : _h.name) : '') + '%0D%0AplayerId: ' + this.profile.playerId + '%0D%0A%0D%0A-----SCRIVI IL TUO MESSAGGIO QUI SOTTO----'); // territorio, campagna, nome squadra, ID utente (Oggetto: "Play&go <nome campagna> Supporto"
    }
  }]);

  return CampaignDetailsPage;
}();

CampaignDetailsPage.ɵfac = function CampaignDetailsPage_Factory(t) {
  return new (t || CampaignDetailsPage)(_angular_core__WEBPACK_IMPORTED_MODULE_23__["ɵɵdirectiveInject"](_angular_router__WEBPACK_IMPORTED_MODULE_36__.ActivatedRoute), _angular_core__WEBPACK_IMPORTED_MODULE_23__["ɵɵdirectiveInject"](src_app_core_shared_services_campaign_service__WEBPACK_IMPORTED_MODULE_9__.CampaignService), _angular_core__WEBPACK_IMPORTED_MODULE_23__["ɵɵdirectiveInject"](src_app_core_shared_services_alert_service__WEBPACK_IMPORTED_MODULE_10__.AlertService), _angular_core__WEBPACK_IMPORTED_MODULE_23__["ɵɵdirectiveInject"](src_app_core_shared_services_user_service__WEBPACK_IMPORTED_MODULE_11__.UserService), _angular_core__WEBPACK_IMPORTED_MODULE_23__["ɵɵdirectiveInject"](_ionic_angular__WEBPACK_IMPORTED_MODULE_37__.NavController), _angular_core__WEBPACK_IMPORTED_MODULE_23__["ɵɵdirectiveInject"](_ionic_angular__WEBPACK_IMPORTED_MODULE_37__.ModalController), _angular_core__WEBPACK_IMPORTED_MODULE_23__["ɵɵdirectiveInject"](src_app_core_shared_services_notifications_notifications_service__WEBPACK_IMPORTED_MODULE_12__.NotificationService), _angular_core__WEBPACK_IMPORTED_MODULE_23__["ɵɵdirectiveInject"](src_app_core_shared_services_page_settings_service__WEBPACK_IMPORTED_MODULE_13__.PageSettingsService), _angular_core__WEBPACK_IMPORTED_MODULE_23__["ɵɵdirectiveInject"](src_app_core_shared_services_error_service__WEBPACK_IMPORTED_MODULE_7__.ErrorService), _angular_core__WEBPACK_IMPORTED_MODULE_23__["ɵɵdirectiveInject"](src_app_core_shared_services_team_service__WEBPACK_IMPORTED_MODULE_14__.TeamService));
};

CampaignDetailsPage.ɵcmp = /*@__PURE__*/_angular_core__WEBPACK_IMPORTED_MODULE_23__["ɵɵdefineComponent"]({
  type: CampaignDetailsPage,
  selectors: [["app-campaign-details"]],
  viewQuery: function CampaignDetailsPage_Query(rf, ctx) {
    if (rf & 1) {
      _angular_core__WEBPACK_IMPORTED_MODULE_23__["ɵɵviewQuery"](_c0, 5);
      _angular_core__WEBPACK_IMPORTED_MODULE_23__["ɵɵviewQuery"](_c1, 5);
    }

    if (rf & 2) {
      var _t;

      _angular_core__WEBPACK_IMPORTED_MODULE_23__["ɵɵqueryRefresh"](_t = _angular_core__WEBPACK_IMPORTED_MODULE_23__["ɵɵloadQuery"]()) && (ctx.ionContent = _t.first);
      _angular_core__WEBPACK_IMPORTED_MODULE_23__["ɵɵqueryRefresh"](_t = _angular_core__WEBPACK_IMPORTED_MODULE_23__["ɵɵloadQuery"]()) && (ctx.descText = _t.first);
    }
  },
  decls: 1,
  vars: 1,
  consts: [[4, "ngIf"], ["mode", "ios", "appHeader", "", "parallax", "", "height", "30vh", 3, "imageUrl", "text", "logo"], ["appContent", "", "class", "page", 3, "fullscreen", "scrollEvents", 4, "ngIf"], ["appContent", "", 1, "page", 3, "fullscreen", "scrollEvents"], [3, "campaign", "header"], [4, "ngFor", "ngForOf"], [3, "routerLink", 4, "ngIf"], [3, "routerLink"], [3, "color"], ["name", "list", 1, "icon-size-normal"], [1, "box", 3, "ngClass", "click"], ["id", "descText", 1, "text", 3, "innerHTML"], ["class", "expansion", 3, "click", 4, "ngIf"], [3, "color", "click"], ["name", "mail-outline", "end", ""], [3, "click", 4, "ngIf"], [3, "campaign", "notification"], ["name", "leaderboard", 1, "icon-size-normal"], ["name", "stat", 1, "icon-size-normal"], ["name", "default", 1, "icon-size-normal"], ["name", "badges", 1, "icon-size-normal"], ["name", "gift", 1, "icon-size-normal"], ["name", "blacklist", 1, "icon-size-normal"], [1, "expansion", 3, "click"], ["name", "chevron-up-outline", 4, "ngIf"], ["name", "chevron-down-outline", 4, "ngIf"], ["name", "chevron-up-outline"], ["name", "chevron-down-outline"], [3, "click"], ["lines", "none"], [1, "text-bold", "text-underlined"], ["name", "information-circle-outline", "end", ""], ["name", "list", "end", ""], ["name", "help-circle-outline", "end", ""], [3, "innerHTML"], ["color", "danger"], ["name", "leave", 1, "icon-size-normal"]],
  template: function CampaignDetailsPage_Template(rf, ctx) {
    if (rf & 1) {
      _angular_core__WEBPACK_IMPORTED_MODULE_23__["ɵɵtemplate"](0, CampaignDetailsPage_ng_container_0_Template, 5, 11, "ng-container", 0);
    }

    if (rf & 2) {
      _angular_core__WEBPACK_IMPORTED_MODULE_23__["ɵɵproperty"]("ngIf", ctx.campaignContainer);
    }
  },
  directives: [_angular_common__WEBPACK_IMPORTED_MODULE_38__.NgIf, _ionic_angular__WEBPACK_IMPORTED_MODULE_37__.IonHeader, _core_shared_directives_parallax_header_directive__WEBPACK_IMPORTED_MODULE_15__.ParallaxDirective, _core_shared_layout_header_header_directive__WEBPACK_IMPORTED_MODULE_16__.HeaderDirective, _ionic_angular__WEBPACK_IMPORTED_MODULE_37__.IonContent, _core_shared_layout_content_content_directive__WEBPACK_IMPORTED_MODULE_17__.ContentDirective, _core_shared_campaigns_app_widget_campaign_app_widget_campaign_component__WEBPACK_IMPORTED_MODULE_18__.WidgetComponent, _angular_common__WEBPACK_IMPORTED_MODULE_38__.NgForOf, _campaign_notification_campaign_notification_component__WEBPACK_IMPORTED_MODULE_19__.CampaignNotificationComponent, _ionic_angular__WEBPACK_IMPORTED_MODULE_37__.IonCard, _angular_router__WEBPACK_IMPORTED_MODULE_36__.RouterLink, _ionic_angular__WEBPACK_IMPORTED_MODULE_37__.RouterLinkDelegate, _ionic_angular__WEBPACK_IMPORTED_MODULE_37__.IonItem, _ionic_angular__WEBPACK_IMPORTED_MODULE_37__.IonLabel, _core_shared_ui_icon_icon_component__WEBPACK_IMPORTED_MODULE_20__.IconComponent, _ionic_angular__WEBPACK_IMPORTED_MODULE_37__.IonIcon, _ionic_angular__WEBPACK_IMPORTED_MODULE_37__.IonCardTitle, _ionic_angular__WEBPACK_IMPORTED_MODULE_37__.IonCardContent, _angular_common__WEBPACK_IMPORTED_MODULE_38__.NgClass],
  pipes: [_core_shared_pipes_localDate_pipe__WEBPACK_IMPORTED_MODULE_21__.LocalDatePipe, _ngx_translate_core__WEBPACK_IMPORTED_MODULE_39__.TranslatePipe, _core_shared_pipes_languageMap_pipe__WEBPACK_IMPORTED_MODULE_22__.LanguageMapPipe],
  styles: [".avatar-campaign[_ngcontent-%COMP%] {\n  margin: 16px auto;\n}\n\n.expansion[_ngcontent-%COMP%] {\n  text-align: center;\n  font-size: xx-large;\n}\n\n\n\n.box[_ngcontent-%COMP%] {\n  max-height: 162px;\n  overflow: hidden;\n  transition: max-height 0.3s cubic-bezier(0, 1, 0, 1);\n}\n\nion-card[_ngcontent-%COMP%] {\n  margin-top: 40px;\n}\n\nion-card[_ngcontent-%COMP%]   ion-card-title[_ngcontent-%COMP%] {\n  font-weight: 600;\n}\n\nion-card[_ngcontent-%COMP%]   ion-item[_ngcontent-%COMP%]   ion-label[_ngcontent-%COMP%] {\n  font-weight: 600;\n}\n\n.box.open[_ngcontent-%COMP%] {\n  max-height: 100rem;\n  transition: max-height 0.3s cubic-bezier(0.9, 0, 0.8, 0.2);\n}\n\n.text[_ngcontent-%COMP%] {\n  display: -webkit-box;\n  -webkit-box-orient: vertical;\n  padding: 2px;\n  text-overflow: ellipsis;\n  overflow: hidden;\n  margin: 12px 0;\n  animation: close 0.1s linear 0.1s forwards;\n}\n\n.open[_ngcontent-%COMP%]   .text[_ngcontent-%COMP%] {\n  animation: open 0.1s linear 0s forwards;\n}\n\n\n\n@keyframes open {\n  from {\n    display: -webkit-box;\n    line-clamp: 3;\n    -webkit-line-clamp: 3;\n    -webkit-box-orient: vertical;\n  }\n  to {\n    display: -webkit-box;\n    line-clamp: initial;\n    -webkit-line-clamp: initial;\n    -webkit-box-orient: vertical;\n  }\n}\n\n@keyframes close {\n  from {\n    display: -webkit-box;\n    line-clamp: initial;\n    -webkit-line-clamp: initial;\n    -webkit-box-orient: vertical;\n  }\n  to {\n    display: -webkit-box;\n    line-clamp: 3;\n    -webkit-line-clamp: 3;\n    -webkit-box-orient: vertical;\n  }\n}\n/*# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbImNhbXBhaWduLWRldGFpbHMucGFnZS5zY3NzIl0sIm5hbWVzIjpbXSwibWFwcGluZ3MiOiJBQUFBO0VBQ0UsaUJBQUE7QUFDRjs7QUFDQTtFQUNFLGtCQUFBO0VBQ0EsbUJBQUE7QUFFRjs7QUFBQSxRQUFBOztBQUNBO0VBSUUsaUJBQUE7RUFDQSxnQkFBQTtFQUNBLG9EQUFBO0FBQUY7O0FBRUE7RUFDRSxnQkFBQTtBQUNGOztBQUFFO0VBQ0UsZ0JBQUE7QUFFSjs7QUFDSTtFQUNFLGdCQUFBO0FBQ047O0FBSUE7RUFDRSxrQkFBQTtFQUNBLDBEQUFBO0FBREY7O0FBR0E7RUFDRSxvQkFBQTtFQUNBLDRCQUFBO0VBQ0EsWUFBQTtFQUNBLHVCQUFBO0VBQ0EsZ0JBQUE7RUFDQSxjQUFBO0VBQ0EsMENBQUE7QUFBRjs7QUFFQTtFQUNFLHVDQUFBO0FBQ0Y7O0FBRUEsU0FBQTs7QUFDQTtFQUNFO0lBQ0Usb0JBQUE7SUFDQSxhQUFBO0lBQ0EscUJBQUE7SUFDQSw0QkFBQTtFQUNGO0VBQ0E7SUFDRSxvQkFBQTtJQUNBLG1CQUFBO0lBQ0EsMkJBQUE7SUFDQSw0QkFBQTtFQUNGO0FBQ0Y7O0FBRUE7RUFDRTtJQUNFLG9CQUFBO0lBQ0EsbUJBQUE7SUFDQSwyQkFBQTtJQUNBLDRCQUFBO0VBQUY7RUFFQTtJQUNFLG9CQUFBO0lBQ0EsYUFBQTtJQUNBLHFCQUFBO0lBQ0EsNEJBQUE7RUFBRjtBQUNGIiwiZmlsZSI6ImNhbXBhaWduLWRldGFpbHMucGFnZS5zY3NzIiwic291cmNlc0NvbnRlbnQiOlsiLmF2YXRhci1jYW1wYWlnbiB7XG4gIG1hcmdpbjogMTZweCBhdXRvO1xufVxuLmV4cGFuc2lvbiB7XG4gIHRleHQtYWxpZ246IGNlbnRlcjtcbiAgZm9udC1zaXplOiB4eC1sYXJnZTtcbn1cbi8qIEJveCAqL1xuLmJveCB7XG4gIC8vIG1hcmdpbjogMjJweCBhdXRvO1xuICAvLyB3aWR0aDogMzIwcHg7XG4gIC8vIHBhZGRpbmc6IDEycHggMzJweCA2NHB4O1xuICBtYXgtaGVpZ2h0OiAxNjJweDtcbiAgb3ZlcmZsb3c6IGhpZGRlbjtcbiAgdHJhbnNpdGlvbjogbWF4LWhlaWdodCAwLjNzIGN1YmljLWJlemllcigwLCAxLCAwLCAxKTtcbn1cbmlvbi1jYXJkIHtcbiAgbWFyZ2luLXRvcDogNDBweDtcbiAgaW9uLWNhcmQtdGl0bGUge1xuICAgIGZvbnQtd2VpZ2h0OiA2MDA7XG4gIH1cbiAgaW9uLWl0ZW0ge1xuICAgIGlvbi1sYWJlbCB7XG4gICAgICBmb250LXdlaWdodDogNjAwO1xuICAgIH1cbiAgfVxufVxuXG4uYm94Lm9wZW4ge1xuICBtYXgtaGVpZ2h0OiAxMDByZW07XG4gIHRyYW5zaXRpb246IG1heC1oZWlnaHQgMC4zcyBjdWJpYy1iZXppZXIoMC45LCAwLCAwLjgsIDAuMik7XG59XG4udGV4dCB7XG4gIGRpc3BsYXk6IC13ZWJraXQtYm94O1xuICAtd2Via2l0LWJveC1vcmllbnQ6IHZlcnRpY2FsO1xuICBwYWRkaW5nOiAycHg7XG4gIHRleHQtb3ZlcmZsb3c6IGVsbGlwc2lzO1xuICBvdmVyZmxvdzogaGlkZGVuO1xuICBtYXJnaW46IDEycHggMDtcbiAgYW5pbWF0aW9uOiBjbG9zZSAwLjFzIGxpbmVhciAwLjFzIGZvcndhcmRzO1xufVxuLm9wZW4gLnRleHQge1xuICBhbmltYXRpb246IG9wZW4gMC4xcyBsaW5lYXIgMHMgZm9yd2FyZHM7XG59XG5cbi8qIFRleHQgKi9cbkBrZXlmcmFtZXMgb3BlbiB7XG4gIGZyb20ge1xuICAgIGRpc3BsYXk6IC13ZWJraXQtYm94O1xuICAgIGxpbmUtY2xhbXA6IDM7XG4gICAgLXdlYmtpdC1saW5lLWNsYW1wOiAzO1xuICAgIC13ZWJraXQtYm94LW9yaWVudDogdmVydGljYWw7XG4gIH1cbiAgdG8ge1xuICAgIGRpc3BsYXk6IC13ZWJraXQtYm94O1xuICAgIGxpbmUtY2xhbXA6IGluaXRpYWw7XG4gICAgLXdlYmtpdC1saW5lLWNsYW1wOiBpbml0aWFsO1xuICAgIC13ZWJraXQtYm94LW9yaWVudDogdmVydGljYWw7XG4gIH1cbn1cblxuQGtleWZyYW1lcyBjbG9zZSB7XG4gIGZyb20ge1xuICAgIGRpc3BsYXk6IC13ZWJraXQtYm94O1xuICAgIGxpbmUtY2xhbXA6IGluaXRpYWw7XG4gICAgLXdlYmtpdC1saW5lLWNsYW1wOiBpbml0aWFsO1xuICAgIC13ZWJraXQtYm94LW9yaWVudDogdmVydGljYWw7XG4gIH1cbiAgdG8ge1xuICAgIGRpc3BsYXk6IC13ZWJraXQtYm94O1xuICAgIGxpbmUtY2xhbXA6IDM7XG4gICAgLXdlYmtpdC1saW5lLWNsYW1wOiAzO1xuICAgIC13ZWJraXQtYm94LW9yaWVudDogdmVydGljYWw7XG4gIH1cbn1cbiJdfQ== */"]
});

/***/ }),

/***/ 48058:
/*!******************************************************************************************************!*\
  !*** ./src/app/pages/home/campaign-details/campaign-notification/campaign-notification.component.ts ***!
  \******************************************************************************************************/
/***/ (function(__unused_webpack_module, __webpack_exports__, __webpack_require__) {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "CampaignNotificationComponent": function() { return /* binding */ CampaignNotificationComponent; }
/* harmony export */ });
/* harmony import */ var _Users_smartcommunitylab_Desktop_newWork_dslab_playgo_mobile_playgo_mobile_node_modules_babel_runtime_helpers_esm_classCallCheck_js__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./node_modules/@babel/runtime/helpers/esm/classCallCheck.js */ 78069);
/* harmony import */ var _Users_smartcommunitylab_Desktop_newWork_dslab_playgo_mobile_playgo_mobile_node_modules_babel_runtime_helpers_esm_createClass_js__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ./node_modules/@babel/runtime/helpers/esm/createClass.js */ 48047);
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! tslib */ 42321);
/* harmony import */ var src_app_core_shared_detail_notification_detail_notification_modal__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! src/app/core/shared/detail-notification/detail-notification.modal */ 72526);
/* harmony import */ var src_app_core_shared_services_notifications_notifications_service__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! src/app/core/shared/services/notifications/notifications.service */ 30299);
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! @angular/core */ 3184);
/* harmony import */ var _ionic_angular__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(/*! @ionic/angular */ 93819);
/* harmony import */ var _ngx_translate_core__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(/*! @ngx-translate/core */ 87514);
/* harmony import */ var _core_shared_ui_icon_icon_component__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! ../../../../core/shared/ui/icon/icon.component */ 71888);



function _regeneratorRuntime() { "use strict"; /*! regenerator-runtime -- Copyright (c) 2014-present, Facebook, Inc. -- license (MIT): https://github.com/facebook/regenerator/blob/main/LICENSE */ _regeneratorRuntime = function _regeneratorRuntime() { return e; }; var t, e = {}, r = Object.prototype, n = r.hasOwnProperty, o = Object.defineProperty || function (t, e, r) { t[e] = r.value; }, i = "function" == typeof Symbol ? Symbol : {}, a = i.iterator || "@@iterator", c = i.asyncIterator || "@@asyncIterator", u = i.toStringTag || "@@toStringTag"; function define(t, e, r) { return Object.defineProperty(t, e, { value: r, enumerable: !0, configurable: !0, writable: !0 }), t[e]; } try { define({}, ""); } catch (t) { define = function define(t, e, r) { return t[e] = r; }; } function wrap(t, e, r, n) { var i = e && e.prototype instanceof Generator ? e : Generator, a = Object.create(i.prototype), c = new Context(n || []); return o(a, "_invoke", { value: makeInvokeMethod(t, r, c) }), a; } function tryCatch(t, e, r) { try { return { type: "normal", arg: t.call(e, r) }; } catch (t) { return { type: "throw", arg: t }; } } e.wrap = wrap; var h = "suspendedStart", l = "suspendedYield", f = "executing", s = "completed", y = {}; function Generator() {} function GeneratorFunction() {} function GeneratorFunctionPrototype() {} var p = {}; define(p, a, function () { return this; }); var d = Object.getPrototypeOf, v = d && d(d(values([]))); v && v !== r && n.call(v, a) && (p = v); var g = GeneratorFunctionPrototype.prototype = Generator.prototype = Object.create(p); function defineIteratorMethods(t) { ["next", "throw", "return"].forEach(function (e) { define(t, e, function (t) { return this._invoke(e, t); }); }); } function AsyncIterator(t, e) { function invoke(r, o, i, a) { var c = tryCatch(t[r], t, o); if ("throw" !== c.type) { var u = c.arg, h = u.value; return h && "object" == typeof h && n.call(h, "__await") ? e.resolve(h.__await).then(function (t) { invoke("next", t, i, a); }, function (t) { invoke("throw", t, i, a); }) : e.resolve(h).then(function (t) { u.value = t, i(u); }, function (t) { return invoke("throw", t, i, a); }); } a(c.arg); } var r; o(this, "_invoke", { value: function value(t, n) { function callInvokeWithMethodAndArg() { return new e(function (e, r) { invoke(t, n, e, r); }); } return r = r ? r.then(callInvokeWithMethodAndArg, callInvokeWithMethodAndArg) : callInvokeWithMethodAndArg(); } }); } function makeInvokeMethod(e, r, n) { var o = h; return function (i, a) { if (o === f) throw new Error("Generator is already running"); if (o === s) { if ("throw" === i) throw a; return { value: t, done: !0 }; } for (n.method = i, n.arg = a;;) { var c = n.delegate; if (c) { var u = maybeInvokeDelegate(c, n); if (u) { if (u === y) continue; return u; } } if ("next" === n.method) n.sent = n._sent = n.arg;else if ("throw" === n.method) { if (o === h) throw o = s, n.arg; n.dispatchException(n.arg); } else "return" === n.method && n.abrupt("return", n.arg); o = f; var p = tryCatch(e, r, n); if ("normal" === p.type) { if (o = n.done ? s : l, p.arg === y) continue; return { value: p.arg, done: n.done }; } "throw" === p.type && (o = s, n.method = "throw", n.arg = p.arg); } }; } function maybeInvokeDelegate(e, r) { var n = r.method, o = e.iterator[n]; if (o === t) return r.delegate = null, "throw" === n && e.iterator.return && (r.method = "return", r.arg = t, maybeInvokeDelegate(e, r), "throw" === r.method) || "return" !== n && (r.method = "throw", r.arg = new TypeError("The iterator does not provide a '" + n + "' method")), y; var i = tryCatch(o, e.iterator, r.arg); if ("throw" === i.type) return r.method = "throw", r.arg = i.arg, r.delegate = null, y; var a = i.arg; return a ? a.done ? (r[e.resultName] = a.value, r.next = e.nextLoc, "return" !== r.method && (r.method = "next", r.arg = t), r.delegate = null, y) : a : (r.method = "throw", r.arg = new TypeError("iterator result is not an object"), r.delegate = null, y); } function pushTryEntry(t) { var e = { tryLoc: t[0] }; 1 in t && (e.catchLoc = t[1]), 2 in t && (e.finallyLoc = t[2], e.afterLoc = t[3]), this.tryEntries.push(e); } function resetTryEntry(t) { var e = t.completion || {}; e.type = "normal", delete e.arg, t.completion = e; } function Context(t) { this.tryEntries = [{ tryLoc: "root" }], t.forEach(pushTryEntry, this), this.reset(!0); } function values(e) { if (e || "" === e) { var r = e[a]; if (r) return r.call(e); if ("function" == typeof e.next) return e; if (!isNaN(e.length)) { var o = -1, i = function next() { for (; ++o < e.length;) if (n.call(e, o)) return next.value = e[o], next.done = !1, next; return next.value = t, next.done = !0, next; }; return i.next = i; } } throw new TypeError(typeof e + " is not iterable"); } return GeneratorFunction.prototype = GeneratorFunctionPrototype, o(g, "constructor", { value: GeneratorFunctionPrototype, configurable: !0 }), o(GeneratorFunctionPrototype, "constructor", { value: GeneratorFunction, configurable: !0 }), GeneratorFunction.displayName = define(GeneratorFunctionPrototype, u, "GeneratorFunction"), e.isGeneratorFunction = function (t) { var e = "function" == typeof t && t.constructor; return !!e && (e === GeneratorFunction || "GeneratorFunction" === (e.displayName || e.name)); }, e.mark = function (t) { return Object.setPrototypeOf ? Object.setPrototypeOf(t, GeneratorFunctionPrototype) : (t.__proto__ = GeneratorFunctionPrototype, define(t, u, "GeneratorFunction")), t.prototype = Object.create(g), t; }, e.awrap = function (t) { return { __await: t }; }, defineIteratorMethods(AsyncIterator.prototype), define(AsyncIterator.prototype, c, function () { return this; }), e.AsyncIterator = AsyncIterator, e.async = function (t, r, n, o, i) { void 0 === i && (i = Promise); var a = new AsyncIterator(wrap(t, r, n, o), i); return e.isGeneratorFunction(r) ? a : a.next().then(function (t) { return t.done ? t.value : a.next(); }); }, defineIteratorMethods(g), define(g, u, "Generator"), define(g, a, function () { return this; }), define(g, "toString", function () { return "[object Generator]"; }), e.keys = function (t) { var e = Object(t), r = []; for (var n in e) r.push(n); return r.reverse(), function next() { for (; r.length;) { var t = r.pop(); if (t in e) return next.value = t, next.done = !1, next; } return next.done = !0, next; }; }, e.values = values, Context.prototype = { constructor: Context, reset: function reset(e) { if (this.prev = 0, this.next = 0, this.sent = this._sent = t, this.done = !1, this.delegate = null, this.method = "next", this.arg = t, this.tryEntries.forEach(resetTryEntry), !e) for (var r in this) "t" === r.charAt(0) && n.call(this, r) && !isNaN(+r.slice(1)) && (this[r] = t); }, stop: function stop() { this.done = !0; var t = this.tryEntries[0].completion; if ("throw" === t.type) throw t.arg; return this.rval; }, dispatchException: function dispatchException(e) { if (this.done) throw e; var r = this; function handle(n, o) { return a.type = "throw", a.arg = e, r.next = n, o && (r.method = "next", r.arg = t), !!o; } for (var o = this.tryEntries.length - 1; o >= 0; --o) { var i = this.tryEntries[o], a = i.completion; if ("root" === i.tryLoc) return handle("end"); if (i.tryLoc <= this.prev) { var c = n.call(i, "catchLoc"), u = n.call(i, "finallyLoc"); if (c && u) { if (this.prev < i.catchLoc) return handle(i.catchLoc, !0); if (this.prev < i.finallyLoc) return handle(i.finallyLoc); } else if (c) { if (this.prev < i.catchLoc) return handle(i.catchLoc, !0); } else { if (!u) throw new Error("try statement without catch or finally"); if (this.prev < i.finallyLoc) return handle(i.finallyLoc); } } } }, abrupt: function abrupt(t, e) { for (var r = this.tryEntries.length - 1; r >= 0; --r) { var o = this.tryEntries[r]; if (o.tryLoc <= this.prev && n.call(o, "finallyLoc") && this.prev < o.finallyLoc) { var i = o; break; } } i && ("break" === t || "continue" === t) && i.tryLoc <= e && e <= i.finallyLoc && (i = null); var a = i ? i.completion : {}; return a.type = t, a.arg = e, i ? (this.method = "next", this.next = i.finallyLoc, y) : this.complete(a); }, complete: function complete(t, e) { if ("throw" === t.type) throw t.arg; return "break" === t.type || "continue" === t.type ? this.next = t.arg : "return" === t.type ? (this.rval = this.arg = t.arg, this.method = "return", this.next = "end") : "normal" === t.type && e && (this.next = e), y; }, finish: function finish(t) { for (var e = this.tryEntries.length - 1; e >= 0; --e) { var r = this.tryEntries[e]; if (r.finallyLoc === t) return this.complete(r.completion, r.afterLoc), resetTryEntry(r), y; } }, catch: function _catch(t) { for (var e = this.tryEntries.length - 1; e >= 0; --e) { var r = this.tryEntries[e]; if (r.tryLoc === t) { var n = r.completion; if ("throw" === n.type) { var o = n.arg; resetTryEntry(r); } return o; } } throw new Error("illegal catch attempt"); }, delegateYield: function delegateYield(e, r, n) { return this.delegate = { iterator: values(e), resultName: r, nextLoc: n }, "next" === this.method && (this.arg = t), y; } }, e; }









var CampaignNotificationComponent = /*#__PURE__*/function () {
  function CampaignNotificationComponent(modalController, notificationService, translateService) {
    (0,_Users_smartcommunitylab_Desktop_newWork_dslab_playgo_mobile_playgo_mobile_node_modules_babel_runtime_helpers_esm_classCallCheck_js__WEBPACK_IMPORTED_MODULE_0__["default"])(this, CampaignNotificationComponent);

    this.modalController = modalController;
    this.notificationService = notificationService;
    this.translateService = translateService;
  }

  (0,_Users_smartcommunitylab_Desktop_newWork_dslab_playgo_mobile_playgo_mobile_node_modules_babel_runtime_helpers_esm_createClass_js__WEBPACK_IMPORTED_MODULE_1__["default"])(CampaignNotificationComponent, [{
    key: "ngOnInit",
    value: function ngOnInit() {}
  }, {
    key: "openDetail",
    value: function openDetail(notification) {
      return (0,tslib__WEBPACK_IMPORTED_MODULE_5__.__awaiter)(this, void 0, void 0, /*#__PURE__*/_regeneratorRuntime().mark(function _callee() {
        var modal;
        return _regeneratorRuntime().wrap(function _callee$(_context) {
          while (1) switch (_context.prev = _context.next) {
            case 0:
              _context.next = 2;
              return this.modalController.create({
                component: src_app_core_shared_detail_notification_detail_notification_modal__WEBPACK_IMPORTED_MODULE_2__.DetailNotificationModalPage,
                cssClass: 'campaign-notification',
                componentProps: {
                  notification: notification,
                  campaign: this.campaign
                }
              });

            case 2:
              modal = _context.sent;
              _context.next = 5;
              return modal.present();

            case 5:
              //mark as read the notification
              this.notificationService.markListOfNotificationAsRead([notification]);
              _context.next = 8;
              return modal.onWillDismiss();

            case 8:
            case "end":
              return _context.stop();
          }
        }, _callee, this);
      }));
    }
  }, {
    key: "getTitle",
    value: function getTitle(notification) {
      var _a;

      switch ((_a = notification === null || notification === void 0 ? void 0 : notification.content) === null || _a === void 0 ? void 0 : _a.type) {
        case src_app_core_shared_services_notifications_notifications_service__WEBPACK_IMPORTED_MODULE_3__.NotificationType.level:
          return this.translateService.instant('modal.levelup');

        case src_app_core_shared_services_notifications_notifications_service__WEBPACK_IMPORTED_MODULE_3__.NotificationType.badge:
          return this.translateService.instant('modal.newbadge');

        default:
          return '';
      }
    }
  }, {
    key: "getImage",
    value: function getImage(notification) {
      var _a;

      switch ((_a = notification === null || notification === void 0 ? void 0 : notification.content) === null || _a === void 0 ? void 0 : _a.type) {
        case src_app_core_shared_services_notifications_notifications_service__WEBPACK_IMPORTED_MODULE_3__.NotificationType.level:
          return 'leaderboard';

        case src_app_core_shared_services_notifications_notifications_service__WEBPACK_IMPORTED_MODULE_3__.NotificationType.badge:
          return 'badges';

        default:
          return '';
      }
    }
  }]);

  return CampaignNotificationComponent;
}();

CampaignNotificationComponent.ɵfac = function CampaignNotificationComponent_Factory(t) {
  return new (t || CampaignNotificationComponent)(_angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵdirectiveInject"](_ionic_angular__WEBPACK_IMPORTED_MODULE_7__.ModalController), _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵdirectiveInject"](src_app_core_shared_services_notifications_notifications_service__WEBPACK_IMPORTED_MODULE_3__.NotificationService), _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵdirectiveInject"](_ngx_translate_core__WEBPACK_IMPORTED_MODULE_8__.TranslateService));
};

CampaignNotificationComponent.ɵcmp = /*@__PURE__*/_angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵdefineComponent"]({
  type: CampaignNotificationComponent,
  selectors: [["app-campaign-notification"]],
  inputs: {
    notification: "notification",
    campaign: "campaign"
  },
  decls: 17,
  vars: 4,
  consts: [[3, "color", "click"], ["color", "danger"], ["name", "alert"], ["size", "10"], [1, "description"], ["size", "2"], [1, "icon-size-big", 3, "name"]],
  template: function CampaignNotificationComponent_Template(rf, ctx) {
    if (rf & 1) {
      _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵelementStart"](0, "ion-card", 0);
      _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵlistener"]("click", function CampaignNotificationComponent_Template_ion_card_click_0_listener() {
        return ctx.openDetail(ctx.notification);
      });
      _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵelementStart"](1, "ion-badge", 1);
      _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵelement"](2, "ion-icon", 2);
      _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵelementEnd"]();
      _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵelementStart"](3, "ion-grid")(4, "ion-row")(5, "ion-col", 3)(6, "ion-row")(7, "ion-col")(8, "span")(9, "b");
      _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵtext"](10);
      _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵelementEnd"]()()();
      _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵelementStart"](11, "ion-row")(12, "ion-col")(13, "span", 4);
      _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵtext"](14);
      _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵelementEnd"]()()()()();
      _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵelementStart"](15, "ion-col", 5);
      _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵelement"](16, "app-icon", 6);
      _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵelementEnd"]()()()();
    }

    if (rf & 2) {
      _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵproperty"]("color", (ctx.campaign == null ? null : ctx.campaign.campaign == null ? null : ctx.campaign.campaign.type) + "-light");
      _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵadvance"](10);
      _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵtextInterpolate"](ctx.getTitle(ctx.notification));
      _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵadvance"](4);
      _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵtextInterpolate"](ctx.notification.description);
      _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵadvance"](2);
      _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵproperty"]("name", ctx.getImage(ctx.notification));
    }
  },
  directives: [_ionic_angular__WEBPACK_IMPORTED_MODULE_7__.IonCard, _ionic_angular__WEBPACK_IMPORTED_MODULE_7__.IonBadge, _ionic_angular__WEBPACK_IMPORTED_MODULE_7__.IonIcon, _ionic_angular__WEBPACK_IMPORTED_MODULE_7__.IonGrid, _ionic_angular__WEBPACK_IMPORTED_MODULE_7__.IonRow, _ionic_angular__WEBPACK_IMPORTED_MODULE_7__.IonCol, _core_shared_ui_icon_icon_component__WEBPACK_IMPORTED_MODULE_4__.IconComponent],
  styles: ["ion-card[_ngcontent-%COMP%] {\n  overflow: visible;\n}\nion-card[_ngcontent-%COMP%]   .description[_ngcontent-%COMP%] {\n  font-style: italic;\n  font-size: 13px;\n  \n  width: 100%;\n  display: -webkit-box;\n  -webkit-line-clamp: 2;\n  -webkit-box-orient: vertical;\n  overflow: hidden;\n  text-overflow: ellipsis;\n}\nion-card[_ngcontent-%COMP%]   ion-badge[_ngcontent-%COMP%] {\n  position: absolute;\n  z-index: 99;\n  right: 2px;\n  top: 2px;\n}\n/*# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbImNhbXBhaWduLW5vdGlmaWNhdGlvbi5jb21wb25lbnQuc2NzcyJdLCJuYW1lcyI6W10sIm1hcHBpbmdzIjoiQUFBQTtFQUNFLGlCQUFBO0FBQ0Y7QUFBRTtFQUNFLGtCQUFBO0VBQ0EsZUFBQTtFQUNBLHFCQUFBO0VBQ0EsV0FBQTtFQUNBLG9CQUFBO0VBQ0EscUJBQUE7RUFDQSw0QkFBQTtFQUNBLGdCQUFBO0VBQ0EsdUJBQUE7QUFFSjtBQUFFO0VBQ0Usa0JBQUE7RUFDQSxXQUFBO0VBQ0EsVUFBQTtFQUNBLFFBQUE7QUFFSiIsImZpbGUiOiJjYW1wYWlnbi1ub3RpZmljYXRpb24uY29tcG9uZW50LnNjc3MiLCJzb3VyY2VzQ29udGVudCI6WyJpb24tY2FyZCB7XG4gIG92ZXJmbG93OiB2aXNpYmxlO1xuICAuZGVzY3JpcHRpb24ge1xuICAgIGZvbnQtc3R5bGU6IGl0YWxpYztcbiAgICBmb250LXNpemU6IDEzcHg7XG4gICAgLyogZm9udC1zaXplOiAxN3B4OyAqL1xuICAgIHdpZHRoOiAxMDAlO1xuICAgIGRpc3BsYXk6IC13ZWJraXQtYm94O1xuICAgIC13ZWJraXQtbGluZS1jbGFtcDogMjtcbiAgICAtd2Via2l0LWJveC1vcmllbnQ6IHZlcnRpY2FsO1xuICAgIG92ZXJmbG93OiBoaWRkZW47XG4gICAgdGV4dC1vdmVyZmxvdzogZWxsaXBzaXM7XG4gIH1cbiAgaW9uLWJhZGdlIHtcbiAgICBwb3NpdGlvbjogYWJzb2x1dGU7XG4gICAgei1pbmRleDogOTk7XG4gICAgcmlnaHQ6IDJweDtcbiAgICB0b3A6IDJweDtcbiAgfVxufVxuIl19 */"]
});

/***/ }),

/***/ 88043:
/*!********************************************************************************!*\
  !*** ./src/app/pages/home/campaign-details/companies-modal/companies.modal.ts ***!
  \********************************************************************************/
/***/ (function(__unused_webpack_module, __webpack_exports__, __webpack_require__) {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "CompaniesCampaignModalPage": function() { return /* binding */ CompaniesCampaignModalPage; }
/* harmony export */ });
/* harmony import */ var _Users_smartcommunitylab_Desktop_newWork_dslab_playgo_mobile_playgo_mobile_node_modules_babel_runtime_helpers_esm_classCallCheck_js__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./node_modules/@babel/runtime/helpers/esm/classCallCheck.js */ 78069);
/* harmony import */ var _Users_smartcommunitylab_Desktop_newWork_dslab_playgo_mobile_playgo_mobile_node_modules_babel_runtime_helpers_esm_createClass_js__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ./node_modules/@babel/runtime/helpers/esm/createClass.js */ 48047);
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @angular/core */ 3184);
/* harmony import */ var _ionic_angular__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! @ionic/angular */ 93819);
/* harmony import */ var src_app_core_shared_services_campaign_service__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! src/app/core/shared/services/campaign.service */ 23645);
/* harmony import */ var _angular_common__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! @angular/common */ 36362);
/* harmony import */ var _ngx_translate_core__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! @ngx-translate/core */ 87514);








function CompaniesCampaignModalPage_div_10_Template(rf, ctx) {
  if (rf & 1) {
    _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵelementStart"](0, "div")(1, "ion-item")(2, "ion-label");
    _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵtext"](3);
    _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵelementEnd"]()()();
  }

  if (rf & 2) {
    var company_r1 = ctx.$implicit;
    _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵadvance"](3);
    _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵtextInterpolate"](company_r1.name);
  }
}

var CompaniesCampaignModalPage = /*#__PURE__*/function () {
  function CompaniesCampaignModalPage(modalController, campaignService) {
    (0,_Users_smartcommunitylab_Desktop_newWork_dslab_playgo_mobile_playgo_mobile_node_modules_babel_runtime_helpers_esm_classCallCheck_js__WEBPACK_IMPORTED_MODULE_0__["default"])(this, CompaniesCampaignModalPage);

    this.modalController = modalController;
    this.campaignService = campaignService;
  }

  (0,_Users_smartcommunitylab_Desktop_newWork_dslab_playgo_mobile_playgo_mobile_node_modules_babel_runtime_helpers_esm_createClass_js__WEBPACK_IMPORTED_MODULE_1__["default"])(CompaniesCampaignModalPage, [{
    key: "ngOnInit",
    value: function ngOnInit() {
      var _this = this;

      var _a;

      this.sub = this.campaignService.getCompaniesForSubscription((_a = this === null || this === void 0 ? void 0 : this.campaign) === null || _a === void 0 ? void 0 : _a.campaignId).subscribe(function (result) {
        if (result) {
          _this.companies = result;
        }
      });
    }
  }, {
    key: "close",
    value: function close() {
      this.modalController.dismiss(false);
    }
  }]);

  return CompaniesCampaignModalPage;
}();

CompaniesCampaignModalPage.ɵfac = function CompaniesCampaignModalPage_Factory(t) {
  return new (t || CompaniesCampaignModalPage)(_angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵdirectiveInject"](_ionic_angular__WEBPACK_IMPORTED_MODULE_4__.ModalController), _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵdirectiveInject"](src_app_core_shared_services_campaign_service__WEBPACK_IMPORTED_MODULE_2__.CampaignService));
};

CompaniesCampaignModalPage.ɵcmp = /*@__PURE__*/_angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵdefineComponent"]({
  type: CompaniesCampaignModalPage,
  selectors: [["app-detail-modal"]],
  decls: 11,
  vars: 7,
  consts: [["color", "playgo"], ["slot", "end"], [3, "click"], [1, "ion-padding"], [4, "ngFor", "ngForOf"]],
  template: function CompaniesCampaignModalPage_Template(rf, ctx) {
    if (rf & 1) {
      _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵelementStart"](0, "ion-header")(1, "ion-toolbar", 0)(2, "ion-title");
      _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵtext"](3);
      _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵpipe"](4, "translate");
      _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵelementEnd"]();
      _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵelementStart"](5, "ion-buttons", 1)(6, "ion-button", 2);
      _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵlistener"]("click", function CompaniesCampaignModalPage_Template_ion_button_click_6_listener() {
        return ctx.close();
      });
      _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵtext"](7);
      _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵpipe"](8, "translate");
      _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵelementEnd"]()()()();
      _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵelementStart"](9, "ion-content", 3);
      _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵtemplate"](10, CompaniesCampaignModalPage_div_10_Template, 4, 1, "div", 4);
      _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵelementEnd"]();
    }

    if (rf & 2) {
      _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵadvance"](3);
      _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵtextInterpolate"](_angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵpipeBind1"](4, 3, "campaigns.campaignmodal.title"));
      _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵadvance"](4);
      _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵtextInterpolate"](_angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵpipeBind1"](8, 5, "campaigns.campaignmodal.close"));
      _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵadvance"](3);
      _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵproperty"]("ngForOf", ctx.companies);
    }
  },
  directives: [_ionic_angular__WEBPACK_IMPORTED_MODULE_4__.IonHeader, _ionic_angular__WEBPACK_IMPORTED_MODULE_4__.IonToolbar, _ionic_angular__WEBPACK_IMPORTED_MODULE_4__.IonTitle, _ionic_angular__WEBPACK_IMPORTED_MODULE_4__.IonButtons, _ionic_angular__WEBPACK_IMPORTED_MODULE_4__.IonButton, _ionic_angular__WEBPACK_IMPORTED_MODULE_4__.IonContent, _angular_common__WEBPACK_IMPORTED_MODULE_5__.NgForOf, _ionic_angular__WEBPACK_IMPORTED_MODULE_4__.IonItem, _ionic_angular__WEBPACK_IMPORTED_MODULE_4__.IonLabel],
  pipes: [_ngx_translate_core__WEBPACK_IMPORTED_MODULE_6__.TranslatePipe],
  styles: ["\n/*# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbXSwibmFtZXMiOltdLCJtYXBwaW5ncyI6IiIsImZpbGUiOiJjb21wYW5pZXMubW9kYWwuc2NzcyJ9 */"]
});

/***/ }),

/***/ 30451:
/*!**************************************************************************!*\
  !*** ./src/app/pages/home/campaign-details/detail-modal/detail.modal.ts ***!
  \**************************************************************************/
/***/ (function(__unused_webpack_module, __webpack_exports__, __webpack_require__) {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "DetailCampaignModalPage": function() { return /* binding */ DetailCampaignModalPage; }
/* harmony export */ });
/* harmony import */ var _Users_smartcommunitylab_Desktop_newWork_dslab_playgo_mobile_playgo_mobile_node_modules_babel_runtime_helpers_esm_classCallCheck_js__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./node_modules/@babel/runtime/helpers/esm/classCallCheck.js */ 78069);
/* harmony import */ var _Users_smartcommunitylab_Desktop_newWork_dslab_playgo_mobile_playgo_mobile_node_modules_babel_runtime_helpers_esm_createClass_js__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ./node_modules/@babel/runtime/helpers/esm/createClass.js */ 48047);
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @angular/core */ 3184);
/* harmony import */ var _ionic_angular__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @ionic/angular */ 93819);




var DetailCampaignModalPage = /*#__PURE__*/function () {
  function DetailCampaignModalPage(modalController) {
    (0,_Users_smartcommunitylab_Desktop_newWork_dslab_playgo_mobile_playgo_mobile_node_modules_babel_runtime_helpers_esm_classCallCheck_js__WEBPACK_IMPORTED_MODULE_0__["default"])(this, DetailCampaignModalPage);

    this.modalController = modalController;
    this.type = 'playgo';
  }

  (0,_Users_smartcommunitylab_Desktop_newWork_dslab_playgo_mobile_playgo_mobile_node_modules_babel_runtime_helpers_esm_createClass_js__WEBPACK_IMPORTED_MODULE_1__["default"])(DetailCampaignModalPage, [{
    key: "ngOnInit",
    value: function ngOnInit() {}
  }, {
    key: "close",
    value: function close() {
      this.modalController.dismiss(false);
    }
  }]);

  return DetailCampaignModalPage;
}();

DetailCampaignModalPage.ɵfac = function DetailCampaignModalPage_Factory(t) {
  return new (t || DetailCampaignModalPage)(_angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵdirectiveInject"](_ionic_angular__WEBPACK_IMPORTED_MODULE_3__.ModalController));
};

DetailCampaignModalPage.ɵcmp = /*@__PURE__*/_angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵdefineComponent"]({
  type: DetailCampaignModalPage,
  selectors: [["app-detail-modal"]],
  decls: 9,
  vars: 3,
  consts: [[3, "color"], ["slot", "end"], [3, "click"], ["name", "close-circle-outline"], [1, "ion-padding"], [3, "innerHTML"]],
  template: function DetailCampaignModalPage_Template(rf, ctx) {
    if (rf & 1) {
      _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵelementStart"](0, "ion-header")(1, "ion-toolbar", 0)(2, "ion-title");
      _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵtext"](3);
      _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵelementEnd"]();
      _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵelementStart"](4, "ion-buttons", 1)(5, "ion-button", 2);
      _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵlistener"]("click", function DetailCampaignModalPage_Template_ion_button_click_5_listener() {
        return ctx.close();
      });
      _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵelement"](6, "ion-icon", 3);
      _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵelementEnd"]()()()();
      _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵelementStart"](7, "ion-content", 4);
      _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵelement"](8, "div", 5);
      _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵelementEnd"]();
    }

    if (rf & 2) {
      _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵadvance"](1);
      _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵproperty"]("color", ctx.type);
      _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵadvance"](2);
      _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵtextInterpolate"](ctx.detail == null ? null : ctx.detail.name);
      _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵadvance"](5);
      _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵproperty"]("innerHTML", ctx.detail == null ? null : ctx.detail.content, _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵsanitizeHtml"]);
    }
  },
  directives: [_ionic_angular__WEBPACK_IMPORTED_MODULE_3__.IonHeader, _ionic_angular__WEBPACK_IMPORTED_MODULE_3__.IonToolbar, _ionic_angular__WEBPACK_IMPORTED_MODULE_3__.IonTitle, _ionic_angular__WEBPACK_IMPORTED_MODULE_3__.IonButtons, _ionic_angular__WEBPACK_IMPORTED_MODULE_3__.IonButton, _ionic_angular__WEBPACK_IMPORTED_MODULE_3__.IonIcon, _ionic_angular__WEBPACK_IMPORTED_MODULE_3__.IonContent],
  styles: ["\n/*# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbXSwibmFtZXMiOltdLCJtYXBwaW5ncyI6IiIsImZpbGUiOiJkZXRhaWwubW9kYWwuc2NzcyJ9 */"]
});

/***/ }),

/***/ 57164:
/*!************************************************************************************!*\
  !*** ./src/app/pages/home/campaign-details/unsubscribe-modal/unsubscribe.modal.ts ***!
  \************************************************************************************/
/***/ (function(__unused_webpack_module, __webpack_exports__, __webpack_require__) {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "UnsubscribeModalPage": function() { return /* binding */ UnsubscribeModalPage; }
/* harmony export */ });
/* harmony import */ var _Users_smartcommunitylab_Desktop_newWork_dslab_playgo_mobile_playgo_mobile_node_modules_babel_runtime_helpers_esm_classCallCheck_js__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./node_modules/@babel/runtime/helpers/esm/classCallCheck.js */ 78069);
/* harmony import */ var _Users_smartcommunitylab_Desktop_newWork_dslab_playgo_mobile_playgo_mobile_node_modules_babel_runtime_helpers_esm_createClass_js__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ./node_modules/@babel/runtime/helpers/esm/createClass.js */ 48047);
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @angular/core */ 3184);
/* harmony import */ var _ionic_angular__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @ionic/angular */ 93819);
/* harmony import */ var _ngx_translate_core__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! @ngx-translate/core */ 87514);





var _c0 = ["class", "modal"];
var UnsubscribeModalPage = /*#__PURE__*/function () {
  function UnsubscribeModalPage(modalController) {
    (0,_Users_smartcommunitylab_Desktop_newWork_dslab_playgo_mobile_playgo_mobile_node_modules_babel_runtime_helpers_esm_classCallCheck_js__WEBPACK_IMPORTED_MODULE_0__["default"])(this, UnsubscribeModalPage);

    this.modalController = modalController;
  }

  (0,_Users_smartcommunitylab_Desktop_newWork_dslab_playgo_mobile_playgo_mobile_node_modules_babel_runtime_helpers_esm_createClass_js__WEBPACK_IMPORTED_MODULE_1__["default"])(UnsubscribeModalPage, [{
    key: "ngOnInit",
    value: function ngOnInit() {}
  }, {
    key: "close",
    value: function close() {
      this.modalController.dismiss(false);
    }
  }, {
    key: "confirm",
    value: function confirm() {
      this.modalController.dismiss(true);
    }
  }]);

  return UnsubscribeModalPage;
}();

UnsubscribeModalPage.ɵfac = function UnsubscribeModalPage_Factory(t) {
  return new (t || UnsubscribeModalPage)(_angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵdirectiveInject"](_ionic_angular__WEBPACK_IMPORTED_MODULE_3__.ModalController));
};

UnsubscribeModalPage.ɵcmp = /*@__PURE__*/_angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵdefineComponent"]({
  type: UnsubscribeModalPage,
  selectors: [["app-unsubscribe", 8, "modal"]],
  attrs: _c0,
  decls: 18,
  vars: 12,
  consts: [["color", "playgo", 1, "external"], [1, "title"], ["color", "playgo", 1, "internal"], [1, "body"], ["size", "6"], ["expand", "block", "color", "light", 3, "click"], ["expand", "block", "color", "danger", 3, "click"]],
  template: function UnsubscribeModalPage_Template(rf, ctx) {
    if (rf & 1) {
      _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵelementStart"](0, "ion-content", 0)(1, "p", 1);
      _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵtext"](2);
      _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵpipe"](3, "translate");
      _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵelementEnd"]();
      _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵelementStart"](4, "div", 2)(5, "p", 3);
      _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵtext"](6);
      _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵpipe"](7, "translate");
      _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵelementEnd"]()();
      _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵelementStart"](8, "ion-grid")(9, "ion-row")(10, "ion-col", 4)(11, "ion-button", 5);
      _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵlistener"]("click", function UnsubscribeModalPage_Template_ion_button_click_11_listener() {
        return ctx.close();
      });
      _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵtext"](12);
      _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵpipe"](13, "translate");
      _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵelementEnd"]()();
      _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵelementStart"](14, "ion-col", 4)(15, "ion-button", 6);
      _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵlistener"]("click", function UnsubscribeModalPage_Template_ion_button_click_15_listener() {
        return ctx.confirm();
      });
      _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵtext"](16);
      _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵpipe"](17, "translate");
      _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵelementEnd"]()()()()();
    }

    if (rf & 2) {
      _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵadvance"](2);
      _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵtextInterpolate"](_angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵpipeBind1"](3, 4, "campaigns.unsub.title"));
      _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵadvance"](4);
      _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵtextInterpolate"](_angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵpipeBind1"](7, 6, "campaigns.unsub.text"));
      _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵadvance"](6);
      _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵtextInterpolate"](_angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵpipeBind1"](13, 8, "campaigns.unsub.close"));
      _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵadvance"](4);
      _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵtextInterpolate"](_angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵpipeBind1"](17, 10, "campaigns.unsub.confirm"));
    }
  },
  directives: [_ionic_angular__WEBPACK_IMPORTED_MODULE_3__.IonContent, _ionic_angular__WEBPACK_IMPORTED_MODULE_3__.IonGrid, _ionic_angular__WEBPACK_IMPORTED_MODULE_3__.IonRow, _ionic_angular__WEBPACK_IMPORTED_MODULE_3__.IonCol, _ionic_angular__WEBPACK_IMPORTED_MODULE_3__.IonButton],
  pipes: [_ngx_translate_core__WEBPACK_IMPORTED_MODULE_4__.TranslatePipe],
  styles: [".external[_ngcontent-%COMP%]   .title[_ngcontent-%COMP%] {\n  text-align: center;\n  font-weight: bold;\n  padding: 8px;\n}\n.external[_ngcontent-%COMP%]   .internal[_ngcontent-%COMP%]   .body[_ngcontent-%COMP%] {\n  text-align: justify;\n  padding: 8px;\n}\n.external[_ngcontent-%COMP%]   ion-grid[_ngcontent-%COMP%] {\n  position: absolute;\n  bottom: 0px;\n  width: 100%;\n}\n/*# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbInVuc3Vic2NyaWJlLm1vZGFsLnNjc3MiXSwibmFtZXMiOltdLCJtYXBwaW5ncyI6IkFBQ0U7RUFDRSxrQkFBQTtFQUNBLGlCQUFBO0VBQ0EsWUFBQTtBQUFKO0FBR0k7RUFDRSxtQkFBQTtFQUNBLFlBQUE7QUFETjtBQUlFO0VBQ0Usa0JBQUE7RUFDQSxXQUFBO0VBQ0EsV0FBQTtBQUZKIiwiZmlsZSI6InVuc3Vic2NyaWJlLm1vZGFsLnNjc3MiLCJzb3VyY2VzQ29udGVudCI6WyIuZXh0ZXJuYWwge1xuICAudGl0bGUge1xuICAgIHRleHQtYWxpZ246IGNlbnRlcjtcbiAgICBmb250LXdlaWdodDogYm9sZDtcbiAgICBwYWRkaW5nOiA4cHg7XG4gIH1cbiAgLmludGVybmFsIHtcbiAgICAuYm9keSB7XG4gICAgICB0ZXh0LWFsaWduOiBqdXN0aWZ5O1xuICAgICAgcGFkZGluZzogOHB4O1xuICAgIH1cbiAgfVxuICBpb24tZ3JpZCB7XG4gICAgcG9zaXRpb246IGFic29sdXRlO1xuICAgIGJvdHRvbTogMHB4O1xuICAgIHdpZHRoOiAxMDAlO1xuICB9XG59XG4iXX0= */"]
});

/***/ })

}]);
//# sourceMappingURL=default-src_app_pages_home_campaign-details_campaign-details_module_ts.js.map