"use strict";
(self["webpackChunkapp"] = self["webpackChunkapp"] || []).push([["src_app_pages_home_campaign-details_school-leaderboard_school-leaderboard_module_ts"],{

/***/ 42341:
/*!*****************************************************************************************************!*\
  !*** ./src/app/pages/home/campaign-details/school-leaderboard/school-leaderboard-routing.module.ts ***!
  \*****************************************************************************************************/
/***/ (function(__unused_webpack_module, __webpack_exports__, __webpack_require__) {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "SchoolLeaderboardPageRoutingModule": function() { return /* binding */ SchoolLeaderboardPageRoutingModule; }
/* harmony export */ });
/* harmony import */ var _Users_smartcommunitylab_Documents_work_projects_dslab_playgo_mobile_playgo_mobile_node_modules_babel_runtime_helpers_esm_createClass_js__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./node_modules/@babel/runtime/helpers/esm/createClass.js */ 48047);
/* harmony import */ var _Users_smartcommunitylab_Documents_work_projects_dslab_playgo_mobile_playgo_mobile_node_modules_babel_runtime_helpers_esm_classCallCheck_js__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ./node_modules/@babel/runtime/helpers/esm/classCallCheck.js */ 78069);
/* harmony import */ var _angular_router__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! @angular/router */ 52816);
/* harmony import */ var _school_leaderboard_page__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! ./school-leaderboard.page */ 92541);
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @angular/core */ 3184);






var routes = [{
  path: '',
  component: _school_leaderboard_page__WEBPACK_IMPORTED_MODULE_2__.SchoolLeaderboardPage,
  data: {
    title: 'leaderboard.title'
  }
}];
var SchoolLeaderboardPageRoutingModule = /*#__PURE__*/(0,_Users_smartcommunitylab_Documents_work_projects_dslab_playgo_mobile_playgo_mobile_node_modules_babel_runtime_helpers_esm_createClass_js__WEBPACK_IMPORTED_MODULE_0__["default"])(function SchoolLeaderboardPageRoutingModule() {
  (0,_Users_smartcommunitylab_Documents_work_projects_dslab_playgo_mobile_playgo_mobile_node_modules_babel_runtime_helpers_esm_classCallCheck_js__WEBPACK_IMPORTED_MODULE_1__["default"])(this, SchoolLeaderboardPageRoutingModule);
});

SchoolLeaderboardPageRoutingModule.ɵfac = function SchoolLeaderboardPageRoutingModule_Factory(t) {
  return new (t || SchoolLeaderboardPageRoutingModule)();
};

SchoolLeaderboardPageRoutingModule.ɵmod = /*@__PURE__*/_angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵdefineNgModule"]({
  type: SchoolLeaderboardPageRoutingModule
});
SchoolLeaderboardPageRoutingModule.ɵinj = /*@__PURE__*/_angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵdefineInjector"]({
  imports: [[_angular_router__WEBPACK_IMPORTED_MODULE_4__.RouterModule.forChild(routes)], _angular_router__WEBPACK_IMPORTED_MODULE_4__.RouterModule]
});

(function () {
  (typeof ngJitMode === "undefined" || ngJitMode) && _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵsetNgModuleScope"](SchoolLeaderboardPageRoutingModule, {
    imports: [_angular_router__WEBPACK_IMPORTED_MODULE_4__.RouterModule],
    exports: [_angular_router__WEBPACK_IMPORTED_MODULE_4__.RouterModule]
  });
})();

/***/ }),

/***/ 67379:
/*!*********************************************************************************************!*\
  !*** ./src/app/pages/home/campaign-details/school-leaderboard/school-leaderboard.module.ts ***!
  \*********************************************************************************************/
/***/ (function(__unused_webpack_module, __webpack_exports__, __webpack_require__) {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "SchoolLeaderboardPageModule": function() { return /* binding */ SchoolLeaderboardPageModule; }
/* harmony export */ });
/* harmony import */ var _Users_smartcommunitylab_Documents_work_projects_dslab_playgo_mobile_playgo_mobile_node_modules_babel_runtime_helpers_esm_createClass_js__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./node_modules/@babel/runtime/helpers/esm/createClass.js */ 48047);
/* harmony import */ var _Users_smartcommunitylab_Documents_work_projects_dslab_playgo_mobile_playgo_mobile_node_modules_babel_runtime_helpers_esm_classCallCheck_js__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ./node_modules/@babel/runtime/helpers/esm/classCallCheck.js */ 78069);
/* harmony import */ var _school_leaderboard_routing_module__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! ./school-leaderboard-routing.module */ 42341);
/* harmony import */ var _school_leaderboard_page__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! ./school-leaderboard.page */ 92541);
/* harmony import */ var src_app_core_shared_shared_module__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! src/app/core/shared/shared.module */ 97205);
/* harmony import */ var _school_placing_detail_school_placing_detail_component__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! ./school-placing-detail/school-placing-detail.component */ 73106);
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! @angular/core */ 3184);







var SchoolLeaderboardPageModule = /*#__PURE__*/(0,_Users_smartcommunitylab_Documents_work_projects_dslab_playgo_mobile_playgo_mobile_node_modules_babel_runtime_helpers_esm_createClass_js__WEBPACK_IMPORTED_MODULE_0__["default"])(function SchoolLeaderboardPageModule() {
  (0,_Users_smartcommunitylab_Documents_work_projects_dslab_playgo_mobile_playgo_mobile_node_modules_babel_runtime_helpers_esm_classCallCheck_js__WEBPACK_IMPORTED_MODULE_1__["default"])(this, SchoolLeaderboardPageModule);
});

SchoolLeaderboardPageModule.ɵfac = function SchoolLeaderboardPageModule_Factory(t) {
  return new (t || SchoolLeaderboardPageModule)();
};

SchoolLeaderboardPageModule.ɵmod = /*@__PURE__*/_angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵdefineNgModule"]({
  type: SchoolLeaderboardPageModule
});
SchoolLeaderboardPageModule.ɵinj = /*@__PURE__*/_angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵdefineInjector"]({
  imports: [[_school_leaderboard_routing_module__WEBPACK_IMPORTED_MODULE_2__.SchoolLeaderboardPageRoutingModule, src_app_core_shared_shared_module__WEBPACK_IMPORTED_MODULE_4__.PlayGoSharedModule]]
});

(function () {
  (typeof ngJitMode === "undefined" || ngJitMode) && _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵsetNgModuleScope"](SchoolLeaderboardPageModule, {
    declarations: [_school_leaderboard_page__WEBPACK_IMPORTED_MODULE_3__.SchoolLeaderboardPage, _school_placing_detail_school_placing_detail_component__WEBPACK_IMPORTED_MODULE_5__.SchoolPlacingDetailComponent],
    imports: [_school_leaderboard_routing_module__WEBPACK_IMPORTED_MODULE_2__.SchoolLeaderboardPageRoutingModule, src_app_core_shared_shared_module__WEBPACK_IMPORTED_MODULE_4__.PlayGoSharedModule]
  });
})();

/***/ }),

/***/ 92541:
/*!*******************************************************************************************!*\
  !*** ./src/app/pages/home/campaign-details/school-leaderboard/school-leaderboard.page.ts ***!
  \*******************************************************************************************/
/***/ (function(__unused_webpack_module, __webpack_exports__, __webpack_require__) {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "SchoolLeaderboardPage": function() { return /* binding */ SchoolLeaderboardPage; }
/* harmony export */ });
/* harmony import */ var _Users_smartcommunitylab_Documents_work_projects_dslab_playgo_mobile_playgo_mobile_node_modules_babel_runtime_helpers_esm_toConsumableArray_js__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./node_modules/@babel/runtime/helpers/esm/toConsumableArray.js */ 58277);
/* harmony import */ var _Users_smartcommunitylab_Documents_work_projects_dslab_playgo_mobile_playgo_mobile_node_modules_babel_runtime_helpers_esm_defineProperty_js__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ./node_modules/@babel/runtime/helpers/esm/defineProperty.js */ 77797);
/* harmony import */ var _Users_smartcommunitylab_Documents_work_projects_dslab_playgo_mobile_playgo_mobile_node_modules_babel_runtime_helpers_esm_classCallCheck_js__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! ./node_modules/@babel/runtime/helpers/esm/classCallCheck.js */ 78069);
/* harmony import */ var _Users_smartcommunitylab_Documents_work_projects_dslab_playgo_mobile_playgo_mobile_node_modules_babel_runtime_helpers_esm_createClass_js__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! ./node_modules/@babel/runtime/helpers/esm/createClass.js */ 48047);
/* harmony import */ var luxon__WEBPACK_IMPORTED_MODULE_17__ = __webpack_require__(/*! luxon */ 29527);
/* harmony import */ var lodash_es__WEBPACK_IMPORTED_MODULE_22__ = __webpack_require__(/*! lodash-es */ 97732);
/* harmony import */ var rxjs__WEBPACK_IMPORTED_MODULE_23__ = __webpack_require__(/*! rxjs */ 80228);
/* harmony import */ var rxjs__WEBPACK_IMPORTED_MODULE_25__ = __webpack_require__(/*! rxjs */ 26562);
/* harmony import */ var rxjs_operators__WEBPACK_IMPORTED_MODULE_18__ = __webpack_require__(/*! rxjs/operators */ 50635);
/* harmony import */ var rxjs_operators__WEBPACK_IMPORTED_MODULE_19__ = __webpack_require__(/*! rxjs/operators */ 98977);
/* harmony import */ var rxjs_operators__WEBPACK_IMPORTED_MODULE_20__ = __webpack_require__(/*! rxjs/operators */ 89196);
/* harmony import */ var rxjs_operators__WEBPACK_IMPORTED_MODULE_21__ = __webpack_require__(/*! rxjs/operators */ 32673);
/* harmony import */ var rxjs_operators__WEBPACK_IMPORTED_MODULE_24__ = __webpack_require__(/*! rxjs/operators */ 44874);
/* harmony import */ var src_app_core_shared_rxjs_utils__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! src/app/core/shared/rxjs.utils */ 9257);
/* harmony import */ var src_app_core_shared_time_utils__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! src/app/core/shared/time.utils */ 93462);
/* harmony import */ var src_app_core_shared_tracking_trip_model__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! src/app/core/shared/tracking/trip.model */ 49110);
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_16__ = __webpack_require__(/*! @angular/core */ 3184);
/* harmony import */ var _angular_router__WEBPACK_IMPORTED_MODULE_26__ = __webpack_require__(/*! @angular/router */ 52816);
/* harmony import */ var src_app_core_api_generated_controllers_reportController_service__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(/*! src/app/core/api/generated/controllers/reportController.service */ 59730);
/* harmony import */ var src_app_core_shared_services_user_service__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(/*! src/app/core/shared/services/user.service */ 50749);
/* harmony import */ var src_app_core_shared_services_campaign_service__WEBPACK_IMPORTED_MODULE_9__ = __webpack_require__(/*! src/app/core/shared/services/campaign.service */ 23645);
/* harmony import */ var src_app_core_shared_services_error_service__WEBPACK_IMPORTED_MODULE_10__ = __webpack_require__(/*! src/app/core/shared/services/error.service */ 96204);
/* harmony import */ var src_app_core_shared_services_page_settings_service__WEBPACK_IMPORTED_MODULE_11__ = __webpack_require__(/*! src/app/core/shared/services/page-settings.service */ 85294);
/* harmony import */ var _ionic_angular__WEBPACK_IMPORTED_MODULE_27__ = __webpack_require__(/*! @ionic/angular */ 93819);
/* harmony import */ var _core_shared_layout_header_header_directive__WEBPACK_IMPORTED_MODULE_12__ = __webpack_require__(/*! ../../../../core/shared/layout/header/header.directive */ 34161);
/* harmony import */ var _core_shared_layout_content_content_directive__WEBPACK_IMPORTED_MODULE_13__ = __webpack_require__(/*! ../../../../core/shared/layout/content/content.directive */ 69669);
/* harmony import */ var _angular_common__WEBPACK_IMPORTED_MODULE_28__ = __webpack_require__(/*! @angular/common */ 36362);
/* harmony import */ var _school_placing_detail_school_placing_detail_component__WEBPACK_IMPORTED_MODULE_14__ = __webpack_require__(/*! ./school-placing-detail/school-placing-detail.component */ 73106);
/* harmony import */ var _core_shared_infinite_scroll_infinite_scroll_component__WEBPACK_IMPORTED_MODULE_15__ = __webpack_require__(/*! ../../../../core/shared/infinite-scroll/infinite-scroll.component */ 3299);
/* harmony import */ var _ngx_translate_core__WEBPACK_IMPORTED_MODULE_29__ = __webpack_require__(/*! @ngx-translate/core */ 87514);


























function SchoolLeaderboardPage_ng_container_2_ion_row_3_ion_select_option_5_Template(rf, ctx) {
  if (rf & 1) {
    _angular_core__WEBPACK_IMPORTED_MODULE_16__["ɵɵelementStart"](0, "ion-select-option", 10);
    _angular_core__WEBPACK_IMPORTED_MODULE_16__["ɵɵtext"](1);
    _angular_core__WEBPACK_IMPORTED_MODULE_16__["ɵɵpipe"](2, "translate");
    _angular_core__WEBPACK_IMPORTED_MODULE_16__["ɵɵelementEnd"]();
  }

  if (rf & 2) {
    var mean_r7 = ctx.$implicit;
    var ctx_r5 = _angular_core__WEBPACK_IMPORTED_MODULE_16__["ɵɵnextContext"](3);
    _angular_core__WEBPACK_IMPORTED_MODULE_16__["ɵɵproperty"]("value", mean_r7);
    _angular_core__WEBPACK_IMPORTED_MODULE_16__["ɵɵadvance"](1);
    _angular_core__WEBPACK_IMPORTED_MODULE_16__["ɵɵtextInterpolate1"](" ", _angular_core__WEBPACK_IMPORTED_MODULE_16__["ɵɵpipeBind1"](2, 2, ctx_r5.meanLabels[mean_r7]), " ");
  }
}

function SchoolLeaderboardPage_ng_container_2_ion_row_3_ion_select_option_11_Template(rf, ctx) {
  if (rf & 1) {
    _angular_core__WEBPACK_IMPORTED_MODULE_16__["ɵɵelementStart"](0, "ion-select-option", 10);
    _angular_core__WEBPACK_IMPORTED_MODULE_16__["ɵɵtext"](1);
    _angular_core__WEBPACK_IMPORTED_MODULE_16__["ɵɵpipe"](2, "translate");
    _angular_core__WEBPACK_IMPORTED_MODULE_16__["ɵɵelementEnd"]();
  }

  if (rf & 2) {
    var metric_r8 = ctx.$implicit;
    var ctx_r6 = _angular_core__WEBPACK_IMPORTED_MODULE_16__["ɵɵnextContext"](3);
    _angular_core__WEBPACK_IMPORTED_MODULE_16__["ɵɵproperty"]("value", metric_r8);
    _angular_core__WEBPACK_IMPORTED_MODULE_16__["ɵɵadvance"](1);
    _angular_core__WEBPACK_IMPORTED_MODULE_16__["ɵɵtextInterpolate1"](" ", _angular_core__WEBPACK_IMPORTED_MODULE_16__["ɵɵpipeBind1"](2, 2, ctx_r6.metricToUnitLabel[metric_r8]), " ");
  }
}

var _c0 = function _c0() {
  return {
    cssClass: "app-alert"
  };
};

function SchoolLeaderboardPage_ng_container_2_ion_row_3_Template(rf, ctx) {
  if (rf & 1) {
    var _r10 = _angular_core__WEBPACK_IMPORTED_MODULE_16__["ɵɵgetCurrentView"]();

    _angular_core__WEBPACK_IMPORTED_MODULE_16__["ɵɵelementStart"](0, "ion-row")(1, "ion-col")(2, "ion-item", 9)(3, "ion-select", 6);
    _angular_core__WEBPACK_IMPORTED_MODULE_16__["ɵɵlistener"]("ionChange", function SchoolLeaderboardPage_ng_container_2_ion_row_3_Template_ion_select_ionChange_3_listener($event) {
      _angular_core__WEBPACK_IMPORTED_MODULE_16__["ɵɵrestoreView"](_r10);
      var ctx_r9 = _angular_core__WEBPACK_IMPORTED_MODULE_16__["ɵɵnextContext"](2);
      return ctx_r9.selectedMeanChangedSubject.next($event);
    });
    _angular_core__WEBPACK_IMPORTED_MODULE_16__["ɵɵpipe"](4, "async");
    _angular_core__WEBPACK_IMPORTED_MODULE_16__["ɵɵtemplate"](5, SchoolLeaderboardPage_ng_container_2_ion_row_3_ion_select_option_5_Template, 3, 4, "ion-select-option", 7);
    _angular_core__WEBPACK_IMPORTED_MODULE_16__["ɵɵpipe"](6, "async");
    _angular_core__WEBPACK_IMPORTED_MODULE_16__["ɵɵelementEnd"]()()();
    _angular_core__WEBPACK_IMPORTED_MODULE_16__["ɵɵelementStart"](7, "ion-col")(8, "ion-item", 9)(9, "ion-select", 6);
    _angular_core__WEBPACK_IMPORTED_MODULE_16__["ɵɵlistener"]("ionChange", function SchoolLeaderboardPage_ng_container_2_ion_row_3_Template_ion_select_ionChange_9_listener($event) {
      _angular_core__WEBPACK_IMPORTED_MODULE_16__["ɵɵrestoreView"](_r10);
      var ctx_r11 = _angular_core__WEBPACK_IMPORTED_MODULE_16__["ɵɵnextContext"](2);
      return ctx_r11.selectedMetricChangedSubject.next($event);
    });
    _angular_core__WEBPACK_IMPORTED_MODULE_16__["ɵɵpipe"](10, "async");
    _angular_core__WEBPACK_IMPORTED_MODULE_16__["ɵɵtemplate"](11, SchoolLeaderboardPage_ng_container_2_ion_row_3_ion_select_option_11_Template, 3, 4, "ion-select-option", 7);
    _angular_core__WEBPACK_IMPORTED_MODULE_16__["ɵɵelementEnd"]()()()();
  }

  if (rf & 2) {
    var ctx_r1 = _angular_core__WEBPACK_IMPORTED_MODULE_16__["ɵɵnextContext"](2);
    _angular_core__WEBPACK_IMPORTED_MODULE_16__["ɵɵadvance"](2);
    _angular_core__WEBPACK_IMPORTED_MODULE_16__["ɵɵproperty"]("color", ctx_r1.campaignContainer == null ? null : ctx_r1.campaignContainer.campaign == null ? null : ctx_r1.campaignContainer.campaign.type);
    _angular_core__WEBPACK_IMPORTED_MODULE_16__["ɵɵadvance"](1);
    _angular_core__WEBPACK_IMPORTED_MODULE_16__["ɵɵproperty"]("interfaceOptions", _angular_core__WEBPACK_IMPORTED_MODULE_16__["ɵɵpureFunction0"](14, _c0))("value", _angular_core__WEBPACK_IMPORTED_MODULE_16__["ɵɵpipeBind1"](4, 8, ctx_r1.selectedMean$));
    _angular_core__WEBPACK_IMPORTED_MODULE_16__["ɵɵadvance"](2);
    _angular_core__WEBPACK_IMPORTED_MODULE_16__["ɵɵproperty"]("ngForOf", _angular_core__WEBPACK_IMPORTED_MODULE_16__["ɵɵpipeBind1"](6, 10, ctx_r1.means$));
    _angular_core__WEBPACK_IMPORTED_MODULE_16__["ɵɵadvance"](3);
    _angular_core__WEBPACK_IMPORTED_MODULE_16__["ɵɵproperty"]("color", ctx_r1.campaignContainer == null ? null : ctx_r1.campaignContainer.campaign == null ? null : ctx_r1.campaignContainer.campaign.type);
    _angular_core__WEBPACK_IMPORTED_MODULE_16__["ɵɵadvance"](1);
    _angular_core__WEBPACK_IMPORTED_MODULE_16__["ɵɵproperty"]("interfaceOptions", _angular_core__WEBPACK_IMPORTED_MODULE_16__["ɵɵpureFunction0"](15, _c0))("value", _angular_core__WEBPACK_IMPORTED_MODULE_16__["ɵɵpipeBind1"](10, 12, ctx_r1.selectedMetric$));
    _angular_core__WEBPACK_IMPORTED_MODULE_16__["ɵɵadvance"](2);
    _angular_core__WEBPACK_IMPORTED_MODULE_16__["ɵɵproperty"]("ngForOf", ctx_r1.metrics);
  }
}

function SchoolLeaderboardPage_ng_container_2_ion_row_5_Template(rf, ctx) {
  if (rf & 1) {
    _angular_core__WEBPACK_IMPORTED_MODULE_16__["ɵɵelementStart"](0, "ion-row")(1, "ion-col")(2, "ion-item", 5);
    _angular_core__WEBPACK_IMPORTED_MODULE_16__["ɵɵtext"](3);
    _angular_core__WEBPACK_IMPORTED_MODULE_16__["ɵɵpipe"](4, "translate");
    _angular_core__WEBPACK_IMPORTED_MODULE_16__["ɵɵelementEnd"]()()();
  }

  if (rf & 2) {
    var ctx_r2 = _angular_core__WEBPACK_IMPORTED_MODULE_16__["ɵɵnextContext"](2);
    _angular_core__WEBPACK_IMPORTED_MODULE_16__["ɵɵadvance"](2);
    _angular_core__WEBPACK_IMPORTED_MODULE_16__["ɵɵproperty"]("color", ctx_r2.campaignContainer == null ? null : ctx_r2.campaignContainer.campaign == null ? null : ctx_r2.campaignContainer.campaign.type);
    _angular_core__WEBPACK_IMPORTED_MODULE_16__["ɵɵadvance"](1);
    _angular_core__WEBPACK_IMPORTED_MODULE_16__["ɵɵtextInterpolate1"](" ", _angular_core__WEBPACK_IMPORTED_MODULE_16__["ɵɵpipeBind1"](4, 2, "campaigns.leaderboard.leaderboard_type.GL"), " ");
  }
}

function SchoolLeaderboardPage_ng_container_2_ion_select_option_12_Template(rf, ctx) {
  if (rf & 1) {
    _angular_core__WEBPACK_IMPORTED_MODULE_16__["ɵɵelementStart"](0, "ion-select-option", 10);
    _angular_core__WEBPACK_IMPORTED_MODULE_16__["ɵɵtext"](1);
    _angular_core__WEBPACK_IMPORTED_MODULE_16__["ɵɵpipe"](2, "translate");
    _angular_core__WEBPACK_IMPORTED_MODULE_16__["ɵɵelementEnd"]();
  }

  if (rf & 2) {
    var period_r12 = ctx.$implicit;
    _angular_core__WEBPACK_IMPORTED_MODULE_16__["ɵɵproperty"]("value", period_r12);
    _angular_core__WEBPACK_IMPORTED_MODULE_16__["ɵɵadvance"](1);
    _angular_core__WEBPACK_IMPORTED_MODULE_16__["ɵɵtextInterpolate1"](" ", _angular_core__WEBPACK_IMPORTED_MODULE_16__["ɵɵpipeBind1"](2, 2, period_r12.labelKey), " ");
  }
}

function SchoolLeaderboardPage_ng_container_2_ng_container_16_ng_template_4_Template(rf, ctx) {
  if (rf & 1) {
    _angular_core__WEBPACK_IMPORTED_MODULE_16__["ɵɵelement"](0, "app-school-placing-detail", 8);
    _angular_core__WEBPACK_IMPORTED_MODULE_16__["ɵɵpipe"](1, "async");
  }

  if (rf & 2) {
    var placing_r15 = ctx.item;
    var ctx_r14 = _angular_core__WEBPACK_IMPORTED_MODULE_16__["ɵɵnextContext"](3);
    _angular_core__WEBPACK_IMPORTED_MODULE_16__["ɵɵproperty"]("placing", placing_r15)("unitLabelKey", _angular_core__WEBPACK_IMPORTED_MODULE_16__["ɵɵpipeBind1"](1, 4, ctx_r14.numberWithUnitKey$))("first", false)("campaign", ctx_r14.campaignContainer);
  }
}

function SchoolLeaderboardPage_ng_container_2_ng_container_16_Template(rf, ctx) {
  if (rf & 1) {
    var _r17 = _angular_core__WEBPACK_IMPORTED_MODULE_16__["ɵɵgetCurrentView"]();

    _angular_core__WEBPACK_IMPORTED_MODULE_16__["ɵɵelementContainerStart"](0);
    _angular_core__WEBPACK_IMPORTED_MODULE_16__["ɵɵelementStart"](1, "app-infinite-scroll", 11);
    _angular_core__WEBPACK_IMPORTED_MODULE_16__["ɵɵlistener"]("request", function SchoolLeaderboardPage_ng_container_2_ng_container_16_Template_app_infinite_scroll_request_1_listener($event) {
      _angular_core__WEBPACK_IMPORTED_MODULE_16__["ɵɵrestoreView"](_r17);
      var ctx_r16 = _angular_core__WEBPACK_IMPORTED_MODULE_16__["ɵɵnextContext"](2);
      return ctx_r16.scrollRequestSubject.next($event);
    });
    _angular_core__WEBPACK_IMPORTED_MODULE_16__["ɵɵpipe"](2, "async");
    _angular_core__WEBPACK_IMPORTED_MODULE_16__["ɵɵpipe"](3, "async");
    _angular_core__WEBPACK_IMPORTED_MODULE_16__["ɵɵtemplate"](4, SchoolLeaderboardPage_ng_container_2_ng_container_16_ng_template_4_Template, 2, 6, "ng-template", 12);
    _angular_core__WEBPACK_IMPORTED_MODULE_16__["ɵɵelementEnd"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_16__["ɵɵelementContainerEnd"]();
  }

  if (rf & 2) {
    var ctx_r4 = _angular_core__WEBPACK_IMPORTED_MODULE_16__["ɵɵnextContext"](2);
    _angular_core__WEBPACK_IMPORTED_MODULE_16__["ɵɵadvance"](1);
    _angular_core__WEBPACK_IMPORTED_MODULE_16__["ɵɵproperty"]("resetItems", _angular_core__WEBPACK_IMPORTED_MODULE_16__["ɵɵpipeBind1"](2, 2, ctx_r4.resetItems$))("response", _angular_core__WEBPACK_IMPORTED_MODULE_16__["ɵɵpipeBind1"](3, 4, ctx_r4.leaderboardScrollResponse$));
  }
}

function SchoolLeaderboardPage_ng_container_2_Template(rf, ctx) {
  if (rf & 1) {
    var _r19 = _angular_core__WEBPACK_IMPORTED_MODULE_16__["ɵɵgetCurrentView"]();

    _angular_core__WEBPACK_IMPORTED_MODULE_16__["ɵɵelementContainerStart"](0);
    _angular_core__WEBPACK_IMPORTED_MODULE_16__["ɵɵelementStart"](1, "div", 3)(2, "div", 4);
    _angular_core__WEBPACK_IMPORTED_MODULE_16__["ɵɵtemplate"](3, SchoolLeaderboardPage_ng_container_2_ion_row_3_Template, 12, 16, "ion-row", 2);
    _angular_core__WEBPACK_IMPORTED_MODULE_16__["ɵɵpipe"](4, "async");
    _angular_core__WEBPACK_IMPORTED_MODULE_16__["ɵɵtemplate"](5, SchoolLeaderboardPage_ng_container_2_ion_row_5_Template, 5, 4, "ion-row", 2);
    _angular_core__WEBPACK_IMPORTED_MODULE_16__["ɵɵpipe"](6, "async");
    _angular_core__WEBPACK_IMPORTED_MODULE_16__["ɵɵelementStart"](7, "ion-row")(8, "ion-col")(9, "ion-item", 5)(10, "ion-select", 6);
    _angular_core__WEBPACK_IMPORTED_MODULE_16__["ɵɵlistener"]("ionChange", function SchoolLeaderboardPage_ng_container_2_Template_ion_select_ionChange_10_listener($event) {
      _angular_core__WEBPACK_IMPORTED_MODULE_16__["ɵɵrestoreView"](_r19);
      var ctx_r18 = _angular_core__WEBPACK_IMPORTED_MODULE_16__["ɵɵnextContext"]();
      return ctx_r18.periodChangedSubject.next($event);
    });
    _angular_core__WEBPACK_IMPORTED_MODULE_16__["ɵɵpipe"](11, "async");
    _angular_core__WEBPACK_IMPORTED_MODULE_16__["ɵɵtemplate"](12, SchoolLeaderboardPage_ng_container_2_ion_select_option_12_Template, 3, 4, "ion-select-option", 7);
    _angular_core__WEBPACK_IMPORTED_MODULE_16__["ɵɵelementEnd"]()()()();
    _angular_core__WEBPACK_IMPORTED_MODULE_16__["ɵɵelement"](13, "app-school-placing-detail", 8);
    _angular_core__WEBPACK_IMPORTED_MODULE_16__["ɵɵpipe"](14, "async");
    _angular_core__WEBPACK_IMPORTED_MODULE_16__["ɵɵpipe"](15, "async");
    _angular_core__WEBPACK_IMPORTED_MODULE_16__["ɵɵelementEnd"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_16__["ɵɵtemplate"](16, SchoolLeaderboardPage_ng_container_2_ng_container_16_Template, 5, 6, "ng-container", 2);
    _angular_core__WEBPACK_IMPORTED_MODULE_16__["ɵɵpipe"](17, "async");
    _angular_core__WEBPACK_IMPORTED_MODULE_16__["ɵɵelementEnd"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_16__["ɵɵelementContainerEnd"]();
  }

  if (rf & 2) {
    var ctx_r0 = _angular_core__WEBPACK_IMPORTED_MODULE_16__["ɵɵnextContext"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_16__["ɵɵadvance"](2);
    _angular_core__WEBPACK_IMPORTED_MODULE_16__["ɵɵstyleProp"]("color", "var(--ion-color-" + ctx_r0.campaignContainer.campaign.type + "-stat-contrast)")("background-color", "var(--ion-color-" + ctx_r0.campaignContainer.campaign.type + ")");
    _angular_core__WEBPACK_IMPORTED_MODULE_16__["ɵɵadvance"](1);
    _angular_core__WEBPACK_IMPORTED_MODULE_16__["ɵɵproperty"]("ngIf", _angular_core__WEBPACK_IMPORTED_MODULE_16__["ɵɵpipeBind1"](4, 15, ctx_r0.useMeanAndMetric$));
    _angular_core__WEBPACK_IMPORTED_MODULE_16__["ɵɵadvance"](2);
    _angular_core__WEBPACK_IMPORTED_MODULE_16__["ɵɵproperty"]("ngIf", _angular_core__WEBPACK_IMPORTED_MODULE_16__["ɵɵpipeBind1"](6, 17, ctx_r0.useMeanAndMetric$) === false);
    _angular_core__WEBPACK_IMPORTED_MODULE_16__["ɵɵadvance"](4);
    _angular_core__WEBPACK_IMPORTED_MODULE_16__["ɵɵproperty"]("color", ctx_r0.campaignContainer == null ? null : ctx_r0.campaignContainer.campaign == null ? null : ctx_r0.campaignContainer.campaign.type);
    _angular_core__WEBPACK_IMPORTED_MODULE_16__["ɵɵadvance"](1);
    _angular_core__WEBPACK_IMPORTED_MODULE_16__["ɵɵproperty"]("interfaceOptions", _angular_core__WEBPACK_IMPORTED_MODULE_16__["ɵɵpureFunction0"](27, _c0))("value", _angular_core__WEBPACK_IMPORTED_MODULE_16__["ɵɵpipeBind1"](11, 19, ctx_r0.selectedPeriod$));
    _angular_core__WEBPACK_IMPORTED_MODULE_16__["ɵɵadvance"](2);
    _angular_core__WEBPACK_IMPORTED_MODULE_16__["ɵɵproperty"]("ngForOf", ctx_r0.periods);
    _angular_core__WEBPACK_IMPORTED_MODULE_16__["ɵɵadvance"](1);
    _angular_core__WEBPACK_IMPORTED_MODULE_16__["ɵɵproperty"]("placing", _angular_core__WEBPACK_IMPORTED_MODULE_16__["ɵɵpipeBind1"](14, 21, ctx_r0.playerPosition$))("unitLabelKey", _angular_core__WEBPACK_IMPORTED_MODULE_16__["ɵɵpipeBind1"](15, 23, ctx_r0.numberWithUnitKey$))("first", true)("campaign", ctx_r0.campaignContainer);
    _angular_core__WEBPACK_IMPORTED_MODULE_16__["ɵɵadvance"](3);
    _angular_core__WEBPACK_IMPORTED_MODULE_16__["ɵɵproperty"]("ngIf", _angular_core__WEBPACK_IMPORTED_MODULE_16__["ɵɵpipeBind1"](17, 25, ctx_r0.filterOptions$));
  }
}

var SchoolLeaderboardPage = /*#__PURE__*/function () {
  function SchoolLeaderboardPage(route, reportControllerService, userService, campaignService, errorService, pageSettingsService) {
    var _this = this;

    (0,_Users_smartcommunitylab_Documents_work_projects_dslab_playgo_mobile_playgo_mobile_node_modules_babel_runtime_helpers_esm_classCallCheck_js__WEBPACK_IMPORTED_MODULE_2__["default"])(this, SchoolLeaderboardPage);

    this.route = route;
    this.reportControllerService = reportControllerService;
    this.userService = userService;
    this.campaignService = campaignService;
    this.errorService = errorService;
    this.pageSettingsService = pageSettingsService;
    this.referenceDate = luxon__WEBPACK_IMPORTED_MODULE_17__.DateTime.local();
    this.periods = this.getPeriods(this.referenceDate);
    this.metricToNumberWithUnitLabel = {
      co2: 'campaigns.leaderboard.leaderboard_type_unit.co2',
      km: 'campaigns.leaderboard.leaderboard_type_unit.km'
    };
    this.metricToUnitLabel = {
      co2: 'campaigns.leaderboard.unit.co2',
      km: 'campaigns.leaderboard.unit.km'
    };
    this.meanLabels = Object.assign(Object.assign({}, src_app_core_shared_tracking_trip_model__WEBPACK_IMPORTED_MODULE_6__.transportTypeLabels), (0,_Users_smartcommunitylab_Documents_work_projects_dslab_playgo_mobile_playgo_mobile_node_modules_babel_runtime_helpers_esm_defineProperty_js__WEBPACK_IMPORTED_MODULE_1__["default"])({}, ALL_MEANS, 'campaigns.leaderboard.all_means'));
    this.campaignId$ = this.route.params.pipe((0,rxjs_operators__WEBPACK_IMPORTED_MODULE_18__.map)(function (params) {
      return params.id;
    }), (0,rxjs_operators__WEBPACK_IMPORTED_MODULE_19__.distinctUntilChanged)(), (0,rxjs_operators__WEBPACK_IMPORTED_MODULE_20__.shareReplay)(1));
    this.campaign$ = this.campaignId$.pipe((0,rxjs_operators__WEBPACK_IMPORTED_MODULE_21__.switchMap)(function (campaignId) {
      return _this.campaignService.allCampaigns$.pipe((0,rxjs_operators__WEBPACK_IMPORTED_MODULE_18__.map)(function (campaigns) {
        return (0,lodash_es__WEBPACK_IMPORTED_MODULE_22__["default"])(campaigns, {
          campaignId: campaignId
        });
      }), (0,src_app_core_shared_rxjs_utils__WEBPACK_IMPORTED_MODULE_4__.throwIfNil)(function () {
        return new Error('Campaign not found');
      }), _this.errorService.getErrorHandler());
    }), (0,rxjs_operators__WEBPACK_IMPORTED_MODULE_20__.shareReplay)(1));
    this.useMeanAndMetric$ = this.campaign$.pipe((0,rxjs_operators__WEBPACK_IMPORTED_MODULE_18__.map)(function (campaign) {
      return campaign.type === 'personal';
    }));
    this.means$ = this.campaignService.availableMeans$.pipe((0,rxjs_operators__WEBPACK_IMPORTED_MODULE_18__.map)(function (availableMeans) {
      return [ALL_MEANS].concat((0,_Users_smartcommunitylab_Documents_work_projects_dslab_playgo_mobile_playgo_mobile_node_modules_babel_runtime_helpers_esm_toConsumableArray_js__WEBPACK_IMPORTED_MODULE_0__["default"])(availableMeans));
    }));
    this.selectedMeanChangedSubject = new rxjs__WEBPACK_IMPORTED_MODULE_23__.Subject();
    this.selectedMean$ = this.selectedMeanChangedSubject.pipe((0,rxjs_operators__WEBPACK_IMPORTED_MODULE_18__.map)(function (event) {
      return event.detail.value;
    }), (0,rxjs_operators__WEBPACK_IMPORTED_MODULE_24__.startWith)(ALL_MEANS), (0,rxjs_operators__WEBPACK_IMPORTED_MODULE_20__.shareReplay)(1));
    this.metrics = ['co2', 'km'];
    this.selectedMetricChangedSubject = new rxjs__WEBPACK_IMPORTED_MODULE_23__.Subject();
    this.selectedMetric$ = this.selectedMetricChangedSubject.pipe((0,rxjs_operators__WEBPACK_IMPORTED_MODULE_18__.map)(function (event) {
      return event.detail.value;
    }), (0,rxjs_operators__WEBPACK_IMPORTED_MODULE_24__.startWith)( // initial select value
    'co2'), (0,rxjs_operators__WEBPACK_IMPORTED_MODULE_20__.shareReplay)(1));
    this.periodChangedSubject = new rxjs__WEBPACK_IMPORTED_MODULE_23__.Subject();
    this.selectedPeriod$ = this.periodChangedSubject.pipe((0,rxjs_operators__WEBPACK_IMPORTED_MODULE_18__.map)(function (event) {
      return event.detail.value;
    }), (0,rxjs_operators__WEBPACK_IMPORTED_MODULE_24__.startWith)((0,lodash_es__WEBPACK_IMPORTED_MODULE_22__["default"])(this.periods, {
      default: true
    })), // initial select value
    (0,rxjs_operators__WEBPACK_IMPORTED_MODULE_20__.shareReplay)(1));
    this.playerId$ = this.userService.userProfile$.pipe((0,rxjs_operators__WEBPACK_IMPORTED_MODULE_18__.map)(function (userProfile) {
      return userProfile.playerId;
    }), (0,rxjs_operators__WEBPACK_IMPORTED_MODULE_19__.distinctUntilChanged)());
    this.filterOptions$ = (0,rxjs__WEBPACK_IMPORTED_MODULE_25__.combineLatest)({
      mean: this.selectedMean$,
      metric: this.selectedMetric$,
      period: this.selectedPeriod$,
      campaignId: this.campaignId$,
      useMeanAndMetric: this.useMeanAndMetric$,
      playerId: this.playerId$
    });
    this.numberWithUnitKey$ = this.filterOptions$.pipe((0,rxjs_operators__WEBPACK_IMPORTED_MODULE_18__.map)(function (_ref) {
      var useMeanAndMetric = _ref.useMeanAndMetric,
          metric = _ref.metric;
      return useMeanAndMetric ? _this.metricToNumberWithUnitLabel[metric] : 'campaigns.leaderboard.leaderboard_type_unit.GL';
    }), (0,rxjs_operators__WEBPACK_IMPORTED_MODULE_20__.shareReplay)(1));
    this.playerPosition$ = this.filterOptions$.pipe((0,rxjs_operators__WEBPACK_IMPORTED_MODULE_21__.switchMap)(function (_ref2) {
      var useMeanAndMetric = _ref2.useMeanAndMetric,
          metric = _ref2.metric,
          mean = _ref2.mean,
          period = _ref2.period,
          campaignId = _ref2.campaignId,
          playerId = _ref2.playerId;

      if (useMeanAndMetric) {
        return _this.reportControllerService.getPlayerCampaingPlacingByTransportModeUsingGET({
          campaignId: campaignId,
          metric: metric,
          mean: mean === ALL_MEANS ? null : mean,
          playerId: playerId,
          dateFrom: period.from,
          dateTo: period.to
        }).pipe(_this.errorService.getErrorHandler());
      } else {
        return _this.reportControllerService.getPlayerCampaingPlacingByGameUsingGET({
          campaignId: campaignId,
          playerId: playerId,
          dateFrom: period.from,
          dateTo: period.to
        }).pipe(_this.errorService.getErrorHandler());
      }
    }), (0,rxjs_operators__WEBPACK_IMPORTED_MODULE_20__.shareReplay)(1));
    this.scrollRequestSubject = new rxjs__WEBPACK_IMPORTED_MODULE_23__.Subject();
    this.leaderboardScrollResponse$ = this.filterOptions$.pipe((0,rxjs_operators__WEBPACK_IMPORTED_MODULE_21__.switchMap)(function (_ref3) {
      var useMeanAndMetric = _ref3.useMeanAndMetric,
          metric = _ref3.metric,
          mean = _ref3.mean,
          period = _ref3.period,
          campaignId = _ref3.campaignId;
      return _this.scrollRequestSubject.pipe((0,rxjs_operators__WEBPACK_IMPORTED_MODULE_24__.startWith)({
        page: 0,
        size: 10
      }), (0,rxjs_operators__WEBPACK_IMPORTED_MODULE_21__.switchMap)(function (_ref4) {
        var page = _ref4.page,
            size = _ref4.size;

        if (useMeanAndMetric) {
          return _this.reportControllerService.getCampaingPlacingByTransportStatsUsingGET({
            page: page,
            size: size,
            campaignId: campaignId,
            metric: metric,
            mean: mean === ALL_MEANS ? null : mean,
            dateFrom: period.from,
            dateTo: period.to
          }).pipe(_this.errorService.getErrorHandler());
        } else {
          return _this.reportControllerService.getCampaingPlacingByGameUsingGET({
            page: page,
            size: size,
            campaignId: campaignId,
            dateFrom: period.from,
            dateTo: period.to
          }).pipe(_this.errorService.getErrorHandler());
        }
      }));
    }));
    this.resetItems$ = this.filterOptions$.pipe((0,rxjs_operators__WEBPACK_IMPORTED_MODULE_18__.map)(function () {
      return Symbol();
    }));
    this.subId = this.route.params.subscribe(function (params) {
      _this.id = params.id;
      _this.subCampaign = _this.campaignService.myCampaigns$.subscribe(function (campaigns) {
        _this.campaignContainer = campaigns.find(function (campaignContainer) {
          return campaignContainer.campaign.campaignId === _this.id;
        });
      });
    });
  }

  (0,_Users_smartcommunitylab_Documents_work_projects_dslab_playgo_mobile_playgo_mobile_node_modules_babel_runtime_helpers_esm_createClass_js__WEBPACK_IMPORTED_MODULE_3__["default"])(SchoolLeaderboardPage, [{
    key: "ngOnDestroy",
    value: function ngOnDestroy() {
      this.subCampaign.unsubscribe();
      this.subId.unsubscribe();
    }
  }, {
    key: "ionViewWillEnter",
    value: function ionViewWillEnter() {
      this.changePageSettings();
    }
  }, {
    key: "changePageSettings",
    value: function changePageSettings() {
      var _a, _b;

      this.pageSettingsService.set({
        color: (_b = (_a = this.campaignContainer) === null || _a === void 0 ? void 0 : _a.campaign) === null || _b === void 0 ? void 0 : _b.type
      });
    }
  }, {
    key: "getPeriods",
    value: function getPeriods(referenceDate) {
      return [{
        labelKey: 'campaigns.leaderboard.period.today',
        from: this.toServerDate(referenceDate.startOf('day')),
        to: this.toServerDate(referenceDate),
        default: false
      }, {
        labelKey: 'campaigns.leaderboard.period.this_week',
        from: this.toServerDate(referenceDate.startOf('week')),
        to: this.toServerDate(referenceDate),
        default: false
      }, {
        labelKey: 'campaigns.leaderboard.period.last_week',
        from: this.toServerDate(referenceDate.startOf('week').minus({
          weeks: 1
        })),
        to: this.toServerDate(referenceDate.startOf('week')),
        default: false
      }, {
        labelKey: 'campaigns.leaderboard.period.this_month',
        from: this.toServerDate(referenceDate.startOf('month')),
        to: this.toServerDate(referenceDate),
        default: false
      }, {
        labelKey: 'campaigns.leaderboard.period.all_time',
        // not specifying dates, will improve the server performance because of special handling
        // but we will lose the confidence that player position and leaderboard are in sync.
        // maybe it is not such deal, "All Time" leaderboard will not change so rapidly.
        from: null,
        to: null,
        default: true
      }];
    }
  }, {
    key: "toServerDate",
    value: function toServerDate(dateTime) {
      // TODO: This is actually quite tricky bug.
      // When we round reference date to the start of the day, than we get this period
      // from beginning of the day to now, where events affecting this period will
      // cause inconsistent data between the loaded pages of pagination.
      return (0,src_app_core_shared_time_utils__WEBPACK_IMPORTED_MODULE_5__.toServerDateOnly)(dateTime);
    }
  }, {
    key: "ngOnInit",
    value: function ngOnInit() {}
  }]);

  return SchoolLeaderboardPage;
}();

SchoolLeaderboardPage.ɵfac = function SchoolLeaderboardPage_Factory(t) {
  return new (t || SchoolLeaderboardPage)(_angular_core__WEBPACK_IMPORTED_MODULE_16__["ɵɵdirectiveInject"](_angular_router__WEBPACK_IMPORTED_MODULE_26__.ActivatedRoute), _angular_core__WEBPACK_IMPORTED_MODULE_16__["ɵɵdirectiveInject"](src_app_core_api_generated_controllers_reportController_service__WEBPACK_IMPORTED_MODULE_7__.ReportControllerService), _angular_core__WEBPACK_IMPORTED_MODULE_16__["ɵɵdirectiveInject"](src_app_core_shared_services_user_service__WEBPACK_IMPORTED_MODULE_8__.UserService), _angular_core__WEBPACK_IMPORTED_MODULE_16__["ɵɵdirectiveInject"](src_app_core_shared_services_campaign_service__WEBPACK_IMPORTED_MODULE_9__.CampaignService), _angular_core__WEBPACK_IMPORTED_MODULE_16__["ɵɵdirectiveInject"](src_app_core_shared_services_error_service__WEBPACK_IMPORTED_MODULE_10__.ErrorService), _angular_core__WEBPACK_IMPORTED_MODULE_16__["ɵɵdirectiveInject"](src_app_core_shared_services_page_settings_service__WEBPACK_IMPORTED_MODULE_11__.PageSettingsService));
};

SchoolLeaderboardPage.ɵcmp = /*@__PURE__*/_angular_core__WEBPACK_IMPORTED_MODULE_16__["ɵɵdefineComponent"]({
  type: SchoolLeaderboardPage,
  selectors: [["app-school-leaderboard"]],
  decls: 4,
  vars: 3,
  consts: [["appHeader", ""], ["appContent", ""], [4, "ngIf"], [1, "header-margin"], [1, "header-sticky"], [3, "color"], [3, "interfaceOptions", "value", "ionChange"], [3, "value", 4, "ngFor", "ngForOf"], [3, "placing", "unitLabelKey", "first", "campaign"], [1, "header-radius", 3, "color"], [3, "value"], [3, "resetItems", "response", "request"], ["appInfiniteScrollContent", ""]],
  template: function SchoolLeaderboardPage_Template(rf, ctx) {
    if (rf & 1) {
      _angular_core__WEBPACK_IMPORTED_MODULE_16__["ɵɵelement"](0, "ion-header", 0);
      _angular_core__WEBPACK_IMPORTED_MODULE_16__["ɵɵelementStart"](1, "ion-content", 1);
      _angular_core__WEBPACK_IMPORTED_MODULE_16__["ɵɵtemplate"](2, SchoolLeaderboardPage_ng_container_2_Template, 18, 28, "ng-container", 2);
      _angular_core__WEBPACK_IMPORTED_MODULE_16__["ɵɵpipe"](3, "async");
      _angular_core__WEBPACK_IMPORTED_MODULE_16__["ɵɵelementEnd"]();
    }

    if (rf & 2) {
      _angular_core__WEBPACK_IMPORTED_MODULE_16__["ɵɵadvance"](2);
      _angular_core__WEBPACK_IMPORTED_MODULE_16__["ɵɵproperty"]("ngIf", _angular_core__WEBPACK_IMPORTED_MODULE_16__["ɵɵpipeBind1"](3, 1, ctx.campaign$) !== null);
    }
  },
  directives: [_ionic_angular__WEBPACK_IMPORTED_MODULE_27__.IonHeader, _core_shared_layout_header_header_directive__WEBPACK_IMPORTED_MODULE_12__.HeaderDirective, _ionic_angular__WEBPACK_IMPORTED_MODULE_27__.IonContent, _core_shared_layout_content_content_directive__WEBPACK_IMPORTED_MODULE_13__.ContentDirective, _angular_common__WEBPACK_IMPORTED_MODULE_28__.NgIf, _ionic_angular__WEBPACK_IMPORTED_MODULE_27__.IonRow, _ionic_angular__WEBPACK_IMPORTED_MODULE_27__.IonCol, _ionic_angular__WEBPACK_IMPORTED_MODULE_27__.IonItem, _ionic_angular__WEBPACK_IMPORTED_MODULE_27__.IonSelect, _ionic_angular__WEBPACK_IMPORTED_MODULE_27__.SelectValueAccessor, _angular_common__WEBPACK_IMPORTED_MODULE_28__.NgForOf, _ionic_angular__WEBPACK_IMPORTED_MODULE_27__.IonSelectOption, _school_placing_detail_school_placing_detail_component__WEBPACK_IMPORTED_MODULE_14__.SchoolPlacingDetailComponent, _core_shared_infinite_scroll_infinite_scroll_component__WEBPACK_IMPORTED_MODULE_15__.InfiniteScrollComponent, _core_shared_infinite_scroll_infinite_scroll_component__WEBPACK_IMPORTED_MODULE_15__.InfiniteScrollContentDirective],
  pipes: [_angular_common__WEBPACK_IMPORTED_MODULE_28__.AsyncPipe, _ngx_translate_core__WEBPACK_IMPORTED_MODULE_29__.TranslatePipe],
  styles: ["\n/*# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbXSwibmFtZXMiOltdLCJtYXBwaW5ncyI6IiIsImZpbGUiOiJzY2hvb2wtbGVhZGVyYm9hcmQucGFnZS5zY3NzIn0= */"]
});
var ALL_MEANS = 'ALL_MEANS';

/***/ }),

/***/ 73106:
/*!*************************************************************************************************************************!*\
  !*** ./src/app/pages/home/campaign-details/school-leaderboard/school-placing-detail/school-placing-detail.component.ts ***!
  \*************************************************************************************************************************/
/***/ (function(__unused_webpack_module, __webpack_exports__, __webpack_require__) {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "SchoolPlacingDetailComponent": function() { return /* binding */ SchoolPlacingDetailComponent; }
/* harmony export */ });
/* harmony import */ var _Users_smartcommunitylab_Documents_work_projects_dslab_playgo_mobile_playgo_mobile_node_modules_babel_runtime_helpers_esm_classCallCheck_js__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./node_modules/@babel/runtime/helpers/esm/classCallCheck.js */ 78069);
/* harmony import */ var _Users_smartcommunitylab_Documents_work_projects_dslab_playgo_mobile_playgo_mobile_node_modules_babel_runtime_helpers_esm_createClass_js__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ./node_modules/@babel/runtime/helpers/esm/createClass.js */ 48047);
/* harmony import */ var rxjs_operators__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! rxjs/operators */ 50635);
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! @angular/core */ 3184);
/* harmony import */ var src_app_core_shared_services_user_service__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! src/app/core/shared/services/user.service */ 50749);
/* harmony import */ var _angular_common__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(/*! @angular/common */ 36362);
/* harmony import */ var _ionic_angular__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(/*! @ionic/angular */ 93819);
/* harmony import */ var _angular_router__WEBPACK_IMPORTED_MODULE_9__ = __webpack_require__(/*! @angular/router */ 52816);
/* harmony import */ var _core_shared_globalization_ordinal_number_ordinal_number_component__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! ../../../../../core/shared/globalization/ordinal-number/ordinal-number.component */ 56032);
/* harmony import */ var _ngx_translate_core__WEBPACK_IMPORTED_MODULE_10__ = __webpack_require__(/*! @ngx-translate/core */ 87514);
/* harmony import */ var _core_shared_pipes_localNumber_pipe__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! ../../../../../core/shared/pipes/localNumber.pipe */ 89713);












function SchoolPlacingDetailComponent_ion_item_0_ng_container_7_Template(rf, ctx) {
  if (rf & 1) {
    _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵelementContainerStart"](0);
    _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵelementStart"](1, "ion-col", 2)(2, "ion-avatar");
    _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵelement"](3, "img", 7);
    _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵpipe"](4, "async");
    _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵelementEnd"]()();
    _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵelementContainerEnd"]();
  }

  if (rf & 2) {
    var ctx_r1 = _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵnextContext"](2);
    _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵadvance"](3);
    _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵproperty"]("src", _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵpipeBind1"](4, 1, ctx_r1.playerAvatarUrl$), _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵsanitizeUrl"]);
  }
}

function SchoolPlacingDetailComponent_ion_item_0_ng_container_9_ion_avatar_2_Template(rf, ctx) {
  if (rf & 1) {
    _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵelementStart"](0, "ion-avatar");
    _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵelement"](1, "img", 7);
    _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵelementEnd"]();
  }

  if (rf & 2) {
    var ctx_r3 = _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵnextContext"](3);
    _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵadvance"](1);
    _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵproperty"]("src", ctx_r3.placing.avatar.url, _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵsanitizeUrl"]);
  }
}

function SchoolPlacingDetailComponent_ion_item_0_ng_container_9_Template(rf, ctx) {
  if (rf & 1) {
    _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵelementContainerStart"](0);
    _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵelementStart"](1, "ion-col", 2);
    _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵtemplate"](2, SchoolPlacingDetailComponent_ion_item_0_ng_container_9_ion_avatar_2_Template, 2, 1, "ion-avatar", 4);
    _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵelementEnd"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵelementContainerEnd"]();
  }

  if (rf & 2) {
    var ctx_r2 = _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵnextContext"](2);
    _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵadvance"](2);
    _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵproperty"]("ngIf", ctx_r2.placing.avatar);
  }
}

var _c0 = function _c0(a0) {
  return {
    border: a0
  };
};

var _c1 = function _c1(a0) {
  return [a0];
};

var _c2 = function _c2() {
  return [];
};

var _c3 = function _c3(a0) {
  return {
    value: a0
  };
};

function SchoolPlacingDetailComponent_ion_item_0_Template(rf, ctx) {
  if (rf & 1) {
    _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵelementStart"](0, "ion-item", 1);
    _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵpipe"](1, "async");
    _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵpipe"](2, "async");
    _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵelementStart"](3, "ion-grid")(4, "ion-row")(5, "ion-col", 2);
    _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵelement"](6, "app-ordinal-number", 3);
    _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵelementEnd"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵtemplate"](7, SchoolPlacingDetailComponent_ion_item_0_ng_container_7_Template, 5, 3, "ng-container", 4);
    _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵpipe"](8, "async");
    _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵtemplate"](9, SchoolPlacingDetailComponent_ion_item_0_ng_container_9_Template, 3, 1, "ng-container", 4);
    _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵpipe"](10, "async");
    _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵelementStart"](11, "ion-col", 5)(12, "span");
    _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵtext"](13);
    _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵelementEnd"]()();
    _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵelementStart"](14, "ion-col", 6);
    _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵtext"](15);
    _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵpipe"](16, "translate");
    _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵpipe"](17, "localNumber");
    _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵelementEnd"]()()()();
  }

  if (rf & 2) {
    var ctx_r0 = _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵnextContext"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵclassProp"]("my-placing", _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵpipeBind1"](1, 9, ctx_r0.playerId$) === ctx_r0.placing.playerId);
    _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵproperty"]("ngStyle", _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵpureFunction1"](22, _c0, ctx_r0.first ? "3px solid var(--ion-color-" + (ctx_r0.campaign == null ? null : ctx_r0.campaign.campaign == null ? null : ctx_r0.campaign.campaign.type) + ")" : ""))("routerLink", _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵpipeBind1"](2, 11, ctx_r0.playerId$) !== ctx_r0.placing.playerId ? _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵpureFunction1"](24, _c1, "/pages/user-profile/" + ctx_r0.placing.playerId + "/" + ctx_r0.placing.nickname) : _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵpureFunction0"](26, _c2));
    _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵadvance"](6);
    _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵproperty"]("value", ctx_r0.placing.position);
    _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵadvance"](1);
    _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵproperty"]("ngIf", _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵpipeBind1"](8, 13, ctx_r0.playerId$) === ctx_r0.placing.playerId);
    _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵadvance"](2);
    _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵproperty"]("ngIf", _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵpipeBind1"](10, 15, ctx_r0.playerId$) !== ctx_r0.placing.playerId);
    _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵadvance"](4);
    _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵtextInterpolate"](ctx_r0.placing.nickname);
    _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵadvance"](2);
    _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵtextInterpolate1"](" ", _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵpipeBind2"](16, 17, ctx_r0.unitLabelKey, _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵpureFunction1"](27, _c3, _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵpipeBind1"](17, 20, ctx_r0.getValue(ctx_r0.placing.value)))), " ");
  }
}

var SchoolPlacingDetailComponent = /*#__PURE__*/function () {
  function SchoolPlacingDetailComponent(userService) {
    (0,_Users_smartcommunitylab_Documents_work_projects_dslab_playgo_mobile_playgo_mobile_node_modules_babel_runtime_helpers_esm_classCallCheck_js__WEBPACK_IMPORTED_MODULE_0__["default"])(this, SchoolPlacingDetailComponent);

    this.userService = userService;
    this.playerId$ = this.userService.userProfile$.pipe((0,rxjs_operators__WEBPACK_IMPORTED_MODULE_6__.map)(function (userProfile) {
      return userProfile.playerId;
    }));
    this.playerAvatarUrl$ = this.userService.userProfile$.pipe((0,rxjs_operators__WEBPACK_IMPORTED_MODULE_6__.map)(function (userProfile) {
      return userProfile.avatar.avatarSmallUrl;
    }));
  }

  (0,_Users_smartcommunitylab_Documents_work_projects_dslab_playgo_mobile_playgo_mobile_node_modules_babel_runtime_helpers_esm_createClass_js__WEBPACK_IMPORTED_MODULE_1__["default"])(SchoolPlacingDetailComponent, [{
    key: "getValue",
    value: function getValue(value) {
      if (this.unitLabelKey === 'campaigns.leaderboard.leaderboard_type_unit.km') {
        return value / 1000;
      }

      return value;
    }
  }, {
    key: "ngOnInit",
    value: function ngOnInit() {}
  }]);

  return SchoolPlacingDetailComponent;
}();

SchoolPlacingDetailComponent.ɵfac = function SchoolPlacingDetailComponent_Factory(t) {
  return new (t || SchoolPlacingDetailComponent)(_angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵdirectiveInject"](src_app_core_shared_services_user_service__WEBPACK_IMPORTED_MODULE_2__.UserService));
};

SchoolPlacingDetailComponent.ɵcmp = /*@__PURE__*/_angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵdefineComponent"]({
  type: SchoolPlacingDetailComponent,
  selectors: [["app-school-placing-detail"]],
  inputs: {
    placing: "placing",
    unitLabelKey: "unitLabelKey",
    first: "first",
    campaign: "campaign"
  },
  decls: 1,
  vars: 1,
  consts: [["detail", "false", 3, "my-placing", "ngStyle", "routerLink", 4, "ngIf"], ["detail", "false", 3, "ngStyle", "routerLink"], ["size", "2"], [3, "value"], [4, "ngIf"], ["size", "3", 1, "ion-text-start"], ["size", "5", 1, "ion-text-end"], ["title", "avatar", 3, "src"]],
  template: function SchoolPlacingDetailComponent_Template(rf, ctx) {
    if (rf & 1) {
      _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵtemplate"](0, SchoolPlacingDetailComponent_ion_item_0_Template, 18, 29, "ion-item", 0);
    }

    if (rf & 2) {
      _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵproperty"]("ngIf", ctx.placing);
    }
  },
  directives: [_angular_common__WEBPACK_IMPORTED_MODULE_7__.NgIf, _ionic_angular__WEBPACK_IMPORTED_MODULE_8__.IonItem, _angular_common__WEBPACK_IMPORTED_MODULE_7__.NgStyle, _angular_router__WEBPACK_IMPORTED_MODULE_9__.RouterLink, _ionic_angular__WEBPACK_IMPORTED_MODULE_8__.RouterLinkDelegate, _ionic_angular__WEBPACK_IMPORTED_MODULE_8__.IonGrid, _ionic_angular__WEBPACK_IMPORTED_MODULE_8__.IonRow, _ionic_angular__WEBPACK_IMPORTED_MODULE_8__.IonCol, _core_shared_globalization_ordinal_number_ordinal_number_component__WEBPACK_IMPORTED_MODULE_3__.OrdinalNumberComponent, _ionic_angular__WEBPACK_IMPORTED_MODULE_8__.IonAvatar],
  pipes: [_angular_common__WEBPACK_IMPORTED_MODULE_7__.AsyncPipe, _ngx_translate_core__WEBPACK_IMPORTED_MODULE_10__.TranslatePipe, _core_shared_pipes_localNumber_pipe__WEBPACK_IMPORTED_MODULE_4__.LocalNumberPipe],
  styles: [".my-placing[_ngcontent-%COMP%] {\n  font-weight: bold;\n}\n\nion-row[_ngcontent-%COMP%] {\n  align-items: center;\n}\n\nion-avatar[_ngcontent-%COMP%] {\n  max-width: 40px;\n  max-height: 40px;\n}\n/*# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbInNjaG9vbC1wbGFjaW5nLWRldGFpbC5jb21wb25lbnQuc2NzcyJdLCJuYW1lcyI6W10sIm1hcHBpbmdzIjoiQUFBQTtFQUNFLGlCQUFBO0FBQ0Y7O0FBRUE7RUFDRSxtQkFBQTtBQUNGOztBQUNBO0VBQ0UsZUFBQTtFQUNBLGdCQUFBO0FBRUYiLCJmaWxlIjoic2Nob29sLXBsYWNpbmctZGV0YWlsLmNvbXBvbmVudC5zY3NzIiwic291cmNlc0NvbnRlbnQiOlsiLm15LXBsYWNpbmcge1xuICBmb250LXdlaWdodDogYm9sZDtcbn1cblxuaW9uLXJvdyB7XG4gIGFsaWduLWl0ZW1zOiBjZW50ZXI7XG59XG5pb24tYXZhdGFyIHtcbiAgbWF4LXdpZHRoOiA0MHB4O1xuICBtYXgtaGVpZ2h0OiA0MHB4O1xufVxuIl19 */"]
});

/***/ })

}]);
//# sourceMappingURL=src_app_pages_home_campaign-details_school-leaderboard_school-leaderboard_module_ts.js.map