"use strict";
(self["webpackChunkapp"] = self["webpackChunkapp"] || []).push([["src_app_pages_user-profile_user-profile_module_ts"],{

/***/ 25373:
/*!*****************************************************************************!*\
  !*** ./src/app/pages/user-profile/campaign-stat/campaign-stat.component.ts ***!
  \*****************************************************************************/
/***/ (function(__unused_webpack_module, __webpack_exports__, __webpack_require__) {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "CampaignStatComponent": function() { return /* binding */ CampaignStatComponent; }
/* harmony export */ });
/* harmony import */ var _Users_smartcommunitylab_Documents_work_projects_dslab_playgo_mobile_playgo_mobile_node_modules_babel_runtime_helpers_esm_classCallCheck_js__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./node_modules/@babel/runtime/helpers/esm/classCallCheck.js */ 78069);
/* harmony import */ var _Users_smartcommunitylab_Documents_work_projects_dslab_playgo_mobile_playgo_mobile_node_modules_babel_runtime_helpers_esm_createClass_js__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ./node_modules/@babel/runtime/helpers/esm/createClass.js */ 48047);
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_17__ = __webpack_require__(/*! tslib */ 34929);
/* harmony import */ var luxon__WEBPACK_IMPORTED_MODULE_15__ = __webpack_require__(/*! luxon */ 29527);
/* harmony import */ var rxjs__WEBPACK_IMPORTED_MODULE_12__ = __webpack_require__(/*! rxjs */ 26067);
/* harmony import */ var rxjs__WEBPACK_IMPORTED_MODULE_13__ = __webpack_require__(/*! rxjs */ 36646);
/* harmony import */ var rxjs__WEBPACK_IMPORTED_MODULE_14__ = __webpack_require__(/*! rxjs */ 50635);
/* harmony import */ var rxjs__WEBPACK_IMPORTED_MODULE_16__ = __webpack_require__(/*! rxjs */ 32673);
/* harmony import */ var src_app_core_shared_campaigns_campaign_utils__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! src/app/core/shared/campaigns/campaign.utils */ 87725);
/* harmony import */ var src_app_core_shared_time_utils__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! src/app/core/shared/time.utils */ 93462);
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_11__ = __webpack_require__(/*! @angular/core */ 3184);
/* harmony import */ var src_app_core_shared_services_challenge_service__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! src/app/core/shared/services/challenge.service */ 66324);
/* harmony import */ var src_app_core_shared_services_report_service__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! src/app/core/shared/services/report.service */ 93981);
/* harmony import */ var _ngx_translate_core__WEBPACK_IMPORTED_MODULE_18__ = __webpack_require__(/*! @ngx-translate/core */ 87514);
/* harmony import */ var src_app_core_shared_services_campaign_service__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! src/app/core/shared/services/campaign.service */ 23645);
/* harmony import */ var src_app_core_auth_auth_service__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(/*! src/app/core/auth/auth.service */ 88951);
/* harmony import */ var src_app_core_shared_services_error_service__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(/*! src/app/core/shared/services/error.service */ 96204);
/* harmony import */ var _ionic_angular__WEBPACK_IMPORTED_MODULE_19__ = __webpack_require__(/*! @ionic/angular */ 93819);
/* harmony import */ var _core_shared_ui_icon_icon_component__WEBPACK_IMPORTED_MODULE_9__ = __webpack_require__(/*! ../../../core/shared/ui/icon/icon.component */ 71888);
/* harmony import */ var _angular_common__WEBPACK_IMPORTED_MODULE_20__ = __webpack_require__(/*! @angular/common */ 36362);
/* harmony import */ var _core_shared_pipes_languageMap_pipe__WEBPACK_IMPORTED_MODULE_10__ = __webpack_require__(/*! ../../../core/shared/pipes/languageMap.pipe */ 73088);



function _regeneratorRuntime() { "use strict"; /*! regenerator-runtime -- Copyright (c) 2014-present, Facebook, Inc. -- license (MIT): https://github.com/facebook/regenerator/blob/main/LICENSE */ _regeneratorRuntime = function _regeneratorRuntime() { return exports; }; var exports = {}, Op = Object.prototype, hasOwn = Op.hasOwnProperty, $Symbol = "function" == typeof Symbol ? Symbol : {}, iteratorSymbol = $Symbol.iterator || "@@iterator", asyncIteratorSymbol = $Symbol.asyncIterator || "@@asyncIterator", toStringTagSymbol = $Symbol.toStringTag || "@@toStringTag"; function define(obj, key, value) { return Object.defineProperty(obj, key, { value: value, enumerable: !0, configurable: !0, writable: !0 }), obj[key]; } try { define({}, ""); } catch (err) { define = function define(obj, key, value) { return obj[key] = value; }; } function wrap(innerFn, outerFn, self, tryLocsList) { var protoGenerator = outerFn && outerFn.prototype instanceof Generator ? outerFn : Generator, generator = Object.create(protoGenerator.prototype), context = new Context(tryLocsList || []); return generator._invoke = function (innerFn, self, context) { var state = "suspendedStart"; return function (method, arg) { if ("executing" === state) throw new Error("Generator is already running"); if ("completed" === state) { if ("throw" === method) throw arg; return doneResult(); } for (context.method = method, context.arg = arg;;) { var delegate = context.delegate; if (delegate) { var delegateResult = maybeInvokeDelegate(delegate, context); if (delegateResult) { if (delegateResult === ContinueSentinel) continue; return delegateResult; } } if ("next" === context.method) context.sent = context._sent = context.arg;else if ("throw" === context.method) { if ("suspendedStart" === state) throw state = "completed", context.arg; context.dispatchException(context.arg); } else "return" === context.method && context.abrupt("return", context.arg); state = "executing"; var record = tryCatch(innerFn, self, context); if ("normal" === record.type) { if (state = context.done ? "completed" : "suspendedYield", record.arg === ContinueSentinel) continue; return { value: record.arg, done: context.done }; } "throw" === record.type && (state = "completed", context.method = "throw", context.arg = record.arg); } }; }(innerFn, self, context), generator; } function tryCatch(fn, obj, arg) { try { return { type: "normal", arg: fn.call(obj, arg) }; } catch (err) { return { type: "throw", arg: err }; } } exports.wrap = wrap; var ContinueSentinel = {}; function Generator() {} function GeneratorFunction() {} function GeneratorFunctionPrototype() {} var IteratorPrototype = {}; define(IteratorPrototype, iteratorSymbol, function () { return this; }); var getProto = Object.getPrototypeOf, NativeIteratorPrototype = getProto && getProto(getProto(values([]))); NativeIteratorPrototype && NativeIteratorPrototype !== Op && hasOwn.call(NativeIteratorPrototype, iteratorSymbol) && (IteratorPrototype = NativeIteratorPrototype); var Gp = GeneratorFunctionPrototype.prototype = Generator.prototype = Object.create(IteratorPrototype); function defineIteratorMethods(prototype) { ["next", "throw", "return"].forEach(function (method) { define(prototype, method, function (arg) { return this._invoke(method, arg); }); }); } function AsyncIterator(generator, PromiseImpl) { function invoke(method, arg, resolve, reject) { var record = tryCatch(generator[method], generator, arg); if ("throw" !== record.type) { var result = record.arg, value = result.value; return value && "object" == typeof value && hasOwn.call(value, "__await") ? PromiseImpl.resolve(value.__await).then(function (value) { invoke("next", value, resolve, reject); }, function (err) { invoke("throw", err, resolve, reject); }) : PromiseImpl.resolve(value).then(function (unwrapped) { result.value = unwrapped, resolve(result); }, function (error) { return invoke("throw", error, resolve, reject); }); } reject(record.arg); } var previousPromise; this._invoke = function (method, arg) { function callInvokeWithMethodAndArg() { return new PromiseImpl(function (resolve, reject) { invoke(method, arg, resolve, reject); }); } return previousPromise = previousPromise ? previousPromise.then(callInvokeWithMethodAndArg, callInvokeWithMethodAndArg) : callInvokeWithMethodAndArg(); }; } function maybeInvokeDelegate(delegate, context) { var method = delegate.iterator[context.method]; if (undefined === method) { if (context.delegate = null, "throw" === context.method) { if (delegate.iterator.return && (context.method = "return", context.arg = undefined, maybeInvokeDelegate(delegate, context), "throw" === context.method)) return ContinueSentinel; context.method = "throw", context.arg = new TypeError("The iterator does not provide a 'throw' method"); } return ContinueSentinel; } var record = tryCatch(method, delegate.iterator, context.arg); if ("throw" === record.type) return context.method = "throw", context.arg = record.arg, context.delegate = null, ContinueSentinel; var info = record.arg; return info ? info.done ? (context[delegate.resultName] = info.value, context.next = delegate.nextLoc, "return" !== context.method && (context.method = "next", context.arg = undefined), context.delegate = null, ContinueSentinel) : info : (context.method = "throw", context.arg = new TypeError("iterator result is not an object"), context.delegate = null, ContinueSentinel); } function pushTryEntry(locs) { var entry = { tryLoc: locs[0] }; 1 in locs && (entry.catchLoc = locs[1]), 2 in locs && (entry.finallyLoc = locs[2], entry.afterLoc = locs[3]), this.tryEntries.push(entry); } function resetTryEntry(entry) { var record = entry.completion || {}; record.type = "normal", delete record.arg, entry.completion = record; } function Context(tryLocsList) { this.tryEntries = [{ tryLoc: "root" }], tryLocsList.forEach(pushTryEntry, this), this.reset(!0); } function values(iterable) { if (iterable) { var iteratorMethod = iterable[iteratorSymbol]; if (iteratorMethod) return iteratorMethod.call(iterable); if ("function" == typeof iterable.next) return iterable; if (!isNaN(iterable.length)) { var i = -1, next = function next() { for (; ++i < iterable.length;) { if (hasOwn.call(iterable, i)) return next.value = iterable[i], next.done = !1, next; } return next.value = undefined, next.done = !0, next; }; return next.next = next; } } return { next: doneResult }; } function doneResult() { return { value: undefined, done: !0 }; } return GeneratorFunction.prototype = GeneratorFunctionPrototype, define(Gp, "constructor", GeneratorFunctionPrototype), define(GeneratorFunctionPrototype, "constructor", GeneratorFunction), GeneratorFunction.displayName = define(GeneratorFunctionPrototype, toStringTagSymbol, "GeneratorFunction"), exports.isGeneratorFunction = function (genFun) { var ctor = "function" == typeof genFun && genFun.constructor; return !!ctor && (ctor === GeneratorFunction || "GeneratorFunction" === (ctor.displayName || ctor.name)); }, exports.mark = function (genFun) { return Object.setPrototypeOf ? Object.setPrototypeOf(genFun, GeneratorFunctionPrototype) : (genFun.__proto__ = GeneratorFunctionPrototype, define(genFun, toStringTagSymbol, "GeneratorFunction")), genFun.prototype = Object.create(Gp), genFun; }, exports.awrap = function (arg) { return { __await: arg }; }, defineIteratorMethods(AsyncIterator.prototype), define(AsyncIterator.prototype, asyncIteratorSymbol, function () { return this; }), exports.AsyncIterator = AsyncIterator, exports.async = function (innerFn, outerFn, self, tryLocsList, PromiseImpl) { void 0 === PromiseImpl && (PromiseImpl = Promise); var iter = new AsyncIterator(wrap(innerFn, outerFn, self, tryLocsList), PromiseImpl); return exports.isGeneratorFunction(outerFn) ? iter : iter.next().then(function (result) { return result.done ? result.value : iter.next(); }); }, defineIteratorMethods(Gp), define(Gp, toStringTagSymbol, "Generator"), define(Gp, iteratorSymbol, function () { return this; }), define(Gp, "toString", function () { return "[object Generator]"; }), exports.keys = function (object) { var keys = []; for (var key in object) { keys.push(key); } return keys.reverse(), function next() { for (; keys.length;) { var key = keys.pop(); if (key in object) return next.value = key, next.done = !1, next; } return next.done = !0, next; }; }, exports.values = values, Context.prototype = { constructor: Context, reset: function reset(skipTempReset) { if (this.prev = 0, this.next = 0, this.sent = this._sent = undefined, this.done = !1, this.delegate = null, this.method = "next", this.arg = undefined, this.tryEntries.forEach(resetTryEntry), !skipTempReset) for (var name in this) { "t" === name.charAt(0) && hasOwn.call(this, name) && !isNaN(+name.slice(1)) && (this[name] = undefined); } }, stop: function stop() { this.done = !0; var rootRecord = this.tryEntries[0].completion; if ("throw" === rootRecord.type) throw rootRecord.arg; return this.rval; }, dispatchException: function dispatchException(exception) { if (this.done) throw exception; var context = this; function handle(loc, caught) { return record.type = "throw", record.arg = exception, context.next = loc, caught && (context.method = "next", context.arg = undefined), !!caught; } for (var i = this.tryEntries.length - 1; i >= 0; --i) { var entry = this.tryEntries[i], record = entry.completion; if ("root" === entry.tryLoc) return handle("end"); if (entry.tryLoc <= this.prev) { var hasCatch = hasOwn.call(entry, "catchLoc"), hasFinally = hasOwn.call(entry, "finallyLoc"); if (hasCatch && hasFinally) { if (this.prev < entry.catchLoc) return handle(entry.catchLoc, !0); if (this.prev < entry.finallyLoc) return handle(entry.finallyLoc); } else if (hasCatch) { if (this.prev < entry.catchLoc) return handle(entry.catchLoc, !0); } else { if (!hasFinally) throw new Error("try statement without catch or finally"); if (this.prev < entry.finallyLoc) return handle(entry.finallyLoc); } } } }, abrupt: function abrupt(type, arg) { for (var i = this.tryEntries.length - 1; i >= 0; --i) { var entry = this.tryEntries[i]; if (entry.tryLoc <= this.prev && hasOwn.call(entry, "finallyLoc") && this.prev < entry.finallyLoc) { var finallyEntry = entry; break; } } finallyEntry && ("break" === type || "continue" === type) && finallyEntry.tryLoc <= arg && arg <= finallyEntry.finallyLoc && (finallyEntry = null); var record = finallyEntry ? finallyEntry.completion : {}; return record.type = type, record.arg = arg, finallyEntry ? (this.method = "next", this.next = finallyEntry.finallyLoc, ContinueSentinel) : this.complete(record); }, complete: function complete(record, afterLoc) { if ("throw" === record.type) throw record.arg; return "break" === record.type || "continue" === record.type ? this.next = record.arg : "return" === record.type ? (this.rval = this.arg = record.arg, this.method = "return", this.next = "end") : "normal" === record.type && afterLoc && (this.next = afterLoc), ContinueSentinel; }, finish: function finish(finallyLoc) { for (var i = this.tryEntries.length - 1; i >= 0; --i) { var entry = this.tryEntries[i]; if (entry.finallyLoc === finallyLoc) return this.complete(entry.completion, entry.afterLoc), resetTryEntry(entry), ContinueSentinel; } }, catch: function _catch(tryLoc) { for (var i = this.tryEntries.length - 1; i >= 0; --i) { var entry = this.tryEntries[i]; if (entry.tryLoc === tryLoc) { var record = entry.completion; if ("throw" === record.type) { var thrown = record.arg; resetTryEntry(entry); } return thrown; } } throw new Error("illegal catch attempt"); }, delegateYield: function delegateYield(iterable, resultName, nextLoc) { return this.delegate = { iterator: values(iterable), resultName: resultName, nextLoc: nextLoc }, "next" === this.method && (this.arg = undefined), ContinueSentinel; } }, exports; }


















var _c0 = function _c0(a0) {
  return {
    won: a0
  };
};

function CampaignStatComponent_div_37_Template(rf, ctx) {
  if (rf & 1) {
    _angular_core__WEBPACK_IMPORTED_MODULE_11__["ɵɵelementStart"](0, "div")(1, "div");
    _angular_core__WEBPACK_IMPORTED_MODULE_11__["ɵɵelement"](2, "app-icon", 11);
    _angular_core__WEBPACK_IMPORTED_MODULE_11__["ɵɵtext"](3);
    _angular_core__WEBPACK_IMPORTED_MODULE_11__["ɵɵelementStart"](4, "b");
    _angular_core__WEBPACK_IMPORTED_MODULE_11__["ɵɵtext"](5);
    _angular_core__WEBPACK_IMPORTED_MODULE_11__["ɵɵpipe"](6, "translate");
    _angular_core__WEBPACK_IMPORTED_MODULE_11__["ɵɵelementEnd"]()()();
  }

  if (rf & 2) {
    var challengeType_r4 = ctx.$implicit;
    var ctx_r0 = _angular_core__WEBPACK_IMPORTED_MODULE_11__["ɵɵnextContext"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_11__["ɵɵadvance"](2);
    _angular_core__WEBPACK_IMPORTED_MODULE_11__["ɵɵproperty"]("name", ctx_r0.imgChallenge(challengeType_r4));
    _angular_core__WEBPACK_IMPORTED_MODULE_11__["ɵɵadvance"](1);
    _angular_core__WEBPACK_IMPORTED_MODULE_11__["ɵɵtextInterpolate2"](" ", challengeType_r4.completed + challengeType_r4.failed, " ", ctx_r0.typeChallenge(challengeType_r4.type), ": ");
    _angular_core__WEBPACK_IMPORTED_MODULE_11__["ɵɵadvance"](2);
    _angular_core__WEBPACK_IMPORTED_MODULE_11__["ɵɵtextInterpolate"](_angular_core__WEBPACK_IMPORTED_MODULE_11__["ɵɵpipeBind2"](6, 4, "userprofile.won", _angular_core__WEBPACK_IMPORTED_MODULE_11__["ɵɵpureFunction1"](7, _c0, challengeType_r4.completed)));
  }
}

function CampaignStatComponent_ng_container_40_Template(rf, ctx) {
  if (rf & 1) {
    var _r6 = _angular_core__WEBPACK_IMPORTED_MODULE_11__["ɵɵgetCurrentView"]();

    _angular_core__WEBPACK_IMPORTED_MODULE_11__["ɵɵelementContainerStart"](0);
    _angular_core__WEBPACK_IMPORTED_MODULE_11__["ɵɵelementStart"](1, "ion-button", 12);
    _angular_core__WEBPACK_IMPORTED_MODULE_11__["ɵɵlistener"]("click", function CampaignStatComponent_ng_container_40_Template_ion_button_click_1_listener() {
      _angular_core__WEBPACK_IMPORTED_MODULE_11__["ɵɵrestoreView"](_r6);
      var ctx_r5 = _angular_core__WEBPACK_IMPORTED_MODULE_11__["ɵɵnextContext"]();
      return ctx_r5.removeBlacklist();
    });
    _angular_core__WEBPACK_IMPORTED_MODULE_11__["ɵɵelement"](2, "app-icon", 13);
    _angular_core__WEBPACK_IMPORTED_MODULE_11__["ɵɵtext"](3);
    _angular_core__WEBPACK_IMPORTED_MODULE_11__["ɵɵpipe"](4, "translate");
    _angular_core__WEBPACK_IMPORTED_MODULE_11__["ɵɵelementEnd"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_11__["ɵɵelementContainerEnd"]();
  }

  if (rf & 2) {
    _angular_core__WEBPACK_IMPORTED_MODULE_11__["ɵɵadvance"](3);
    _angular_core__WEBPACK_IMPORTED_MODULE_11__["ɵɵtextInterpolate"](_angular_core__WEBPACK_IMPORTED_MODULE_11__["ɵɵpipeBind1"](4, 1, "userprofile.remove_blacklist"));
  }
}

function CampaignStatComponent_ng_template_42_Template(rf, ctx) {
  if (rf & 1) {
    var _r8 = _angular_core__WEBPACK_IMPORTED_MODULE_11__["ɵɵgetCurrentView"]();

    _angular_core__WEBPACK_IMPORTED_MODULE_11__["ɵɵelementStart"](0, "ion-button", 14);
    _angular_core__WEBPACK_IMPORTED_MODULE_11__["ɵɵlistener"]("click", function CampaignStatComponent_ng_template_42_Template_ion_button_click_0_listener() {
      _angular_core__WEBPACK_IMPORTED_MODULE_11__["ɵɵrestoreView"](_r8);
      var ctx_r7 = _angular_core__WEBPACK_IMPORTED_MODULE_11__["ɵɵnextContext"]();
      return ctx_r7.addBlacklist();
    });
    _angular_core__WEBPACK_IMPORTED_MODULE_11__["ɵɵelement"](1, "app-icon", 15);
    _angular_core__WEBPACK_IMPORTED_MODULE_11__["ɵɵtext"](2);
    _angular_core__WEBPACK_IMPORTED_MODULE_11__["ɵɵpipe"](3, "translate");
    _angular_core__WEBPACK_IMPORTED_MODULE_11__["ɵɵelementEnd"]();
  }

  if (rf & 2) {
    _angular_core__WEBPACK_IMPORTED_MODULE_11__["ɵɵadvance"](2);
    _angular_core__WEBPACK_IMPORTED_MODULE_11__["ɵɵtextInterpolate"](_angular_core__WEBPACK_IMPORTED_MODULE_11__["ɵɵpipeBind1"](3, 1, "userprofile.add_blacklist"));
  }
}

var _c1 = function _c1(a0) {
  return {
    position: a0
  };
};

var _c2 = function _c2(a0) {
  return {
    points: a0
  };
};

var CampaignStatComponent = /*#__PURE__*/function () {
  // public points$
  function CampaignStatComponent(challengeService, reportService, translateService, campaignService, authService, errorService) {
    (0,_Users_smartcommunitylab_Documents_work_projects_dslab_playgo_mobile_playgo_mobile_node_modules_babel_runtime_helpers_esm_classCallCheck_js__WEBPACK_IMPORTED_MODULE_0__["default"])(this, CampaignStatComponent);

    this.challengeService = challengeService;
    this.reportService = reportService;
    this.translateService = translateService;
    this.campaignService = campaignService;
    this.authService = authService;
    this.errorService = errorService;
    this.imgChallenge = src_app_core_shared_campaigns_campaign_utils__WEBPACK_IMPORTED_MODULE_2__.getImgChallenge;
    this.blacklistRefresher$ = new rxjs__WEBPACK_IMPORTED_MODULE_12__.ReplaySubject(1);
    this.blacklistCouldBeChanged$ = (0,rxjs__WEBPACK_IMPORTED_MODULE_13__.merge)(this.authService.isReadyForApi$.pipe((0,rxjs__WEBPACK_IMPORTED_MODULE_14__.map)(function () {
      return {
        isFirst: true
      };
    })), this.blacklistRefresher$.pipe((0,rxjs__WEBPACK_IMPORTED_MODULE_14__.map)(function () {
      return {
        isFirst: false
      };
    })));
  }

  (0,_Users_smartcommunitylab_Documents_work_projects_dslab_playgo_mobile_playgo_mobile_node_modules_babel_runtime_helpers_esm_createClass_js__WEBPACK_IMPORTED_MODULE_1__["default"])(CampaignStatComponent, [{
    key: "ngOnInit",
    value: function ngOnInit() {
      var _this = this;

      var _a, _b, _c;

      this.challengeStat$ = this.challengeService.getChallengeStats({
        campaignId: (_a = this.campaign) === null || _a === void 0 ? void 0 : _a.campaignId,
        playerId: this.playerId,
        groupMode: 'month',
        dateFrom: (0,src_app_core_shared_time_utils__WEBPACK_IMPORTED_MODULE_3__.toServerDateOnly)(luxon__WEBPACK_IMPORTED_MODULE_15__.DateTime.utc().minus({
          month: 1
        })),
        dateTo: (0,src_app_core_shared_time_utils__WEBPACK_IMPORTED_MODULE_3__.toServerDateOnly)(luxon__WEBPACK_IMPORTED_MODULE_15__.DateTime.utc())
      });
      this.reportWeek$ = this.reportService.getGameStats((_b = this.campaign) === null || _b === void 0 ? void 0 : _b.campaignId, this.playerId, (0,src_app_core_shared_time_utils__WEBPACK_IMPORTED_MODULE_3__.toServerDateOnly)(luxon__WEBPACK_IMPORTED_MODULE_15__.DateTime.utc().minus({
        week: 1
      })), (0,src_app_core_shared_time_utils__WEBPACK_IMPORTED_MODULE_3__.toServerDateOnly)(luxon__WEBPACK_IMPORTED_MODULE_15__.DateTime.utc()));
      this.reportTotal$ = this.reportService.getGameStats((_c = this.campaign) === null || _c === void 0 ? void 0 : _c.campaignId, this.playerId);
      this.blacklisted$ = this.blacklistCouldBeChanged$.pipe((0,rxjs__WEBPACK_IMPORTED_MODULE_16__.switchMap)(function () {
        var _a;

        return _this.challengeService.getBlacklistByCampaign((_a = _this.campaign) === null || _a === void 0 ? void 0 : _a.campaignId).pipe((0,rxjs__WEBPACK_IMPORTED_MODULE_14__.map)(function (blacklist) {
          return blacklist.map(function (user) {
            return user.id;
          }).includes(_this.playerId);
        }));
      }));
    }
  }, {
    key: "typeChallenge",
    value: function typeChallenge(type) {
      return this.translateService.instant((0,src_app_core_shared_campaigns_campaign_utils__WEBPACK_IMPORTED_MODULE_2__.getTypeStringChallenge)(type));
    }
  }, {
    key: "removeBlacklist",
    value: function removeBlacklist() {
      return (0,tslib__WEBPACK_IMPORTED_MODULE_17__.__awaiter)(this, void 0, void 0, /*#__PURE__*/_regeneratorRuntime().mark(function _callee() {
        var removed;
        return _regeneratorRuntime().wrap(function _callee$(_context) {
          while (1) {
            switch (_context.prev = _context.next) {
              case 0:
                _context.prev = 0;
                _context.next = 3;
                return this.challengeService.removeBlacklist(this.campaign.campaignId, this.playerId);

              case 3:
                removed = _context.sent;
                this.blacklistRefresher$.next();
                _context.next = 10;
                break;

              case 7:
                _context.prev = 7;
                _context.t0 = _context["catch"](0);
                this.errorService.handleError(_context.t0, 'normal');

              case 10:
              case "end":
                return _context.stop();
            }
          }
        }, _callee, this, [[0, 7]]);
      }));
    }
  }, {
    key: "addBlacklist",
    value: function addBlacklist() {
      return (0,tslib__WEBPACK_IMPORTED_MODULE_17__.__awaiter)(this, void 0, void 0, /*#__PURE__*/_regeneratorRuntime().mark(function _callee2() {
        var removed;
        return _regeneratorRuntime().wrap(function _callee2$(_context2) {
          while (1) {
            switch (_context2.prev = _context2.next) {
              case 0:
                _context2.prev = 0;
                _context2.next = 3;
                return this.challengeService.addBlacklist(this.campaign.campaignId, this.playerId);

              case 3:
                removed = _context2.sent;
                this.blacklistRefresher$.next();
                _context2.next = 10;
                break;

              case 7:
                _context2.prev = 7;
                _context2.t0 = _context2["catch"](0);
                this.errorService.handleError(_context2.t0, 'normal');

              case 10:
              case "end":
                return _context2.stop();
            }
          }
        }, _callee2, this, [[0, 7]]);
      }));
    }
  }]);

  return CampaignStatComponent;
}();

CampaignStatComponent.ɵfac = function CampaignStatComponent_Factory(t) {
  return new (t || CampaignStatComponent)(_angular_core__WEBPACK_IMPORTED_MODULE_11__["ɵɵdirectiveInject"](src_app_core_shared_services_challenge_service__WEBPACK_IMPORTED_MODULE_4__.ChallengeService), _angular_core__WEBPACK_IMPORTED_MODULE_11__["ɵɵdirectiveInject"](src_app_core_shared_services_report_service__WEBPACK_IMPORTED_MODULE_5__.ReportService), _angular_core__WEBPACK_IMPORTED_MODULE_11__["ɵɵdirectiveInject"](_ngx_translate_core__WEBPACK_IMPORTED_MODULE_18__.TranslateService), _angular_core__WEBPACK_IMPORTED_MODULE_11__["ɵɵdirectiveInject"](src_app_core_shared_services_campaign_service__WEBPACK_IMPORTED_MODULE_6__.CampaignService), _angular_core__WEBPACK_IMPORTED_MODULE_11__["ɵɵdirectiveInject"](src_app_core_auth_auth_service__WEBPACK_IMPORTED_MODULE_7__.AuthService), _angular_core__WEBPACK_IMPORTED_MODULE_11__["ɵɵdirectiveInject"](src_app_core_shared_services_error_service__WEBPACK_IMPORTED_MODULE_8__.ErrorService));
};

CampaignStatComponent.ɵcmp = /*@__PURE__*/_angular_core__WEBPACK_IMPORTED_MODULE_11__["ɵɵdefineComponent"]({
  type: CampaignStatComponent,
  selectors: [["app-campaign-stat"]],
  inputs: {
    playerId: "playerId",
    campaign: "campaign"
  },
  decls: 44,
  vars: 36,
  consts: [[3, "color"], [1, "border"], ["size", "2"], ["name", "leaderboard", 1, "icon-size-big"], [1, "result"], [1, "icon-size-big", 3, "name"], ["name", "default", 1, "icon-size-big"], [4, "ngFor", "ngForOf"], [1, "ion-text-center"], [4, "ngIf", "ngIfElse"], ["addblacklist", ""], [1, "challenge-icon", "icon-size-normal", 3, "name"], [1, "remove-button", 3, "click"], ["name", "invitation", 1, "icon-size-normal"], [1, "add-button", 3, "click"], ["name", "blacklist", 1, "icon-size-normal"]],
  template: function CampaignStatComponent_Template(rf, ctx) {
    if (rf & 1) {
      _angular_core__WEBPACK_IMPORTED_MODULE_11__["ɵɵelement"](0, "p");
      _angular_core__WEBPACK_IMPORTED_MODULE_11__["ɵɵelementStart"](1, "ion-card")(2, "ion-card-header", 0);
      _angular_core__WEBPACK_IMPORTED_MODULE_11__["ɵɵtext"](3);
      _angular_core__WEBPACK_IMPORTED_MODULE_11__["ɵɵpipe"](4, "languageMap");
      _angular_core__WEBPACK_IMPORTED_MODULE_11__["ɵɵelementEnd"]();
      _angular_core__WEBPACK_IMPORTED_MODULE_11__["ɵɵelementStart"](5, "ion-card-content")(6, "ion-grid")(7, "ion-row", 1)(8, "ion-col", 2);
      _angular_core__WEBPACK_IMPORTED_MODULE_11__["ɵɵelement"](9, "app-icon", 3);
      _angular_core__WEBPACK_IMPORTED_MODULE_11__["ɵɵelementEnd"]();
      _angular_core__WEBPACK_IMPORTED_MODULE_11__["ɵɵelementStart"](10, "ion-col")(11, "div", 4)(12, "div");
      _angular_core__WEBPACK_IMPORTED_MODULE_11__["ɵɵtext"](13);
      _angular_core__WEBPACK_IMPORTED_MODULE_11__["ɵɵpipe"](14, "translate");
      _angular_core__WEBPACK_IMPORTED_MODULE_11__["ɵɵpipe"](15, "async");
      _angular_core__WEBPACK_IMPORTED_MODULE_11__["ɵɵelementEnd"]();
      _angular_core__WEBPACK_IMPORTED_MODULE_11__["ɵɵelementStart"](16, "div");
      _angular_core__WEBPACK_IMPORTED_MODULE_11__["ɵɵtext"](17);
      _angular_core__WEBPACK_IMPORTED_MODULE_11__["ɵɵpipe"](18, "translate");
      _angular_core__WEBPACK_IMPORTED_MODULE_11__["ɵɵpipe"](19, "async");
      _angular_core__WEBPACK_IMPORTED_MODULE_11__["ɵɵelementEnd"]()()()()();
      _angular_core__WEBPACK_IMPORTED_MODULE_11__["ɵɵelementStart"](20, "div")(21, "ion-grid")(22, "ion-row", 1)(23, "ion-col", 2);
      _angular_core__WEBPACK_IMPORTED_MODULE_11__["ɵɵelement"](24, "app-icon", 5);
      _angular_core__WEBPACK_IMPORTED_MODULE_11__["ɵɵelementEnd"]();
      _angular_core__WEBPACK_IMPORTED_MODULE_11__["ɵɵelementStart"](25, "ion-col")(26, "div", 4);
      _angular_core__WEBPACK_IMPORTED_MODULE_11__["ɵɵtext"](27);
      _angular_core__WEBPACK_IMPORTED_MODULE_11__["ɵɵpipe"](28, "translate");
      _angular_core__WEBPACK_IMPORTED_MODULE_11__["ɵɵpipe"](29, "async");
      _angular_core__WEBPACK_IMPORTED_MODULE_11__["ɵɵelementEnd"]()()()()();
      _angular_core__WEBPACK_IMPORTED_MODULE_11__["ɵɵelementStart"](30, "div")(31, "ion-grid")(32, "ion-row")(33, "ion-col", 2);
      _angular_core__WEBPACK_IMPORTED_MODULE_11__["ɵɵelement"](34, "app-icon", 6);
      _angular_core__WEBPACK_IMPORTED_MODULE_11__["ɵɵelementEnd"]();
      _angular_core__WEBPACK_IMPORTED_MODULE_11__["ɵɵelementStart"](35, "ion-col")(36, "div", 4);
      _angular_core__WEBPACK_IMPORTED_MODULE_11__["ɵɵtemplate"](37, CampaignStatComponent_div_37_Template, 7, 9, "div", 7);
      _angular_core__WEBPACK_IMPORTED_MODULE_11__["ɵɵpipe"](38, "async");
      _angular_core__WEBPACK_IMPORTED_MODULE_11__["ɵɵelementEnd"]()()()()();
      _angular_core__WEBPACK_IMPORTED_MODULE_11__["ɵɵelementStart"](39, "div", 8);
      _angular_core__WEBPACK_IMPORTED_MODULE_11__["ɵɵtemplate"](40, CampaignStatComponent_ng_container_40_Template, 5, 3, "ng-container", 9);
      _angular_core__WEBPACK_IMPORTED_MODULE_11__["ɵɵpipe"](41, "async");
      _angular_core__WEBPACK_IMPORTED_MODULE_11__["ɵɵtemplate"](42, CampaignStatComponent_ng_template_42_Template, 4, 3, "ng-template", null, 10, _angular_core__WEBPACK_IMPORTED_MODULE_11__["ɵɵtemplateRefExtractor"]);
      _angular_core__WEBPACK_IMPORTED_MODULE_11__["ɵɵelementEnd"]()()();
    }

    if (rf & 2) {
      var _r2 = _angular_core__WEBPACK_IMPORTED_MODULE_11__["ɵɵreference"](43);

      var tmp_2_0;
      var tmp_3_0;
      var tmp_5_0;
      _angular_core__WEBPACK_IMPORTED_MODULE_11__["ɵɵadvance"](2);
      _angular_core__WEBPACK_IMPORTED_MODULE_11__["ɵɵproperty"]("color", ctx.campaign.type);
      _angular_core__WEBPACK_IMPORTED_MODULE_11__["ɵɵadvance"](1);
      _angular_core__WEBPACK_IMPORTED_MODULE_11__["ɵɵtextInterpolate1"](" ", _angular_core__WEBPACK_IMPORTED_MODULE_11__["ɵɵpipeBind1"](4, 9, ctx.campaign.name), " ");
      _angular_core__WEBPACK_IMPORTED_MODULE_11__["ɵɵadvance"](10);
      _angular_core__WEBPACK_IMPORTED_MODULE_11__["ɵɵtextInterpolate1"](" ", _angular_core__WEBPACK_IMPORTED_MODULE_11__["ɵɵpipeBind2"](14, 11, "userprofile.last_week_position", _angular_core__WEBPACK_IMPORTED_MODULE_11__["ɵɵpureFunction1"](30, _c1, (tmp_2_0 = _angular_core__WEBPACK_IMPORTED_MODULE_11__["ɵɵpipeBind1"](15, 14, ctx.reportWeek$)) == null ? null : tmp_2_0.position)), " ");
      _angular_core__WEBPACK_IMPORTED_MODULE_11__["ɵɵadvance"](4);
      _angular_core__WEBPACK_IMPORTED_MODULE_11__["ɵɵtextInterpolate1"](" ", _angular_core__WEBPACK_IMPORTED_MODULE_11__["ɵɵpipeBind2"](18, 16, "userprofile.general_position", _angular_core__WEBPACK_IMPORTED_MODULE_11__["ɵɵpureFunction1"](32, _c1, (tmp_3_0 = _angular_core__WEBPACK_IMPORTED_MODULE_11__["ɵɵpipeBind1"](19, 19, ctx.reportTotal$)) == null ? null : tmp_3_0.position)), " ");
      _angular_core__WEBPACK_IMPORTED_MODULE_11__["ɵɵadvance"](7);
      _angular_core__WEBPACK_IMPORTED_MODULE_11__["ɵɵproperty"]("name", ctx.campaignService.getCampaignTypeIcon(ctx.campaign));
      _angular_core__WEBPACK_IMPORTED_MODULE_11__["ɵɵadvance"](3);
      _angular_core__WEBPACK_IMPORTED_MODULE_11__["ɵɵtextInterpolate1"](" ", _angular_core__WEBPACK_IMPORTED_MODULE_11__["ɵɵpipeBind2"](28, 21, "userprofile.total_points", _angular_core__WEBPACK_IMPORTED_MODULE_11__["ɵɵpureFunction1"](34, _c2, (tmp_5_0 = _angular_core__WEBPACK_IMPORTED_MODULE_11__["ɵɵpipeBind1"](29, 24, ctx.reportTotal$)) == null ? null : tmp_5_0.value)), " ");
      _angular_core__WEBPACK_IMPORTED_MODULE_11__["ɵɵadvance"](10);
      _angular_core__WEBPACK_IMPORTED_MODULE_11__["ɵɵproperty"]("ngForOf", _angular_core__WEBPACK_IMPORTED_MODULE_11__["ɵɵpipeBind1"](38, 26, ctx.challengeStat$));
      _angular_core__WEBPACK_IMPORTED_MODULE_11__["ɵɵadvance"](3);
      _angular_core__WEBPACK_IMPORTED_MODULE_11__["ɵɵproperty"]("ngIf", _angular_core__WEBPACK_IMPORTED_MODULE_11__["ɵɵpipeBind1"](41, 28, ctx.blacklisted$))("ngIfElse", _r2);
    }
  },
  directives: [_ionic_angular__WEBPACK_IMPORTED_MODULE_19__.IonCard, _ionic_angular__WEBPACK_IMPORTED_MODULE_19__.IonCardHeader, _ionic_angular__WEBPACK_IMPORTED_MODULE_19__.IonCardContent, _ionic_angular__WEBPACK_IMPORTED_MODULE_19__.IonGrid, _ionic_angular__WEBPACK_IMPORTED_MODULE_19__.IonRow, _ionic_angular__WEBPACK_IMPORTED_MODULE_19__.IonCol, _core_shared_ui_icon_icon_component__WEBPACK_IMPORTED_MODULE_9__.IconComponent, _angular_common__WEBPACK_IMPORTED_MODULE_20__.NgForOf, _angular_common__WEBPACK_IMPORTED_MODULE_20__.NgIf, _ionic_angular__WEBPACK_IMPORTED_MODULE_19__.IonButton],
  pipes: [_core_shared_pipes_languageMap_pipe__WEBPACK_IMPORTED_MODULE_10__.LanguageMapPipe, _ngx_translate_core__WEBPACK_IMPORTED_MODULE_18__.TranslatePipe, _angular_common__WEBPACK_IMPORTED_MODULE_20__.AsyncPipe],
  styles: [".result[_ngcontent-%COMP%] {\n  display: flex;\n  flex-flow: column;\n  height: 100%;\n  justify-content: center;\n}\n\n.border[_ngcontent-%COMP%] {\n  border-bottom: 2px solid black;\n}\n\n.add-button[_ngcontent-%COMP%] {\n  --background: rgba(198, 16, 16, 1);\n}\n\n.remove-button[_ngcontent-%COMP%] {\n  --background: rgba(53, 150, 117, 1);\n}\n\nion-button[_ngcontent-%COMP%]   app-icon[_ngcontent-%COMP%] {\n  padding: 0px 8px 0px 0px;\n}\n/*# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbImNhbXBhaWduLXN0YXQuY29tcG9uZW50LnNjc3MiXSwibmFtZXMiOltdLCJtYXBwaW5ncyI6IkFBQUE7RUFDRSxhQUFBO0VBQ0EsaUJBQUE7RUFDQSxZQUFBO0VBQ0EsdUJBQUE7QUFDRjs7QUFFQTtFQUNFLDhCQUFBO0FBQ0Y7O0FBQ0E7RUFDRSxrQ0FBQTtBQUVGOztBQUFBO0VBQ0UsbUNBQUE7QUFHRjs7QUFBRTtFQUNFLHdCQUFBO0FBR0oiLCJmaWxlIjoiY2FtcGFpZ24tc3RhdC5jb21wb25lbnQuc2NzcyIsInNvdXJjZXNDb250ZW50IjpbIi5yZXN1bHQge1xuICBkaXNwbGF5OiBmbGV4O1xuICBmbGV4LWZsb3c6IGNvbHVtbjtcbiAgaGVpZ2h0OiAxMDAlO1xuICBqdXN0aWZ5LWNvbnRlbnQ6IGNlbnRlcjtcbn1cblxuLmJvcmRlciB7XG4gIGJvcmRlci1ib3R0b206IDJweCBzb2xpZCBibGFjaztcbn1cbi5hZGQtYnV0dG9uIHtcbiAgLS1iYWNrZ3JvdW5kOiByZ2JhKDE5OCwgMTYsIDE2LCAxKTtcbn1cbi5yZW1vdmUtYnV0dG9uIHtcbiAgLS1iYWNrZ3JvdW5kOiByZ2JhKDUzLCAxNTAsIDExNywgMSk7XG59XG5pb24tYnV0dG9uIHtcbiAgYXBwLWljb24ge1xuICAgIHBhZGRpbmc6IDBweCA4cHggMHB4IDBweDtcbiAgfVxufVxuIl19 */"]
});

/***/ }),

/***/ 2731:
/*!*******************************************************************************!*\
  !*** ./src/app/pages/user-profile/transport-stat/transport-stat.component.ts ***!
  \*******************************************************************************/
/***/ (function(__unused_webpack_module, __webpack_exports__, __webpack_require__) {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "TransportStatComponent": function() { return /* binding */ TransportStatComponent; }
/* harmony export */ });
/* harmony import */ var _Users_smartcommunitylab_Documents_work_projects_dslab_playgo_mobile_playgo_mobile_node_modules_babel_runtime_helpers_esm_classCallCheck_js__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./node_modules/@babel/runtime/helpers/esm/classCallCheck.js */ 78069);
/* harmony import */ var _Users_smartcommunitylab_Documents_work_projects_dslab_playgo_mobile_playgo_mobile_node_modules_babel_runtime_helpers_esm_createClass_js__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ./node_modules/@babel/runtime/helpers/esm/createClass.js */ 48047);
/* harmony import */ var rxjs__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(/*! rxjs */ 32673);
/* harmony import */ var rxjs__WEBPACK_IMPORTED_MODULE_10__ = __webpack_require__(/*! rxjs */ 89196);
/* harmony import */ var src_app_core_shared_time_utils__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! src/app/core/shared/time.utils */ 93462);
/* harmony import */ var luxon__WEBPACK_IMPORTED_MODULE_9__ = __webpack_require__(/*! luxon */ 29527);
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(/*! @angular/core */ 3184);
/* harmony import */ var src_app_core_shared_services_campaign_service__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! src/app/core/shared/services/campaign.service */ 23645);
/* harmony import */ var src_app_core_api_generated_controllers_reportController_service__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! src/app/core/api/generated/controllers/reportController.service */ 59730);
/* harmony import */ var _ionic_angular__WEBPACK_IMPORTED_MODULE_11__ = __webpack_require__(/*! @ionic/angular */ 93819);
/* harmony import */ var _angular_common__WEBPACK_IMPORTED_MODULE_12__ = __webpack_require__(/*! @angular/common */ 36362);
/* harmony import */ var _core_shared_ui_icon_icon_component__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! ../../../core/shared/ui/icon/icon.component */ 71888);
/* harmony import */ var _ngx_translate_core__WEBPACK_IMPORTED_MODULE_13__ = __webpack_require__(/*! @ngx-translate/core */ 87514);
/* harmony import */ var _core_shared_pipes_localNumber_pipe__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! ../../../core/shared/pipes/localNumber.pipe */ 89713);














function TransportStatComponent_ng_container_7_ion_col_1_Template(rf, ctx) {
  if (rf & 1) {
    _angular_core__WEBPACK_IMPORTED_MODULE_7__["ɵɵelementStart"](0, "ion-col", 4);
    _angular_core__WEBPACK_IMPORTED_MODULE_7__["ɵɵelement"](1, "app-icon", 5);
    _angular_core__WEBPACK_IMPORTED_MODULE_7__["ɵɵelementStart"](2, "span");
    _angular_core__WEBPACK_IMPORTED_MODULE_7__["ɵɵtext"](3);
    _angular_core__WEBPACK_IMPORTED_MODULE_7__["ɵɵpipe"](4, "localNumber");
    _angular_core__WEBPACK_IMPORTED_MODULE_7__["ɵɵpipe"](5, "translate");
    _angular_core__WEBPACK_IMPORTED_MODULE_7__["ɵɵpipe"](6, "translate");
    _angular_core__WEBPACK_IMPORTED_MODULE_7__["ɵɵelementEnd"]()();
  }

  if (rf & 2) {
    var stat_r4 = ctx.$implicit;
    _angular_core__WEBPACK_IMPORTED_MODULE_7__["ɵɵadvance"](1);
    _angular_core__WEBPACK_IMPORTED_MODULE_7__["ɵɵproperty"]("name", "directions_" + stat_r4.mean);
    _angular_core__WEBPACK_IMPORTED_MODULE_7__["ɵɵadvance"](2);
    _angular_core__WEBPACK_IMPORTED_MODULE_7__["ɵɵtextInterpolate3"](" ", _angular_core__WEBPACK_IMPORTED_MODULE_7__["ɵɵpipeBind2"](4, 4, stat_r4.value / 1000, "0.0-1"), " ", _angular_core__WEBPACK_IMPORTED_MODULE_7__["ɵɵpipeBind1"](5, 7, "km"), " ", _angular_core__WEBPACK_IMPORTED_MODULE_7__["ɵɵpipeBind1"](6, 9, "userprofile.personal_stat_" + stat_r4.mean), " ");
  }
}

function TransportStatComponent_ng_container_7_Template(rf, ctx) {
  if (rf & 1) {
    _angular_core__WEBPACK_IMPORTED_MODULE_7__["ɵɵelementContainerStart"](0);
    _angular_core__WEBPACK_IMPORTED_MODULE_7__["ɵɵtemplate"](1, TransportStatComponent_ng_container_7_ion_col_1_Template, 7, 11, "ion-col", 3);
    _angular_core__WEBPACK_IMPORTED_MODULE_7__["ɵɵpipe"](2, "async");
    _angular_core__WEBPACK_IMPORTED_MODULE_7__["ɵɵelementContainerEnd"]();
  }

  if (rf & 2) {
    var ctx_r0 = _angular_core__WEBPACK_IMPORTED_MODULE_7__["ɵɵnextContext"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_7__["ɵɵadvance"](1);
    _angular_core__WEBPACK_IMPORTED_MODULE_7__["ɵɵproperty"]("ngForOf", _angular_core__WEBPACK_IMPORTED_MODULE_7__["ɵɵpipeBind1"](2, 1, ctx_r0.personalStat$));
  }
}

function TransportStatComponent_ng_template_9_Template(rf, ctx) {
  if (rf & 1) {
    _angular_core__WEBPACK_IMPORTED_MODULE_7__["ɵɵelementStart"](0, "ion-col")(1, "div", 6);
    _angular_core__WEBPACK_IMPORTED_MODULE_7__["ɵɵtext"](2);
    _angular_core__WEBPACK_IMPORTED_MODULE_7__["ɵɵpipe"](3, "translate");
    _angular_core__WEBPACK_IMPORTED_MODULE_7__["ɵɵelementEnd"]()();
  }

  if (rf & 2) {
    _angular_core__WEBPACK_IMPORTED_MODULE_7__["ɵɵadvance"](2);
    _angular_core__WEBPACK_IMPORTED_MODULE_7__["ɵɵtextInterpolate"](_angular_core__WEBPACK_IMPORTED_MODULE_7__["ɵɵpipeBind1"](3, 1, "userprofile.empty"));
  }
}

var TransportStatComponent = /*#__PURE__*/function () {
  function TransportStatComponent(campaignService, reportController) {
    var _this = this;

    (0,_Users_smartcommunitylab_Documents_work_projects_dslab_playgo_mobile_playgo_mobile_node_modules_babel_runtime_helpers_esm_classCallCheck_js__WEBPACK_IMPORTED_MODULE_0__["default"])(this, TransportStatComponent);

    this.campaignService = campaignService;
    this.reportController = reportController;
    this.personalCampaign$ = this.campaignService.getPersonalCampaign();
    this.personalStat$ = this.personalCampaign$.pipe((0,rxjs__WEBPACK_IMPORTED_MODULE_8__.switchMap)(function (personalCampaign) {
      var _a;

      return _this.reportController.getPlayerTransportStatsGroupByMeanUsingGET({
        campaignId: (_a = personalCampaign === null || personalCampaign === void 0 ? void 0 : personalCampaign.campaign) === null || _a === void 0 ? void 0 : _a.campaignId,
        playerId: _this.playerId,
        metric: 'km',
        dateFrom: (0,src_app_core_shared_time_utils__WEBPACK_IMPORTED_MODULE_2__.toServerDateOnly)(luxon__WEBPACK_IMPORTED_MODULE_9__.DateTime.utc().minus({
          month: 1
        })),
        dateTo: (0,src_app_core_shared_time_utils__WEBPACK_IMPORTED_MODULE_2__.toServerDateOnly)(luxon__WEBPACK_IMPORTED_MODULE_9__.DateTime.utc())
      });
    }), (0,rxjs__WEBPACK_IMPORTED_MODULE_10__.shareReplay)(1));
  }

  (0,_Users_smartcommunitylab_Documents_work_projects_dslab_playgo_mobile_playgo_mobile_node_modules_babel_runtime_helpers_esm_createClass_js__WEBPACK_IMPORTED_MODULE_1__["default"])(TransportStatComponent, [{
    key: "ngOnInit",
    value: function ngOnInit() {}
  }]);

  return TransportStatComponent;
}();

TransportStatComponent.ɵfac = function TransportStatComponent_Factory(t) {
  return new (t || TransportStatComponent)(_angular_core__WEBPACK_IMPORTED_MODULE_7__["ɵɵdirectiveInject"](src_app_core_shared_services_campaign_service__WEBPACK_IMPORTED_MODULE_3__.CampaignService), _angular_core__WEBPACK_IMPORTED_MODULE_7__["ɵɵdirectiveInject"](src_app_core_api_generated_controllers_reportController_service__WEBPACK_IMPORTED_MODULE_4__.ReportControllerService));
};

TransportStatComponent.ɵcmp = /*@__PURE__*/_angular_core__WEBPACK_IMPORTED_MODULE_7__["ɵɵdefineComponent"]({
  type: TransportStatComponent,
  selectors: [["app-transport-stat"]],
  inputs: {
    playerId: "playerId"
  },
  decls: 11,
  vars: 7,
  consts: [["color", "personal"], [4, "ngIf", "ngIfElse"], ["emptyStat", ""], ["size", "6", 4, "ngFor", "ngForOf"], ["size", "6"], [1, "icon-size-normal", 3, "name"], [1, "empty-stats"]],
  template: function TransportStatComponent_Template(rf, ctx) {
    if (rf & 1) {
      _angular_core__WEBPACK_IMPORTED_MODULE_7__["ɵɵelementStart"](0, "ion-card")(1, "ion-card-header", 0);
      _angular_core__WEBPACK_IMPORTED_MODULE_7__["ɵɵtext"](2);
      _angular_core__WEBPACK_IMPORTED_MODULE_7__["ɵɵpipe"](3, "translate");
      _angular_core__WEBPACK_IMPORTED_MODULE_7__["ɵɵelementEnd"]();
      _angular_core__WEBPACK_IMPORTED_MODULE_7__["ɵɵelementStart"](4, "ion-card-content")(5, "ion-grid")(6, "ion-row");
      _angular_core__WEBPACK_IMPORTED_MODULE_7__["ɵɵtemplate"](7, TransportStatComponent_ng_container_7_Template, 3, 3, "ng-container", 1);
      _angular_core__WEBPACK_IMPORTED_MODULE_7__["ɵɵpipe"](8, "async");
      _angular_core__WEBPACK_IMPORTED_MODULE_7__["ɵɵtemplate"](9, TransportStatComponent_ng_template_9_Template, 4, 3, "ng-template", null, 2, _angular_core__WEBPACK_IMPORTED_MODULE_7__["ɵɵtemplateRefExtractor"]);
      _angular_core__WEBPACK_IMPORTED_MODULE_7__["ɵɵelementEnd"]()()()();
    }

    if (rf & 2) {
      var _r1 = _angular_core__WEBPACK_IMPORTED_MODULE_7__["ɵɵreference"](10);

      var tmp_1_0;
      _angular_core__WEBPACK_IMPORTED_MODULE_7__["ɵɵadvance"](2);
      _angular_core__WEBPACK_IMPORTED_MODULE_7__["ɵɵtextInterpolate1"](" ", _angular_core__WEBPACK_IMPORTED_MODULE_7__["ɵɵpipeBind1"](3, 3, "userprofile.last_month"), "");
      _angular_core__WEBPACK_IMPORTED_MODULE_7__["ɵɵadvance"](5);
      _angular_core__WEBPACK_IMPORTED_MODULE_7__["ɵɵproperty"]("ngIf", ((tmp_1_0 = _angular_core__WEBPACK_IMPORTED_MODULE_7__["ɵɵpipeBind1"](8, 5, ctx.personalStat$)) == null ? null : tmp_1_0.length) > 0)("ngIfElse", _r1);
    }
  },
  directives: [_ionic_angular__WEBPACK_IMPORTED_MODULE_11__.IonCard, _ionic_angular__WEBPACK_IMPORTED_MODULE_11__.IonCardHeader, _ionic_angular__WEBPACK_IMPORTED_MODULE_11__.IonCardContent, _ionic_angular__WEBPACK_IMPORTED_MODULE_11__.IonGrid, _ionic_angular__WEBPACK_IMPORTED_MODULE_11__.IonRow, _angular_common__WEBPACK_IMPORTED_MODULE_12__.NgIf, _angular_common__WEBPACK_IMPORTED_MODULE_12__.NgForOf, _ionic_angular__WEBPACK_IMPORTED_MODULE_11__.IonCol, _core_shared_ui_icon_icon_component__WEBPACK_IMPORTED_MODULE_5__.IconComponent],
  pipes: [_ngx_translate_core__WEBPACK_IMPORTED_MODULE_13__.TranslatePipe, _angular_common__WEBPACK_IMPORTED_MODULE_12__.AsyncPipe, _core_shared_pipes_localNumber_pipe__WEBPACK_IMPORTED_MODULE_6__.LocalNumberPipe],
  styles: ["ion-col[_ngcontent-%COMP%] {\n  display: flex;\n  align-items: center !important;\n}\n\n.empty-stats[_ngcontent-%COMP%] {\n  margin: auto;\n  padding: 8px;\n  font-size: 20px;\n  text-align: center;\n  -ms-transform: translateY(-50%);\n}\n/*# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbInRyYW5zcG9ydC1zdGF0LmNvbXBvbmVudC5zY3NzIl0sIm5hbWVzIjpbXSwibWFwcGluZ3MiOiJBQUFBO0VBQ0UsYUFBQTtFQUNBLDhCQUFBO0FBQ0Y7O0FBQ0E7RUFDRSxZQUFBO0VBQ0EsWUFBQTtFQUNBLGVBQUE7RUFDQSxrQkFBQTtFQUNBLCtCQUFBO0FBRUYiLCJmaWxlIjoidHJhbnNwb3J0LXN0YXQuY29tcG9uZW50LnNjc3MiLCJzb3VyY2VzQ29udGVudCI6WyJpb24tY29sIHtcbiAgZGlzcGxheTogZmxleDtcbiAgYWxpZ24taXRlbXM6IGNlbnRlciAhaW1wb3J0YW50O1xufVxuLmVtcHR5LXN0YXRzIHtcbiAgbWFyZ2luOiBhdXRvO1xuICBwYWRkaW5nOiA4cHg7XG4gIGZvbnQtc2l6ZTogMjBweDtcbiAgdGV4dC1hbGlnbjogY2VudGVyO1xuICAtbXMtdHJhbnNmb3JtOiB0cmFuc2xhdGVZKC01MCUpO1xufVxuIl19 */"]
});

/***/ }),

/***/ 23376:
/*!*******************************************************************!*\
  !*** ./src/app/pages/user-profile/user-profile-routing.module.ts ***!
  \*******************************************************************/
/***/ (function(__unused_webpack_module, __webpack_exports__, __webpack_require__) {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "UserProfilePageRoutingModule": function() { return /* binding */ UserProfilePageRoutingModule; }
/* harmony export */ });
/* harmony import */ var _Users_smartcommunitylab_Documents_work_projects_dslab_playgo_mobile_playgo_mobile_node_modules_babel_runtime_helpers_esm_createClass_js__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./node_modules/@babel/runtime/helpers/esm/createClass.js */ 48047);
/* harmony import */ var _Users_smartcommunitylab_Documents_work_projects_dslab_playgo_mobile_playgo_mobile_node_modules_babel_runtime_helpers_esm_classCallCheck_js__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ./node_modules/@babel/runtime/helpers/esm/classCallCheck.js */ 78069);
/* harmony import */ var _angular_router__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! @angular/router */ 52816);
/* harmony import */ var _user_profile_page__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! ./user-profile.page */ 41553);
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @angular/core */ 3184);






var routes = [{
  path: '',
  component: _user_profile_page__WEBPACK_IMPORTED_MODULE_2__.UserProfilePage,
  data: {
    title: 'userprofile.title',
    customHeader: true
  }
}];
var UserProfilePageRoutingModule = /*#__PURE__*/(0,_Users_smartcommunitylab_Documents_work_projects_dslab_playgo_mobile_playgo_mobile_node_modules_babel_runtime_helpers_esm_createClass_js__WEBPACK_IMPORTED_MODULE_0__["default"])(function UserProfilePageRoutingModule() {
  (0,_Users_smartcommunitylab_Documents_work_projects_dslab_playgo_mobile_playgo_mobile_node_modules_babel_runtime_helpers_esm_classCallCheck_js__WEBPACK_IMPORTED_MODULE_1__["default"])(this, UserProfilePageRoutingModule);
});

UserProfilePageRoutingModule.ɵfac = function UserProfilePageRoutingModule_Factory(t) {
  return new (t || UserProfilePageRoutingModule)();
};

UserProfilePageRoutingModule.ɵmod = /*@__PURE__*/_angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵdefineNgModule"]({
  type: UserProfilePageRoutingModule
});
UserProfilePageRoutingModule.ɵinj = /*@__PURE__*/_angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵdefineInjector"]({
  imports: [[_angular_router__WEBPACK_IMPORTED_MODULE_4__.RouterModule.forChild(routes)], _angular_router__WEBPACK_IMPORTED_MODULE_4__.RouterModule]
});

(function () {
  (typeof ngJitMode === "undefined" || ngJitMode) && _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵsetNgModuleScope"](UserProfilePageRoutingModule, {
    imports: [_angular_router__WEBPACK_IMPORTED_MODULE_4__.RouterModule],
    exports: [_angular_router__WEBPACK_IMPORTED_MODULE_4__.RouterModule]
  });
})();

/***/ }),

/***/ 71749:
/*!***********************************************************!*\
  !*** ./src/app/pages/user-profile/user-profile.module.ts ***!
  \***********************************************************/
/***/ (function(__unused_webpack_module, __webpack_exports__, __webpack_require__) {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "UserProfilePageModule": function() { return /* binding */ UserProfilePageModule; }
/* harmony export */ });
/* harmony import */ var _Users_smartcommunitylab_Documents_work_projects_dslab_playgo_mobile_playgo_mobile_node_modules_babel_runtime_helpers_esm_createClass_js__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./node_modules/@babel/runtime/helpers/esm/createClass.js */ 48047);
/* harmony import */ var _Users_smartcommunitylab_Documents_work_projects_dslab_playgo_mobile_playgo_mobile_node_modules_babel_runtime_helpers_esm_classCallCheck_js__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ./node_modules/@babel/runtime/helpers/esm/classCallCheck.js */ 78069);
/* harmony import */ var _user_profile_routing_module__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! ./user-profile-routing.module */ 23376);
/* harmony import */ var _user_profile_page__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! ./user-profile.page */ 41553);
/* harmony import */ var src_app_core_shared_shared_module__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! src/app/core/shared/shared.module */ 97205);
/* harmony import */ var _transport_stat_transport_stat_component__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! ./transport-stat/transport-stat.component */ 2731);
/* harmony import */ var _campaign_stat_campaign_stat_component__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! ./campaign-stat/campaign-stat.component */ 25373);
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(/*! @angular/core */ 3184);








var UserProfilePageModule = /*#__PURE__*/(0,_Users_smartcommunitylab_Documents_work_projects_dslab_playgo_mobile_playgo_mobile_node_modules_babel_runtime_helpers_esm_createClass_js__WEBPACK_IMPORTED_MODULE_0__["default"])(function UserProfilePageModule() {
  (0,_Users_smartcommunitylab_Documents_work_projects_dslab_playgo_mobile_playgo_mobile_node_modules_babel_runtime_helpers_esm_classCallCheck_js__WEBPACK_IMPORTED_MODULE_1__["default"])(this, UserProfilePageModule);
});

UserProfilePageModule.ɵfac = function UserProfilePageModule_Factory(t) {
  return new (t || UserProfilePageModule)();
};

UserProfilePageModule.ɵmod = /*@__PURE__*/_angular_core__WEBPACK_IMPORTED_MODULE_7__["ɵɵdefineNgModule"]({
  type: UserProfilePageModule
});
UserProfilePageModule.ɵinj = /*@__PURE__*/_angular_core__WEBPACK_IMPORTED_MODULE_7__["ɵɵdefineInjector"]({
  imports: [[src_app_core_shared_shared_module__WEBPACK_IMPORTED_MODULE_4__.PlayGoSharedModule, _user_profile_routing_module__WEBPACK_IMPORTED_MODULE_2__.UserProfilePageRoutingModule]]
});

(function () {
  (typeof ngJitMode === "undefined" || ngJitMode) && _angular_core__WEBPACK_IMPORTED_MODULE_7__["ɵɵsetNgModuleScope"](UserProfilePageModule, {
    declarations: [_user_profile_page__WEBPACK_IMPORTED_MODULE_3__.UserProfilePage, _transport_stat_transport_stat_component__WEBPACK_IMPORTED_MODULE_5__.TransportStatComponent, _campaign_stat_campaign_stat_component__WEBPACK_IMPORTED_MODULE_6__.CampaignStatComponent],
    imports: [src_app_core_shared_shared_module__WEBPACK_IMPORTED_MODULE_4__.PlayGoSharedModule, _user_profile_routing_module__WEBPACK_IMPORTED_MODULE_2__.UserProfilePageRoutingModule]
  });
})();

/***/ }),

/***/ 41553:
/*!*********************************************************!*\
  !*** ./src/app/pages/user-profile/user-profile.page.ts ***!
  \*********************************************************/
/***/ (function(__unused_webpack_module, __webpack_exports__, __webpack_require__) {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "UserProfilePage": function() { return /* binding */ UserProfilePage; }
/* harmony export */ });
/* harmony import */ var _Users_smartcommunitylab_Documents_work_projects_dslab_playgo_mobile_playgo_mobile_node_modules_babel_runtime_helpers_esm_slicedToArray_js__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./node_modules/@babel/runtime/helpers/esm/slicedToArray.js */ 10507);
/* harmony import */ var _Users_smartcommunitylab_Documents_work_projects_dslab_playgo_mobile_playgo_mobile_node_modules_babel_runtime_helpers_esm_classCallCheck_js__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ./node_modules/@babel/runtime/helpers/esm/classCallCheck.js */ 78069);
/* harmony import */ var _Users_smartcommunitylab_Documents_work_projects_dslab_playgo_mobile_playgo_mobile_node_modules_babel_runtime_helpers_esm_createClass_js__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! ./node_modules/@babel/runtime/helpers/esm/createClass.js */ 48047);
/* harmony import */ var rxjs__WEBPACK_IMPORTED_MODULE_12__ = __webpack_require__(/*! rxjs */ 50635);
/* harmony import */ var rxjs__WEBPACK_IMPORTED_MODULE_13__ = __webpack_require__(/*! rxjs */ 98977);
/* harmony import */ var rxjs__WEBPACK_IMPORTED_MODULE_14__ = __webpack_require__(/*! rxjs */ 89196);
/* harmony import */ var rxjs__WEBPACK_IMPORTED_MODULE_15__ = __webpack_require__(/*! rxjs */ 32673);
/* harmony import */ var rxjs__WEBPACK_IMPORTED_MODULE_16__ = __webpack_require__(/*! rxjs */ 26562);
/* harmony import */ var rxjs__WEBPACK_IMPORTED_MODULE_19__ = __webpack_require__(/*! rxjs */ 19337);
/* harmony import */ var lodash_es__WEBPACK_IMPORTED_MODULE_17__ = __webpack_require__(/*! lodash-es */ 71156);
/* harmony import */ var lodash_es__WEBPACK_IMPORTED_MODULE_18__ = __webpack_require__(/*! lodash-es */ 63247);
/* harmony import */ var src_app_core_shared_rxjs_utils__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! src/app/core/shared/rxjs.utils */ 9257);
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_11__ = __webpack_require__(/*! @angular/core */ 3184);
/* harmony import */ var _angular_router__WEBPACK_IMPORTED_MODULE_20__ = __webpack_require__(/*! @angular/router */ 52816);
/* harmony import */ var src_app_core_shared_services_error_service__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! src/app/core/shared/services/error.service */ 96204);
/* harmony import */ var src_app_core_shared_services_user_service__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! src/app/core/shared/services/user.service */ 50749);
/* harmony import */ var src_app_core_shared_services_campaign_service__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! src/app/core/shared/services/campaign.service */ 23645);
/* harmony import */ var _ionic_angular__WEBPACK_IMPORTED_MODULE_21__ = __webpack_require__(/*! @ionic/angular */ 93819);
/* harmony import */ var _core_shared_layout_header_header_directive__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(/*! ../../core/shared/layout/header/header.directive */ 34161);
/* harmony import */ var _core_shared_layout_content_content_directive__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(/*! ../../core/shared/layout/content/content.directive */ 69669);
/* harmony import */ var _transport_stat_transport_stat_component__WEBPACK_IMPORTED_MODULE_9__ = __webpack_require__(/*! ./transport-stat/transport-stat.component */ 2731);
/* harmony import */ var _angular_common__WEBPACK_IMPORTED_MODULE_22__ = __webpack_require__(/*! @angular/common */ 36362);
/* harmony import */ var _campaign_stat_campaign_stat_component__WEBPACK_IMPORTED_MODULE_10__ = __webpack_require__(/*! ./campaign-stat/campaign-stat.component */ 25373);


















function UserProfilePage_ng_container_11_Template(rf, ctx) {
  if (rf & 1) {
    _angular_core__WEBPACK_IMPORTED_MODULE_11__["ɵɵelementContainerStart"](0);
    _angular_core__WEBPACK_IMPORTED_MODULE_11__["ɵɵelement"](1, "app-campaign-stat", 7);
    _angular_core__WEBPACK_IMPORTED_MODULE_11__["ɵɵpipe"](2, "async");
    _angular_core__WEBPACK_IMPORTED_MODULE_11__["ɵɵelementContainerEnd"]();
  }

  if (rf & 2) {
    var campaign_r1 = ctx.$implicit;
    var ctx_r0 = _angular_core__WEBPACK_IMPORTED_MODULE_11__["ɵɵnextContext"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_11__["ɵɵadvance"](1);
    _angular_core__WEBPACK_IMPORTED_MODULE_11__["ɵɵproperty"]("playerId", _angular_core__WEBPACK_IMPORTED_MODULE_11__["ɵɵpipeBind1"](2, 2, ctx_r0.userId$))("campaign", campaign_r1);
  }
}

var UserProfilePage = /*#__PURE__*/function () {
  // public campaigns: PlayerCampaign[] = [];
  function UserProfilePage(route, errorService, userService, campaignService) {
    var _this = this;

    (0,_Users_smartcommunitylab_Documents_work_projects_dslab_playgo_mobile_playgo_mobile_node_modules_babel_runtime_helpers_esm_classCallCheck_js__WEBPACK_IMPORTED_MODULE_1__["default"])(this, UserProfilePage);

    this.route = route;
    this.errorService = errorService;
    this.userService = userService;
    this.campaignService = campaignService;
    this.userId$ = this.route.params.pipe((0,rxjs__WEBPACK_IMPORTED_MODULE_12__.map)(function (params) {
      return params.id;
    }), (0,rxjs__WEBPACK_IMPORTED_MODULE_13__.distinctUntilChanged)(), (0,rxjs__WEBPACK_IMPORTED_MODULE_14__.shareReplay)(1));
    this.userNickname$ = this.route.params.pipe((0,rxjs__WEBPACK_IMPORTED_MODULE_12__.map)(function (params) {
      return params.nickname;
    }), (0,rxjs__WEBPACK_IMPORTED_MODULE_13__.distinctUntilChanged)(), (0,rxjs__WEBPACK_IMPORTED_MODULE_14__.shareReplay)(1));
    this.userAvatar$ = this.userId$.pipe((0,rxjs__WEBPACK_IMPORTED_MODULE_15__.switchMap)(function (userId) {
      return _this.userService.getOtherPlayerAvatar(userId).pipe(_this.errorService.getErrorHandler());
    }), (0,rxjs__WEBPACK_IMPORTED_MODULE_14__.shareReplay)(1));
    this.campaigns$ = (0,rxjs__WEBPACK_IMPORTED_MODULE_16__.combineLatest)([this.userId$, this.campaignService.myCampaigns$]).pipe((0,rxjs__WEBPACK_IMPORTED_MODULE_15__.switchMap)(function (_ref) {
      var _ref2 = (0,_Users_smartcommunitylab_Documents_work_projects_dslab_playgo_mobile_playgo_mobile_node_modules_babel_runtime_helpers_esm_slicedToArray_js__WEBPACK_IMPORTED_MODULE_0__["default"])(_ref, 2),
          userId = _ref2[0],
          myCampaigns = _ref2[1];

      return _this.campaignService.getCampaignByPlayerId(userId).pipe((0,src_app_core_shared_rxjs_utils__WEBPACK_IMPORTED_MODULE_3__.tapLog)('Initial Campaign'), (0,rxjs__WEBPACK_IMPORTED_MODULE_12__.map)( //filter my campaigns in order to have only common campaigns
      function (otherUserCampaigns) {
        var intersection = (0,lodash_es__WEBPACK_IMPORTED_MODULE_17__["default"])(otherUserCampaigns.map(function (campaign) {
          return campaign.campaignId;
        }), myCampaigns.map(function (campaign) {
          return campaign.campaign.campaignId;
        }), lodash_es__WEBPACK_IMPORTED_MODULE_18__["default"]);
        return otherUserCampaigns.filter(function (campaign) {
          return intersection.includes(campaign.campaignId) && campaign.type !== 'personal' && campaign.type !== 'company';
        });
      }), (0,src_app_core_shared_rxjs_utils__WEBPACK_IMPORTED_MODULE_3__.tapLog)('filteredcampaign'), ////filter personal campaign and campaigns without challenge 'personal' && 'company'
      _this.errorService.getErrorHandler());
    }), (0,rxjs__WEBPACK_IMPORTED_MODULE_19__.tap)(function (campaigns) {
      return console.log(campaigns);
    }), (0,rxjs__WEBPACK_IMPORTED_MODULE_14__.shareReplay)(1));
  }

  (0,_Users_smartcommunitylab_Documents_work_projects_dslab_playgo_mobile_playgo_mobile_node_modules_babel_runtime_helpers_esm_createClass_js__WEBPACK_IMPORTED_MODULE_2__["default"])(UserProfilePage, [{
    key: "ngOnInit",
    value: function ngOnInit() {}
  }]);

  return UserProfilePage;
}();

UserProfilePage.ɵfac = function UserProfilePage_Factory(t) {
  return new (t || UserProfilePage)(_angular_core__WEBPACK_IMPORTED_MODULE_11__["ɵɵdirectiveInject"](_angular_router__WEBPACK_IMPORTED_MODULE_20__.ActivatedRoute), _angular_core__WEBPACK_IMPORTED_MODULE_11__["ɵɵdirectiveInject"](src_app_core_shared_services_error_service__WEBPACK_IMPORTED_MODULE_4__.ErrorService), _angular_core__WEBPACK_IMPORTED_MODULE_11__["ɵɵdirectiveInject"](src_app_core_shared_services_user_service__WEBPACK_IMPORTED_MODULE_5__.UserService), _angular_core__WEBPACK_IMPORTED_MODULE_11__["ɵɵdirectiveInject"](src_app_core_shared_services_campaign_service__WEBPACK_IMPORTED_MODULE_6__.CampaignService));
};

UserProfilePage.ɵcmp = /*@__PURE__*/_angular_core__WEBPACK_IMPORTED_MODULE_11__["ɵɵdefineComponent"]({
  type: UserProfilePage,
  selectors: [["app-user-profile"]],
  decls: 13,
  vars: 13,
  consts: [["appHeader", ""], ["appContent", "", 3, "fullscreen"], [1, "user-intro"], [3, "src"], [1, "nickname"], [3, "playerId"], [4, "ngFor", "ngForOf"], [3, "playerId", "campaign"]],
  template: function UserProfilePage_Template(rf, ctx) {
    if (rf & 1) {
      _angular_core__WEBPACK_IMPORTED_MODULE_11__["ɵɵelement"](0, "ion-header", 0);
      _angular_core__WEBPACK_IMPORTED_MODULE_11__["ɵɵelementStart"](1, "ion-content", 1)(2, "div", 2)(3, "ion-avatar");
      _angular_core__WEBPACK_IMPORTED_MODULE_11__["ɵɵelement"](4, "img", 3);
      _angular_core__WEBPACK_IMPORTED_MODULE_11__["ɵɵpipe"](5, "async");
      _angular_core__WEBPACK_IMPORTED_MODULE_11__["ɵɵelementEnd"]();
      _angular_core__WEBPACK_IMPORTED_MODULE_11__["ɵɵelementStart"](6, "div", 4);
      _angular_core__WEBPACK_IMPORTED_MODULE_11__["ɵɵtext"](7);
      _angular_core__WEBPACK_IMPORTED_MODULE_11__["ɵɵpipe"](8, "async");
      _angular_core__WEBPACK_IMPORTED_MODULE_11__["ɵɵelementEnd"]()();
      _angular_core__WEBPACK_IMPORTED_MODULE_11__["ɵɵelement"](9, "app-transport-stat", 5);
      _angular_core__WEBPACK_IMPORTED_MODULE_11__["ɵɵpipe"](10, "async");
      _angular_core__WEBPACK_IMPORTED_MODULE_11__["ɵɵtemplate"](11, UserProfilePage_ng_container_11_Template, 3, 4, "ng-container", 6);
      _angular_core__WEBPACK_IMPORTED_MODULE_11__["ɵɵpipe"](12, "async");
      _angular_core__WEBPACK_IMPORTED_MODULE_11__["ɵɵelementEnd"]();
    }

    if (rf & 2) {
      var tmp_1_0;
      _angular_core__WEBPACK_IMPORTED_MODULE_11__["ɵɵadvance"](1);
      _angular_core__WEBPACK_IMPORTED_MODULE_11__["ɵɵproperty"]("fullscreen", true);
      _angular_core__WEBPACK_IMPORTED_MODULE_11__["ɵɵadvance"](3);
      _angular_core__WEBPACK_IMPORTED_MODULE_11__["ɵɵproperty"]("src", (tmp_1_0 = _angular_core__WEBPACK_IMPORTED_MODULE_11__["ɵɵpipeBind1"](5, 5, ctx.userAvatar$)) == null ? null : tmp_1_0.avatarUrl, _angular_core__WEBPACK_IMPORTED_MODULE_11__["ɵɵsanitizeUrl"]);
      _angular_core__WEBPACK_IMPORTED_MODULE_11__["ɵɵadvance"](3);
      _angular_core__WEBPACK_IMPORTED_MODULE_11__["ɵɵtextInterpolate"](_angular_core__WEBPACK_IMPORTED_MODULE_11__["ɵɵpipeBind1"](8, 7, ctx.userNickname$));
      _angular_core__WEBPACK_IMPORTED_MODULE_11__["ɵɵadvance"](2);
      _angular_core__WEBPACK_IMPORTED_MODULE_11__["ɵɵproperty"]("playerId", _angular_core__WEBPACK_IMPORTED_MODULE_11__["ɵɵpipeBind1"](10, 9, ctx.userId$));
      _angular_core__WEBPACK_IMPORTED_MODULE_11__["ɵɵadvance"](2);
      _angular_core__WEBPACK_IMPORTED_MODULE_11__["ɵɵproperty"]("ngForOf", _angular_core__WEBPACK_IMPORTED_MODULE_11__["ɵɵpipeBind1"](12, 11, ctx.campaigns$));
    }
  },
  directives: [_ionic_angular__WEBPACK_IMPORTED_MODULE_21__.IonHeader, _core_shared_layout_header_header_directive__WEBPACK_IMPORTED_MODULE_7__.HeaderDirective, _ionic_angular__WEBPACK_IMPORTED_MODULE_21__.IonContent, _core_shared_layout_content_content_directive__WEBPACK_IMPORTED_MODULE_8__.ContentDirective, _ionic_angular__WEBPACK_IMPORTED_MODULE_21__.IonAvatar, _transport_stat_transport_stat_component__WEBPACK_IMPORTED_MODULE_9__.TransportStatComponent, _angular_common__WEBPACK_IMPORTED_MODULE_22__.NgForOf, _campaign_stat_campaign_stat_component__WEBPACK_IMPORTED_MODULE_10__.CampaignStatComponent],
  pipes: [_angular_common__WEBPACK_IMPORTED_MODULE_22__.AsyncPipe],
  styles: [".user-intro[_ngcontent-%COMP%] {\n  text-align: center;\n  margin: 52px auto;\n  width: 102px;\n  height: 102px;\n}\n.user-intro[_ngcontent-%COMP%]   ion-avatar[_ngcontent-%COMP%] {\n  margin: auto;\n}\n.user-intro[_ngcontent-%COMP%]   .nickname[_ngcontent-%COMP%] {\n  margin-top: 32px;\n}\n/*# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbInVzZXItcHJvZmlsZS5wYWdlLnNjc3MiXSwibmFtZXMiOltdLCJtYXBwaW5ncyI6IkFBQUE7RUFDRSxrQkFBQTtFQUNBLGlCQUFBO0VBQ0EsWUFBQTtFQUNBLGFBQUE7QUFDRjtBQUFFO0VBQ0UsWUFBQTtBQUVKO0FBQUU7RUFDRSxnQkFBQTtBQUVKIiwiZmlsZSI6InVzZXItcHJvZmlsZS5wYWdlLnNjc3MiLCJzb3VyY2VzQ29udGVudCI6WyIudXNlci1pbnRybyB7XG4gIHRleHQtYWxpZ246IGNlbnRlcjtcbiAgbWFyZ2luOiA1MnB4IGF1dG87XG4gIHdpZHRoOiAxMDJweDtcbiAgaGVpZ2h0OiAxMDJweDtcbiAgaW9uLWF2YXRhciB7XG4gICAgbWFyZ2luOiBhdXRvO1xuICB9XG4gIC5uaWNrbmFtZSB7XG4gICAgbWFyZ2luLXRvcDogMzJweDtcbiAgfVxufVxuIl19 */"]
});

/***/ }),

/***/ 79637:
/*!**************************************************!*\
  !*** ./node_modules/lodash-es/_arrayIncludes.js ***!
  \**************************************************/
/***/ (function(__unused_webpack___webpack_module__, __webpack_exports__, __webpack_require__) {

__webpack_require__.r(__webpack_exports__);
/* harmony import */ var _baseIndexOf_js__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./_baseIndexOf.js */ 81944);

/**
 * A specialized version of `_.includes` for arrays without support for
 * specifying an index to search from.
 *
 * @private
 * @param {Array} [array] The array to inspect.
 * @param {*} target The value to search for.
 * @returns {boolean} Returns `true` if `target` is found, else `false`.
 */

function arrayIncludes(array, value) {
  var length = array == null ? 0 : array.length;
  return !!length && (0,_baseIndexOf_js__WEBPACK_IMPORTED_MODULE_0__["default"])(array, value, 0) > -1;
}

/* harmony default export */ __webpack_exports__["default"] = (arrayIncludes);

/***/ }),

/***/ 54540:
/*!******************************************************!*\
  !*** ./node_modules/lodash-es/_arrayIncludesWith.js ***!
  \******************************************************/
/***/ (function(__unused_webpack___webpack_module__, __webpack_exports__, __webpack_require__) {

__webpack_require__.r(__webpack_exports__);
/**
 * This function is like `arrayIncludes` except that it accepts a comparator.
 *
 * @private
 * @param {Array} [array] The array to inspect.
 * @param {*} target The value to search for.
 * @param {Function} comparator The comparator invoked per element.
 * @returns {boolean} Returns `true` if `target` is found, else `false`.
 */
function arrayIncludesWith(array, value, comparator) {
  var index = -1,
      length = array == null ? 0 : array.length;

  while (++index < length) {
    if (comparator(value, array[index])) {
      return true;
    }
  }

  return false;
}

/* harmony default export */ __webpack_exports__["default"] = (arrayIncludesWith);

/***/ }),

/***/ 81944:
/*!************************************************!*\
  !*** ./node_modules/lodash-es/_baseIndexOf.js ***!
  \************************************************/
/***/ (function(__unused_webpack___webpack_module__, __webpack_exports__, __webpack_require__) {

__webpack_require__.r(__webpack_exports__);
/* harmony import */ var _baseFindIndex_js__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ./_baseFindIndex.js */ 19402);
/* harmony import */ var _baseIsNaN_js__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! ./_baseIsNaN.js */ 43876);
/* harmony import */ var _strictIndexOf_js__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./_strictIndexOf.js */ 35161);



/**
 * The base implementation of `_.indexOf` without `fromIndex` bounds checks.
 *
 * @private
 * @param {Array} array The array to inspect.
 * @param {*} value The value to search for.
 * @param {number} fromIndex The index to search from.
 * @returns {number} Returns the index of the matched value, else `-1`.
 */

function baseIndexOf(array, value, fromIndex) {
  return value === value ? (0,_strictIndexOf_js__WEBPACK_IMPORTED_MODULE_0__["default"])(array, value, fromIndex) : (0,_baseFindIndex_js__WEBPACK_IMPORTED_MODULE_1__["default"])(array, _baseIsNaN_js__WEBPACK_IMPORTED_MODULE_2__["default"], fromIndex);
}

/* harmony default export */ __webpack_exports__["default"] = (baseIndexOf);

/***/ }),

/***/ 49089:
/*!*****************************************************!*\
  !*** ./node_modules/lodash-es/_baseIntersection.js ***!
  \*****************************************************/
/***/ (function(__unused_webpack___webpack_module__, __webpack_exports__, __webpack_require__) {

__webpack_require__.r(__webpack_exports__);
/* harmony import */ var _SetCache_js__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! ./_SetCache.js */ 85675);
/* harmony import */ var _arrayIncludes_js__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ./_arrayIncludes.js */ 79637);
/* harmony import */ var _arrayIncludesWith_js__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./_arrayIncludesWith.js */ 54540);
/* harmony import */ var _arrayMap_js__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! ./_arrayMap.js */ 66717);
/* harmony import */ var _baseUnary_js__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! ./_baseUnary.js */ 7560);
/* harmony import */ var _cacheHas_js__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! ./_cacheHas.js */ 36149);






/* Built-in method references for those with the same name as other `lodash` methods. */

var nativeMin = Math.min;
/**
 * The base implementation of methods like `_.intersection`, without support
 * for iteratee shorthands, that accepts an array of arrays to inspect.
 *
 * @private
 * @param {Array} arrays The arrays to inspect.
 * @param {Function} [iteratee] The iteratee invoked per element.
 * @param {Function} [comparator] The comparator invoked per element.
 * @returns {Array} Returns the new array of shared values.
 */

function baseIntersection(arrays, iteratee, comparator) {
  var includes = comparator ? _arrayIncludesWith_js__WEBPACK_IMPORTED_MODULE_0__["default"] : _arrayIncludes_js__WEBPACK_IMPORTED_MODULE_1__["default"],
      length = arrays[0].length,
      othLength = arrays.length,
      othIndex = othLength,
      caches = Array(othLength),
      maxLength = Infinity,
      result = [];

  while (othIndex--) {
    var array = arrays[othIndex];

    if (othIndex && iteratee) {
      array = (0,_arrayMap_js__WEBPACK_IMPORTED_MODULE_2__["default"])(array, (0,_baseUnary_js__WEBPACK_IMPORTED_MODULE_3__["default"])(iteratee));
    }

    maxLength = nativeMin(array.length, maxLength);
    caches[othIndex] = !comparator && (iteratee || length >= 120 && array.length >= 120) ? new _SetCache_js__WEBPACK_IMPORTED_MODULE_4__["default"](othIndex && array) : undefined;
  }

  array = arrays[0];
  var index = -1,
      seen = caches[0];

  outer: while (++index < length && result.length < maxLength) {
    var value = array[index],
        computed = iteratee ? iteratee(value) : value;
    value = comparator || value !== 0 ? value : 0;

    if (!(seen ? (0,_cacheHas_js__WEBPACK_IMPORTED_MODULE_5__["default"])(seen, computed) : includes(result, computed, comparator))) {
      othIndex = othLength;

      while (--othIndex) {
        var cache = caches[othIndex];

        if (!(cache ? (0,_cacheHas_js__WEBPACK_IMPORTED_MODULE_5__["default"])(cache, computed) : includes(arrays[othIndex], computed, comparator))) {
          continue outer;
        }
      }

      if (seen) {
        seen.push(computed);
      }

      result.push(value);
    }
  }

  return result;
}

/* harmony default export */ __webpack_exports__["default"] = (baseIntersection);

/***/ }),

/***/ 43876:
/*!**********************************************!*\
  !*** ./node_modules/lodash-es/_baseIsNaN.js ***!
  \**********************************************/
/***/ (function(__unused_webpack___webpack_module__, __webpack_exports__, __webpack_require__) {

__webpack_require__.r(__webpack_exports__);
/**
 * The base implementation of `_.isNaN` without support for number objects.
 *
 * @private
 * @param {*} value The value to check.
 * @returns {boolean} Returns `true` if `value` is `NaN`, else `false`.
 */
function baseIsNaN(value) {
  return value !== value;
}

/* harmony default export */ __webpack_exports__["default"] = (baseIsNaN);

/***/ }),

/***/ 26061:
/*!********************************************************!*\
  !*** ./node_modules/lodash-es/_castArrayLikeObject.js ***!
  \********************************************************/
/***/ (function(__unused_webpack___webpack_module__, __webpack_exports__, __webpack_require__) {

__webpack_require__.r(__webpack_exports__);
/* harmony import */ var _isArrayLikeObject_js__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./isArrayLikeObject.js */ 69275);

/**
 * Casts `value` to an empty array if it's not an array like object.
 *
 * @private
 * @param {*} value The value to inspect.
 * @returns {Array|Object} Returns the cast array-like object.
 */

function castArrayLikeObject(value) {
  return (0,_isArrayLikeObject_js__WEBPACK_IMPORTED_MODULE_0__["default"])(value) ? value : [];
}

/* harmony default export */ __webpack_exports__["default"] = (castArrayLikeObject);

/***/ }),

/***/ 35161:
/*!**************************************************!*\
  !*** ./node_modules/lodash-es/_strictIndexOf.js ***!
  \**************************************************/
/***/ (function(__unused_webpack___webpack_module__, __webpack_exports__, __webpack_require__) {

__webpack_require__.r(__webpack_exports__);
/**
 * A specialized version of `_.indexOf` which performs strict equality
 * comparisons of values, i.e. `===`.
 *
 * @private
 * @param {Array} array The array to inspect.
 * @param {*} value The value to search for.
 * @param {number} fromIndex The index to search from.
 * @returns {number} Returns the index of the matched value, else `-1`.
 */
function strictIndexOf(array, value, fromIndex) {
  var index = fromIndex - 1,
      length = array.length;

  while (++index < length) {
    if (array[index] === value) {
      return index;
    }
  }

  return -1;
}

/* harmony default export */ __webpack_exports__["default"] = (strictIndexOf);

/***/ }),

/***/ 71156:
/*!****************************************************!*\
  !*** ./node_modules/lodash-es/intersectionWith.js ***!
  \****************************************************/
/***/ (function(__unused_webpack___webpack_module__, __webpack_exports__, __webpack_require__) {

__webpack_require__.r(__webpack_exports__);
/* harmony import */ var _arrayMap_js__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! ./_arrayMap.js */ 66717);
/* harmony import */ var _baseIntersection_js__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! ./_baseIntersection.js */ 49089);
/* harmony import */ var _baseRest_js__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./_baseRest.js */ 67269);
/* harmony import */ var _castArrayLikeObject_js__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! ./_castArrayLikeObject.js */ 26061);
/* harmony import */ var _last_js__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ./last.js */ 10757);





/**
 * This method is like `_.intersection` except that it accepts `comparator`
 * which is invoked to compare elements of `arrays`. The order and references
 * of result values are determined by the first array. The comparator is
 * invoked with two arguments: (arrVal, othVal).
 *
 * @static
 * @memberOf _
 * @since 4.0.0
 * @category Array
 * @param {...Array} [arrays] The arrays to inspect.
 * @param {Function} [comparator] The comparator invoked per element.
 * @returns {Array} Returns the new array of intersecting values.
 * @example
 *
 * var objects = [{ 'x': 1, 'y': 2 }, { 'x': 2, 'y': 1 }];
 * var others = [{ 'x': 1, 'y': 1 }, { 'x': 1, 'y': 2 }];
 *
 * _.intersectionWith(objects, others, _.isEqual);
 * // => [{ 'x': 1, 'y': 2 }]
 */

var intersectionWith = (0,_baseRest_js__WEBPACK_IMPORTED_MODULE_0__["default"])(function (arrays) {
  var comparator = (0,_last_js__WEBPACK_IMPORTED_MODULE_1__["default"])(arrays),
      mapped = (0,_arrayMap_js__WEBPACK_IMPORTED_MODULE_2__["default"])(arrays, _castArrayLikeObject_js__WEBPACK_IMPORTED_MODULE_3__["default"]);
  comparator = typeof comparator == 'function' ? comparator : undefined;

  if (comparator) {
    mapped.pop();
  }

  return mapped.length && mapped[0] === arrays[0] ? (0,_baseIntersection_js__WEBPACK_IMPORTED_MODULE_4__["default"])(mapped, undefined, comparator) : [];
});
/* harmony default export */ __webpack_exports__["default"] = (intersectionWith);

/***/ })

}]);
//# sourceMappingURL=src_app_pages_user-profile_user-profile_module_ts.js.map