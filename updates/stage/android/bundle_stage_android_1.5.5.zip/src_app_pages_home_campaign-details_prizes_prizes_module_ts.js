"use strict";
(self["webpackChunkapp"] = self["webpackChunkapp"] || []).push([["src_app_pages_home_campaign-details_prizes_prizes_module_ts"],{

/***/ 9865:
/*!*********************************************************************************!*\
  !*** ./src/app/pages/home/campaign-details/prizes/detail-modal/detail.modal.ts ***!
  \*********************************************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   DetailPrizeModalPage: () => (/* binding */ DetailPrizeModalPage)
/* harmony export */ });
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! @angular/core */ 12481);
/* harmony import */ var _ionic_angular__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @ionic/angular */ 21507);
/* harmony import */ var _ngx_translate_core__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @ngx-translate/core */ 48503);
/* harmony import */ var _core_shared_pipes_languageMap_pipe__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! ../../../../../core/shared/pipes/languageMap.pipe */ 69618);
var _staticBlock;




class DetailPrizeModalPage {
  constructor(modalController) {
    this.modalController = modalController;
    this.type = 'playgo';
  }
  ngOnInit() {}
  close() {
    this.modalController.dismiss(false);
  }
  static #_ = _staticBlock = () => (this.ɵfac = function DetailPrizeModalPage_Factory(__ngFactoryType__) {
    return new (__ngFactoryType__ || DetailPrizeModalPage)(_angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵdirectiveInject"](_ionic_angular__WEBPACK_IMPORTED_MODULE_1__.ModalController));
  }, this.ɵcmp = /*@__PURE__*/_angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵdefineComponent"]({
    type: DetailPrizeModalPage,
    selectors: [["app-detail-modal"]],
    standalone: false,
    decls: 14,
    vars: 9,
    consts: [[3, "color"], ["mode", "md"], ["slot", " end"], [3, "click"], ["name", "close-circle-outline"], [1, "ion-padding", 3, "color"], [3, "innerHTML"], ["color", "playgo", 1, "ion-text-center"], ["expand", "block", "color", "light", 3, "click"]],
    template: function DetailPrizeModalPage_Template(rf, ctx) {
      if (rf & 1) {
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](0, "ion-header")(1, "ion-toolbar", 0)(2, "ion-title", 1);
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵtext"](3);
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](4, "ion-buttons", 2)(5, "ion-button", 3);
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵlistener"]("click", function DetailPrizeModalPage_Template_ion_button_click_5_listener() {
          return ctx.close();
        });
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelement"](6, "ion-icon", 4);
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]()()()();
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](7, "ion-content", 5);
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelement"](8, "div", 6);
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵpipe"](9, "languageMap");
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](10, "ion-footer", 7)(11, "ion-button", 8);
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵlistener"]("click", function DetailPrizeModalPage_Template_ion_button_click_11_listener() {
          return ctx.close();
        });
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵtext"](12);
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵpipe"](13, "translate");
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]()();
      }
      if (rf & 2) {
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵadvance"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵproperty"]("color", ctx.type);
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵadvance"](2);
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵtextInterpolate"](ctx.title);
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵadvance"](4);
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵproperty"]("color", ctx.type);
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵadvance"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵproperty"]("innerHTML", _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵpipeBind1"](9, 5, ctx.detail), _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵsanitizeHtml"]);
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵadvance"](4);
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵtextInterpolate"](_angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵpipeBind1"](13, 7, "modal.ok"));
      }
    },
    dependencies: [_ionic_angular__WEBPACK_IMPORTED_MODULE_1__.IonButton, _ionic_angular__WEBPACK_IMPORTED_MODULE_1__.IonButtons, _ionic_angular__WEBPACK_IMPORTED_MODULE_1__.IonContent, _ionic_angular__WEBPACK_IMPORTED_MODULE_1__.IonFooter, _ionic_angular__WEBPACK_IMPORTED_MODULE_1__.IonHeader, _ionic_angular__WEBPACK_IMPORTED_MODULE_1__.IonIcon, _ionic_angular__WEBPACK_IMPORTED_MODULE_1__.IonTitle, _ionic_angular__WEBPACK_IMPORTED_MODULE_1__.IonToolbar, _ngx_translate_core__WEBPACK_IMPORTED_MODULE_2__.TranslatePipe, _core_shared_pipes_languageMap_pipe__WEBPACK_IMPORTED_MODULE_3__.LanguageMapPipe],
    styles: ["/*# sourceMappingURL=data:application/json;charset=utf-8;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbXSwibmFtZXMiOltdLCJtYXBwaW5ncyI6IiIsInNvdXJjZVJvb3QiOiIifQ== */"]
  }));
}
_staticBlock();

/***/ }),

/***/ 74921:
/*!*****************************************************************************!*\
  !*** ./src/app/pages/home/campaign-details/prizes/prizes-routing.module.ts ***!
  \*****************************************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   PrizesPageRoutingModule: () => (/* binding */ PrizesPageRoutingModule)
/* harmony export */ });
/* harmony import */ var _angular_router__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! @angular/router */ 34487);
/* harmony import */ var _prizes_page__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ./prizes.page */ 85403);
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @angular/core */ 34205);
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @angular/core */ 12481);
var _staticBlock;




const routes = [{
  path: '',
  component: _prizes_page__WEBPACK_IMPORTED_MODULE_1__.PrizesPage,
  data: {
    title: 'campaigns.detail.prizes'
  }
}];
class PrizesPageRoutingModule {
  static #_ = _staticBlock = () => (this.ɵfac = function PrizesPageRoutingModule_Factory(__ngFactoryType__) {
    return new (__ngFactoryType__ || PrizesPageRoutingModule)();
  }, this.ɵmod = /*@__PURE__*/_angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵdefineNgModule"]({
    type: PrizesPageRoutingModule
  }), this.ɵinj = /*@__PURE__*/_angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵdefineInjector"]({
    imports: [_angular_router__WEBPACK_IMPORTED_MODULE_0__.RouterModule.forChild(routes), _angular_router__WEBPACK_IMPORTED_MODULE_0__.RouterModule]
  }));
}
_staticBlock();
(function () {
  (typeof ngJitMode === "undefined" || ngJitMode) && _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵsetNgModuleScope"](PrizesPageRoutingModule, {
    imports: [_angular_router__WEBPACK_IMPORTED_MODULE_0__.RouterModule],
    exports: [_angular_router__WEBPACK_IMPORTED_MODULE_0__.RouterModule]
  });
})();

/***/ }),

/***/ 85403:
/*!*******************************************************************!*\
  !*** ./src/app/pages/home/campaign-details/prizes/prizes.page.ts ***!
  \*******************************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   PrizesPage: () => (/* binding */ PrizesPage)
/* harmony export */ });
/* harmony import */ var _Users_smartcommunitylab_Desktop_newWork_playAndGo_playGo_node_modules_babel_runtime_helpers_esm_asyncToGenerator_js__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./node_modules/@babel/runtime/helpers/esm/asyncToGenerator.js */ 89204);
/* harmony import */ var luxon__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! luxon */ 45967);
/* harmony import */ var rxjs__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! rxjs */ 56196);
/* harmony import */ var rxjs__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! rxjs */ 70271);
/* harmony import */ var rxjs__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! rxjs */ 86301);
/* harmony import */ var _prize_modal_prize_modal__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! ./prize-modal/prize.modal */ 98769);
/* harmony import */ var _capacitor_browser__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! @capacitor/browser */ 26515);
/* harmony import */ var _detail_modal_detail_modal__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(/*! ./detail-modal/detail.modal */ 9865);
/* harmony import */ var _ionic_angular__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(/*! @ionic/angular */ 21507);
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_9__ = __webpack_require__(/*! @angular/core */ 34205);
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_10__ = __webpack_require__(/*! @angular/core */ 12481);
/* harmony import */ var _angular_router__WEBPACK_IMPORTED_MODULE_11__ = __webpack_require__(/*! @angular/router */ 85422);
/* harmony import */ var src_app_core_shared_services_page_settings_service__WEBPACK_IMPORTED_MODULE_12__ = __webpack_require__(/*! src/app/core/shared/services/page-settings.service */ 40147);
/* harmony import */ var src_app_core_shared_services_campaign_service__WEBPACK_IMPORTED_MODULE_13__ = __webpack_require__(/*! src/app/core/shared/services/campaign.service */ 76658);
/* harmony import */ var _ngx_translate_core__WEBPACK_IMPORTED_MODULE_14__ = __webpack_require__(/*! @ngx-translate/core */ 48503);
/* harmony import */ var _angular_common__WEBPACK_IMPORTED_MODULE_15__ = __webpack_require__(/*! @angular/common */ 93683);
/* harmony import */ var _angular_forms__WEBPACK_IMPORTED_MODULE_16__ = __webpack_require__(/*! @angular/forms */ 34456);
/* harmony import */ var _core_shared_layout_header_header_directive__WEBPACK_IMPORTED_MODULE_17__ = __webpack_require__(/*! ../../../../core/shared/layout/header/header.directive */ 85039);
/* harmony import */ var _core_shared_layout_content_content_directive__WEBPACK_IMPORTED_MODULE_18__ = __webpack_require__(/*! ../../../../core/shared/layout/content/content.directive */ 75855);
/* harmony import */ var _core_shared_globalization_ordinal_number_ordinal_number_component__WEBPACK_IMPORTED_MODULE_19__ = __webpack_require__(/*! ../../../../core/shared/globalization/ordinal-number/ordinal-number.component */ 6972);
/* harmony import */ var _core_shared_pipes_localDate_pipe__WEBPACK_IMPORTED_MODULE_20__ = __webpack_require__(/*! ../../../../core/shared/pipes/localDate.pipe */ 86451);
/* harmony import */ var _core_shared_pipes_languageMap_pipe__WEBPACK_IMPORTED_MODULE_21__ = __webpack_require__(/*! ../../../../core/shared/pipes/languageMap.pipe */ 69618);

var _staticBlock;



















function PrizesPage_div_11_ng_container_1_ng_container_13_ion_card_1_ng_container_5_Template(rf, ctx) {
  if (rf & 1) {
    _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵelementContainerStart"](0);
    _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵtext"](1);
    _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵpipe"](2, "languageMap");
    _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵelementContainerEnd"]();
  }
  if (rf & 2) {
    const reward_r4 = _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵnextContext"]().$implicit;
    _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵadvance"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵtextInterpolate1"](" ", _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵpipeBind1"](2, 1, reward_r4.label), " ");
  }
}
function PrizesPage_div_11_ng_container_1_ng_container_13_ion_card_1_ng_template_7_Template(rf, ctx) {
  if (rf & 1) {
    _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵelement"](0, "app-ordinal-number", 19);
  }
  if (rf & 2) {
    const i_r5 = _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵnextContext"]().index;
    _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵproperty"]("value", i_r5 + 1);
  }
}
function PrizesPage_div_11_ng_container_1_ng_container_13_ion_card_1_ion_grid_13_ion_row_6_div_6_Template(rf, ctx) {
  if (rf & 1) {
    _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵelementStart"](0, "div", 21)(1, "b");
    _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵtext"](2);
    _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵelementEnd"]()();
  }
  if (rf & 2) {
    const reward_r4 = _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵnextContext"](3).$implicit;
    _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵadvance"](2);
    _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵtextInterpolate"](reward_r4.sponsor);
  }
}
function PrizesPage_div_11_ng_container_1_ng_container_13_ion_card_1_ion_grid_13_ion_row_6_div_7_Template(rf, ctx) {
  if (rf & 1) {
    _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵelement"](0, "div", 28);
    _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵpipe"](1, "languageMap");
  }
  if (rf & 2) {
    const reward_r4 = _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵnextContext"](3).$implicit;
    _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵproperty"]("innerHTML", _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵpipeBind1"](1, 1, reward_r4.sponsorDesc), _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵsanitizeHtml"]);
  }
}
function PrizesPage_div_11_ng_container_1_ng_container_13_ion_card_1_ion_grid_13_ion_row_6_div_8_Template(rf, ctx) {
  if (rf & 1) {
    const _r6 = _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵgetCurrentView"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵelementStart"](0, "div", 29);
    _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵlistener"]("click", function PrizesPage_div_11_ng_container_1_ng_container_13_ion_card_1_ion_grid_13_ion_row_6_div_8_Template_div_click_0_listener() {
      _angular_core__WEBPACK_IMPORTED_MODULE_9__["ɵɵrestoreView"](_r6);
      const reward_r4 = _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵnextContext"](3).$implicit;
      const ctx_r1 = _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵnextContext"](4);
      return _angular_core__WEBPACK_IMPORTED_MODULE_9__["ɵɵresetView"](ctx_r1.openLink(reward_r4.sponsorWebsite));
    });
    _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵtext"](1);
    _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵpipe"](2, "translate");
    _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵelementEnd"]();
  }
  if (rf & 2) {
    _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵadvance"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵtextInterpolate1"](" ", _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵpipeBind1"](2, 1, "campaigns.detail.prize.website"));
  }
}
function PrizesPage_div_11_ng_container_1_ng_container_13_ion_card_1_ion_grid_13_ion_row_6_Template(rf, ctx) {
  if (rf & 1) {
    _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵelementStart"](0, "ion-row", 23)(1, "ion-col")(2, "div", 24);
    _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵtext"](3);
    _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵpipe"](4, "translate");
    _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵpipe"](5, "uppercase");
    _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵelementEnd"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵtemplate"](6, PrizesPage_div_11_ng_container_1_ng_container_13_ion_card_1_ion_grid_13_ion_row_6_div_6_Template, 3, 1, "div", 25)(7, PrizesPage_div_11_ng_container_1_ng_container_13_ion_card_1_ion_grid_13_ion_row_6_div_7_Template, 2, 3, "div", 26)(8, PrizesPage_div_11_ng_container_1_ng_container_13_ion_card_1_ion_grid_13_ion_row_6_div_8_Template, 3, 3, "div", 27);
    _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵelementEnd"]()();
  }
  if (rf & 2) {
    const reward_r4 = _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵnextContext"](2).$implicit;
    _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵadvance"](3);
    _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵtextInterpolate1"]("", _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵpipeBind1"](5, 6, _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵpipeBind1"](4, 4, "campaigns.detail.prize.sponsorBy")), " ");
    _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵadvance"](3);
    _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵproperty"]("ngIf", reward_r4.sponsor);
    _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵadvance"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵproperty"]("ngIf", reward_r4.sponsorDesc);
    _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵadvance"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵproperty"]("ngIf", reward_r4.sponsorWebsite);
  }
}
function PrizesPage_div_11_ng_container_1_ng_container_13_ion_card_1_ion_grid_13_Template(rf, ctx) {
  if (rf & 1) {
    _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵelementStart"](0, "ion-grid")(1, "ion-row", 20)(2, "ion-col", 21)(3, "b");
    _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵtext"](4);
    _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵpipe"](5, "languageMap");
    _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵelementEnd"]()()();
    _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵtemplate"](6, PrizesPage_div_11_ng_container_1_ng_container_13_ion_card_1_ion_grid_13_ion_row_6_Template, 9, 8, "ion-row", 22);
    _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵpipe"](7, "languageMap");
    _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵelementEnd"]();
  }
  if (rf & 2) {
    const reward_r4 = _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵnextContext"]().$implicit;
    _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵadvance"](4);
    _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵtextInterpolate"](_angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵpipeBind1"](5, 2, reward_r4.desc));
    _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵadvance"](2);
    _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵproperty"]("ngIf", _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵpipeBind1"](7, 4, reward_r4.sponsorDesc) || reward_r4.sponsor || reward_r4.sponsorWebsite);
  }
}
function PrizesPage_div_11_ng_container_1_ng_container_13_ion_card_1_Template(rf, ctx) {
  if (rf & 1) {
    const _r3 = _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵgetCurrentView"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵelementStart"](0, "ion-card")(1, "ion-card-header", 14)(2, "ion-card-title")(3, "span");
    _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵelement"](4, "ion-icon", 15);
    _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵtemplate"](5, PrizesPage_div_11_ng_container_1_ng_container_13_ion_card_1_ng_container_5_Template, 3, 3, "ng-container", 10);
    _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵpipe"](6, "languageMap");
    _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵtemplate"](7, PrizesPage_div_11_ng_container_1_ng_container_13_ion_card_1_ng_template_7_Template, 1, 1, "ng-template", null, 2, _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵtemplateRefExtractor"]);
    _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵelementEnd"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵelementStart"](9, "ion-icon", 16);
    _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵlistener"]("click", function PrizesPage_div_11_ng_container_1_ng_container_13_ion_card_1_Template_ion_icon_click_9_listener() {
      const i_r5 = _angular_core__WEBPACK_IMPORTED_MODULE_9__["ɵɵrestoreView"](_r3).index;
      const ctx_r1 = _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵnextContext"](4);
      return _angular_core__WEBPACK_IMPORTED_MODULE_9__["ɵɵresetView"](ctx_r1.openRewardDescActual(ctx_r1.actualPrize, i_r5));
    });
    _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵelementEnd"]()()();
    _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵelementStart"](10, "ion-card-content")(11, "div", 17)(12, "div", 18);
    _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵtemplate"](13, PrizesPage_div_11_ng_container_1_ng_container_13_ion_card_1_ion_grid_13_Template, 8, 6, "ion-grid", 9);
    _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵelementEnd"]()()()();
  }
  if (rf & 2) {
    const reward_r4 = ctx.$implicit;
    const ordinaryNumber_r7 = _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵreference"](8);
    const ctx_r1 = _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵnextContext"](4);
    _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵadvance"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵproperty"]("ngClass", ctx_r1.getPostion(reward_r4.position - 1));
    _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵadvance"](4);
    _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵproperty"]("ngIf", _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵpipeBind1"](6, 4, reward_r4.label))("ngIfElse", ordinaryNumber_r7);
    _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵadvance"](8);
    _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵproperty"]("ngIf", reward_r4.desc);
  }
}
function PrizesPage_div_11_ng_container_1_ng_container_13_Template(rf, ctx) {
  if (rf & 1) {
    _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵelementContainerStart"](0);
    _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵtemplate"](1, PrizesPage_div_11_ng_container_1_ng_container_13_ion_card_1_Template, 14, 6, "ion-card", 13);
    _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵelementContainerEnd"]();
  }
  if (rf & 2) {
    const ctx_r1 = _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵnextContext"](3);
    _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵadvance"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵproperty"]("ngForOf", ctx_r1.actualPrize.rewards);
  }
}
function PrizesPage_div_11_ng_container_1_ng_container_14_ion_button_1_Template(rf, ctx) {
  if (rf & 1) {
    const _r8 = _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵgetCurrentView"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵelementStart"](0, "ion-button", 31);
    _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵlistener"]("click", function PrizesPage_div_11_ng_container_1_ng_container_14_ion_button_1_Template_ion_button_click_0_listener() {
      _angular_core__WEBPACK_IMPORTED_MODULE_9__["ɵɵrestoreView"](_r8);
      const ctx_r1 = _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵnextContext"](4);
      return _angular_core__WEBPACK_IMPORTED_MODULE_9__["ɵɵresetView"](ctx_r1.expandPrizes());
    });
    _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵtext"](1);
    _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵpipe"](2, "translate");
    _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵelementEnd"]();
  }
  if (rf & 2) {
    const ctx_r1 = _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵnextContext"](4);
    _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵproperty"]("color", ctx_r1.campaignContainer == null ? null : ctx_r1.campaignContainer.campaign == null ? null : ctx_r1.campaignContainer.campaign.type);
    _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵadvance"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵtextInterpolate"](_angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵpipeBind1"](2, 2, "campaigns.detail.prize.expand"));
  }
}
function PrizesPage_div_11_ng_container_1_ng_container_14_Template(rf, ctx) {
  if (rf & 1) {
    _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵelementContainerStart"](0);
    _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵtemplate"](1, PrizesPage_div_11_ng_container_1_ng_container_14_ion_button_1_Template, 3, 4, "ion-button", 30);
    _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵelementContainerEnd"]();
  }
  if (rf & 2) {
    _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵnextContext"](2);
    const expanded_r9 = _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵreference"](5);
    const ctx_r1 = _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵnextContext"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵadvance"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵproperty"]("ngIf", ctx_r1.notExpanded)("ngIfElse", expanded_r9);
  }
}
function PrizesPage_div_11_ng_container_1_Template(rf, ctx) {
  if (rf & 1) {
    const _r1 = _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵgetCurrentView"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵelementContainerStart"](0);
    _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵelementStart"](1, "div", 11)(2, "p")(3, "b");
    _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵtext"](4);
    _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵpipe"](5, "translate");
    _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵelementEnd"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵelementStart"](6, "ion-icon", 12);
    _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵlistener"]("click", function PrizesPage_div_11_ng_container_1_Template_ion_icon_click_6_listener() {
      _angular_core__WEBPACK_IMPORTED_MODULE_9__["ɵɵrestoreView"](_r1);
      const ctx_r1 = _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵnextContext"](2);
      return _angular_core__WEBPACK_IMPORTED_MODULE_9__["ɵɵresetView"](ctx_r1.openWeekDescActual(ctx_r1.actualPrize));
    });
    _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵelementEnd"]()();
    _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵelementStart"](7, "p");
    _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵtext"](8);
    _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵpipe"](9, "translate");
    _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵpipe"](10, "localDate");
    _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵpipe"](11, "translate");
    _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵpipe"](12, "localDate");
    _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵelementEnd"]()();
    _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵtemplate"](13, PrizesPage_div_11_ng_container_1_ng_container_13_Template, 2, 1, "ng-container", 10)(14, PrizesPage_div_11_ng_container_1_ng_container_14_Template, 2, 2, "ng-container", 9);
    _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵelementContainerEnd"]();
  }
  if (rf & 2) {
    _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵnextContext"]();
    const noRewards_r10 = _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵreference"](3);
    const ctx_r1 = _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵnextContext"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵadvance"](4);
    _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵtextInterpolate"](_angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵpipeBind1"](5, 8, "campaigns.detail.prize.prizeactual"));
    _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵadvance"](4);
    _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵtextInterpolate4"]("", _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵpipeBind1"](9, 10, "campaigns.detail.from"), "", _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵpipeBind2"](10, 12, ctx_r1.actualPrize.dateFrom, "d MMMM "), " \u00A0", _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵpipeBind1"](11, 15, "campaigns.detail.to"), "", _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵpipeBind2"](12, 17, ctx_r1.actualPrize.dateTo, " d MMMM y"));
    _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵadvance"](5);
    _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵproperty"]("ngIf", ctx_r1.prizePresent)("ngIfElse", noRewards_r10);
    _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵadvance"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵproperty"]("ngIf", ctx_r1.pastprizes());
  }
}
function PrizesPage_div_11_ng_template_2_Template(rf, ctx) {
  if (rf & 1) {
    _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵelementStart"](0, "div", 32);
    _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵtext"](1);
    _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵpipe"](2, "translate");
    _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵelementEnd"]();
  }
  if (rf & 2) {
    _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵadvance"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵtextInterpolate"](_angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵpipeBind1"](2, 1, "campaigns.detail.prize.noActual"));
  }
}
function PrizesPage_div_11_ng_template_4_Template(rf, ctx) {
  if (rf & 1) {
    _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵelementStart"](0, "div", 33)(1, "p")(2, "b");
    _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵtext"](3);
    _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵpipe"](4, "translate");
    _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵelementEnd"]()()();
  }
  if (rf & 2) {
    _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵadvance"](3);
    _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵtextInterpolate"](_angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵpipeBind1"](4, 1, "campaigns.detail.prize.expanded"));
  }
}
function PrizesPage_div_11_ng_container_6_ng_container_1_ion_card_1_span_9_Template(rf, ctx) {
  if (rf & 1) {
    _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵelementStart"](0, "span", 36);
    _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵtext"](1);
    _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵpipe"](2, "translate");
    _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵelementEnd"]();
  }
  if (rf & 2) {
    _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵadvance"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵtextInterpolate"](_angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵpipeBind1"](2, 1, "campaigns.detail.current"));
  }
}
function PrizesPage_div_11_ng_container_6_ng_container_1_ion_card_1_ion_accordion_13_div_12_div_6_Template(rf, ctx) {
  if (rf & 1) {
    _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵelementStart"](0, "div", 21)(1, "b");
    _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵtext"](2);
    _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵelementEnd"]()();
  }
  if (rf & 2) {
    const reward_r13 = _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵnextContext"](2).$implicit;
    _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵadvance"](2);
    _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵtextInterpolate"](reward_r13.sponsor);
  }
}
function PrizesPage_div_11_ng_container_6_ng_container_1_ion_card_1_ion_accordion_13_div_12_div_7_Template(rf, ctx) {
  if (rf & 1) {
    _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵelement"](0, "div", 28);
    _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵpipe"](1, "languageMap");
  }
  if (rf & 2) {
    const reward_r13 = _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵnextContext"](2).$implicit;
    _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵproperty"]("innerHTML", _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵpipeBind1"](1, 1, reward_r13.sponsorDesc), _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵsanitizeHtml"]);
  }
}
function PrizesPage_div_11_ng_container_6_ng_container_1_ion_card_1_ion_accordion_13_div_12_div_8_Template(rf, ctx) {
  if (rf & 1) {
    const _r14 = _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵgetCurrentView"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵelementStart"](0, "div", 29);
    _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵlistener"]("click", function PrizesPage_div_11_ng_container_6_ng_container_1_ion_card_1_ion_accordion_13_div_12_div_8_Template_div_click_0_listener() {
      _angular_core__WEBPACK_IMPORTED_MODULE_9__["ɵɵrestoreView"](_r14);
      const reward_r13 = _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵnextContext"](2).$implicit;
      const ctx_r1 = _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵnextContext"](5);
      return _angular_core__WEBPACK_IMPORTED_MODULE_9__["ɵɵresetView"](ctx_r1.openLink(reward_r13.sponsorWebsite));
    });
    _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵtext"](1);
    _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵpipe"](2, "translate");
    _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵelementEnd"]();
  }
  if (rf & 2) {
    _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵadvance"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵtextInterpolate1"](" ", _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵpipeBind1"](2, 1, "campaigns.detail.prize.website"));
  }
}
function PrizesPage_div_11_ng_container_6_ng_container_1_ion_card_1_ion_accordion_13_div_12_Template(rf, ctx) {
  if (rf & 1) {
    _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵelementStart"](0, "div", 44)(1, "div", 45)(2, "div", 24);
    _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵtext"](3);
    _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵpipe"](4, "translate");
    _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵpipe"](5, "uppercase");
    _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵelementEnd"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵtemplate"](6, PrizesPage_div_11_ng_container_6_ng_container_1_ion_card_1_ion_accordion_13_div_12_div_6_Template, 3, 1, "div", 25)(7, PrizesPage_div_11_ng_container_6_ng_container_1_ion_card_1_ion_accordion_13_div_12_div_7_Template, 2, 3, "div", 26)(8, PrizesPage_div_11_ng_container_6_ng_container_1_ion_card_1_ion_accordion_13_div_12_div_8_Template, 3, 3, "div", 27);
    _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵelementEnd"]()();
  }
  if (rf & 2) {
    const reward_r13 = _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵnextContext"]().$implicit;
    _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵadvance"](3);
    _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵtextInterpolate1"]("", _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵpipeBind1"](5, 6, _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵpipeBind1"](4, 4, "campaigns.detail.prize.sponsorBy")), " ");
    _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵadvance"](3);
    _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵproperty"]("ngIf", reward_r13.sponsor);
    _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵadvance"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵproperty"]("ngIf", reward_r13.sponsorDesc);
    _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵadvance"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵproperty"]("ngIf", reward_r13.sponsorWebsite);
  }
}
function PrizesPage_div_11_ng_container_6_ng_container_1_ion_card_1_ion_accordion_13_Template(rf, ctx) {
  if (rf & 1) {
    _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵelementStart"](0, "ion-accordion")(1, "ion-item", 37)(2, "div", 38)(3, "ion-grid")(4, "ion-row")(5, "ion-col", 39);
    _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵelement"](6, "ion-icon", 40)(7, "app-ordinal-number", 41);
    _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵelementEnd"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵelementStart"](8, "ion-col")(9, "span", 42);
    _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵtext"](10);
    _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵpipe"](11, "languageMap");
    _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵelementEnd"]()()()()()();
    _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵtemplate"](12, PrizesPage_div_11_ng_container_6_ng_container_1_ion_card_1_ion_accordion_13_div_12_Template, 9, 8, "div", 43);
    _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵpipe"](13, "languageMap");
    _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵelementEnd"]();
  }
  if (rf & 2) {
    const reward_r13 = ctx.$implicit;
    const ctx_r1 = _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵnextContext"](5);
    _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵadvance"](6);
    _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵproperty"]("ngClass", "packet-" + ctx_r1.getPostion((reward_r13 == null ? null : reward_r13.position) - 1));
    _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵadvance"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵproperty"]("value", reward_r13 == null ? null : reward_r13.position)("ngClass", "packet-" + ctx_r1.getPostion((reward_r13 == null ? null : reward_r13.position) - 1));
    _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵadvance"](3);
    _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵtextInterpolate"](_angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵpipeBind1"](11, 5, reward_r13.desc));
    _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵadvance"](2);
    _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵproperty"]("ngIf", _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵpipeBind1"](13, 7, reward_r13.sponsorDesc) || reward_r13.sponsor || reward_r13.sponsorWebsite);
  }
}
function PrizesPage_div_11_ng_container_6_ng_container_1_ion_card_1_Template(rf, ctx) {
  if (rf & 1) {
    const _r11 = _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵgetCurrentView"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵelementStart"](0, "ion-card")(1, "ion-card-header")(2, "ion-card-title")(3, "span", 34);
    _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵtext"](4);
    _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵpipe"](5, "translate");
    _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵpipe"](6, "localDate");
    _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵpipe"](7, "translate");
    _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵpipe"](8, "localDate");
    _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵelementEnd"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵtemplate"](9, PrizesPage_div_11_ng_container_6_ng_container_1_ion_card_1_span_9_Template, 3, 3, "span", 35);
    _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵelementStart"](10, "ion-icon", 16);
    _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵlistener"]("click", function PrizesPage_div_11_ng_container_6_ng_container_1_ion_card_1_Template_ion_icon_click_10_listener() {
      _angular_core__WEBPACK_IMPORTED_MODULE_9__["ɵɵrestoreView"](_r11);
      const conf_r12 = _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵnextContext"]().$implicit;
      const ctx_r1 = _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵnextContext"](3);
      return _angular_core__WEBPACK_IMPORTED_MODULE_9__["ɵɵresetView"](ctx_r1.openWeekDescPast(conf_r12));
    });
    _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵelementEnd"]()()();
    _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵelementStart"](11, "ion-card-content", 17)(12, "ion-accordion-group");
    _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵtemplate"](13, PrizesPage_div_11_ng_container_6_ng_container_1_ion_card_1_ion_accordion_13_Template, 14, 9, "ion-accordion", 13);
    _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵelementEnd"]()()();
  }
  if (rf & 2) {
    const conf_r12 = _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵnextContext"]().$implicit;
    const ctx_r1 = _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵnextContext"](3);
    _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵadvance"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵstyleProp"]("--background", "var(--ion-color-" + ctx_r1.campaignContainer.campaign.type + ")");
    _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵadvance"](3);
    _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵtextInterpolate4"]("", _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵpipeBind1"](5, 8, "campaigns.detail.from"), "", _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵpipeBind1"](6, 10, conf_r12.dateFrom), " ", _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵpipeBind1"](7, 12, "campaigns.detail.to"), " ", _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵpipeBind1"](8, 14, conf_r12.dateTo));
    _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵadvance"](5);
    _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵproperty"]("ngIf", ctx_r1.isThisPeriod(conf_r12 == null ? null : conf_r12.dateFrom, conf_r12 == null ? null : conf_r12.dateTo));
    _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵadvance"](4);
    _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵproperty"]("ngForOf", conf_r12.rewards);
  }
}
function PrizesPage_div_11_ng_container_6_ng_container_1_Template(rf, ctx) {
  if (rf & 1) {
    _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵelementContainerStart"](0);
    _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵtemplate"](1, PrizesPage_div_11_ng_container_6_ng_container_1_ion_card_1_Template, 14, 16, "ion-card", 9);
    _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵelementContainerEnd"]();
  }
  if (rf & 2) {
    const conf_r12 = ctx.$implicit;
    const ctx_r1 = _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵnextContext"](3);
    _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵadvance"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵproperty"]("ngIf", (conf_r12 == null ? null : conf_r12.rewards == null ? null : conf_r12.rewards.length) > 0 && (conf_r12 == null ? null : conf_r12.dateFrom) && (conf_r12 == null ? null : conf_r12.dateTo) && ctx_r1.isBeforeNow(conf_r12) && conf_r12.weekNumber !== 0 && ctx_r1.isMyGroupPrize(conf_r12));
  }
}
function PrizesPage_div_11_ng_container_6_Template(rf, ctx) {
  if (rf & 1) {
    _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵelementContainerStart"](0);
    _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵtemplate"](1, PrizesPage_div_11_ng_container_6_ng_container_1_Template, 2, 1, "ng-container", 13);
    _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵelementContainerEnd"]();
  }
  if (rf & 2) {
    const ctx_r1 = _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵnextContext"](2);
    _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵadvance"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵproperty"]("ngForOf", ctx_r1.campaignContainer == null ? null : ctx_r1.campaignContainer.campaign == null ? null : ctx_r1.campaignContainer.campaign.weekConfs);
  }
}
function PrizesPage_div_11_Template(rf, ctx) {
  if (rf & 1) {
    _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵelementStart"](0, "div");
    _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵtemplate"](1, PrizesPage_div_11_ng_container_1_Template, 15, 20, "ng-container", 10)(2, PrizesPage_div_11_ng_template_2_Template, 3, 3, "ng-template", null, 0, _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵtemplateRefExtractor"])(4, PrizesPage_div_11_ng_template_4_Template, 5, 3, "ng-template", null, 1, _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵtemplateRefExtractor"])(6, PrizesPage_div_11_ng_container_6_Template, 2, 1, "ng-container", 9);
    _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵelementEnd"]();
  }
  if (rf & 2) {
    const noRewards_r10 = _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵreference"](3);
    const ctx_r1 = _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵnextContext"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵadvance"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵproperty"]("ngIf", ctx_r1.pastprizes() || ctx_r1.prizePresent)("ngIfElse", noRewards_r10);
    _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵadvance"](5);
    _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵproperty"]("ngIf", !ctx_r1.notExpanded);
  }
}
function PrizesPage_div_12_ng_container_1_ion_card_6_ng_container_5_Template(rf, ctx) {
  if (rf & 1) {
    _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵelementContainerStart"](0);
    _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵelementStart"](1, "b");
    _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵtext"](2);
    _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵpipe"](3, "languageMap");
    _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵelementEnd"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵelementContainerEnd"]();
  }
  if (rf & 2) {
    const reward_r18 = _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵnextContext"]().$implicit;
    _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵadvance"](2);
    _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵtextInterpolate"](_angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵpipeBind1"](3, 1, reward_r18.label));
  }
}
function PrizesPage_div_12_ng_container_1_ion_card_6_ng_template_7_Template(rf, ctx) {
  if (rf & 1) {
    _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵelementStart"](0, "b");
    _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵelement"](1, "app-ordinal-number", 19);
    _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵelementEnd"]();
  }
  if (rf & 2) {
    const i_r19 = _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵnextContext"]().index;
    _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵadvance"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵproperty"]("value", i_r19 + 1);
  }
}
function PrizesPage_div_12_ng_container_1_ion_card_6_ion_grid_13_ion_row_5_div_6_Template(rf, ctx) {
  if (rf & 1) {
    _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵelementStart"](0, "div", 21)(1, "b");
    _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵtext"](2);
    _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵelementEnd"]()();
  }
  if (rf & 2) {
    const reward_r18 = _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵnextContext"](3).$implicit;
    _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵadvance"](2);
    _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵtextInterpolate"](reward_r18.sponsor);
  }
}
function PrizesPage_div_12_ng_container_1_ion_card_6_ion_grid_13_ion_row_5_div_7_Template(rf, ctx) {
  if (rf & 1) {
    _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵelement"](0, "div", 28);
    _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵpipe"](1, "languageMap");
  }
  if (rf & 2) {
    const reward_r18 = _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵnextContext"](3).$implicit;
    _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵproperty"]("innerHTML", _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵpipeBind1"](1, 1, reward_r18.sponsorDesc), _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵsanitizeHtml"]);
  }
}
function PrizesPage_div_12_ng_container_1_ion_card_6_ion_grid_13_ion_row_5_div_8_Template(rf, ctx) {
  if (rf & 1) {
    const _r20 = _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵgetCurrentView"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵelementStart"](0, "div", 29);
    _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵlistener"]("click", function PrizesPage_div_12_ng_container_1_ion_card_6_ion_grid_13_ion_row_5_div_8_Template_div_click_0_listener() {
      _angular_core__WEBPACK_IMPORTED_MODULE_9__["ɵɵrestoreView"](_r20);
      const reward_r18 = _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵnextContext"](3).$implicit;
      const ctx_r1 = _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵnextContext"](3);
      return _angular_core__WEBPACK_IMPORTED_MODULE_9__["ɵɵresetView"](ctx_r1.openLink(reward_r18.sponsorWebsite));
    });
    _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵtext"](1);
    _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵpipe"](2, "translate");
    _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵelementEnd"]();
  }
  if (rf & 2) {
    _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵadvance"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵtextInterpolate1"](" ", _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵpipeBind1"](2, 1, "campaigns.detail.prize.website"));
  }
}
function PrizesPage_div_12_ng_container_1_ion_card_6_ion_grid_13_ion_row_5_Template(rf, ctx) {
  if (rf & 1) {
    _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵelementStart"](0, "ion-row", 23)(1, "ion-col")(2, "div", 24);
    _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵtext"](3);
    _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵpipe"](4, "translate");
    _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵpipe"](5, "uppercase");
    _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵelementEnd"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵtemplate"](6, PrizesPage_div_12_ng_container_1_ion_card_6_ion_grid_13_ion_row_5_div_6_Template, 3, 1, "div", 25)(7, PrizesPage_div_12_ng_container_1_ion_card_6_ion_grid_13_ion_row_5_div_7_Template, 2, 3, "div", 26)(8, PrizesPage_div_12_ng_container_1_ion_card_6_ion_grid_13_ion_row_5_div_8_Template, 3, 3, "div", 27);
    _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵelementEnd"]()();
  }
  if (rf & 2) {
    const reward_r18 = _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵnextContext"](2).$implicit;
    _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵadvance"](3);
    _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵtextInterpolate1"]("", _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵpipeBind1"](5, 6, _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵpipeBind1"](4, 4, "campaigns.detail.prize.sponsorBy")), " ");
    _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵadvance"](3);
    _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵproperty"]("ngIf", reward_r18.sponsor);
    _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵadvance"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵproperty"]("ngIf", reward_r18.sponsorDesc);
    _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵadvance"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵproperty"]("ngIf", reward_r18.sponsorWebsite);
  }
}
function PrizesPage_div_12_ng_container_1_ion_card_6_ion_grid_13_Template(rf, ctx) {
  if (rf & 1) {
    _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵelementStart"](0, "ion-grid")(1, "ion-row", 20)(2, "ion-col", 21);
    _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵtext"](3);
    _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵpipe"](4, "languageMap");
    _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵelementEnd"]()();
    _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵtemplate"](5, PrizesPage_div_12_ng_container_1_ion_card_6_ion_grid_13_ion_row_5_Template, 9, 8, "ion-row", 22);
    _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵpipe"](6, "languageMap");
    _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵelementEnd"]();
  }
  if (rf & 2) {
    const reward_r18 = _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵnextContext"]().$implicit;
    _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵadvance"](3);
    _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵtextInterpolate1"]("", _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵpipeBind1"](4, 2, reward_r18.desc), " ");
    _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵadvance"](2);
    _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵproperty"]("ngIf", _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵpipeBind1"](6, 4, reward_r18.sponsorDesc) || reward_r18.sponsor || reward_r18.sponsorWebsite);
  }
}
function PrizesPage_div_12_ng_container_1_ion_card_6_Template(rf, ctx) {
  if (rf & 1) {
    const _r17 = _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵgetCurrentView"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵelementStart"](0, "ion-card")(1, "ion-card-header", 14)(2, "ion-card-title")(3, "span");
    _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵelement"](4, "ion-icon", 15);
    _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵtemplate"](5, PrizesPage_div_12_ng_container_1_ion_card_6_ng_container_5_Template, 4, 3, "ng-container", 10);
    _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵpipe"](6, "languageMap");
    _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵtemplate"](7, PrizesPage_div_12_ng_container_1_ion_card_6_ng_template_7_Template, 2, 1, "ng-template", null, 2, _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵtemplateRefExtractor"]);
    _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵelementEnd"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵelementStart"](9, "ion-icon", 16);
    _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵlistener"]("click", function PrizesPage_div_12_ng_container_1_ion_card_6_Template_ion_icon_click_9_listener() {
      const i_r19 = _angular_core__WEBPACK_IMPORTED_MODULE_9__["ɵɵrestoreView"](_r17).index;
      const finalPrize_r16 = _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵnextContext"]().ngIf;
      const ctx_r1 = _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵnextContext"](2);
      return _angular_core__WEBPACK_IMPORTED_MODULE_9__["ɵɵresetView"](ctx_r1.openRewardDescFinal(finalPrize_r16, i_r19));
    });
    _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵelementEnd"]()()();
    _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵelementStart"](10, "ion-card-content")(11, "div", 17)(12, "div", 18);
    _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵtemplate"](13, PrizesPage_div_12_ng_container_1_ion_card_6_ion_grid_13_Template, 7, 6, "ion-grid", 9);
    _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵelementEnd"]()()()();
  }
  if (rf & 2) {
    const reward_r18 = ctx.$implicit;
    const ordinaryNumber_r21 = _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵreference"](8);
    const ctx_r1 = _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵnextContext"](3);
    _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵadvance"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵproperty"]("ngClass", ctx_r1.getPostion(reward_r18.position - 1));
    _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵadvance"](4);
    _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵproperty"]("ngIf", _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵpipeBind1"](6, 4, reward_r18.label))("ngIfElse", ordinaryNumber_r21);
    _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵadvance"](8);
    _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵproperty"]("ngIf", reward_r18.desc);
  }
}
function PrizesPage_div_12_ng_container_1_Template(rf, ctx) {
  if (rf & 1) {
    const _r15 = _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵgetCurrentView"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵelementContainerStart"](0);
    _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵelementStart"](1, "div", 46)(2, "span");
    _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵtext"](3);
    _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵpipe"](4, "translate");
    _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵelementStart"](5, "ion-icon", 12);
    _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵlistener"]("click", function PrizesPage_div_12_ng_container_1_Template_ion_icon_click_5_listener() {
      const finalPrize_r16 = _angular_core__WEBPACK_IMPORTED_MODULE_9__["ɵɵrestoreView"](_r15).ngIf;
      const ctx_r1 = _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵnextContext"](2);
      return _angular_core__WEBPACK_IMPORTED_MODULE_9__["ɵɵresetView"](ctx_r1.openWeekDescFinal(finalPrize_r16));
    });
    _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵelementEnd"]()()();
    _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵtemplate"](6, PrizesPage_div_12_ng_container_1_ion_card_6_Template, 14, 6, "ion-card", 13);
    _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵelementContainerEnd"]();
  }
  if (rf & 2) {
    const finalPrize_r16 = ctx.ngIf;
    _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵadvance"](3);
    _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵtextInterpolate"](_angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵpipeBind1"](4, 2, "campaigns.detail.prize.prizefinal"));
    _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵadvance"](3);
    _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵproperty"]("ngForOf", finalPrize_r16.rewards);
  }
}
function PrizesPage_div_12_ng_template_2_Template(rf, ctx) {
  if (rf & 1) {
    _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵelementStart"](0, "div", 32);
    _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵtext"](1);
    _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵpipe"](2, "translate");
    _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵelementEnd"]();
  }
  if (rf & 2) {
    _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵadvance"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵtextInterpolate"](_angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵpipeBind1"](2, 1, "campaigns.detail.prize.noFinal"));
  }
}
function PrizesPage_div_12_Template(rf, ctx) {
  if (rf & 1) {
    _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵelementStart"](0, "div");
    _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵtemplate"](1, PrizesPage_div_12_ng_container_1_Template, 7, 4, "ng-container", 10)(2, PrizesPage_div_12_ng_template_2_Template, 3, 3, "ng-template", null, 3, _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵtemplateRefExtractor"]);
    _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵelementEnd"]();
  }
  if (rf & 2) {
    const noFinal_r22 = _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵreference"](3);
    const ctx_r1 = _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵnextContext"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵadvance"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵproperty"]("ngIf", ctx_r1.getFinalPrize())("ngIfElse", noFinal_r22);
  }
}
class PrizesPage {
  constructor(route, pageSettingsService, campaignService, modalController, translateService) {
    this.route = route;
    this.pageSettingsService = pageSettingsService;
    this.campaignService = campaignService;
    this.modalController = modalController;
    this.translateService = translateService;
    this.notExpanded = true;
    this.campaignId$ = this.route.params.pipe((0,rxjs__WEBPACK_IMPORTED_MODULE_3__.map)(params => params.id), (0,rxjs__WEBPACK_IMPORTED_MODULE_4__.shareReplay)(1));
    this.dateTimeToCheck = luxon__WEBPACK_IMPORTED_MODULE_1__.DateTime.utc();
    this.prizePresent = false;
    this.subId = this.route.params.subscribe(params => {
      this.id = params.id;
      this.subCampaign = this.campaignService.myCampaigns$.subscribe(campaigns => {
        this.campaignContainer = campaigns.find(campaignContainer => campaignContainer.campaign.campaignId === this.id);
        this.campaignContainer.campaign.weekConfs.sort((a, b) => {
          const aDate = a?.dateFrom ?? 0;
          const bDate = b?.dateFrom ?? 0;
          return bDate - aDate;
        });
      });
    });
  }
  ngOnInit() {}
  ionViewWillEnter() {
    this.changePageSettings();
    let pastPrizes = this.pastprizes();
    this.actualPrize = this.getActualPrize();
    if (!pastPrizes && !this.prizePresent) {
      this.selectedSegment = 'finalPrizes';
      return;
    } else {
      this.selectedSegment = 'periodicPrizes';
    }
    if (!this.prizePresent) {
      this.notExpanded = false;
    }
    console.log('actualPrizes', this.actualPrize);
  }
  getFinalPrize() {
    if (!this.campaignContainer?.campaign?.weekConfs) {
      console.warn('WeekConfs not available');
      return null;
    }
    const playerGroupId = this.campaignContainer?.subscription?.campaignData?.groupId;
    let prize = this.campaignContainer.campaign.weekConfs.find(x => x.weekNumber === 0 && (!x.groupId || x.groupId === playerGroupId));
    if (prize && prize.rewards && prize.rewards.length > 0) {
      return prize;
    }
    return null;
  }
  getActualPrize() {
    if (!this.campaignContainer?.campaign?.weekConfs) {
      console.warn('WeekConfs not available');
      return null;
    }
    const playerGroupId = this.campaignContainer?.subscription?.campaignData?.groupId;
    let prize = this.campaignContainer.campaign.weekConfs.find(x => this.isThisPeriod(x.dateFrom, x.dateTo) && x.weekNumber !== 0 && (!x.groupId || x.groupId === playerGroupId));
    if (prize && prize.rewards && prize.rewards.length > 0) {
      this.prizePresent = true;
      return prize;
    }
    return null;
  }
  openWeekDescActual(finalPrize) {
    var _this = this;
    return (0,_Users_smartcommunitylab_Desktop_newWork_playAndGo_playGo_node_modules_babel_runtime_helpers_esm_asyncToGenerator_js__WEBPACK_IMPORTED_MODULE_0__["default"])(function* () {
      const titlePrize = yield (0,rxjs__WEBPACK_IMPORTED_MODULE_2__.firstValueFrom)(_this.translateService.get('campaigns.detail.prize.actualWeekTitle'));
      const modal = yield _this.modalController.create({
        component: _detail_modal_detail_modal__WEBPACK_IMPORTED_MODULE_7__.DetailPrizeModalPage,
        componentProps: {
          title: titlePrize,
          detail: finalPrize.desc
        },
        cssClass: 'challenge-info'
      });
      yield modal.present();
      const {
        data
      } = yield modal.onWillDismiss();
    })();
  }
  scrollTo(elementId) {
    let id = document.getElementById('subprizes');
    this.content.scrollToPoint(0, id?.offsetTop, 1000);
  }
  pastprizes() {
    const playerGroupId = this.campaignContainer?.subscription?.campaignData?.groupId;
    return this.campaignContainer.campaign?.weekConfs?.filter(x => luxon__WEBPACK_IMPORTED_MODULE_1__.DateTime.fromMillis(x.dateTo) < this.dateTimeToCheck && x?.rewards?.length > 0 && x.weekNumber !== 0 && (!x.groupId || x.groupId === playerGroupId));
  }
  isMyGroupPrize(conf) {
    const playerGroupId = this.campaignContainer?.subscription?.campaignData?.groupId;
    return !conf.groupId || conf.groupId === playerGroupId;
  }
  openWeekDescPast(confPrize) {
    var _this2 = this;
    return (0,_Users_smartcommunitylab_Desktop_newWork_playAndGo_playGo_node_modules_babel_runtime_helpers_esm_asyncToGenerator_js__WEBPACK_IMPORTED_MODULE_0__["default"])(function* () {
      const titlePrize = yield (0,rxjs__WEBPACK_IMPORTED_MODULE_2__.firstValueFrom)(_this2.translateService.get('campaigns.detail.prize.actualWeekTitle'));
      const modal = yield _this2.modalController.create({
        component: _detail_modal_detail_modal__WEBPACK_IMPORTED_MODULE_7__.DetailPrizeModalPage,
        componentProps: {
          title: titlePrize,
          detail: confPrize.desc
        },
        cssClass: 'challenge-info'
      });
      yield modal.present();
      const {
        data
      } = yield modal.onWillDismiss();
    })();
  }
  openRewardDescActual(actualPrize, index) {
    var _this3 = this;
    return (0,_Users_smartcommunitylab_Desktop_newWork_playAndGo_playGo_node_modules_babel_runtime_helpers_esm_asyncToGenerator_js__WEBPACK_IMPORTED_MODULE_0__["default"])(function* () {
      const titlePrize = yield (0,rxjs__WEBPACK_IMPORTED_MODULE_2__.firstValueFrom)(_this3.translateService.get('campaigns.detail.prize.periodicWeekTitle'));
      const modal = yield _this3.modalController.create({
        component: _detail_modal_detail_modal__WEBPACK_IMPORTED_MODULE_7__.DetailPrizeModalPage,
        componentProps: {
          title: titlePrize,
          detail: actualPrize.rewards?.[index]?.rewardNote ?? ''
        },
        cssClass: 'challenge-info'
      });
      yield modal.present();
      const {
        data
      } = yield modal.onWillDismiss();
    })();
  }
  openWeekDescFinal(actualPrize) {
    var _this4 = this;
    return (0,_Users_smartcommunitylab_Desktop_newWork_playAndGo_playGo_node_modules_babel_runtime_helpers_esm_asyncToGenerator_js__WEBPACK_IMPORTED_MODULE_0__["default"])(function* () {
      const titlePrize = yield (0,rxjs__WEBPACK_IMPORTED_MODULE_2__.firstValueFrom)(_this4.translateService.get('campaigns.detail.prize.finalWeekTitle'));
      const modal = yield _this4.modalController.create({
        component: _detail_modal_detail_modal__WEBPACK_IMPORTED_MODULE_7__.DetailPrizeModalPage,
        componentProps: {
          title: titlePrize,
          detail: actualPrize.desc
        },
        cssClass: 'challenge-info'
      });
      yield modal.present();
      const {
        data
      } = yield modal.onWillDismiss();
    })();
  }
  openRewardDescFinal(finalPrize, index) {
    var _this5 = this;
    return (0,_Users_smartcommunitylab_Desktop_newWork_playAndGo_playGo_node_modules_babel_runtime_helpers_esm_asyncToGenerator_js__WEBPACK_IMPORTED_MODULE_0__["default"])(function* () {
      const titlePrize = yield (0,rxjs__WEBPACK_IMPORTED_MODULE_2__.firstValueFrom)(_this5.translateService.get('campaigns.detail.prize.finalRewardTitle'));
      const modal = yield _this5.modalController.create({
        component: _detail_modal_detail_modal__WEBPACK_IMPORTED_MODULE_7__.DetailPrizeModalPage,
        componentProps: {
          title: titlePrize,
          detail: finalPrize?.rewards?.[index]?.rewardNote ?? ''
        },
        cssClass: 'challenge-info'
      });
      yield modal.present();
      const {
        data
      } = yield modal.onWillDismiss();
    })();
  }
  ngAfterViewInit() {
    // //change the behaviour of _blank arrived with editor, adding a new listener and opening a browser
    // this.anchors = this.elementRef.nativeElement.querySelectorAll('a');
    // this.anchors.forEach((anchor: HTMLAnchorElement) => {
    //   anchor.addEventListener('click', this.handleAnchorClick);
    // });
  }
  expandPrizes() {
    this.notExpanded = false;
    this.scrollTo('subprizes');
  }
  openLink(link) {
    _capacitor_browser__WEBPACK_IMPORTED_MODULE_6__.Browser.open({
      url: link,
      windowName: '_system',
      presentationStyle: 'popover'
    });
  }
  getPostion(arg0) {
    switch (arg0) {
      case 0:
        return 'gold';
      case 1:
        return 'silver';
      case 2:
        return 'bronze';
      default:
        return '';
    }
  }
  isThisPeriod(dateFrom, dateTo) {
    const interval = luxon__WEBPACK_IMPORTED_MODULE_1__.Interval.fromDateTimes(luxon__WEBPACK_IMPORTED_MODULE_1__.DateTime.fromMillis(dateFrom), luxon__WEBPACK_IMPORTED_MODULE_1__.DateTime.fromMillis(dateTo));
    return interval.contains(this.dateTimeToCheck);
  }
  changePageSettings() {
    this.pageSettingsService.set({
      color: this.campaignContainer?.campaign?.type
    });
  }
  ngOnDestroy() {
    this.subCampaign.unsubscribe();
    this.subId.unsubscribe();
  }
  openPrize() {
    var _this6 = this;
    return (0,_Users_smartcommunitylab_Desktop_newWork_playAndGo_playGo_node_modules_babel_runtime_helpers_esm_asyncToGenerator_js__WEBPACK_IMPORTED_MODULE_0__["default"])(function* () {
      const modal = yield _this6.modalController.create({
        component: _prize_modal_prize_modal__WEBPACK_IMPORTED_MODULE_5__.PrizeModalPage,
        cssClass: 'challenge-info'
      });
      yield modal.present();
      yield modal.onWillDismiss();
    })();
  }
  isBeforeNow(conf) {
    return luxon__WEBPACK_IMPORTED_MODULE_1__.DateTime.fromMillis(conf.dateTo) < this.dateTimeToCheck;
  }
  static #_ = _staticBlock = () => (this.ɵfac = function PrizesPage_Factory(__ngFactoryType__) {
    return new (__ngFactoryType__ || PrizesPage)(_angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵdirectiveInject"](_angular_router__WEBPACK_IMPORTED_MODULE_11__.ActivatedRoute), _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵdirectiveInject"](src_app_core_shared_services_page_settings_service__WEBPACK_IMPORTED_MODULE_12__.PageSettingsService), _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵdirectiveInject"](src_app_core_shared_services_campaign_service__WEBPACK_IMPORTED_MODULE_13__.CampaignService), _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵdirectiveInject"](_ionic_angular__WEBPACK_IMPORTED_MODULE_8__.ModalController), _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵdirectiveInject"](_ngx_translate_core__WEBPACK_IMPORTED_MODULE_14__.TranslateService));
  }, this.ɵcmp = /*@__PURE__*/_angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵdefineComponent"]({
    type: PrizesPage,
    selectors: [["app-stats"]],
    viewQuery: function PrizesPage_Query(rf, ctx) {
      if (rf & 1) {
        _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵviewQuery"](_ionic_angular__WEBPACK_IMPORTED_MODULE_8__.IonContent, 5);
      }
      if (rf & 2) {
        let _t;
        _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵqueryRefresh"](_t = _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵloadQuery"]()) && (ctx.content = _t.first);
      }
    },
    standalone: false,
    decls: 13,
    vars: 20,
    consts: [["noRewards", ""], ["expanded", ""], ["ordinaryNumber", ""], ["noFinal", ""], ["appHeader", ""], ["appContent", "", 3, "fullscreen"], ["mode", "md", "scrollable", "", 1, "app-segment", 3, "ngModelChange", "ngModel"], ["value", "periodicPrizes", "checked", "", "mode", "ios", 1, "app-segment-button"], ["value", "finalPrizes", "checked", "", "mode", "ios", 1, "app-segment-button"], [4, "ngIf"], [4, "ngIf", "ngIfElse"], [1, "actual-header"], ["name", "information-circle", 3, "click"], [4, "ngFor", "ngForOf"], [3, "ngClass"], ["name", "gift"], ["name", "information-circle", 1, "information", 3, "click"], [1, "ion-no-padding"], [1, "sponsor"], [3, "value"], [1, "desc"], [1, "ion-text-start"], ["class", "detail", 4, "ngIf"], [1, "detail"], [1, "ion-text-start", "sponsorby"], ["class", "ion-text-start", 4, "ngIf"], ["class", "ion-text-start", 3, "innerHTML", 4, "ngIf"], ["class", "ion-text-end website", 3, "click", 4, "ngIf"], [1, "ion-text-start", 3, "innerHTML"], [1, "ion-text-end", "website", 3, "click"], ["id", "subprizes", "class", "ion-margin", "expand", "block", 3, "color", "click", 4, "ngIf", "ngIfElse"], ["id", "subprizes", "expand", "block", 1, "ion-margin", 3, "click", "color"], [1, "no-prizes"], [1, "sub-header"], [1, "date-prize"], ["class", "on-going", 4, "ngIf"], [1, "on-going"], ["slot", "header"], [1, "ion-no-padding", "container"], ["size", "2"], ["name", "gift", 3, "ngClass"], [3, "value", "ngClass"], [1, "prize"], ["class", "ion-padding sponsor", "slot", "content", 4, "ngIf"], ["slot", "content", 1, "ion-padding", "sponsor"], [1, "detail", "ion-padding"], [1, "final-header"]],
    template: function PrizesPage_Template(rf, ctx) {
      if (rf & 1) {
        _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵelement"](0, "ion-header", 4);
        _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵelementStart"](1, "ion-content", 5)(2, "ion-segment", 6);
        _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵtwoWayListener"]("ngModelChange", function PrizesPage_Template_ion_segment_ngModelChange_2_listener($event) {
          _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵtwoWayBindingSet"](ctx.selectedSegment, $event) || (ctx.selectedSegment = $event);
          return $event;
        });
        _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵelementStart"](3, "ion-segment-button", 7)(4, "ion-label");
        _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵtext"](5);
        _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵpipe"](6, "translate");
        _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵelementEnd"]()();
        _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵelementStart"](7, "ion-segment-button", 8)(8, "ion-label");
        _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵtext"](9);
        _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵpipe"](10, "translate");
        _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵelementEnd"]()()();
        _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵtemplate"](11, PrizesPage_div_11_Template, 7, 3, "div", 9)(12, PrizesPage_div_12_Template, 4, 2, "div", 9);
        _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵelementEnd"]();
      }
      if (rf & 2) {
        _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵadvance"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵproperty"]("fullscreen", true);
        _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵadvance"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵstyleProp"]("--background", "var(--ion-color-" + ctx.campaignContainer.campaign.type + ")");
        _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵtwoWayProperty"]("ngModel", ctx.selectedSegment);
        _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵadvance"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵstyleProp"]("--color", "var(--ion-color-" + ctx.campaignContainer.campaign.type + "-contrast)")("--color-checked", "black");
        _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵadvance"](2);
        _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵtextInterpolate"](_angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵpipeBind1"](6, 16, "campaigns.detail.prize.periodic"));
        _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵadvance"](2);
        _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵstyleProp"]("--color", "var(--ion-color-" + ctx.campaignContainer.campaign.type + "-contrast)")("--color-checked", "black");
        _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵadvance"](2);
        _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵtextInterpolate"](_angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵpipeBind1"](10, 18, "campaigns.detail.prize.final"));
        _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵadvance"](2);
        _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵproperty"]("ngIf", ctx.selectedSegment === "periodicPrizes");
        _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵadvance"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵproperty"]("ngIf", ctx.selectedSegment === "finalPrizes");
      }
    },
    dependencies: [_angular_common__WEBPACK_IMPORTED_MODULE_15__.NgClass, _angular_common__WEBPACK_IMPORTED_MODULE_15__.NgForOf, _angular_common__WEBPACK_IMPORTED_MODULE_15__.NgIf, _angular_forms__WEBPACK_IMPORTED_MODULE_16__.NgControlStatus, _angular_forms__WEBPACK_IMPORTED_MODULE_16__.NgModel, _ionic_angular__WEBPACK_IMPORTED_MODULE_8__.IonAccordion, _ionic_angular__WEBPACK_IMPORTED_MODULE_8__.IonAccordionGroup, _ionic_angular__WEBPACK_IMPORTED_MODULE_8__.IonButton, _ionic_angular__WEBPACK_IMPORTED_MODULE_8__.IonCard, _ionic_angular__WEBPACK_IMPORTED_MODULE_8__.IonCardContent, _ionic_angular__WEBPACK_IMPORTED_MODULE_8__.IonCardHeader, _ionic_angular__WEBPACK_IMPORTED_MODULE_8__.IonCardTitle, _ionic_angular__WEBPACK_IMPORTED_MODULE_8__.IonCol, _ionic_angular__WEBPACK_IMPORTED_MODULE_8__.IonContent, _ionic_angular__WEBPACK_IMPORTED_MODULE_8__.IonGrid, _ionic_angular__WEBPACK_IMPORTED_MODULE_8__.IonHeader, _ionic_angular__WEBPACK_IMPORTED_MODULE_8__.IonIcon, _ionic_angular__WEBPACK_IMPORTED_MODULE_8__.IonItem, _ionic_angular__WEBPACK_IMPORTED_MODULE_8__.IonLabel, _ionic_angular__WEBPACK_IMPORTED_MODULE_8__.IonRow, _ionic_angular__WEBPACK_IMPORTED_MODULE_8__.IonSegment, _ionic_angular__WEBPACK_IMPORTED_MODULE_8__.IonSegmentButton, _ionic_angular__WEBPACK_IMPORTED_MODULE_8__.SelectValueAccessor, _core_shared_layout_header_header_directive__WEBPACK_IMPORTED_MODULE_17__.HeaderDirective, _core_shared_layout_content_content_directive__WEBPACK_IMPORTED_MODULE_18__.ContentDirective, _core_shared_globalization_ordinal_number_ordinal_number_component__WEBPACK_IMPORTED_MODULE_19__.OrdinalNumberComponent, _angular_common__WEBPACK_IMPORTED_MODULE_15__.UpperCasePipe, _ngx_translate_core__WEBPACK_IMPORTED_MODULE_14__.TranslatePipe, _core_shared_pipes_localDate_pipe__WEBPACK_IMPORTED_MODULE_20__.LocalDatePipe, _core_shared_pipes_languageMap_pipe__WEBPACK_IMPORTED_MODULE_21__.LanguageMapPipe],
    styles: ["ion-card-title[_ngcontent-%COMP%] {\n  font-size: 16px;\n  font-weight: 300;\n  display: flex;\n  justify-content: space-between;\n}\n\nion-card[_ngcontent-%COMP%] {\n  color: black;\n}\n\nion-card-content[_ngcontent-%COMP%]   .prize[_ngcontent-%COMP%] {\n  font-weight: 700;\n}\nion-card-content[_ngcontent-%COMP%]   .info-prize[_ngcontent-%COMP%] {\n  display: flex;\n  align-items: center;\n  justify-content: flex-end;\n}\nion-card-content[_ngcontent-%COMP%]   .info-prize[_ngcontent-%COMP%]   ion-icon[_ngcontent-%COMP%] {\n  font-size: 22px;\n  margin: 6px;\n}\nion-card-content[_ngcontent-%COMP%]   ion-grid[_ngcontent-%COMP%]   ion-row[_ngcontent-%COMP%]   ion-col[_ngcontent-%COMP%] {\n  display: flex;\n  justify-content: center;\n  flex-direction: column;\n}\nion-card-content[_ngcontent-%COMP%]   ion-grid[_ngcontent-%COMP%]   ion-row[_ngcontent-%COMP%]   ion-col[_ngcontent-%COMP%]   ion-icon[_ngcontent-%COMP%] {\n  margin: auto;\n  font-size: 30px;\n}\nion-card-content[_ngcontent-%COMP%]   ion-grid[_ngcontent-%COMP%]   ion-row[_ngcontent-%COMP%]   ion-col[_ngcontent-%COMP%]:first-child {\n  text-align: center;\n}\n\n.gold[_ngcontent-%COMP%] {\n  background-color: gold;\n}\n\n.silver[_ngcontent-%COMP%] {\n  background-color: silver;\n}\n\n.bronze[_ngcontent-%COMP%] {\n  background-color: chocolate;\n  color: white;\n}\n\n.packet-gold[_ngcontent-%COMP%] {\n  color: gold;\n}\n\n.packet-silver[_ngcontent-%COMP%] {\n  color: silver;\n}\n\n.packet-bronze[_ngcontent-%COMP%] {\n  color: chocolate;\n}\n\n.active[_ngcontent-%COMP%] {\n  background-color: gold;\n}\n\n.not-active[_ngcontent-%COMP%] {\n  background-color: silver;\n}\n\n.on-going[_ngcontent-%COMP%] {\n  font-style: italic;\n}\n\nion-card-header[_ngcontent-%COMP%] {\n  border-bottom: 1px solid #e0e0e0;\n}\n\n.final-header[_ngcontent-%COMP%] {\n  text-align: center;\n  height: 70px;\n  display: flex;\n  justify-content: center;\n  margin-bottom: -20px;\n}\n.final-header[_ngcontent-%COMP%]   span[_ngcontent-%COMP%] {\n  font-size: 18px;\n  font-weight: bold;\n  display: flex;\n  justify-content: center;\n  align-items: center;\n}\n.final-header[_ngcontent-%COMP%]   span[_ngcontent-%COMP%]   ion-icon[_ngcontent-%COMP%] {\n  color: rgba(0, 0, 0, 0.2588235294);\n  margin-left: 8px;\n}\n\n.actual-header[_ngcontent-%COMP%] {\n  text-align: center;\n  height: 70px;\n  justify-content: center;\n}\n.actual-header[_ngcontent-%COMP%]   p[_ngcontent-%COMP%] {\n  font-size: 20px;\n  display: flex;\n  justify-content: center;\n  align-items: center;\n}\n.actual-header[_ngcontent-%COMP%]   p[_ngcontent-%COMP%]   ion-icon[_ngcontent-%COMP%] {\n  color: rgba(0, 0, 0, 0.2588235294);\n  margin-left: 8px;\n}\n\n.sub-header[_ngcontent-%COMP%] {\n  text-align: center;\n  justify-content: center;\n  padding: 8px;\n}\n.sub-header[_ngcontent-%COMP%]   p[_ngcontent-%COMP%] {\n  font-size: 20px;\n  display: flex;\n  justify-content: center;\n  align-items: center;\n}\n.sub-header[_ngcontent-%COMP%]   p[_ngcontent-%COMP%]   ion-icon[_ngcontent-%COMP%] {\n  color: rgba(0, 0, 0, 0.2588235294);\n  margin-left: 8px;\n}\n\n.information[_ngcontent-%COMP%] {\n  opacity: 50%;\n}\n\n.date-prize[_ngcontent-%COMP%] {\n  font-weight: 300;\n}\n\n.sponsor[_ngcontent-%COMP%]   .desc[_ngcontent-%COMP%] {\n  font-size: 17px;\n}\n.sponsor[_ngcontent-%COMP%]   .detail[_ngcontent-%COMP%] {\n  background-color: rgba(182, 182, 182, 0.1019607843);\n  color: #666666;\n}\n.sponsor[_ngcontent-%COMP%]   .detail[_ngcontent-%COMP%]   .sponsorby[_ngcontent-%COMP%] {\n  color: rgba(0, 0, 0, 0.1490196078);\n}\n.sponsor[_ngcontent-%COMP%]   .detail[_ngcontent-%COMP%]   .website[_ngcontent-%COMP%] {\n  color: #ecd56c;\n  text-decoration: underline;\n}\n\n.no-prizes[_ngcontent-%COMP%] {\n  text-align: center;\n  margin: 40px;\n  font-weight: 700;\n}\n\nion-accordion-group[_ngcontent-%COMP%]   ion-accordion[_ngcontent-%COMP%]   .container[_ngcontent-%COMP%] {\n  width: 100%;\n}\n/*# sourceMappingURL=data:application/json;charset=utf-8;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbIndlYnBhY2s6Ly8uL3NyYy9hcHAvcGFnZXMvaG9tZS9jYW1wYWlnbi1kZXRhaWxzL3ByaXplcy9wcml6ZXMucGFnZS5zY3NzIl0sIm5hbWVzIjpbXSwibWFwcGluZ3MiOiJBQUFBO0VBQ0UsZUFBQTtFQUNBLGdCQUFBO0VBQ0EsYUFBQTtFQUNBLDhCQUFBO0FBQ0Y7O0FBQ0E7RUFDRSxZQUFBO0FBRUY7O0FBQ0U7RUFDRSxnQkFBQTtBQUVKO0FBQUU7RUFDRSxhQUFBO0VBQ0EsbUJBQUE7RUFDQSx5QkFBQTtBQUVKO0FBREk7RUFDRSxlQUFBO0VBQ0EsV0FBQTtBQUdOO0FBRU07RUFDRSxhQUFBO0VBQ0EsdUJBQUE7RUFDQSxzQkFBQTtBQUFSO0FBQ1E7RUFDRSxZQUFBO0VBQ0EsZUFBQTtBQUNWO0FBRU07RUFDRSxrQkFBQTtBQUFSOztBQU1BO0VBQ0Usc0JBQUE7QUFIRjs7QUFLQTtFQUNFLHdCQUFBO0FBRkY7O0FBSUE7RUFDRSwyQkFBQTtFQUNBLFlBQUE7QUFERjs7QUFHQTtFQUNFLFdBQUE7QUFBRjs7QUFFQTtFQUNFLGFBQUE7QUFDRjs7QUFDQTtFQUNFLGdCQUFBO0FBRUY7O0FBQUE7RUFDRSxzQkFBQTtBQUdGOztBQURBO0VBQ0Usd0JBQUE7QUFJRjs7QUFGQTtFQUNFLGtCQUFBO0FBS0Y7O0FBSEE7RUFDRSxnQ0FBQTtBQU1GOztBQUpBO0VBQ0Usa0JBQUE7RUFDQSxZQUFBO0VBQ0EsYUFBQTtFQUNBLHVCQUFBO0VBQ0Esb0JBQUE7QUFPRjtBQU5FO0VBQ0UsZUFBQTtFQUNBLGlCQUFBO0VBQ0EsYUFBQTtFQUNBLHVCQUFBO0VBQ0EsbUJBQUE7QUFRSjtBQVBJO0VBQ0Usa0NBQUE7RUFDQSxnQkFBQTtBQVNOOztBQUxBO0VBQ0Usa0JBQUE7RUFDQSxZQUFBO0VBQ0EsdUJBQUE7QUFRRjtBQVBFO0VBQ0UsZUFBQTtFQUNBLGFBQUE7RUFDQSx1QkFBQTtFQUNBLG1CQUFBO0FBU0o7QUFSSTtFQUNFLGtDQUFBO0VBQ0EsZ0JBQUE7QUFVTjs7QUFOQTtFQUNFLGtCQUFBO0VBQ0EsdUJBQUE7RUFDQSxZQUFBO0FBU0Y7QUFSRTtFQUNFLGVBQUE7RUFDQSxhQUFBO0VBQ0EsdUJBQUE7RUFDQSxtQkFBQTtBQVVKO0FBVEk7RUFDRSxrQ0FBQTtFQUNBLGdCQUFBO0FBV047O0FBUEE7RUFDRSxZQUFBO0FBVUY7O0FBUkE7RUFDRSxnQkFBQTtBQVdGOztBQVJFO0VBQ0UsZUFBQTtBQVdKO0FBVEU7RUFDRSxtREFBQTtFQUNBLGNBQUE7QUFXSjtBQVZJO0VBQ0Usa0NBQUE7QUFZTjtBQVZJO0VBQ0UsY0FBQTtFQUNBLDBCQUFBO0FBWU47O0FBUkE7RUFDRSxrQkFBQTtFQUNBLFlBQUE7RUFDQSxnQkFBQTtBQVdGOztBQVBJO0VBQ0UsV0FBQTtBQVVOIiwic291cmNlc0NvbnRlbnQiOlsiaW9uLWNhcmQtdGl0bGUge1xuICBmb250LXNpemU6IDE2cHg7XG4gIGZvbnQtd2VpZ2h0OiAzMDA7XG4gIGRpc3BsYXk6IGZsZXg7XG4gIGp1c3RpZnktY29udGVudDogc3BhY2UtYmV0d2Vlbjtcbn1cbmlvbi1jYXJkIHtcbiAgY29sb3I6IGJsYWNrO1xufVxuaW9uLWNhcmQtY29udGVudCB7XG4gIC5wcml6ZSB7XG4gICAgZm9udC13ZWlnaHQ6IDcwMDtcbiAgfVxuICAuaW5mby1wcml6ZSB7XG4gICAgZGlzcGxheTogZmxleDtcbiAgICBhbGlnbi1pdGVtczogY2VudGVyO1xuICAgIGp1c3RpZnktY29udGVudDogZmxleC1lbmQ7XG4gICAgaW9uLWljb24ge1xuICAgICAgZm9udC1zaXplOiAyMnB4O1xuICAgICAgbWFyZ2luOiA2cHg7XG4gICAgfVxuICB9XG4gIGlvbi1ncmlkIHtcbiAgICBpb24tcm93IHtcbiAgICAgIGlvbi1jb2wge1xuICAgICAgICBkaXNwbGF5OiBmbGV4O1xuICAgICAgICBqdXN0aWZ5LWNvbnRlbnQ6IGNlbnRlcjtcbiAgICAgICAgZmxleC1kaXJlY3Rpb246IGNvbHVtbjtcbiAgICAgICAgaW9uLWljb24ge1xuICAgICAgICAgIG1hcmdpbjogYXV0bztcbiAgICAgICAgICBmb250LXNpemU6IDMwcHg7XG4gICAgICAgIH1cbiAgICAgIH1cbiAgICAgIGlvbi1jb2w6Zmlyc3QtY2hpbGQge1xuICAgICAgICB0ZXh0LWFsaWduOiBjZW50ZXI7XG4gICAgICB9XG4gICAgfVxuICB9XG59XG5cbi5nb2xkIHtcbiAgYmFja2dyb3VuZC1jb2xvcjogZ29sZDtcbn1cbi5zaWx2ZXIge1xuICBiYWNrZ3JvdW5kLWNvbG9yOiBzaWx2ZXI7XG59XG4uYnJvbnplIHtcbiAgYmFja2dyb3VuZC1jb2xvcjogY2hvY29sYXRlO1xuICBjb2xvcjogd2hpdGU7XG59XG4ucGFja2V0LWdvbGQge1xuICBjb2xvcjogZ29sZDtcbn1cbi5wYWNrZXQtc2lsdmVyIHtcbiAgY29sb3I6IHNpbHZlcjtcbn1cbi5wYWNrZXQtYnJvbnplIHtcbiAgY29sb3I6IGNob2NvbGF0ZTtcbn1cbi5hY3RpdmUge1xuICBiYWNrZ3JvdW5kLWNvbG9yOiBnb2xkO1xufVxuLm5vdC1hY3RpdmUge1xuICBiYWNrZ3JvdW5kLWNvbG9yOiBzaWx2ZXI7XG59XG4ub24tZ29pbmcge1xuICBmb250LXN0eWxlOiBpdGFsaWM7XG59XG5pb24tY2FyZC1oZWFkZXIge1xuICBib3JkZXItYm90dG9tOiAxcHggc29saWQgI2UwZTBlMDtcbn1cbi5maW5hbC1oZWFkZXIge1xuICB0ZXh0LWFsaWduOiBjZW50ZXI7XG4gIGhlaWdodDogNzBweDtcbiAgZGlzcGxheTogZmxleDtcbiAganVzdGlmeS1jb250ZW50OiBjZW50ZXI7XG4gIG1hcmdpbi1ib3R0b206IC0yMHB4O1xuICBzcGFuIHtcbiAgICBmb250LXNpemU6IDE4cHg7XG4gICAgZm9udC13ZWlnaHQ6IGJvbGQ7XG4gICAgZGlzcGxheTogZmxleDtcbiAgICBqdXN0aWZ5LWNvbnRlbnQ6IGNlbnRlcjtcbiAgICBhbGlnbi1pdGVtczogY2VudGVyO1xuICAgIGlvbi1pY29uIHtcbiAgICAgIGNvbG9yOiAjMDAwMDAwNDI7XG4gICAgICBtYXJnaW4tbGVmdDogOHB4O1xuICAgIH1cbiAgfVxufVxuLmFjdHVhbC1oZWFkZXIge1xuICB0ZXh0LWFsaWduOiBjZW50ZXI7XG4gIGhlaWdodDogNzBweDtcbiAganVzdGlmeS1jb250ZW50OiBjZW50ZXI7XG4gIHAge1xuICAgIGZvbnQtc2l6ZTogMjBweDtcbiAgICBkaXNwbGF5OiBmbGV4O1xuICAgIGp1c3RpZnktY29udGVudDogY2VudGVyO1xuICAgIGFsaWduLWl0ZW1zOiBjZW50ZXI7XG4gICAgaW9uLWljb24ge1xuICAgICAgY29sb3I6ICMwMDAwMDA0MjtcbiAgICAgIG1hcmdpbi1sZWZ0OiA4cHg7XG4gICAgfVxuICB9XG59XG4uc3ViLWhlYWRlciB7XG4gIHRleHQtYWxpZ246IGNlbnRlcjtcbiAganVzdGlmeS1jb250ZW50OiBjZW50ZXI7XG4gIHBhZGRpbmc6IDhweDtcbiAgcCB7XG4gICAgZm9udC1zaXplOiAyMHB4O1xuICAgIGRpc3BsYXk6IGZsZXg7XG4gICAganVzdGlmeS1jb250ZW50OiBjZW50ZXI7XG4gICAgYWxpZ24taXRlbXM6IGNlbnRlcjtcbiAgICBpb24taWNvbiB7XG4gICAgICBjb2xvcjogIzAwMDAwMDQyO1xuICAgICAgbWFyZ2luLWxlZnQ6IDhweDtcbiAgICB9XG4gIH1cbn1cbi5pbmZvcm1hdGlvbiB7XG4gIG9wYWNpdHk6IDUwJTtcbn1cbi5kYXRlLXByaXplIHtcbiAgZm9udC13ZWlnaHQ6IDMwMDtcbn1cbi5zcG9uc29yIHtcbiAgLmRlc2Mge1xuICAgIGZvbnQtc2l6ZTogMTdweDtcbiAgfVxuICAuZGV0YWlsIHtcbiAgICBiYWNrZ3JvdW5kLWNvbG9yOiAjYjZiNmI2MWE7XG4gICAgY29sb3I6ICM2NjY2NjY7XG4gICAgLnNwb25zb3JieSB7XG4gICAgICBjb2xvcjogIzAwMDAwMDI2O1xuICAgIH1cbiAgICAud2Vic2l0ZSB7XG4gICAgICBjb2xvcjogI2VjZDU2YztcbiAgICAgIHRleHQtZGVjb3JhdGlvbjogdW5kZXJsaW5lO1xuICAgIH1cbiAgfVxufVxuLm5vLXByaXplcyB7XG4gIHRleHQtYWxpZ246IGNlbnRlcjtcbiAgbWFyZ2luOiA0MHB4O1xuICBmb250LXdlaWdodDogNzAwO1xufVxuaW9uLWFjY29yZGlvbi1ncm91cCB7XG4gIGlvbi1hY2NvcmRpb24ge1xuICAgIC5jb250YWluZXIge1xuICAgICAgd2lkdGg6IDEwMCU7XG4gICAgfVxuICB9XG59XG4iXSwic291cmNlUm9vdCI6IiJ9 */"]
  }));
}
_staticBlock();

/***/ }),

/***/ 96160:
/*!*********************************************************************!*\
  !*** ./src/app/pages/home/campaign-details/prizes/prizes.module.ts ***!
  \*********************************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   PrizesPageModule: () => (/* binding */ PrizesPageModule)
/* harmony export */ });
/* harmony import */ var _prizes_routing_module__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./prizes-routing.module */ 74921);
/* harmony import */ var _prizes_page__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ./prizes.page */ 85403);
/* harmony import */ var src_app_core_shared_shared_module__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! src/app/core/shared/shared.module */ 62657);
/* harmony import */ var src_app_core_shared_pipes_localDate_pipe__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! src/app/core/shared/pipes/localDate.pipe */ 86451);
/* harmony import */ var _prize_modal_prize_modal__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! ./prize-modal/prize.modal */ 98769);
/* harmony import */ var _detail_modal_detail_modal__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! ./detail-modal/detail.modal */ 9865);
/* harmony import */ var _ionic_angular__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! @ionic/angular */ 21507);
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(/*! @angular/core */ 34205);
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(/*! @angular/core */ 12481);
var _staticBlock;








class PrizesPageModule {
  static #_ = _staticBlock = () => (this.ɵfac = function PrizesPageModule_Factory(__ngFactoryType__) {
    return new (__ngFactoryType__ || PrizesPageModule)();
  }, this.ɵmod = /*@__PURE__*/_angular_core__WEBPACK_IMPORTED_MODULE_8__["ɵɵdefineNgModule"]({
    type: PrizesPageModule
  }), this.ɵinj = /*@__PURE__*/_angular_core__WEBPACK_IMPORTED_MODULE_7__["ɵɵdefineInjector"]({
    providers: [src_app_core_shared_pipes_localDate_pipe__WEBPACK_IMPORTED_MODULE_3__.LocalDatePipe],
    imports: [src_app_core_shared_shared_module__WEBPACK_IMPORTED_MODULE_2__.PlayGoSharedModule, _prizes_routing_module__WEBPACK_IMPORTED_MODULE_0__.PrizesPageRoutingModule, _ionic_angular__WEBPACK_IMPORTED_MODULE_6__.IonicModule]
  }));
}
_staticBlock();
(function () {
  (typeof ngJitMode === "undefined" || ngJitMode) && _angular_core__WEBPACK_IMPORTED_MODULE_8__["ɵɵsetNgModuleScope"](PrizesPageModule, {
    declarations: [_prizes_page__WEBPACK_IMPORTED_MODULE_1__.PrizesPage, _prize_modal_prize_modal__WEBPACK_IMPORTED_MODULE_4__.PrizeModalPage, _detail_modal_detail_modal__WEBPACK_IMPORTED_MODULE_5__.DetailPrizeModalPage],
    imports: [src_app_core_shared_shared_module__WEBPACK_IMPORTED_MODULE_2__.PlayGoSharedModule, _prizes_routing_module__WEBPACK_IMPORTED_MODULE_0__.PrizesPageRoutingModule, _ionic_angular__WEBPACK_IMPORTED_MODULE_6__.IonicModule]
  });
})();

/***/ }),

/***/ 98769:
/*!*******************************************************************************!*\
  !*** ./src/app/pages/home/campaign-details/prizes/prize-modal/prize.modal.ts ***!
  \*******************************************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   PrizeModalPage: () => (/* binding */ PrizeModalPage)
/* harmony export */ });
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! @angular/core */ 12481);
/* harmony import */ var _ionic_angular__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @ionic/angular */ 21507);
/* harmony import */ var _ngx_translate_core__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @ngx-translate/core */ 48503);
var _staticBlock;



class PrizeModalPage {
  constructor(modalController) {
    this.modalController = modalController;
  }
  ngOnInit() {}
  close() {
    this.modalController.dismiss(false);
  }
  static #_ = _staticBlock = () => (this.ɵfac = function PrizeModalPage_Factory(__ngFactoryType__) {
    return new (__ngFactoryType__ || PrizeModalPage)(_angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵdirectiveInject"](_ionic_angular__WEBPACK_IMPORTED_MODULE_1__.ModalController));
  }, this.ɵcmp = /*@__PURE__*/_angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵdefineComponent"]({
    type: PrizeModalPage,
    selectors: [["app-prize-modal"]],
    standalone: false,
    decls: 15,
    vars: 9,
    consts: [["color", "playgo"], ["slot", "end"], [3, "click"], ["name", "close-circle-outline"], ["color", "playgo", 1, "ion-padding"], [3, "innerHTML"], ["color", "playgo", 1, "ion-text-center"], ["expand", "block", "color", "light", 3, "click"]],
    template: function PrizeModalPage_Template(rf, ctx) {
      if (rf & 1) {
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](0, "ion-header")(1, "ion-toolbar", 0)(2, "ion-title");
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵtext"](3);
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵpipe"](4, "translate");
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](5, "ion-buttons", 1)(6, "ion-button", 2);
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵlistener"]("click", function PrizeModalPage_Template_ion_button_click_6_listener() {
          return ctx.close();
        });
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelement"](7, "ion-icon", 3);
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]()()()();
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](8, "ion-content", 4);
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelement"](9, "div", 5);
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵpipe"](10, "translate");
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](11, "ion-footer", 6)(12, "ion-button", 7);
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵlistener"]("click", function PrizeModalPage_Template_ion_button_click_12_listener() {
          return ctx.close();
        });
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵtext"](13);
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵpipe"](14, "translate");
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]()();
      }
      if (rf & 2) {
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵadvance"](3);
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵtextInterpolate"](_angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵpipeBind1"](4, 3, "campaigns.detail.prize.title"));
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵadvance"](6);
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵproperty"]("innerHTML", _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵpipeBind1"](10, 5, "campaigns.detail.prize.desc"), _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵsanitizeHtml"]);
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵadvance"](4);
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵtextInterpolate"](_angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵpipeBind1"](14, 7, "modal.ok"));
      }
    },
    dependencies: [_ionic_angular__WEBPACK_IMPORTED_MODULE_1__.IonButton, _ionic_angular__WEBPACK_IMPORTED_MODULE_1__.IonButtons, _ionic_angular__WEBPACK_IMPORTED_MODULE_1__.IonContent, _ionic_angular__WEBPACK_IMPORTED_MODULE_1__.IonFooter, _ionic_angular__WEBPACK_IMPORTED_MODULE_1__.IonHeader, _ionic_angular__WEBPACK_IMPORTED_MODULE_1__.IonIcon, _ionic_angular__WEBPACK_IMPORTED_MODULE_1__.IonTitle, _ionic_angular__WEBPACK_IMPORTED_MODULE_1__.IonToolbar, _ngx_translate_core__WEBPACK_IMPORTED_MODULE_2__.TranslatePipe],
    styles: ["ion-footer[_ngcontent-%COMP%] {\n  background: var(--ion-color-playgo);\n}\n/*# sourceMappingURL=data:application/json;charset=utf-8;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbIndlYnBhY2s6Ly8uL3NyYy9hcHAvcGFnZXMvaG9tZS9jYW1wYWlnbi1kZXRhaWxzL3ByaXplcy9wcml6ZS1tb2RhbC9wcml6ZS5tb2RhbC5zY3NzIl0sIm5hbWVzIjpbXSwibWFwcGluZ3MiOiJBQUFBO0VBQ0UsbUNBQUE7QUFDRiIsInNvdXJjZXNDb250ZW50IjpbImlvbi1mb290ZXIge1xuICBiYWNrZ3JvdW5kOiB2YXIoLS1pb24tY29sb3ItcGxheWdvKTtcbn1cbiJdLCJzb3VyY2VSb290IjoiIn0= */"]
  }));
}
_staticBlock();

/***/ })

}]);
//# sourceMappingURL=src_app_pages_home_campaign-details_prizes_prizes_module_ts.js.map