"use strict";
(self["webpackChunkapp"] = self["webpackChunkapp"] || []).push([["src_app_pages_pages-routing_module_ts"],{

/***/ 9390:
/*!***********************************************!*\
  !*** ./src/app/pages/pages-routing.module.ts ***!
  \***********************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   PagesRoutingModule: () => (/* binding */ PagesRoutingModule)
/* harmony export */ });
/* harmony import */ var _angular_router__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! @angular/router */ 34487);
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @angular/core */ 34205);
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @angular/core */ 12481);
var _staticBlock;



class PagesRoutingModule {
  static #_ = _staticBlock = () => (this.ɵfac = function PagesRoutingModule_Factory(__ngFactoryType__) {
    return new (__ngFactoryType__ || PagesRoutingModule)();
  }, this.ɵmod = /*@__PURE__*/_angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵdefineNgModule"]({
    type: PagesRoutingModule
  }), this.ɵinj = /*@__PURE__*/_angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵdefineInjector"]({
    imports: [_angular_router__WEBPACK_IMPORTED_MODULE_0__.RouterModule.forChild([{
      path: '',
      loadChildren: () => __webpack_require__.e(/*! import() */ "src_app_pages_tabs-container_tabs_module_ts").then(__webpack_require__.bind(__webpack_require__, /*! ./tabs-container/tabs.module */ 53194)).then(m => m.TabsPageModule)
    }, {
      path: 'registration',
      loadChildren: () => Promise.all(/*! import() */[__webpack_require__.e("common"), __webpack_require__.e("src_app_pages_registration_registration_module_ts")]).then(__webpack_require__.bind(__webpack_require__, /*! ./registration/registration.module */ 35066)).then(m => m.RegistrationPageModule)
    }, {
      path: 'notifications',
      loadChildren: () => __webpack_require__.e(/*! import() */ "src_app_pages_notifications_notifications_module_ts").then(__webpack_require__.bind(__webpack_require__, /*! ./notifications/notifications.module */ 95746)).then(m => m.NotificationsPageModule)
    }, {
      path: 'blacklist/:id',
      loadChildren: () => __webpack_require__.e(/*! import() */ "src_app_pages_blacklist_blacklist_module_ts").then(__webpack_require__.bind(__webpack_require__, /*! ./blacklist/blacklist.module */ 33726)).then(m => m.BlacklistPageModule)
    }, {
      path: 'user-profile/:id/:nickname',
      loadChildren: () => Promise.all(/*! import() */[__webpack_require__.e("common"), __webpack_require__.e("src_app_pages_user-profile_user-profile_module_ts")]).then(__webpack_require__.bind(__webpack_require__, /*! ./user-profile/user-profile.module */ 83606)).then(m => m.UserProfilePageModule)
    }, {
      path: 'team-profile/:initiativeId/:teamId/:type',
      loadChildren: () => __webpack_require__.e(/*! import() */ "src_app_pages_team-profile_team-profile_module_ts").then(__webpack_require__.bind(__webpack_require__, /*! ./team-profile/team-profile.module */ 31102)).then(m => m.TeamProfilePageModule)
    }])]
  }));
}
_staticBlock();
(function () {
  (typeof ngJitMode === "undefined" || ngJitMode) && _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵsetNgModuleScope"](PagesRoutingModule, {
    imports: [_angular_router__WEBPACK_IMPORTED_MODULE_0__.RouterModule]
  });
})();

/***/ })

}]);
//# sourceMappingURL=src_app_pages_pages-routing_module_ts.js.map