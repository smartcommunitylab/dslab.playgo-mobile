"use strict";
(self["webpackChunkapp"] = self["webpackChunkapp"] || []).push([["src_app_pages_home_campaign-details_school-leaderboard_school-leaderboard_module_ts"],{

/***/ 22208:
/*!*************************************************************************************************************************!*\
  !*** ./src/app/pages/home/campaign-details/school-leaderboard/school-placing-detail/school-placing-detail.component.ts ***!
  \*************************************************************************************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   SchoolPlacingDetailComponent: () => (/* binding */ SchoolPlacingDetailComponent)
/* harmony export */ });
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! @angular/core */ 12481);
/* harmony import */ var src_app_core_shared_services_user_service__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! src/app/core/shared/services/user.service */ 89815);
/* harmony import */ var src_app_core_shared_services_team_service__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! src/app/core/shared/services/team.service */ 62625);
/* harmony import */ var _angular_router__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @angular/router */ 34487);
/* harmony import */ var _angular_common__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! @angular/common */ 93683);
/* harmony import */ var _ionic_angular__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! @ionic/angular */ 21507);
/* harmony import */ var _core_shared_globalization_ordinal_number_ordinal_number_component__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! ../../../../../core/shared/globalization/ordinal-number/ordinal-number.component */ 6972);
/* harmony import */ var _core_shared_ui_icon_icon_component__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(/*! ../../../../../core/shared/ui/icon/icon.component */ 59621);
/* harmony import */ var _core_shared_pipes_localNumber_pipe__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(/*! ../../../../../core/shared/pipes/localNumber.pipe */ 16024);
var _staticBlock;









const _c0 = a0 => ({
  border: a0
});
const _c1 = a0 => [a0];
function SchoolPlacingDetailComponent_ion_item_0_ng_container_5_ion_avatar_2_Template(rf, ctx) {
  if (rf & 1) {
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](0, "ion-avatar");
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelement"](1, "img", 12);
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();
  }
  if (rf & 2) {
    const ctx_r0 = _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵnextContext"](3);
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵadvance"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵproperty"]("src", ctx_r0.myTeam == null ? null : ctx_r0.myTeam.avatar == null ? null : ctx_r0.myTeam.avatar.url, _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵsanitizeUrl"]);
  }
}
function SchoolPlacingDetailComponent_ion_item_0_ng_container_5_ng_template_3_Template(rf, ctx) {
  if (rf & 1) {
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](0, "ion-avatar");
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelement"](1, "ion-icon", 13);
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();
  }
}
function SchoolPlacingDetailComponent_ion_item_0_ng_container_5_Template(rf, ctx) {
  if (rf & 1) {
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementContainerStart"](0);
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](1, "ion-col", 3);
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵtemplate"](2, SchoolPlacingDetailComponent_ion_item_0_ng_container_5_ion_avatar_2_Template, 2, 1, "ion-avatar", 11)(3, SchoolPlacingDetailComponent_ion_item_0_ng_container_5_ng_template_3_Template, 2, 0, "ng-template", null, 0, _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵtemplateRefExtractor"]);
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementContainerEnd"]();
  }
  if (rf & 2) {
    const alternativeAvatar_r2 = _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵreference"](4);
    const ctx_r0 = _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵnextContext"](2);
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵadvance"](2);
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵproperty"]("ngIf", ctx_r0.myTeam == null ? null : ctx_r0.myTeam.avatar == null ? null : ctx_r0.myTeam.avatar.url)("ngIfElse", alternativeAvatar_r2);
  }
}
function SchoolPlacingDetailComponent_ion_item_0_ng_container_6_ion_avatar_2_Template(rf, ctx) {
  if (rf & 1) {
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](0, "ion-avatar");
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelement"](1, "img", 12);
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();
  }
  if (rf & 2) {
    const ctx_r0 = _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵnextContext"](3);
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵadvance"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵproperty"]("src", ctx_r0.placing == null ? null : ctx_r0.placing.avatar == null ? null : ctx_r0.placing.avatar.url, _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵsanitizeUrl"]);
  }
}
function SchoolPlacingDetailComponent_ion_item_0_ng_container_6_ng_template_3_Template(rf, ctx) {
  if (rf & 1) {
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](0, "ion-avatar");
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelement"](1, "ion-icon", 13);
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();
  }
}
function SchoolPlacingDetailComponent_ion_item_0_ng_container_6_Template(rf, ctx) {
  if (rf & 1) {
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementContainerStart"](0);
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](1, "ion-col", 3);
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵtemplate"](2, SchoolPlacingDetailComponent_ion_item_0_ng_container_6_ion_avatar_2_Template, 2, 1, "ion-avatar", 11)(3, SchoolPlacingDetailComponent_ion_item_0_ng_container_6_ng_template_3_Template, 2, 0, "ng-template", null, 0, _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵtemplateRefExtractor"]);
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementContainerEnd"]();
  }
  if (rf & 2) {
    const alternativeAvatar_r3 = _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵreference"](4);
    const ctx_r0 = _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵnextContext"](2);
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵadvance"](2);
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵproperty"]("ngIf", ctx_r0.placing == null ? null : ctx_r0.placing.avatar)("ngIfElse", alternativeAvatar_r3);
  }
}
function SchoolPlacingDetailComponent_ion_item_0_Template(rf, ctx) {
  if (rf & 1) {
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](0, "ion-item", 2)(1, "ion-grid")(2, "ion-row")(3, "ion-col", 3);
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelement"](4, "app-ordinal-number", 4);
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵtemplate"](5, SchoolPlacingDetailComponent_ion_item_0_ng_container_5_Template, 5, 2, "ng-container", 5)(6, SchoolPlacingDetailComponent_ion_item_0_ng_container_6_Template, 5, 2, "ng-container", 5);
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](7, "ion-col", 6)(8, "p", 7);
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵtext"](9);
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]()();
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](10, "ion-col", 8)(11, "div", 9);
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵtext"](12);
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵpipe"](13, "localNumber");
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelement"](14, "app-icon", 10);
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]()()()()();
  }
  if (rf & 2) {
    const ctx_r0 = _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵnextContext"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵclassProp"]("my-placing", (ctx_r0.myTeam == null ? null : ctx_r0.myTeam.id) === ctx_r0.placing.groupId);
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵproperty"]("ngStyle", _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵpureFunction1"](12, _c0, ctx_r0.mine ? "3px solid var(--ion-color-" + (ctx_r0.campaign == null ? null : ctx_r0.campaign.campaign == null ? null : ctx_r0.campaign.campaign.type) + ")" : ""))("routerLink", (ctx_r0.myTeam == null ? null : ctx_r0.myTeam.id) !== ctx_r0.placing.groupId ? _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵpureFunction1"](14, _c1, "/pages/team-profile/" + (ctx_r0.campaign == null ? null : ctx_r0.campaign.campaign == null ? null : ctx_r0.campaign.campaign.campaignId) + "/" + ctx_r0.placing.groupId + "/public") : _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵpureFunction1"](16, _c1, "/pages/team-profile/" + (ctx_r0.campaign == null ? null : ctx_r0.campaign.campaign == null ? null : ctx_r0.campaign.campaign.campaignId) + "/" + ctx_r0.placing.groupId + "/my"));
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵadvance"](4);
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵproperty"]("value", ctx_r0.placing.position);
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵadvance"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵproperty"]("ngIf", (ctx_r0.myTeam == null ? null : ctx_r0.myTeam.id) === ctx_r0.placing.groupId);
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵadvance"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵproperty"]("ngIf", (ctx_r0.myTeam == null ? null : ctx_r0.myTeam.id) !== ctx_r0.placing.groupId);
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵadvance"](3);
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵtextInterpolate"](ctx_r0.placing == null ? null : ctx_r0.placing.customData == null ? null : ctx_r0.placing.customData.name);
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵadvance"](3);
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵtextInterpolate1"]("", _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵpipeBind2"](13, 9, ctx_r0.getValue(ctx_r0.placing.value), "0.0-1"), " ");
  }
}
class SchoolPlacingDetailComponent {
  // playerId$ = this.userService.userProfile$.pipe(
  //   map((userProfile) => userProfile.playerId)
  // );
  // playerAvatarUrl$ = this.userService.userProfile$.pipe(
  //   map((userProfile) => userProfile.avatar.avatarSmallUrl)
  // );
  constructor(userService, teamService) {
    this.userService = userService;
    this.teamService = teamService;
  }
  getValue(value) {
    if (this.unitLabelKey === 'campaigns.leaderboard.leaderboard_type_unit.km') {
      return value / 1000;
    }
    return value;
  }
  ngOnInit() {
    console.log(this.placing);
    // this.myTeam$ = this.teamService.getMyTeam(
    //   this.campaign?.campaign?.campaignId,
    //   this.campaign?.subscription?.campaignData?.teamId
    // ).pipe(shareReplay(1));
  }
  static #_ = _staticBlock = () => (this.ɵfac = function SchoolPlacingDetailComponent_Factory(__ngFactoryType__) {
    return new (__ngFactoryType__ || SchoolPlacingDetailComponent)(_angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵdirectiveInject"](src_app_core_shared_services_user_service__WEBPACK_IMPORTED_MODULE_1__.UserService), _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵdirectiveInject"](src_app_core_shared_services_team_service__WEBPACK_IMPORTED_MODULE_2__.TeamService));
  }, this.ɵcmp = /*@__PURE__*/_angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵdefineComponent"]({
    type: SchoolPlacingDetailComponent,
    selectors: [["app-school-placing-detail"]],
    inputs: {
      placing: "placing",
      unitLabelKey: "unitLabelKey",
      mine: "mine",
      campaign: "campaign",
      myTeam: "myTeam",
      teamId: "teamId"
    },
    standalone: false,
    decls: 1,
    vars: 1,
    consts: [["alternativeAvatar", ""], ["detail", "false", 3, "my-placing", "ngStyle", "routerLink", 4, "ngIf"], ["detail", "false", 3, "ngStyle", "routerLink"], ["size", "2"], [3, "value"], [4, "ngIf"], ["size", "5", 1, "ion-text-start"], [1, "nickname"], ["size", "3", 1, "ion-text-end"], [1, "points"], ["name", "ecoLeavesHsc"], [4, "ngIf", "ngIfElse"], ["title", "avatar", 3, "src"], ["name", "people-circle-outline"]],
    template: function SchoolPlacingDetailComponent_Template(rf, ctx) {
      if (rf & 1) {
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵtemplate"](0, SchoolPlacingDetailComponent_ion_item_0_Template, 15, 18, "ion-item", 1);
      }
      if (rf & 2) {
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵproperty"]("ngIf", ctx.placing);
      }
    },
    dependencies: [_angular_router__WEBPACK_IMPORTED_MODULE_3__.RouterLink, _angular_common__WEBPACK_IMPORTED_MODULE_4__.NgIf, _angular_common__WEBPACK_IMPORTED_MODULE_4__.NgStyle, _ionic_angular__WEBPACK_IMPORTED_MODULE_5__.IonAvatar, _ionic_angular__WEBPACK_IMPORTED_MODULE_5__.IonCol, _ionic_angular__WEBPACK_IMPORTED_MODULE_5__.IonGrid, _ionic_angular__WEBPACK_IMPORTED_MODULE_5__.IonIcon, _ionic_angular__WEBPACK_IMPORTED_MODULE_5__.IonItem, _ionic_angular__WEBPACK_IMPORTED_MODULE_5__.IonRow, _ionic_angular__WEBPACK_IMPORTED_MODULE_5__.RouterLinkDelegate, _core_shared_globalization_ordinal_number_ordinal_number_component__WEBPACK_IMPORTED_MODULE_6__.OrdinalNumberComponent, _core_shared_ui_icon_icon_component__WEBPACK_IMPORTED_MODULE_7__.IconComponent, _core_shared_pipes_localNumber_pipe__WEBPACK_IMPORTED_MODULE_8__.LocalNumberPipe],
    styles: [".my-placing[_ngcontent-%COMP%] {\n  font-weight: bold;\n}\n\n.nickname[_ngcontent-%COMP%] {\n  text-overflow: ellipsis;\n  white-space: nowrap;\n  overflow: hidden;\n}\n\nion-row[_ngcontent-%COMP%] {\n  align-items: center;\n}\n\nion-avatar[_ngcontent-%COMP%] {\n  width: 48px;\n  height: 48px;\n}\nion-avatar[_ngcontent-%COMP%]   img[_ngcontent-%COMP%] {\n  margin: 4px;\n}\n\nion-icon[_ngcontent-%COMP%] {\n  width: 59px;\n  height: 59px;\n}\n\n.points[_ngcontent-%COMP%] {\n  display: flex;\n  align-items: center;\n  justify-content: flex-end;\n}\n.points[_ngcontent-%COMP%]   app-icon[_ngcontent-%COMP%] {\n  margin: 0px 4px;\n}\n/*# sourceMappingURL=data:application/json;charset=utf-8;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbIndlYnBhY2s6Ly8uL3NyYy9hcHAvcGFnZXMvaG9tZS9jYW1wYWlnbi1kZXRhaWxzL3NjaG9vbC1sZWFkZXJib2FyZC9zY2hvb2wtcGxhY2luZy1kZXRhaWwvc2Nob29sLXBsYWNpbmctZGV0YWlsLmNvbXBvbmVudC5zY3NzIl0sIm5hbWVzIjpbXSwibWFwcGluZ3MiOiJBQUFBO0VBQ0UsaUJBQUE7QUFDRjs7QUFDQTtFQUNFLHVCQUFBO0VBQ0EsbUJBQUE7RUFDQSxnQkFBQTtBQUVGOztBQUFBO0VBQ0UsbUJBQUE7QUFHRjs7QUFEQTtFQUNFLFdBQUE7RUFDQSxZQUFBO0FBSUY7QUFIRTtFQUNFLFdBQUE7QUFLSjs7QUFGQTtFQUNFLFdBQUE7RUFDQSxZQUFBO0FBS0Y7O0FBSEE7RUFDRSxhQUFBO0VBQ0EsbUJBQUE7RUFDQSx5QkFBQTtBQU1GO0FBTEU7RUFDRSxlQUFBO0FBT0oiLCJzb3VyY2VzQ29udGVudCI6WyIubXktcGxhY2luZyB7XG4gIGZvbnQtd2VpZ2h0OiBib2xkO1xufVxuLm5pY2tuYW1lIHtcbiAgdGV4dC1vdmVyZmxvdzogZWxsaXBzaXM7XG4gIHdoaXRlLXNwYWNlOiBub3dyYXA7XG4gIG92ZXJmbG93OiBoaWRkZW47XG59XG5pb24tcm93IHtcbiAgYWxpZ24taXRlbXM6IGNlbnRlcjtcbn1cbmlvbi1hdmF0YXIge1xuICB3aWR0aDogNDhweDtcbiAgaGVpZ2h0OiA0OHB4O1xuICBpbWcge1xuICAgIG1hcmdpbjogNHB4O1xuICB9XG59XG5pb24taWNvbiB7XG4gIHdpZHRoOiA1OXB4O1xuICBoZWlnaHQ6IDU5cHg7XG59XG4ucG9pbnRzIHtcbiAgZGlzcGxheTogZmxleDtcbiAgYWxpZ24taXRlbXM6IGNlbnRlcjtcbiAganVzdGlmeS1jb250ZW50OiBmbGV4LWVuZDtcbiAgYXBwLWljb24ge1xuICAgIG1hcmdpbjogMHB4IDRweDtcbiAgfVxufVxuIl0sInNvdXJjZVJvb3QiOiIifQ== */"]
  }));
}
_staticBlock();

/***/ }),

/***/ 71145:
/*!*******************************************************************************************!*\
  !*** ./src/app/pages/home/campaign-details/school-leaderboard/school-leaderboard.page.ts ***!
  \*******************************************************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   SchoolLeaderboardPage: () => (/* binding */ SchoolLeaderboardPage)
/* harmony export */ });
/* harmony import */ var luxon__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! luxon */ 45967);
/* harmony import */ var lodash_es__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! lodash-es */ 24979);
/* harmony import */ var rxjs__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! rxjs */ 10819);
/* harmony import */ var rxjs__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! rxjs */ 19999);
/* harmony import */ var rxjs_operators__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! rxjs/operators */ 91817);
/* harmony import */ var rxjs_operators__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! rxjs/operators */ 70271);
/* harmony import */ var rxjs_operators__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! rxjs/operators */ 86301);
/* harmony import */ var rxjs_operators__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(/*! rxjs/operators */ 63037);
/* harmony import */ var rxjs_operators__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(/*! rxjs/operators */ 36647);
/* harmony import */ var rxjs_operators__WEBPACK_IMPORTED_MODULE_9__ = __webpack_require__(/*! rxjs/operators */ 98764);
/* harmony import */ var src_app_core_shared_rxjs_utils__WEBPACK_IMPORTED_MODULE_10__ = __webpack_require__(/*! src/app/core/shared/rxjs.utils */ 86040);
/* harmony import */ var src_app_core_shared_time_utils__WEBPACK_IMPORTED_MODULE_11__ = __webpack_require__(/*! src/app/core/shared/time.utils */ 27780);
/* harmony import */ var src_app_core_shared_tracking_trip_model__WEBPACK_IMPORTED_MODULE_12__ = __webpack_require__(/*! src/app/core/shared/tracking/trip.model */ 23126);
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_13__ = __webpack_require__(/*! @angular/core */ 34205);
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_14__ = __webpack_require__(/*! @angular/core */ 12481);
/* harmony import */ var _angular_router__WEBPACK_IMPORTED_MODULE_15__ = __webpack_require__(/*! @angular/router */ 85422);
/* harmony import */ var src_app_core_shared_services_team_service__WEBPACK_IMPORTED_MODULE_16__ = __webpack_require__(/*! src/app/core/shared/services/team.service */ 62625);
/* harmony import */ var src_app_core_api_generated_hsc_controllers_teamStatsController_service__WEBPACK_IMPORTED_MODULE_17__ = __webpack_require__(/*! src/app/core/api/generated-hsc/controllers/teamStatsController.service */ 52493);
/* harmony import */ var src_app_core_shared_services_campaign_service__WEBPACK_IMPORTED_MODULE_18__ = __webpack_require__(/*! src/app/core/shared/services/campaign.service */ 76658);
/* harmony import */ var src_app_core_shared_services_error_service__WEBPACK_IMPORTED_MODULE_19__ = __webpack_require__(/*! src/app/core/shared/services/error.service */ 46078);
/* harmony import */ var src_app_core_shared_services_page_settings_service__WEBPACK_IMPORTED_MODULE_20__ = __webpack_require__(/*! src/app/core/shared/services/page-settings.service */ 40147);
/* harmony import */ var _angular_common__WEBPACK_IMPORTED_MODULE_21__ = __webpack_require__(/*! @angular/common */ 93683);
/* harmony import */ var _ionic_angular__WEBPACK_IMPORTED_MODULE_22__ = __webpack_require__(/*! @ionic/angular */ 21507);
/* harmony import */ var _core_shared_layout_header_header_directive__WEBPACK_IMPORTED_MODULE_23__ = __webpack_require__(/*! ../../../../core/shared/layout/header/header.directive */ 85039);
/* harmony import */ var _core_shared_layout_content_content_directive__WEBPACK_IMPORTED_MODULE_24__ = __webpack_require__(/*! ../../../../core/shared/layout/content/content.directive */ 75855);
/* harmony import */ var _core_shared_infinite_scroll_infinite_scroll_component__WEBPACK_IMPORTED_MODULE_25__ = __webpack_require__(/*! ../../../../core/shared/infinite-scroll/infinite-scroll.component */ 666);
/* harmony import */ var _school_placing_detail_school_placing_detail_component__WEBPACK_IMPORTED_MODULE_26__ = __webpack_require__(/*! ./school-placing-detail/school-placing-detail.component */ 22208);
/* harmony import */ var _ngx_translate_core__WEBPACK_IMPORTED_MODULE_27__ = __webpack_require__(/*! @ngx-translate/core */ 48503);
var _staticBlock;





















const _c0 = () => ({
  cssClass: "app-alert"
});
function SchoolLeaderboardPage_ng_container_2_ion_col_8_Template(rf, ctx) {
  if (rf & 1) {
    _angular_core__WEBPACK_IMPORTED_MODULE_14__["ɵɵelementStart"](0, "ion-col", 13)(1, "ion-item", 14)(2, "span");
    _angular_core__WEBPACK_IMPORTED_MODULE_14__["ɵɵtext"](3);
    _angular_core__WEBPACK_IMPORTED_MODULE_14__["ɵɵpipe"](4, "translate");
    _angular_core__WEBPACK_IMPORTED_MODULE_14__["ɵɵelementEnd"]()()();
  }
  if (rf & 2) {
    const ctx_r1 = _angular_core__WEBPACK_IMPORTED_MODULE_14__["ɵɵnextContext"](2);
    _angular_core__WEBPACK_IMPORTED_MODULE_14__["ɵɵadvance"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_14__["ɵɵproperty"]("color", ctx_r1.campaignContainer == null ? null : ctx_r1.campaignContainer.campaign == null ? null : ctx_r1.campaignContainer.campaign.type);
    _angular_core__WEBPACK_IMPORTED_MODULE_14__["ɵɵadvance"](2);
    _angular_core__WEBPACK_IMPORTED_MODULE_14__["ɵɵtextInterpolate"](_angular_core__WEBPACK_IMPORTED_MODULE_14__["ɵɵpipeBind1"](4, 2, "campaigns.leaderboard.leaderboard_type.GL"));
  }
}
function SchoolLeaderboardPage_ng_container_2_ion_select_option_15_Template(rf, ctx) {
  if (rf & 1) {
    _angular_core__WEBPACK_IMPORTED_MODULE_14__["ɵɵelementStart"](0, "ion-select-option", 15);
    _angular_core__WEBPACK_IMPORTED_MODULE_14__["ɵɵtext"](1);
    _angular_core__WEBPACK_IMPORTED_MODULE_14__["ɵɵpipe"](2, "translate");
    _angular_core__WEBPACK_IMPORTED_MODULE_14__["ɵɵelementEnd"]();
  }
  if (rf & 2) {
    const period_r3 = ctx.$implicit;
    _angular_core__WEBPACK_IMPORTED_MODULE_14__["ɵɵproperty"]("value", period_r3);
    _angular_core__WEBPACK_IMPORTED_MODULE_14__["ɵɵadvance"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_14__["ɵɵtextInterpolate1"](" ", _angular_core__WEBPACK_IMPORTED_MODULE_14__["ɵɵpipeBind1"](2, 2, period_r3.labelKey), " ");
  }
}
function SchoolLeaderboardPage_ng_container_2_app_school_placing_detail_16_Template(rf, ctx) {
  if (rf & 1) {
    _angular_core__WEBPACK_IMPORTED_MODULE_14__["ɵɵelement"](0, "app-school-placing-detail", 16);
    _angular_core__WEBPACK_IMPORTED_MODULE_14__["ɵɵpipe"](1, "async");
    _angular_core__WEBPACK_IMPORTED_MODULE_14__["ɵɵpipe"](2, "async");
  }
  if (rf & 2) {
    const ctx_r1 = _angular_core__WEBPACK_IMPORTED_MODULE_14__["ɵɵnextContext"](2);
    _angular_core__WEBPACK_IMPORTED_MODULE_14__["ɵɵproperty"]("myTeam", ctx_r1.myTeam)("placing", _angular_core__WEBPACK_IMPORTED_MODULE_14__["ɵɵpipeBind1"](1, 5, ctx_r1.teamPosition$))("unitLabelKey", _angular_core__WEBPACK_IMPORTED_MODULE_14__["ɵɵpipeBind1"](2, 7, ctx_r1.numberWithUnitKey$))("mine", true)("campaign", ctx_r1.campaignContainer);
  }
}
function SchoolLeaderboardPage_ng_container_2_ng_container_18_ng_template_4_Template(rf, ctx) {
  if (rf & 1) {
    _angular_core__WEBPACK_IMPORTED_MODULE_14__["ɵɵelement"](0, "app-school-placing-detail", 19);
    _angular_core__WEBPACK_IMPORTED_MODULE_14__["ɵɵpipe"](1, "async");
  }
  if (rf & 2) {
    const placing_r5 = ctx.item;
    const ctx_r1 = _angular_core__WEBPACK_IMPORTED_MODULE_14__["ɵɵnextContext"](3);
    _angular_core__WEBPACK_IMPORTED_MODULE_14__["ɵɵproperty"]("placing", placing_r5)("unitLabelKey", _angular_core__WEBPACK_IMPORTED_MODULE_14__["ɵɵpipeBind1"](1, 5, ctx_r1.numberWithUnitKey$))("mine", false)("campaign", ctx_r1.campaignContainer)("myTeam", ctx_r1.myTeam);
  }
}
function SchoolLeaderboardPage_ng_container_2_ng_container_18_Template(rf, ctx) {
  if (rf & 1) {
    const _r4 = _angular_core__WEBPACK_IMPORTED_MODULE_14__["ɵɵgetCurrentView"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_14__["ɵɵelementContainerStart"](0);
    _angular_core__WEBPACK_IMPORTED_MODULE_14__["ɵɵelementStart"](1, "app-infinite-scroll", 17);
    _angular_core__WEBPACK_IMPORTED_MODULE_14__["ɵɵpipe"](2, "async");
    _angular_core__WEBPACK_IMPORTED_MODULE_14__["ɵɵpipe"](3, "async");
    _angular_core__WEBPACK_IMPORTED_MODULE_14__["ɵɵlistener"]("request", function SchoolLeaderboardPage_ng_container_2_ng_container_18_Template_app_infinite_scroll_request_1_listener($event) {
      _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵrestoreView"](_r4);
      const ctx_r1 = _angular_core__WEBPACK_IMPORTED_MODULE_14__["ɵɵnextContext"](2);
      return _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵresetView"](ctx_r1.scrollRequestSubject.next($event));
    });
    _angular_core__WEBPACK_IMPORTED_MODULE_14__["ɵɵtemplate"](4, SchoolLeaderboardPage_ng_container_2_ng_container_18_ng_template_4_Template, 2, 7, "ng-template", 18);
    _angular_core__WEBPACK_IMPORTED_MODULE_14__["ɵɵelementEnd"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_14__["ɵɵelementContainerEnd"]();
  }
  if (rf & 2) {
    const ctx_r1 = _angular_core__WEBPACK_IMPORTED_MODULE_14__["ɵɵnextContext"](2);
    _angular_core__WEBPACK_IMPORTED_MODULE_14__["ɵɵadvance"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_14__["ɵɵproperty"]("resetItems", _angular_core__WEBPACK_IMPORTED_MODULE_14__["ɵɵpipeBind1"](2, 2, ctx_r1.resetItems$))("response", _angular_core__WEBPACK_IMPORTED_MODULE_14__["ɵɵpipeBind1"](3, 4, ctx_r1.leaderboardScrollResponse$));
  }
}
function SchoolLeaderboardPage_ng_container_2_ng_template_21_Template(rf, ctx) {
  if (rf & 1) {
    _angular_core__WEBPACK_IMPORTED_MODULE_14__["ɵɵelementStart"](0, "ion-col")(1, "div", 20);
    _angular_core__WEBPACK_IMPORTED_MODULE_14__["ɵɵtext"](2);
    _angular_core__WEBPACK_IMPORTED_MODULE_14__["ɵɵpipe"](3, "translate");
    _angular_core__WEBPACK_IMPORTED_MODULE_14__["ɵɵelementEnd"]()();
  }
  if (rf & 2) {
    _angular_core__WEBPACK_IMPORTED_MODULE_14__["ɵɵadvance"](2);
    _angular_core__WEBPACK_IMPORTED_MODULE_14__["ɵɵtextInterpolate"](_angular_core__WEBPACK_IMPORTED_MODULE_14__["ɵɵpipeBind1"](3, 1, "campaigns.leaderboard.empty"));
  }
}
function SchoolLeaderboardPage_ng_container_2_Template(rf, ctx) {
  if (rf & 1) {
    const _r1 = _angular_core__WEBPACK_IMPORTED_MODULE_14__["ɵɵgetCurrentView"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_14__["ɵɵelementContainerStart"](0);
    _angular_core__WEBPACK_IMPORTED_MODULE_14__["ɵɵelementStart"](1, "div", 4)(2, "div", 5)(3, "ion-row")(4, "ion-col")(5, "ion-item", 6);
    _angular_core__WEBPACK_IMPORTED_MODULE_14__["ɵɵtext"](6);
    _angular_core__WEBPACK_IMPORTED_MODULE_14__["ɵɵpipe"](7, "translate");
    _angular_core__WEBPACK_IMPORTED_MODULE_14__["ɵɵelementEnd"]()();
    _angular_core__WEBPACK_IMPORTED_MODULE_14__["ɵɵtemplate"](8, SchoolLeaderboardPage_ng_container_2_ion_col_8_Template, 5, 4, "ion-col", 7);
    _angular_core__WEBPACK_IMPORTED_MODULE_14__["ɵɵpipe"](9, "async");
    _angular_core__WEBPACK_IMPORTED_MODULE_14__["ɵɵelementEnd"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_14__["ɵɵelementStart"](10, "ion-row")(11, "ion-col")(12, "ion-item", 8)(13, "ion-select", 9);
    _angular_core__WEBPACK_IMPORTED_MODULE_14__["ɵɵpipe"](14, "async");
    _angular_core__WEBPACK_IMPORTED_MODULE_14__["ɵɵlistener"]("ionChange", function SchoolLeaderboardPage_ng_container_2_Template_ion_select_ionChange_13_listener($event) {
      _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵrestoreView"](_r1);
      const ctx_r1 = _angular_core__WEBPACK_IMPORTED_MODULE_14__["ɵɵnextContext"]();
      return _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵresetView"](ctx_r1.periodChangedSubject.next($event));
    });
    _angular_core__WEBPACK_IMPORTED_MODULE_14__["ɵɵtemplate"](15, SchoolLeaderboardPage_ng_container_2_ion_select_option_15_Template, 3, 4, "ion-select-option", 10);
    _angular_core__WEBPACK_IMPORTED_MODULE_14__["ɵɵelementEnd"]()()()();
    _angular_core__WEBPACK_IMPORTED_MODULE_14__["ɵɵtemplate"](16, SchoolLeaderboardPage_ng_container_2_app_school_placing_detail_16_Template, 3, 9, "app-school-placing-detail", 11);
    _angular_core__WEBPACK_IMPORTED_MODULE_14__["ɵɵpipe"](17, "async");
    _angular_core__WEBPACK_IMPORTED_MODULE_14__["ɵɵelementEnd"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_14__["ɵɵtemplate"](18, SchoolLeaderboardPage_ng_container_2_ng_container_18_Template, 5, 6, "ng-container", 12);
    _angular_core__WEBPACK_IMPORTED_MODULE_14__["ɵɵpipe"](19, "async");
    _angular_core__WEBPACK_IMPORTED_MODULE_14__["ɵɵpipe"](20, "async");
    _angular_core__WEBPACK_IMPORTED_MODULE_14__["ɵɵtemplate"](21, SchoolLeaderboardPage_ng_container_2_ng_template_21_Template, 4, 3, "ng-template", null, 0, _angular_core__WEBPACK_IMPORTED_MODULE_14__["ɵɵtemplateRefExtractor"]);
    _angular_core__WEBPACK_IMPORTED_MODULE_14__["ɵɵelementEnd"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_14__["ɵɵelementContainerEnd"]();
  }
  if (rf & 2) {
    let tmp_11_0;
    let tmp_12_0;
    const emptyLead_r6 = _angular_core__WEBPACK_IMPORTED_MODULE_14__["ɵɵreference"](22);
    const ctx_r1 = _angular_core__WEBPACK_IMPORTED_MODULE_14__["ɵɵnextContext"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_14__["ɵɵadvance"](2);
    _angular_core__WEBPACK_IMPORTED_MODULE_14__["ɵɵstyleProp"]("color", "var(--ion-color-" + ctx_r1.campaignContainer.campaign.type + "-stat-contrast)")("background-color", "var(--ion-color-" + ctx_r1.campaignContainer.campaign.type + ")");
    _angular_core__WEBPACK_IMPORTED_MODULE_14__["ɵɵadvance"](3);
    _angular_core__WEBPACK_IMPORTED_MODULE_14__["ɵɵproperty"]("color", ctx_r1.campaignContainer == null ? null : ctx_r1.campaignContainer.campaign == null ? null : ctx_r1.campaignContainer.campaign.type);
    _angular_core__WEBPACK_IMPORTED_MODULE_14__["ɵɵadvance"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_14__["ɵɵtextInterpolate1"](" ", _angular_core__WEBPACK_IMPORTED_MODULE_14__["ɵɵpipeBind1"](7, 14, "campaigns.leaderboard.all_means"), " ");
    _angular_core__WEBPACK_IMPORTED_MODULE_14__["ɵɵadvance"](2);
    _angular_core__WEBPACK_IMPORTED_MODULE_14__["ɵɵproperty"]("ngIf", _angular_core__WEBPACK_IMPORTED_MODULE_14__["ɵɵpipeBind1"](9, 16, ctx_r1.useMeanAndMetric$) === false);
    _angular_core__WEBPACK_IMPORTED_MODULE_14__["ɵɵadvance"](4);
    _angular_core__WEBPACK_IMPORTED_MODULE_14__["ɵɵproperty"]("color", ctx_r1.campaignContainer == null ? null : ctx_r1.campaignContainer.campaign == null ? null : ctx_r1.campaignContainer.campaign.type);
    _angular_core__WEBPACK_IMPORTED_MODULE_14__["ɵɵadvance"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_14__["ɵɵproperty"]("interfaceOptions", _angular_core__WEBPACK_IMPORTED_MODULE_14__["ɵɵpureFunction0"](26, _c0))("value", _angular_core__WEBPACK_IMPORTED_MODULE_14__["ɵɵpipeBind1"](14, 18, ctx_r1.selectedPeriod$));
    _angular_core__WEBPACK_IMPORTED_MODULE_14__["ɵɵadvance"](2);
    _angular_core__WEBPACK_IMPORTED_MODULE_14__["ɵɵproperty"]("ngForOf", ctx_r1.periods);
    _angular_core__WEBPACK_IMPORTED_MODULE_14__["ɵɵadvance"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_14__["ɵɵproperty"]("ngIf", ((tmp_11_0 = _angular_core__WEBPACK_IMPORTED_MODULE_14__["ɵɵpipeBind1"](17, 20, ctx_r1.leaderboardScrollResponse$)) == null ? null : tmp_11_0.totalElements) > 0);
    _angular_core__WEBPACK_IMPORTED_MODULE_14__["ɵɵadvance"](2);
    _angular_core__WEBPACK_IMPORTED_MODULE_14__["ɵɵproperty"]("ngIf", ((tmp_12_0 = _angular_core__WEBPACK_IMPORTED_MODULE_14__["ɵɵpipeBind1"](19, 22, ctx_r1.leaderboardScrollResponse$)) == null ? null : tmp_12_0.totalElements) > 0 && _angular_core__WEBPACK_IMPORTED_MODULE_14__["ɵɵpipeBind1"](20, 24, ctx_r1.filterOptions$))("ngIfElse", emptyLead_r6);
  }
}
class SchoolLeaderboardPage {
  constructor(route, teamService, teamStatsControllerService, campaignService, errorService, pageSettingsService) {
    this.route = route;
    this.teamService = teamService;
    this.teamStatsControllerService = teamStatsControllerService;
    this.campaignService = campaignService;
    this.errorService = errorService;
    this.pageSettingsService = pageSettingsService;
    this.referenceDate = luxon__WEBPACK_IMPORTED_MODULE_0__.DateTime.local();
    this.periods = this.getPeriods(this.referenceDate);
    this.metricToNumberWithUnitLabel = {
      co2: 'campaigns.leaderboard.leaderboard_type_unit.co2',
      km: 'campaigns.leaderboard.leaderboard_type_unit.km'
    };
    this.metricToUnitLabel = {
      co2: 'campaigns.leaderboard.unit.co2',
      km: 'campaigns.leaderboard.unit.km'
    };
    this.meanLabels = {
      ...src_app_core_shared_tracking_trip_model__WEBPACK_IMPORTED_MODULE_12__.transportTypeLabels,
      [ALL_MEANS]: 'campaigns.leaderboard.all_means'
    };
    this.campaignId$ = this.route.params.pipe((0,rxjs_operators__WEBPACK_IMPORTED_MODULE_5__.map)(params => params.id), (0,rxjs_operators__WEBPACK_IMPORTED_MODULE_4__.distinctUntilChanged)(), (0,rxjs_operators__WEBPACK_IMPORTED_MODULE_6__.shareReplay)(1));
    this.campaign$ = this.campaignId$.pipe((0,rxjs_operators__WEBPACK_IMPORTED_MODULE_8__.switchMap)(campaignId => this.campaignService.allCampaigns$.pipe((0,rxjs_operators__WEBPACK_IMPORTED_MODULE_5__.map)(campaigns => (0,lodash_es__WEBPACK_IMPORTED_MODULE_1__["default"])(campaigns, {
      campaignId
    })), (0,src_app_core_shared_rxjs_utils__WEBPACK_IMPORTED_MODULE_10__.throwIfNil)(() => new Error('Campaign not found')), this.errorService.getErrorHandler())), (0,rxjs_operators__WEBPACK_IMPORTED_MODULE_6__.shareReplay)(1));
    this.playerCampaign$ = this.campaignId$.pipe((0,rxjs_operators__WEBPACK_IMPORTED_MODULE_8__.switchMap)(campaignId => this.campaignService.myCampaigns$.pipe((0,rxjs_operators__WEBPACK_IMPORTED_MODULE_5__.map)(campaigns => (0,lodash_es__WEBPACK_IMPORTED_MODULE_1__["default"])(campaigns, playercampaign => playercampaign?.subscription?.campaignId === campaignId)), (0,src_app_core_shared_rxjs_utils__WEBPACK_IMPORTED_MODULE_10__.throwIfNil)(() => new Error('Campaign not found')), this.errorService.getErrorHandler())), (0,rxjs_operators__WEBPACK_IMPORTED_MODULE_9__.tap)(campaign => console.log('playercampaign' + campaign)), (0,rxjs_operators__WEBPACK_IMPORTED_MODULE_6__.shareReplay)(1));
    this.useMeanAndMetric$ = this.campaign$.pipe((0,rxjs_operators__WEBPACK_IMPORTED_MODULE_5__.map)(campaign => campaign.type === 'personal'));
    this.means$ = this.campaignService.availableMeans$.pipe((0,rxjs_operators__WEBPACK_IMPORTED_MODULE_5__.map)(availableMeans => [ALL_MEANS, ...availableMeans]));
    this.selectedMeanChangedSubject = new rxjs__WEBPACK_IMPORTED_MODULE_2__.Subject();
    this.selectedMean$ = this.selectedMeanChangedSubject.pipe((0,rxjs_operators__WEBPACK_IMPORTED_MODULE_5__.map)(event => event.detail.value), (0,rxjs_operators__WEBPACK_IMPORTED_MODULE_7__.startWith)(ALL_MEANS), (0,rxjs_operators__WEBPACK_IMPORTED_MODULE_6__.shareReplay)(1));
    this.metrics = ['co2', 'km'];
    this.selectedMetricChangedSubject = new rxjs__WEBPACK_IMPORTED_MODULE_2__.Subject();
    this.selectedMetric$ = this.selectedMetricChangedSubject.pipe((0,rxjs_operators__WEBPACK_IMPORTED_MODULE_5__.map)(event => event.detail.value), (0,rxjs_operators__WEBPACK_IMPORTED_MODULE_7__.startWith)(
    // initial select value
    'co2'), (0,rxjs_operators__WEBPACK_IMPORTED_MODULE_6__.shareReplay)(1));
    this.periodChangedSubject = new rxjs__WEBPACK_IMPORTED_MODULE_2__.Subject();
    this.selectedPeriod$ = this.periodChangedSubject.pipe((0,rxjs_operators__WEBPACK_IMPORTED_MODULE_5__.map)(event => event.detail.value), (0,rxjs_operators__WEBPACK_IMPORTED_MODULE_7__.startWith)((0,lodash_es__WEBPACK_IMPORTED_MODULE_1__["default"])(this.periods, {
      default: true
    }) ?? this.periods[0]),
    // initial select value
    (0,rxjs_operators__WEBPACK_IMPORTED_MODULE_6__.shareReplay)(1));
    this.teamId$ = this.playerCampaign$.pipe((0,rxjs_operators__WEBPACK_IMPORTED_MODULE_5__.map)(campaign => {
      console.log(campaign);
      return campaign?.subscription?.campaignData?.teamId;
    }), (0,rxjs_operators__WEBPACK_IMPORTED_MODULE_9__.tap)(team => console.log(team)), (0,rxjs_operators__WEBPACK_IMPORTED_MODULE_6__.shareReplay)(1));
    // this.userService.userProfile$.pipe(
    //   map((userProfile) => userProfile.playerId),
    //   distinctUntilChanged()
    // );
    // this.route.params.pipe(
    //   map((params) => params.id),
    this.filterOptions$ = (0,rxjs__WEBPACK_IMPORTED_MODULE_3__.combineLatest)({
      mean: this.selectedMean$,
      metric: this.selectedMetric$,
      period: this.selectedPeriod$,
      campaignId: this.campaignId$,
      useMeanAndMetric: this.useMeanAndMetric$,
      teamId: this.teamId$
    });
    this.numberWithUnitKey$ = this.filterOptions$.pipe((0,rxjs_operators__WEBPACK_IMPORTED_MODULE_5__.map)(({
      useMeanAndMetric,
      metric
    }) => useMeanAndMetric ? this.metricToNumberWithUnitLabel[metric] : 'campaigns.leaderboard.leaderboard_type_unit.GL'), (0,rxjs_operators__WEBPACK_IMPORTED_MODULE_6__.shareReplay)(1));
    this.teamPosition$ = this.filterOptions$.pipe((0,rxjs_operators__WEBPACK_IMPORTED_MODULE_8__.switchMap)(({
      useMeanAndMetric,
      metric,
      mean,
      period,
      campaignId,
      teamId
    }) => {
      if (useMeanAndMetric) {
        return this.teamStatsControllerService.geGroupCampaingPlacingByTransportModeUsingGET({
          campaignId,
          groupId: teamId,
          metric,
          mean: mean === ALL_MEANS ? undefined : mean,
          dateFrom: period.from ?? undefined,
          dateTo: period.to ?? undefined
        }).pipe((0,rxjs_operators__WEBPACK_IMPORTED_MODULE_5__.map)(place => {
          place.groupId = teamId;
          return place;
        }), this.errorService.getErrorHandler());
      } else {
        return this.teamStatsControllerService.getGroupCampaingPlacingByGameUsingGET({
          campaignId,
          groupId: teamId,
          dateFrom: period.from ?? undefined,
          dateTo: period.to ?? undefined
        }).pipe((0,rxjs_operators__WEBPACK_IMPORTED_MODULE_5__.map)(place => {
          place.groupId = teamId;
          return place;
        }), this.errorService.getErrorHandler());
      }
    }), (0,rxjs_operators__WEBPACK_IMPORTED_MODULE_6__.shareReplay)(1));
    this.scrollRequestSubject = new rxjs__WEBPACK_IMPORTED_MODULE_2__.Subject();
    this.leaderboardScrollResponse$ = this.filterOptions$.pipe((0,rxjs_operators__WEBPACK_IMPORTED_MODULE_8__.switchMap)(({
      useMeanAndMetric,
      metric,
      mean,
      period,
      campaignId
    }) => this.scrollRequestSubject.pipe((0,rxjs_operators__WEBPACK_IMPORTED_MODULE_7__.startWith)({
      page: 0,
      size: 10
    }), (0,rxjs_operators__WEBPACK_IMPORTED_MODULE_8__.switchMap)(({
      page,
      size
    }) => {
      if (useMeanAndMetric) {
        return this.teamStatsControllerService.getCampaingPlacingByTransportStatsUsingGET({
          page: page ?? 0,
          size: size ?? 0,
          campaignId,
          metric,
          mean: mean === ALL_MEANS ? undefined : mean,
          dateFrom: period.from ?? undefined,
          dateTo: period.to ?? undefined
        }).pipe(this.errorService.getErrorHandler());
      } else {
        return this.teamStatsControllerService.getCampaingPlacingByGameUsingGET({
          page: page ?? 0,
          size: size ?? 0,
          campaignId,
          dateFrom: period.from ?? undefined,
          dateTo: period.to ?? undefined
        }).pipe(this.errorService.getErrorHandler());
      }
    }))));
    this.resetItems$ = this.filterOptions$.pipe((0,rxjs_operators__WEBPACK_IMPORTED_MODULE_5__.map)(() => Symbol()));
    this.subId = this.route.params.subscribe(params => {
      this.id = params.id;
      this.subCampaign = this.campaignService.myCampaigns$.subscribe(campaigns => {
        this.campaignContainer = campaigns.find(campaignContainer => campaignContainer?.campaign?.campaignId === this.id);
      });
    });
  }
  ngOnDestroy() {
    this.subCampaign.unsubscribe();
    this.subId.unsubscribe();
    this.myTeamSub.unsubscribe();
  }
  ionViewWillEnter() {
    this.changePageSettings();
  }
  changePageSettings() {
    this.pageSettingsService.set({
      color: this.campaignContainer?.campaign?.type
    });
  }
  getPeriods(referenceDate) {
    return [{
      labelKey: 'campaigns.leaderboard.period.today',
      from: this.toServerDate(referenceDate.startOf('day')),
      to: this.toServerDate(referenceDate),
      default: false
    }, {
      labelKey: 'campaigns.leaderboard.period.this_week',
      from: this.toServerDate(referenceDate.startOf('week')),
      to: this.toServerDate(referenceDate),
      default: true
    }, {
      labelKey: 'campaigns.leaderboard.period.last_week',
      from: this.toServerDate(referenceDate.startOf('week').minus({
        weeks: 1
      })),
      to: this.toServerDate(referenceDate.startOf('week').minus({
        weeks: 1
      }).endOf('week')),
      default: false
    }, {
      labelKey: 'campaigns.leaderboard.period.this_month',
      from: this.toServerDate(referenceDate.startOf('month')),
      to: this.toServerDate(referenceDate),
      default: false
    }, {
      labelKey: 'campaigns.leaderboard.period.all_time',
      // not specifying dates, will improve the server performance because of special handling
      // but we will lose the confidence that player position and leaderboard are in sync.
      // maybe it is not such deal, "All Time" leaderboard will not change so rapidly.
      from: null,
      //this.toServerDate(minusInfDate),
      to: null,
      //this.toServerDate(referenceDate),
      default: false
    }];
  }
  toServerDate(dateTime) {
    // TODO: This is actually quite tricky bug.
    // When we round reference date to the start of the day, than we get this period
    // from beginning of the day to now, where events affecting this period will
    // cause inconsistent data between the loaded pages of pagination.
    return (0,src_app_core_shared_time_utils__WEBPACK_IMPORTED_MODULE_11__.toServerDateOnly)(dateTime);
  }
  ngOnInit() {
    this.myTeamSub = (0,rxjs__WEBPACK_IMPORTED_MODULE_3__.combineLatest)([this.campaignId$, this.teamId$]).pipe((0,rxjs_operators__WEBPACK_IMPORTED_MODULE_8__.switchMap)(([campaignId, teamId]) => this.teamService.getMyTeam(campaignId, teamId))).subscribe(team => this.myTeam = team);
  }
  static #_ = _staticBlock = () => (this.ɵfac = function SchoolLeaderboardPage_Factory(__ngFactoryType__) {
    return new (__ngFactoryType__ || SchoolLeaderboardPage)(_angular_core__WEBPACK_IMPORTED_MODULE_14__["ɵɵdirectiveInject"](_angular_router__WEBPACK_IMPORTED_MODULE_15__.ActivatedRoute), _angular_core__WEBPACK_IMPORTED_MODULE_14__["ɵɵdirectiveInject"](src_app_core_shared_services_team_service__WEBPACK_IMPORTED_MODULE_16__.TeamService), _angular_core__WEBPACK_IMPORTED_MODULE_14__["ɵɵdirectiveInject"](src_app_core_api_generated_hsc_controllers_teamStatsController_service__WEBPACK_IMPORTED_MODULE_17__.TeamStatsControllerService), _angular_core__WEBPACK_IMPORTED_MODULE_14__["ɵɵdirectiveInject"](src_app_core_shared_services_campaign_service__WEBPACK_IMPORTED_MODULE_18__.CampaignService), _angular_core__WEBPACK_IMPORTED_MODULE_14__["ɵɵdirectiveInject"](src_app_core_shared_services_error_service__WEBPACK_IMPORTED_MODULE_19__.ErrorService), _angular_core__WEBPACK_IMPORTED_MODULE_14__["ɵɵdirectiveInject"](src_app_core_shared_services_page_settings_service__WEBPACK_IMPORTED_MODULE_20__.PageSettingsService));
  }, this.ɵcmp = /*@__PURE__*/_angular_core__WEBPACK_IMPORTED_MODULE_14__["ɵɵdefineComponent"]({
    type: SchoolLeaderboardPage,
    selectors: [["app-school-leaderboard"]],
    standalone: false,
    decls: 4,
    vars: 3,
    consts: [["emptyLead", ""], ["appHeader", ""], ["appContent", ""], [4, "ngIf"], [1, "header-margin"], [1, "header-sticky"], ["lines", "full", 3, "color"], ["class", "flex-end", 4, "ngIf"], [1, "", 3, "color"], ["interface", "popover", 3, "ionChange", "interfaceOptions", "value"], [3, "value", 4, "ngFor", "ngForOf"], [3, "myTeam", "placing", "unitLabelKey", "mine", "campaign", 4, "ngIf"], [4, "ngIf", "ngIfElse"], [1, "flex-end"], ["lines", "full", 1, "ion-text-end", 3, "color"], [3, "value"], [3, "myTeam", "placing", "unitLabelKey", "mine", "campaign"], [3, "request", "resetItems", "response"], ["appInfiniteScrollContent", ""], [3, "placing", "unitLabelKey", "mine", "campaign", "myTeam"], [1, "empty-lead"]],
    template: function SchoolLeaderboardPage_Template(rf, ctx) {
      if (rf & 1) {
        _angular_core__WEBPACK_IMPORTED_MODULE_14__["ɵɵelement"](0, "ion-header", 1);
        _angular_core__WEBPACK_IMPORTED_MODULE_14__["ɵɵelementStart"](1, "ion-content", 2);
        _angular_core__WEBPACK_IMPORTED_MODULE_14__["ɵɵtemplate"](2, SchoolLeaderboardPage_ng_container_2_Template, 23, 27, "ng-container", 3);
        _angular_core__WEBPACK_IMPORTED_MODULE_14__["ɵɵpipe"](3, "async");
        _angular_core__WEBPACK_IMPORTED_MODULE_14__["ɵɵelementEnd"]();
      }
      if (rf & 2) {
        _angular_core__WEBPACK_IMPORTED_MODULE_14__["ɵɵadvance"](2);
        _angular_core__WEBPACK_IMPORTED_MODULE_14__["ɵɵproperty"]("ngIf", _angular_core__WEBPACK_IMPORTED_MODULE_14__["ɵɵpipeBind1"](3, 1, ctx.campaign$) !== null && ctx.myTeam !== null);
      }
    },
    dependencies: [_angular_common__WEBPACK_IMPORTED_MODULE_21__.NgForOf, _angular_common__WEBPACK_IMPORTED_MODULE_21__.NgIf, _ionic_angular__WEBPACK_IMPORTED_MODULE_22__.IonCol, _ionic_angular__WEBPACK_IMPORTED_MODULE_22__.IonContent, _ionic_angular__WEBPACK_IMPORTED_MODULE_22__.IonHeader, _ionic_angular__WEBPACK_IMPORTED_MODULE_22__.IonItem, _ionic_angular__WEBPACK_IMPORTED_MODULE_22__.IonRow, _ionic_angular__WEBPACK_IMPORTED_MODULE_22__.IonSelect, _ionic_angular__WEBPACK_IMPORTED_MODULE_22__.IonSelectOption, _ionic_angular__WEBPACK_IMPORTED_MODULE_22__.SelectValueAccessor, _core_shared_layout_header_header_directive__WEBPACK_IMPORTED_MODULE_23__.HeaderDirective, _core_shared_layout_content_content_directive__WEBPACK_IMPORTED_MODULE_24__.ContentDirective, _core_shared_infinite_scroll_infinite_scroll_component__WEBPACK_IMPORTED_MODULE_25__.InfiniteScrollComponent, _core_shared_infinite_scroll_infinite_scroll_component__WEBPACK_IMPORTED_MODULE_25__.InfiniteScrollContentDirective, _school_placing_detail_school_placing_detail_component__WEBPACK_IMPORTED_MODULE_26__.SchoolPlacingDetailComponent, _angular_common__WEBPACK_IMPORTED_MODULE_21__.AsyncPipe, _ngx_translate_core__WEBPACK_IMPORTED_MODULE_27__.TranslatePipe],
    styles: ["ion-item[_ngcontent-%COMP%] {\n  width: 100%;\n}\nion-item[_ngcontent-%COMP%]   span[_ngcontent-%COMP%] {\n  width: 100%;\n}\n\n.empty-lead[_ngcontent-%COMP%] {\n  margin: auto;\n  padding: 8px;\n  font-size: 20px;\n  text-align: center;\n}\n/*# sourceMappingURL=data:application/json;charset=utf-8;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbIndlYnBhY2s6Ly8uL3NyYy9hcHAvcGFnZXMvaG9tZS9jYW1wYWlnbi1kZXRhaWxzL3NjaG9vbC1sZWFkZXJib2FyZC9zY2hvb2wtbGVhZGVyYm9hcmQucGFnZS5zY3NzIl0sIm5hbWVzIjpbXSwibWFwcGluZ3MiOiJBQUFBO0VBQ0UsV0FBQTtBQUNGO0FBQUU7RUFDRSxXQUFBO0FBRUo7O0FBQ0E7RUFDRSxZQUFBO0VBQ0EsWUFBQTtFQUNBLGVBQUE7RUFDQSxrQkFBQTtBQUVGIiwic291cmNlc0NvbnRlbnQiOlsiaW9uLWl0ZW0ge1xuICB3aWR0aDogMTAwJTtcbiAgc3BhbiB7XG4gICAgd2lkdGg6IDEwMCU7XG4gIH1cbn1cbi5lbXB0eS1sZWFkIHtcbiAgbWFyZ2luOiBhdXRvO1xuICBwYWRkaW5nOiA4cHg7XG4gIGZvbnQtc2l6ZTogMjBweDtcbiAgdGV4dC1hbGlnbjogY2VudGVyO1xufVxuIl0sInNvdXJjZVJvb3QiOiIifQ== */"]
  }));
}
_staticBlock();
const ALL_MEANS = 'ALL_MEANS';

/***/ }),

/***/ 73142:
/*!*********************************************************************************************!*\
  !*** ./src/app/pages/home/campaign-details/school-leaderboard/school-leaderboard.module.ts ***!
  \*********************************************************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   SchoolLeaderboardPageModule: () => (/* binding */ SchoolLeaderboardPageModule)
/* harmony export */ });
/* harmony import */ var _school_leaderboard_routing_module__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./school-leaderboard-routing.module */ 97991);
/* harmony import */ var _school_leaderboard_page__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ./school-leaderboard.page */ 71145);
/* harmony import */ var src_app_core_shared_shared_module__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! src/app/core/shared/shared.module */ 62657);
/* harmony import */ var _school_placing_detail_school_placing_detail_component__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! ./school-placing-detail/school-placing-detail.component */ 22208);
/* harmony import */ var _ionic_angular__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! @ionic/angular */ 21507);
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! @angular/core */ 34205);
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! @angular/core */ 12481);
var _staticBlock;






class SchoolLeaderboardPageModule {
  static #_ = _staticBlock = () => (this.ɵfac = function SchoolLeaderboardPageModule_Factory(__ngFactoryType__) {
    return new (__ngFactoryType__ || SchoolLeaderboardPageModule)();
  }, this.ɵmod = /*@__PURE__*/_angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵdefineNgModule"]({
    type: SchoolLeaderboardPageModule
  }), this.ɵinj = /*@__PURE__*/_angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵdefineInjector"]({
    imports: [_school_leaderboard_routing_module__WEBPACK_IMPORTED_MODULE_0__.SchoolLeaderboardPageRoutingModule, src_app_core_shared_shared_module__WEBPACK_IMPORTED_MODULE_2__.PlayGoSharedModule, _ionic_angular__WEBPACK_IMPORTED_MODULE_4__.IonicModule]
  }));
}
_staticBlock();
(function () {
  (typeof ngJitMode === "undefined" || ngJitMode) && _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵsetNgModuleScope"](SchoolLeaderboardPageModule, {
    declarations: [_school_leaderboard_page__WEBPACK_IMPORTED_MODULE_1__.SchoolLeaderboardPage, _school_placing_detail_school_placing_detail_component__WEBPACK_IMPORTED_MODULE_3__.SchoolPlacingDetailComponent],
    imports: [_school_leaderboard_routing_module__WEBPACK_IMPORTED_MODULE_0__.SchoolLeaderboardPageRoutingModule, src_app_core_shared_shared_module__WEBPACK_IMPORTED_MODULE_2__.PlayGoSharedModule, _ionic_angular__WEBPACK_IMPORTED_MODULE_4__.IonicModule]
  });
})();

/***/ }),

/***/ 97991:
/*!*****************************************************************************************************!*\
  !*** ./src/app/pages/home/campaign-details/school-leaderboard/school-leaderboard-routing.module.ts ***!
  \*****************************************************************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   SchoolLeaderboardPageRoutingModule: () => (/* binding */ SchoolLeaderboardPageRoutingModule)
/* harmony export */ });
/* harmony import */ var _angular_router__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! @angular/router */ 34487);
/* harmony import */ var _school_leaderboard_page__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ./school-leaderboard.page */ 71145);
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @angular/core */ 34205);
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @angular/core */ 12481);
var _staticBlock;




const routes = [{
  path: '',
  component: _school_leaderboard_page__WEBPACK_IMPORTED_MODULE_1__.SchoolLeaderboardPage,
  data: {
    title: 'leaderboard.title',
    color: 'school',
    backButton: true
  }
}];
class SchoolLeaderboardPageRoutingModule {
  static #_ = _staticBlock = () => (this.ɵfac = function SchoolLeaderboardPageRoutingModule_Factory(__ngFactoryType__) {
    return new (__ngFactoryType__ || SchoolLeaderboardPageRoutingModule)();
  }, this.ɵmod = /*@__PURE__*/_angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵdefineNgModule"]({
    type: SchoolLeaderboardPageRoutingModule
  }), this.ɵinj = /*@__PURE__*/_angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵdefineInjector"]({
    imports: [_angular_router__WEBPACK_IMPORTED_MODULE_0__.RouterModule.forChild(routes), _angular_router__WEBPACK_IMPORTED_MODULE_0__.RouterModule]
  }));
}
_staticBlock();
(function () {
  (typeof ngJitMode === "undefined" || ngJitMode) && _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵsetNgModuleScope"](SchoolLeaderboardPageRoutingModule, {
    imports: [_angular_router__WEBPACK_IMPORTED_MODULE_0__.RouterModule],
    exports: [_angular_router__WEBPACK_IMPORTED_MODULE_0__.RouterModule]
  });
})();

/***/ })

}]);
//# sourceMappingURL=src_app_pages_home_campaign-details_school-leaderboard_school-leaderboard_module_ts.js.map