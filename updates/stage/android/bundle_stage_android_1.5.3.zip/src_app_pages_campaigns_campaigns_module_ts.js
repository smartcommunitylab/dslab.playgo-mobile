"use strict";
(self["webpackChunkapp"] = self["webpackChunkapp"] || []).push([["src_app_pages_campaigns_campaigns_module_ts"],{

/***/ 10961:
/*!***************************************************!*\
  !*** ./src/app/pages/campaigns/campaigns.page.ts ***!
  \***************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   CampaignsPage: () => (/* binding */ CampaignsPage)
/* harmony export */ });
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! @angular/core */ 12481);
/* harmony import */ var src_app_core_shared_services_campaign_service__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! src/app/core/shared/services/campaign.service */ 76658);
/* harmony import */ var _ionic_angular__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @ionic/angular */ 21507);
/* harmony import */ var _core_shared_layout_header_header_directive__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! ../../core/shared/layout/header/header.directive */ 85039);
/* harmony import */ var _core_shared_layout_content_content_directive__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! ../../core/shared/layout/content/content.directive */ 75855);
/* harmony import */ var _all_campaign_all_campaign_component__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! ./all-campaign/all-campaign.component */ 96121);
var _staticBlock;






const _c0 = ["refresher"];
class CampaignsPage {
  constructor(campaignService) {
    this.campaignService = campaignService;
  }
  ngOnInit() {
    this.selectedSegment = 'publicCampaigns';
  }
  segmentChanged(ev) {
    console.log('Segment changed', ev);
  }
  static #_ = _staticBlock = () => (this.ɵfac = function CampaignsPage_Factory(__ngFactoryType__) {
    return new (__ngFactoryType__ || CampaignsPage)(_angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵdirectiveInject"](src_app_core_shared_services_campaign_service__WEBPACK_IMPORTED_MODULE_1__.CampaignService));
  }, this.ɵcmp = /*@__PURE__*/_angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵdefineComponent"]({
    type: CampaignsPage,
    selectors: [["app-campaigns"]],
    viewQuery: function CampaignsPage_Query(rf, ctx) {
      if (rf & 1) {
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵviewQuery"](_c0, 5);
      }
      if (rf & 2) {
        let _t;
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵqueryRefresh"](_t = _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵloadQuery"]()) && (ctx.refresher = _t.first);
      }
    },
    standalone: false,
    decls: 3,
    vars: 1,
    consts: [["appHeader", ""], ["appContent", "", 1, "page", 3, "fullscreen"]],
    template: function CampaignsPage_Template(rf, ctx) {
      if (rf & 1) {
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelement"](0, "ion-header", 0);
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](1, "ion-content", 1);
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelement"](2, "app-all-campaign");
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();
      }
      if (rf & 2) {
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵadvance"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵproperty"]("fullscreen", true);
      }
    },
    dependencies: [_ionic_angular__WEBPACK_IMPORTED_MODULE_2__.IonContent, _ionic_angular__WEBPACK_IMPORTED_MODULE_2__.IonHeader, _core_shared_layout_header_header_directive__WEBPACK_IMPORTED_MODULE_3__.HeaderDirective, _core_shared_layout_content_content_directive__WEBPACK_IMPORTED_MODULE_4__.ContentDirective, _all_campaign_all_campaign_component__WEBPACK_IMPORTED_MODULE_5__.AllCampaignComponent],
    styles: ["/*# sourceMappingURL=data:application/json;charset=utf-8;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbXSwibmFtZXMiOltdLCJtYXBwaW5ncyI6IiIsInNvdXJjZVJvb3QiOiIifQ== */"]
  }));
}
_staticBlock();

/***/ }),

/***/ 13422:
/*!*****************************************************!*\
  !*** ./src/app/pages/campaigns/campaigns.module.ts ***!
  \*****************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   CampaignsPageModule: () => (/* binding */ CampaignsPageModule)
/* harmony export */ });
/* harmony import */ var _campaigns_page__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./campaigns.page */ 10961);
/* harmony import */ var _campaigns_routing_module__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ./campaigns-routing.module */ 87839);
/* harmony import */ var src_app_core_shared_shared_module__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! src/app/core/shared/shared.module */ 62657);
/* harmony import */ var _my_campaign_my_campaign_component__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! ./my-campaign/my-campaign.component */ 44475);
/* harmony import */ var _all_campaign_all_campaign_component__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! ./all-campaign/all-campaign.component */ 96121);
/* harmony import */ var _ionic_angular__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! @ionic/angular */ 21507);
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! @angular/core */ 34205);
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(/*! @angular/core */ 12481);
var _staticBlock;







class CampaignsPageModule {
  static #_ = _staticBlock = () => (this.ɵfac = function CampaignsPageModule_Factory(__ngFactoryType__) {
    return new (__ngFactoryType__ || CampaignsPageModule)();
  }, this.ɵmod = /*@__PURE__*/_angular_core__WEBPACK_IMPORTED_MODULE_7__["ɵɵdefineNgModule"]({
    type: CampaignsPageModule
  }), this.ɵinj = /*@__PURE__*/_angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵdefineInjector"]({
    imports: [src_app_core_shared_shared_module__WEBPACK_IMPORTED_MODULE_2__.PlayGoSharedModule, _campaigns_routing_module__WEBPACK_IMPORTED_MODULE_1__.CampaignsRoutingModule, _ionic_angular__WEBPACK_IMPORTED_MODULE_5__.IonicModule]
  }));
}
_staticBlock();
(function () {
  (typeof ngJitMode === "undefined" || ngJitMode) && _angular_core__WEBPACK_IMPORTED_MODULE_7__["ɵɵsetNgModuleScope"](CampaignsPageModule, {
    declarations: [_campaigns_page__WEBPACK_IMPORTED_MODULE_0__.CampaignsPage, _my_campaign_my_campaign_component__WEBPACK_IMPORTED_MODULE_3__.MyCampaignComponent, _all_campaign_all_campaign_component__WEBPACK_IMPORTED_MODULE_4__.AllCampaignComponent],
    imports: [src_app_core_shared_shared_module__WEBPACK_IMPORTED_MODULE_2__.PlayGoSharedModule, _campaigns_routing_module__WEBPACK_IMPORTED_MODULE_1__.CampaignsRoutingModule, _ionic_angular__WEBPACK_IMPORTED_MODULE_5__.IonicModule]
  });
})();

/***/ }),

/***/ 44475:
/*!**********************************************************************!*\
  !*** ./src/app/pages/campaigns/my-campaign/my-campaign.component.ts ***!
  \**********************************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   MyCampaignComponent: () => (/* binding */ MyCampaignComponent)
/* harmony export */ });
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! @angular/core */ 12481);
/* harmony import */ var src_app_core_shared_services_campaign_service__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! src/app/core/shared/services/campaign.service */ 76658);
/* harmony import */ var _angular_common__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @angular/common */ 93683);
/* harmony import */ var _ionic_angular__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @ionic/angular */ 21507);
/* harmony import */ var _core_shared_campaigns_my_campaign_card_my_campaign_card_component__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! ../../../core/shared/campaigns/my-campaign-card/my-campaign-card.component */ 40508);
/* harmony import */ var _ngx_translate_core__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! @ngx-translate/core */ 48503);
var _staticBlock;






function MyCampaignComponent_div_0_ion_row_3_ion_col_1_Template(rf, ctx) {
  if (rf & 1) {
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](0, "ion-col", 3);
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelement"](1, "app-my-campaign-card", 4);
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();
  }
  if (rf & 2) {
    const campaign_r1 = _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵnextContext"]().$implicit;
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵadvance"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵproperty"]("containerCampaign", campaign_r1);
  }
}
function MyCampaignComponent_div_0_ion_row_3_Template(rf, ctx) {
  if (rf & 1) {
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](0, "ion-row");
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵtemplate"](1, MyCampaignComponent_div_0_ion_row_3_ion_col_1_Template, 2, 1, "ion-col", 2);
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();
  }
  if (rf & 2) {
    const campaign_r1 = ctx.$implicit;
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵadvance"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵproperty"]("ngIf", campaign_r1);
  }
}
function MyCampaignComponent_div_0_Template(rf, ctx) {
  if (rf & 1) {
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](0, "div")(1, "ion-list")(2, "ion-grid");
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵtemplate"](3, MyCampaignComponent_div_0_ion_row_3_Template, 2, 1, "ion-row", 1);
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]()()();
  }
  if (rf & 2) {
    const ctx_r1 = _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵnextContext"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵadvance"](3);
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵproperty"]("ngForOf", ctx_r1.myCampaigns);
  }
}
function MyCampaignComponent_div_1_Template(rf, ctx) {
  if (rf & 1) {
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](0, "div")(1, "ion-grid")(2, "ion-row")(3, "ion-col")(4, "ion-card")(5, "ion-card-header")(6, "strong");
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵtext"](7);
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵpipe"](8, "translate");
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]()()()()()()();
  }
  if (rf & 2) {
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵadvance"](7);
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵtextInterpolate"](_angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵpipeBind1"](8, 1, "noCampaigns"));
  }
}
class MyCampaignComponent {
  constructor(campaignService) {
    this.campaignService = campaignService;
  }
  ngOnInit() {
    this.sub = this.campaignService.myCampaigns$.subscribe(campaigns => {
      this.myCampaigns = campaigns;
    });
  }
  ngOnDestroy() {
    this.sub.unsubscribe();
  }
  joinCampaign(id) {
    console.log('joining the campaign', id);
  }
  static #_ = _staticBlock = () => (this.ɵfac = function MyCampaignComponent_Factory(__ngFactoryType__) {
    return new (__ngFactoryType__ || MyCampaignComponent)(_angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵdirectiveInject"](src_app_core_shared_services_campaign_service__WEBPACK_IMPORTED_MODULE_1__.CampaignService));
  }, this.ɵcmp = /*@__PURE__*/_angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵdefineComponent"]({
    type: MyCampaignComponent,
    selectors: [["app-my-campaign"]],
    standalone: false,
    decls: 2,
    vars: 2,
    consts: [[4, "ngIf"], [4, "ngFor", "ngForOf"], ["size-md", "6", "offset-md", "3", 4, "ngIf"], ["size-md", "6", "offset-md", "3"], [3, "containerCampaign"]],
    template: function MyCampaignComponent_Template(rf, ctx) {
      if (rf & 1) {
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵtemplate"](0, MyCampaignComponent_div_0_Template, 4, 1, "div", 0)(1, MyCampaignComponent_div_1_Template, 9, 3, "div", 0);
      }
      if (rf & 2) {
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵproperty"]("ngIf", ctx.myCampaigns !== undefined && ctx.myCampaigns.length > 0);
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵadvance"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵproperty"]("ngIf", ctx.myCampaigns === undefined || ctx.myCampaigns.length === 0);
      }
    },
    dependencies: [_angular_common__WEBPACK_IMPORTED_MODULE_2__.NgForOf, _angular_common__WEBPACK_IMPORTED_MODULE_2__.NgIf, _ionic_angular__WEBPACK_IMPORTED_MODULE_3__.IonCard, _ionic_angular__WEBPACK_IMPORTED_MODULE_3__.IonCardHeader, _ionic_angular__WEBPACK_IMPORTED_MODULE_3__.IonCol, _ionic_angular__WEBPACK_IMPORTED_MODULE_3__.IonGrid, _ionic_angular__WEBPACK_IMPORTED_MODULE_3__.IonList, _ionic_angular__WEBPACK_IMPORTED_MODULE_3__.IonRow, _core_shared_campaigns_my_campaign_card_my_campaign_card_component__WEBPACK_IMPORTED_MODULE_4__.MyCampaignCardComponent, _ngx_translate_core__WEBPACK_IMPORTED_MODULE_5__.TranslatePipe],
    styles: ["/*# sourceMappingURL=data:application/json;charset=utf-8;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbXSwibmFtZXMiOltdLCJtYXBwaW5ncyI6IiIsInNvdXJjZVJvb3QiOiIifQ== */"]
  }));
}
_staticBlock();

/***/ }),

/***/ 87839:
/*!*************************************************************!*\
  !*** ./src/app/pages/campaigns/campaigns-routing.module.ts ***!
  \*************************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   CampaignsRoutingModule: () => (/* binding */ CampaignsRoutingModule)
/* harmony export */ });
/* harmony import */ var _angular_router__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! @angular/router */ 34487);
/* harmony import */ var _campaigns_page__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ./campaigns.page */ 10961);
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @angular/core */ 34205);
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @angular/core */ 12481);
var _staticBlock;




const routes = [{
  path: '',
  component: _campaigns_page__WEBPACK_IMPORTED_MODULE_1__.CampaignsPage,
  data: {
    title: 'campaigns_title',
    backButton: false,
    showPlayButton: true,
    refresher: true
  }
}, {
  path: 'join/:id',
  loadChildren: () => __webpack_require__.e(/*! import() */ "src_app_pages_campaigns_campaign-join_campaign-join_module_ts").then(__webpack_require__.bind(__webpack_require__, /*! ./campaign-join/campaign-join.module */ 8682)).then(m => m.CampaignJoinPageModule)
}];
class CampaignsRoutingModule {
  static #_ = _staticBlock = () => (this.ɵfac = function CampaignsRoutingModule_Factory(__ngFactoryType__) {
    return new (__ngFactoryType__ || CampaignsRoutingModule)();
  }, this.ɵmod = /*@__PURE__*/_angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵdefineNgModule"]({
    type: CampaignsRoutingModule
  }), this.ɵinj = /*@__PURE__*/_angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵdefineInjector"]({
    imports: [_angular_router__WEBPACK_IMPORTED_MODULE_0__.RouterModule.forChild(routes), _angular_router__WEBPACK_IMPORTED_MODULE_0__.RouterModule]
  }));
}
_staticBlock();
(function () {
  (typeof ngJitMode === "undefined" || ngJitMode) && _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵsetNgModuleScope"](CampaignsRoutingModule, {
    imports: [_angular_router__WEBPACK_IMPORTED_MODULE_0__.RouterModule],
    exports: [_angular_router__WEBPACK_IMPORTED_MODULE_0__.RouterModule]
  });
})();

/***/ }),

/***/ 96121:
/*!************************************************************************!*\
  !*** ./src/app/pages/campaigns/all-campaign/all-campaign.component.ts ***!
  \************************************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   AllCampaignComponent: () => (/* binding */ AllCampaignComponent)
/* harmony export */ });
/* harmony import */ var rxjs__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! rxjs */ 19999);
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @angular/core */ 12481);
/* harmony import */ var src_app_core_shared_services_campaign_service__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! src/app/core/shared/services/campaign.service */ 76658);
/* harmony import */ var _angular_common__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @angular/common */ 93683);
/* harmony import */ var _ionic_angular__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! @ionic/angular */ 21507);
/* harmony import */ var _core_shared_campaigns_public_campaign_card_public_campaign_card_component__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! ../../../core/shared/campaigns/public-campaign-card/public-campaign-card.component */ 47550);
/* harmony import */ var _ngx_translate_core__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! @ngx-translate/core */ 48503);
var _staticBlock;







function AllCampaignComponent_div_0_ion_row_3_ion_col_1_Template(rf, ctx) {
  if (rf & 1) {
    _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵelementStart"](0, "ion-col", 3);
    _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵelement"](1, "app-public-campaign-card", 4);
    _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵelementEnd"]();
  }
  if (rf & 2) {
    const campaign_r1 = _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵnextContext"]().$implicit;
    _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵadvance"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵproperty"]("campaign", campaign_r1);
  }
}
function AllCampaignComponent_div_0_ion_row_3_Template(rf, ctx) {
  if (rf & 1) {
    _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵelementStart"](0, "ion-row");
    _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵtemplate"](1, AllCampaignComponent_div_0_ion_row_3_ion_col_1_Template, 2, 1, "ion-col", 2);
    _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵelementEnd"]();
  }
  if (rf & 2) {
    const campaign_r1 = ctx.$implicit;
    _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵadvance"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵproperty"]("ngIf", campaign_r1);
  }
}
function AllCampaignComponent_div_0_Template(rf, ctx) {
  if (rf & 1) {
    _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵelementStart"](0, "div")(1, "ion-list")(2, "ion-grid");
    _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵtemplate"](3, AllCampaignComponent_div_0_ion_row_3_Template, 2, 1, "ion-row", 1);
    _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵelementEnd"]()()();
  }
  if (rf & 2) {
    const ctx_r1 = _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵnextContext"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵadvance"](3);
    _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵproperty"]("ngForOf", ctx_r1.allCampaigns);
  }
}
function AllCampaignComponent_div_1_Template(rf, ctx) {
  if (rf & 1) {
    _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵelementStart"](0, "div")(1, "ion-grid")(2, "ion-row")(3, "ion-col")(4, "div", 5)(5, "strong");
    _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵtext"](6);
    _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵpipe"](7, "translate");
    _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵelementEnd"]()()()()()();
  }
  if (rf & 2) {
    _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵadvance"](6);
    _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵtextInterpolate1"](" ", _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵpipeBind1"](7, 1, "noOtherCampaigns"));
  }
}
class AllCampaignComponent {
  constructor(campaignService) {
    this.campaignService = campaignService;
    this.numberPage = 0;
  }
  ngOnInit() {
    this.sub = (0,rxjs__WEBPACK_IMPORTED_MODULE_0__.combineLatest)([this.campaignService.myCampaigns$, this.campaignService.allCampaigns$]).subscribe(([my, all]) => {
      this.allCampaigns = all.filter(allCampaign => !my.find(myCampaign => allCampaign.campaignId === myCampaign.campaign.campaignId));
    });
  }
  ngOnDestroy() {
    this.sub.unsubscribe();
  }
  joinCampaign(id) {
    console.log('joining the campaign', id);
  }
  static #_ = _staticBlock = () => (this.ɵfac = function AllCampaignComponent_Factory(__ngFactoryType__) {
    return new (__ngFactoryType__ || AllCampaignComponent)(_angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵdirectiveInject"](src_app_core_shared_services_campaign_service__WEBPACK_IMPORTED_MODULE_2__.CampaignService));
  }, this.ɵcmp = /*@__PURE__*/_angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵdefineComponent"]({
    type: AllCampaignComponent,
    selectors: [["app-all-campaign"]],
    standalone: false,
    decls: 2,
    vars: 2,
    consts: [[4, "ngIf"], [4, "ngFor", "ngForOf"], ["size-md", "6", "offset-md", "3", 4, "ngIf"], ["size-md", "6", "offset-md", "3"], [3, "campaign"], [1, "empty-campaigns"]],
    template: function AllCampaignComponent_Template(rf, ctx) {
      if (rf & 1) {
        _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵtemplate"](0, AllCampaignComponent_div_0_Template, 4, 1, "div", 0)(1, AllCampaignComponent_div_1_Template, 8, 3, "div", 0);
      }
      if (rf & 2) {
        _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵproperty"]("ngIf", ctx.allCampaigns !== undefined && ctx.allCampaigns.length > 0);
        _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵadvance"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵproperty"]("ngIf", ctx.allCampaigns !== undefined && ctx.allCampaigns.length === 0);
      }
    },
    dependencies: [_angular_common__WEBPACK_IMPORTED_MODULE_3__.NgForOf, _angular_common__WEBPACK_IMPORTED_MODULE_3__.NgIf, _ionic_angular__WEBPACK_IMPORTED_MODULE_4__.IonCol, _ionic_angular__WEBPACK_IMPORTED_MODULE_4__.IonGrid, _ionic_angular__WEBPACK_IMPORTED_MODULE_4__.IonList, _ionic_angular__WEBPACK_IMPORTED_MODULE_4__.IonRow, _core_shared_campaigns_public_campaign_card_public_campaign_card_component__WEBPACK_IMPORTED_MODULE_5__.PublicCampaignCardComponent, _ngx_translate_core__WEBPACK_IMPORTED_MODULE_6__.TranslatePipe],
    styles: [".empty-campaigns[_ngcontent-%COMP%] {\n  margin: auto;\n  padding: 8px;\n  font-size: 20px;\n  text-align: center;\n}\n/*# sourceMappingURL=data:application/json;charset=utf-8;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbIndlYnBhY2s6Ly8uL3NyYy9hcHAvcGFnZXMvY2FtcGFpZ25zL2FsbC1jYW1wYWlnbi9hbGwtY2FtcGFpZ24uY29tcG9uZW50LnNjc3MiXSwibmFtZXMiOltdLCJtYXBwaW5ncyI6IkFBQUE7RUFDRSxZQUFBO0VBQ0EsWUFBQTtFQUNBLGVBQUE7RUFDQSxrQkFBQTtBQUNGIiwic291cmNlc0NvbnRlbnQiOlsiLmVtcHR5LWNhbXBhaWducyB7XG4gIG1hcmdpbjogYXV0bztcbiAgcGFkZGluZzogOHB4O1xuICBmb250LXNpemU6IDIwcHg7XG4gIHRleHQtYWxpZ246IGNlbnRlcjtcbn1cbiJdLCJzb3VyY2VSb290IjoiIn0= */"]
  }));
}
_staticBlock();

/***/ })

}]);
//# sourceMappingURL=src_app_pages_campaigns_campaigns_module_ts.js.map