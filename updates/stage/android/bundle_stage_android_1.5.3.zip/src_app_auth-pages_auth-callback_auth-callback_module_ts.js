"use strict";
(self["webpackChunkapp"] = self["webpackChunkapp"] || []).push([["src_app_auth-pages_auth-callback_auth-callback_module_ts"],{

/***/ 34038:
/*!****************************************************************!*\
  !*** ./src/app/auth-pages/auth-callback/auth-callback.page.ts ***!
  \****************************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   AuthCallbackPage: () => (/* binding */ AuthCallbackPage)
/* harmony export */ });
/* harmony import */ var _ionic_angular__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! @ionic/angular */ 3920);
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @angular/core */ 12481);
/* harmony import */ var src_app_core_auth_auth_service__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! src/app/core/auth/auth.service */ 35524);
/* harmony import */ var src_app_core_shared_services_auth_flow_service__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! src/app/core/shared/services/auth-flow.service */ 58073);
/* harmony import */ var _angular_router__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! @angular/router */ 85422);
/* harmony import */ var _ngx_translate_core__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! @ngx-translate/core */ 48503);
var _staticBlock;






class AuthCallbackPage {
  constructor(authService, authFlowService, router) {
    this.authService = authService;
    this.authFlowService = authFlowService;
    this.router = router;
  }
  ngOnInit() {
    const url = window.location.href;
    const urlObj = new URL(url);
    const state = urlObj.searchParams.get('state');
    const isTempCallback = state?.startsWith('temp_');
    if (!(0,_ionic_angular__WEBPACK_IMPORTED_MODULE_0__.isPlatform)('capacitor')) {
      if (isTempCallback) {
        console.log('Processing temporary callback');
        this.authFlowService.handleTemporaryAuthCallback(url);
        // Recupera l'ID della campagna salvato
        const campaignId = sessionStorage.getItem('pending_campaign_id');
        if (campaignId) {
          // Segnala successo
          sessionStorage.setItem('temp_auth_success', 'true');
          // Naviga alla pagina specifica della campagna
          setTimeout(() => {
            this.router.navigate(['/pages/tabs/campaigns/join', campaignId]);
          }, 1500);
        } else {
          // Fallback: vai alla lista campagne
          console.warn('No campaign ID found, navigating to campaigns list');
          setTimeout(() => {
            this.router.navigate(['/pages/tabs/campaigns']);
          }, 1500);
        }
      } else {
        // Callback login principale
        this.authService.authorizationCallback();
        setTimeout(() => {
          this.router.navigate(['/pages/tabs/home']);
        }, 1000);
      }
    } else {
      // Native callback
      if (isTempCallback) {
        this.authFlowService.handleTemporaryAuthCallback(url);
      } else {
        this.authService.authorizationCallback();
        setTimeout(() => {
          this.router.navigate(['/pages/tabs/home']);
        }, 500);
      }
    }
  }
  static #_ = _staticBlock = () => (this.ɵfac = function AuthCallbackPage_Factory(__ngFactoryType__) {
    return new (__ngFactoryType__ || AuthCallbackPage)(_angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵdirectiveInject"](src_app_core_auth_auth_service__WEBPACK_IMPORTED_MODULE_2__.AuthService), _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵdirectiveInject"](src_app_core_shared_services_auth_flow_service__WEBPACK_IMPORTED_MODULE_3__.AuthFlowService), _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵdirectiveInject"](_angular_router__WEBPACK_IMPORTED_MODULE_4__.Router));
  }, this.ɵcmp = /*@__PURE__*/_angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵdefineComponent"]({
    type: AuthCallbackPage,
    selectors: [["ng-component"]],
    standalone: false,
    decls: 3,
    vars: 3,
    template: function AuthCallbackPage_Template(rf, ctx) {
      if (rf & 1) {
        _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵelementStart"](0, "p");
        _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵtext"](1);
        _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵpipe"](2, "translate");
        _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵelementEnd"]();
      }
      if (rf & 2) {
        _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵadvance"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵtextInterpolate"](_angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵpipeBind1"](2, 1, "login.labelSignin"));
      }
    },
    dependencies: [_ngx_translate_core__WEBPACK_IMPORTED_MODULE_5__.TranslatePipe],
    encapsulation: 2
  }));
}
_staticBlock();

/***/ }),

/***/ 37261:
/*!******************************************************************!*\
  !*** ./src/app/auth-pages/auth-callback/auth-callback.module.ts ***!
  \******************************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   AuthCallbackPageModule: () => (/* binding */ AuthCallbackPageModule)
/* harmony export */ });
/* harmony import */ var _angular_router__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! @angular/router */ 34487);
/* harmony import */ var _ionic_angular__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @ionic/angular */ 21507);
/* harmony import */ var _auth_callback_page__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! ./auth-callback.page */ 34038);
/* harmony import */ var src_app_core_shared_shared_libs_module__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! src/app/core/shared/shared-libs.module */ 64412);
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! @angular/core */ 34205);
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! @angular/core */ 12481);
var _staticBlock;






const routes = [{
  path: '',
  component: _auth_callback_page__WEBPACK_IMPORTED_MODULE_2__.AuthCallbackPage,
  data: {
    title: 'login.labelSignin'
  }
}];
class AuthCallbackPageModule {
  static #_ = _staticBlock = () => (this.ɵfac = function AuthCallbackPageModule_Factory(__ngFactoryType__) {
    return new (__ngFactoryType__ || AuthCallbackPageModule)();
  }, this.ɵmod = /*@__PURE__*/_angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵdefineNgModule"]({
    type: AuthCallbackPageModule
  }), this.ɵinj = /*@__PURE__*/_angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵdefineInjector"]({
    imports: [src_app_core_shared_shared_libs_module__WEBPACK_IMPORTED_MODULE_3__.PlayGoSharedLibsModule, _ionic_angular__WEBPACK_IMPORTED_MODULE_1__.IonicModule, _angular_router__WEBPACK_IMPORTED_MODULE_0__.RouterModule.forChild(routes)]
  }));
}
_staticBlock();
(function () {
  (typeof ngJitMode === "undefined" || ngJitMode) && _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵsetNgModuleScope"](AuthCallbackPageModule, {
    declarations: [_auth_callback_page__WEBPACK_IMPORTED_MODULE_2__.AuthCallbackPage],
    imports: [src_app_core_shared_shared_libs_module__WEBPACK_IMPORTED_MODULE_3__.PlayGoSharedLibsModule, _ionic_angular__WEBPACK_IMPORTED_MODULE_1__.IonicModule, _angular_router__WEBPACK_IMPORTED_MODULE_0__.RouterModule]
  });
})();

/***/ })

}]);
//# sourceMappingURL=src_app_auth-pages_auth-callback_auth-callback_module_ts.js.map