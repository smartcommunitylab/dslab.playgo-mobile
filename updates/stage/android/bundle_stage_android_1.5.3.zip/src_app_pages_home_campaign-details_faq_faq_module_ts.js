"use strict";
(self["webpackChunkapp"] = self["webpackChunkapp"] || []).push([["src_app_pages_home_campaign-details_faq_faq_module_ts"],{

/***/ 1668:
/*!***************************************************************!*\
  !*** ./src/app/pages/home/campaign-details/faq/faq.module.ts ***!
  \***************************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   FaqPageModule: () => (/* binding */ FaqPageModule)
/* harmony export */ });
/* harmony import */ var src_app_core_shared_shared_module__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! src/app/core/shared/shared.module */ 62657);
/* harmony import */ var _faq_routing_module__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ./faq-routing.module */ 84989);
/* harmony import */ var _faq_page__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! ./faq.page */ 17103);
/* harmony import */ var _ionic_angular__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @ionic/angular */ 21507);
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! @angular/core */ 34205);
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! @angular/core */ 12481);
var _staticBlock;





class FaqPageModule {
  static #_ = _staticBlock = () => (this.ɵfac = function FaqPageModule_Factory(__ngFactoryType__) {
    return new (__ngFactoryType__ || FaqPageModule)();
  }, this.ɵmod = /*@__PURE__*/_angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵdefineNgModule"]({
    type: FaqPageModule
  }), this.ɵinj = /*@__PURE__*/_angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵdefineInjector"]({
    imports: [src_app_core_shared_shared_module__WEBPACK_IMPORTED_MODULE_0__.PlayGoSharedModule, _faq_routing_module__WEBPACK_IMPORTED_MODULE_1__.FaqPageRoutingModule, _ionic_angular__WEBPACK_IMPORTED_MODULE_3__.IonicModule]
  }));
}
_staticBlock();
(function () {
  (typeof ngJitMode === "undefined" || ngJitMode) && _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵsetNgModuleScope"](FaqPageModule, {
    declarations: [_faq_page__WEBPACK_IMPORTED_MODULE_2__.FaqPage],
    imports: [src_app_core_shared_shared_module__WEBPACK_IMPORTED_MODULE_0__.PlayGoSharedModule, _faq_routing_module__WEBPACK_IMPORTED_MODULE_1__.FaqPageRoutingModule, _ionic_angular__WEBPACK_IMPORTED_MODULE_3__.IonicModule]
  });
})();

/***/ }),

/***/ 17103:
/*!*************************************************************!*\
  !*** ./src/app/pages/home/campaign-details/faq/faq.page.ts ***!
  \*************************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   FaqPage: () => (/* binding */ FaqPage)
/* harmony export */ });
/* harmony import */ var rxjs__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! rxjs */ 70271);
/* harmony import */ var rxjs__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! rxjs */ 86301);
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @angular/core */ 12481);
/* harmony import */ var _angular_router__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @angular/router */ 85422);
/* harmony import */ var src_app_core_shared_services_campaign_service__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! src/app/core/shared/services/campaign.service */ 76658);
/* harmony import */ var src_app_core_shared_services_page_settings_service__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! src/app/core/shared/services/page-settings.service */ 40147);
/* harmony import */ var src_app_core_shared_services_user_service__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! src/app/core/shared/services/user.service */ 89815);
/* harmony import */ var _ionic_angular__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(/*! @ionic/angular */ 21507);
/* harmony import */ var _core_shared_layout_header_header_directive__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(/*! ../../../../core/shared/layout/header/header.directive */ 85039);
var _staticBlock;








class FaqPage {
  constructor(route, campaignService, pageSettingsService, userService) {
    this.route = route;
    this.campaignService = campaignService;
    this.pageSettingsService = pageSettingsService;
    this.userService = userService;
    this.campaignId$ = this.route.params.pipe((0,rxjs__WEBPACK_IMPORTED_MODULE_0__.map)(params => params.id), (0,rxjs__WEBPACK_IMPORTED_MODULE_1__.shareReplay)(1));
  }
  ngOnInit() {
    this.language = this.userService.getLanguage();
    this.subCampaignId = this.campaignId$.subscribe(campaignId => {
      this.subCampaignContainer = this.campaignService.myCampaigns$.subscribe(campaigns => {
        this.campaignContainer = campaigns.find(campaignContainer => campaignContainer.campaign.campaignId === campaignId);
        if (this.campaignContainer) {
          this.detailFaq = this.campaignContainer?.campaign?.details[this.language]?.filter(detail => detail.type === 'faq')[0];
          this.changePageSettings();
        }
      });
    });
  }
  changePageSettings() {
    this.pageSettingsService.set({
      color: this.campaignContainer?.campaign?.type
    });
  }
  ngOnDestroy() {}
  ionViewDidLeave() {
    this.subCampaignContainer.unsubscribe();
    this.subCampaignId.unsubscribe();
  }
  static #_ = _staticBlock = () => (this.ɵfac = function FaqPage_Factory(__ngFactoryType__) {
    return new (__ngFactoryType__ || FaqPage)(_angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵdirectiveInject"](_angular_router__WEBPACK_IMPORTED_MODULE_3__.ActivatedRoute), _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵdirectiveInject"](src_app_core_shared_services_campaign_service__WEBPACK_IMPORTED_MODULE_4__.CampaignService), _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵdirectiveInject"](src_app_core_shared_services_page_settings_service__WEBPACK_IMPORTED_MODULE_5__.PageSettingsService), _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵdirectiveInject"](src_app_core_shared_services_user_service__WEBPACK_IMPORTED_MODULE_6__.UserService));
  }, this.ɵcmp = /*@__PURE__*/_angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵdefineComponent"]({
    type: FaqPage,
    selectors: [["app-faq-page"]],
    standalone: false,
    decls: 3,
    vars: 1,
    consts: [["appHeader", ""], [1, "ion-padding"], [3, "innerHTML"]],
    template: function FaqPage_Template(rf, ctx) {
      if (rf & 1) {
        _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵelement"](0, "ion-header", 0);
        _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵelementStart"](1, "ion-content", 1);
        _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵelement"](2, "div", 2);
        _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵelementEnd"]();
      }
      if (rf & 2) {
        _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵadvance"](2);
        _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵproperty"]("innerHTML", ctx.detailFaq == null ? null : ctx.detailFaq.content, _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵsanitizeHtml"]);
      }
    },
    dependencies: [_ionic_angular__WEBPACK_IMPORTED_MODULE_7__.IonContent, _ionic_angular__WEBPACK_IMPORTED_MODULE_7__.IonHeader, _core_shared_layout_header_header_directive__WEBPACK_IMPORTED_MODULE_8__.HeaderDirective],
    styles: ["/*# sourceMappingURL=data:application/json;charset=utf-8;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbXSwibmFtZXMiOltdLCJtYXBwaW5ncyI6IiIsInNvdXJjZVJvb3QiOiIifQ== */"]
  }));
}
_staticBlock();

/***/ }),

/***/ 84989:
/*!***********************************************************************!*\
  !*** ./src/app/pages/home/campaign-details/faq/faq-routing.module.ts ***!
  \***********************************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   FaqPageRoutingModule: () => (/* binding */ FaqPageRoutingModule)
/* harmony export */ });
/* harmony import */ var _angular_router__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! @angular/router */ 34487);
/* harmony import */ var _faq_page__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ./faq.page */ 17103);
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @angular/core */ 34205);
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @angular/core */ 12481);
var _staticBlock;




const routes = [{
  path: '',
  component: _faq_page__WEBPACK_IMPORTED_MODULE_1__.FaqPage,
  data: {
    title: 'campaigns.detail.faq'
  }
}];
class FaqPageRoutingModule {
  static #_ = _staticBlock = () => (this.ɵfac = function FaqPageRoutingModule_Factory(__ngFactoryType__) {
    return new (__ngFactoryType__ || FaqPageRoutingModule)();
  }, this.ɵmod = /*@__PURE__*/_angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵdefineNgModule"]({
    type: FaqPageRoutingModule
  }), this.ɵinj = /*@__PURE__*/_angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵdefineInjector"]({
    imports: [_angular_router__WEBPACK_IMPORTED_MODULE_0__.RouterModule.forChild(routes), _angular_router__WEBPACK_IMPORTED_MODULE_0__.RouterModule]
  }));
}
_staticBlock();
(function () {
  (typeof ngJitMode === "undefined" || ngJitMode) && _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵsetNgModuleScope"](FaqPageRoutingModule, {
    imports: [_angular_router__WEBPACK_IMPORTED_MODULE_0__.RouterModule],
    exports: [_angular_router__WEBPACK_IMPORTED_MODULE_0__.RouterModule]
  });
})();

/***/ })

}]);
//# sourceMappingURL=src_app_pages_home_campaign-details_faq_faq_module_ts.js.map