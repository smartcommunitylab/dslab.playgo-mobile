"use strict";
(self["webpackChunkapp"] = self["webpackChunkapp"] || []).push([["src_app_pages_challenges_create-challenge_create-challenge_module_ts"],{

/***/ 431:
/*!************************************************************************************************************!*\
  !*** ./src/app/pages/challenges/create-challenge/select-challenge-mean/select-challenge-mean.component.ts ***!
  \************************************************************************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   SelectChallengeMeanComponent: () => (/* binding */ SelectChallengeMeanComponent)
/* harmony export */ });
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! @angular/core */ 12481);
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @angular/core */ 34205);
/* harmony import */ var _angular_common__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @angular/common */ 93683);
/* harmony import */ var _core_shared_ui_icon_icon_component__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! ../../../../core/shared/ui/icon/icon.component */ 59621);
/* harmony import */ var _ngx_translate_core__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! @ngx-translate/core */ 48503);
var _staticBlock;





function SelectChallengeMeanComponent_div_1_Template(rf, ctx) {
  if (rf & 1) {
    const _r1 = _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵgetCurrentView"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](0, "div", 2);
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵpipe"](1, "translate");
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵlistener"]("click", function SelectChallengeMeanComponent_div_1_Template_div_click_0_listener() {
      const mean_r2 = _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵrestoreView"](_r1).$implicit;
      const ctx_r2 = _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵnextContext"]();
      return _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵresetView"](ctx_r2.selectMean(mean_r2));
    });
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelement"](2, "app-icon", 3);
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();
  }
  if (rf & 2) {
    const mean_r2 = ctx.$implicit;
    const ctx_r2 = _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵnextContext"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵclassProp"]("selected", mean_r2.name === ctx_r2.selectedMeanName);
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵproperty"]("title", _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵinterpolate"](_angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵpipeBind1"](1, 5, mean_r2.title)));
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵadvance"](2);
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵproperty"]("name", mean_r2.icon);
  }
}
class SelectChallengeMeanComponent {
  constructor() {
    this.selectedMean = new _angular_core__WEBPACK_IMPORTED_MODULE_0__.EventEmitter();
  }
  ngOnInit() {}
  selectMean(model) {
    this.selectedMeanName = model.name;
    this.selectedMean.emit(this.selectedMeanName);
  }
  static #_ = _staticBlock = () => (this.ɵfac = function SelectChallengeMeanComponent_Factory(__ngFactoryType__) {
    return new (__ngFactoryType__ || SelectChallengeMeanComponent)();
  }, this.ɵcmp = /*@__PURE__*/_angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵdefineComponent"]({
    type: SelectChallengeMeanComponent,
    selectors: [["app-select-challenge-mean"]],
    inputs: {
      availableMeans: "availableMeans"
    },
    outputs: {
      selectedMean: "selectedMean"
    },
    standalone: false,
    decls: 2,
    vars: 1,
    consts: [[1, "wrapper"], ["class", "mean", 3, "selected", "title", "click", 4, "ngFor", "ngForOf"], [1, "mean", 3, "click", "title"], [3, "name"]],
    template: function SelectChallengeMeanComponent_Template(rf, ctx) {
      if (rf & 1) {
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](0, "div", 0);
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵtemplate"](1, SelectChallengeMeanComponent_div_1_Template, 3, 7, "div", 1);
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();
      }
      if (rf & 2) {
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵadvance"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵproperty"]("ngForOf", ctx.availableMeans);
      }
    },
    dependencies: [_angular_common__WEBPACK_IMPORTED_MODULE_2__.NgForOf, _core_shared_ui_icon_icon_component__WEBPACK_IMPORTED_MODULE_3__.IconComponent, _ngx_translate_core__WEBPACK_IMPORTED_MODULE_4__.TranslatePipe],
    styles: [".wrapper[_ngcontent-%COMP%] {\n  display: grid;\n  grid-template-columns: repeat(3, 1fr);\n  grid-column-gap: 10px;\n  grid-row-gap: 10px;\n}\n\n.mean[_ngcontent-%COMP%] {\n  aspect-ratio: 1/1;\n  border: 2px solid var(--ion-color-base);\n  background-color: var(--ion-color-lighter);\n  border-radius: 10px;\n  display: flex;\n  align-items: center;\n  justify-content: center;\n  background-color: #f2f6fa;\n}\n.mean.disabled[_ngcontent-%COMP%] {\n  border-color: gray;\n  background-color: lightgray;\n}\n.mean.selected[_ngcontent-%COMP%] {\n  border-width: 4px;\n  background-color: #fdfdaa;\n}\n.mean[_ngcontent-%COMP%]   app-icon[_ngcontent-%COMP%] {\n  font-size: 56px;\n  line-height: 100%;\n}\n/*# sourceMappingURL=data:application/json;charset=utf-8;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbIndlYnBhY2s6Ly8uL3NyYy9hcHAvcGFnZXMvY2hhbGxlbmdlcy9jcmVhdGUtY2hhbGxlbmdlL3NlbGVjdC1jaGFsbGVuZ2UtbWVhbi9zZWxlY3QtY2hhbGxlbmdlLW1lYW4uY29tcG9uZW50LnNjc3MiXSwibmFtZXMiOltdLCJtYXBwaW5ncyI6IkFBQUE7RUFDRSxhQUFBO0VBQ0EscUNBQUE7RUFDQSxxQkFBQTtFQUNBLGtCQUFBO0FBQ0Y7O0FBQ0E7RUFDRSxpQkFBQTtFQUNBLHVDQUFBO0VBQ0EsMENBQUE7RUFDQSxtQkFBQTtFQUVBLGFBQUE7RUFDQSxtQkFBQTtFQUNBLHVCQUFBO0VBQ0EseUJBQUE7QUFDRjtBQUVFO0VBQ0Usa0JBQUE7RUFDQSwyQkFBQTtBQUFKO0FBRUU7RUFDRSxpQkFBQTtFQUNBLHlCQUFBO0FBQUo7QUFFRTtFQUNFLGVBQUE7RUFFQSxpQkFBQTtBQURKIiwic291cmNlc0NvbnRlbnQiOlsiLndyYXBwZXIge1xuICBkaXNwbGF5OiBncmlkO1xuICBncmlkLXRlbXBsYXRlLWNvbHVtbnM6IHJlcGVhdCgzLCAxZnIpO1xuICBncmlkLWNvbHVtbi1nYXA6IDEwcHg7XG4gIGdyaWQtcm93LWdhcDogMTBweDtcbn1cbi5tZWFuIHtcbiAgYXNwZWN0LXJhdGlvOiAxLzE7XG4gIGJvcmRlcjogMnB4IHNvbGlkIHZhcigtLWlvbi1jb2xvci1iYXNlKTtcbiAgYmFja2dyb3VuZC1jb2xvcjogdmFyKC0taW9uLWNvbG9yLWxpZ2h0ZXIpO1xuICBib3JkZXItcmFkaXVzOiAxMHB4O1xuXG4gIGRpc3BsYXk6IGZsZXg7XG4gIGFsaWduLWl0ZW1zOiBjZW50ZXI7XG4gIGp1c3RpZnktY29udGVudDogY2VudGVyO1xuICBiYWNrZ3JvdW5kLWNvbG9yOiAjZjJmNmZhO1xuXG4gIC8vIG1hcmdpbjogMTBweDtcbiAgJi5kaXNhYmxlZCB7XG4gICAgYm9yZGVyLWNvbG9yOiBncmF5O1xuICAgIGJhY2tncm91bmQtY29sb3I6IGxpZ2h0Z3JheTtcbiAgfVxuICAmLnNlbGVjdGVkIHtcbiAgICBib3JkZXItd2lkdGg6IDRweDtcbiAgICBiYWNrZ3JvdW5kLWNvbG9yOiAjZmRmZGFhO1xuICB9XG4gIGFwcC1pY29uIHtcbiAgICBmb250LXNpemU6IDU2cHg7XG4gICAgLy8gb3V0bGluZTogMXB4IHNvbGlkIHJlZDtcbiAgICBsaW5lLWhlaWdodDogMTAwJTtcbiAgfVxufVxuIl0sInNvdXJjZVJvb3QiOiIifQ== */"]
  }));
}
_staticBlock();

/***/ }),

/***/ 7535:
/*!***********************************************************************************************!*\
  !*** ./src/app/pages/challenges/create-challenge/wizard/wizard-step/wizard-step.component.ts ***!
  \***********************************************************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   WizardStepComponent: () => (/* binding */ WizardStepComponent)
/* harmony export */ });
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! @angular/core */ 12481);
var _staticBlock;


const _c0 = ["template"];
const _c1 = ["*"];
function WizardStepComponent_ng_template_0_Template(rf, ctx) {
  if (rf & 1) {
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵprojection"](0);
  }
}
class WizardStepComponent {
  constructor() {
    this.validForNextStep = true;
    this.activated = new _angular_core__WEBPACK_IMPORTED_MODULE_0__.EventEmitter();
  }
  static #_ = _staticBlock = () => (this.ɵfac = function WizardStepComponent_Factory(__ngFactoryType__) {
    return new (__ngFactoryType__ || WizardStepComponent)();
  }, this.ɵcmp = /*@__PURE__*/_angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵdefineComponent"]({
    type: WizardStepComponent,
    selectors: [["app-wizard-step"]],
    viewQuery: function WizardStepComponent_Query(rf, ctx) {
      if (rf & 1) {
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵviewQuery"](_c0, 7, _angular_core__WEBPACK_IMPORTED_MODULE_0__.TemplateRef);
      }
      if (rf & 2) {
        let _t;
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵqueryRefresh"](_t = _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵloadQuery"]()) && (ctx.template = _t.first);
      }
    },
    inputs: {
      title: "title",
      validForNextStep: "validForNextStep"
    },
    outputs: {
      activated: "activated"
    },
    standalone: false,
    ngContentSelectors: _c1,
    decls: 2,
    vars: 0,
    consts: [["template", ""]],
    template: function WizardStepComponent_Template(rf, ctx) {
      if (rf & 1) {
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵprojectionDef"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵtemplate"](0, WizardStepComponent_ng_template_0_Template, 1, 0, "ng-template", null, 0, _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵtemplateRefExtractor"]);
      }
    },
    styles: ["/*# sourceMappingURL=data:application/json;charset=utf-8;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbXSwibmFtZXMiOltdLCJtYXBwaW5ncyI6IiIsInNvdXJjZVJvb3QiOiIifQ== */"]
  }));
}
_staticBlock();

/***/ }),

/***/ 9119:
/*!******************************************************************************!*\
  !*** ./src/app/pages/challenges/create-challenge/create-challenge.module.ts ***!
  \******************************************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   CreateChallengePageModule: () => (/* binding */ CreateChallengePageModule)
/* harmony export */ });
/* harmony import */ var _create_challenge_routing_module__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./create-challenge-routing.module */ 73302);
/* harmony import */ var _create_challenge_page__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ./create-challenge.page */ 20168);
/* harmony import */ var src_app_core_shared_shared_module__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! src/app/core/shared/shared.module */ 62657);
/* harmony import */ var _wizard_wizard_component__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! ./wizard/wizard.component */ 62675);
/* harmony import */ var _wizard_wizard_step_wizard_step_component__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! ./wizard/wizard-step/wizard-step.component */ 7535);
/* harmony import */ var _select_challenge_model_select_challenge_model_component__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! ./select-challenge-model/select-challenge-model.component */ 69761);
/* harmony import */ var _select_challenge_mean_select_challenge_mean_component__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! ./select-challenge-mean/select-challenge-mean.component */ 431);
/* harmony import */ var _select_challengeable_select_challengeable_component__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(/*! ./select-challengeable/select-challengeable.component */ 99181);
/* harmony import */ var _challenge_preview_challenge_preview_component__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(/*! ./challenge-preview/challenge-preview.component */ 86791);
/* harmony import */ var _ionic_angular__WEBPACK_IMPORTED_MODULE_9__ = __webpack_require__(/*! @ionic/angular */ 21507);
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_10__ = __webpack_require__(/*! @angular/core */ 34205);
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_11__ = __webpack_require__(/*! @angular/core */ 12481);
/* harmony import */ var _angular_common__WEBPACK_IMPORTED_MODULE_12__ = __webpack_require__(/*! @angular/common */ 93683);
/* harmony import */ var _core_shared_layout_header_header_directive__WEBPACK_IMPORTED_MODULE_13__ = __webpack_require__(/*! ../../../core/shared/layout/header/header.directive */ 85039);
/* harmony import */ var _core_shared_layout_content_content_directive__WEBPACK_IMPORTED_MODULE_14__ = __webpack_require__(/*! ../../../core/shared/layout/content/content.directive */ 75855);
/* harmony import */ var _ngx_translate_core__WEBPACK_IMPORTED_MODULE_15__ = __webpack_require__(/*! @ngx-translate/core */ 48503);
/* harmony import */ var _core_shared_pipes_languageMap_pipe__WEBPACK_IMPORTED_MODULE_16__ = __webpack_require__(/*! ../../../core/shared/pipes/languageMap.pipe */ 69618);
var _staticBlock;

















class CreateChallengePageModule {
  static #_ = _staticBlock = () => (this.ɵfac = function CreateChallengePageModule_Factory(__ngFactoryType__) {
    return new (__ngFactoryType__ || CreateChallengePageModule)();
  }, this.ɵmod = /*@__PURE__*/_angular_core__WEBPACK_IMPORTED_MODULE_11__["ɵɵdefineNgModule"]({
    type: CreateChallengePageModule
  }), this.ɵinj = /*@__PURE__*/_angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵdefineInjector"]({
    imports: [src_app_core_shared_shared_module__WEBPACK_IMPORTED_MODULE_2__.PlayGoSharedModule, _create_challenge_routing_module__WEBPACK_IMPORTED_MODULE_0__.CreateChallengePageRoutingModule, _ionic_angular__WEBPACK_IMPORTED_MODULE_9__.IonicModule]
  }));
}
_staticBlock();
(function () {
  (typeof ngJitMode === "undefined" || ngJitMode) && _angular_core__WEBPACK_IMPORTED_MODULE_11__["ɵɵsetNgModuleScope"](CreateChallengePageModule, {
    declarations: [_create_challenge_page__WEBPACK_IMPORTED_MODULE_1__.CreateChallengePage, _wizard_wizard_component__WEBPACK_IMPORTED_MODULE_3__.WizardComponent, _wizard_wizard_step_wizard_step_component__WEBPACK_IMPORTED_MODULE_4__.WizardStepComponent, _select_challenge_model_select_challenge_model_component__WEBPACK_IMPORTED_MODULE_5__.SelectChallengeModelComponent, _select_challenge_mean_select_challenge_mean_component__WEBPACK_IMPORTED_MODULE_6__.SelectChallengeMeanComponent, _select_challengeable_select_challengeable_component__WEBPACK_IMPORTED_MODULE_7__.SelectChallengeableComponent, _challenge_preview_challenge_preview_component__WEBPACK_IMPORTED_MODULE_8__.ChallengePreviewComponent],
    imports: [src_app_core_shared_shared_module__WEBPACK_IMPORTED_MODULE_2__.PlayGoSharedModule, _create_challenge_routing_module__WEBPACK_IMPORTED_MODULE_0__.CreateChallengePageRoutingModule, _ionic_angular__WEBPACK_IMPORTED_MODULE_9__.IonicModule]
  });
})();
_angular_core__WEBPACK_IMPORTED_MODULE_11__["ɵɵsetComponentScope"](_create_challenge_page__WEBPACK_IMPORTED_MODULE_1__.CreateChallengePage, [_angular_common__WEBPACK_IMPORTED_MODULE_12__.NgClass, _angular_common__WEBPACK_IMPORTED_MODULE_12__.NgIf, _ionic_angular__WEBPACK_IMPORTED_MODULE_9__.IonContent, _ionic_angular__WEBPACK_IMPORTED_MODULE_9__.IonHeader, _core_shared_layout_header_header_directive__WEBPACK_IMPORTED_MODULE_13__.HeaderDirective, _core_shared_layout_content_content_directive__WEBPACK_IMPORTED_MODULE_14__.ContentDirective, _wizard_wizard_component__WEBPACK_IMPORTED_MODULE_3__.WizardComponent, _wizard_wizard_step_wizard_step_component__WEBPACK_IMPORTED_MODULE_4__.WizardStepComponent, _select_challenge_model_select_challenge_model_component__WEBPACK_IMPORTED_MODULE_5__.SelectChallengeModelComponent, _select_challenge_mean_select_challenge_mean_component__WEBPACK_IMPORTED_MODULE_6__.SelectChallengeMeanComponent, _select_challengeable_select_challengeable_component__WEBPACK_IMPORTED_MODULE_7__.SelectChallengeableComponent, _challenge_preview_challenge_preview_component__WEBPACK_IMPORTED_MODULE_8__.ChallengePreviewComponent], [_angular_common__WEBPACK_IMPORTED_MODULE_12__.AsyncPipe, _ngx_translate_core__WEBPACK_IMPORTED_MODULE_15__.TranslatePipe, _core_shared_pipes_languageMap_pipe__WEBPACK_IMPORTED_MODULE_16__.LanguageMapPipe]);

/***/ }),

/***/ 20168:
/*!****************************************************************************!*\
  !*** ./src/app/pages/challenges/create-challenge/create-challenge.page.ts ***!
  \****************************************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   CreateChallengePage: () => (/* binding */ CreateChallengePage),
/* harmony export */   POINT_CONCEPT_GAME: () => (/* binding */ POINT_CONCEPT_GAME),
/* harmony export */   meanToPointConcept: () => (/* binding */ meanToPointConcept)
/* harmony export */ });
/* harmony import */ var _Users_smartcommunitylab_Desktop_newWork_playAndGo_playGo_node_modules_babel_runtime_helpers_esm_asyncToGenerator_js__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./node_modules/@babel/runtime/helpers/esm/asyncToGenerator.js */ 89204);
/* harmony import */ var lodash_es__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! lodash-es */ 24979);
/* harmony import */ var rxjs__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! rxjs */ 10819);
/* harmony import */ var rxjs__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! rxjs */ 56196);
/* harmony import */ var rxjs__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! rxjs */ 19999);
/* harmony import */ var rxjs__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! rxjs */ 70271);
/* harmony import */ var rxjs__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! rxjs */ 86301);
/* harmony import */ var rxjs__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(/*! rxjs */ 36647);
/* harmony import */ var rxjs__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(/*! rxjs */ 98764);
/* harmony import */ var src_app_core_shared_tracking_trip_model__WEBPACK_IMPORTED_MODULE_9__ = __webpack_require__(/*! src/app/core/shared/tracking/trip.model */ 23126);
/* harmony import */ var src_app_core_shared_rxjs_utils__WEBPACK_IMPORTED_MODULE_10__ = __webpack_require__(/*! src/app/core/shared/rxjs.utils */ 86040);
/* harmony import */ var _sent_invitation_modal_sent_invitation_modal__WEBPACK_IMPORTED_MODULE_11__ = __webpack_require__(/*! ./sent-invitation-modal/sent-invitation.modal */ 41609);
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_12__ = __webpack_require__(/*! @angular/core */ 34205);
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_13__ = __webpack_require__(/*! @angular/core */ 12481);
/* harmony import */ var _angular_router__WEBPACK_IMPORTED_MODULE_14__ = __webpack_require__(/*! @angular/router */ 85422);
/* harmony import */ var src_app_core_shared_services_campaign_service__WEBPACK_IMPORTED_MODULE_15__ = __webpack_require__(/*! src/app/core/shared/services/campaign.service */ 76658);
/* harmony import */ var src_app_core_api_generated_controllers_challengeController_service__WEBPACK_IMPORTED_MODULE_16__ = __webpack_require__(/*! src/app/core/api/generated/controllers/challengeController.service */ 79811);
/* harmony import */ var src_app_core_shared_services_error_service__WEBPACK_IMPORTED_MODULE_17__ = __webpack_require__(/*! src/app/core/shared/services/error.service */ 46078);
/* harmony import */ var _ionic_angular__WEBPACK_IMPORTED_MODULE_18__ = __webpack_require__(/*! @ionic/angular */ 4059);
/* harmony import */ var _ionic_angular__WEBPACK_IMPORTED_MODULE_19__ = __webpack_require__(/*! @ionic/angular */ 21507);
/* harmony import */ var src_app_core_shared_services_challenge_service__WEBPACK_IMPORTED_MODULE_20__ = __webpack_require__(/*! src/app/core/shared/services/challenge.service */ 16561);

var _staticBlock;












function CreateChallengePage_app_wizard_2_Template(rf, ctx) {
  if (rf & 1) {
    const _r1 = _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵgetCurrentView"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵelementStart"](0, "app-wizard", 3);
    _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵpipe"](1, "languageMap");
    _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵpipe"](2, "translate");
    _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵlistener"]("finish", function CreateChallengePage_app_wizard_2_Template_app_wizard_finish_0_listener() {
      _angular_core__WEBPACK_IMPORTED_MODULE_12__["ɵɵrestoreView"](_r1);
      const ctx_r1 = _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵnextContext"]();
      return _angular_core__WEBPACK_IMPORTED_MODULE_12__["ɵɵresetView"](ctx_r1.onInvite());
    });
    _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵelementStart"](3, "app-wizard-step", 4);
    _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵpipe"](4, "async");
    _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵelementStart"](5, "div", 5)(6, "h2");
    _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵtext"](7);
    _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵpipe"](8, "translate");
    _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵelementEnd"]()();
    _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵelementStart"](9, "app-select-challenge-model", 6);
    _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵpipe"](10, "async");
    _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵlistener"]("selectedModel", function CreateChallengePage_app_wizard_2_Template_app_select_challenge_model_selectedModel_9_listener($event) {
      _angular_core__WEBPACK_IMPORTED_MODULE_12__["ɵɵrestoreView"](_r1);
      const ctx_r1 = _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵnextContext"]();
      return _angular_core__WEBPACK_IMPORTED_MODULE_12__["ɵɵresetView"](ctx_r1.selectedModelName$.next($event));
    });
    _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵelementEnd"]()();
    _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵelementStart"](11, "app-wizard-step", 7);
    _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵpipe"](12, "async");
    _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵelementStart"](13, "div", 5)(14, "h2");
    _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵtext"](15);
    _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵpipe"](16, "translate");
    _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵelementEnd"]()();
    _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵelementStart"](17, "app-select-challenge-mean", 8);
    _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵpipe"](18, "async");
    _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵlistener"]("selectedMean", function CreateChallengePage_app_wizard_2_Template_app_select_challenge_mean_selectedMean_17_listener($event) {
      _angular_core__WEBPACK_IMPORTED_MODULE_12__["ɵɵrestoreView"](_r1);
      const ctx_r1 = _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵnextContext"]();
      return _angular_core__WEBPACK_IMPORTED_MODULE_12__["ɵɵresetView"](ctx_r1.selectedPointConcept$.next($event));
    });
    _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵelementEnd"]()();
    _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵelementStart"](19, "app-wizard-step", 9);
    _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵpipe"](20, "async");
    _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵelementStart"](21, "app-select-challengeable", 10);
    _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵpipe"](22, "async");
    _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵlistener"]("selectedChallengeable", function CreateChallengePage_app_wizard_2_Template_app_select_challengeable_selectedChallengeable_21_listener($event) {
      _angular_core__WEBPACK_IMPORTED_MODULE_12__["ɵɵrestoreView"](_r1);
      const ctx_r1 = _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵnextContext"]();
      return _angular_core__WEBPACK_IMPORTED_MODULE_12__["ɵɵresetView"](ctx_r1.selectedChallengeableId$.next($event));
    });
    _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵelementEnd"]()();
    _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵelementStart"](23, "app-wizard-step", 11);
    _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵlistener"]("activated", function CreateChallengePage_app_wizard_2_Template_app_wizard_step_activated_23_listener() {
      _angular_core__WEBPACK_IMPORTED_MODULE_12__["ɵɵrestoreView"](_r1);
      const ctx_r1 = _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵnextContext"]();
      return _angular_core__WEBPACK_IMPORTED_MODULE_12__["ɵɵresetView"](ctx_r1.previewActive$.next());
    });
    _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵelement"](24, "app-challenge-preview", 12);
    _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵpipe"](25, "async");
    _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵpipe"](26, "async");
    _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵpipe"](27, "async");
    _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵpipe"](28, "async");
    _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵelementEnd"]()();
  }
  if (rf & 2) {
    const campaign_r3 = ctx.ngIf;
    const ctx_r1 = _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵnextContext"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵproperty"]("title", _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵpipeBind1"](1, 16, campaign_r3.name))("backButton", false)("ngClass", "ion-color-" + ctx_r1.getCampaignColor(campaign_r3))("finishButtonLabel", _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵpipeBind1"](2, 18, "challenges.create.invite"));
    _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵadvance"](3);
    _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵproperty"]("validForNextStep", _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵpipeBind1"](4, 20, ctx_r1.selectedModelName$) !== null);
    _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵadvance"](4);
    _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵtextInterpolate"](_angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵpipeBind1"](8, 22, "challenges.challenge_model.title"));
    _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵadvance"](2);
    _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵproperty"]("availableModels", _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵpipeBind1"](10, 24, ctx_r1.challengeModels$));
    _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵadvance"](2);
    _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵproperty"]("validForNextStep", _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵpipeBind1"](12, 26, ctx_r1.selectedPointConcept$) !== null);
    _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵadvance"](4);
    _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵtextInterpolate"](_angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵpipeBind1"](16, 28, "challenges.challenge_mean.title"));
    _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵadvance"](2);
    _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵproperty"]("availableMeans", _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵpipeBind1"](18, 30, ctx_r1.pointConcepts$));
    _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵadvance"](2);
    _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵproperty"]("validForNextStep", _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵpipeBind1"](20, 32, ctx_r1.selectedChallengeableId$) !== null);
    _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵadvance"](2);
    _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵproperty"]("availableChallengeables", _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵpipeBind1"](22, 34, ctx_r1.challengeables$));
    _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵadvance"](3);
    _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵproperty"]("challengeModelName", _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵpipeBind1"](25, 36, ctx_r1.selectedModelName$))("pointConcept", _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵpipeBind1"](26, 38, ctx_r1.selectedPointConcept$))("challengeable", _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵpipeBind1"](27, 40, ctx_r1.selectedChallengeable$))("preview", _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵpipeBind1"](28, 42, ctx_r1.preview$));
  }
}
class CreateChallengePage {
  constructor(route, campaignService, challengeControllerService, errorService, navController, challengeService, modalController) {
    this.route = route;
    this.campaignService = campaignService;
    this.challengeControllerService = challengeControllerService;
    this.errorService = errorService;
    this.navController = navController;
    this.challengeService = challengeService;
    this.modalController = modalController;
    this.campaignId$ = this.route.params.pipe((0,rxjs__WEBPACK_IMPORTED_MODULE_5__.map)(params => params.id));
    this.campaign$ = this.campaignId$.pipe((0,rxjs__WEBPACK_IMPORTED_MODULE_7__.switchMap)(campaignId => this.campaignService.myCampaigns$.pipe((0,rxjs__WEBPACK_IMPORTED_MODULE_5__.map)(campaigns => campaigns.find(campaignContainer => campaignContainer.campaign.campaignId === campaignId)?.campaign))));
    this.challengeModels$ = this.campaignId$.pipe((0,rxjs__WEBPACK_IMPORTED_MODULE_7__.switchMap)(campaignId => this.challengeControllerService.getChallengesStatusUsingGET(campaignId).pipe(this.errorService.getErrorHandler())), (0,rxjs__WEBPACK_IMPORTED_MODULE_5__.map)(availableChallenges => {
      const all = [{
        challengeModelName: 'groupCooperative',
        availableFromLevel: 4
      }, {
        challengeModelName: 'groupCompetitiveTime',
        availableFromLevel: 5
      }, {
        challengeModelName: 'groupCompetitivePerformance',
        availableFromLevel: 6
      }];
      const allWithAvailableInfo = all.map(challengeModel => {
        const serverState = availableChallenges.find(eachServerChallengeMode => eachServerChallengeMode.modelName === challengeModel.challengeModelName)?.state;
        return {
          ...challengeModel,
          available: serverState === 'ACTIVE'
        };
      });
      return allWithAvailableInfo;
    }));
    this.selectedModelName$ = new rxjs__WEBPACK_IMPORTED_MODULE_2__.Subject();
    this.pointConcepts$ = (0,rxjs__WEBPACK_IMPORTED_MODULE_4__.combineLatest)([this.campaignService.availableMeans$, this.campaign$]).pipe((0,rxjs__WEBPACK_IMPORTED_MODULE_5__.map)(([means, campaign]) => {
      const gameInfo = {
        isMean: false,
        icon: this.campaignService.getCampaignScoreIcon(campaign),
        name: POINT_CONCEPT_GAME,
        title: this.campaignService.getCampaignScoreLabel(campaign)
      };
      const meansInfos = means.filter(mean => meanToPointConcept[mean]).map(mean => ({
        isMean: true,
        icon: src_app_core_shared_tracking_trip_model__WEBPACK_IMPORTED_MODULE_9__.transportTypeIcons[mean],
        name: meanToPointConcept[mean],
        title: src_app_core_shared_tracking_trip_model__WEBPACK_IMPORTED_MODULE_9__.transportTypeLabels[mean]
      }));
      return [gameInfo, ...meansInfos];
    }));
    this.selectedPointConcept$ = new rxjs__WEBPACK_IMPORTED_MODULE_2__.Subject();
    this.challengeables$ = this.campaignId$.pipe((0,rxjs__WEBPACK_IMPORTED_MODULE_7__.switchMap)(campaignId => this.challengeControllerService.getChallengeablesUsingGET(campaignId).pipe(this.errorService.getErrorHandler())), (0,rxjs__WEBPACK_IMPORTED_MODULE_5__.map)(challengeables => challengeables.map(eachUser => ({
      id: eachUser.id,
      nickname: eachUser.nickname,
      avatarUrl: eachUser?.avatar?.url ?? 'assets/images/registration/generic_user.png'
    }))));
    this.selectedChallengeableId$ = new rxjs__WEBPACK_IMPORTED_MODULE_2__.Subject();
    this.selectedChallengeable$ = (0,rxjs__WEBPACK_IMPORTED_MODULE_4__.combineLatest)([this.challengeables$, this.selectedChallengeableId$]).pipe((0,rxjs__WEBPACK_IMPORTED_MODULE_5__.map)(([allChallengeables, selectedId]) => (0,lodash_es__WEBPACK_IMPORTED_MODULE_1__["default"])(allChallengeables, {
      id: selectedId
    })), (0,rxjs__WEBPACK_IMPORTED_MODULE_8__.tap)(chall => this.nicknameOpponent = chall.nickname));
    this.previewActive$ = new rxjs__WEBPACK_IMPORTED_MODULE_2__.Subject();
    this.inviteParams$ = (0,rxjs__WEBPACK_IMPORTED_MODULE_4__.combineLatest)({
      campaignId: this.campaignId$,
      selectedChallengeableId: this.selectedChallengeableId$,
      selectedModelName: this.selectedModelName$,
      selectedPointConcept: this.selectedPointConcept$
    }).pipe((0,rxjs__WEBPACK_IMPORTED_MODULE_5__.map)(({
      campaignId,
      selectedChallengeableId,
      selectedModelName,
      selectedPointConcept
    }) => ({
      campaignId,
      body: {
        attendeeId: selectedChallengeableId,
        challengeModelName: selectedModelName,
        challengePointConcept: selectedPointConcept
      }
    })), (0,rxjs__WEBPACK_IMPORTED_MODULE_6__.shareReplay)(1));
    this.preview$ = this.inviteParams$.pipe((0,rxjs__WEBPACK_IMPORTED_MODULE_7__.switchMap)(data => this.previewActive$.pipe((0,rxjs__WEBPACK_IMPORTED_MODULE_5__.map)(() => data))), (0,rxjs__WEBPACK_IMPORTED_MODULE_7__.switchMap)(inviteParams => this.challengeControllerService.getGroupChallengePreviewUsingPOST(inviteParams).pipe(this.errorService.getErrorHandler(), (0,src_app_core_shared_rxjs_utils__WEBPACK_IMPORTED_MODULE_10__.castTo)())));
    this.getCampaignColor = this.campaignService.getCampaignColor;
  }
  ngOnInit() {}
  onInvite() {
    var _this = this;
    return (0,_Users_smartcommunitylab_Desktop_newWork_playAndGo_playGo_node_modules_babel_runtime_helpers_esm_asyncToGenerator_js__WEBPACK_IMPORTED_MODULE_0__["default"])(function* () {
      console.log('Invite!');
      const inviteParams = yield (0,rxjs__WEBPACK_IMPORTED_MODULE_3__.firstValueFrom)(_this.inviteParams$);
      try {
        yield _this.challengeService.sendInvitation(inviteParams);
        // await this.alertService.presentAlert({
        //   messageString: JSON.stringify(invitation),
        // });
        const modal = yield _this.modalController.create({
          component: _sent_invitation_modal_sent_invitation_modal__WEBPACK_IMPORTED_MODULE_11__.SentInvitationlModalPage,
          cssClass: 'modal-challenge',
          componentProps: {
            opponentName: _this.nicknameOpponent
          }
        });
        yield modal.present();
        const navigationExtras = {
          queryParams: {
            selectedSegment: 'futureChallenges'
          }
        };
        _this.navController.navigateBack('pages/tabs/challenges', navigationExtras);
      } catch (e) {
        _this.errorService.handleError(e);
      }
    })();
  }
  static #_ = _staticBlock = () => (this.ɵfac = function CreateChallengePage_Factory(__ngFactoryType__) {
    return new (__ngFactoryType__ || CreateChallengePage)(_angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵdirectiveInject"](_angular_router__WEBPACK_IMPORTED_MODULE_14__.ActivatedRoute), _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵdirectiveInject"](src_app_core_shared_services_campaign_service__WEBPACK_IMPORTED_MODULE_15__.CampaignService), _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵdirectiveInject"](src_app_core_api_generated_controllers_challengeController_service__WEBPACK_IMPORTED_MODULE_16__.ChallengeControllerService), _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵdirectiveInject"](src_app_core_shared_services_error_service__WEBPACK_IMPORTED_MODULE_17__.ErrorService), _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵdirectiveInject"](_ionic_angular__WEBPACK_IMPORTED_MODULE_18__.NavController), _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵdirectiveInject"](src_app_core_shared_services_challenge_service__WEBPACK_IMPORTED_MODULE_20__.ChallengeService), _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵdirectiveInject"](_ionic_angular__WEBPACK_IMPORTED_MODULE_19__.ModalController));
  }, this.ɵcmp = /*@__PURE__*/_angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵdefineComponent"]({
    type: CreateChallengePage,
    selectors: [["app-create-challenge"]],
    standalone: false,
    decls: 4,
    vars: 3,
    consts: [["appHeader", ""], ["appContent", ""], [3, "title", "backButton", "ngClass", "finishButtonLabel", "finish", 4, "ngIf"], [3, "finish", "title", "backButton", "ngClass", "finishButtonLabel"], ["title", "challenges.create.choose_type", 3, "validForNextStep"], [1, "ion-text-center"], [3, "selectedModel", "availableModels"], ["title", "challenges.create.choose_metric", 3, "validForNextStep"], [3, "selectedMean", "availableMeans"], ["title", "challenges.create.choose_partner", 3, "validForNextStep"], [3, "selectedChallengeable", "availableChallengeables"], ["title", "challenges.create.activate", 3, "activated"], [3, "challengeModelName", "pointConcept", "challengeable", "preview"]],
    template: function CreateChallengePage_Template(rf, ctx) {
      if (rf & 1) {
        _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵelement"](0, "ion-header", 0);
        _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵelementStart"](1, "ion-content", 1);
        _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵtemplate"](2, CreateChallengePage_app_wizard_2_Template, 29, 44, "app-wizard", 2);
        _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵpipe"](3, "async");
        _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵelementEnd"]();
      }
      if (rf & 2) {
        _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵadvance"](2);
        _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵproperty"]("ngIf", _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵpipeBind1"](3, 1, ctx.campaign$));
      }
    },
    styles: ["/*# sourceMappingURL=data:application/json;charset=utf-8;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbXSwibmFtZXMiOltdLCJtYXBwaW5ncyI6IiIsInNvdXJjZVJvb3QiOiIifQ== */"]
  }));
}
// | 'Boat_Km'
// | 'Bus_Km'
// | 'Car_Km'
// | 'Train_Km';
_staticBlock();
const POINT_CONCEPT_GAME = 'green leaves';
const meanToPointConcept = {
  bike: 'Bike_Km',
  walk: 'Walk_Km',
  boat: null,
  bus: null,
  car: null,
  train: null,
  unknown: null
};

/***/ }),

/***/ 62675:
/*!******************************************************************************!*\
  !*** ./src/app/pages/challenges/create-challenge/wizard/wizard.component.ts ***!
  \******************************************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   WizardComponent: () => (/* binding */ WizardComponent)
/* harmony export */ });
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! @angular/core */ 12481);
/* harmony import */ var _wizard_step_wizard_step_component__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ./wizard-step/wizard-step.component */ 7535);
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @angular/core */ 34205);
/* harmony import */ var _angular_common__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @angular/common */ 93683);
/* harmony import */ var _ionic_angular__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! @ionic/angular */ 21507);
/* harmony import */ var _ngx_translate_core__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! @ngx-translate/core */ 48503);
var _staticBlock;






function WizardComponent_div_4_Template(rf, ctx) {
  if (rf & 1) {
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](0, "div", 10);
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵtext"](1);
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();
  }
  if (rf & 2) {
    const ctx_r0 = _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵnextContext"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵadvance"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵtextInterpolate1"](" ", ctx_r0.title, " ");
  }
}
function WizardComponent_div_5_Template(rf, ctx) {
  if (rf & 1) {
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](0, "div", 11);
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵtext"](1);
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵpipe"](2, "translate");
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();
  }
  if (rf & 2) {
    const ctx_r0 = _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵnextContext"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵadvance"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵtextInterpolate1"](" ", _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵpipeBind1"](2, 1, ctx_r0.selectedStep.title), " ");
  }
}
function WizardComponent_ng_container_8_Template(rf, ctx) {
  if (rf & 1) {
    const _r2 = _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵgetCurrentView"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementContainerStart"](0);
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelement"](1, "div", 12);
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](2, "div", 13);
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵlistener"]("click", function WizardComponent_ng_container_8_Template_div_click_2_listener() {
      const currentStepIndex_r3 = _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵrestoreView"](_r2).index;
      const ctx_r0 = _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵnextContext"]();
      return _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵresetView"](ctx_r0.changeStep(currentStepIndex_r3));
    });
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵtext"](3);
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementContainerEnd"]();
  }
  if (rf & 2) {
    const currentStepIndex_r3 = ctx.index;
    const ctx_r0 = _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵnextContext"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵadvance"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵclassProp"]("first-step", currentStepIndex_r3 === 0);
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵadvance"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵclassProp"]("previous", currentStepIndex_r3 < ctx_r0.selectedStepIndex)("step-current", currentStepIndex_r3 === ctx_r0.selectedStepIndex)("last-step", currentStepIndex_r3 === ctx_r0.steps.length - 1);
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵadvance"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵtextInterpolate1"](" ", currentStepIndex_r3 + 1, " ");
  }
}
function WizardComponent_ion_button_12_Template(rf, ctx) {
  if (rf & 1) {
    const _r4 = _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵgetCurrentView"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](0, "ion-button", 14);
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵlistener"]("click", function WizardComponent_ion_button_12_Template_ion_button_click_0_listener() {
      _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵrestoreView"](_r4);
      const ctx_r0 = _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵnextContext"]();
      return _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵresetView"](ctx_r0.changeStep(ctx_r0.selectedStepIndex - 1));
    });
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵtext"](1);
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵpipe"](2, "translate");
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();
  }
  if (rf & 2) {
    const ctx_r0 = _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵnextContext"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵproperty"]("disabled", ctx_r0.selectedStepIndex === 0);
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵadvance"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵtextInterpolate1"](" ", _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵpipeBind1"](2, 2, "wizard.back"), " ");
  }
}
function WizardComponent_ion_button_13_Template(rf, ctx) {
  if (rf & 1) {
    const _r5 = _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵgetCurrentView"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](0, "ion-button", 14);
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵlistener"]("click", function WizardComponent_ion_button_13_Template_ion_button_click_0_listener() {
      _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵrestoreView"](_r5);
      const ctx_r0 = _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵnextContext"]();
      return _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵresetView"](ctx_r0.changeStep(ctx_r0.selectedStepIndex + 1));
    });
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵtext"](1);
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵpipe"](2, "translate");
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();
  }
  if (rf & 2) {
    const ctx_r0 = _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵnextContext"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵproperty"]("disabled", ctx_r0.selectedStep.validForNextStep !== true);
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵadvance"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵtextInterpolate1"](" ", _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵpipeBind1"](2, 2, "wizard.next"), " ");
  }
}
function WizardComponent_ion_button_14_Template(rf, ctx) {
  if (rf & 1) {
    const _r6 = _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵgetCurrentView"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](0, "ion-button", 14);
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵlistener"]("click", function WizardComponent_ion_button_14_Template_ion_button_click_0_listener() {
      _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵrestoreView"](_r6);
      const ctx_r0 = _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵnextContext"]();
      return _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵresetView"](ctx_r0.finish.emit());
    });
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵtext"](1);
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();
  }
  if (rf & 2) {
    const ctx_r0 = _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵnextContext"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵproperty"]("disabled", ctx_r0.selectedStep.validForNextStep !== true);
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵadvance"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵtextInterpolate1"](" ", ctx_r0.finishButtonLabel, " ");
  }
}
class WizardComponent {
  set stepComponents(stepComponents) {
    this.steps = stepComponents.toArray();
    this.templates = stepComponents.map(eachComponent => eachComponent.template);
    this.changeStep(0);
  }
  constructor() {
    this.title = '';
    this.backButton = true;
    this.finishButtonLabel = '';
    this.finish = new _angular_core__WEBPACK_IMPORTED_MODULE_0__.EventEmitter();
    this.steps = [];
    this.templates = [];
    this.selectedStepIndex = 0;
  }
  ngAfterContentInit() {}
  isStepValid(newStepIdx) {
    if (newStepIdx === 0) {
      return true;
    }
    const previousStepIdx = Math.max(newStepIdx - 1, 0);
    const previousStep = this.steps[previousStepIdx];
    return previousStep.validForNextStep !== false;
  }
  changeStep(newStepIdx) {
    if (!this.isStepValid(newStepIdx)) {
      return;
    }
    this.selectedStepIndex = newStepIdx;
    this.selectedStep = this.steps[this.selectedStepIndex];
    this.selectedStep.activated.next();
  }
  ngOnInit() {}
  static #_ = _staticBlock = () => (this.ɵfac = function WizardComponent_Factory(__ngFactoryType__) {
    return new (__ngFactoryType__ || WizardComponent)();
  }, this.ɵcmp = /*@__PURE__*/_angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵdefineComponent"]({
    type: WizardComponent,
    selectors: [["app-wizard"]],
    contentQueries: function WizardComponent_ContentQueries(rf, ctx, dirIndex) {
      if (rf & 1) {
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵcontentQuery"](dirIndex, _wizard_step_wizard_step_component__WEBPACK_IMPORTED_MODULE_1__.WizardStepComponent, 4);
      }
      if (rf & 2) {
        let _t;
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵqueryRefresh"](_t = _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵloadQuery"]()) && (ctx.stepComponents = _t);
      }
    },
    inputs: {
      title: "title",
      backButton: "backButton",
      finishButtonLabel: "finishButtonLabel"
    },
    outputs: {
      finish: "finish"
    },
    standalone: false,
    decls: 15,
    vars: 7,
    consts: [[1, "wrapper"], ["color", "base", 1, "title-header"], ["class", "ion-text-start", 4, "ngIf"], ["class", "ion-text-end", 4, "ngIf"], [1, "form-steps-container"], [4, "ngFor", "ngForOf"], [1, "step-content-wrapper"], [3, "ngTemplateOutlet"], [1, "ion-justify-content-around", 2, "display", "flex"], ["color", "base", 3, "disabled", "click", 4, "ngIf"], [1, "ion-text-start"], [1, "ion-text-end"], [1, "step-divider"], [1, "step-bubble", 3, "click"], ["color", "base", 3, "click", "disabled"]],
    template: function WizardComponent_Template(rf, ctx) {
      if (rf & 1) {
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](0, "div", 0)(1, "ion-card")(2, "ion-card-header", 1)(3, "ion-card-title");
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵtemplate"](4, WizardComponent_div_4_Template, 2, 1, "div", 2)(5, WizardComponent_div_5_Template, 3, 3, "div", 3);
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]()();
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](6, "ion-card-content")(7, "div", 4);
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵtemplate"](8, WizardComponent_ng_container_8_Template, 4, 9, "ng-container", 5);
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](9, "div", 6);
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementContainer"](10, 7);
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](11, "div", 8);
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵtemplate"](12, WizardComponent_ion_button_12_Template, 3, 4, "ion-button", 9)(13, WizardComponent_ion_button_13_Template, 3, 4, "ion-button", 9)(14, WizardComponent_ion_button_14_Template, 2, 2, "ion-button", 9);
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]()()()();
      }
      if (rf & 2) {
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵadvance"](4);
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵproperty"]("ngIf", ctx.title);
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵadvance"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵproperty"]("ngIf", ctx.selectedStep.title);
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵadvance"](3);
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵproperty"]("ngForOf", ctx.steps);
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵadvance"](2);
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵproperty"]("ngTemplateOutlet", ctx.templates[ctx.selectedStepIndex]);
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵadvance"](2);
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵproperty"]("ngIf", ctx.backButton);
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵadvance"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵproperty"]("ngIf", ctx.selectedStepIndex !== ctx.steps.length - 1);
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵadvance"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵproperty"]("ngIf", ctx.selectedStepIndex === ctx.steps.length - 1);
      }
    },
    dependencies: [_angular_common__WEBPACK_IMPORTED_MODULE_3__.NgForOf, _angular_common__WEBPACK_IMPORTED_MODULE_3__.NgIf, _angular_common__WEBPACK_IMPORTED_MODULE_3__.NgTemplateOutlet, _ionic_angular__WEBPACK_IMPORTED_MODULE_4__.IonButton, _ionic_angular__WEBPACK_IMPORTED_MODULE_4__.IonCard, _ionic_angular__WEBPACK_IMPORTED_MODULE_4__.IonCardContent, _ionic_angular__WEBPACK_IMPORTED_MODULE_4__.IonCardHeader, _ionic_angular__WEBPACK_IMPORTED_MODULE_4__.IonCardTitle, _ngx_translate_core__WEBPACK_IMPORTED_MODULE_5__.TranslatePipe],
    styles: ["[_nghost-%COMP%] {\n  height: 100%;\n}\n\n.wrapper[_ngcontent-%COMP%] {\n  height: calc(100% - 20px);\n}\n.wrapper[_ngcontent-%COMP%]   ion-card[_ngcontent-%COMP%] {\n  height: 100%;\n  margin: 10px;\n  display: flex;\n  flex-direction: column;\n}\n.wrapper[_ngcontent-%COMP%]   ion-card[_ngcontent-%COMP%]   ion-card-content[_ngcontent-%COMP%] {\n  flex: 1;\n  display: flex;\n  flex-direction: column;\n  overflow-y: auto;\n}\n\n.title-header[_ngcontent-%COMP%]   ion-card-title[_ngcontent-%COMP%] {\n  font-size: 10px;\n  display: flex;\n  justify-content: space-between;\n}\n\n.form-steps-container[_ngcontent-%COMP%] {\n  display: flex;\n  justify-content: space-between;\n  align-items: center;\n  padding: 0 20px 0 10px;\n  margin-top: 10px;\n}\n\n.step-bubble[_ngcontent-%COMP%] {\n  padding: 8px;\n  border: 3px solid var(--ion-color-base);\n  width: 30px;\n  height: 30px;\n  display: flex;\n  justify-content: center;\n  align-items: center;\n  border-radius: 50%;\n  font-size: 1em;\n  cursor: pointer;\n  -webkit-user-select: none;\n          user-select: none;\n  background: #f2f6fa;\n}\n.step-bubble.step-current[_ngcontent-%COMP%] {\n  border-width: 5px;\n  width: 34px;\n  height: 34px;\n  margin-left: -2px;\n  margin-right: -2px;\n  background: white;\n  font-weight: bold;\n}\n.step-bubble.previous[_ngcontent-%COMP%] {\n  background-color: #fdfdaa;\n}\n.step-bubble.last-step[_ngcontent-%COMP%] {\n  border-radius: 0;\n}\n\n.step-divider[_ngcontent-%COMP%] {\n  height: 2px;\n  background: var(--ion-color-base);\n  flex: 1;\n}\n.step-divider.first-step[_ngcontent-%COMP%] {\n  flex: 0.2;\n}\n\n.step-content-wrapper[_ngcontent-%COMP%] {\n  flex: 1;\n}\n/*# sourceMappingURL=data:application/json;charset=utf-8;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbIndlYnBhY2s6Ly8uL3NyYy9hcHAvcGFnZXMvY2hhbGxlbmdlcy9jcmVhdGUtY2hhbGxlbmdlL3dpemFyZC93aXphcmQuY29tcG9uZW50LnNjc3MiXSwibmFtZXMiOltdLCJtYXBwaW5ncyI6IkFBSUE7RUFDRSxZQUFBO0FBSEY7O0FBTUE7RUFDRSx5QkFBQTtBQUhGO0FBSUU7RUFDRSxZQUFBO0VBQ0EsWUFBQTtFQUVBLGFBQUE7RUFDQSxzQkFBQTtBQUhKO0FBSUk7RUFDRSxPQUFBO0VBQ0EsYUFBQTtFQUNBLHNCQUFBO0VBQ0EsZ0JBQUE7QUFGTjs7QUFRRTtFQUNFLGVBQUE7RUFDQSxhQUFBO0VBQ0EsOEJBQUE7QUFMSjs7QUFRQTtFQUNFLGFBQUE7RUFDQSw4QkFBQTtFQUNBLG1CQUFBO0VBQ0Esc0JBQUE7RUFDQSxnQkFBQTtBQUxGOztBQVdBO0VBQ0UsWUFBQTtFQUNBLHVDQUFBO0VBQ0EsV0FOWTtFQU9aLFlBUFk7RUFRWixhQUFBO0VBQ0EsdUJBQUE7RUFDQSxtQkFBQTtFQUNBLGtCQUFBO0VBQ0EsY0FBQTtFQUNBLGVBQUE7RUFDQSx5QkFBQTtVQUFBLGlCQUFBO0VBQ0EsbUJBdER3QjtBQThDMUI7QUFVRTtFQUNFLGlCQUFBO0VBQ0EsV0FBQTtFQUNBLFlBQUE7RUFDQSxpQkFBQTtFQUNBLGtCQUFBO0VBQ0EsaUJBL0RrQjtFQWdFbEIsaUJBQUE7QUFSSjtBQVVFO0VBQ0UseUJBQUE7QUFSSjtBQVVFO0VBQ0UsZ0JBQUE7QUFSSjs7QUFZQTtFQUNFLFdBQUE7RUFDQSxpQ0FBQTtFQUNBLE9BQUE7QUFURjtBQVdFO0VBQ0UsU0FBQTtBQVRKOztBQWFBO0VBQ0UsT0FBQTtBQVZGIiwic291cmNlc0NvbnRlbnQiOlsiJHNlbGVjdGVkLWJhY2tncm91bmQ6IHdoaXRlO1xuJG5vdC1zZWxlY3RlZC1iYWNrZ3JvdW5kOiAjZjJmNmZhO1xuLy8gJG5vdC1zZWxlY3RlZC1iYWNrZ3JvdW5kOiByZWQ7XG5cbjpob3N0IHtcbiAgaGVpZ2h0OiAxMDAlO1xufVxuXG4ud3JhcHBlciB7XG4gIGhlaWdodDogY2FsYygxMDAlIC0gMjBweCk7XG4gIGlvbi1jYXJkIHtcbiAgICBoZWlnaHQ6IDEwMCU7XG4gICAgbWFyZ2luOiAxMHB4O1xuXG4gICAgZGlzcGxheTogZmxleDtcbiAgICBmbGV4LWRpcmVjdGlvbjogY29sdW1uO1xuICAgIGlvbi1jYXJkLWNvbnRlbnQge1xuICAgICAgZmxleDogMTtcbiAgICAgIGRpc3BsYXk6IGZsZXg7XG4gICAgICBmbGV4LWRpcmVjdGlvbjogY29sdW1uO1xuICAgICAgb3ZlcmZsb3cteTogYXV0bztcbiAgICB9XG4gIH1cbn1cblxuLnRpdGxlLWhlYWRlciB7XG4gIGlvbi1jYXJkLXRpdGxlIHtcbiAgICBmb250LXNpemU6IDEwcHg7XG4gICAgZGlzcGxheTogZmxleDtcbiAgICBqdXN0aWZ5LWNvbnRlbnQ6IHNwYWNlLWJldHdlZW47XG4gIH1cbn1cbi5mb3JtLXN0ZXBzLWNvbnRhaW5lciB7XG4gIGRpc3BsYXk6IGZsZXg7XG4gIGp1c3RpZnktY29udGVudDogc3BhY2UtYmV0d2VlbjtcbiAgYWxpZ24taXRlbXM6IGNlbnRlcjtcbiAgcGFkZGluZzogMCAyMHB4IDAgMTBweDtcbiAgbWFyZ2luLXRvcDogMTBweDtcbn1cblxuJGJ1YmJsZS1zaXplOiAzMHB4O1xuJGJ1YmJsZS1ib3JkZXI6IDNweDtcbiRzZWxlY3RlZC1idWJibGUtaW5jcmVhc2U6IDJweDtcbi5zdGVwLWJ1YmJsZSB7XG4gIHBhZGRpbmc6IDhweDtcbiAgYm9yZGVyOiAkYnViYmxlLWJvcmRlciBzb2xpZCB2YXIoLS1pb24tY29sb3ItYmFzZSk7XG4gIHdpZHRoOiAkYnViYmxlLXNpemU7XG4gIGhlaWdodDogJGJ1YmJsZS1zaXplO1xuICBkaXNwbGF5OiBmbGV4O1xuICBqdXN0aWZ5LWNvbnRlbnQ6IGNlbnRlcjtcbiAgYWxpZ24taXRlbXM6IGNlbnRlcjtcbiAgYm9yZGVyLXJhZGl1czogNTAlO1xuICBmb250LXNpemU6IDFlbTtcbiAgY3Vyc29yOiBwb2ludGVyO1xuICB1c2VyLXNlbGVjdDogbm9uZTtcbiAgYmFja2dyb3VuZDogJG5vdC1zZWxlY3RlZC1iYWNrZ3JvdW5kO1xuXG4gICYuc3RlcC1jdXJyZW50IHtcbiAgICBib3JkZXItd2lkdGg6ICRidWJibGUtYm9yZGVyICsgJHNlbGVjdGVkLWJ1YmJsZS1pbmNyZWFzZTtcbiAgICB3aWR0aDogJGJ1YmJsZS1zaXplICsgMiAqICRzZWxlY3RlZC1idWJibGUtaW5jcmVhc2U7XG4gICAgaGVpZ2h0OiAkYnViYmxlLXNpemUgKyAyICogJHNlbGVjdGVkLWJ1YmJsZS1pbmNyZWFzZTtcbiAgICBtYXJnaW4tbGVmdDogLSRzZWxlY3RlZC1idWJibGUtaW5jcmVhc2U7XG4gICAgbWFyZ2luLXJpZ2h0OiAtJHNlbGVjdGVkLWJ1YmJsZS1pbmNyZWFzZTtcbiAgICBiYWNrZ3JvdW5kOiAkc2VsZWN0ZWQtYmFja2dyb3VuZDtcbiAgICBmb250LXdlaWdodDogYm9sZDtcbiAgfVxuICAmLnByZXZpb3VzIHtcbiAgICBiYWNrZ3JvdW5kLWNvbG9yOiAjZmRmZGFhO1xuICB9XG4gICYubGFzdC1zdGVwIHtcbiAgICBib3JkZXItcmFkaXVzOiAwO1xuICB9XG59XG5cbi5zdGVwLWRpdmlkZXIge1xuICBoZWlnaHQ6IDJweDtcbiAgYmFja2dyb3VuZDogdmFyKC0taW9uLWNvbG9yLWJhc2UpO1xuICBmbGV4OiAxO1xuXG4gICYuZmlyc3Qtc3RlcCB7XG4gICAgZmxleDogMC4yO1xuICB9XG59XG5cbi5zdGVwLWNvbnRlbnQtd3JhcHBlciB7XG4gIGZsZXg6IDE7XG59XG4iXSwic291cmNlUm9vdCI6IiJ9 */"]
  }));
}
_staticBlock();

/***/ }),

/***/ 69761:
/*!**************************************************************************************************************!*\
  !*** ./src/app/pages/challenges/create-challenge/select-challenge-model/select-challenge-model.component.ts ***!
  \**************************************************************************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   SelectChallengeModelComponent: () => (/* binding */ SelectChallengeModelComponent)
/* harmony export */ });
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! @angular/core */ 12481);
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @angular/core */ 34205);
/* harmony import */ var _angular_common__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @angular/common */ 93683);
/* harmony import */ var _ionic_angular__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @ionic/angular */ 21507);
/* harmony import */ var _core_shared_ui_icon_icon_component__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! ../../../../core/shared/ui/icon/icon.component */ 59621);
/* harmony import */ var _ngx_translate_core__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! @ngx-translate/core */ 48503);
var _staticBlock;






const _c0 = a0 => ({
  level: a0
});
function SelectChallengeModelComponent_ion_col_2_div_5_Template(rf, ctx) {
  if (rf & 1) {
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](0, "div")(1, "div");
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelement"](2, "app-icon", 6);
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](3, "div", 7);
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵtext"](4);
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵpipe"](5, "translate");
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]()();
  }
  if (rf & 2) {
    const eachModel_r2 = _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵnextContext"]().$implicit;
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵadvance"](2);
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵproperty"]("name", eachModel_r2.challengeModelName);
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵadvance"](2);
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵtextInterpolate1"](" ", _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵpipeBind1"](5, 2, "challenges.challenge_model.description." + eachModel_r2.challengeModelName), " ");
  }
}
function SelectChallengeModelComponent_ion_col_2_div_6_Template(rf, ctx) {
  if (rf & 1) {
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](0, "div")(1, "div");
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelement"](2, "app-icon", 8);
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](3, "div");
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵtext"](4);
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵpipe"](5, "translate");
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]()();
  }
  if (rf & 2) {
    const eachModel_r2 = _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵnextContext"]().$implicit;
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵadvance"](4);
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵtextInterpolate1"](" ", _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵpipeBind2"](5, 1, "challenges.challenge_model.disabled_until_level", _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵpureFunction1"](4, _c0, eachModel_r2.availableFromLevel)), " ");
  }
}
function SelectChallengeModelComponent_ion_col_2_Template(rf, ctx) {
  if (rf & 1) {
    const _r1 = _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵgetCurrentView"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](0, "ion-col", 2)(1, "div", 3);
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵlistener"]("click", function SelectChallengeModelComponent_ion_col_2_Template_div_click_1_listener() {
      const eachModel_r2 = _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵrestoreView"](_r1).$implicit;
      const ctx_r2 = _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵnextContext"]();
      return _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵresetView"](ctx_r2.selectModel(eachModel_r2));
    });
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](2, "div", 4);
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵtext"](3);
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵpipe"](4, "translate");
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵtemplate"](5, SelectChallengeModelComponent_ion_col_2_div_5_Template, 6, 4, "div", 5)(6, SelectChallengeModelComponent_ion_col_2_div_6_Template, 6, 6, "div", 5);
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]()();
  }
  if (rf & 2) {
    const eachModel_r2 = ctx.$implicit;
    const ctx_r2 = _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵnextContext"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵadvance"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵclassProp"]("disabled", !eachModel_r2.available)("selected", eachModel_r2.challengeModelName === ctx_r2.selectedModelName);
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵadvance"](2);
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵtextInterpolate1"](" ", _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵpipeBind1"](4, 7, "challenges.challenge_model.name." + eachModel_r2.challengeModelName), " ");
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵadvance"](2);
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵproperty"]("ngIf", eachModel_r2.available);
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵadvance"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵproperty"]("ngIf", !eachModel_r2.available);
  }
}
class SelectChallengeModelComponent {
  constructor() {
    this.selectedModel = new _angular_core__WEBPACK_IMPORTED_MODULE_0__.EventEmitter();
  }
  ngOnInit() {}
  selectModel(model) {
    if (model.available) {
      this.selectedModelName = model.challengeModelName;
      this.selectedModel.emit(this.selectedModelName);
    }
  }
  static #_ = _staticBlock = () => (this.ɵfac = function SelectChallengeModelComponent_Factory(__ngFactoryType__) {
    return new (__ngFactoryType__ || SelectChallengeModelComponent)();
  }, this.ɵcmp = /*@__PURE__*/_angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵdefineComponent"]({
    type: SelectChallengeModelComponent,
    selectors: [["app-select-challenge-model"]],
    inputs: {
      availableModels: "availableModels"
    },
    outputs: {
      selectedModel: "selectedModel"
    },
    standalone: false,
    decls: 3,
    vars: 1,
    consts: [[1, "wrapper"], ["size", "6", "class", "ion-text-center", 4, "ngFor", "ngForOf"], ["size", "6", 1, "ion-text-center"], [1, "model", 3, "click"], [1, "text-bold"], [4, "ngIf"], [3, "name"], [1, "description"], ["name", "lock"]],
    template: function SelectChallengeModelComponent_Template(rf, ctx) {
      if (rf & 1) {
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](0, "ion-grid", 0)(1, "ion-row");
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵtemplate"](2, SelectChallengeModelComponent_ion_col_2_Template, 7, 9, "ion-col", 1);
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]()();
      }
      if (rf & 2) {
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵadvance"](2);
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵproperty"]("ngForOf", ctx.availableModels);
      }
    },
    dependencies: [_angular_common__WEBPACK_IMPORTED_MODULE_2__.NgForOf, _angular_common__WEBPACK_IMPORTED_MODULE_2__.NgIf, _ionic_angular__WEBPACK_IMPORTED_MODULE_3__.IonCol, _ionic_angular__WEBPACK_IMPORTED_MODULE_3__.IonGrid, _ionic_angular__WEBPACK_IMPORTED_MODULE_3__.IonRow, _core_shared_ui_icon_icon_component__WEBPACK_IMPORTED_MODULE_4__.IconComponent, _ngx_translate_core__WEBPACK_IMPORTED_MODULE_5__.TranslatePipe],
    styles: [".model[_ngcontent-%COMP%] {\n  border: 2px solid var(--ion-color-base);\n  background-color: var(--ion-color-lighter);\n  border-radius: 10px;\n  margin: 10px;\n  padding: 4px;\n  background-color: #f2f6fa;\n  height: 100%;\n}\n.model[_ngcontent-%COMP%]   .description[_ngcontent-%COMP%] {\n  font-size: 13px;\n  font-style: italic;\n}\n.model.disabled[_ngcontent-%COMP%] {\n  border-color: gray;\n  background-color: lightgray;\n}\n.model.selected[_ngcontent-%COMP%] {\n  border-width: 4px;\n  padding: 2px;\n  background-color: #fdfdaa;\n}\n.model[_ngcontent-%COMP%]   app-icon[_ngcontent-%COMP%] {\n  font-size: 32px;\n}\n/*# sourceMappingURL=data:application/json;charset=utf-8;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbIndlYnBhY2s6Ly8uL3NyYy9hcHAvcGFnZXMvY2hhbGxlbmdlcy9jcmVhdGUtY2hhbGxlbmdlL3NlbGVjdC1jaGFsbGVuZ2UtbW9kZWwvc2VsZWN0LWNoYWxsZW5nZS1tb2RlbC5jb21wb25lbnQuc2NzcyJdLCJuYW1lcyI6W10sIm1hcHBpbmdzIjoiQUFBQTtFQUNFLHVDQUFBO0VBQ0EsMENBQUE7RUFDQSxtQkFBQTtFQUNBLFlBQUE7RUFDQSxZQUFBO0VBQ0EseUJBQUE7RUFDQSxZQUFBO0FBQ0Y7QUFBRTtFQUNFLGVBQUE7RUFDQSxrQkFBQTtBQUVKO0FBQUU7RUFDRSxrQkFBQTtFQUNBLDJCQUFBO0FBRUo7QUFBRTtFQUNFLGlCQUFBO0VBQ0EsWUFBQTtFQUNBLHlCQUFBO0FBRUo7QUFBRTtFQUNFLGVBQUE7QUFFSiIsInNvdXJjZXNDb250ZW50IjpbIi5tb2RlbCB7XG4gIGJvcmRlcjogMnB4IHNvbGlkIHZhcigtLWlvbi1jb2xvci1iYXNlKTtcbiAgYmFja2dyb3VuZC1jb2xvcjogdmFyKC0taW9uLWNvbG9yLWxpZ2h0ZXIpO1xuICBib3JkZXItcmFkaXVzOiAxMHB4O1xuICBtYXJnaW46IDEwcHg7XG4gIHBhZGRpbmc6IDRweDtcbiAgYmFja2dyb3VuZC1jb2xvcjogI2YyZjZmYTtcbiAgaGVpZ2h0OiAxMDAlO1xuICAuZGVzY3JpcHRpb24ge1xuICAgIGZvbnQtc2l6ZTogMTNweDtcbiAgICBmb250LXN0eWxlOiBpdGFsaWM7XG4gIH1cbiAgJi5kaXNhYmxlZCB7XG4gICAgYm9yZGVyLWNvbG9yOiBncmF5O1xuICAgIGJhY2tncm91bmQtY29sb3I6IGxpZ2h0Z3JheTtcbiAgfVxuICAmLnNlbGVjdGVkIHtcbiAgICBib3JkZXItd2lkdGg6IDRweDtcbiAgICBwYWRkaW5nOiAycHg7XG4gICAgYmFja2dyb3VuZC1jb2xvcjogI2ZkZmRhYTtcbiAgfVxuICBhcHAtaWNvbiB7XG4gICAgZm9udC1zaXplOiAzMnB4O1xuICB9XG59XG4iXSwic291cmNlUm9vdCI6IiJ9 */"]
  }));
}
_staticBlock();

/***/ }),

/***/ 73302:
/*!**************************************************************************************!*\
  !*** ./src/app/pages/challenges/create-challenge/create-challenge-routing.module.ts ***!
  \**************************************************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   CreateChallengePageRoutingModule: () => (/* binding */ CreateChallengePageRoutingModule)
/* harmony export */ });
/* harmony import */ var _angular_router__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! @angular/router */ 34487);
/* harmony import */ var _create_challenge_page__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ./create-challenge.page */ 20168);
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @angular/core */ 34205);
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @angular/core */ 12481);
var _staticBlock;




const routes = [{
  path: '',
  component: _create_challenge_page__WEBPACK_IMPORTED_MODULE_1__.CreateChallengePage,
  data: {
    title: 'challenges.create.title'
  }
}];
class CreateChallengePageRoutingModule {
  static #_ = _staticBlock = () => (this.ɵfac = function CreateChallengePageRoutingModule_Factory(__ngFactoryType__) {
    return new (__ngFactoryType__ || CreateChallengePageRoutingModule)();
  }, this.ɵmod = /*@__PURE__*/_angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵdefineNgModule"]({
    type: CreateChallengePageRoutingModule
  }), this.ɵinj = /*@__PURE__*/_angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵdefineInjector"]({
    imports: [_angular_router__WEBPACK_IMPORTED_MODULE_0__.RouterModule.forChild(routes), _angular_router__WEBPACK_IMPORTED_MODULE_0__.RouterModule]
  }));
}
_staticBlock();
(function () {
  (typeof ngJitMode === "undefined" || ngJitMode) && _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵsetNgModuleScope"](CreateChallengePageRoutingModule, {
    imports: [_angular_router__WEBPACK_IMPORTED_MODULE_0__.RouterModule],
    exports: [_angular_router__WEBPACK_IMPORTED_MODULE_0__.RouterModule]
  });
})();

/***/ }),

/***/ 86791:
/*!****************************************************************************************************!*\
  !*** ./src/app/pages/challenges/create-challenge/challenge-preview/challenge-preview.component.ts ***!
  \****************************************************************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   ChallengePreviewComponent: () => (/* binding */ ChallengePreviewComponent)
/* harmony export */ });
/* harmony import */ var rxjs__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! rxjs */ 70271);
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @angular/core */ 12481);
/* harmony import */ var src_app_core_shared_services_user_service__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! src/app/core/shared/services/user.service */ 89815);
/* harmony import */ var _angular_common__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @angular/common */ 93683);
/* harmony import */ var _ionic_angular__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! @ionic/angular */ 21507);
/* harmony import */ var _ngx_translate_core__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! @ngx-translate/core */ 48503);
/* harmony import */ var _core_shared_pipes_languageMap_pipe__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! ../../../../core/shared/pipes/languageMap.pipe */ 69618);
var _staticBlock;







function ChallengePreviewComponent_ng_container_0_Template(rf, ctx) {
  if (rf & 1) {
    _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵelementContainerStart"](0);
    _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵelementStart"](1, "ion-grid")(2, "ion-row", 1)(3, "ion-col", 2);
    _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵtext"](4);
    _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵpipe"](5, "languageMap");
    _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵelementEnd"]()();
    _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵelementStart"](6, "ion-row", 3)(7, "ion-col", 4)(8, "ion-avatar");
    _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵelement"](9, "img", 5);
    _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵpipe"](10, "async");
    _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵelementEnd"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵtext"](11);
    _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵpipe"](12, "translate");
    _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵelementEnd"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵelementStart"](13, "ion-col", 4)(14, "ion-avatar");
    _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵelement"](15, "img", 5);
    _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵelementEnd"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵtext"](16);
    _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵelementEnd"]()();
    _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵelementStart"](17, "ion-row", 1)(18, "ion-col", 6);
    _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵtext"](19);
    _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵpipe"](20, "translate");
    _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵelementEnd"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵelementStart"](21, "ion-col", 7);
    _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵtext"](22);
    _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵpipe"](23, "translate");
    _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵelementEnd"]()();
    _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵelementStart"](24, "ion-row")(25, "ion-col", 6);
    _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵtext"](26);
    _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵpipe"](27, "translate");
    _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵelementEnd"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵelementStart"](28, "ion-col", 7);
    _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵtext"](29);
    _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵpipe"](30, "translate");
    _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵelementEnd"]()();
    _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵelementStart"](31, "ion-row")(32, "ion-col", 6);
    _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵtext"](33);
    _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵpipe"](34, "translate");
    _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵelementEnd"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵelementStart"](35, "ion-col", 7);
    _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵtext"](36);
    _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵelementEnd"]()();
    _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵelementStart"](37, "ion-row", 1)(38, "ion-col", 8);
    _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵtext"](39);
    _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵpipe"](40, "languageMap");
    _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵelementEnd"]()()();
    _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵelementContainerEnd"]();
  }
  if (rf & 2) {
    const ctx_r0 = _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵnextContext"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵadvance"](4);
    _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵtextInterpolate"](_angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵpipeBind1"](5, 12, ctx_r0.preview.description));
    _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵadvance"](5);
    _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵproperty"]("src", _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵpipeBind1"](10, 14, ctx_r0.avatarUrl$), _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵsanitizeUrl"]);
    _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵadvance"](2);
    _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵtextInterpolate1"](" ", _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵpipeBind1"](12, 16, "challenges.create.preview.you"), " ");
    _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵadvance"](4);
    _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵproperty"]("src", ctx_r0.challengeable.avatarUrl, _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵsanitizeUrl"]);
    _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵadvance"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵtextInterpolate1"](" ", ctx_r0.challengeable.nickname, " ");
    _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵadvance"](3);
    _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵtextInterpolate"](_angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵpipeBind1"](20, 18, "challenges.create.preview.model"));
    _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵadvance"](3);
    _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵtextInterpolate"](_angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵpipeBind1"](23, 20, "challenges.challenge_model.name." + ctx_r0.challengeModelName));
    _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵadvance"](4);
    _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵtextInterpolate"](_angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵpipeBind1"](27, 22, "challenges.create.preview.mean"));
    _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵadvance"](3);
    _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵtextInterpolate"](_angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵpipeBind1"](30, 24, "challenges.challenge_mean.pointconcept." + ctx_r0.pointConcept));
    _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵadvance"](4);
    _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵtextInterpolate"](_angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵpipeBind1"](34, 26, "challenges.create.preview.challengeable"));
    _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵadvance"](3);
    _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵtextInterpolate"](ctx_r0.challengeable.nickname);
    _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵadvance"](3);
    _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵtextInterpolate"](_angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵpipeBind1"](40, 28, ctx_r0.preview.longDescription));
  }
}
class ChallengePreviewComponent {
  constructor(userService) {
    this.userService = userService;
    this.avatarUrl$ = this.userService.userProfile$.pipe((0,rxjs__WEBPACK_IMPORTED_MODULE_0__.map)(profile => profile.avatar.avatarSmallUrl));
  }
  ngOnInit() {}
  static #_ = _staticBlock = () => (this.ɵfac = function ChallengePreviewComponent_Factory(__ngFactoryType__) {
    return new (__ngFactoryType__ || ChallengePreviewComponent)(_angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵdirectiveInject"](src_app_core_shared_services_user_service__WEBPACK_IMPORTED_MODULE_2__.UserService));
  }, this.ɵcmp = /*@__PURE__*/_angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵdefineComponent"]({
    type: ChallengePreviewComponent,
    selectors: [["app-challenge-preview"]],
    inputs: {
      challengeModelName: "challengeModelName",
      pointConcept: "pointConcept",
      challengeable: "challengeable",
      preview: "preview"
    },
    standalone: false,
    decls: 1,
    vars: 1,
    consts: [[4, "ngIf"], [1, "ion-margin-top"], [1, "text-bold", "ion-text-center"], [1, "ion-justify-content-around", "ion-margin-top"], ["size", "auto", 1, "ion-text-center"], [3, "src"], [1, "ion-text-left"], [1, "ion-text-right", "text-bold"], [1, "text-italic"]],
    template: function ChallengePreviewComponent_Template(rf, ctx) {
      if (rf & 1) {
        _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵtemplate"](0, ChallengePreviewComponent_ng_container_0_Template, 41, 30, "ng-container", 0);
      }
      if (rf & 2) {
        _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵproperty"]("ngIf", ctx.preview);
      }
    },
    dependencies: [_angular_common__WEBPACK_IMPORTED_MODULE_3__.NgIf, _ionic_angular__WEBPACK_IMPORTED_MODULE_4__.IonAvatar, _ionic_angular__WEBPACK_IMPORTED_MODULE_4__.IonCol, _ionic_angular__WEBPACK_IMPORTED_MODULE_4__.IonGrid, _ionic_angular__WEBPACK_IMPORTED_MODULE_4__.IonRow, _angular_common__WEBPACK_IMPORTED_MODULE_3__.AsyncPipe, _ngx_translate_core__WEBPACK_IMPORTED_MODULE_5__.TranslatePipe, _core_shared_pipes_languageMap_pipe__WEBPACK_IMPORTED_MODULE_6__.LanguageMapPipe],
    styles: ["/*# sourceMappingURL=data:application/json;charset=utf-8;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbXSwibmFtZXMiOltdLCJtYXBwaW5ncyI6IiIsInNvdXJjZVJvb3QiOiIifQ== */"]
  }));
}
_staticBlock();

/***/ }),

/***/ 99181:
/*!**********************************************************************************************************!*\
  !*** ./src/app/pages/challenges/create-challenge/select-challengeable/select-challengeable.component.ts ***!
  \**********************************************************************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   SelectChallengeableComponent: () => (/* binding */ SelectChallengeableComponent)
/* harmony export */ });
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! @angular/core */ 12481);
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @angular/core */ 34205);
/* harmony import */ var _angular_common__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @angular/common */ 93683);
/* harmony import */ var _angular_forms__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @angular/forms */ 34456);
/* harmony import */ var _ionic_angular__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! @ionic/angular */ 21507);
/* harmony import */ var _core_shared_pipes_filter_pipe__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! ../../../../core/shared/pipes/filter.pipe */ 82310);
var _staticBlock;






const _c0 = () => ["nickname"];
function SelectChallengeableComponent_ion_item_1_ion_icon_5_Template(rf, ctx) {
  if (rf & 1) {
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelement"](0, "ion-icon", 5);
  }
}
function SelectChallengeableComponent_ion_item_1_Template(rf, ctx) {
  if (rf & 1) {
    const _r1 = _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵgetCurrentView"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](0, "ion-item", 2);
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵlistener"]("click", function SelectChallengeableComponent_ion_item_1_Template_ion_item_click_0_listener() {
      const user_r2 = _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵrestoreView"](_r1).$implicit;
      const ctx_r2 = _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵnextContext"]();
      return _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵresetView"](ctx_r2.selectChallengeable(user_r2));
    });
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](1, "ion-avatar");
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelement"](2, "img", 3);
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](3, "ion-label");
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵtext"](4);
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵtemplate"](5, SelectChallengeableComponent_ion_item_1_ion_icon_5_Template, 1, 0, "ion-icon", 4);
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();
  }
  if (rf & 2) {
    const user_r2 = ctx.$implicit;
    const ctx_r2 = _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵnextContext"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵclassProp"]("selected", user_r2.id === ctx_r2.selectedChallengeableId);
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵadvance"](2);
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵproperty"]("src", user_r2.avatarUrl, _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵsanitizeUrl"]);
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵadvance"](2);
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵtextInterpolate1"](" ", user_r2.nickname, " ");
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵadvance"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵproperty"]("ngIf", user_r2.id === ctx_r2.selectedChallengeableId);
  }
}
class SelectChallengeableComponent {
  constructor() {
    this.selectedChallengeable = new _angular_core__WEBPACK_IMPORTED_MODULE_0__.EventEmitter();
  }
  selectChallengeable(challengeable) {
    this.selectedChallengeableId = challengeable.id;
    this.selectedChallengeable.emit(this.selectedChallengeableId);
  }
  static #_ = _staticBlock = () => (this.ɵfac = function SelectChallengeableComponent_Factory(__ngFactoryType__) {
    return new (__ngFactoryType__ || SelectChallengeableComponent)();
  }, this.ɵcmp = /*@__PURE__*/_angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵdefineComponent"]({
    type: SelectChallengeableComponent,
    selectors: [["app-select-challengeable"]],
    inputs: {
      availableChallengeables: "availableChallengeables"
    },
    outputs: {
      selectedChallengeable: "selectedChallengeable"
    },
    standalone: false,
    decls: 3,
    vars: 7,
    consts: [["color", "light", "mode", "ios", "placeholder", "nome utente", 1, "ion-no-padding", 3, "ngModelChange", "ngModel"], ["class", "user", 3, "selected", "click", 4, "ngFor", "ngForOf"], [1, "user", 3, "click"], [3, "src"], ["color", "success", "name", "checkmark", 4, "ngIf"], ["color", "success", "name", "checkmark"]],
    template: function SelectChallengeableComponent_Template(rf, ctx) {
      if (rf & 1) {
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](0, "ion-searchbar", 0);
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵtwoWayListener"]("ngModelChange", function SelectChallengeableComponent_Template_ion_searchbar_ngModelChange_0_listener($event) {
          _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵtwoWayBindingSet"](ctx.searchData, $event) || (ctx.searchData = $event);
          return $event;
        });
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵtemplate"](1, SelectChallengeableComponent_ion_item_1_Template, 6, 5, "ion-item", 1);
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵpipe"](2, "filterData");
      }
      if (rf & 2) {
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵtwoWayProperty"]("ngModel", ctx.searchData);
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵadvance"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵproperty"]("ngForOf", _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵpipeBind3"](2, 2, ctx.availableChallengeables, _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵpureFunction0"](6, _c0), ctx.searchData));
      }
    },
    dependencies: [_angular_common__WEBPACK_IMPORTED_MODULE_2__.NgForOf, _angular_common__WEBPACK_IMPORTED_MODULE_2__.NgIf, _angular_forms__WEBPACK_IMPORTED_MODULE_3__.NgControlStatus, _angular_forms__WEBPACK_IMPORTED_MODULE_3__.NgModel, _ionic_angular__WEBPACK_IMPORTED_MODULE_4__.IonAvatar, _ionic_angular__WEBPACK_IMPORTED_MODULE_4__.IonIcon, _ionic_angular__WEBPACK_IMPORTED_MODULE_4__.IonItem, _ionic_angular__WEBPACK_IMPORTED_MODULE_4__.IonLabel, _ionic_angular__WEBPACK_IMPORTED_MODULE_4__.IonSearchbar, _ionic_angular__WEBPACK_IMPORTED_MODULE_4__.TextValueAccessor, _core_shared_pipes_filter_pipe__WEBPACK_IMPORTED_MODULE_5__.FilterPipe],
    styles: [".user.selected[_ngcontent-%COMP%] {\n  --border-color: var(--ion-color-base);\n  border: 2px solid var(--ion-color-base);\n}\n.user[_ngcontent-%COMP%]   ion-label[_ngcontent-%COMP%] {\n  margin-left: 17px;\n}\n/*# sourceMappingURL=data:application/json;charset=utf-8;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbIndlYnBhY2s6Ly8uL3NyYy9hcHAvcGFnZXMvY2hhbGxlbmdlcy9jcmVhdGUtY2hhbGxlbmdlL3NlbGVjdC1jaGFsbGVuZ2VhYmxlL3NlbGVjdC1jaGFsbGVuZ2VhYmxlLmNvbXBvbmVudC5zY3NzIl0sIm5hbWVzIjpbXSwibWFwcGluZ3MiOiJBQUNFO0VBQ0UscUNBQUE7RUFDQSx1Q0FBQTtBQUFKO0FBRUU7RUFDRSxpQkFBQTtBQUFKIiwic291cmNlc0NvbnRlbnQiOlsiLnVzZXIge1xuICAmLnNlbGVjdGVkIHtcbiAgICAtLWJvcmRlci1jb2xvcjogdmFyKC0taW9uLWNvbG9yLWJhc2UpO1xuICAgIGJvcmRlcjogMnB4IHNvbGlkIHZhcigtLWlvbi1jb2xvci1iYXNlKTtcbiAgfVxuICBpb24tbGFiZWwge1xuICAgIG1hcmdpbi1sZWZ0OiAxN3B4O1xuICB9XG59XG4iXSwic291cmNlUm9vdCI6IiJ9 */"]
  }));
}
_staticBlock();

/***/ })

}]);
//# sourceMappingURL=src_app_pages_challenges_create-challenge_create-challenge_module_ts.js.map