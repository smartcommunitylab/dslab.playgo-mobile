"use strict";
(self["webpackChunkapp"] = self["webpackChunkapp"] || []).push([["src_app_pages_challenges_challenges_module_ts"],{

/***/ 12298:
/*!*****************************************************************************************************!*\
  !*** ./src/app/pages/challenges/single-challenge-proposed/single-proposal/single-proposal.modal.ts ***!
  \*****************************************************************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   SingleProposalModalPage: () => (/* binding */ SingleProposalModalPage)
/* harmony export */ });
/* harmony import */ var _Users_smartcommunitylab_Desktop_newWork_playAndGo_playGo_node_modules_babel_runtime_helpers_esm_asyncToGenerator_js__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./node_modules/@babel/runtime/helpers/esm/asyncToGenerator.js */ 89204);
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @angular/core */ 12481);
/* harmony import */ var _ionic_angular__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @ionic/angular */ 21507);
/* harmony import */ var src_app_core_shared_services_challenge_service__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! src/app/core/shared/services/challenge.service */ 16561);
/* harmony import */ var src_app_core_shared_services_campaign_service__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! src/app/core/shared/services/campaign.service */ 76658);
/* harmony import */ var src_app_core_shared_services_error_service__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! src/app/core/shared/services/error.service */ 46078);
/* harmony import */ var _core_shared_ui_icon_icon_component__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! ../../../../core/shared/ui/icon/icon.component */ 59621);
/* harmony import */ var _ngx_translate_core__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(/*! @ngx-translate/core */ 48503);
/* harmony import */ var _core_shared_pipes_localDate_pipe__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(/*! ../../../../core/shared/pipes/localDate.pipe */ 86451);
/* harmony import */ var _core_shared_pipes_languageMap_pipe__WEBPACK_IMPORTED_MODULE_9__ = __webpack_require__(/*! ../../../../core/shared/pipes/languageMap.pipe */ 69618);

var _staticBlock;









const _c0 = (a0, a1) => ({
  from: a0,
  to: a1
});
class SingleProposalModalPage {
  constructor(modalController, challengeService, campaignService, errorService) {
    this.modalController = modalController;
    this.challengeService = challengeService;
    this.campaignService = campaignService;
    this.errorService = errorService;
  }
  ngOnInit() {}
  //computed errorcontrol
  close() {
    this.modalController.dismiss(false);
  }
  activate() {
    var _this = this;
    return (0,_Users_smartcommunitylab_Desktop_newWork_playAndGo_playGo_node_modules_babel_runtime_helpers_esm_asyncToGenerator_js__WEBPACK_IMPORTED_MODULE_0__["default"])(function* () {
      try {
        yield _this.challengeService.acceptSingleChallenge(_this.campaign, _this.challenge);
      } catch (e) {
        _this.errorService.handleError(e);
      } finally {
        _this.modalController.dismiss(true);
      }
    })();
  }
  static #_ = _staticBlock = () => (this.ɵfac = function SingleProposalModalPage_Factory(__ngFactoryType__) {
    return new (__ngFactoryType__ || SingleProposalModalPage)(_angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵdirectiveInject"](_ionic_angular__WEBPACK_IMPORTED_MODULE_2__.ModalController), _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵdirectiveInject"](src_app_core_shared_services_challenge_service__WEBPACK_IMPORTED_MODULE_3__.ChallengeService), _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵdirectiveInject"](src_app_core_shared_services_campaign_service__WEBPACK_IMPORTED_MODULE_4__.CampaignService), _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵdirectiveInject"](src_app_core_shared_services_error_service__WEBPACK_IMPORTED_MODULE_5__.ErrorService));
  }, this.ɵcmp = /*@__PURE__*/_angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵdefineComponent"]({
    type: SingleProposalModalPage,
    selectors: [["app-single-proposal"]],
    standalone: false,
    decls: 39,
    vars: 27,
    consts: [[3, "color"], ["slot", "end"], [3, "click"], ["name", "close-circle-outline"], ["size", "3", 1, "ion-text-center"], ["name", "default", 1, "icon-size-big"], [1, "flex-center"], [1, "title-challenge"], [1, "desc-challenge"], [1, "ion-text-center"], [3, "click", "color"], ["size", "8", 1, "ion-text-left"], [1, "date-challenge"], [1, "ion-text-end"], [1, "flex-center", "date-challenge"], [3, "name"]],
    template: function SingleProposalModalPage_Template(rf, ctx) {
      if (rf & 1) {
        _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵelementStart"](0, "ion-header")(1, "ion-toolbar", 0)(2, "ion-title");
        _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵtext"](3);
        _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵpipe"](4, "languageMap");
        _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵelementStart"](5, "ion-buttons", 1)(6, "ion-button", 2);
        _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵlistener"]("click", function SingleProposalModalPage_Template_ion_button_click_6_listener() {
          return ctx.close();
        });
        _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵelement"](7, "ion-icon", 3);
        _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵelementEnd"]()()()();
        _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵelementStart"](8, "ion-content")(9, "ion-grid")(10, "ion-row")(11, "ion-col", 4);
        _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵelement"](12, "app-icon", 5);
        _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵelementStart"](13, "ion-col", 6)(14, "span", 7);
        _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵtext"](15);
        _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵpipe"](16, "translate");
        _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵelementEnd"]()()();
        _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵelementStart"](17, "ion-row")(18, "ion-col")(19, "span", 8);
        _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵtext"](20);
        _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵpipe"](21, "languageMap");
        _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵelementEnd"]()()()()();
        _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵelementStart"](22, "ion-footer")(23, "ion-row")(24, "ion-col", 9)(25, "ion-button", 10);
        _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵlistener"]("click", function SingleProposalModalPage_Template_ion_button_click_25_listener() {
          return ctx.activate();
        });
        _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵtext"](26);
        _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵpipe"](27, "translate");
        _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵelementEnd"]()()();
        _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵelementStart"](28, "ion-row")(29, "ion-col", 11)(30, "span", 12);
        _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵtext"](31);
        _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵpipe"](32, "localDate");
        _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵpipe"](33, "localDate");
        _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵpipe"](34, "translate");
        _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵelementEnd"]()();
        _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵelementStart"](35, "ion-col", 13)(36, "span", 14);
        _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵtext"](37);
        _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵelement"](38, "app-icon", 15);
        _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵelementEnd"]()()()();
      }
      if (rf & 2) {
        _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵadvance"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵproperty"]("color", ctx.campaign.campaign.type);
        _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵadvance"](2);
        _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵtextInterpolate1"](" ", _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵpipeBind1"](4, 9, ctx.campaign.campaign.name), " ");
        _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵadvance"](12);
        _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵtextInterpolate"](_angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵpipeBind1"](16, 11, "challenges.singleproposal"));
        _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵadvance"](5);
        _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵtextInterpolate"](_angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵpipeBind1"](21, 13, ctx.challenge.challDesc));
        _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵadvance"](5);
        _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵproperty"]("color", ctx.campaign == null ? null : ctx.campaign.campaign == null ? null : ctx.campaign.campaign.type);
        _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵadvance"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵtextInterpolate1"](" ", _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵpipeBind1"](27, 15, "challenges.activate"), " ");
        _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵadvance"](5);
        _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵtextInterpolate"](_angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵpipeBind2"](34, 21, "challenges.fromto", _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵpureFunction2"](24, _c0, _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵpipeBind1"](32, 17, ctx.challenge.startDate), _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵpipeBind1"](33, 19, ctx.challenge.endDate))));
        _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵadvance"](6);
        _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵtextInterpolate1"]("", ctx.challenge.bonus, " ");
        _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵadvance"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵproperty"]("name", ctx.campaignService.getCampaignTypeIcon(ctx.campaign == null ? null : ctx.campaign.campaign));
      }
    },
    dependencies: [_ionic_angular__WEBPACK_IMPORTED_MODULE_2__.IonButton, _ionic_angular__WEBPACK_IMPORTED_MODULE_2__.IonButtons, _ionic_angular__WEBPACK_IMPORTED_MODULE_2__.IonCol, _ionic_angular__WEBPACK_IMPORTED_MODULE_2__.IonContent, _ionic_angular__WEBPACK_IMPORTED_MODULE_2__.IonFooter, _ionic_angular__WEBPACK_IMPORTED_MODULE_2__.IonGrid, _ionic_angular__WEBPACK_IMPORTED_MODULE_2__.IonHeader, _ionic_angular__WEBPACK_IMPORTED_MODULE_2__.IonIcon, _ionic_angular__WEBPACK_IMPORTED_MODULE_2__.IonRow, _ionic_angular__WEBPACK_IMPORTED_MODULE_2__.IonTitle, _ionic_angular__WEBPACK_IMPORTED_MODULE_2__.IonToolbar, _core_shared_ui_icon_icon_component__WEBPACK_IMPORTED_MODULE_6__.IconComponent, _ngx_translate_core__WEBPACK_IMPORTED_MODULE_7__.TranslatePipe, _core_shared_pipes_localDate_pipe__WEBPACK_IMPORTED_MODULE_8__.LocalDatePipe, _core_shared_pipes_languageMap_pipe__WEBPACK_IMPORTED_MODULE_9__.LanguageMapPipe],
    styles: ["ion-footer[_ngcontent-%COMP%] {\n  color: black;\n}\n\n.title-challenge[_ngcontent-%COMP%] {\n  font-style: italic;\n  font-weight: 200;\n  font-size: 16px;\n}\n\n.desc-challenge[_ngcontent-%COMP%] {\n  font-style: normal;\n  font-weight: 300;\n  font-size: 17px;\n}\n\n.date-challenge[_ngcontent-%COMP%] {\n  font-style: italic;\n  font-weight: 300;\n  font-size: 13px;\n}\n/*# sourceMappingURL=data:application/json;charset=utf-8;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbIndlYnBhY2s6Ly8uL3NyYy9hcHAvcGFnZXMvY2hhbGxlbmdlcy9zaW5nbGUtY2hhbGxlbmdlLXByb3Bvc2VkL3NpbmdsZS1wcm9wb3NhbC9zaW5nbGUtcHJvcG9zYWwubW9kYWwuc2NzcyJdLCJuYW1lcyI6W10sIm1hcHBpbmdzIjoiQUFBQTtFQUNFLFlBQUE7QUFDRjs7QUFDQTtFQUNFLGtCQUFBO0VBQ0EsZ0JBQUE7RUFDQSxlQUFBO0FBRUY7O0FBQUE7RUFDRSxrQkFBQTtFQUNBLGdCQUFBO0VBQ0EsZUFBQTtBQUdGOztBQURBO0VBQ0Usa0JBQUE7RUFDQSxnQkFBQTtFQUNBLGVBQUE7QUFJRiIsInNvdXJjZXNDb250ZW50IjpbImlvbi1mb290ZXIge1xuICBjb2xvcjogYmxhY2s7XG59XG4udGl0bGUtY2hhbGxlbmdlIHtcbiAgZm9udC1zdHlsZTogaXRhbGljO1xuICBmb250LXdlaWdodDogMjAwO1xuICBmb250LXNpemU6IDE2cHg7XG59XG4uZGVzYy1jaGFsbGVuZ2Uge1xuICBmb250LXN0eWxlOiBub3JtYWw7XG4gIGZvbnQtd2VpZ2h0OiAzMDA7XG4gIGZvbnQtc2l6ZTogMTdweDtcbn1cbi5kYXRlLWNoYWxsZW5nZSB7XG4gIGZvbnQtc3R5bGU6IGl0YWxpYztcbiAgZm9udC13ZWlnaHQ6IDMwMDtcbiAgZm9udC1zaXplOiAxM3B4O1xufVxuIl0sInNvdXJjZVJvb3QiOiIifQ== */"]
  }));
}
_staticBlock();

/***/ }),

/***/ 12558:
/*!***********************************************************************************************************!*\
  !*** ./src/app/pages/challenges/challenges-stat/challenge-single-stat/challenge-single-stat.component.ts ***!
  \***********************************************************************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   ChalengeSingleStatComponent: () => (/* binding */ ChalengeSingleStatComponent)
/* harmony export */ });
/* harmony import */ var src_app_core_shared_campaigns_campaign_utils__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! src/app/core/shared/campaigns/campaign.utils */ 14691);
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @angular/core */ 12481);
/* harmony import */ var _ngx_translate_core__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @ngx-translate/core */ 48503);
/* harmony import */ var _angular_common__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @angular/common */ 93683);
/* harmony import */ var _core_shared_ui_icon_icon_component__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! ../../../../core/shared/ui/icon/icon.component */ 59621);
var _staticBlock;





function ChalengeSingleStatComponent_div_8_span_3_Template(rf, ctx) {
  if (rf & 1) {
    _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵelementStart"](0, "span");
    _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵtext"](1);
    _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵpipe"](2, "translate");
    _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵelementEnd"]();
  }
  if (rf & 2) {
    _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵadvance"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵtextInterpolate1"]("\u00A0", _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵpipeBind1"](2, 1, "challenges.stats.singleChallengeWin.single"));
  }
}
function ChalengeSingleStatComponent_div_8_span_4_Template(rf, ctx) {
  if (rf & 1) {
    _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵelementStart"](0, "span");
    _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵtext"](1);
    _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵpipe"](2, "translate");
    _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵelementEnd"]();
  }
  if (rf & 2) {
    _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵadvance"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵtextInterpolate1"]("\u00A0", _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵpipeBind1"](2, 1, "challenges.stats.singleChallengeWin.plural"));
  }
}
function ChalengeSingleStatComponent_div_8_Template(rf, ctx) {
  if (rf & 1) {
    _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵelementStart"](0, "div", 7)(1, "span");
    _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵtext"](2);
    _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵelementEnd"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵtemplate"](3, ChalengeSingleStatComponent_div_8_span_3_Template, 3, 3, "span", 8)(4, ChalengeSingleStatComponent_div_8_span_4_Template, 3, 3, "span", 8);
    _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵelementEnd"]();
  }
  if (rf & 2) {
    const ctx_r0 = _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵnextContext"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵadvance"](2);
    _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵtextInterpolate"](ctx_r0.stat.completed);
    _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵadvance"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵproperty"]("ngIf", ctx_r0.stat.completed <= 1);
    _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵadvance"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵproperty"]("ngIf", ctx_r0.stat.completed > 1);
  }
}
function ChalengeSingleStatComponent_div_9_span_3_Template(rf, ctx) {
  if (rf & 1) {
    _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵelementStart"](0, "span");
    _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵtext"](1);
    _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵpipe"](2, "translate");
    _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵelementEnd"]();
  }
  if (rf & 2) {
    _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵadvance"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵtextInterpolate1"]("\u00A0", _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵpipeBind1"](2, 1, "challenges.stats.singleChallengeLost.single"));
  }
}
function ChalengeSingleStatComponent_div_9_span_4_Template(rf, ctx) {
  if (rf & 1) {
    _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵelementStart"](0, "span");
    _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵtext"](1);
    _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵpipe"](2, "translate");
    _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵelementEnd"]();
  }
  if (rf & 2) {
    _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵadvance"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵtextInterpolate1"]("\u00A0", _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵpipeBind1"](2, 1, "challenges.stats.singleChallengeLost.plural"));
  }
}
function ChalengeSingleStatComponent_div_9_Template(rf, ctx) {
  if (rf & 1) {
    _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵelementStart"](0, "div", 9)(1, "span");
    _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵtext"](2);
    _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵelementEnd"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵtemplate"](3, ChalengeSingleStatComponent_div_9_span_3_Template, 3, 3, "span", 8)(4, ChalengeSingleStatComponent_div_9_span_4_Template, 3, 3, "span", 8);
    _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵelementEnd"]();
  }
  if (rf & 2) {
    const ctx_r0 = _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵnextContext"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵadvance"](2);
    _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵtextInterpolate"](ctx_r0.stat.failed);
    _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵadvance"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵproperty"]("ngIf", ctx_r0.stat.failed <= 1);
    _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵadvance"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵproperty"]("ngIf", ctx_r0.stat.failed > 1);
  }
}
class ChalengeSingleStatComponent {
  constructor(translateService) {
    this.translateService = translateService;
    this.imgChallenge = src_app_core_shared_campaigns_campaign_utils__WEBPACK_IMPORTED_MODULE_0__.getImgChallenge;
  }
  ngOnInit() {
    this.typeChallenge = this.kind === "school" && this.stat.type === 'single' ? this.translateService.instant('challenges.challenge_model.name.default-team') : this.translateService.instant((0,src_app_core_shared_campaigns_campaign_utils__WEBPACK_IMPORTED_MODULE_0__.getTypeStringChallenge)(this.stat.type));
  }
  static #_ = _staticBlock = () => (this.ɵfac = function ChalengeSingleStatComponent_Factory(__ngFactoryType__) {
    return new (__ngFactoryType__ || ChalengeSingleStatComponent)(_angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵdirectiveInject"](_ngx_translate_core__WEBPACK_IMPORTED_MODULE_2__.TranslateService));
  }, this.ɵcmp = /*@__PURE__*/_angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵdefineComponent"]({
    type: ChalengeSingleStatComponent,
    selectors: [["app-challenge-single-stat"]],
    inputs: {
      stat: "stat",
      kind: "kind"
    },
    standalone: false,
    decls: 10,
    vars: 4,
    consts: [[1, "container"], [1, "single-stat-container"], [1, "single-stat-content"], [1, "ion-text-center"], [1, "icon-size-big", 3, "name"], ["class", "challenge-won", 4, "ngIf"], ["class", "challenge-lost", 4, "ngIf"], [1, "challenge-won"], [4, "ngIf"], [1, "challenge-lost"]],
    template: function ChalengeSingleStatComponent_Template(rf, ctx) {
      if (rf & 1) {
        _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵelementStart"](0, "div", 0)(1, "div", 1)(2, "div", 2)(3, "div", 3);
        _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵelement"](4, "app-icon", 4);
        _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵelementStart"](5, "div", 3)(6, "div");
        _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵtext"](7);
        _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵtemplate"](8, ChalengeSingleStatComponent_div_8_Template, 5, 3, "div", 5)(9, ChalengeSingleStatComponent_div_9_Template, 5, 3, "div", 6);
        _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵelementEnd"]()()()();
      }
      if (rf & 2) {
        _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵadvance"](4);
        _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵproperty"]("name", ctx.imgChallenge(ctx.stat.type));
        _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵadvance"](3);
        _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵtextInterpolate"](ctx.typeChallenge);
        _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵadvance"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵproperty"]("ngIf", ctx.stat.completed);
        _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵadvance"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵproperty"]("ngIf", ctx.stat.failed);
      }
    },
    dependencies: [_angular_common__WEBPACK_IMPORTED_MODULE_3__.NgIf, _core_shared_ui_icon_icon_component__WEBPACK_IMPORTED_MODULE_4__.IconComponent, _ngx_translate_core__WEBPACK_IMPORTED_MODULE_2__.TranslatePipe],
    styles: [".container[_ngcontent-%COMP%] {\n  display: flex;\n  justify-content: center;\n}\n.container[_ngcontent-%COMP%]   .single-stat-container[_ngcontent-%COMP%] {\n  display: flex;\n  align-items: center;\n  justify-content: center;\n}\n.container[_ngcontent-%COMP%]   .single-stat-container[_ngcontent-%COMP%]   .single-stat-content[_ngcontent-%COMP%] {\n  width: 150px;\n  height: 150px;\n  border: solid 2px #ccc;\n  border-radius: 50%;\n  margin: auto;\n  font-size: 13px;\n}\n.container[_ngcontent-%COMP%]   .single-stat-container[_ngcontent-%COMP%]   .single-stat-content[_ngcontent-%COMP%]   .challenge-lost[_ngcontent-%COMP%] {\n  color: #c61010;\n  font-weight: 500;\n}\n.container[_ngcontent-%COMP%]   .single-stat-container[_ngcontent-%COMP%]   .single-stat-content[_ngcontent-%COMP%]   .challenge-won[_ngcontent-%COMP%] {\n  color: #359675;\n  font-weight: 500;\n}\n/*# sourceMappingURL=data:application/json;charset=utf-8;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbIndlYnBhY2s6Ly8uL3NyYy9hcHAvcGFnZXMvY2hhbGxlbmdlcy9jaGFsbGVuZ2VzLXN0YXQvY2hhbGxlbmdlLXNpbmdsZS1zdGF0L2NoYWxsZW5nZS1zaW5nbGUtc3RhdC5jb21wb25lbnQuc2NzcyJdLCJuYW1lcyI6W10sIm1hcHBpbmdzIjoiQUFBQTtFQUNFLGFBQUE7RUFDQSx1QkFBQTtBQUNGO0FBQUU7RUFDRSxhQUFBO0VBQ0EsbUJBQUE7RUFDQSx1QkFBQTtBQUVKO0FBREk7RUFDRSxZQUFBO0VBQ0EsYUFBQTtFQUNBLHNCQUFBO0VBQ0Esa0JBQUE7RUFDQSxZQUFBO0VBQ0EsZUFBQTtBQUdOO0FBRk07RUFDRSxjQUFBO0VBQ0EsZ0JBQUE7QUFJUjtBQUZNO0VBQ0UsY0FBQTtFQUNBLGdCQUFBO0FBSVIiLCJzb3VyY2VzQ29udGVudCI6WyIuY29udGFpbmVyIHtcbiAgZGlzcGxheTogZmxleDtcbiAganVzdGlmeS1jb250ZW50OiBjZW50ZXI7XG4gIC5zaW5nbGUtc3RhdC1jb250YWluZXIge1xuICAgIGRpc3BsYXk6IGZsZXg7XG4gICAgYWxpZ24taXRlbXM6IGNlbnRlcjtcbiAgICBqdXN0aWZ5LWNvbnRlbnQ6IGNlbnRlcjtcbiAgICAuc2luZ2xlLXN0YXQtY29udGVudCB7XG4gICAgICB3aWR0aDogMTUwcHg7XG4gICAgICBoZWlnaHQ6IDE1MHB4O1xuICAgICAgYm9yZGVyOiBzb2xpZCAycHggI2NjYztcbiAgICAgIGJvcmRlci1yYWRpdXM6IDUwJTtcbiAgICAgIG1hcmdpbjogYXV0bztcbiAgICAgIGZvbnQtc2l6ZTogMTNweDtcbiAgICAgIC5jaGFsbGVuZ2UtbG9zdCB7XG4gICAgICAgIGNvbG9yOiAjYzYxMDEwO1xuICAgICAgICBmb250LXdlaWdodDogNTAwO1xuICAgICAgfVxuICAgICAgLmNoYWxsZW5nZS13b24ge1xuICAgICAgICBjb2xvcjogIzM1OTY3NTtcbiAgICAgICAgZm9udC13ZWlnaHQ6IDUwMDtcbiAgICAgIH1cbiAgICB9XG4gIH1cbn1cbiJdLCJzb3VyY2VSb290IjoiIn0= */"]
  }));
}
_staticBlock();

/***/ }),

/***/ 14858:
/*!***************************************************************************************************!*\
  !*** ./src/app/pages/challenges/couple-challenge-proposed/couple-challenge-proposed.component.ts ***!
  \***************************************************************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   CoupleChallengeProposedComponent: () => (/* binding */ CoupleChallengeProposedComponent)
/* harmony export */ });
/* harmony import */ var _Users_smartcommunitylab_Desktop_newWork_playAndGo_playGo_node_modules_babel_runtime_helpers_esm_asyncToGenerator_js__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./node_modules/@babel/runtime/helpers/esm/asyncToGenerator.js */ 89204);
/* harmony import */ var rxjs__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! rxjs */ 70271);
/* harmony import */ var _invitation_challenge_invitation_challenge_modal__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! ./invitation-challenge/invitation-challenge.modal */ 86574);
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @angular/core */ 12481);
/* harmony import */ var src_app_core_shared_services_user_service__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! src/app/core/shared/services/user.service */ 89815);
/* harmony import */ var _ionic_angular__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! @ionic/angular */ 21507);
/* harmony import */ var _core_shared_ui_icon_icon_component__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! ../../../core/shared/ui/icon/icon.component */ 59621);
/* harmony import */ var _angular_common__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(/*! @angular/common */ 93683);
/* harmony import */ var _ngx_translate_core__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(/*! @ngx-translate/core */ 48503);
/* harmony import */ var _core_shared_pipes_languageMap_pipe__WEBPACK_IMPORTED_MODULE_9__ = __webpack_require__(/*! ../../../core/shared/pipes/languageMap.pipe */ 69618);

var _staticBlock;









const _c0 = a0 => ({
  nickname: a0
});
class CoupleChallengeProposedComponent {
  constructor(userService, modalController) {
    this.userService = userService;
    this.modalController = modalController;
    this.playerAvatarUrl$ = this.userService.userProfile$.pipe((0,rxjs__WEBPACK_IMPORTED_MODULE_1__.map)(userProfile => userProfile.avatar.avatarSmallUrl));
    this.playerId$ = this.userService.userProfile$.pipe((0,rxjs__WEBPACK_IMPORTED_MODULE_1__.map)(userProfile => userProfile.playerId));
  }
  ngOnInit() {}
  openInvitationPopup() {
    var _this = this;
    return (0,_Users_smartcommunitylab_Desktop_newWork_playAndGo_playGo_node_modules_babel_runtime_helpers_esm_asyncToGenerator_js__WEBPACK_IMPORTED_MODULE_0__["default"])(function* () {
      const modal = yield _this.modalController.create({
        component: _invitation_challenge_invitation_challenge_modal__WEBPACK_IMPORTED_MODULE_2__.InvitationlModalPage,
        cssClass: 'modal-challenge',
        componentProps: {
          challenge: _this.challenge,
          campaign: _this.campaign
        },
        canDismiss: true
      });
      yield modal.present();
      const {
        data
      } = yield modal.onWillDismiss();
    })();
  }
  static #_ = _staticBlock = () => (this.ɵfac = function CoupleChallengeProposedComponent_Factory(__ngFactoryType__) {
    return new (__ngFactoryType__ || CoupleChallengeProposedComponent)(_angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵdirectiveInject"](src_app_core_shared_services_user_service__WEBPACK_IMPORTED_MODULE_4__.UserService), _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵdirectiveInject"](_ionic_angular__WEBPACK_IMPORTED_MODULE_5__.ModalController));
  }, this.ɵcmp = /*@__PURE__*/_angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵdefineComponent"]({
    type: CoupleChallengeProposedComponent,
    selectors: [["app-couple-challenge-proposed"]],
    inputs: {
      challenge: "challenge",
      campaign: "campaign"
    },
    standalone: false,
    decls: 20,
    vars: 25,
    consts: [[3, "click"], [1, "header", 3, "color"], [1, "content"], [1, "ion-align-items-center"], ["size", "2"], [1, "avatar"], [3, "src", "title"], [1, "icon-size-medium", 3, "name"], [1, "flex-center"]],
    template: function CoupleChallengeProposedComponent_Template(rf, ctx) {
      if (rf & 1) {
        _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵelementStart"](0, "ion-card", 0);
        _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵlistener"]("click", function CoupleChallengeProposedComponent_Template_ion_card_click_0_listener() {
          return ctx.openInvitationPopup();
        });
        _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵelementStart"](1, "ion-card-header", 1)(2, "span");
        _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵtext"](3);
        _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵpipe"](4, "async");
        _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵpipe"](5, "translate");
        _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵpipe"](6, "translate");
        _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵelementEnd"]()();
        _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵelementStart"](7, "ion-card-content", 2)(8, "ion-grid")(9, "ion-row", 3)(10, "ion-col", 4)(11, "ion-avatar", 5);
        _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵelement"](12, "img", 6);
        _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵpipe"](13, "translate");
        _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵelement"](14, "app-icon", 7);
        _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵpipe"](15, "async");
        _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵelementStart"](16, "ion-col", 8)(17, "span");
        _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵtext"](18);
        _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵpipe"](19, "languageMap");
        _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵelementEnd"]()()()()()();
      }
      if (rf & 2) {
        _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵadvance"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵproperty"]("color", ctx.campaign.campaign.type);
        _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵadvance"](2);
        _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵtextInterpolate1"](" ", _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵpipeBind1"](4, 7, ctx.playerId$) === ctx.challenge.proposerId ? _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵpipeBind2"](5, 9, "challenges.sent", _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵpureFunction1"](21, _c0, ctx.challenge.otherAttendeeData.nickname)) : _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵpipeBind2"](6, 12, "challenges.received", _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵpureFunction1"](23, _c0, ctx.challenge.otherAttendeeData.nickname)), " ");
        _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵadvance"](9);
        _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵproperty"]("title", _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵinterpolate"](_angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵpipeBind1"](13, 15, "registration.avatar.title")))("src", ctx.challenge.otherAttendeeData.avatar.url, _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵsanitizeUrl"]);
        _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵadvance"](2);
        _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵproperty"]("name", _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵpipeBind1"](15, 17, ctx.playerId$) === ctx.challenge.proposerId ? "invite" : "invitation");
        _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵadvance"](4);
        _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵtextInterpolate"](_angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵpipeBind1"](19, 19, ctx.challenge.challDesc));
      }
    },
    dependencies: [_ionic_angular__WEBPACK_IMPORTED_MODULE_5__.IonAvatar, _ionic_angular__WEBPACK_IMPORTED_MODULE_5__.IonCard, _ionic_angular__WEBPACK_IMPORTED_MODULE_5__.IonCardContent, _ionic_angular__WEBPACK_IMPORTED_MODULE_5__.IonCardHeader, _ionic_angular__WEBPACK_IMPORTED_MODULE_5__.IonCol, _ionic_angular__WEBPACK_IMPORTED_MODULE_5__.IonGrid, _ionic_angular__WEBPACK_IMPORTED_MODULE_5__.IonRow, _core_shared_ui_icon_icon_component__WEBPACK_IMPORTED_MODULE_6__.IconComponent, _angular_common__WEBPACK_IMPORTED_MODULE_7__.AsyncPipe, _ngx_translate_core__WEBPACK_IMPORTED_MODULE_8__.TranslatePipe, _core_shared_pipes_languageMap_pipe__WEBPACK_IMPORTED_MODULE_9__.LanguageMapPipe],
    styles: [".header[_ngcontent-%COMP%] {\n  text-align: end;\n  padding: 2px;\n  font-style: italic;\n}\n.header[_ngcontent-%COMP%]   span[_ngcontent-%COMP%] {\n  margin: 4px;\n}\n\n.content[_ngcontent-%COMP%] {\n  padding: 2px 8px;\n  display: flex;\n  align-items: center;\n}\n.content[_ngcontent-%COMP%]   span[_ngcontent-%COMP%] {\n  font-style: normal;\n  font-weight: 300;\n  font-size: 13px;\n  width: 100%;\n  text-align: center;\n  display: -webkit-box;\n  -webkit-line-clamp: 2;\n  -webkit-box-orient: vertical;\n  overflow: hidden;\n  text-overflow: ellipsis;\n}\n\nion-avatar[_ngcontent-%COMP%] {\n  position: absolute;\n  width: 25px;\n  height: 25px;\n  left: -7px;\n  top: 5px;\n}\n/*# sourceMappingURL=data:application/json;charset=utf-8;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbIndlYnBhY2s6Ly8uL3NyYy9hcHAvcGFnZXMvY2hhbGxlbmdlcy9jb3VwbGUtY2hhbGxlbmdlLXByb3Bvc2VkL2NvdXBsZS1jaGFsbGVuZ2UtcHJvcG9zZWQuY29tcG9uZW50LnNjc3MiXSwibmFtZXMiOltdLCJtYXBwaW5ncyI6IkFBQUE7RUFDRSxlQUFBO0VBQ0EsWUFBQTtFQUNBLGtCQUFBO0FBQ0Y7QUFBRTtFQUNFLFdBQUE7QUFFSjs7QUFDQTtFQUNFLGdCQUFBO0VBQ0EsYUFBQTtFQUNBLG1CQUFBO0FBRUY7QUFERTtFQUNFLGtCQUFBO0VBQ0EsZ0JBQUE7RUFDQSxlQUFBO0VBQ0EsV0FBQTtFQUNBLGtCQUFBO0VBQ0Esb0JBQUE7RUFDQSxxQkFBQTtFQUNBLDRCQUFBO0VBQ0EsZ0JBQUE7RUFDQSx1QkFBQTtBQUdKOztBQUFBO0VBQ0Usa0JBQUE7RUFDQSxXQUFBO0VBQ0EsWUFBQTtFQUNBLFVBQUE7RUFDQSxRQUFBO0FBR0YiLCJzb3VyY2VzQ29udGVudCI6WyIuaGVhZGVyIHtcbiAgdGV4dC1hbGlnbjogZW5kO1xuICBwYWRkaW5nOiAycHg7XG4gIGZvbnQtc3R5bGU6IGl0YWxpYztcbiAgc3BhbiB7XG4gICAgbWFyZ2luOiA0cHg7XG4gIH1cbn1cbi5jb250ZW50IHtcbiAgcGFkZGluZzogMnB4IDhweDtcbiAgZGlzcGxheTogZmxleDtcbiAgYWxpZ24taXRlbXM6IGNlbnRlcjtcbiAgc3BhbiB7XG4gICAgZm9udC1zdHlsZTogbm9ybWFsO1xuICAgIGZvbnQtd2VpZ2h0OiAzMDA7XG4gICAgZm9udC1zaXplOiAxM3B4O1xuICAgIHdpZHRoOiAxMDAlO1xuICAgIHRleHQtYWxpZ246IGNlbnRlcjtcbiAgICBkaXNwbGF5OiAtd2Via2l0LWJveDtcbiAgICAtd2Via2l0LWxpbmUtY2xhbXA6IDI7XG4gICAgLXdlYmtpdC1ib3gtb3JpZW50OiB2ZXJ0aWNhbDtcbiAgICBvdmVyZmxvdzogaGlkZGVuO1xuICAgIHRleHQtb3ZlcmZsb3c6IGVsbGlwc2lzO1xuICB9XG59XG5pb24tYXZhdGFyIHtcbiAgcG9zaXRpb246IGFic29sdXRlO1xuICB3aWR0aDogMjVweDtcbiAgaGVpZ2h0OiAyNXB4O1xuICBsZWZ0OiAtN3B4O1xuICB0b3A6IDVweDtcbn1cbiJdLCJzb3VyY2VSb290IjoiIn0= */"]
  }));
}
_staticBlock();

/***/ }),

/***/ 30166:
/*!***********************************************************************************************!*\
  !*** ./src/app/pages/challenges/create-challenge-button/create-challenge-button.component.ts ***!
  \***********************************************************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   CreateChallengeButtonComponent: () => (/* binding */ CreateChallengeButtonComponent)
/* harmony export */ });
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! @angular/core */ 12481);
/* harmony import */ var _ionic_angular__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @ionic/angular */ 21507);
/* harmony import */ var _core_shared_ui_icon_icon_component__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! ../../../core/shared/ui/icon/icon.component */ 59621);
/* harmony import */ var _ngx_translate_core__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @ngx-translate/core */ 48503);
var _staticBlock;




class CreateChallengeButtonComponent {
  constructor() {}
  ngOnInit() {}
  static #_ = _staticBlock = () => (this.ɵfac = function CreateChallengeButtonComponent_Factory(__ngFactoryType__) {
    return new (__ngFactoryType__ || CreateChallengeButtonComponent)();
  }, this.ɵcmp = /*@__PURE__*/_angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵdefineComponent"]({
    type: CreateChallengeButtonComponent,
    selectors: [["app-create-challenge-button"]],
    inputs: {
      campaign: "campaign"
    },
    standalone: false,
    decls: 14,
    vars: 7,
    consts: [[1, "header", 3, "color"], [1, "content"], [1, "ion-align-items-center"], ["size", "2"], ["name", "groupCompetitivePerformance", 1, "icon-size-medium"], [1, "flex-center"]],
    template: function CreateChallengeButtonComponent_Template(rf, ctx) {
      if (rf & 1) {
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](0, "ion-card")(1, "ion-card-header", 0)(2, "span");
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵtext"](3);
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵpipe"](4, "translate");
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]()();
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](5, "ion-card-content", 1)(6, "ion-grid")(7, "ion-row", 2)(8, "ion-col", 3);
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelement"](9, "app-icon", 4);
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](10, "ion-col", 5)(11, "span");
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵtext"](12);
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵpipe"](13, "translate");
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]()()()()()();
      }
      if (rf & 2) {
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵadvance"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵproperty"]("color", ctx.campaign.campaign.type);
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵadvance"](2);
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵtextInterpolate1"](" ", _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵpipeBind1"](4, 3, "challenges.create.configure"), " ");
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵadvance"](9);
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵtextInterpolate"](_angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵpipeBind1"](13, 5, "challenges.create.button_create"));
      }
    },
    dependencies: [_ionic_angular__WEBPACK_IMPORTED_MODULE_1__.IonCard, _ionic_angular__WEBPACK_IMPORTED_MODULE_1__.IonCardContent, _ionic_angular__WEBPACK_IMPORTED_MODULE_1__.IonCardHeader, _ionic_angular__WEBPACK_IMPORTED_MODULE_1__.IonCol, _ionic_angular__WEBPACK_IMPORTED_MODULE_1__.IonGrid, _ionic_angular__WEBPACK_IMPORTED_MODULE_1__.IonRow, _core_shared_ui_icon_icon_component__WEBPACK_IMPORTED_MODULE_2__.IconComponent, _ngx_translate_core__WEBPACK_IMPORTED_MODULE_3__.TranslatePipe],
    styles: [".header[_ngcontent-%COMP%] {\n  text-align: end;\n  padding: 2px;\n  font-style: italic;\n}\n\n.content[_ngcontent-%COMP%] {\n  padding: 2px 8px;\n  display: flex;\n  align-items: center;\n}\n.content[_ngcontent-%COMP%]   span[_ngcontent-%COMP%] {\n  font-style: normal;\n  font-weight: 300;\n  font-size: 13px;\n}\n/*# sourceMappingURL=data:application/json;charset=utf-8;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbIndlYnBhY2s6Ly8uL3NyYy9hcHAvcGFnZXMvY2hhbGxlbmdlcy9jcmVhdGUtY2hhbGxlbmdlLWJ1dHRvbi9jcmVhdGUtY2hhbGxlbmdlLWJ1dHRvbi5jb21wb25lbnQuc2NzcyJdLCJuYW1lcyI6W10sIm1hcHBpbmdzIjoiQUFBQTtFQUNFLGVBQUE7RUFDQSxZQUFBO0VBQ0Esa0JBQUE7QUFDRjs7QUFDQTtFQUNFLGdCQUFBO0VBQ0EsYUFBQTtFQUNBLG1CQUFBO0FBRUY7QUFERTtFQUNFLGtCQUFBO0VBQ0EsZ0JBQUE7RUFDQSxlQUFBO0FBR0oiLCJzb3VyY2VzQ29udGVudCI6WyIuaGVhZGVyIHtcbiAgdGV4dC1hbGlnbjogZW5kO1xuICBwYWRkaW5nOiAycHg7XG4gIGZvbnQtc3R5bGU6IGl0YWxpYztcbn1cbi5jb250ZW50IHtcbiAgcGFkZGluZzogMnB4IDhweDtcbiAgZGlzcGxheTogZmxleDtcbiAgYWxpZ24taXRlbXM6IGNlbnRlcjtcbiAgc3BhbiB7XG4gICAgZm9udC1zdHlsZTogbm9ybWFsO1xuICAgIGZvbnQtd2VpZ2h0OiAzMDA7XG4gICAgZm9udC1zaXplOiAxM3B4O1xuICB9XG59XG4iXSwic291cmNlUm9vdCI6IiJ9 */"]
  }));
}
_staticBlock();

/***/ }),

/***/ 38686:
/*!*******************************************************************************!*\
  !*** ./src/app/pages/challenges/challenges-stat/challenges-stat.component.ts ***!
  \*******************************************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   ChallengesStatComponent: () => (/* binding */ ChallengesStatComponent)
/* harmony export */ });
/* harmony import */ var chart_js__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! chart.js */ 36792);
/* harmony import */ var luxon__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! luxon */ 45967);
/* harmony import */ var rxjs__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! rxjs */ 10819);
/* harmony import */ var rxjs__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! rxjs */ 19999);
/* harmony import */ var rxjs__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! rxjs */ 91817);
/* harmony import */ var rxjs__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! rxjs */ 51567);
/* harmony import */ var rxjs__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! rxjs */ 70271);
/* harmony import */ var rxjs__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(/*! rxjs */ 86301);
/* harmony import */ var rxjs__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(/*! rxjs */ 63037);
/* harmony import */ var rxjs__WEBPACK_IMPORTED_MODULE_9__ = __webpack_require__(/*! rxjs */ 36647);
/* harmony import */ var lodash_es__WEBPACK_IMPORTED_MODULE_10__ = __webpack_require__(/*! lodash-es */ 92434);
/* harmony import */ var src_app_core_shared_time_utils__WEBPACK_IMPORTED_MODULE_11__ = __webpack_require__(/*! src/app/core/shared/time.utils */ 27780);
/* harmony import */ var src_app_core_shared_campaigns_campaign_utils__WEBPACK_IMPORTED_MODULE_12__ = __webpack_require__(/*! src/app/core/shared/campaigns/campaign.utils */ 14691);
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_13__ = __webpack_require__(/*! @angular/core */ 34205);
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_14__ = __webpack_require__(/*! @angular/core */ 12481);
/* harmony import */ var src_app_core_shared_services_challenge_service__WEBPACK_IMPORTED_MODULE_15__ = __webpack_require__(/*! src/app/core/shared/services/challenge.service */ 16561);
/* harmony import */ var src_app_core_shared_services_user_service__WEBPACK_IMPORTED_MODULE_16__ = __webpack_require__(/*! src/app/core/shared/services/user.service */ 89815);
/* harmony import */ var src_app_core_shared_services_error_service__WEBPACK_IMPORTED_MODULE_17__ = __webpack_require__(/*! src/app/core/shared/services/error.service */ 46078);
/* harmony import */ var _angular_common__WEBPACK_IMPORTED_MODULE_18__ = __webpack_require__(/*! @angular/common */ 93683);
/* harmony import */ var _angular_forms__WEBPACK_IMPORTED_MODULE_19__ = __webpack_require__(/*! @angular/forms */ 34456);
/* harmony import */ var _ionic_angular__WEBPACK_IMPORTED_MODULE_20__ = __webpack_require__(/*! @ionic/angular */ 21507);
/* harmony import */ var _challenge_single_stat_challenge_single_stat_component__WEBPACK_IMPORTED_MODULE_21__ = __webpack_require__(/*! ./challenge-single-stat/challenge-single-stat.component */ 12558);
/* harmony import */ var _ngx_translate_core__WEBPACK_IMPORTED_MODULE_22__ = __webpack_require__(/*! @ngx-translate/core */ 48503);
/* harmony import */ var _core_shared_pipes_languageMap_pipe__WEBPACK_IMPORTED_MODULE_23__ = __webpack_require__(/*! ../../../core/shared/pipes/languageMap.pipe */ 69618);
var _staticBlock;
















const _c0 = ["barCanvas"];
const _c1 = a0 => ({
  borderBottomColor: a0
});
const _c2 = a0 => ({
  totalChallenges: a0
});
const _c3 = a0 => ({
  totalWon: a0
});
const _c4 = () => ({
  cssClass: "app-alert"
});
function ChallengesStatComponent_ion_select_6_ion_select_option_2_Template(rf, ctx) {
  if (rf & 1) {
    _angular_core__WEBPACK_IMPORTED_MODULE_14__["ɵɵelementStart"](0, "ion-select-option", 19);
    _angular_core__WEBPACK_IMPORTED_MODULE_14__["ɵɵtext"](1);
    _angular_core__WEBPACK_IMPORTED_MODULE_14__["ɵɵpipe"](2, "languageMap");
    _angular_core__WEBPACK_IMPORTED_MODULE_14__["ɵɵelementEnd"]();
  }
  if (rf & 2) {
    const campaign_r4 = ctx.$implicit;
    _angular_core__WEBPACK_IMPORTED_MODULE_14__["ɵɵproperty"]("value", campaign_r4);
    _angular_core__WEBPACK_IMPORTED_MODULE_14__["ɵɵadvance"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_14__["ɵɵtextInterpolate1"](" ", _angular_core__WEBPACK_IMPORTED_MODULE_14__["ɵɵpipeBind1"](2, 2, campaign_r4.campaign.name), " ");
  }
}
function ChallengesStatComponent_ion_select_6_Template(rf, ctx) {
  if (rf & 1) {
    const _r2 = _angular_core__WEBPACK_IMPORTED_MODULE_14__["ɵɵgetCurrentView"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_14__["ɵɵelementStart"](0, "ion-select", 17);
    _angular_core__WEBPACK_IMPORTED_MODULE_14__["ɵɵpipe"](1, "async");
    _angular_core__WEBPACK_IMPORTED_MODULE_14__["ɵɵlistener"]("ionChange", function ChallengesStatComponent_ion_select_6_Template_ion_select_ionChange_0_listener($event) {
      _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵrestoreView"](_r2);
      const ctx_r2 = _angular_core__WEBPACK_IMPORTED_MODULE_14__["ɵɵnextContext"]();
      return _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵresetView"](ctx_r2.campaignChangedSubject.next($event));
    });
    _angular_core__WEBPACK_IMPORTED_MODULE_14__["ɵɵtemplate"](2, ChallengesStatComponent_ion_select_6_ion_select_option_2_Template, 3, 4, "ion-select-option", 18);
    _angular_core__WEBPACK_IMPORTED_MODULE_14__["ɵɵelementEnd"]();
  }
  if (rf & 2) {
    const ctx_r2 = _angular_core__WEBPACK_IMPORTED_MODULE_14__["ɵɵnextContext"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_14__["ɵɵproperty"]("interfaceOptions", _angular_core__WEBPACK_IMPORTED_MODULE_14__["ɵɵpureFunction0"](5, _c4))("value", _angular_core__WEBPACK_IMPORTED_MODULE_14__["ɵɵpipeBind1"](1, 3, ctx_r2.selectedCampaign$));
    _angular_core__WEBPACK_IMPORTED_MODULE_14__["ɵɵadvance"](2);
    _angular_core__WEBPACK_IMPORTED_MODULE_14__["ɵɵproperty"]("ngForOf", ctx_r2.campaigns);
  }
}
function ChallengesStatComponent_ng_template_7_Template(rf, ctx) {
  if (rf & 1) {
    _angular_core__WEBPACK_IMPORTED_MODULE_14__["ɵɵelementStart"](0, "ion-label");
    _angular_core__WEBPACK_IMPORTED_MODULE_14__["ɵɵtext"](1);
    _angular_core__WEBPACK_IMPORTED_MODULE_14__["ɵɵpipe"](2, "translate");
    _angular_core__WEBPACK_IMPORTED_MODULE_14__["ɵɵelementEnd"]();
  }
  if (rf & 2) {
    _angular_core__WEBPACK_IMPORTED_MODULE_14__["ɵɵadvance"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_14__["ɵɵtextInterpolate1"](" ", _angular_core__WEBPACK_IMPORTED_MODULE_14__["ɵɵpipeBind1"](2, 1, "challenges.stats.filter.no_campaigns"));
  }
}
function ChallengesStatComponent_ion_segment_button_10_Template(rf, ctx) {
  if (rf & 1) {
    _angular_core__WEBPACK_IMPORTED_MODULE_14__["ɵɵelementStart"](0, "ion-segment-button", 20)(1, "ion-label");
    _angular_core__WEBPACK_IMPORTED_MODULE_14__["ɵɵtext"](2);
    _angular_core__WEBPACK_IMPORTED_MODULE_14__["ɵɵpipe"](3, "translate");
    _angular_core__WEBPACK_IMPORTED_MODULE_14__["ɵɵelementEnd"]()();
  }
  if (rf & 2) {
    const period_r5 = ctx.$implicit;
    _angular_core__WEBPACK_IMPORTED_MODULE_14__["ɵɵstyleProp"]("--color", "white")("--color-checked", "black");
    _angular_core__WEBPACK_IMPORTED_MODULE_14__["ɵɵproperty"]("value", period_r5);
    _angular_core__WEBPACK_IMPORTED_MODULE_14__["ɵɵadvance"](2);
    _angular_core__WEBPACK_IMPORTED_MODULE_14__["ɵɵtextInterpolate"](_angular_core__WEBPACK_IMPORTED_MODULE_14__["ɵɵpipeBind1"](3, 6, period_r5.labelKey));
  }
}
function ChallengesStatComponent_div_27_ion_col_3_Template(rf, ctx) {
  if (rf & 1) {
    _angular_core__WEBPACK_IMPORTED_MODULE_14__["ɵɵelementStart"](0, "ion-col");
    _angular_core__WEBPACK_IMPORTED_MODULE_14__["ɵɵelement"](1, "app-challenge-single-stat", 22);
    _angular_core__WEBPACK_IMPORTED_MODULE_14__["ɵɵpipe"](2, "async");
    _angular_core__WEBPACK_IMPORTED_MODULE_14__["ɵɵelementEnd"]();
  }
  if (rf & 2) {
    let tmp_6_0;
    const stat_r6 = ctx.$implicit;
    const ctx_r2 = _angular_core__WEBPACK_IMPORTED_MODULE_14__["ɵɵnextContext"](2);
    _angular_core__WEBPACK_IMPORTED_MODULE_14__["ɵɵadvance"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_14__["ɵɵproperty"]("stat", stat_r6)("kind", (tmp_6_0 = _angular_core__WEBPACK_IMPORTED_MODULE_14__["ɵɵpipeBind1"](2, 2, ctx_r2.selectedCampaign$)) == null ? null : tmp_6_0.campaign == null ? null : tmp_6_0.campaign.type);
  }
}
function ChallengesStatComponent_div_27_Template(rf, ctx) {
  if (rf & 1) {
    _angular_core__WEBPACK_IMPORTED_MODULE_14__["ɵɵelementStart"](0, "div")(1, "ion-grid")(2, "ion-row");
    _angular_core__WEBPACK_IMPORTED_MODULE_14__["ɵɵtemplate"](3, ChallengesStatComponent_div_27_ion_col_3_Template, 3, 4, "ion-col", 21);
    _angular_core__WEBPACK_IMPORTED_MODULE_14__["ɵɵelementEnd"]()()();
  }
  if (rf & 2) {
    const ctx_r2 = _angular_core__WEBPACK_IMPORTED_MODULE_14__["ɵɵnextContext"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_14__["ɵɵadvance"](3);
    _angular_core__WEBPACK_IMPORTED_MODULE_14__["ɵɵproperty"]("ngForOf", ctx_r2.stats);
  }
}
function ChallengesStatComponent_ng_template_28_Template(rf, ctx) {
  if (rf & 1) {
    _angular_core__WEBPACK_IMPORTED_MODULE_14__["ɵɵelement"](0, "canvas", 23, 2);
  }
}
class ChallengesStatComponent {
  constructor(challengeService, userService, errorService) {
    this.challengeService = challengeService;
    this.userService = userService;
    this.errorService = errorService;
    this.campaignChangedSubject = new rxjs__WEBPACK_IMPORTED_MODULE_2__.Subject();
    this.statPeriodChangedSubject = new rxjs__WEBPACK_IMPORTED_MODULE_2__.Subject();
    this.campaigns$ = this.challengeService.campaignsWithChallenges$;
    this.referenceDate = luxon__WEBPACK_IMPORTED_MODULE_1__.DateTime.local().minus({
      weeks: 1
    });
    this.periods = (0,src_app_core_shared_campaigns_campaign_utils__WEBPACK_IMPORTED_MODULE_12__.getPeriods)(this.referenceDate);
    this.totalChallenges = 0;
    this.totalWon = 0;
    this.selectedPeriod = this.periods[0];
    this.playerId$ = this.userService.userProfile$.pipe((0,rxjs__WEBPACK_IMPORTED_MODULE_6__.map)(userProfile => userProfile.playerId), (0,rxjs__WEBPACK_IMPORTED_MODULE_7__.shareReplay)(1));
    this.selectedCampaign$ = this.campaignChangedSubject.pipe((0,rxjs__WEBPACK_IMPORTED_MODULE_6__.map)(event => event.detail.value), (0,rxjs__WEBPACK_IMPORTED_MODULE_7__.shareReplay)(1));
    this.selectedPeriod$ = this.statPeriodChangedSubject.pipe((0,rxjs__WEBPACK_IMPORTED_MODULE_6__.map)(period => {
      this.selectedPeriod = period;
      return this.getPeriodByReference(period);
    }), (0,rxjs__WEBPACK_IMPORTED_MODULE_8__.startWith)(this.periods[0]), (0,rxjs__WEBPACK_IMPORTED_MODULE_7__.shareReplay)(1));
    this.filterOptions$ = (0,rxjs__WEBPACK_IMPORTED_MODULE_3__.combineLatest)([this.selectedCampaign$, this.selectedPeriod$, this.playerId$.pipe((0,rxjs__WEBPACK_IMPORTED_MODULE_4__.distinctUntilChanged)(lodash_es__WEBPACK_IMPORTED_MODULE_10__["default"]))]).pipe((0,rxjs__WEBPACK_IMPORTED_MODULE_6__.map)(([campaign, period, playerId]) => ({
      campaign,
      period,
      playerId
    })));
    this.statResponse$ = this.filterOptions$.pipe((0,rxjs__WEBPACK_IMPORTED_MODULE_5__.filter)(obj => obj.campaign != null), (0,rxjs__WEBPACK_IMPORTED_MODULE_9__.switchMap)(({
      campaign,
      period,
      playerId
    }) => this.challengeService.getChallengeStats({
      campaignId: campaign?.campaign?.campaignId,
      playerId,
      groupMode: period.group,
      dateFrom: (0,src_app_core_shared_time_utils__WEBPACK_IMPORTED_MODULE_11__.toServerDateOnly)(period.from),
      dateTo: (0,src_app_core_shared_time_utils__WEBPACK_IMPORTED_MODULE_11__.toServerDateOnly)(period.to)
    }).pipe(this.errorService.getErrorHandler())));
    this.statsSubs = this.statResponse$.subscribe(stats => {
      this.stats = this.groupStat(stats);
      this.setChart(stats);
      this.setTotal(stats);
    });
    this.campaignsSubs = this.campaigns$.subscribe(campaigns => {
      this.campaigns = campaigns;
      this.campaignChangedSubject.next({
        detail: {
          value: campaigns[0]
        }
      });
    });
  }
  groupStat(stats) {
    const holder = {};
    stats.forEach(d => {
      //check even the type if is not group or survey put everything in the same
      if (d?.type !== 'groupCooperative' && d?.type !== 'groupCompetitiveTime' && d?.type !== 'groupCompetitivePerformance' && d?.type !== 'survey') {
        d.type = 'single';
      }
      if (holder.hasOwnProperty(d.type)) {
        holder[d.type].completed = holder[d.type].completed + d.completed;
        holder[d.type].failed = holder[d.type].failed + d.failed;
      } else {
        holder[d.type] = {};
        holder[d.type].completed = d.completed;
        holder[d.type].failed = d.failed;
      }
    });
    const obj2 = [];
    // eslint-disable-next-line guard-for-in
    for (const prop in holder) {
      obj2.push({
        type: prop,
        completed: holder[prop].completed,
        failed: holder[prop].failed
      });
    }
    return obj2;
    //   //group stat if not know type
    //   let returnStats: ChallengeStatsInfo[] = [];
    //   stats.forEach(stat => {
    //     if (stat.type !== 'groupCooperative' &&
    //       stat?.type !== 'groupCompetitiveTime' &&
    //       stat?.type !== 'groupCompetitivePerformance' && stat?.type!== 'survey') {
    //         returnStats
    //       }
    // })
    // }
    //   return returnStats;
  }
  setTotal(stats) {
    this.totalChallenges = stats.map(stat => stat?.completed + stat?.failed).reduce((prev, next) => prev + next, 0);
    this.totalWon = stats.map(stat => stat?.completed > 0 ? stat.completed : 0).reduce((prev, next) => prev + next, 0);
  }
  ngOnDestroy() {
    this.statsSubs.unsubscribe();
    this.campaignsSubs.unsubscribe();
  }
  ngOnInit() {
    this.selectedSegment = this.periods[0];
  }
  segmentChanged(ev) {
    // console.log('Segment changed, change the selected period', ev);
  }
  backPeriod() {
    //change referenceDate
    this.referenceDate = this.referenceDate.plus({
      [this.selectedPeriod.add]: -1
    });
    //only get but it doesn't write on subject
    this.periods = (0,src_app_core_shared_campaigns_campaign_utils__WEBPACK_IMPORTED_MODULE_12__.getPeriods)(this.referenceDate);
    const tabIndex = this.periods.findIndex(period => period.group === this.selectedPeriod.group);
    this.selectedSegment = this.periods[tabIndex];
    this.statPeriodChangedSubject.next(this.periods[tabIndex]);
  }
  forwardPeriod() {
    this.referenceDate = this.referenceDate.plus({
      [this.selectedPeriod.add]: 1
    });
    this.periods = (0,src_app_core_shared_campaigns_campaign_utils__WEBPACK_IMPORTED_MODULE_12__.getPeriods)(this.referenceDate);
    const tabIndex = this.periods.findIndex(period => period.group === this.selectedPeriod.group);
    this.selectedSegment = this.periods[tabIndex];
    this.statPeriodChangedSubject.next(this.periods[tabIndex]);
  }
  getSelectedPeriod() {
    return this.selectedPeriod.from.toFormat(this.selectedPeriod.label);
  }
  getPeriodByReference(value) {
    return this.periods.find(period => period.group === value.group);
  }
  isWeekSelected() {
    return this.selectedPeriod.add === 'week';
  }
  setChart(stats) {
    // Now we need to supply a Chart element reference with an
    //object that defines the type of chart we want to use, and the type of data we want to display.
    // console.log('setChart based on selected tab', this.selectedPeriod);
    chart_js__WEBPACK_IMPORTED_MODULE_0__.Chart.register(chart_js__WEBPACK_IMPORTED_MODULE_0__.LineController, chart_js__WEBPACK_IMPORTED_MODULE_0__.BarController, chart_js__WEBPACK_IMPORTED_MODULE_0__.CategoryScale, chart_js__WEBPACK_IMPORTED_MODULE_0__.LinearScale, chart_js__WEBPACK_IMPORTED_MODULE_0__.BarElement, chart_js__WEBPACK_IMPORTED_MODULE_0__.DoughnutController, chart_js__WEBPACK_IMPORTED_MODULE_0__.ArcElement, chart_js__WEBPACK_IMPORTED_MODULE_0__.PointElement, chart_js__WEBPACK_IMPORTED_MODULE_0__.LineElement);
    if (!this.barCanvas) {
      return;
    } else {
      const chartExist = chart_js__WEBPACK_IMPORTED_MODULE_0__.Chart.getChart('statsChart');
      if (chartExist !== undefined) {
        chartExist.destroy();
      }
    }
    //build using stats and this.selectedPeriod
    const arrOfPeriod = this.daysFromInterval();
    const arrOfValuesCompleted = this.valuesFromStat(arrOfPeriod, stats, 'completed');
    const arrOfValuesFailed = this.valuesFromStat(arrOfPeriod, stats, 'failed');
    // if (stats && stats.length) {
    this.barChart = new chart_js__WEBPACK_IMPORTED_MODULE_0__.Chart(this.barCanvas.nativeElement, {
      type: 'bar',
      options: {
        onClick: e => {
          const points = this.barChart.getElementsAtEventForMode(e, 'nearest', {
            intersect: true
          }, true);
          if (points.length) {
            const firstPoint = points[0];
            const label = this.barChart.data.labels[firstPoint.index];
            this.changeView(label);
          }
        },
        scales: {
          x: {
            stacked: true
          },
          y: {
            stacked: true,
            ticks: {
              stepSize: 1
            }
          }
        }
      },
      data: {
        labels: arrOfPeriod.map(period => period.toFormat(this.selectedPeriod.format)),
        datasets: [{
          data: arrOfValuesCompleted,
          backgroundColor: '#359675',
          borderRadius: 5
        }, {
          data: arrOfValuesFailed,
          backgroundColor: '#C61010',
          borderRadius: 5
        }]
      }
    });
    // }
  }
  valuesFromStat(arrOfPeriod, stats, type) {
    //  check if stats[i] is part of arrOfPeriod
    // const statsArrayDate = stats.map((stat) => {
    //   console.log(stat);
    //   return DateTime.fromObject(this.getObjectDate(stat.period));
    // });
    // console.log(statsArrayDate);
    const retArr = [];
    for (const period of arrOfPeriod) {
      //check if statsArrayDate has a period
      // const i = statsArrayDate.findIndex(
      //   (statPeriod) => statPeriod.toISO() === period.toISO()
      // );
      //get array filtered by period
      const arrayFiltered = stats.filter(stat => luxon__WEBPACK_IMPORTED_MODULE_1__.DateTime.fromObject(this.getObjectDate(stat.period)).toISO() === period.toISO());
      if (arrayFiltered.length > 0) {
        retArr.push(arrayFiltered.reduce((prev, next) => prev + next[type], 0));
      } else {
        retArr.push(0);
      }
    }
    return retArr;
  }
  getObjectDate(statPeriod) {
    //anno - mese o anno numero settimana o anno mese giorno in base alla selezione
    const periodSplitted = statPeriod.split('-');
    switch (this.selectedPeriod.group) {
      case 'day':
        return {
          year: Number(periodSplitted[0]),
          month: Number(periodSplitted[1]),
          day: Number(periodSplitted[2])
        };
      case 'week':
        return {
          weekYear: Number(periodSplitted[0]),
          weekNumber: Number(periodSplitted[1])
        };
      case 'month':
        return {
          year: Number(periodSplitted[0]),
          month: Number(periodSplitted[1])
        };
    }
  }
  daysFromInterval() {
    const retArr = [];
    const start = this.selectedPeriod.from;
    const end = this.selectedPeriod.to;
    const interval = luxon__WEBPACK_IMPORTED_MODULE_1__.Interval.fromDateTimes(start, end);
    let cursor = interval.start;
    cursor = cursor.startOf(this.selectedPeriod.group);
    while (cursor < interval.end) {
      //begin of the element
      retArr.push(cursor);
      cursor = cursor.plus({
        [this.selectedPeriod.group]: 1
      });
    }
    return retArr;
  }
  changeView(label) {
    // segmentChanged($event); statPeriodChangedSubject.next(selectedSegment)
    const switchToPeriod = null;
    switch (this.selectedSegment.group) {
      case 'month':
        label = luxon__WEBPACK_IMPORTED_MODULE_1__.DateTime.fromFormat(label, 'MM-yyyy').toFormat('yyyy-MM-dd');
        break;
      case 'week':
        label = luxon__WEBPACK_IMPORTED_MODULE_1__.DateTime.fromFormat(label, 'dd-MM-yyyy').toFormat('yyyy-WW');
        break;
      case 'day':
        // label = DateTime.fromFormat(label, 'dd-MM').toFormat('yyyy-MM-dd');
        return;
      default:
        break;
    }
    // change reference date
    //only get but it doesn't write on subject
    this.referenceDate = luxon__WEBPACK_IMPORTED_MODULE_1__.DateTime.fromObject(this.getObjectDate(label));
    this.periods = (0,src_app_core_shared_campaigns_campaign_utils__WEBPACK_IMPORTED_MODULE_12__.getPeriods)(this.referenceDate);
    this.selectedSegment = this.periods.find(a => a.group === this.selectedSegment.switchTo);
    this.statPeriodChangedSubject.next(this.selectedSegment);
  }
  static #_ = _staticBlock = () => (this.ɵfac = function ChallengesStatComponent_Factory(__ngFactoryType__) {
    return new (__ngFactoryType__ || ChallengesStatComponent)(_angular_core__WEBPACK_IMPORTED_MODULE_14__["ɵɵdirectiveInject"](src_app_core_shared_services_challenge_service__WEBPACK_IMPORTED_MODULE_15__.ChallengeService), _angular_core__WEBPACK_IMPORTED_MODULE_14__["ɵɵdirectiveInject"](src_app_core_shared_services_user_service__WEBPACK_IMPORTED_MODULE_16__.UserService), _angular_core__WEBPACK_IMPORTED_MODULE_14__["ɵɵdirectiveInject"](src_app_core_shared_services_error_service__WEBPACK_IMPORTED_MODULE_17__.ErrorService));
  }, this.ɵcmp = /*@__PURE__*/_angular_core__WEBPACK_IMPORTED_MODULE_14__["ɵɵdefineComponent"]({
    type: ChallengesStatComponent,
    selectors: [["app-challenges-stat"]],
    viewQuery: function ChallengesStatComponent_Query(rf, ctx) {
      if (rf & 1) {
        _angular_core__WEBPACK_IMPORTED_MODULE_14__["ɵɵviewQuery"](_c0, 5);
      }
      if (rf & 2) {
        let _t;
        _angular_core__WEBPACK_IMPORTED_MODULE_14__["ɵɵqueryRefresh"](_t = _angular_core__WEBPACK_IMPORTED_MODULE_14__["ɵɵloadQuery"]()) && (ctx.barCanvas = _t.first);
      }
    },
    standalone: false,
    decls: 34,
    vars: 36,
    consts: [["noCampaigns", ""], ["barChart", ""], ["barCanvas", ""], [1, "header-margin"], ["color", "playgo", 1, "header-radius", 3, "ngStyle"], [3, "interfaceOptions", "value", "ionChange", 4, "ngIf", "ngIfElse"], ["mode", "md", "scrollable", "", 1, "app-segment", 3, "ngModelChange", "ionChange", "ngModel"], ["checked", "", "mode", "ios", "class", "app-segment-button", 3, "value", "--color", "--color-checked", 4, "ngFor", "ngForOf"], [1, "table-header"], ["size", "2"], ["color", "light", "fill", "clear", 3, "click"], ["name", "chevron-back"], ["size", "8"], [1, "ion-text-center"], ["name", "chevron-forward"], [4, "ngIf", "ngIfElse"], [1, "empty-stats"], [3, "ionChange", "interfaceOptions", "value"], [3, "value", 4, "ngFor", "ngForOf"], [3, "value"], ["checked", "", "mode", "ios", 1, "app-segment-button", 3, "value"], [4, "ngFor", "ngForOf"], [3, "stat", "kind"], ["id", "statsChart", 2, "position", "relative", "height", "20vh", "width", "40vw"]],
    template: function ChallengesStatComponent_Template(rf, ctx) {
      if (rf & 1) {
        const _r1 = _angular_core__WEBPACK_IMPORTED_MODULE_14__["ɵɵgetCurrentView"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_14__["ɵɵelementStart"](0, "div", 3)(1, "ion-item", 4);
        _angular_core__WEBPACK_IMPORTED_MODULE_14__["ɵɵpipe"](2, "async");
        _angular_core__WEBPACK_IMPORTED_MODULE_14__["ɵɵelementStart"](3, "ion-label");
        _angular_core__WEBPACK_IMPORTED_MODULE_14__["ɵɵtext"](4);
        _angular_core__WEBPACK_IMPORTED_MODULE_14__["ɵɵpipe"](5, "translate");
        _angular_core__WEBPACK_IMPORTED_MODULE_14__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_14__["ɵɵtemplate"](6, ChallengesStatComponent_ion_select_6_Template, 3, 6, "ion-select", 5)(7, ChallengesStatComponent_ng_template_7_Template, 3, 3, "ng-template", null, 0, _angular_core__WEBPACK_IMPORTED_MODULE_14__["ɵɵtemplateRefExtractor"]);
        _angular_core__WEBPACK_IMPORTED_MODULE_14__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_14__["ɵɵelementStart"](9, "ion-segment", 6);
        _angular_core__WEBPACK_IMPORTED_MODULE_14__["ɵɵtwoWayListener"]("ngModelChange", function ChallengesStatComponent_Template_ion_segment_ngModelChange_9_listener($event) {
          _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵrestoreView"](_r1);
          _angular_core__WEBPACK_IMPORTED_MODULE_14__["ɵɵtwoWayBindingSet"](ctx.selectedSegment, $event) || (ctx.selectedSegment = $event);
          return _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵresetView"]($event);
        });
        _angular_core__WEBPACK_IMPORTED_MODULE_14__["ɵɵlistener"]("ionChange", function ChallengesStatComponent_Template_ion_segment_ionChange_9_listener($event) {
          _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵrestoreView"](_r1);
          ctx.segmentChanged($event);
          return _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵresetView"](ctx.statPeriodChangedSubject.next(ctx.selectedSegment));
        });
        _angular_core__WEBPACK_IMPORTED_MODULE_14__["ɵɵtemplate"](10, ChallengesStatComponent_ion_segment_button_10_Template, 4, 8, "ion-segment-button", 7);
        _angular_core__WEBPACK_IMPORTED_MODULE_14__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_14__["ɵɵelementStart"](11, "ion-grid", 8)(12, "ion-row")(13, "ion-col", 9)(14, "ion-button", 10);
        _angular_core__WEBPACK_IMPORTED_MODULE_14__["ɵɵlistener"]("click", function ChallengesStatComponent_Template_ion_button_click_14_listener() {
          _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵrestoreView"](_r1);
          return _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵresetView"](ctx.backPeriod());
        });
        _angular_core__WEBPACK_IMPORTED_MODULE_14__["ɵɵelement"](15, "ion-icon", 11);
        _angular_core__WEBPACK_IMPORTED_MODULE_14__["ɵɵelementEnd"]()();
        _angular_core__WEBPACK_IMPORTED_MODULE_14__["ɵɵelementStart"](16, "ion-col", 12)(17, "p", 13);
        _angular_core__WEBPACK_IMPORTED_MODULE_14__["ɵɵtext"](18);
        _angular_core__WEBPACK_IMPORTED_MODULE_14__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_14__["ɵɵelementStart"](19, "p", 13);
        _angular_core__WEBPACK_IMPORTED_MODULE_14__["ɵɵtext"](20);
        _angular_core__WEBPACK_IMPORTED_MODULE_14__["ɵɵpipe"](21, "translate");
        _angular_core__WEBPACK_IMPORTED_MODULE_14__["ɵɵpipe"](22, "translate");
        _angular_core__WEBPACK_IMPORTED_MODULE_14__["ɵɵelementEnd"]()();
        _angular_core__WEBPACK_IMPORTED_MODULE_14__["ɵɵelementStart"](23, "ion-col", 9)(24, "ion-button", 10);
        _angular_core__WEBPACK_IMPORTED_MODULE_14__["ɵɵlistener"]("click", function ChallengesStatComponent_Template_ion_button_click_24_listener() {
          _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵrestoreView"](_r1);
          return _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵresetView"](ctx.forwardPeriod());
        });
        _angular_core__WEBPACK_IMPORTED_MODULE_14__["ɵɵelement"](25, "ion-icon", 14);
        _angular_core__WEBPACK_IMPORTED_MODULE_14__["ɵɵelementEnd"]()()()();
        _angular_core__WEBPACK_IMPORTED_MODULE_14__["ɵɵelementStart"](26, "div");
        _angular_core__WEBPACK_IMPORTED_MODULE_14__["ɵɵtemplate"](27, ChallengesStatComponent_div_27_Template, 4, 1, "div", 15)(28, ChallengesStatComponent_ng_template_28_Template, 2, 0, "ng-template", null, 1, _angular_core__WEBPACK_IMPORTED_MODULE_14__["ɵɵtemplateRefExtractor"]);
        _angular_core__WEBPACK_IMPORTED_MODULE_14__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_14__["ɵɵelementStart"](30, "div")(31, "div", 16);
        _angular_core__WEBPACK_IMPORTED_MODULE_14__["ɵɵtext"](32);
        _angular_core__WEBPACK_IMPORTED_MODULE_14__["ɵɵpipe"](33, "translate");
        _angular_core__WEBPACK_IMPORTED_MODULE_14__["ɵɵelementEnd"]()()();
      }
      if (rf & 2) {
        let tmp_2_0;
        const noCampaigns_r7 = _angular_core__WEBPACK_IMPORTED_MODULE_14__["ɵɵreference"](8);
        const barChart_r8 = _angular_core__WEBPACK_IMPORTED_MODULE_14__["ɵɵreference"](29);
        _angular_core__WEBPACK_IMPORTED_MODULE_14__["ɵɵadvance"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_14__["ɵɵproperty"]("ngStyle", _angular_core__WEBPACK_IMPORTED_MODULE_14__["ɵɵpureFunction1"](30, _c1, " var(--ion-color-" + ((tmp_2_0 = _angular_core__WEBPACK_IMPORTED_MODULE_14__["ɵɵpipeBind1"](2, 18, ctx.selectedCampaign$)) == null ? null : tmp_2_0.campaign == null ? null : tmp_2_0.campaign.type) + ")"));
        _angular_core__WEBPACK_IMPORTED_MODULE_14__["ɵɵadvance"](3);
        _angular_core__WEBPACK_IMPORTED_MODULE_14__["ɵɵtextInterpolate"](_angular_core__WEBPACK_IMPORTED_MODULE_14__["ɵɵpipeBind1"](5, 20, "challenges.stats.filter.campaign"));
        _angular_core__WEBPACK_IMPORTED_MODULE_14__["ɵɵadvance"](2);
        _angular_core__WEBPACK_IMPORTED_MODULE_14__["ɵɵproperty"]("ngIf", ctx.campaigns.length > 0)("ngIfElse", noCampaigns_r7);
        _angular_core__WEBPACK_IMPORTED_MODULE_14__["ɵɵadvance"](3);
        _angular_core__WEBPACK_IMPORTED_MODULE_14__["ɵɵstyleProp"]("--background", "var(--ion-color-playgo)");
        _angular_core__WEBPACK_IMPORTED_MODULE_14__["ɵɵtwoWayProperty"]("ngModel", ctx.selectedSegment);
        _angular_core__WEBPACK_IMPORTED_MODULE_14__["ɵɵadvance"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_14__["ɵɵproperty"]("ngForOf", ctx.periods);
        _angular_core__WEBPACK_IMPORTED_MODULE_14__["ɵɵadvance"](8);
        _angular_core__WEBPACK_IMPORTED_MODULE_14__["ɵɵtextInterpolate"](ctx.getSelectedPeriod());
        _angular_core__WEBPACK_IMPORTED_MODULE_14__["ɵɵadvance"](2);
        _angular_core__WEBPACK_IMPORTED_MODULE_14__["ɵɵtextInterpolate2"](" ", _angular_core__WEBPACK_IMPORTED_MODULE_14__["ɵɵpipeBind2"](21, 22, "challenges.stats.totalChallenges", _angular_core__WEBPACK_IMPORTED_MODULE_14__["ɵɵpureFunction1"](32, _c2, ctx.totalChallenges)), " / ", _angular_core__WEBPACK_IMPORTED_MODULE_14__["ɵɵpipeBind2"](22, 25, "challenges.stats.totalWon", _angular_core__WEBPACK_IMPORTED_MODULE_14__["ɵɵpureFunction1"](34, _c3, ctx.totalWon)), " ");
        _angular_core__WEBPACK_IMPORTED_MODULE_14__["ɵɵadvance"](6);
        _angular_core__WEBPACK_IMPORTED_MODULE_14__["ɵɵstyleProp"]("display", ctx.stats && (ctx.stats == null ? null : ctx.stats.length) > 0 ? "block" : "none");
        _angular_core__WEBPACK_IMPORTED_MODULE_14__["ɵɵadvance"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_14__["ɵɵproperty"]("ngIf", ctx.isWeekSelected())("ngIfElse", barChart_r8);
        _angular_core__WEBPACK_IMPORTED_MODULE_14__["ɵɵadvance"](3);
        _angular_core__WEBPACK_IMPORTED_MODULE_14__["ɵɵstyleProp"]("display", ctx.stats === null || (ctx.stats == null ? null : ctx.stats.length) <= 0 ? "block" : "none");
        _angular_core__WEBPACK_IMPORTED_MODULE_14__["ɵɵadvance"](2);
        _angular_core__WEBPACK_IMPORTED_MODULE_14__["ɵɵtextInterpolate"](_angular_core__WEBPACK_IMPORTED_MODULE_14__["ɵɵpipeBind1"](33, 28, "challenges.stats.empty"));
      }
    },
    dependencies: [_angular_common__WEBPACK_IMPORTED_MODULE_18__.NgForOf, _angular_common__WEBPACK_IMPORTED_MODULE_18__.NgIf, _angular_common__WEBPACK_IMPORTED_MODULE_18__.NgStyle, _angular_forms__WEBPACK_IMPORTED_MODULE_19__.NgControlStatus, _angular_forms__WEBPACK_IMPORTED_MODULE_19__.NgModel, _ionic_angular__WEBPACK_IMPORTED_MODULE_20__.IonButton, _ionic_angular__WEBPACK_IMPORTED_MODULE_20__.IonCol, _ionic_angular__WEBPACK_IMPORTED_MODULE_20__.IonGrid, _ionic_angular__WEBPACK_IMPORTED_MODULE_20__.IonIcon, _ionic_angular__WEBPACK_IMPORTED_MODULE_20__.IonItem, _ionic_angular__WEBPACK_IMPORTED_MODULE_20__.IonLabel, _ionic_angular__WEBPACK_IMPORTED_MODULE_20__.IonRow, _ionic_angular__WEBPACK_IMPORTED_MODULE_20__.IonSegment, _ionic_angular__WEBPACK_IMPORTED_MODULE_20__.IonSegmentButton, _ionic_angular__WEBPACK_IMPORTED_MODULE_20__.IonSelect, _ionic_angular__WEBPACK_IMPORTED_MODULE_20__.IonSelectOption, _ionic_angular__WEBPACK_IMPORTED_MODULE_20__.SelectValueAccessor, _challenge_single_stat_challenge_single_stat_component__WEBPACK_IMPORTED_MODULE_21__.ChalengeSingleStatComponent, _angular_common__WEBPACK_IMPORTED_MODULE_18__.AsyncPipe, _ngx_translate_core__WEBPACK_IMPORTED_MODULE_22__.TranslatePipe, _core_shared_pipes_languageMap_pipe__WEBPACK_IMPORTED_MODULE_23__.LanguageMapPipe],
    styles: [".header-margin[_ngcontent-%COMP%] {\n  margin: 8px;\n}\n.header-margin[_ngcontent-%COMP%]   .header-radius[_ngcontent-%COMP%] {\n  border-radius: 8px 8px 0 0;\n  border-bottom: 5px solid;\n}\n.header-margin[_ngcontent-%COMP%]   .table-header[_ngcontent-%COMP%] {\n  background-color: var(--ion-color-playgo);\n  color: white;\n  font-size: 22px;\n}\n.header-margin[_ngcontent-%COMP%]   .empty-stats[_ngcontent-%COMP%] {\n  margin-top: calc(var(--ion-safe-area-top, 0) + 20px);\n  margin-bottom: calc(var(--ion-safe-area-bottom, 0) + 20px);\n  text-align: center;\n  color: var(--ion-color-medium);\n}\n/*# sourceMappingURL=data:application/json;charset=utf-8;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbIndlYnBhY2s6Ly8uL3NyYy9hcHAvcGFnZXMvY2hhbGxlbmdlcy9jaGFsbGVuZ2VzLXN0YXQvY2hhbGxlbmdlcy1zdGF0LmNvbXBvbmVudC5zY3NzIl0sIm5hbWVzIjpbXSwibWFwcGluZ3MiOiJBQUFBO0VBQ0UsV0FBQTtBQUNGO0FBQ0U7RUFDRSwwQkFBQTtFQUNBLHdCQUFBO0FBQ0o7QUFDRTtFQUNFLHlDQUFBO0VBQ0EsWUFBQTtFQUNBLGVBQUE7QUFDSjtBQUNFO0VBQ0Usb0RBQUE7RUFDQSwwREFBQTtFQUNBLGtCQUFBO0VBQ0EsOEJBQUE7QUFDSiIsInNvdXJjZXNDb250ZW50IjpbIi5oZWFkZXItbWFyZ2luIHtcbiAgbWFyZ2luOiA4cHg7XG5cbiAgLmhlYWRlci1yYWRpdXMge1xuICAgIGJvcmRlci1yYWRpdXM6IDhweCA4cHggMCAwO1xuICAgIGJvcmRlci1ib3R0b206IDVweCBzb2xpZDtcbiAgfVxuICAudGFibGUtaGVhZGVyIHtcbiAgICBiYWNrZ3JvdW5kLWNvbG9yOiB2YXIoLS1pb24tY29sb3ItcGxheWdvKTtcbiAgICBjb2xvcjogd2hpdGU7XG4gICAgZm9udC1zaXplOiAyMnB4O1xuICB9XG4gIC5lbXB0eS1zdGF0cyB7XG4gICAgbWFyZ2luLXRvcDogY2FsYyh2YXIoLS1pb24tc2FmZS1hcmVhLXRvcCwgMCkgKyAyMHB4KTtcbiAgICBtYXJnaW4tYm90dG9tOiBjYWxjKHZhcigtLWlvbi1zYWZlLWFyZWEtYm90dG9tLCAwKSArIDIwcHgpO1xuICAgIHRleHQtYWxpZ246IGNlbnRlcjtcbiAgICBjb2xvcjogdmFyKC0taW9uLWNvbG9yLW1lZGl1bSk7XG4gIH1cbn1cbiJdLCJzb3VyY2VSb290IjoiIn0= */"]
  }));
}
_staticBlock();

/***/ }),

/***/ 41609:
/*!**************************************************************************************************!*\
  !*** ./src/app/pages/challenges/create-challenge/sent-invitation-modal/sent-invitation.modal.ts ***!
  \**************************************************************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   SentInvitationlModalPage: () => (/* binding */ SentInvitationlModalPage)
/* harmony export */ });
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! @angular/core */ 12481);
/* harmony import */ var _ionic_angular__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @ionic/angular */ 21507);
/* harmony import */ var _ngx_translate_core__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @ngx-translate/core */ 48503);
var _staticBlock;



const _c0 = a0 => ({
  nickname: a0
});
class SentInvitationlModalPage {
  constructor(modalController) {
    this.modalController = modalController;
  }
  ngOnInit() {}
  //computed errorcontrol
  close() {
    this.modalController.dismiss(false);
  }
  static #_ = _staticBlock = () => (this.ɵfac = function SentInvitationlModalPage_Factory(__ngFactoryType__) {
    return new (__ngFactoryType__ || SentInvitationlModalPage)(_angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵdirectiveInject"](_ionic_angular__WEBPACK_IMPORTED_MODULE_1__.ModalController));
  }, this.ɵcmp = /*@__PURE__*/_angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵdefineComponent"]({
    type: SentInvitationlModalPage,
    selectors: [["app-sent-invitation"]],
    standalone: false,
    decls: 10,
    vars: 18,
    consts: [["color", "playgo"], [1, "title"], [1, "body"], ["expand", "block", "color", "light", 3, "click"]],
    template: function SentInvitationlModalPage_Template(rf, ctx) {
      if (rf & 1) {
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](0, "ion-content", 0)(1, "p", 1);
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵtext"](2);
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵpipe"](3, "translate");
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](4, "p", 2);
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵtext"](5);
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵpipe"](6, "translate");
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](7, "ion-button", 3);
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵlistener"]("click", function SentInvitationlModalPage_Template_ion_button_click_7_listener() {
          return ctx.close();
        });
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵtext"](8);
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵpipe"](9, "translate");
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]()();
      }
      if (rf & 2) {
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵadvance"](2);
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵtextInterpolate1"](" ", _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵpipeBind2"](3, 3, "challenges.create.sent_title", _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵpureFunction1"](12, _c0, ctx.opponentName)), " ");
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵadvance"](3);
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵtextInterpolate1"](" ", _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵpipeBind2"](6, 6, "challenges.create.sent_body", _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵpureFunction1"](14, _c0, ctx.opponentName)), " ");
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵadvance"](3);
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵtextInterpolate"](_angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵpipeBind2"](9, 9, "challenges.create.close", _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵpureFunction1"](16, _c0, ctx.opponentName)));
      }
    },
    dependencies: [_ionic_angular__WEBPACK_IMPORTED_MODULE_1__.IonButton, _ionic_angular__WEBPACK_IMPORTED_MODULE_1__.IonContent, _ngx_translate_core__WEBPACK_IMPORTED_MODULE_2__.TranslatePipe],
    styles: ["ion-content[_ngcontent-%COMP%]   .title[_ngcontent-%COMP%] {\n  text-align: center;\n  font-weight: bold;\n  padding: 8px;\n}\nion-content[_ngcontent-%COMP%]   .body[_ngcontent-%COMP%] {\n  text-align: justify;\n  padding: 8px;\n}\nion-content[_ngcontent-%COMP%]   ion-button[_ngcontent-%COMP%] {\n  position: absolute;\n  bottom: 0px;\n  left: 50%;\n  width: 60%;\n  margin: 8px;\n  left: 50%;\n  transform: translateX(-50%);\n}\n/*# sourceMappingURL=data:application/json;charset=utf-8;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbIndlYnBhY2s6Ly8uL3NyYy9hcHAvcGFnZXMvY2hhbGxlbmdlcy9jcmVhdGUtY2hhbGxlbmdlL3NlbnQtaW52aXRhdGlvbi1tb2RhbC9zZW50LWludml0YXRpb24ubW9kYWwuc2NzcyJdLCJuYW1lcyI6W10sIm1hcHBpbmdzIjoiQUFDRTtFQUNFLGtCQUFBO0VBQ0EsaUJBQUE7RUFDQSxZQUFBO0FBQUo7QUFFRTtFQUNFLG1CQUFBO0VBQ0EsWUFBQTtBQUFKO0FBRUU7RUFDRSxrQkFBQTtFQUNBLFdBQUE7RUFDQSxTQUFBO0VBQ0EsVUFBQTtFQUNBLFdBQUE7RUFDQSxTQUFBO0VBQ0EsMkJBQUE7QUFBSiIsInNvdXJjZXNDb250ZW50IjpbImlvbi1jb250ZW50IHtcbiAgLnRpdGxlIHtcbiAgICB0ZXh0LWFsaWduOiBjZW50ZXI7XG4gICAgZm9udC13ZWlnaHQ6IGJvbGQ7XG4gICAgcGFkZGluZzogOHB4O1xuICB9XG4gIC5ib2R5IHtcbiAgICB0ZXh0LWFsaWduOiBqdXN0aWZ5O1xuICAgIHBhZGRpbmc6IDhweDtcbiAgfVxuICBpb24tYnV0dG9uIHtcbiAgICBwb3NpdGlvbjogYWJzb2x1dGU7XG4gICAgYm90dG9tOiAwcHg7XG4gICAgbGVmdDogNTAlO1xuICAgIHdpZHRoOiA2MCU7XG4gICAgbWFyZ2luOiA4cHg7XG4gICAgbGVmdDogNTAlO1xuICAgIHRyYW5zZm9ybTogdHJhbnNsYXRlWCgtNTAlKTtcbiAgfVxufVxuIl0sInNvdXJjZVJvb3QiOiIifQ== */"]
  }));
}
_staticBlock();

/***/ }),

/***/ 52782:
/*!***********************************************************************************************************************!*\
  !*** ./src/app/pages/challenges/single-challenge-proposed/single-proposal-accepted/single-proposal-accepted.modal.ts ***!
  \***********************************************************************************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   SingleProposalAcceptedModalPage: () => (/* binding */ SingleProposalAcceptedModalPage)
/* harmony export */ });
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! @angular/core */ 12481);
/* harmony import */ var _ionic_angular__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @ionic/angular */ 21507);
/* harmony import */ var src_app_core_shared_services_campaign_service__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! src/app/core/shared/services/campaign.service */ 76658);
/* harmony import */ var _core_shared_ui_icon_icon_component__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! ../../../../core/shared/ui/icon/icon.component */ 59621);
/* harmony import */ var _ngx_translate_core__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! @ngx-translate/core */ 48503);
/* harmony import */ var _core_shared_pipes_localDate_pipe__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! ../../../../core/shared/pipes/localDate.pipe */ 86451);
var _staticBlock;






const _c0 = (a0, a1) => ({
  from: a0,
  to: a1
});
class SingleProposalAcceptedModalPage {
  constructor(modalController, campaignService) {
    this.modalController = modalController;
    this.campaignService = campaignService;
  }
  ngOnInit() {}
  //computed errorcontrol
  close() {
    this.modalController.dismiss(false);
  }
  static #_ = _staticBlock = () => (this.ɵfac = function SingleProposalAcceptedModalPage_Factory(__ngFactoryType__) {
    return new (__ngFactoryType__ || SingleProposalAcceptedModalPage)(_angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵdirectiveInject"](_ionic_angular__WEBPACK_IMPORTED_MODULE_1__.ModalController), _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵdirectiveInject"](src_app_core_shared_services_campaign_service__WEBPACK_IMPORTED_MODULE_2__.CampaignService));
  }, this.ɵcmp = /*@__PURE__*/_angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵdefineComponent"]({
    type: SingleProposalAcceptedModalPage,
    selectors: [["app-single-proposal-accepted"]],
    standalone: false,
    decls: 26,
    vars: 17,
    consts: [["color", "playgo"], [1, "content"], [1, "ion-text-center"], ["name", "checked", 1, "type-notif", "icon-size-normal"], ["name", "default", 1, "type-notif", "icon-size-big"], ["color", "playgo", "mode", "ios"], ["color", "light", "expand", "block", 3, "click"]],
    template: function SingleProposalAcceptedModalPage_Template(rf, ctx) {
      if (rf & 1) {
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](0, "ion-content", 0)(1, "ion-grid", 1)(2, "ion-row")(3, "ion-col", 2)(4, "div");
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelement"](5, "app-icon", 3);
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]()()();
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](6, "ion-row")(7, "ion-col", 2)(8, "div");
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵtext"](9);
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵpipe"](10, "translate");
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]()()();
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](11, "ion-row")(12, "ion-col", 2)(13, "div");
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelement"](14, "app-icon", 4);
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]()()();
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](15, "ion-row")(16, "ion-col", 2)(17, "div");
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵtext"](18);
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵpipe"](19, "localDate");
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵpipe"](20, "localDate");
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵpipe"](21, "translate");
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]()()()()();
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](22, "ion-footer", 5)(23, "ion-button", 6);
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵlistener"]("click", function SingleProposalAcceptedModalPage_Template_ion_button_click_23_listener() {
          return ctx.close();
        });
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵtext"](24);
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵpipe"](25, "translate");
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]()();
      }
      if (rf & 2) {
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵadvance"](9);
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵtextInterpolate1"](" ", _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵpipeBind1"](10, 3, "challenges.singleActivated"));
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵadvance"](9);
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵtextInterpolate"](_angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵpipeBind2"](21, 9, "challenges.singleDesc", _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵpureFunction2"](14, _c0, _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵpipeBind1"](19, 5, ctx.challenge.startDate), _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵpipeBind1"](20, 7, ctx.challenge.endDate))));
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵadvance"](6);
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵtextInterpolate"](_angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵpipeBind1"](25, 12, "notifications.close"));
      }
    },
    dependencies: [_ionic_angular__WEBPACK_IMPORTED_MODULE_1__.IonButton, _ionic_angular__WEBPACK_IMPORTED_MODULE_1__.IonCol, _ionic_angular__WEBPACK_IMPORTED_MODULE_1__.IonContent, _ionic_angular__WEBPACK_IMPORTED_MODULE_1__.IonFooter, _ionic_angular__WEBPACK_IMPORTED_MODULE_1__.IonGrid, _ionic_angular__WEBPACK_IMPORTED_MODULE_1__.IonRow, _core_shared_ui_icon_icon_component__WEBPACK_IMPORTED_MODULE_3__.IconComponent, _ngx_translate_core__WEBPACK_IMPORTED_MODULE_4__.TranslatePipe, _core_shared_pipes_localDate_pipe__WEBPACK_IMPORTED_MODULE_5__.LocalDatePipe],
    styles: ["ion-footer[_ngcontent-%COMP%] {\n  color: black;\n}\n\n.title-challenge[_ngcontent-%COMP%] {\n  font-style: italic;\n  font-weight: 200;\n  font-size: 16px;\n}\n\n.desc-challenge[_ngcontent-%COMP%] {\n  font-style: normal;\n  font-weight: 300;\n  font-size: 17px;\n}\n\n.date-challenge[_ngcontent-%COMP%] {\n  font-style: italic;\n  font-weight: 300;\n  font-size: 13px;\n}\n/*# sourceMappingURL=data:application/json;charset=utf-8;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbIndlYnBhY2s6Ly8uL3NyYy9hcHAvcGFnZXMvY2hhbGxlbmdlcy9zaW5nbGUtY2hhbGxlbmdlLXByb3Bvc2VkL3NpbmdsZS1wcm9wb3NhbC1hY2NlcHRlZC9zaW5nbGUtcHJvcG9zYWwtYWNjZXB0ZWQubW9kYWwuc2NzcyJdLCJuYW1lcyI6W10sIm1hcHBpbmdzIjoiQUFBQTtFQUNFLFlBQUE7QUFDRjs7QUFDQTtFQUNFLGtCQUFBO0VBQ0EsZ0JBQUE7RUFDQSxlQUFBO0FBRUY7O0FBQUE7RUFDRSxrQkFBQTtFQUNBLGdCQUFBO0VBQ0EsZUFBQTtBQUdGOztBQURBO0VBQ0Usa0JBQUE7RUFDQSxnQkFBQTtFQUNBLGVBQUE7QUFJRiIsInNvdXJjZXNDb250ZW50IjpbImlvbi1mb290ZXIge1xuICBjb2xvcjogYmxhY2s7XG59XG4udGl0bGUtY2hhbGxlbmdlIHtcbiAgZm9udC1zdHlsZTogaXRhbGljO1xuICBmb250LXdlaWdodDogMjAwO1xuICBmb250LXNpemU6IDE2cHg7XG59XG4uZGVzYy1jaGFsbGVuZ2Uge1xuICBmb250LXN0eWxlOiBub3JtYWw7XG4gIGZvbnQtd2VpZ2h0OiAzMDA7XG4gIGZvbnQtc2l6ZTogMTdweDtcbn1cbi5kYXRlLWNoYWxsZW5nZSB7XG4gIGZvbnQtc3R5bGU6IGl0YWxpYztcbiAgZm9udC13ZWlnaHQ6IDMwMDtcbiAgZm9udC1zaXplOiAxM3B4O1xufVxuIl0sInNvdXJjZVJvb3QiOiIifQ== */"]
  }));
}
_staticBlock();

/***/ }),

/***/ 67793:
/*!***************************************************************!*\
  !*** ./src/app/pages/challenges/challenges-routing.module.ts ***!
  \***************************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   ChallengesRoutingModule: () => (/* binding */ ChallengesRoutingModule)
/* harmony export */ });
/* harmony import */ var _angular_router__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! @angular/router */ 34487);
/* harmony import */ var _challenges_page__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ./challenges.page */ 97843);
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @angular/core */ 34205);
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @angular/core */ 12481);
var _staticBlock;




const routes = [{
  path: '',
  component: _challenges_page__WEBPACK_IMPORTED_MODULE_1__.ChallengesPage,
  data: {
    title: 'challenges.challenges',
    backButton: false,
    showPlayButton: true,
    refresher: true
  }
}, {
  path: 'create-challenge/:id',
  loadChildren: () => Promise.all(/*! import() */[__webpack_require__.e("common"), __webpack_require__.e("src_app_pages_challenges_create-challenge_create-challenge_module_ts")]).then(__webpack_require__.bind(__webpack_require__, /*! ./create-challenge/create-challenge.module */ 9119)).then(m => m.CreateChallengePageModule)
}];
class ChallengesRoutingModule {
  static #_ = _staticBlock = () => (this.ɵfac = function ChallengesRoutingModule_Factory(__ngFactoryType__) {
    return new (__ngFactoryType__ || ChallengesRoutingModule)();
  }, this.ɵmod = /*@__PURE__*/_angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵdefineNgModule"]({
    type: ChallengesRoutingModule
  }), this.ɵinj = /*@__PURE__*/_angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵdefineInjector"]({
    imports: [_angular_router__WEBPACK_IMPORTED_MODULE_0__.RouterModule.forChild(routes), _angular_router__WEBPACK_IMPORTED_MODULE_0__.RouterModule]
  }));
}
_staticBlock();
(function () {
  (typeof ngJitMode === "undefined" || ngJitMode) && _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵsetNgModuleScope"](ChallengesRoutingModule, {
    imports: [_angular_router__WEBPACK_IMPORTED_MODULE_0__.RouterModule],
    exports: [_angular_router__WEBPACK_IMPORTED_MODULE_0__.RouterModule]
  });
})();

/***/ }),

/***/ 68552:
/*!*******************************************************!*\
  !*** ./src/app/pages/challenges/challenges.module.ts ***!
  \*******************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   ChallengesPageModule: () => (/* binding */ ChallengesPageModule)
/* harmony export */ });
/* harmony import */ var src_app_core_shared_shared_module__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! src/app/core/shared/shared.module */ 62657);
/* harmony import */ var _challenge_card_challenge_card_component__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ./challenge-card/challenge-card.component */ 72508);
/* harmony import */ var _challenge_card_detail_modal_detail_modal__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! ./challenge-card/detail-modal/detail.modal */ 94103);
/* harmony import */ var _challenge_container_challenge_container_component__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! ./challenge-container/challenge-container.component */ 77382);
/* harmony import */ var _challenges_proposed_card_challenges_proposed_card_component__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! ./challenges-proposed-card/challenges-proposed-card.component */ 71900);
/* harmony import */ var _challenges_proposed_card_info_challenge_single_modal_info_challenge_single_modal__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! ./challenges-proposed-card/info-challenge-single-modal/info-challenge-single.modal */ 72813);
/* harmony import */ var _challenges_proposed_card_info_challenge_group_modal_info_challenge_group_modal__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! ./challenges-proposed-card/info-challenge-group-modal/info-challenge-group.modal */ 73759);
/* harmony import */ var _challenges_routing_module__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(/*! ./challenges-routing.module */ 67793);
/* harmony import */ var _challenges_stat_challenge_single_stat_challenge_single_stat_component__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(/*! ./challenges-stat/challenge-single-stat/challenge-single-stat.component */ 12558);
/* harmony import */ var _challenges_stat_challenges_stat_component__WEBPACK_IMPORTED_MODULE_9__ = __webpack_require__(/*! ./challenges-stat/challenges-stat.component */ 38686);
/* harmony import */ var _challenges_page__WEBPACK_IMPORTED_MODULE_10__ = __webpack_require__(/*! ./challenges.page */ 97843);
/* harmony import */ var _couple_challenge_proposed_couple_challenge_proposed_component__WEBPACK_IMPORTED_MODULE_11__ = __webpack_require__(/*! ./couple-challenge-proposed/couple-challenge-proposed.component */ 14858);
/* harmony import */ var _couple_challenge_proposed_invitation_challenge_invitation_challenge_modal__WEBPACK_IMPORTED_MODULE_12__ = __webpack_require__(/*! ./couple-challenge-proposed/invitation-challenge/invitation-challenge.modal */ 86574);
/* harmony import */ var _create_challenge_button_create_challenge_button_component__WEBPACK_IMPORTED_MODULE_13__ = __webpack_require__(/*! ./create-challenge-button/create-challenge-button.component */ 30166);
/* harmony import */ var _create_challenge_sent_invitation_modal_sent_invitation_modal__WEBPACK_IMPORTED_MODULE_14__ = __webpack_require__(/*! ./create-challenge/sent-invitation-modal/sent-invitation.modal */ 41609);
/* harmony import */ var _single_challenge_proposed_single_challenge_proposed_component__WEBPACK_IMPORTED_MODULE_15__ = __webpack_require__(/*! ./single-challenge-proposed/single-challenge-proposed.component */ 78350);
/* harmony import */ var _single_challenge_proposed_single_proposal_accepted_single_proposal_accepted_modal__WEBPACK_IMPORTED_MODULE_16__ = __webpack_require__(/*! ./single-challenge-proposed/single-proposal-accepted/single-proposal-accepted.modal */ 52782);
/* harmony import */ var _single_challenge_proposed_single_proposal_single_proposal_modal__WEBPACK_IMPORTED_MODULE_17__ = __webpack_require__(/*! ./single-challenge-proposed/single-proposal/single-proposal.modal */ 12298);
/* harmony import */ var _ionic_angular__WEBPACK_IMPORTED_MODULE_18__ = __webpack_require__(/*! @ionic/angular */ 21507);
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_19__ = __webpack_require__(/*! @angular/core */ 34205);
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_20__ = __webpack_require__(/*! @angular/core */ 12481);
/* harmony import */ var _angular_common__WEBPACK_IMPORTED_MODULE_21__ = __webpack_require__(/*! @angular/common */ 93683);
/* harmony import */ var _angular_forms__WEBPACK_IMPORTED_MODULE_22__ = __webpack_require__(/*! @angular/forms */ 34456);
/* harmony import */ var _core_shared_layout_header_header_directive__WEBPACK_IMPORTED_MODULE_23__ = __webpack_require__(/*! ../../core/shared/layout/header/header.directive */ 85039);
/* harmony import */ var _core_shared_layout_content_content_directive__WEBPACK_IMPORTED_MODULE_24__ = __webpack_require__(/*! ../../core/shared/layout/content/content.directive */ 75855);
/* harmony import */ var _ngx_translate_core__WEBPACK_IMPORTED_MODULE_25__ = __webpack_require__(/*! @ngx-translate/core */ 48503);
var _staticBlock;


























class ChallengesPageModule {
  static #_ = _staticBlock = () => (this.ɵfac = function ChallengesPageModule_Factory(__ngFactoryType__) {
    return new (__ngFactoryType__ || ChallengesPageModule)();
  }, this.ɵmod = /*@__PURE__*/_angular_core__WEBPACK_IMPORTED_MODULE_20__["ɵɵdefineNgModule"]({
    type: ChallengesPageModule
  }), this.ɵinj = /*@__PURE__*/_angular_core__WEBPACK_IMPORTED_MODULE_19__["ɵɵdefineInjector"]({
    imports: [src_app_core_shared_shared_module__WEBPACK_IMPORTED_MODULE_0__.PlayGoSharedModule, _challenges_routing_module__WEBPACK_IMPORTED_MODULE_7__.ChallengesRoutingModule, _ionic_angular__WEBPACK_IMPORTED_MODULE_18__.IonicModule]
  }));
}
_staticBlock();
(function () {
  (typeof ngJitMode === "undefined" || ngJitMode) && _angular_core__WEBPACK_IMPORTED_MODULE_20__["ɵɵsetNgModuleScope"](ChallengesPageModule, {
    declarations: [_challenges_page__WEBPACK_IMPORTED_MODULE_10__.ChallengesPage, _challenge_card_challenge_card_component__WEBPACK_IMPORTED_MODULE_1__.ChallengeCardComponent, _challenge_container_challenge_container_component__WEBPACK_IMPORTED_MODULE_3__.ChallengeContainerComponent, _challenges_stat_challenges_stat_component__WEBPACK_IMPORTED_MODULE_9__.ChallengesStatComponent, _create_challenge_button_create_challenge_button_component__WEBPACK_IMPORTED_MODULE_13__.CreateChallengeButtonComponent, _challenges_stat_challenge_single_stat_challenge_single_stat_component__WEBPACK_IMPORTED_MODULE_8__.ChalengeSingleStatComponent, _challenges_proposed_card_challenges_proposed_card_component__WEBPACK_IMPORTED_MODULE_4__.ChallengesProposedCardComponent, _couple_challenge_proposed_couple_challenge_proposed_component__WEBPACK_IMPORTED_MODULE_11__.CoupleChallengeProposedComponent, _single_challenge_proposed_single_challenge_proposed_component__WEBPACK_IMPORTED_MODULE_15__.SingleChallengeProposedComponent, _couple_challenge_proposed_invitation_challenge_invitation_challenge_modal__WEBPACK_IMPORTED_MODULE_12__.InvitationlModalPage, _single_challenge_proposed_single_proposal_single_proposal_modal__WEBPACK_IMPORTED_MODULE_17__.SingleProposalModalPage, _create_challenge_sent_invitation_modal_sent_invitation_modal__WEBPACK_IMPORTED_MODULE_14__.SentInvitationlModalPage, _challenges_proposed_card_info_challenge_single_modal_info_challenge_single_modal__WEBPACK_IMPORTED_MODULE_5__.InfoChallengeSingleModalPage, _challenges_proposed_card_info_challenge_group_modal_info_challenge_group_modal__WEBPACK_IMPORTED_MODULE_6__.InfoChallengeGroupModalPage, _challenge_card_detail_modal_detail_modal__WEBPACK_IMPORTED_MODULE_2__.DetailChallengenModalPage, _single_challenge_proposed_single_proposal_accepted_single_proposal_accepted_modal__WEBPACK_IMPORTED_MODULE_16__.SingleProposalAcceptedModalPage],
    imports: [src_app_core_shared_shared_module__WEBPACK_IMPORTED_MODULE_0__.PlayGoSharedModule, _challenges_routing_module__WEBPACK_IMPORTED_MODULE_7__.ChallengesRoutingModule, _ionic_angular__WEBPACK_IMPORTED_MODULE_18__.IonicModule]
  });
})();
_angular_core__WEBPACK_IMPORTED_MODULE_20__["ɵɵsetComponentScope"](_challenges_page__WEBPACK_IMPORTED_MODULE_10__.ChallengesPage, [_angular_common__WEBPACK_IMPORTED_MODULE_21__.NgForOf, _angular_common__WEBPACK_IMPORTED_MODULE_21__.NgIf, _angular_forms__WEBPACK_IMPORTED_MODULE_22__.NgControlStatus, _angular_forms__WEBPACK_IMPORTED_MODULE_22__.NgModel, _ionic_angular__WEBPACK_IMPORTED_MODULE_18__.IonContent, _ionic_angular__WEBPACK_IMPORTED_MODULE_18__.IonHeader, _ionic_angular__WEBPACK_IMPORTED_MODULE_18__.IonLabel, _ionic_angular__WEBPACK_IMPORTED_MODULE_18__.IonSegment, _ionic_angular__WEBPACK_IMPORTED_MODULE_18__.IonSegmentButton, _ionic_angular__WEBPACK_IMPORTED_MODULE_18__.SelectValueAccessor, _core_shared_layout_header_header_directive__WEBPACK_IMPORTED_MODULE_23__.HeaderDirective, _core_shared_layout_content_content_directive__WEBPACK_IMPORTED_MODULE_24__.ContentDirective, _challenge_container_challenge_container_component__WEBPACK_IMPORTED_MODULE_3__.ChallengeContainerComponent, _challenges_stat_challenges_stat_component__WEBPACK_IMPORTED_MODULE_9__.ChallengesStatComponent], [_ngx_translate_core__WEBPACK_IMPORTED_MODULE_25__.TranslatePipe]);
_angular_core__WEBPACK_IMPORTED_MODULE_20__["ɵɵsetComponentScope"](_challenge_container_challenge_container_component__WEBPACK_IMPORTED_MODULE_3__.ChallengeContainerComponent, [_angular_common__WEBPACK_IMPORTED_MODULE_21__.NgForOf, _angular_common__WEBPACK_IMPORTED_MODULE_21__.NgIf, _challenge_card_challenge_card_component__WEBPACK_IMPORTED_MODULE_1__.ChallengeCardComponent, _challenges_proposed_card_challenges_proposed_card_component__WEBPACK_IMPORTED_MODULE_4__.ChallengesProposedCardComponent], []);

/***/ }),

/***/ 71900:
/*!*************************************************************************************************!*\
  !*** ./src/app/pages/challenges/challenges-proposed-card/challenges-proposed-card.component.ts ***!
  \*************************************************************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   ChallengesProposedCardComponent: () => (/* binding */ ChallengesProposedCardComponent)
/* harmony export */ });
/* harmony import */ var _Users_smartcommunitylab_Desktop_newWork_playAndGo_playGo_node_modules_babel_runtime_helpers_esm_asyncToGenerator_js__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./node_modules/@babel/runtime/helpers/esm/asyncToGenerator.js */ 89204);
/* harmony import */ var rxjs__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! rxjs */ 19999);
/* harmony import */ var rxjs__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! rxjs */ 59452);
/* harmony import */ var rxjs__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! rxjs */ 36647);
/* harmony import */ var _info_challenge_single_modal_info_challenge_single_modal__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! ./info-challenge-single-modal/info-challenge-single.modal */ 72813);
/* harmony import */ var _info_challenge_group_modal_info_challenge_group_modal__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! ./info-challenge-group-modal/info-challenge-group.modal */ 73759);
/* harmony import */ var src_app_core_shared_campaigns_campaign_utils__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! src/app/core/shared/campaigns/campaign.utils */ 14691);
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(/*! @angular/core */ 34205);
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(/*! @angular/core */ 12481);
/* harmony import */ var src_app_core_shared_services_campaign_service__WEBPACK_IMPORTED_MODULE_9__ = __webpack_require__(/*! src/app/core/shared/services/campaign.service */ 76658);
/* harmony import */ var _ionic_angular__WEBPACK_IMPORTED_MODULE_10__ = __webpack_require__(/*! @ionic/angular */ 4059);
/* harmony import */ var _ionic_angular__WEBPACK_IMPORTED_MODULE_11__ = __webpack_require__(/*! @ionic/angular */ 21507);
/* harmony import */ var src_app_core_shared_services_challenge_service__WEBPACK_IMPORTED_MODULE_12__ = __webpack_require__(/*! src/app/core/shared/services/challenge.service */ 16561);
/* harmony import */ var src_app_core_shared_services_user_service__WEBPACK_IMPORTED_MODULE_13__ = __webpack_require__(/*! src/app/core/shared/services/user.service */ 89815);
/* harmony import */ var _angular_common__WEBPACK_IMPORTED_MODULE_14__ = __webpack_require__(/*! @angular/common */ 93683);
/* harmony import */ var _create_challenge_button_create_challenge_button_component__WEBPACK_IMPORTED_MODULE_15__ = __webpack_require__(/*! ../create-challenge-button/create-challenge-button.component */ 30166);
/* harmony import */ var _couple_challenge_proposed_couple_challenge_proposed_component__WEBPACK_IMPORTED_MODULE_16__ = __webpack_require__(/*! ../couple-challenge-proposed/couple-challenge-proposed.component */ 14858);
/* harmony import */ var _single_challenge_proposed_single_challenge_proposed_component__WEBPACK_IMPORTED_MODULE_17__ = __webpack_require__(/*! ../single-challenge-proposed/single-challenge-proposed.component */ 78350);
/* harmony import */ var _ngx_translate_core__WEBPACK_IMPORTED_MODULE_18__ = __webpack_require__(/*! @ngx-translate/core */ 48503);
/* harmony import */ var _core_shared_pipes_languageMap_pipe__WEBPACK_IMPORTED_MODULE_19__ = __webpack_require__(/*! ../../../core/shared/pipes/languageMap.pipe */ 69618);

var _staticBlock;















const _c0 = a0 => ({
  "background-color": a0
});
function ChallengesProposedCardComponent_ion_card_0_div_9_app_single_challenge_proposed_5_Template(rf, ctx) {
  if (rf & 1) {
    _angular_core__WEBPACK_IMPORTED_MODULE_8__["ɵɵelement"](0, "app-single-challenge-proposed", 9);
  }
  if (rf & 2) {
    const chall_r3 = ctx.$implicit;
    const ctx_r1 = _angular_core__WEBPACK_IMPORTED_MODULE_8__["ɵɵnextContext"](3);
    _angular_core__WEBPACK_IMPORTED_MODULE_8__["ɵɵproperty"]("challenge", chall_r3)("campaign", ctx_r1.campaign);
  }
}
function ChallengesProposedCardComponent_ion_card_0_div_9_Template(rf, ctx) {
  if (rf & 1) {
    const _r1 = _angular_core__WEBPACK_IMPORTED_MODULE_8__["ɵɵgetCurrentView"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_8__["ɵɵelementStart"](0, "div", 5)(1, "ion-icon", 6);
    _angular_core__WEBPACK_IMPORTED_MODULE_8__["ɵɵlistener"]("click", function ChallengesProposedCardComponent_ion_card_0_div_9_Template_ion_icon_click_1_listener() {
      _angular_core__WEBPACK_IMPORTED_MODULE_7__["ɵɵrestoreView"](_r1);
      const ctx_r1 = _angular_core__WEBPACK_IMPORTED_MODULE_8__["ɵɵnextContext"](2);
      return _angular_core__WEBPACK_IMPORTED_MODULE_7__["ɵɵresetView"](ctx_r1.openInfoChallengeSingle());
    });
    _angular_core__WEBPACK_IMPORTED_MODULE_8__["ɵɵelementEnd"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_8__["ɵɵelementStart"](2, "p", 7);
    _angular_core__WEBPACK_IMPORTED_MODULE_8__["ɵɵtext"](3);
    _angular_core__WEBPACK_IMPORTED_MODULE_8__["ɵɵpipe"](4, "translate");
    _angular_core__WEBPACK_IMPORTED_MODULE_8__["ɵɵelementEnd"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_8__["ɵɵtemplate"](5, ChallengesProposedCardComponent_ion_card_0_div_9_app_single_challenge_proposed_5_Template, 1, 2, "app-single-challenge-proposed", 8);
    _angular_core__WEBPACK_IMPORTED_MODULE_8__["ɵɵelementEnd"]();
  }
  if (rf & 2) {
    const ctx_r1 = _angular_core__WEBPACK_IMPORTED_MODULE_8__["ɵɵnextContext"](2);
    _angular_core__WEBPACK_IMPORTED_MODULE_8__["ɵɵadvance"](3);
    _angular_core__WEBPACK_IMPORTED_MODULE_8__["ɵɵtextInterpolate1"](" ", _angular_core__WEBPACK_IMPORTED_MODULE_8__["ɵɵpipeBind1"](4, 2, "challenges.choose_single"), " ");
    _angular_core__WEBPACK_IMPORTED_MODULE_8__["ɵɵadvance"](2);
    _angular_core__WEBPACK_IMPORTED_MODULE_8__["ɵɵproperty"]("ngForOf", ctx_r1.singleChallenges);
  }
}
function ChallengesProposedCardComponent_ion_card_0_div_10_app_create_challenge_button_5_Template(rf, ctx) {
  if (rf & 1) {
    const _r5 = _angular_core__WEBPACK_IMPORTED_MODULE_8__["ɵɵgetCurrentView"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_8__["ɵɵelementStart"](0, "app-create-challenge-button", 12);
    _angular_core__WEBPACK_IMPORTED_MODULE_8__["ɵɵlistener"]("click", function ChallengesProposedCardComponent_ion_card_0_div_10_app_create_challenge_button_5_Template_app_create_challenge_button_click_0_listener($event) {
      _angular_core__WEBPACK_IMPORTED_MODULE_7__["ɵɵrestoreView"](_r5);
      const ctx_r1 = _angular_core__WEBPACK_IMPORTED_MODULE_8__["ɵɵnextContext"](3);
      return _angular_core__WEBPACK_IMPORTED_MODULE_7__["ɵɵresetView"](ctx_r1.goToCreateChallenge($event, ctx_r1.campaign));
    });
    _angular_core__WEBPACK_IMPORTED_MODULE_8__["ɵɵelementEnd"]();
  }
  if (rf & 2) {
    const ctx_r1 = _angular_core__WEBPACK_IMPORTED_MODULE_8__["ɵɵnextContext"](3);
    _angular_core__WEBPACK_IMPORTED_MODULE_8__["ɵɵproperty"]("campaign", ctx_r1.campaign);
  }
}
function ChallengesProposedCardComponent_ion_card_0_div_10_app_couple_challenge_proposed_7_Template(rf, ctx) {
  if (rf & 1) {
    _angular_core__WEBPACK_IMPORTED_MODULE_8__["ɵɵelement"](0, "app-couple-challenge-proposed", 9);
  }
  if (rf & 2) {
    const chall_r6 = ctx.$implicit;
    const ctx_r1 = _angular_core__WEBPACK_IMPORTED_MODULE_8__["ɵɵnextContext"](3);
    _angular_core__WEBPACK_IMPORTED_MODULE_8__["ɵɵproperty"]("challenge", chall_r6)("campaign", ctx_r1.campaign);
  }
}
function ChallengesProposedCardComponent_ion_card_0_div_10_Template(rf, ctx) {
  if (rf & 1) {
    const _r4 = _angular_core__WEBPACK_IMPORTED_MODULE_8__["ɵɵgetCurrentView"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_8__["ɵɵelementStart"](0, "div", 5)(1, "ion-icon", 6);
    _angular_core__WEBPACK_IMPORTED_MODULE_8__["ɵɵlistener"]("click", function ChallengesProposedCardComponent_ion_card_0_div_10_Template_ion_icon_click_1_listener() {
      _angular_core__WEBPACK_IMPORTED_MODULE_7__["ɵɵrestoreView"](_r4);
      const ctx_r1 = _angular_core__WEBPACK_IMPORTED_MODULE_8__["ɵɵnextContext"](2);
      return _angular_core__WEBPACK_IMPORTED_MODULE_7__["ɵɵresetView"](ctx_r1.openInfoChallengeGroup());
    });
    _angular_core__WEBPACK_IMPORTED_MODULE_8__["ɵɵelementEnd"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_8__["ɵɵelementStart"](2, "p", 10);
    _angular_core__WEBPACK_IMPORTED_MODULE_8__["ɵɵtext"](3);
    _angular_core__WEBPACK_IMPORTED_MODULE_8__["ɵɵpipe"](4, "translate");
    _angular_core__WEBPACK_IMPORTED_MODULE_8__["ɵɵelementEnd"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_8__["ɵɵtemplate"](5, ChallengesProposedCardComponent_ion_card_0_div_10_app_create_challenge_button_5_Template, 1, 1, "app-create-challenge-button", 11);
    _angular_core__WEBPACK_IMPORTED_MODULE_8__["ɵɵpipe"](6, "async");
    _angular_core__WEBPACK_IMPORTED_MODULE_8__["ɵɵtemplate"](7, ChallengesProposedCardComponent_ion_card_0_div_10_app_couple_challenge_proposed_7_Template, 1, 2, "app-couple-challenge-proposed", 8);
    _angular_core__WEBPACK_IMPORTED_MODULE_8__["ɵɵelementEnd"]();
  }
  if (rf & 2) {
    const ctx_r1 = _angular_core__WEBPACK_IMPORTED_MODULE_8__["ɵɵnextContext"](2);
    _angular_core__WEBPACK_IMPORTED_MODULE_8__["ɵɵadvance"](3);
    _angular_core__WEBPACK_IMPORTED_MODULE_8__["ɵɵtextInterpolate1"](" ", _angular_core__WEBPACK_IMPORTED_MODULE_8__["ɵɵpipeBind1"](4, 3, "challenges.choose_or_configure"), " ");
    _angular_core__WEBPACK_IMPORTED_MODULE_8__["ɵɵadvance"](2);
    _angular_core__WEBPACK_IMPORTED_MODULE_8__["ɵɵproperty"]("ngIf", ctx_r1.canInvite && _angular_core__WEBPACK_IMPORTED_MODULE_8__["ɵɵpipeBind1"](6, 5, ctx_r1.sentInvitation$) === false);
    _angular_core__WEBPACK_IMPORTED_MODULE_8__["ɵɵadvance"](2);
    _angular_core__WEBPACK_IMPORTED_MODULE_8__["ɵɵproperty"]("ngForOf", ctx_r1.coupleChallenges);
  }
}
function ChallengesProposedCardComponent_ion_card_0_Template(rf, ctx) {
  if (rf & 1) {
    _angular_core__WEBPACK_IMPORTED_MODULE_8__["ɵɵelementStart"](0, "ion-card")(1, "ion-card-header", 1)(2, "span");
    _angular_core__WEBPACK_IMPORTED_MODULE_8__["ɵɵtext"](3);
    _angular_core__WEBPACK_IMPORTED_MODULE_8__["ɵɵpipe"](4, "languageMap");
    _angular_core__WEBPACK_IMPORTED_MODULE_8__["ɵɵelementEnd"]()();
    _angular_core__WEBPACK_IMPORTED_MODULE_8__["ɵɵelementStart"](5, "ion-card-content", 2)(6, "p", 3);
    _angular_core__WEBPACK_IMPORTED_MODULE_8__["ɵɵtext"](7);
    _angular_core__WEBPACK_IMPORTED_MODULE_8__["ɵɵpipe"](8, "translate");
    _angular_core__WEBPACK_IMPORTED_MODULE_8__["ɵɵelementEnd"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_8__["ɵɵtemplate"](9, ChallengesProposedCardComponent_ion_card_0_div_9_Template, 6, 4, "div", 4)(10, ChallengesProposedCardComponent_ion_card_0_div_10_Template, 8, 7, "div", 4);
    _angular_core__WEBPACK_IMPORTED_MODULE_8__["ɵɵpipe"](11, "async");
    _angular_core__WEBPACK_IMPORTED_MODULE_8__["ɵɵelementEnd"]()();
  }
  if (rf & 2) {
    const ctx_r1 = _angular_core__WEBPACK_IMPORTED_MODULE_8__["ɵɵnextContext"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_8__["ɵɵadvance"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_8__["ɵɵproperty"]("color", ctx_r1.campaign == null ? null : ctx_r1.campaign.campaign == null ? null : ctx_r1.campaign.campaign.type);
    _angular_core__WEBPACK_IMPORTED_MODULE_8__["ɵɵadvance"](2);
    _angular_core__WEBPACK_IMPORTED_MODULE_8__["ɵɵtextInterpolate"](_angular_core__WEBPACK_IMPORTED_MODULE_8__["ɵɵpipeBind1"](4, 6, ctx_r1.campaign == null ? null : ctx_r1.campaign.campaign == null ? null : ctx_r1.campaign.campaign.name));
    _angular_core__WEBPACK_IMPORTED_MODULE_8__["ɵɵadvance"](2);
    _angular_core__WEBPACK_IMPORTED_MODULE_8__["ɵɵproperty"]("ngStyle", _angular_core__WEBPACK_IMPORTED_MODULE_8__["ɵɵpureFunction1"](12, _c0, "var(--ion-color-" + (ctx_r1.campaign == null ? null : ctx_r1.campaign.campaign == null ? null : ctx_r1.campaign.campaign.type) + "-light)"));
    _angular_core__WEBPACK_IMPORTED_MODULE_8__["ɵɵadvance"](2);
    _angular_core__WEBPACK_IMPORTED_MODULE_8__["ɵɵtextInterpolate"](_angular_core__WEBPACK_IMPORTED_MODULE_8__["ɵɵpipeBind1"](8, 8, "challenges.proposed"));
    _angular_core__WEBPACK_IMPORTED_MODULE_8__["ɵɵadvance"](2);
    _angular_core__WEBPACK_IMPORTED_MODULE_8__["ɵɵproperty"]("ngIf", (ctx_r1.singleChallenges == null ? null : ctx_r1.singleChallenges.length) > 0);
    _angular_core__WEBPACK_IMPORTED_MODULE_8__["ɵɵadvance"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_8__["ɵɵproperty"]("ngIf", ctx_r1.canInvite && _angular_core__WEBPACK_IMPORTED_MODULE_8__["ɵɵpipeBind1"](11, 10, ctx_r1.sentInvitation$) === false || ctx_r1.coupleChallenges.length > 0);
  }
}
class ChallengesProposedCardComponent {
  constructor(campaignService, navCtrl, challengeService, userService, modalController) {
    this.campaignService = campaignService;
    this.navCtrl = navCtrl;
    this.challengeService = challengeService;
    this.userService = userService;
    this.modalController = modalController;
    this.challenges = [];
    this.imgChallenge = src_app_core_shared_campaigns_campaign_utils__WEBPACK_IMPORTED_MODULE_6__.getImgChallenge;
    this.singleChallenges = [];
    this.coupleChallenges = [];
  }
  ngOnInit() {
    this.sentInvitation$ = (0,rxjs__WEBPACK_IMPORTED_MODULE_1__.combineLatest)([this.userService.userProfile$, this.challengeService.futureChallenges$, this.challengeService.futureChallengesTeam$]).pipe((0,rxjs__WEBPACK_IMPORTED_MODULE_3__.switchMap)(([profile, challenges, challengesTeam]) => {
      if (challenges.some(chall => chall.proposerId === profile.playerId) || challengesTeam.some(chall => chall.proposerId === profile.playerId)) {
        return (0,rxjs__WEBPACK_IMPORTED_MODULE_2__.of)(true);
      }
      return (0,rxjs__WEBPACK_IMPORTED_MODULE_2__.of)(false);
    }));
  }
  ngOnChanges() {
    // console.log(this.canInvite);
    this.singleChallenges = this.challenges?.filter(challenge => challenge.otherAttendeeData == null);
    this.coupleChallenges = this.challenges?.filter(challenge => challenge.otherAttendeeData != null);
  }
  goToCreateChallenge(event, campaign) {
    this.navCtrl.navigateRoot(`/pages/tabs/challenges/create-challenge/${campaign.campaign.campaignId}`);
  }
  openInfoChallengeSingle() {
    var _this = this;
    return (0,_Users_smartcommunitylab_Desktop_newWork_playAndGo_playGo_node_modules_babel_runtime_helpers_esm_asyncToGenerator_js__WEBPACK_IMPORTED_MODULE_0__["default"])(function* () {
      const modal = yield _this.modalController.create({
        component: _info_challenge_single_modal_info_challenge_single_modal__WEBPACK_IMPORTED_MODULE_4__.InfoChallengeSingleModalPage,
        cssClass: 'modal-challenge',
        canDismiss: true
      });
      yield modal.present();
      yield modal.onWillDismiss();
    })();
  }
  openInfoChallengeGroup() {
    var _this2 = this;
    return (0,_Users_smartcommunitylab_Desktop_newWork_playAndGo_playGo_node_modules_babel_runtime_helpers_esm_asyncToGenerator_js__WEBPACK_IMPORTED_MODULE_0__["default"])(function* () {
      const modal = yield _this2.modalController.create({
        component: _info_challenge_group_modal_info_challenge_group_modal__WEBPACK_IMPORTED_MODULE_5__.InfoChallengeGroupModalPage,
        cssClass: 'modal-challenge',
        canDismiss: true
      });
      yield modal.present();
      yield modal.onWillDismiss();
    })();
  }
  static #_ = _staticBlock = () => (this.ɵfac = function ChallengesProposedCardComponent_Factory(__ngFactoryType__) {
    return new (__ngFactoryType__ || ChallengesProposedCardComponent)(_angular_core__WEBPACK_IMPORTED_MODULE_8__["ɵɵdirectiveInject"](src_app_core_shared_services_campaign_service__WEBPACK_IMPORTED_MODULE_9__.CampaignService), _angular_core__WEBPACK_IMPORTED_MODULE_8__["ɵɵdirectiveInject"](_ionic_angular__WEBPACK_IMPORTED_MODULE_10__.NavController), _angular_core__WEBPACK_IMPORTED_MODULE_8__["ɵɵdirectiveInject"](src_app_core_shared_services_challenge_service__WEBPACK_IMPORTED_MODULE_12__.ChallengeService), _angular_core__WEBPACK_IMPORTED_MODULE_8__["ɵɵdirectiveInject"](src_app_core_shared_services_user_service__WEBPACK_IMPORTED_MODULE_13__.UserService), _angular_core__WEBPACK_IMPORTED_MODULE_8__["ɵɵdirectiveInject"](_ionic_angular__WEBPACK_IMPORTED_MODULE_11__.ModalController));
  }, this.ɵcmp = /*@__PURE__*/_angular_core__WEBPACK_IMPORTED_MODULE_8__["ɵɵdefineComponent"]({
    type: ChallengesProposedCardComponent,
    selectors: [["app-challenges-proposed-card"]],
    inputs: {
      challenges: "challenges",
      campaign: "campaign",
      type: "type",
      canInvite: "canInvite"
    },
    standalone: false,
    features: [_angular_core__WEBPACK_IMPORTED_MODULE_8__["ɵɵNgOnChangesFeature"]],
    decls: 2,
    vars: 3,
    consts: [[4, "ngIf"], [1, "header", 3, "color"], [3, "ngStyle"], [1, "text-proposed"], ["class", "container", 4, "ngIf"], [1, "container"], ["name", "information-circle-outline", 1, "popup-icon", 3, "click"], [1, "subtext-proposed"], [3, "challenge", "campaign", 4, "ngFor", "ngForOf"], [3, "challenge", "campaign"], [1, "ion-text-center", "subtext-proposed"], [3, "campaign", "click", 4, "ngIf"], [3, "click", "campaign"]],
    template: function ChallengesProposedCardComponent_Template(rf, ctx) {
      if (rf & 1) {
        _angular_core__WEBPACK_IMPORTED_MODULE_8__["ɵɵtemplate"](0, ChallengesProposedCardComponent_ion_card_0_Template, 12, 14, "ion-card", 0);
        _angular_core__WEBPACK_IMPORTED_MODULE_8__["ɵɵpipe"](1, "async");
      }
      if (rf & 2) {
        _angular_core__WEBPACK_IMPORTED_MODULE_8__["ɵɵproperty"]("ngIf", (ctx.singleChallenges == null ? null : ctx.singleChallenges.length) > 0 || ctx.canInvite && _angular_core__WEBPACK_IMPORTED_MODULE_8__["ɵɵpipeBind1"](1, 1, ctx.sentInvitation$) === false || ctx.coupleChallenges.length > 0);
      }
    },
    dependencies: [_angular_common__WEBPACK_IMPORTED_MODULE_14__.NgForOf, _angular_common__WEBPACK_IMPORTED_MODULE_14__.NgIf, _angular_common__WEBPACK_IMPORTED_MODULE_14__.NgStyle, _ionic_angular__WEBPACK_IMPORTED_MODULE_11__.IonCard, _ionic_angular__WEBPACK_IMPORTED_MODULE_11__.IonCardContent, _ionic_angular__WEBPACK_IMPORTED_MODULE_11__.IonCardHeader, _ionic_angular__WEBPACK_IMPORTED_MODULE_11__.IonIcon, _create_challenge_button_create_challenge_button_component__WEBPACK_IMPORTED_MODULE_15__.CreateChallengeButtonComponent, _couple_challenge_proposed_couple_challenge_proposed_component__WEBPACK_IMPORTED_MODULE_16__.CoupleChallengeProposedComponent, _single_challenge_proposed_single_challenge_proposed_component__WEBPACK_IMPORTED_MODULE_17__.SingleChallengeProposedComponent, _angular_common__WEBPACK_IMPORTED_MODULE_14__.AsyncPipe, _ngx_translate_core__WEBPACK_IMPORTED_MODULE_18__.TranslatePipe, _core_shared_pipes_languageMap_pipe__WEBPACK_IMPORTED_MODULE_19__.LanguageMapPipe],
    styles: ["ion-card-title[_ngcontent-%COMP%] {\n  font-size: small;\n}\n\n.text-proposed[_ngcontent-%COMP%] {\n  text-align: center;\n  font-style: normal;\n  font-weight: 600;\n  font-size: 18px;\n  text-align: center;\n  color: #000000;\n}\n\n.subtext-proposed[_ngcontent-%COMP%] {\n  font-style: normal;\n  font-weight: 300;\n  font-size: 15px;\n  line-height: 18px;\n  text-align: center;\n  color: #000000;\n}\n\n.container[_ngcontent-%COMP%] {\n  position: relative;\n}\n.container[_ngcontent-%COMP%]   .popup-icon[_ngcontent-%COMP%] {\n  position: absolute;\n  right: 0px;\n  top: 0px;\n  font-size: 20px;\n}\n\n.header[_ngcontent-%COMP%] {\n  text-align: start;\n  padding: 4px;\n  font-style: italic;\n  font-weight: 300;\n  font-size: 13px;\n}\n.header[_ngcontent-%COMP%]   span[_ngcontent-%COMP%] {\n  margin-left: 18px;\n}\n/*# sourceMappingURL=data:application/json;charset=utf-8;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbIndlYnBhY2s6Ly8uL3NyYy9hcHAvcGFnZXMvY2hhbGxlbmdlcy9jaGFsbGVuZ2VzLXByb3Bvc2VkLWNhcmQvY2hhbGxlbmdlcy1wcm9wb3NlZC1jYXJkLmNvbXBvbmVudC5zY3NzIl0sIm5hbWVzIjpbXSwibWFwcGluZ3MiOiJBQUFBO0VBQ0UsZ0JBQUE7QUFDRjs7QUFDQTtFQUNFLGtCQUFBO0VBQ0Esa0JBQUE7RUFDQSxnQkFBQTtFQUNBLGVBQUE7RUFDQSxrQkFBQTtFQUNBLGNBQUE7QUFFRjs7QUFBQTtFQUNFLGtCQUFBO0VBQ0EsZ0JBQUE7RUFDQSxlQUFBO0VBQ0EsaUJBQUE7RUFDQSxrQkFBQTtFQUNBLGNBQUE7QUFHRjs7QUFEQTtFQUNFLGtCQUFBO0FBSUY7QUFIRTtFQUNFLGtCQUFBO0VBQ0EsVUFBQTtFQUNBLFFBQUE7RUFDQSxlQUFBO0FBS0o7O0FBRkE7RUFDRSxpQkFBQTtFQUNBLFlBQUE7RUFDQSxrQkFBQTtFQUNBLGdCQUFBO0VBQ0EsZUFBQTtBQUtGO0FBSkU7RUFDRSxpQkFBQTtBQU1KIiwic291cmNlc0NvbnRlbnQiOlsiaW9uLWNhcmQtdGl0bGUge1xuICBmb250LXNpemU6IHNtYWxsO1xufVxuLnRleHQtcHJvcG9zZWQge1xuICB0ZXh0LWFsaWduOiBjZW50ZXI7XG4gIGZvbnQtc3R5bGU6IG5vcm1hbDtcbiAgZm9udC13ZWlnaHQ6IDYwMDtcbiAgZm9udC1zaXplOiAxOHB4O1xuICB0ZXh0LWFsaWduOiBjZW50ZXI7XG4gIGNvbG9yOiAjMDAwMDAwO1xufVxuLnN1YnRleHQtcHJvcG9zZWQge1xuICBmb250LXN0eWxlOiBub3JtYWw7XG4gIGZvbnQtd2VpZ2h0OiAzMDA7XG4gIGZvbnQtc2l6ZTogMTVweDtcbiAgbGluZS1oZWlnaHQ6IDE4cHg7XG4gIHRleHQtYWxpZ246IGNlbnRlcjtcbiAgY29sb3I6ICMwMDAwMDA7XG59XG4uY29udGFpbmVyIHtcbiAgcG9zaXRpb246IHJlbGF0aXZlO1xuICAucG9wdXAtaWNvbiB7XG4gICAgcG9zaXRpb246IGFic29sdXRlO1xuICAgIHJpZ2h0OiAwcHg7XG4gICAgdG9wOiAwcHg7XG4gICAgZm9udC1zaXplOiAyMHB4O1xuICB9XG59XG4uaGVhZGVyIHtcbiAgdGV4dC1hbGlnbjogc3RhcnQ7XG4gIHBhZGRpbmc6IDRweDtcbiAgZm9udC1zdHlsZTogaXRhbGljO1xuICBmb250LXdlaWdodDogMzAwO1xuICBmb250LXNpemU6IDEzcHg7XG4gIHNwYW4ge1xuICAgIG1hcmdpbi1sZWZ0OiAxOHB4O1xuICB9XG59XG4iXSwic291cmNlUm9vdCI6IiJ9 */"]
  }));
}
_staticBlock();

/***/ }),

/***/ 72508:
/*!*****************************************************************************!*\
  !*** ./src/app/pages/challenges/challenge-card/challenge-card.component.ts ***!
  \*****************************************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   ChallengeCardComponent: () => (/* binding */ ChallengeCardComponent)
/* harmony export */ });
/* harmony import */ var _Users_smartcommunitylab_Desktop_newWork_playAndGo_playGo_node_modules_babel_runtime_helpers_esm_asyncToGenerator_js__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./node_modules/@babel/runtime/helpers/esm/asyncToGenerator.js */ 89204);
/* harmony import */ var _capacitor_browser__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @capacitor/browser */ 26515);
/* harmony import */ var _detail_modal_detail_modal__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! ./detail-modal/detail.modal */ 94103);
/* harmony import */ var src_app_core_shared_campaigns_campaign_utils__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! src/app/core/shared/campaigns/campaign.utils */ 14691);
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! @angular/core */ 34205);
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! @angular/core */ 12481);
/* harmony import */ var src_app_core_shared_services_campaign_service__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! src/app/core/shared/services/campaign.service */ 76658);
/* harmony import */ var _ionic_angular__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(/*! @ionic/angular */ 21507);
/* harmony import */ var _ngx_translate_core__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(/*! @ngx-translate/core */ 48503);
/* harmony import */ var src_app_core_shared_services_refresher_service__WEBPACK_IMPORTED_MODULE_9__ = __webpack_require__(/*! src/app/core/shared/services/refresher.service */ 8780);
/* harmony import */ var src_app_core_shared_services_team_service__WEBPACK_IMPORTED_MODULE_10__ = __webpack_require__(/*! src/app/core/shared/services/team.service */ 62625);
/* harmony import */ var _angular_common__WEBPACK_IMPORTED_MODULE_11__ = __webpack_require__(/*! @angular/common */ 93683);
/* harmony import */ var _core_shared_ui_icon_icon_component__WEBPACK_IMPORTED_MODULE_12__ = __webpack_require__(/*! ../../../core/shared/ui/icon/icon.component */ 59621);
/* harmony import */ var _core_shared_campaigns_challenge_users_status_challenge_users_status_component__WEBPACK_IMPORTED_MODULE_13__ = __webpack_require__(/*! ../../../core/shared/campaigns/challenge-users-status/challenge-users-status.component */ 11454);
/* harmony import */ var _core_shared_campaigns_challenge_bar_status_challenge_bar_status_component__WEBPACK_IMPORTED_MODULE_14__ = __webpack_require__(/*! ../../../core/shared/campaigns/challenge-bar-status/challenge-bar-status.component */ 26856);
/* harmony import */ var _core_shared_pipes_localDate_pipe__WEBPACK_IMPORTED_MODULE_15__ = __webpack_require__(/*! ../../../core/shared/pipes/localDate.pipe */ 86451);
/* harmony import */ var _core_shared_pipes_languageMap_pipe__WEBPACK_IMPORTED_MODULE_16__ = __webpack_require__(/*! ../../../core/shared/pipes/languageMap.pipe */ 69618);

var _staticBlock;















const _c0 = (a0, a1) => ({
  from: a0,
  to: a1
});
const _c1 = a0 => ({
  prize: a0
});
const _c2 = a0 => ({
  startDate: a0
});
function ChallengeCardComponent_ion_row_19_div_2_Template(rf, ctx) {
  if (rf & 1) {
    _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵelementStart"](0, "div")(1, "p", 20);
    _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵtext"](2);
    _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵpipe"](3, "translate");
    _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵpipe"](4, "uppercase");
    _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵelementEnd"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵelementStart"](5, "p", 21);
    _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵtext"](6);
    _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵpipe"](7, "translate");
    _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵelement"](8, "app-icon", 18);
    _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵelementEnd"]()();
  }
  if (rf & 2) {
    const ctx_r1 = _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵnextContext"](2);
    _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵadvance"](2);
    _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵtextInterpolate1"](" ", _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵpipeBind1"](4, 5, _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵpipeBind1"](3, 3, "challenges.challenge_detail.won")), " ");
    _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵadvance"](4);
    _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵtextInterpolate1"](" ", _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵpipeBind2"](7, 7, "challenges.challenge_detail.prize", _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵpureFunction1"](10, _c1, ctx_r1.challenge.bonus)), " ");
    _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵadvance"](2);
    _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵproperty"]("name", ctx_r1.campaignService.getCampaignScoreIcon(ctx_r1.challenge.campaign));
  }
}
function ChallengeCardComponent_ion_row_19_ng_template_3_Template(rf, ctx) {
  if (rf & 1) {
    _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵelementStart"](0, "p", 22);
    _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵtext"](1);
    _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵpipe"](2, "translate");
    _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵpipe"](3, "uppercase");
    _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵelementEnd"]();
  }
  if (rf & 2) {
    _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵadvance"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵtextInterpolate1"](" ", _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵpipeBind1"](3, 3, _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵpipeBind1"](2, 1, "challenges.challenge_detail.lost")), " ");
  }
}
function ChallengeCardComponent_ion_row_19_Template(rf, ctx) {
  if (rf & 1) {
    _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵelementStart"](0, "ion-row")(1, "ion-col", 19);
    _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵtemplate"](2, ChallengeCardComponent_ion_row_19_div_2_Template, 9, 12, "div", 14)(3, ChallengeCardComponent_ion_row_19_ng_template_3_Template, 4, 5, "ng-template", null, 1, _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵtemplateRefExtractor"]);
    _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵelementEnd"]()();
  }
  if (rf & 2) {
    const challengeLost_r3 = _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵreference"](4);
    const ctx_r1 = _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵnextContext"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵadvance"](2);
    _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵproperty"]("ngIf", ctx_r1.challengeWon())("ngIfElse", challengeLost_r3);
  }
}
function ChallengeCardComponent_app_challenge_users_status_22_Template(rf, ctx) {
  if (rf & 1) {
    _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵelement"](0, "app-challenge-users-status", 23);
  }
  if (rf & 2) {
    const ctx_r1 = _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵnextContext"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵproperty"]("status", ctx_r1.challenge.status)("rowStatus", ctx_r1.challenge.row_status)("type", ctx_r1.type)("challengeType", ctx_r1.challenge.type)("otherUser", ctx_r1.challenge.otherAttendeeData)("kind", ctx_r1.challenge.kind)("campaignContainer", ctx_r1.campaignContainer)("unitHasKm", ctx_r1.getUnitChallenge(ctx_r1.challenge));
  }
}
function ChallengeCardComponent_div_25_app_challenge_bar_status_1_Template(rf, ctx) {
  if (rf & 1) {
    _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵelement"](0, "app-challenge-bar-status", 25);
  }
  if (rf & 2) {
    const ctx_r1 = _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵnextContext"](2);
    _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵproperty"]("status", ctx_r1.challenge.status)("rowStatus", ctx_r1.challenge.row_status)("otherStatus", ctx_r1.challenge.otherAttendeeData == null ? null : ctx_r1.challenge.otherAttendeeData.status)("challengeType", ctx_r1.challenge.type)("type", ctx_r1.type)("campaignType", ctx_r1.challenge.campaign.type);
  }
}
function ChallengeCardComponent_div_25_ng_template_2_ion_button_0_Template(rf, ctx) {
  if (rf & 1) {
    const _r4 = _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵgetCurrentView"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵelementStart"](0, "ion-button", 27);
    _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵlistener"]("click", function ChallengeCardComponent_div_25_ng_template_2_ion_button_0_Template_ion_button_click_0_listener() {
      _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵrestoreView"](_r4);
      const ctx_r1 = _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵnextContext"](3);
      return _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵresetView"](ctx_r1.fillSurvey());
    });
    _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵtext"](1);
    _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵpipe"](2, "translate");
    _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵelementEnd"]();
  }
  if (rf & 2) {
    const ctx_r1 = _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵnextContext"](3);
    _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵproperty"]("color", ctx_r1.challenge == null ? null : ctx_r1.challenge.campaign == null ? null : ctx_r1.challenge.campaign.type);
    _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵadvance"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵtextInterpolate1"](" ", _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵpipeBind1"](2, 2, "challenges.challenge_detail.survey"), " ");
  }
}
function ChallengeCardComponent_div_25_ng_template_2_Template(rf, ctx) {
  if (rf & 1) {
    _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵtemplate"](0, ChallengeCardComponent_div_25_ng_template_2_ion_button_0_Template, 3, 4, "ion-button", 26);
  }
  if (rf & 2) {
    const ctx_r1 = _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵnextContext"](2);
    _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵproperty"]("ngIf", ctx_r1.challenge.extUrl && ctx_r1.challenge.status < 100);
  }
}
function ChallengeCardComponent_div_25_Template(rf, ctx) {
  if (rf & 1) {
    _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵelementStart"](0, "div");
    _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵtemplate"](1, ChallengeCardComponent_div_25_app_challenge_bar_status_1_Template, 1, 6, "app-challenge-bar-status", 24)(2, ChallengeCardComponent_div_25_ng_template_2_Template, 1, 1, "ng-template", null, 2, _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵtemplateRefExtractor"]);
    _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵelementEnd"]();
  }
  if (rf & 2) {
    const survey_r5 = _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵreference"](3);
    const ctx_r1 = _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵnextContext"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵadvance"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵproperty"]("ngIf", ctx_r1.challenge.type !== "survey")("ngIfElse", survey_r5);
  }
}
function ChallengeCardComponent_ng_template_26_Template(rf, ctx) {
  if (rf & 1) {
    _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵelementStart"](0, "div", 28);
    _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵtext"](1);
    _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵpipe"](2, "localDate");
    _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵpipe"](3, "translate");
    _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵelementEnd"]();
  }
  if (rf & 2) {
    const ctx_r1 = _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵnextContext"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵadvance"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵtextInterpolate1"](" ", _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵpipeBind2"](3, 3, "challenges.challenge_detail.challenge_future_start", _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵpureFunction1"](6, _c2, _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵpipeBind1"](2, 1, ctx_r1.challenge.startDate))), " ");
  }
}
class ChallengeCardComponent {
  constructor(campaignService, elementRef, modalController, translateService, refresherService, teamService) {
    this.campaignService = campaignService;
    this.elementRef = elementRef;
    this.modalController = modalController;
    this.translateService = translateService;
    this.refresherService = refresherService;
    this.teamService = teamService;
    this.team = false;
    this.imgChallenge = src_app_core_shared_campaigns_campaign_utils__WEBPACK_IMPORTED_MODULE_3__.getImgChallenge;
    this.handleAnchorClick = event => {
      // Prevent opening anchors the default way
      event.preventDefault();
      const anchor = event.target;
      _capacitor_browser__WEBPACK_IMPORTED_MODULE_1__.Browser.open({
        url: anchor.href,
        windowName: '_system',
        presentationStyle: 'popover'
      });
    };
  }
  ngAfterViewInit() {
    //change the behaviour of _blank arrived with editor, adding a new listener and opening a browser
    this.anchors = this.elementRef.nativeElement.querySelectorAll('a');
    this.anchors.forEach(anchor => {
      anchor.addEventListener('click', this.handleAnchorClick);
    });
  }
  ngOnInit() {
    if (this.team && this.challenge?.otherAttendeeData) {
      this.otherTeam$ = this.teamService.getPublicTeam(this.campaignContainer?.campaign?.campaignId, this.challenge?.otherAttendeeData.playerId);
    }
    ;
  }
  typeChallenge(kind, type, other) {
    return kind === "team" ? other ? this.translateService.instant('challenges.challenge_model.name.teams') : this.translateService.instant('challenges.challenge_model.name.default-team') : this.translateService.instant((0,src_app_core_shared_campaigns_campaign_utils__WEBPACK_IMPORTED_MODULE_3__.getTypeStringChallenge)(type));
  }
  fillSurvey() {
    _capacitor_browser__WEBPACK_IMPORTED_MODULE_1__.Browser.addListener('browserFinished', () => {
      //send refresh challenge event
      this.refresherService.onRefresh(null);
    });
    _capacitor_browser__WEBPACK_IMPORTED_MODULE_1__.Browser.open({
      url: this.challenge.extUrl,
      windowName: '_system',
      presentationStyle: 'popover'
    });
  }
  getUnitChallenge(challenge) {
    return challenge?.unit?.toLowerCase().includes('km'.toLowerCase());
  }
  moreInfo() {
    var _this = this;
    return (0,_Users_smartcommunitylab_Desktop_newWork_playAndGo_playGo_node_modules_babel_runtime_helpers_esm_asyncToGenerator_js__WEBPACK_IMPORTED_MODULE_0__["default"])(function* () {
      const modal = yield _this.modalController.create({
        component: _detail_modal_detail_modal__WEBPACK_IMPORTED_MODULE_2__.DetailChallengenModalPage,
        componentProps: {
          campaignContainer: _this.campaignContainer,
          challenge: _this.challenge,
          team: _this.team
        },
        cssClass: 'challenge-info'
      });
      yield modal.present();
      const {
        data
      } = yield modal.onWillDismiss();
    })();
  }
  challengeEnded() {
    if (!this.isGroupCompetitivePerformance()) {
      {
        if (this.challenge?.status === 100 || this.challenge?.success === true || this.challenge?.otherAttendeeData?.status === 100) {
          return true;
        }
      }
    }
    return false;
  }
  challengeWon() {
    if (!this.isGroupCompetitivePerformance()) {
      if (this.challenge?.status === 100 || this.challenge.success === true) {
        return true;
      } else {
        return this.challenge.success;
      }
    }
  }
  isGroupCompetitivePerformance() {
    return this.challenge.type === 'groupCompetitivePerformance';
  }
  challDesc(desc, name) {
    //sub id with name
    const search = this.challenge?.otherAttendeeData?.playerId;
    const searchRegExp = new RegExp(search, 'g');
    const replaceWith = name;
    if (this.team && name && desc) return desc.replace(searchRegExp, replaceWith);
    return desc;
  }
  static #_ = _staticBlock = () => (this.ɵfac = function ChallengeCardComponent_Factory(__ngFactoryType__) {
    return new (__ngFactoryType__ || ChallengeCardComponent)(_angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵdirectiveInject"](src_app_core_shared_services_campaign_service__WEBPACK_IMPORTED_MODULE_6__.CampaignService), _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵdirectiveInject"](_angular_core__WEBPACK_IMPORTED_MODULE_5__.ElementRef), _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵdirectiveInject"](_ionic_angular__WEBPACK_IMPORTED_MODULE_7__.ModalController), _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵdirectiveInject"](_ngx_translate_core__WEBPACK_IMPORTED_MODULE_8__.TranslateService), _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵdirectiveInject"](src_app_core_shared_services_refresher_service__WEBPACK_IMPORTED_MODULE_9__.RefresherService), _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵdirectiveInject"](src_app_core_shared_services_team_service__WEBPACK_IMPORTED_MODULE_10__.TeamService));
  }, this.ɵcmp = /*@__PURE__*/_angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵdefineComponent"]({
    type: ChallengeCardComponent,
    selectors: [["app-challenge-card"]],
    inputs: {
      campaignContainer: "campaignContainer",
      challenge: "challenge",
      type: "type",
      team: "team"
    },
    standalone: false,
    decls: 40,
    vars: 28,
    consts: [["future", ""], ["challengeLost", ""], ["survey", ""], [1, "header", 3, "color"], [1, "ion-no-padding"], [1, "ion-align-items-center"], [1, "ion-text-center", "challenge-type"], ["size", "2"], [1, "icon-size-medium", 3, "name"], [3, "innerHTML"], ["size", "1"], ["name", "information-circle-outline", 1, "popup-icon", 3, "click"], [4, "ngIf"], [3, "status", "rowStatus", "type", "challengeType", "otherUser", "kind", "campaignContainer", "unitHasKm", 4, "ngIf"], [4, "ngIf", "ngIfElse"], ["size", "8"], [1, "challenge-date"], ["size", "4", 1, "ion-text-end", "point-col"], [3, "name"], [1, "ion-text-center", "status-chall"], [1, "won"], [1, "prize"], [1, "lost"], [3, "status", "rowStatus", "type", "challengeType", "otherUser", "kind", "campaignContainer", "unitHasKm"], [3, "status", "rowStatus", "otherStatus", "challengeType", "type", "campaignType", 4, "ngIf", "ngIfElse"], [3, "status", "rowStatus", "otherStatus", "challengeType", "type", "campaignType"], ["expand", "block", 3, "color", "click", 4, "ngIf"], ["expand", "block", 3, "click", "color"], [1, "ion-text-center", "challenge-date"]],
    template: function ChallengeCardComponent_Template(rf, ctx) {
      if (rf & 1) {
        const _r1 = _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵgetCurrentView"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵelementStart"](0, "ion-card")(1, "ion-card-header", 3)(2, "span");
        _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵtext"](3);
        _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵpipe"](4, "languageMap");
        _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵelementEnd"]()();
        _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵelementStart"](5, "ion-card-content", 4)(6, "ion-grid")(7, "ion-row", 5)(8, "ion-col", 6);
        _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵtext"](9);
        _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵelementEnd"]()();
        _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵelementStart"](10, "ion-row", 5)(11, "ion-col", 7);
        _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵelement"](12, "app-icon", 8);
        _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵelementStart"](13, "ion-col");
        _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵelement"](14, "p", 9);
        _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵpipe"](15, "languageMap");
        _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵpipe"](16, "async");
        _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵelementStart"](17, "ion-col", 10)(18, "ion-icon", 11);
        _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵlistener"]("click", function ChallengeCardComponent_Template_ion_icon_click_18_listener() {
          _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵrestoreView"](_r1);
          return _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵresetView"](ctx.moreInfo());
        });
        _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵelementEnd"]()()();
        _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵtemplate"](19, ChallengeCardComponent_ion_row_19_Template, 5, 2, "ion-row", 12);
        _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵelementStart"](20, "ion-row")(21, "ion-col");
        _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵtemplate"](22, ChallengeCardComponent_app_challenge_users_status_22_Template, 1, 8, "app-challenge-users-status", 13);
        _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵelementEnd"]()();
        _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵelementStart"](23, "ion-row")(24, "ion-col");
        _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵtemplate"](25, ChallengeCardComponent_div_25_Template, 4, 2, "div", 14)(26, ChallengeCardComponent_ng_template_26_Template, 4, 8, "ng-template", null, 0, _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵtemplateRefExtractor"]);
        _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵelementEnd"]()();
        _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵelementStart"](28, "ion-row")(29, "ion-col", 15)(30, "span", 16);
        _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵtext"](31);
        _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵpipe"](32, "localDate");
        _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵpipe"](33, "localDate");
        _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵpipe"](34, "translate");
        _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵelementEnd"]()();
        _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵelementStart"](35, "ion-col", 17)(36, "span", 16);
        _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵtext"](37);
        _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵelement"](38, "app-icon", 18);
        _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵelementEnd"]()()();
        _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵelement"](39, "p");
        _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵelementEnd"]()();
      }
      if (rf & 2) {
        let tmp_5_0;
        const future_r6 = _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵreference"](27);
        _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵadvance"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵproperty"]("color", ctx.challenge == null ? null : ctx.challenge.campaign == null ? null : ctx.challenge.campaign.type);
        _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵadvance"](2);
        _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵtextInterpolate"](_angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵpipeBind1"](4, 12, ctx.challenge == null ? null : ctx.challenge.campaign == null ? null : ctx.challenge.campaign.name));
        _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵadvance"](6);
        _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵtextInterpolate1"](" ", ctx.typeChallenge(ctx.challenge.kind, ctx.challenge.type, ctx.challenge.otherAttendeeData ? true : false), " ");
        _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵadvance"](3);
        _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵproperty"]("name", ctx.imgChallenge(ctx.challenge.type));
        _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵadvance"](2);
        _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵproperty"]("innerHTML", ctx.challDesc(_angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵpipeBind1"](15, 14, ctx.challenge == null ? null : ctx.challenge.challDesc), (tmp_5_0 = _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵpipeBind1"](16, 16, ctx.otherTeam$)) == null ? null : tmp_5_0.customData == null ? null : tmp_5_0.customData.name), _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵsanitizeHtml"]);
        _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵadvance"](5);
        _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵproperty"]("ngIf", ctx.challengeEnded());
        _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵadvance"](3);
        _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵproperty"]("ngIf", ctx.challenge.type !== "survey");
        _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵadvance"](3);
        _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵproperty"]("ngIf", ctx.type === "active")("ngIfElse", future_r6);
        _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵadvance"](6);
        _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵtextInterpolate"](_angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵpipeBind2"](34, 22, "date.from_to", _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵpureFunction2"](25, _c0, _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵpipeBind1"](32, 18, ctx.challenge.startDate), _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵpipeBind1"](33, 20, ctx.challenge.endDate))));
        _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵadvance"](6);
        _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵtextInterpolate"](ctx.challenge.bonus);
        _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵadvance"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵproperty"]("name", ctx.campaignService.getCampaignScoreIcon(ctx.challenge.campaign));
      }
    },
    dependencies: [_angular_common__WEBPACK_IMPORTED_MODULE_11__.NgIf, _ionic_angular__WEBPACK_IMPORTED_MODULE_7__.IonButton, _ionic_angular__WEBPACK_IMPORTED_MODULE_7__.IonCard, _ionic_angular__WEBPACK_IMPORTED_MODULE_7__.IonCardContent, _ionic_angular__WEBPACK_IMPORTED_MODULE_7__.IonCardHeader, _ionic_angular__WEBPACK_IMPORTED_MODULE_7__.IonCol, _ionic_angular__WEBPACK_IMPORTED_MODULE_7__.IonGrid, _ionic_angular__WEBPACK_IMPORTED_MODULE_7__.IonIcon, _ionic_angular__WEBPACK_IMPORTED_MODULE_7__.IonRow, _core_shared_ui_icon_icon_component__WEBPACK_IMPORTED_MODULE_12__.IconComponent, _core_shared_campaigns_challenge_users_status_challenge_users_status_component__WEBPACK_IMPORTED_MODULE_13__.ChallengeUsersStatusComponent, _core_shared_campaigns_challenge_bar_status_challenge_bar_status_component__WEBPACK_IMPORTED_MODULE_14__.ChallengeBarStatusComponent, _angular_common__WEBPACK_IMPORTED_MODULE_11__.AsyncPipe, _angular_common__WEBPACK_IMPORTED_MODULE_11__.UpperCasePipe, _ngx_translate_core__WEBPACK_IMPORTED_MODULE_8__.TranslatePipe, _core_shared_pipes_localDate_pipe__WEBPACK_IMPORTED_MODULE_15__.LocalDatePipe, _core_shared_pipes_languageMap_pipe__WEBPACK_IMPORTED_MODULE_16__.LanguageMapPipe],
    styles: ["ion-card-title[_ngcontent-%COMP%] {\n  font-size: small;\n}\n\n.header[_ngcontent-%COMP%] {\n  text-align: start;\n  padding: 4px;\n  font-style: italic;\n  font-weight: 300;\n  font-size: 13px;\n}\n.header[_ngcontent-%COMP%]   span[_ngcontent-%COMP%] {\n  margin-left: 18px;\n}\n\nion-card-content[_ngcontent-%COMP%] {\n  padding: 0px 4px;\n}\nion-card-content[_ngcontent-%COMP%]   .challenge-type[_ngcontent-%COMP%] {\n  font-style: italic;\n  font-weight: 200;\n  font-size: 16px;\n}\nion-card-content[_ngcontent-%COMP%]   .challenge-date[_ngcontent-%COMP%] {\n  font-style: italic;\n  font-weight: 300;\n  font-size: 13px;\n}\nion-card-content[_ngcontent-%COMP%]   .point-col[_ngcontent-%COMP%] {\n  line-height: 15px;\n  display: flex;\n  justify-content: flex-end;\n  align-items: center;\n}\nion-card-content[_ngcontent-%COMP%]   .popup-icon[_ngcontent-%COMP%] {\n  font-size: 30px;\n}\nion-card-content[_ngcontent-%COMP%]   .status-chall[_ngcontent-%COMP%] {\n  font-style: normal;\n  font-weight: 600;\n  font-size: 18px;\n  line-height: 21px;\n}\nion-card-content[_ngcontent-%COMP%]   .status-chall[_ngcontent-%COMP%]   .won[_ngcontent-%COMP%] {\n  color: var(--ion-color-start);\n  font-size: 18px;\n}\nion-card-content[_ngcontent-%COMP%]   .status-chall[_ngcontent-%COMP%]   .prize[_ngcontent-%COMP%] {\n  font-size: 13px;\n  font-style: italic;\n  font-weight: 300;\n  line-height: 15px;\n  letter-spacing: 0px;\n  text-align: center;\n}\nion-card-content[_ngcontent-%COMP%]   .status-chall[_ngcontent-%COMP%]   .lost[_ngcontent-%COMP%] {\n  color: #c61010;\n  font-size: 18px;\n}\n/*# sourceMappingURL=data:application/json;charset=utf-8;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbIndlYnBhY2s6Ly8uL3NyYy9hcHAvcGFnZXMvY2hhbGxlbmdlcy9jaGFsbGVuZ2UtY2FyZC9jaGFsbGVuZ2UtY2FyZC5jb21wb25lbnQuc2NzcyJdLCJuYW1lcyI6W10sIm1hcHBpbmdzIjoiQUFBQTtFQUNFLGdCQUFBO0FBQ0Y7O0FBQ0E7RUFDRSxpQkFBQTtFQUNBLFlBQUE7RUFDQSxrQkFBQTtFQUNBLGdCQUFBO0VBQ0EsZUFBQTtBQUVGO0FBREU7RUFDRSxpQkFBQTtBQUdKOztBQUFBO0VBQ0UsZ0JBQUE7QUFHRjtBQUZFO0VBQ0Usa0JBQUE7RUFDQSxnQkFBQTtFQUNBLGVBQUE7QUFJSjtBQUZFO0VBQ0Usa0JBQUE7RUFDQSxnQkFBQTtFQUNBLGVBQUE7QUFJSjtBQUZFO0VBQ0UsaUJBQUE7RUFDQSxhQUFBO0VBQ0EseUJBQUE7RUFDQSxtQkFBQTtBQUlKO0FBRkU7RUFDRSxlQUFBO0FBSUo7QUFGRTtFQUNFLGtCQUFBO0VBQ0EsZ0JBQUE7RUFDQSxlQUFBO0VBQ0EsaUJBQUE7QUFJSjtBQUhJO0VBQ0UsNkJBQUE7RUFDQSxlQUFBO0FBS047QUFISTtFQUNFLGVBQUE7RUFDQSxrQkFBQTtFQUNBLGdCQUFBO0VBQ0EsaUJBQUE7RUFDQSxtQkFBQTtFQUNBLGtCQUFBO0FBS047QUFISTtFQUNFLGNBQUE7RUFDQSxlQUFBO0FBS04iLCJzb3VyY2VzQ29udGVudCI6WyJpb24tY2FyZC10aXRsZSB7XG4gIGZvbnQtc2l6ZTogc21hbGw7XG59XG4uaGVhZGVyIHtcbiAgdGV4dC1hbGlnbjogc3RhcnQ7XG4gIHBhZGRpbmc6IDRweDtcbiAgZm9udC1zdHlsZTogaXRhbGljO1xuICBmb250LXdlaWdodDogMzAwO1xuICBmb250LXNpemU6IDEzcHg7XG4gIHNwYW4ge1xuICAgIG1hcmdpbi1sZWZ0OiAxOHB4O1xuICB9XG59XG5pb24tY2FyZC1jb250ZW50IHtcbiAgcGFkZGluZzogMHB4IDRweDtcbiAgLmNoYWxsZW5nZS10eXBlIHtcbiAgICBmb250LXN0eWxlOiBpdGFsaWM7XG4gICAgZm9udC13ZWlnaHQ6IDIwMDtcbiAgICBmb250LXNpemU6IDE2cHg7XG4gIH1cbiAgLmNoYWxsZW5nZS1kYXRlIHtcbiAgICBmb250LXN0eWxlOiBpdGFsaWM7XG4gICAgZm9udC13ZWlnaHQ6IDMwMDtcbiAgICBmb250LXNpemU6IDEzcHg7XG4gIH1cbiAgLnBvaW50LWNvbCB7XG4gICAgbGluZS1oZWlnaHQ6IDE1cHg7XG4gICAgZGlzcGxheTogZmxleDtcbiAgICBqdXN0aWZ5LWNvbnRlbnQ6IGZsZXgtZW5kO1xuICAgIGFsaWduLWl0ZW1zOiBjZW50ZXI7XG4gIH1cbiAgLnBvcHVwLWljb24ge1xuICAgIGZvbnQtc2l6ZTogMzBweDtcbiAgfVxuICAuc3RhdHVzLWNoYWxsIHtcbiAgICBmb250LXN0eWxlOiBub3JtYWw7XG4gICAgZm9udC13ZWlnaHQ6IDYwMDtcbiAgICBmb250LXNpemU6IDE4cHg7XG4gICAgbGluZS1oZWlnaHQ6IDIxcHg7XG4gICAgLndvbiB7XG4gICAgICBjb2xvcjogdmFyKC0taW9uLWNvbG9yLXN0YXJ0KTtcbiAgICAgIGZvbnQtc2l6ZTogMThweDtcbiAgICB9XG4gICAgLnByaXplIHtcbiAgICAgIGZvbnQtc2l6ZTogMTNweDtcbiAgICAgIGZvbnQtc3R5bGU6IGl0YWxpYztcbiAgICAgIGZvbnQtd2VpZ2h0OiAzMDA7XG4gICAgICBsaW5lLWhlaWdodDogMTVweDtcbiAgICAgIGxldHRlci1zcGFjaW5nOiAwcHg7XG4gICAgICB0ZXh0LWFsaWduOiBjZW50ZXI7XG4gICAgfVxuICAgIC5sb3N0IHtcbiAgICAgIGNvbG9yOiAjYzYxMDEwO1xuICAgICAgZm9udC1zaXplOiAxOHB4O1xuICAgIH1cbiAgfVxufVxuIl0sInNvdXJjZVJvb3QiOiIifQ== */"]
  }));
}
_staticBlock();

/***/ }),

/***/ 72813:
/*!**********************************************************************************************************************!*\
  !*** ./src/app/pages/challenges/challenges-proposed-card/info-challenge-single-modal/info-challenge-single.modal.ts ***!
  \**********************************************************************************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   InfoChallengeSingleModalPage: () => (/* binding */ InfoChallengeSingleModalPage)
/* harmony export */ });
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! @angular/core */ 12481);
/* harmony import */ var _ionic_angular__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @ionic/angular */ 21507);
/* harmony import */ var _ngx_translate_core__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @ngx-translate/core */ 48503);
var _staticBlock;



const _c0 = ["class", "modal"];
class InfoChallengeSingleModalPage {
  constructor(modalController) {
    this.modalController = modalController;
  }
  ngOnInit() {}
  close() {
    this.modalController.dismiss(false);
  }
  static #_ = _staticBlock = () => (this.ɵfac = function InfoChallengeSingleModalPage_Factory(__ngFactoryType__) {
    return new (__ngFactoryType__ || InfoChallengeSingleModalPage)(_angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵdirectiveInject"](_ionic_angular__WEBPACK_IMPORTED_MODULE_1__.ModalController));
  }, this.ɵcmp = /*@__PURE__*/_angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵdefineComponent"]({
    type: InfoChallengeSingleModalPage,
    selectors: [["app-info-challenge", 8, "modal"]],
    standalone: false,
    attrs: _c0,
    decls: 15,
    vars: 9,
    consts: [["color", "playgo"], ["slot", "end"], [3, "click"], ["name", "close-circle-outline"], ["color", "playgo", 1, "ion-padding"], [3, "innerHTML"], ["color", "light", "expand", "block", 3, "click"]],
    template: function InfoChallengeSingleModalPage_Template(rf, ctx) {
      if (rf & 1) {
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](0, "ion-header")(1, "ion-toolbar", 0)(2, "ion-title");
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵtext"](3);
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵpipe"](4, "translate");
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](5, "ion-buttons", 1)(6, "ion-button", 2);
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵlistener"]("click", function InfoChallengeSingleModalPage_Template_ion_button_click_6_listener() {
          return ctx.close();
        });
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelement"](7, "ion-icon", 3);
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]()()()();
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](8, "ion-content", 4);
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelement"](9, "div", 5);
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵpipe"](10, "translate");
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](11, "ion-footer", 0)(12, "ion-button", 6);
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵlistener"]("click", function InfoChallengeSingleModalPage_Template_ion_button_click_12_listener() {
          return ctx.close();
        });
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵtext"](13);
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵpipe"](14, "translate");
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]()();
      }
      if (rf & 2) {
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵadvance"](3);
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵtextInterpolate"](_angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵpipeBind1"](4, 3, "challenges.info.title"));
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵadvance"](6);
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵproperty"]("innerHTML", _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵpipeBind1"](10, 5, "challenges.info.body"), _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵsanitizeHtml"]);
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵadvance"](4);
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵtextInterpolate"](_angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵpipeBind1"](14, 7, "challenges.info.close"));
      }
    },
    dependencies: [_ionic_angular__WEBPACK_IMPORTED_MODULE_1__.IonButton, _ionic_angular__WEBPACK_IMPORTED_MODULE_1__.IonButtons, _ionic_angular__WEBPACK_IMPORTED_MODULE_1__.IonContent, _ionic_angular__WEBPACK_IMPORTED_MODULE_1__.IonFooter, _ionic_angular__WEBPACK_IMPORTED_MODULE_1__.IonHeader, _ionic_angular__WEBPACK_IMPORTED_MODULE_1__.IonIcon, _ionic_angular__WEBPACK_IMPORTED_MODULE_1__.IonTitle, _ionic_angular__WEBPACK_IMPORTED_MODULE_1__.IonToolbar, _ngx_translate_core__WEBPACK_IMPORTED_MODULE_2__.TranslatePipe],
    styles: [".external[_ngcontent-%COMP%]   .title[_ngcontent-%COMP%] {\n  text-align: center;\n  font-weight: bold;\n  padding: 8px;\n}\n.external[_ngcontent-%COMP%]   .internal[_ngcontent-%COMP%]   .body[_ngcontent-%COMP%] {\n  text-align: justify;\n  padding: 8px;\n}\n/*# sourceMappingURL=data:application/json;charset=utf-8;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbIndlYnBhY2s6Ly8uL3NyYy9hcHAvcGFnZXMvY2hhbGxlbmdlcy9jaGFsbGVuZ2VzLXByb3Bvc2VkLWNhcmQvaW5mby1jaGFsbGVuZ2Utc2luZ2xlLW1vZGFsL2luZm8tY2hhbGxlbmdlLXNpbmdsZS5tb2RhbC5zY3NzIl0sIm5hbWVzIjpbXSwibWFwcGluZ3MiOiJBQUNFO0VBQ0Usa0JBQUE7RUFDQSxpQkFBQTtFQUNBLFlBQUE7QUFBSjtBQUdJO0VBQ0UsbUJBQUE7RUFDQSxZQUFBO0FBRE4iLCJzb3VyY2VzQ29udGVudCI6WyIuZXh0ZXJuYWwge1xuICAudGl0bGUge1xuICAgIHRleHQtYWxpZ246IGNlbnRlcjtcbiAgICBmb250LXdlaWdodDogYm9sZDtcbiAgICBwYWRkaW5nOiA4cHg7XG4gIH1cbiAgLmludGVybmFsIHtcbiAgICAuYm9keSB7XG4gICAgICB0ZXh0LWFsaWduOiBqdXN0aWZ5O1xuICAgICAgcGFkZGluZzogOHB4O1xuICAgIH1cbiAgfVxufVxuIl0sInNvdXJjZVJvb3QiOiIifQ== */"]
  }));
}
_staticBlock();

/***/ }),

/***/ 73759:
/*!********************************************************************************************************************!*\
  !*** ./src/app/pages/challenges/challenges-proposed-card/info-challenge-group-modal/info-challenge-group.modal.ts ***!
  \********************************************************************************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   InfoChallengeGroupModalPage: () => (/* binding */ InfoChallengeGroupModalPage)
/* harmony export */ });
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! @angular/core */ 12481);
/* harmony import */ var _ionic_angular__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @ionic/angular */ 21507);
/* harmony import */ var _ngx_translate_core__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @ngx-translate/core */ 48503);
var _staticBlock;



const _c0 = ["class", "modal"];
class InfoChallengeGroupModalPage {
  constructor(modalController) {
    this.modalController = modalController;
  }
  ngOnInit() {}
  close() {
    this.modalController.dismiss(false);
  }
  static #_ = _staticBlock = () => (this.ɵfac = function InfoChallengeGroupModalPage_Factory(__ngFactoryType__) {
    return new (__ngFactoryType__ || InfoChallengeGroupModalPage)(_angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵdirectiveInject"](_ionic_angular__WEBPACK_IMPORTED_MODULE_1__.ModalController));
  }, this.ɵcmp = /*@__PURE__*/_angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵdefineComponent"]({
    type: InfoChallengeGroupModalPage,
    selectors: [["app-info-challenge-group", 8, "modal"]],
    standalone: false,
    attrs: _c0,
    decls: 15,
    vars: 9,
    consts: [["color", "playgo"], ["slot", "end"], [3, "click"], ["name", "close-circle-outline"], ["color", "playgo", 1, "ion-padding"], [3, "innerHTML"], ["color", "light", "expand", "block", 3, "click"]],
    template: function InfoChallengeGroupModalPage_Template(rf, ctx) {
      if (rf & 1) {
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](0, "ion-header")(1, "ion-toolbar", 0)(2, "ion-title");
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵtext"](3);
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵpipe"](4, "translate");
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](5, "ion-buttons", 1)(6, "ion-button", 2);
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵlistener"]("click", function InfoChallengeGroupModalPage_Template_ion_button_click_6_listener() {
          return ctx.close();
        });
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelement"](7, "ion-icon", 3);
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]()()()();
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](8, "ion-content", 4);
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelement"](9, "div", 5);
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵpipe"](10, "translate");
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](11, "ion-footer", 0)(12, "ion-button", 6);
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵlistener"]("click", function InfoChallengeGroupModalPage_Template_ion_button_click_12_listener() {
          return ctx.close();
        });
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵtext"](13);
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵpipe"](14, "translate");
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]()();
      }
      if (rf & 2) {
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵadvance"](3);
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵtextInterpolate"](_angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵpipeBind1"](4, 3, "challenges.infogroup.title"));
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵadvance"](6);
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵproperty"]("innerHTML", _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵpipeBind1"](10, 5, "challenges.infogroup.body"), _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵsanitizeHtml"]);
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵadvance"](4);
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵtextInterpolate"](_angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵpipeBind1"](14, 7, "challenges.info.close"));
      }
    },
    dependencies: [_ionic_angular__WEBPACK_IMPORTED_MODULE_1__.IonButton, _ionic_angular__WEBPACK_IMPORTED_MODULE_1__.IonButtons, _ionic_angular__WEBPACK_IMPORTED_MODULE_1__.IonContent, _ionic_angular__WEBPACK_IMPORTED_MODULE_1__.IonFooter, _ionic_angular__WEBPACK_IMPORTED_MODULE_1__.IonHeader, _ionic_angular__WEBPACK_IMPORTED_MODULE_1__.IonIcon, _ionic_angular__WEBPACK_IMPORTED_MODULE_1__.IonTitle, _ionic_angular__WEBPACK_IMPORTED_MODULE_1__.IonToolbar, _ngx_translate_core__WEBPACK_IMPORTED_MODULE_2__.TranslatePipe],
    styles: [".external[_ngcontent-%COMP%]   .title[_ngcontent-%COMP%] {\n  text-align: center;\n  font-weight: bold;\n  padding: 8px;\n}\n.external[_ngcontent-%COMP%]   .internal[_ngcontent-%COMP%]   .body[_ngcontent-%COMP%] {\n  text-align: justify;\n  padding: 8px;\n}\n/*# sourceMappingURL=data:application/json;charset=utf-8;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbIndlYnBhY2s6Ly8uL3NyYy9hcHAvcGFnZXMvY2hhbGxlbmdlcy9jaGFsbGVuZ2VzLXByb3Bvc2VkLWNhcmQvaW5mby1jaGFsbGVuZ2UtZ3JvdXAtbW9kYWwvaW5mby1jaGFsbGVuZ2UtZ3JvdXAubW9kYWwuc2NzcyJdLCJuYW1lcyI6W10sIm1hcHBpbmdzIjoiQUFDRTtFQUNFLGtCQUFBO0VBQ0EsaUJBQUE7RUFDQSxZQUFBO0FBQUo7QUFHSTtFQUNFLG1CQUFBO0VBQ0EsWUFBQTtBQUROIiwic291cmNlc0NvbnRlbnQiOlsiLmV4dGVybmFsIHtcbiAgLnRpdGxlIHtcbiAgICB0ZXh0LWFsaWduOiBjZW50ZXI7XG4gICAgZm9udC13ZWlnaHQ6IGJvbGQ7XG4gICAgcGFkZGluZzogOHB4O1xuICB9XG4gIC5pbnRlcm5hbCB7XG4gICAgLmJvZHkge1xuICAgICAgdGV4dC1hbGlnbjoganVzdGlmeTtcbiAgICAgIHBhZGRpbmc6IDhweDtcbiAgICB9XG4gIH1cbn1cbiJdLCJzb3VyY2VSb290IjoiIn0= */"]
  }));
}
_staticBlock();

/***/ }),

/***/ 77382:
/*!***************************************************************************************!*\
  !*** ./src/app/pages/challenges/challenge-container/challenge-container.component.ts ***!
  \***************************************************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   ChallengeContainerComponent: () => (/* binding */ ChallengeContainerComponent)
/* harmony export */ });
/* harmony import */ var src_app_core_shared_utils__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! src/app/core/shared/utils */ 7497);
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @angular/core */ 12481);
/* harmony import */ var src_app_core_shared_services_campaign_service__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! src/app/core/shared/services/campaign.service */ 76658);
var _staticBlock;



function ChallengeContainerComponent_ng_container_0_app_challenge_card_1_Template(rf, ctx) {
  if (rf & 1) {
    _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵelement"](0, "app-challenge-card", 3);
  }
  if (rf & 2) {
    const challenge_r1 = _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵnextContext"]().$implicit;
    const ctx_r1 = _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵnextContext"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵproperty"]("team", ctx_r1.team)("challenge", challenge_r1)("campaignContainer", ctx_r1.campaign)("type", ctx_r1.type);
  }
}
function ChallengeContainerComponent_ng_container_0_Template(rf, ctx) {
  if (rf & 1) {
    _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵelementContainerStart"](0);
    _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵtemplate"](1, ChallengeContainerComponent_ng_container_0_app_challenge_card_1_Template, 1, 4, "app-challenge-card", 2);
    _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵelementContainerEnd"]();
  }
  if (rf & 2) {
    const challenge_r1 = ctx.$implicit;
    _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵadvance"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵproperty"]("ngIf", challenge_r1.challengeType !== "PROPOSED");
  }
}
class ChallengeContainerComponent {
  constructor(campaignService) {
    this.campaignService = campaignService;
    this.team = false;
    this.challengeTracking = (0,src_app_core_shared_utils__WEBPACK_IMPORTED_MODULE_0__.trackByProperty)('challId');
  }
  ngOnInit() {}
  ngOnChanges() {
    this.challengeProposed = this.challenges?.filter(challenge => challenge.challengeType === 'PROPOSED');
    this.challenges?.map(chall => {
      if (chall.challengeType === 'FUTURE' && chall.otherAttendeeData) {
        this.canInvite = false;
      }
    });
    // console.log(this.challengeProposed);
  }
  static #_ = _staticBlock = () => (this.ɵfac = function ChallengeContainerComponent_Factory(__ngFactoryType__) {
    return new (__ngFactoryType__ || ChallengeContainerComponent)(_angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵdirectiveInject"](src_app_core_shared_services_campaign_service__WEBPACK_IMPORTED_MODULE_2__.CampaignService));
  }, this.ɵcmp = /*@__PURE__*/_angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵdefineComponent"]({
    type: ChallengeContainerComponent,
    selectors: [["app-challenge-container"]],
    inputs: {
      campaign: "campaign",
      challenges: "challenges",
      type: "type",
      canInvite: "canInvite",
      team: "team"
    },
    standalone: false,
    features: [_angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵNgOnChangesFeature"]],
    decls: 2,
    vars: 6,
    consts: [[4, "ngFor", "ngForOf", "ngForTrackBy"], [3, "challenges", "type", "campaign", "canInvite"], [3, "team", "challenge", "campaignContainer", "type", 4, "ngIf"], [3, "team", "challenge", "campaignContainer", "type"]],
    template: function ChallengeContainerComponent_Template(rf, ctx) {
      if (rf & 1) {
        _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵtemplate"](0, ChallengeContainerComponent_ng_container_0_Template, 2, 1, "ng-container", 0);
        _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵelement"](1, "app-challenges-proposed-card", 1);
      }
      if (rf & 2) {
        _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵproperty"]("ngForOf", ctx.challenges)("ngForTrackBy", ctx.challengeTracking);
        _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵadvance"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵproperty"]("challenges", ctx.challengeProposed)("type", ctx.type)("campaign", ctx.campaign)("canInvite", ctx.canInvite);
      }
    },
    styles: ["ion-card-title[_ngcontent-%COMP%] {\n  font-size: small;\n}\n/*# sourceMappingURL=data:application/json;charset=utf-8;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbIndlYnBhY2s6Ly8uL3NyYy9hcHAvcGFnZXMvY2hhbGxlbmdlcy9jaGFsbGVuZ2UtY29udGFpbmVyL2NoYWxsZW5nZS1jb250YWluZXIuY29tcG9uZW50LnNjc3MiXSwibmFtZXMiOltdLCJtYXBwaW5ncyI6IkFBQUE7RUFDRSxnQkFBQTtBQUNGIiwic291cmNlc0NvbnRlbnQiOlsiaW9uLWNhcmQtdGl0bGUge1xuICBmb250LXNpemU6IHNtYWxsO1xufVxuIl0sInNvdXJjZVJvb3QiOiIifQ== */"]
  }));
}
_staticBlock();

/***/ }),

/***/ 78350:
/*!***************************************************************************************************!*\
  !*** ./src/app/pages/challenges/single-challenge-proposed/single-challenge-proposed.component.ts ***!
  \***************************************************************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   SingleChallengeProposedComponent: () => (/* binding */ SingleChallengeProposedComponent)
/* harmony export */ });
/* harmony import */ var _Users_smartcommunitylab_Desktop_newWork_playAndGo_playGo_node_modules_babel_runtime_helpers_esm_asyncToGenerator_js__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./node_modules/@babel/runtime/helpers/esm/asyncToGenerator.js */ 89204);
/* harmony import */ var _single_proposal_accepted_single_proposal_accepted_modal__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ./single-proposal-accepted/single-proposal-accepted.modal */ 52782);
/* harmony import */ var _single_proposal_single_proposal_modal__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! ./single-proposal/single-proposal.modal */ 12298);
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @angular/core */ 12481);
/* harmony import */ var _ionic_angular__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! @ionic/angular */ 21507);
/* harmony import */ var _core_shared_ui_icon_icon_component__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! ../../../core/shared/ui/icon/icon.component */ 59621);
/* harmony import */ var _ngx_translate_core__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! @ngx-translate/core */ 48503);
/* harmony import */ var _core_shared_pipes_languageMap_pipe__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(/*! ../../../core/shared/pipes/languageMap.pipe */ 69618);

var _staticBlock;







class SingleChallengeProposedComponent {
  constructor(modalController) {
    this.modalController = modalController;
  }
  ngOnInit() {}
  openSelectionPopup() {
    var _this = this;
    return (0,_Users_smartcommunitylab_Desktop_newWork_playAndGo_playGo_node_modules_babel_runtime_helpers_esm_asyncToGenerator_js__WEBPACK_IMPORTED_MODULE_0__["default"])(function* () {
      let modal = yield _this.modalController.create({
        component: _single_proposal_single_proposal_modal__WEBPACK_IMPORTED_MODULE_2__.SingleProposalModalPage,
        cssClass: 'modal-challenge',
        componentProps: {
          challenge: _this.challenge,
          campaign: _this.campaign
        },
        canDismiss: true
      });
      yield modal.present();
      const {
        data
      } = yield modal.onWillDismiss();
      if (data) {
        modal = yield _this.modalController.create({
          component: _single_proposal_accepted_single_proposal_accepted_modal__WEBPACK_IMPORTED_MODULE_1__.SingleProposalAcceptedModalPage,
          cssClass: 'modal-challenge',
          componentProps: {
            challenge: _this.challenge,
            campaign: _this.campaign
          }
        });
        yield modal.present();
        yield modal.onWillDismiss();
      }
    })();
  }
  static #_ = _staticBlock = () => (this.ɵfac = function SingleChallengeProposedComponent_Factory(__ngFactoryType__) {
    return new (__ngFactoryType__ || SingleChallengeProposedComponent)(_angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵdirectiveInject"](_ionic_angular__WEBPACK_IMPORTED_MODULE_4__.ModalController));
  }, this.ɵcmp = /*@__PURE__*/_angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵdefineComponent"]({
    type: SingleChallengeProposedComponent,
    selectors: [["app-single-challenge-proposed"]],
    inputs: {
      challenge: "challenge",
      campaign: "campaign"
    },
    standalone: false,
    decls: 14,
    vars: 7,
    consts: [[3, "click"], [1, "header", 3, "color"], [1, "content"], [1, "ion-align-items-center"], ["size", "2"], ["name", "default", 1, "icon-size-medium"], [1, "flex-center"]],
    template: function SingleChallengeProposedComponent_Template(rf, ctx) {
      if (rf & 1) {
        _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵelementStart"](0, "ion-card", 0);
        _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵlistener"]("click", function SingleChallengeProposedComponent_Template_ion_card_click_0_listener() {
          return ctx.openSelectionPopup();
        });
        _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵelementStart"](1, "ion-card-header", 1)(2, "span");
        _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵtext"](3);
        _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵpipe"](4, "translate");
        _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵelementEnd"]()();
        _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵelementStart"](5, "ion-card-content", 2)(6, "ion-grid")(7, "ion-row", 3)(8, "ion-col", 4);
        _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵelement"](9, "app-icon", 5);
        _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵelementStart"](10, "ion-col", 6)(11, "span");
        _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵtext"](12);
        _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵpipe"](13, "languageMap");
        _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵelementEnd"]()()()()()();
      }
      if (rf & 2) {
        _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵadvance"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵproperty"]("color", ctx.campaign.campaign.type);
        _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵadvance"](2);
        _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵtextInterpolate1"](" ", _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵpipeBind1"](4, 3, "challenges.singleproposal"), " ");
        _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵadvance"](9);
        _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵtextInterpolate"](_angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵpipeBind1"](13, 5, ctx.challenge.challDesc));
      }
    },
    dependencies: [_ionic_angular__WEBPACK_IMPORTED_MODULE_4__.IonCard, _ionic_angular__WEBPACK_IMPORTED_MODULE_4__.IonCardContent, _ionic_angular__WEBPACK_IMPORTED_MODULE_4__.IonCardHeader, _ionic_angular__WEBPACK_IMPORTED_MODULE_4__.IonCol, _ionic_angular__WEBPACK_IMPORTED_MODULE_4__.IonGrid, _ionic_angular__WEBPACK_IMPORTED_MODULE_4__.IonRow, _core_shared_ui_icon_icon_component__WEBPACK_IMPORTED_MODULE_5__.IconComponent, _ngx_translate_core__WEBPACK_IMPORTED_MODULE_6__.TranslatePipe, _core_shared_pipes_languageMap_pipe__WEBPACK_IMPORTED_MODULE_7__.LanguageMapPipe],
    styles: [".header[_ngcontent-%COMP%] {\n  padding: 2px;\n  text-align: right;\n  font-style: italic;\n}\n.header[_ngcontent-%COMP%]   span[_ngcontent-%COMP%] {\n  margin: 4px;\n}\n\nspan[_ngcontent-%COMP%] {\n  font-style: normal;\n  font-weight: 300;\n  font-size: 13px;\n}\n/*# sourceMappingURL=data:application/json;charset=utf-8;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbIndlYnBhY2s6Ly8uL3NyYy9hcHAvcGFnZXMvY2hhbGxlbmdlcy9zaW5nbGUtY2hhbGxlbmdlLXByb3Bvc2VkL3NpbmdsZS1jaGFsbGVuZ2UtcHJvcG9zZWQuY29tcG9uZW50LnNjc3MiXSwibmFtZXMiOltdLCJtYXBwaW5ncyI6IkFBQUE7RUFDRSxZQUFBO0VBQ0EsaUJBQUE7RUFDQSxrQkFBQTtBQUNGO0FBQUU7RUFDRSxXQUFBO0FBRUo7O0FBQ0E7RUFDRSxrQkFBQTtFQUNBLGdCQUFBO0VBQ0EsZUFBQTtBQUVGIiwic291cmNlc0NvbnRlbnQiOlsiLmhlYWRlciB7XG4gIHBhZGRpbmc6IDJweDtcbiAgdGV4dC1hbGlnbjogcmlnaHQ7XG4gIGZvbnQtc3R5bGU6IGl0YWxpYztcbiAgc3BhbiB7XG4gICAgbWFyZ2luOiA0cHg7XG4gIH1cbn1cbnNwYW4ge1xuICBmb250LXN0eWxlOiBub3JtYWw7XG4gIGZvbnQtd2VpZ2h0OiAzMDA7XG4gIGZvbnQtc2l6ZTogMTNweDtcbn1cbiJdLCJzb3VyY2VSb290IjoiIn0= */"]
  }));
}
_staticBlock();

/***/ }),

/***/ 86574:
/*!***************************************************************************************************************!*\
  !*** ./src/app/pages/challenges/couple-challenge-proposed/invitation-challenge/invitation-challenge.modal.ts ***!
  \***************************************************************************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   InvitationlModalPage: () => (/* binding */ InvitationlModalPage)
/* harmony export */ });
/* harmony import */ var _Users_smartcommunitylab_Desktop_newWork_playAndGo_playGo_node_modules_babel_runtime_helpers_esm_asyncToGenerator_js__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./node_modules/@babel/runtime/helpers/esm/asyncToGenerator.js */ 89204);
/* harmony import */ var rxjs__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! rxjs */ 70271);
/* harmony import */ var src_app_core_shared_campaigns_campaign_utils__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! src/app/core/shared/campaigns/campaign.utils */ 14691);
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @angular/core */ 34205);
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! @angular/core */ 12481);
/* harmony import */ var _ionic_angular__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! @ionic/angular */ 21507);
/* harmony import */ var src_app_core_shared_services_user_service__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! src/app/core/shared/services/user.service */ 89815);
/* harmony import */ var src_app_core_shared_services_challenge_service__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(/*! src/app/core/shared/services/challenge.service */ 16561);
/* harmony import */ var _ngx_translate_core__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(/*! @ngx-translate/core */ 48503);
/* harmony import */ var src_app_core_shared_services_error_service__WEBPACK_IMPORTED_MODULE_9__ = __webpack_require__(/*! src/app/core/shared/services/error.service */ 46078);
/* harmony import */ var _angular_common__WEBPACK_IMPORTED_MODULE_10__ = __webpack_require__(/*! @angular/common */ 93683);
/* harmony import */ var _core_shared_ui_icon_icon_component__WEBPACK_IMPORTED_MODULE_11__ = __webpack_require__(/*! ../../../../core/shared/ui/icon/icon.component */ 59621);
/* harmony import */ var _core_shared_pipes_languageMap_pipe__WEBPACK_IMPORTED_MODULE_12__ = __webpack_require__(/*! ../../../../core/shared/pipes/languageMap.pipe */ 69618);

var _staticBlock;











function InvitationlModalPage_ion_row_26_Template(rf, ctx) {
  if (rf & 1) {
    const _r2 = _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵgetCurrentView"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵelementStart"](0, "ion-row")(1, "ion-col", 15)(2, "ion-button", 16);
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵlistener"]("click", function InvitationlModalPage_ion_row_26_Template_ion_button_click_2_listener() {
      _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵrestoreView"](_r2);
      const ctx_r2 = _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵnextContext"]();
      return _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵresetView"](ctx_r2.activate());
    });
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵtext"](3);
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵpipe"](4, "translate");
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵelementEnd"]()();
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵelementStart"](5, "ion-col", 15)(6, "ion-button", 17);
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵlistener"]("click", function InvitationlModalPage_ion_row_26_Template_ion_button_click_6_listener() {
      _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵrestoreView"](_r2);
      const ctx_r2 = _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵnextContext"]();
      return _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵresetView"](ctx_r2.reject());
    });
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵtext"](7);
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵpipe"](8, "translate");
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵelementEnd"]()()();
  }
  if (rf & 2) {
    const ctx_r2 = _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵnextContext"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵadvance"](2);
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵproperty"]("color", ctx_r2.campaign == null ? null : ctx_r2.campaign.campaign == null ? null : ctx_r2.campaign.campaign.type);
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵadvance"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵtextInterpolate1"](" ", _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵpipeBind1"](4, 3, "challenges.activate"), " ");
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵadvance"](4);
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵtextInterpolate1"](" ", _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵpipeBind1"](8, 5, "challenges.reject"), " ");
  }
}
function InvitationlModalPage_ng_template_28_Template(rf, ctx) {
  if (rf & 1) {
    const _r4 = _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵgetCurrentView"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵelementStart"](0, "ion-row")(1, "ion-col", 15)(2, "ion-button", 16);
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵlistener"]("click", function InvitationlModalPage_ng_template_28_Template_ion_button_click_2_listener() {
      _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵrestoreView"](_r4);
      const ctx_r2 = _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵnextContext"]();
      return _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵresetView"](ctx_r2.cancel());
    });
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵtext"](3);
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵpipe"](4, "translate");
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵelementEnd"]()()();
  }
  if (rf & 2) {
    const ctx_r2 = _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵnextContext"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵadvance"](2);
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵproperty"]("color", ctx_r2.campaign == null ? null : ctx_r2.campaign.campaign == null ? null : ctx_r2.campaign.campaign.type);
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵadvance"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵtextInterpolate1"](" ", _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵpipeBind1"](4, 2, "challenges.cancel"), " ");
  }
}
class InvitationlModalPage {
  constructor(modalController, userService, challengeService, translateService, errorService) {
    this.modalController = modalController;
    this.userService = userService;
    this.challengeService = challengeService;
    this.translateService = translateService;
    this.errorService = errorService;
    this.playerId$ = this.userService.userProfile$.pipe((0,rxjs__WEBPACK_IMPORTED_MODULE_1__.map)(userProfile => userProfile.playerId));
  }
  ngOnInit() {
    this.typeChallenge = this.translateService.instant((0,src_app_core_shared_campaigns_campaign_utils__WEBPACK_IMPORTED_MODULE_2__.getTypeStringChallenge)(this.challenge.type));
  }
  //computed errorcontrol
  close() {
    this.modalController.dismiss(false);
  }
  activate() {
    var _this = this;
    return (0,_Users_smartcommunitylab_Desktop_newWork_playAndGo_playGo_node_modules_babel_runtime_helpers_esm_asyncToGenerator_js__WEBPACK_IMPORTED_MODULE_0__["default"])(function* () {
      try {
        yield _this.challengeService.acceptChallenge(_this.campaign, _this.challenge);
      } catch (e) {
        _this.errorService.handleError(e);
      } finally {
        _this.modalController.dismiss(false);
      }
    })();
  }
  reject() {
    var _this2 = this;
    return (0,_Users_smartcommunitylab_Desktop_newWork_playAndGo_playGo_node_modules_babel_runtime_helpers_esm_asyncToGenerator_js__WEBPACK_IMPORTED_MODULE_0__["default"])(function* () {
      try {
        yield _this2.challengeService.rejectChallenge(_this2.campaign, _this2.challenge);
      } catch (e) {
        _this2.errorService.handleError(e);
      } finally {
        _this2.modalController.dismiss(false);
      }
    })();
  }
  cancel() {
    var _this3 = this;
    return (0,_Users_smartcommunitylab_Desktop_newWork_playAndGo_playGo_node_modules_babel_runtime_helpers_esm_asyncToGenerator_js__WEBPACK_IMPORTED_MODULE_0__["default"])(function* () {
      try {
        yield _this3.challengeService.cancelChallenge(_this3.campaign, _this3.challenge);
      } catch (e) {
        _this3.errorService.handleError(e);
      } finally {
        _this3.modalController.dismiss(false);
      }
    })();
  }
  static #_ = _staticBlock = () => (this.ɵfac = function InvitationlModalPage_Factory(__ngFactoryType__) {
    return new (__ngFactoryType__ || InvitationlModalPage)(_angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵdirectiveInject"](_ionic_angular__WEBPACK_IMPORTED_MODULE_5__.ModalController), _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵdirectiveInject"](src_app_core_shared_services_user_service__WEBPACK_IMPORTED_MODULE_6__.UserService), _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵdirectiveInject"](src_app_core_shared_services_challenge_service__WEBPACK_IMPORTED_MODULE_7__.ChallengeService), _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵdirectiveInject"](_ngx_translate_core__WEBPACK_IMPORTED_MODULE_8__.TranslateService), _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵdirectiveInject"](src_app_core_shared_services_error_service__WEBPACK_IMPORTED_MODULE_9__.ErrorService));
  }, this.ɵcmp = /*@__PURE__*/_angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵdefineComponent"]({
    type: InvitationlModalPage,
    selectors: [["app-invitation-challenge"]],
    standalone: false,
    decls: 30,
    vars: 20,
    consts: [["sentTemplate", ""], [3, "color"], ["slot", "end"], [3, "click"], ["name", "close-circle-outline"], [1, "ion-margin"], [1, "ion-align-items-center"], ["size", "2"], [1, "avatar"], [3, "src", "title"], [1, "icon-size-medium", 3, "name"], [1, "flex-center"], [1, "title-challenge"], [1, "desc-challenge"], [4, "ngIf", "ngIfElse"], [1, "ion-text-center"], [3, "click", "color"], ["color", "light", 3, "click"]],
    template: function InvitationlModalPage_Template(rf, ctx) {
      if (rf & 1) {
        const _r1 = _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵgetCurrentView"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵelementStart"](0, "ion-header")(1, "ion-toolbar", 1)(2, "ion-title");
        _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵtext"](3);
        _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵpipe"](4, "languageMap");
        _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵelementStart"](5, "ion-buttons", 2)(6, "ion-button", 3);
        _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵlistener"]("click", function InvitationlModalPage_Template_ion_button_click_6_listener() {
          _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵrestoreView"](_r1);
          return _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵresetView"](ctx.close());
        });
        _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵelement"](7, "ion-icon", 4);
        _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵelementEnd"]()()()();
        _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵelementStart"](8, "ion-content")(9, "ion-grid", 5)(10, "ion-row", 6)(11, "ion-col", 7)(12, "ion-avatar", 8);
        _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵelement"](13, "img", 9);
        _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵpipe"](14, "translate");
        _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵelement"](15, "app-icon", 10);
        _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵpipe"](16, "async");
        _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵelementStart"](17, "ion-col", 11)(18, "span", 12);
        _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵtext"](19);
        _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵelementEnd"]()()();
        _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵelementStart"](20, "ion-row")(21, "ion-col")(22, "span", 13);
        _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵtext"](23);
        _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵpipe"](24, "languageMap");
        _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵelementEnd"]()()()()();
        _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵelementStart"](25, "ion-footer");
        _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵtemplate"](26, InvitationlModalPage_ion_row_26_Template, 9, 7, "ion-row", 14);
        _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵpipe"](27, "async");
        _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵtemplate"](28, InvitationlModalPage_ng_template_28_Template, 5, 4, "ng-template", null, 0, _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵtemplateRefExtractor"]);
        _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵelementEnd"]();
      }
      if (rf & 2) {
        const sentTemplate_r5 = _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵreference"](29);
        _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵadvance"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵproperty"]("color", ctx.campaign == null ? null : ctx.campaign.campaign == null ? null : ctx.campaign.campaign.type);
        _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵadvance"](2);
        _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵtextInterpolate1"](" ", _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵpipeBind1"](4, 10, ctx.campaign == null ? null : ctx.campaign.campaign == null ? null : ctx.campaign.campaign.name), " ");
        _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵadvance"](10);
        _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵproperty"]("title", _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵinterpolate"](_angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵpipeBind1"](14, 12, "registration.avatar.title")))("src", ctx.challenge.otherAttendeeData.avatar.url, _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵsanitizeUrl"]);
        _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵadvance"](2);
        _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵproperty"]("name", _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵpipeBind1"](16, 14, ctx.playerId$) === ctx.challenge.proposerId ? "invite" : "invitation");
        _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵadvance"](4);
        _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵtextInterpolate"](ctx.typeChallenge);
        _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵadvance"](4);
        _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵtextInterpolate1"]("", _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵpipeBind1"](24, 16, ctx.challenge == null ? null : ctx.challenge.challDesc), " ");
        _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵadvance"](3);
        _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵproperty"]("ngIf", _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵpipeBind1"](27, 18, ctx.playerId$) !== ctx.challenge.proposerId)("ngIfElse", sentTemplate_r5);
      }
    },
    dependencies: [_angular_common__WEBPACK_IMPORTED_MODULE_10__.NgIf, _ionic_angular__WEBPACK_IMPORTED_MODULE_5__.IonAvatar, _ionic_angular__WEBPACK_IMPORTED_MODULE_5__.IonButton, _ionic_angular__WEBPACK_IMPORTED_MODULE_5__.IonButtons, _ionic_angular__WEBPACK_IMPORTED_MODULE_5__.IonCol, _ionic_angular__WEBPACK_IMPORTED_MODULE_5__.IonContent, _ionic_angular__WEBPACK_IMPORTED_MODULE_5__.IonFooter, _ionic_angular__WEBPACK_IMPORTED_MODULE_5__.IonGrid, _ionic_angular__WEBPACK_IMPORTED_MODULE_5__.IonHeader, _ionic_angular__WEBPACK_IMPORTED_MODULE_5__.IonIcon, _ionic_angular__WEBPACK_IMPORTED_MODULE_5__.IonRow, _ionic_angular__WEBPACK_IMPORTED_MODULE_5__.IonTitle, _ionic_angular__WEBPACK_IMPORTED_MODULE_5__.IonToolbar, _core_shared_ui_icon_icon_component__WEBPACK_IMPORTED_MODULE_11__.IconComponent, _angular_common__WEBPACK_IMPORTED_MODULE_10__.AsyncPipe, _ngx_translate_core__WEBPACK_IMPORTED_MODULE_8__.TranslatePipe, _core_shared_pipes_languageMap_pipe__WEBPACK_IMPORTED_MODULE_12__.LanguageMapPipe],
    styles: ["ion-footer[_ngcontent-%COMP%] {\n  color: black;\n}\n\n.title-challenge[_ngcontent-%COMP%] {\n  font-style: italic;\n  font-weight: 200;\n  font-size: 16px;\n}\n\n.desc-challenge[_ngcontent-%COMP%] {\n  font-style: normal;\n  font-weight: 300;\n  font-size: 17px;\n}\n\n.date-challenge[_ngcontent-%COMP%] {\n  font-style: italic;\n  font-weight: 300;\n  font-size: 13px;\n}\n\nion-avatar[_ngcontent-%COMP%] {\n  position: absolute;\n  width: 25px;\n  height: 25px;\n  left: -7px;\n  top: 5px;\n}\n/*# sourceMappingURL=data:application/json;charset=utf-8;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbIndlYnBhY2s6Ly8uL3NyYy9hcHAvcGFnZXMvY2hhbGxlbmdlcy9jb3VwbGUtY2hhbGxlbmdlLXByb3Bvc2VkL2ludml0YXRpb24tY2hhbGxlbmdlL2ludml0YXRpb24tY2hhbGxlbmdlLm1vZGFsLnNjc3MiXSwibmFtZXMiOltdLCJtYXBwaW5ncyI6IkFBQUE7RUFDRSxZQUFBO0FBQ0Y7O0FBQ0E7RUFDRSxrQkFBQTtFQUNBLGdCQUFBO0VBQ0EsZUFBQTtBQUVGOztBQUFBO0VBQ0Usa0JBQUE7RUFDQSxnQkFBQTtFQUNBLGVBQUE7QUFHRjs7QUFEQTtFQUNFLGtCQUFBO0VBQ0EsZ0JBQUE7RUFDQSxlQUFBO0FBSUY7O0FBRkE7RUFDRSxrQkFBQTtFQUNBLFdBQUE7RUFDQSxZQUFBO0VBQ0EsVUFBQTtFQUNBLFFBQUE7QUFLRiIsInNvdXJjZXNDb250ZW50IjpbImlvbi1mb290ZXIge1xuICBjb2xvcjogYmxhY2s7XG59XG4udGl0bGUtY2hhbGxlbmdlIHtcbiAgZm9udC1zdHlsZTogaXRhbGljO1xuICBmb250LXdlaWdodDogMjAwO1xuICBmb250LXNpemU6IDE2cHg7XG59XG4uZGVzYy1jaGFsbGVuZ2Uge1xuICBmb250LXN0eWxlOiBub3JtYWw7XG4gIGZvbnQtd2VpZ2h0OiAzMDA7XG4gIGZvbnQtc2l6ZTogMTdweDtcbn1cbi5kYXRlLWNoYWxsZW5nZSB7XG4gIGZvbnQtc3R5bGU6IGl0YWxpYztcbiAgZm9udC13ZWlnaHQ6IDMwMDtcbiAgZm9udC1zaXplOiAxM3B4O1xufVxuaW9uLWF2YXRhciB7XG4gIHBvc2l0aW9uOiBhYnNvbHV0ZTtcbiAgd2lkdGg6IDI1cHg7XG4gIGhlaWdodDogMjVweDtcbiAgbGVmdDogLTdweDtcbiAgdG9wOiA1cHg7XG59XG4iXSwic291cmNlUm9vdCI6IiJ9 */"]
  }));
}
_staticBlock();

/***/ }),

/***/ 94103:
/*!******************************************************************************!*\
  !*** ./src/app/pages/challenges/challenge-card/detail-modal/detail.modal.ts ***!
  \******************************************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   DetailChallengenModalPage: () => (/* binding */ DetailChallengenModalPage)
/* harmony export */ });
/* harmony import */ var _capacitor_browser__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! @capacitor/browser */ 26515);
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @angular/core */ 12481);
/* harmony import */ var _ionic_angular__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @ionic/angular */ 21507);
/* harmony import */ var src_app_core_shared_services_team_service__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! src/app/core/shared/services/team.service */ 62625);
/* harmony import */ var _angular_common__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! @angular/common */ 93683);
/* harmony import */ var _ngx_translate_core__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! @ngx-translate/core */ 48503);
/* harmony import */ var _core_shared_pipes_languageMap_pipe__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! ../../../../core/shared/pipes/languageMap.pipe */ 69618);
var _staticBlock;







class DetailChallengenModalPage {
  constructor(elementRef, modalController, teamService) {
    this.elementRef = elementRef;
    this.modalController = modalController;
    this.teamService = teamService;
    this.handleAnchorClick = event => {
      // Prevent opening anchors the default way
      event.preventDefault();
      const anchor = event.target;
      _capacitor_browser__WEBPACK_IMPORTED_MODULE_0__.Browser.open({
        url: anchor.href,
        windowName: '_system',
        presentationStyle: 'popover'
      });
    };
  }
  ngAfterViewInit() {
    //change the behaviour of _blank arrived with editor, adding a new listener and opening a browser
    this.anchors = this.elementRef.nativeElement.querySelectorAll('a');
    this.anchors.forEach(anchor => {
      anchor.addEventListener('click', this.handleAnchorClick);
    });
  }
  ngOnInit() {
    if (this.team && this.challenge?.otherAttendeeData) {
      this.otherTeam$ = this.teamService.getPublicTeam(this.campaignContainer?.campaign?.campaignId, this.challenge?.otherAttendeeData.playerId);
    }
    ;
  }
  close() {
    this.modalController.dismiss(false);
  }
  challDesc(desc, name) {
    //sub id with name
    const search = this.challenge?.otherAttendeeData?.playerId;
    const searchRegExp = new RegExp(search, 'g');
    const replaceWith = name;
    if (this.team && name && desc) return desc.replace(searchRegExp, replaceWith);
    return desc;
  }
  static #_ = _staticBlock = () => (this.ɵfac = function DetailChallengenModalPage_Factory(__ngFactoryType__) {
    return new (__ngFactoryType__ || DetailChallengenModalPage)(_angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵdirectiveInject"](_angular_core__WEBPACK_IMPORTED_MODULE_1__.ElementRef), _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵdirectiveInject"](_ionic_angular__WEBPACK_IMPORTED_MODULE_2__.ModalController), _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵdirectiveInject"](src_app_core_shared_services_team_service__WEBPACK_IMPORTED_MODULE_3__.TeamService));
  }, this.ɵcmp = /*@__PURE__*/_angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵdefineComponent"]({
    type: DetailChallengenModalPage,
    selectors: [["app-detail-modal"]],
    standalone: false,
    decls: 16,
    vars: 11,
    consts: [["color", "playgo"], ["slot", "end"], [3, "click"], ["name", "close-circle-outline"], ["color", "playgo", 1, "ion-padding"], [1, "ion-padding", 3, "innerHTML"], ["color", "light", "expand", "block", 3, "click"]],
    template: function DetailChallengenModalPage_Template(rf, ctx) {
      if (rf & 1) {
        _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵelementStart"](0, "ion-header")(1, "ion-toolbar", 0)(2, "ion-title");
        _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵtext"](3);
        _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵpipe"](4, "translate");
        _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵelementStart"](5, "ion-buttons", 1)(6, "ion-button", 2);
        _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵlistener"]("click", function DetailChallengenModalPage_Template_ion_button_click_6_listener() {
          return ctx.close();
        });
        _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵelement"](7, "ion-icon", 3);
        _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵelementEnd"]()()()();
        _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵelementStart"](8, "ion-content", 4);
        _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵelement"](9, "div", 5);
        _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵpipe"](10, "languageMap");
        _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵpipe"](11, "async");
        _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵelementStart"](12, "ion-footer", 0)(13, "ion-button", 6);
        _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵlistener"]("click", function DetailChallengenModalPage_Template_ion_button_click_13_listener() {
          return ctx.close();
        });
        _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵtext"](14);
        _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵpipe"](15, "translate");
        _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵelementEnd"]()();
      }
      if (rf & 2) {
        let tmp_1_0;
        _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵadvance"](3);
        _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵtextInterpolate"](_angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵpipeBind1"](4, 3, "challenges.detail.title"));
        _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵadvance"](6);
        _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵproperty"]("innerHTML", ctx.challDesc(_angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵpipeBind1"](10, 5, ctx.challenge == null ? null : ctx.challenge.challCompleteDesc), (tmp_1_0 = _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵpipeBind1"](11, 7, ctx.otherTeam$)) == null ? null : tmp_1_0.customData == null ? null : tmp_1_0.customData.name), _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵsanitizeHtml"]);
        _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵadvance"](5);
        _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵtextInterpolate"](_angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵpipeBind1"](15, 9, "challenges.detail.close"));
      }
    },
    dependencies: [_ionic_angular__WEBPACK_IMPORTED_MODULE_2__.IonButton, _ionic_angular__WEBPACK_IMPORTED_MODULE_2__.IonButtons, _ionic_angular__WEBPACK_IMPORTED_MODULE_2__.IonContent, _ionic_angular__WEBPACK_IMPORTED_MODULE_2__.IonFooter, _ionic_angular__WEBPACK_IMPORTED_MODULE_2__.IonHeader, _ionic_angular__WEBPACK_IMPORTED_MODULE_2__.IonIcon, _ionic_angular__WEBPACK_IMPORTED_MODULE_2__.IonTitle, _ionic_angular__WEBPACK_IMPORTED_MODULE_2__.IonToolbar, _angular_common__WEBPACK_IMPORTED_MODULE_4__.AsyncPipe, _ngx_translate_core__WEBPACK_IMPORTED_MODULE_5__.TranslatePipe, _core_shared_pipes_languageMap_pipe__WEBPACK_IMPORTED_MODULE_6__.LanguageMapPipe],
    styles: ["/*# sourceMappingURL=data:application/json;charset=utf-8;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbXSwibmFtZXMiOltdLCJtYXBwaW5ncyI6IiIsInNvdXJjZVJvb3QiOiIifQ== */"]
  }));
}
_staticBlock();

/***/ }),

/***/ 97843:
/*!*****************************************************!*\
  !*** ./src/app/pages/challenges/challenges.page.ts ***!
  \*****************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   ChallengesPage: () => (/* binding */ ChallengesPage)
/* harmony export */ });
/* harmony import */ var rxjs__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! rxjs */ 19999);
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @angular/core */ 12481);
/* harmony import */ var src_app_core_shared_services_challenge_service__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! src/app/core/shared/services/challenge.service */ 16561);
/* harmony import */ var src_app_core_shared_services_notifications_notifications_service__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! src/app/core/shared/services/notifications/notifications.service */ 16095);
/* harmony import */ var _angular_router__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! @angular/router */ 85422);
var _staticBlock;





const _c0 = ["active"];
const _c1 = ["future"];
function ChallengesPage_div_15_Template(rf, ctx) {
  if (rf & 1) {
    _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵelementStart"](0, "div");
    _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵelement"](1, "app-challenges-stat");
    _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵelementEnd"]();
  }
}
function ChallengesPage_div_16_ng_container_1_div_1_div_1_Template(rf, ctx) {
  if (rf & 1) {
    _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵelementStart"](0, "div");
    _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵelement"](1, "app-challenge-container", 13, 1);
    _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵelementEnd"]();
  }
  if (rf & 2) {
    const campaign_r1 = _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵnextContext"]().$implicit;
    const ctx_r1 = _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵnextContext"](3);
    _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵadvance"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵproperty"]("campaign", campaign_r1)("challenges", ctx_r1.activeChallenges[campaign_r1 == null ? null : campaign_r1.campaign == null ? null : campaign_r1.campaign.campaignId])("type", "active");
  }
}
function ChallengesPage_div_16_ng_container_1_div_1_div_2_Template(rf, ctx) {
  if (rf & 1) {
    _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵelementStart"](0, "div");
    _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵelement"](1, "app-challenge-container", 14, 1);
    _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵelementEnd"]();
  }
  if (rf & 2) {
    const campaign_r1 = _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵnextContext"]().$implicit;
    const ctx_r1 = _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵnextContext"](3);
    _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵadvance"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵproperty"]("campaign", campaign_r1)("team", true)("challenges", ctx_r1.activeChallengesTeam[campaign_r1 == null ? null : campaign_r1.campaign == null ? null : campaign_r1.campaign.campaignId])("type", "active");
  }
}
function ChallengesPage_div_16_ng_container_1_div_1_Template(rf, ctx) {
  if (rf & 1) {
    _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵelementStart"](0, "div");
    _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵtemplate"](1, ChallengesPage_div_16_ng_container_1_div_1_div_1_Template, 3, 3, "div", 10)(2, ChallengesPage_div_16_ng_container_1_div_1_div_2_Template, 3, 4, "div", 10);
    _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵelementEnd"]();
  }
  if (rf & 2) {
    const campaign_r1 = ctx.$implicit;
    const ctx_r1 = _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵnextContext"](3);
    _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵadvance"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵproperty"]("ngIf", (ctx_r1.activeChallenges[campaign_r1 == null ? null : campaign_r1.campaign == null ? null : campaign_r1.campaign.campaignId] == null ? null : ctx_r1.activeChallenges[campaign_r1 == null ? null : campaign_r1.campaign == null ? null : campaign_r1.campaign.campaignId].length) > 0);
    _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵadvance"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵproperty"]("ngIf", (ctx_r1.activeChallengesTeam[campaign_r1 == null ? null : campaign_r1.campaign == null ? null : campaign_r1.campaign.campaignId] == null ? null : ctx_r1.activeChallengesTeam[campaign_r1 == null ? null : campaign_r1.campaign == null ? null : campaign_r1.campaign.campaignId].length) > 0);
  }
}
function ChallengesPage_div_16_ng_container_1_Template(rf, ctx) {
  if (rf & 1) {
    _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵelementContainerStart"](0);
    _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵtemplate"](1, ChallengesPage_div_16_ng_container_1_div_1_Template, 3, 2, "div", 12);
    _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵelementContainerEnd"]();
  }
  if (rf & 2) {
    const ctx_r1 = _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵnextContext"](2);
    _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵadvance"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵproperty"]("ngForOf", ctx_r1.campaignsWithChallenges);
  }
}
function ChallengesPage_div_16_ng_template_2_Template(rf, ctx) {
  if (rf & 1) {
    _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵelementStart"](0, "div", 15);
    _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵtext"](1);
    _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵpipe"](2, "translate");
    _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵelementEnd"]();
  }
  if (rf & 2) {
    _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵadvance"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵtextInterpolate"](_angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵpipeBind1"](2, 1, "challenges.empty"));
  }
}
function ChallengesPage_div_16_Template(rf, ctx) {
  if (rf & 1) {
    _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵelementStart"](0, "div");
    _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵtemplate"](1, ChallengesPage_div_16_ng_container_1_Template, 2, 1, "ng-container", 11)(2, ChallengesPage_div_16_ng_template_2_Template, 3, 3, "ng-template", null, 0, _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵtemplateRefExtractor"]);
    _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵelementEnd"]();
  }
  if (rf & 2) {
    const noChallengeActive_r3 = _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵreference"](3);
    const ctx_r1 = _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵnextContext"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵadvance"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵproperty"]("ngIf", ctx_r1.thereAreChallengeActive)("ngIfElse", noChallengeActive_r3);
  }
}
function ChallengesPage_div_17_ng_container_1_div_1_div_1_Template(rf, ctx) {
  if (rf & 1) {
    _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵelementStart"](0, "div");
    _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵelement"](1, "app-challenge-container", 16, 3);
    _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵelementEnd"]();
  }
  if (rf & 2) {
    const campaign_r4 = _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵnextContext"]().$implicit;
    const ctx_r1 = _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵnextContext"](3);
    _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵadvance"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵproperty"]("campaign", campaign_r4)("challenges", ctx_r1.futureChallenges[campaign_r4 == null ? null : campaign_r4.campaign == null ? null : campaign_r4.campaign.campaignId])("type", "future")("canInvite", ctx_r1.canInvite[campaign_r4 == null ? null : campaign_r4.campaign == null ? null : campaign_r4.campaign.campaignId]);
  }
}
function ChallengesPage_div_17_ng_container_1_div_1_div_2_Template(rf, ctx) {
  if (rf & 1) {
    _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵelementStart"](0, "div");
    _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵelement"](1, "app-challenge-container", 14, 3);
    _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵelementEnd"]();
  }
  if (rf & 2) {
    const campaign_r4 = _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵnextContext"]().$implicit;
    const ctx_r1 = _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵnextContext"](3);
    _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵadvance"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵproperty"]("campaign", campaign_r4)("team", true)("challenges", ctx_r1.futureChallengesTeam[campaign_r4 == null ? null : campaign_r4.campaign == null ? null : campaign_r4.campaign.campaignId])("type", "future");
  }
}
function ChallengesPage_div_17_ng_container_1_div_1_Template(rf, ctx) {
  if (rf & 1) {
    _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵelementStart"](0, "div");
    _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵtemplate"](1, ChallengesPage_div_17_ng_container_1_div_1_div_1_Template, 3, 4, "div", 10)(2, ChallengesPage_div_17_ng_container_1_div_1_div_2_Template, 3, 4, "div", 10);
    _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵelementEnd"]();
  }
  if (rf & 2) {
    const campaign_r4 = ctx.$implicit;
    const ctx_r1 = _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵnextContext"](3);
    _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵadvance"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵproperty"]("ngIf", (ctx_r1.futureChallenges[campaign_r4 == null ? null : campaign_r4.campaign == null ? null : campaign_r4.campaign.campaignId] == null ? null : ctx_r1.futureChallenges[campaign_r4 == null ? null : campaign_r4.campaign == null ? null : campaign_r4.campaign.campaignId].length) > 0 || ctx_r1.canInvite[campaign_r4 == null ? null : campaign_r4.campaign == null ? null : campaign_r4.campaign.campaignId]);
    _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵadvance"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵproperty"]("ngIf", (ctx_r1.futureChallengesTeam[campaign_r4 == null ? null : campaign_r4.campaign == null ? null : campaign_r4.campaign.campaignId] == null ? null : ctx_r1.futureChallengesTeam[campaign_r4 == null ? null : campaign_r4.campaign == null ? null : campaign_r4.campaign.campaignId].length) > 0);
  }
}
function ChallengesPage_div_17_ng_container_1_Template(rf, ctx) {
  if (rf & 1) {
    _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵelementContainerStart"](0);
    _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵtemplate"](1, ChallengesPage_div_17_ng_container_1_div_1_Template, 3, 2, "div", 12);
    _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵelementContainerEnd"]();
  }
  if (rf & 2) {
    const ctx_r1 = _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵnextContext"](2);
    _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵadvance"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵproperty"]("ngForOf", ctx_r1.campaignsWithChallenges);
  }
}
function ChallengesPage_div_17_ng_template_2_Template(rf, ctx) {
  if (rf & 1) {
    _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵelementStart"](0, "div", 15);
    _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵtext"](1);
    _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵpipe"](2, "translate");
    _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵelementEnd"]();
  }
  if (rf & 2) {
    _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵadvance"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵtextInterpolate"](_angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵpipeBind1"](2, 1, "challenges.empty"));
  }
}
function ChallengesPage_div_17_Template(rf, ctx) {
  if (rf & 1) {
    _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵelementStart"](0, "div");
    _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵtemplate"](1, ChallengesPage_div_17_ng_container_1_Template, 2, 1, "ng-container", 11)(2, ChallengesPage_div_17_ng_template_2_Template, 3, 3, "ng-template", null, 2, _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵtemplateRefExtractor"]);
    _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵelementEnd"]();
  }
  if (rf & 2) {
    const noChallengeFuture_r5 = _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵreference"](3);
    const ctx_r1 = _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵnextContext"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵadvance"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵproperty"]("ngIf", ctx_r1.thereAreChallengeFuture || ctx_r1.userCanInvite)("ngIfElse", noChallengeFuture_r5);
  }
}
class ChallengesPage {
  constructor(challengeService, notificationService, activatedRoute) {
    this.challengeService = challengeService;
    this.notificationService = notificationService;
    this.activatedRoute = activatedRoute;
    this.campaignsWithChallenges = [];
    this.thereAreChallengeActive = false;
    this.thereAreChallengeFuture = false;
    this.activeChallenges = {};
    this.activeChallengesTeam = {};
    this.futureChallenges = {};
    this.futureChallengesTeam = {};
    this.canInvite = {};
    // public pastChallenges$: Observable<Challenge[]> =
    //   this.challengeService.pastChallenges$;
    this.activeChallenges$ = this.challengeService.activeChallenges$;
    this.futureChallenges$ = this.challengeService.futureChallenges$;
  }
  ngOnInit() {}
  ionViewWillEnter() {
    this.selectedSegment = 'activeChallenges';
    this.subSegment = this.activatedRoute.queryParams.subscribe(params => {
      if (params && params.selectedSegment) {
        //store the temp in data
        this.selectedSegment = params.selectedSegment;
      }
    });
    //mark common challenges notification as readed: activated, failed or completed
    this.notificationService.markCommonChallengeNotificationAsRead();
    this.subCampaignChall = this.challengeService.campaignsWithChallenges$.subscribe(campaigns => {
      this.campaignsWithChallenges = campaigns;
    });
    this.subCampaignActiveChall = (0,rxjs__WEBPACK_IMPORTED_MODULE_0__.combineLatest)([this.challengeService.activeChallenges$, this.challengeService.activeChallengesTeam$]).subscribe(([active, team]) => {
      this.activeChallenges = active.reduce((result, a) => ((result[a.campaign.campaignId] = result[a.campaign.campaignId] || []).push(a), result), {});
      this.activeChallengesTeam = team.reduce((result, a) => ((result[a.campaign.campaignId] = result[a.campaign.campaignId] || []).push(a), result), {});
      if (active.length > 0 || team.length > 0) {
        this.thereAreChallengeActive = true;
      } else {
        this.thereAreChallengeActive = false;
      }
    });
    this.subCampaignFutureChall = (0,rxjs__WEBPACK_IMPORTED_MODULE_0__.combineLatest)([this.challengeService.futureChallenges$, this.challengeService.futureChallengesTeam$]).subscribe(([future, team]) => {
      this.futureChallenges = future.reduce((result, a) => ((result[a.campaign.campaignId] = result[a.campaign.campaignId] || []).push(a), result), {});
      this.futureChallengesTeam = team.reduce((result, a) => ((result[a.campaign.campaignId] = result[a.campaign.campaignId] || []).push(a), result), {});
      if (future.length > 0 || team.length > 0) {
        this.thereAreChallengeFuture = true;
      } else {
        this.thereAreChallengeFuture = false;
      }
    });
    this.subCampaignCanInvite = this.challengeService.canInvite$.subscribe(canInvite => {
      this.canInvite = canInvite.reduce((result, a) => (result[a.campaign.campaignId] = a.canInvite || false, result), {});
      this.userCanInvite = Object.values(this.canInvite).some(x => x === true);
    });
  }
  ngOnDestroy() {}
  ionViewDidLeave() {
    this.subCampaignActiveChall?.unsubscribe();
    this.subCampaignCanInvite?.unsubscribe();
    this.subCampaignChall?.unsubscribe();
    this.subCampaignFutureChall?.unsubscribe();
    this.subSegment?.unsubscribe();
  }
  static #_ = _staticBlock = () => (this.ɵfac = function ChallengesPage_Factory(__ngFactoryType__) {
    return new (__ngFactoryType__ || ChallengesPage)(_angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵdirectiveInject"](src_app_core_shared_services_challenge_service__WEBPACK_IMPORTED_MODULE_2__.ChallengeService), _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵdirectiveInject"](src_app_core_shared_services_notifications_notifications_service__WEBPACK_IMPORTED_MODULE_3__.NotificationService), _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵdirectiveInject"](_angular_router__WEBPACK_IMPORTED_MODULE_4__.ActivatedRoute));
  }, this.ɵcmp = /*@__PURE__*/_angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵdefineComponent"]({
    type: ChallengesPage,
    selectors: [["app-challenges"]],
    viewQuery: function ChallengesPage_Query(rf, ctx) {
      if (rf & 1) {
        _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵviewQuery"](_c0, 5);
        _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵviewQuery"](_c1, 5);
      }
      if (rf & 2) {
        let _t;
        _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵqueryRefresh"](_t = _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵloadQuery"]()) && (ctx.activeChallengeChild = _t.first);
        _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵqueryRefresh"](_t = _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵloadQuery"]()) && (ctx.futureChallengeChild = _t.first);
      }
    },
    standalone: false,
    decls: 18,
    vars: 28,
    consts: [["noChallengeActive", ""], ["active", ""], ["noChallengeFuture", ""], ["futuri", ""], ["appHeader", ""], ["appContent", "", 1, "page", 3, "fullscreen"], ["mode", "md", "scrollable", "", 1, "app-segment", 3, "ngModelChange", "ngModel"], ["value", "pastChallenges", "checked", "", "mode", "ios", 1, "app-segment-button"], ["value", "activeChallenges", "checked", "", "mode", "ios", 1, "app-segment-button"], ["value", "futureChallenges", "mode", "ios", 1, "app-segment-button"], [4, "ngIf"], [4, "ngIf", "ngIfElse"], [4, "ngFor", "ngForOf"], [3, "campaign", "challenges", "type"], [3, "campaign", "team", "challenges", "type"], [1, "empty-challenge"], [3, "campaign", "challenges", "type", "canInvite"]],
    template: function ChallengesPage_Template(rf, ctx) {
      if (rf & 1) {
        _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵelement"](0, "ion-header", 4);
        _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵelementStart"](1, "ion-content", 5)(2, "ion-segment", 6);
        _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵtwoWayListener"]("ngModelChange", function ChallengesPage_Template_ion_segment_ngModelChange_2_listener($event) {
          _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵtwoWayBindingSet"](ctx.selectedSegment, $event) || (ctx.selectedSegment = $event);
          return $event;
        });
        _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵelementStart"](3, "ion-segment-button", 7)(4, "ion-label");
        _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵtext"](5);
        _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵpipe"](6, "translate");
        _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵelementEnd"]()();
        _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵelementStart"](7, "ion-segment-button", 8)(8, "ion-label");
        _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵtext"](9);
        _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵpipe"](10, "translate");
        _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵelementEnd"]()();
        _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵelementStart"](11, "ion-segment-button", 9)(12, "ion-label");
        _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵtext"](13);
        _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵpipe"](14, "translate");
        _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵelementEnd"]()()();
        _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵtemplate"](15, ChallengesPage_div_15_Template, 2, 0, "div", 10)(16, ChallengesPage_div_16_Template, 4, 2, "div", 10)(17, ChallengesPage_div_17_Template, 4, 2, "div", 10);
        _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵelementEnd"]();
      }
      if (rf & 2) {
        _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵadvance"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵproperty"]("fullscreen", true);
        _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵadvance"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵstyleProp"]("--background", "var(--ion-color-playgo)");
        _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵtwoWayProperty"]("ngModel", ctx.selectedSegment);
        _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵadvance"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵstyleProp"]("--color", "white")("--color-checked", "black");
        _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵadvance"](2);
        _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵtextInterpolate"](_angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵpipeBind1"](6, 22, "challenges.past"));
        _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵadvance"](2);
        _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵstyleProp"]("--color", "white")("--color-checked", "black");
        _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵadvance"](2);
        _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵtextInterpolate"](_angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵpipeBind1"](10, 24, "challenges.present"));
        _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵadvance"](2);
        _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵstyleProp"]("--color", "white")("--color-checked", "black");
        _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵadvance"](2);
        _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵtextInterpolate"](_angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵpipeBind1"](14, 26, "challenges.future"));
        _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵadvance"](2);
        _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵproperty"]("ngIf", ctx.selectedSegment === "pastChallenges");
        _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵadvance"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵproperty"]("ngIf", ctx.selectedSegment === "activeChallenges");
        _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵadvance"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵproperty"]("ngIf", ctx.selectedSegment === "futureChallenges");
      }
    },
    styles: [".empty-challenge[_ngcontent-%COMP%] {\n  margin: auto;\n  padding: 8px;\n  font-size: 20px;\n  text-align: center;\n  -ms-transform: translateY(-50%);\n}\n/*# sourceMappingURL=data:application/json;charset=utf-8;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbIndlYnBhY2s6Ly8uL3NyYy9hcHAvcGFnZXMvY2hhbGxlbmdlcy9jaGFsbGVuZ2VzLnBhZ2Uuc2NzcyJdLCJuYW1lcyI6W10sIm1hcHBpbmdzIjoiQUFBQTtFQUNFLFlBQUE7RUFDQSxZQUFBO0VBQ0EsZUFBQTtFQUNBLGtCQUFBO0VBQ0EsK0JBQUE7QUFDRiIsInNvdXJjZXNDb250ZW50IjpbIi5lbXB0eS1jaGFsbGVuZ2Uge1xuICBtYXJnaW46IGF1dG87XG4gIHBhZGRpbmc6IDhweDtcbiAgZm9udC1zaXplOiAyMHB4O1xuICB0ZXh0LWFsaWduOiBjZW50ZXI7XG4gIC1tcy10cmFuc2Zvcm06IHRyYW5zbGF0ZVkoLTUwJSk7XG59XG4iXSwic291cmNlUm9vdCI6IiJ9 */"]
  }));
}
_staticBlock();

/***/ })

}]);
//# sourceMappingURL=src_app_pages_challenges_challenges_module_ts.js.map