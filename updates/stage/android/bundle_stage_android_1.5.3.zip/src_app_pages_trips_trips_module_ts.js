"use strict";
(self["webpackChunkapp"] = self["webpackChunkapp"] || []).push([["src_app_pages_trips_trips_module_ts"],{

/***/ 3417:
/*!*********************************************************!*\
  !*** ./node_modules/backoff-rxjs/dist/esm2015/utils.js ***!
  \*********************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   exponentialBackoffDelay: () => (/* binding */ exponentialBackoffDelay),
/* harmony export */   getDelay: () => (/* binding */ getDelay)
/* harmony export */ });
function getDelay(backoffDelay, maxInterval) {
  return Math.min(backoffDelay, maxInterval);
}
function exponentialBackoffDelay(iteration, initialInterval) {
  return Math.pow(2, iteration) * initialInterval;
}

/***/ }),

/***/ 4960:
/*!*********************************************************!*\
  !*** ./node_modules/backoff-rxjs/dist/esm2015/index.js ***!
  \*********************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   intervalBackoff: () => (/* reexport safe */ _observable_intervalBackoff__WEBPACK_IMPORTED_MODULE_1__.intervalBackoff),
/* harmony export */   retryBackoff: () => (/* reexport safe */ _operators_retryBackoff__WEBPACK_IMPORTED_MODULE_0__.retryBackoff)
/* harmony export */ });
/* harmony import */ var _operators_retryBackoff__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./operators/retryBackoff */ 30158);
/* harmony import */ var _observable_intervalBackoff__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ./observable/intervalBackoff */ 55679);



/***/ }),

/***/ 14470:
/*!*******************************************!*\
  !*** ./node_modules/lodash-es/_baseLt.js ***!
  \*******************************************/
/***/ ((__unused_webpack___webpack_module__, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "default": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/**
 * The base implementation of `_.lt` which doesn't coerce arguments.
 *
 * @private
 * @param {*} value The value to compare.
 * @param {*} other The other value to compare.
 * @returns {boolean} Returns `true` if `value` is less than `other`,
 *  else `false`.
 */
function baseLt(value, other) {
  return value < other;
}
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (baseLt);

/***/ }),

/***/ 20599:
/*!*************************************************************!*\
  !*** ./src/app/core/shared/tracking/local-trips.service.ts ***!
  \*************************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   InitServiceStream: () => (/* binding */ InitServiceStream),
/* harmony export */   LocalTripsService: () => (/* binding */ LocalTripsService)
/* harmony export */ });
/* harmony import */ var _Users_smartcommunitylab_Desktop_newWork_playAndGo_playGo_node_modules_babel_runtime_helpers_esm_asyncToGenerator_js__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./node_modules/@babel/runtime/helpers/esm/asyncToGenerator.js */ 89204);
/* harmony import */ var rxjs__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! rxjs */ 10819);
/* harmony import */ var rxjs__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! rxjs */ 44665);
/* harmony import */ var rxjs__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! rxjs */ 137);
/* harmony import */ var rxjs__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! rxjs */ 63617);
/* harmony import */ var rxjs__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! rxjs */ 59452);
/* harmony import */ var rxjs__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! rxjs */ 79439);
/* harmony import */ var rxjs_operators__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(/*! rxjs/operators */ 61318);
/* harmony import */ var rxjs_operators__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(/*! rxjs/operators */ 51903);
/* harmony import */ var rxjs_operators__WEBPACK_IMPORTED_MODULE_9__ = __webpack_require__(/*! rxjs/operators */ 91817);
/* harmony import */ var rxjs_operators__WEBPACK_IMPORTED_MODULE_10__ = __webpack_require__(/*! rxjs/operators */ 70271);
/* harmony import */ var rxjs_operators__WEBPACK_IMPORTED_MODULE_11__ = __webpack_require__(/*! rxjs/operators */ 86301);
/* harmony import */ var rxjs_operators__WEBPACK_IMPORTED_MODULE_12__ = __webpack_require__(/*! rxjs/operators */ 36647);
/* harmony import */ var rxjs_operators__WEBPACK_IMPORTED_MODULE_13__ = __webpack_require__(/*! rxjs/operators */ 12136);
/* harmony import */ var rxjs_operators__WEBPACK_IMPORTED_MODULE_14__ = __webpack_require__(/*! rxjs/operators */ 15842);
/* harmony import */ var backoff_rxjs__WEBPACK_IMPORTED_MODULE_15__ = __webpack_require__(/*! backoff-rxjs */ 4960);
/* harmony import */ var luxon__WEBPACK_IMPORTED_MODULE_16__ = __webpack_require__(/*! luxon */ 45967);
/* harmony import */ var lodash_es__WEBPACK_IMPORTED_MODULE_17__ = __webpack_require__(/*! lodash-es */ 95110);
/* harmony import */ var lodash_es__WEBPACK_IMPORTED_MODULE_18__ = __webpack_require__(/*! lodash-es */ 24979);
/* harmony import */ var lodash_es__WEBPACK_IMPORTED_MODULE_19__ = __webpack_require__(/*! lodash-es */ 87923);
/* harmony import */ var lodash_es__WEBPACK_IMPORTED_MODULE_20__ = __webpack_require__(/*! lodash-es */ 92434);
/* harmony import */ var lodash_es__WEBPACK_IMPORTED_MODULE_21__ = __webpack_require__(/*! lodash-es */ 80524);
/* harmony import */ var lodash_es__WEBPACK_IMPORTED_MODULE_22__ = __webpack_require__(/*! lodash-es */ 89951);
/* harmony import */ var lodash_es__WEBPACK_IMPORTED_MODULE_23__ = __webpack_require__(/*! lodash-es */ 28320);
/* harmony import */ var lodash_es__WEBPACK_IMPORTED_MODULE_24__ = __webpack_require__(/*! lodash-es */ 23477);
/* harmony import */ var _utils__WEBPACK_IMPORTED_MODULE_25__ = __webpack_require__(/*! ../utils */ 7497);
/* harmony import */ var _rxjs_utils__WEBPACK_IMPORTED_MODULE_26__ = __webpack_require__(/*! ../rxjs.utils */ 86040);
/* harmony import */ var _time_utils__WEBPACK_IMPORTED_MODULE_27__ = __webpack_require__(/*! ../time.utils */ 27780);
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_28__ = __webpack_require__(/*! @angular/core */ 34205);
/* harmony import */ var _services_local_storage_service__WEBPACK_IMPORTED_MODULE_29__ = __webpack_require__(/*! ../services/local-storage.service */ 9891);
/* harmony import */ var _track_api_service__WEBPACK_IMPORTED_MODULE_30__ = __webpack_require__(/*! ./track-api.service */ 39499);
/* harmony import */ var _background_tracking_service__WEBPACK_IMPORTED_MODULE_31__ = __webpack_require__(/*! ./background-tracking.service */ 27215);
/* harmony import */ var _auth_auth_service__WEBPACK_IMPORTED_MODULE_32__ = __webpack_require__(/*! ../../auth/auth.service */ 35524);
/* harmony import */ var _services_refresher_service__WEBPACK_IMPORTED_MODULE_33__ = __webpack_require__(/*! ../services/refresher.service */ 8780);
/* harmony import */ var _services_notifications_pushNotification_service__WEBPACK_IMPORTED_MODULE_34__ = __webpack_require__(/*! ../services/notifications/pushNotification.service */ 47562);

var _staticBlock, _staticBlock2;















/** Needed for delaying start in case of testing */
class InitServiceStream {
  get() {
    return (0,rxjs__WEBPACK_IMPORTED_MODULE_5__.of)(undefined);
  }
  static #_ = _staticBlock = () => (this.ɵfac = function InitServiceStream_Factory(__ngFactoryType__) {
    return new (__ngFactoryType__ || InitServiceStream)();
  }, this.ɵprov = /*@__PURE__*/_angular_core__WEBPACK_IMPORTED_MODULE_28__["ɵɵdefineInjectable"]({
    token: InitServiceStream,
    factory: InitServiceStream.ɵfac,
    providedIn: 'root'
  }));
}
/**
 * This service is responsible for providing most recent trips.
 *
 * After backgroundGeolocation plugin sync was called, the trips are not yet
 * available in the API. This service is responsible for smartly polling the API until
 * these "pending" trips are available.
 *
 * Service keeps list of trips, which some of them are pending. And will call the API
 * on these triggers:
 * - reloadPendingTrigger. When this is triggered, the service will reload all pending trips.
 *        This is triggered few times after each sync, after push notifications,
 *        after app is resumed (todo), and after network is back online (todo).
 * - reloadFromLastTripTrigger. Load trips from last trip in the list. This is triggered
 *       in the app start - to fill any trips that could be tracked on different device.
 * - reloadAllTrigger. This is triggered when user explicitly requests to reload all trips.
 *
 * The trips are also cached in local storage, so that the app can be used offline.
 */
_staticBlock();
class LocalTripsService {
  constructor(initStream, localStorageService, trackApiService, backgroundTrackingService, authService, refresherService, pushNotificationService) {
    this.initStream = initStream;
    this.localStorageService = localStorageService;
    this.trackApiService = trackApiService;
    this.backgroundTrackingService = backgroundTrackingService;
    this.authService = authService;
    this.refresherService = refresherService;
    this.pushNotificationService = pushNotificationService;
    this.storage = this.localStorageService.getStorageOf('trips');
    /** Specify interval on which LocalTripsService works */
    this.localDataFromDate = luxon__WEBPACK_IMPORTED_MODULE_16__.DateTime.local()
    // .minus({ month: 1 })
    .minus({
      days: 7
    }).toUTC().startOf('day');
    this.justSynchronizedLocations$ = this.backgroundTrackingService.synchronizedLocations$;
    this.explicitReload$ = this.refresherService.refreshed$;
    /** After backgroundGeolocation plugin sync was called, we ask server multiple
     * times, to see if synced trips are already available and validated. */
    this.afterSyncTimer$ = this.justSynchronizedLocations$.pipe((0,rxjs_operators__WEBPACK_IMPORTED_MODULE_12__.switchMap)(() => (0,backoff_rxjs__WEBPACK_IMPORTED_MODULE_15__.intervalBackoff)({
      initialInterval: 1000,
      maxInterval: 30 * 1000
    })), (0,_rxjs_utils__WEBPACK_IMPORTED_MODULE_26__.mapTo)(undefined));
    this.pushNotification$ = this.pushNotificationService.notifications$.pipe((0,_rxjs_utils__WEBPACK_IMPORTED_MODULE_26__.mapTo)(undefined));
    this.appResumed$ = rxjs__WEBPACK_IMPORTED_MODULE_6__.NEVER;
    this.networkStatusChanged$ = rxjs__WEBPACK_IMPORTED_MODULE_6__.NEVER;
    /** Contains all triggers, for which we will ask server to check on
     * pending trips. */
    this.reloadPendingTrigger$ = (0,rxjs__WEBPACK_IMPORTED_MODULE_4__.merge)(this.afterSyncTimer$, this.appResumed$, this.networkStatusChanged$, this.pushNotification$).pipe((0,rxjs_operators__WEBPACK_IMPORTED_MODULE_13__.throttleTime)(500), (0,_rxjs_utils__WEBPACK_IMPORTED_MODULE_26__.mapTo)('RELOAD_ONLY_PENDING'));
    this.reloadFromLastTripTrigger$ = (0,rxjs__WEBPACK_IMPORTED_MODULE_4__.merge)(this.authService.isReadyForApi$).pipe((0,_rxjs_utils__WEBPACK_IMPORTED_MODULE_26__.mapTo)('RELOAD_FROM_LAST_TRIP'));
    this.reloadAllTrigger$ = (0,rxjs__WEBPACK_IMPORTED_MODULE_4__.merge)(this.explicitReload$).pipe((0,_rxjs_utils__WEBPACK_IMPORTED_MODULE_26__.mapTo)('RELOAD_WHOLE_PERIOD'));
    this.trigger$ = (0,rxjs__WEBPACK_IMPORTED_MODULE_4__.merge)(this.reloadPendingTrigger$, this.reloadFromLastTripTrigger$, this.reloadAllTrigger$).pipe((0,rxjs_operators__WEBPACK_IMPORTED_MODULE_11__.shareReplay)({
      refCount: false,
      bufferSize: 100
    }));
    this.initialLocalData$ = (0,rxjs__WEBPACK_IMPORTED_MODULE_3__.defer)(() => this.getTripsFromStorage(this.localDataFromDate));
    this.localDataSubject = new rxjs__WEBPACK_IMPORTED_MODULE_1__.Subject();
    this.lastLocalData$ = (0,rxjs__WEBPACK_IMPORTED_MODULE_2__.concat)(this.initialLocalData$, this.localDataSubject).pipe((0,rxjs_operators__WEBPACK_IMPORTED_MODULE_11__.shareReplay)({
      refCount: false,
      bufferSize: 1
    }));
    this.dataFromPluginDB$ = this.justSynchronizedLocations$.pipe((0,rxjs_operators__WEBPACK_IMPORTED_MODULE_10__.map)(synchronizedLocations => {
      const tripLocations = synchronizedLocations.filter(location => location.idTrip);
      return (0,_utils__WEBPACK_IMPORTED_MODULE_25__.groupByConsecutiveValues)(tripLocations, 'idTrip').map(({
        group,
        values
      }) => {
        const idTrip = group;
        const locations = values;
        const representativeLocation = (0,lodash_es__WEBPACK_IMPORTED_MODULE_17__["default"])(locations);
        const trip = {
          campaigns: [],
          distance: 0,
          startTime: (0,lodash_es__WEBPACK_IMPORTED_MODULE_17__["default"])(locations).date,
          endTime: (0,lodash_es__WEBPACK_IMPORTED_MODULE_21__["default"])(locations).date,
          modeType: representativeLocation.transportType,
          multimodalId: representativeLocation.multimodalId,
          polyline: '',
          trackedInstanceId: `localId_${idTrip}`,
          validity: null,
          clientId: idTrip
        };
        return trip;
      });
    }), (0,rxjs_operators__WEBPACK_IMPORTED_MODULE_10__.map)(trips => trips.map(trip => ({
      id: trip.clientId,
      status: 'syncedButNotReturnedFromServer',
      date: luxon__WEBPACK_IMPORTED_MODULE_16__.DateTime.fromMillis(trip.endTime).toISODate(),
      tripData: trip
    }))));
    this.dataFromServer$ = this.trigger$.pipe((0,_rxjs_utils__WEBPACK_IMPORTED_MODULE_26__.withReplayedLatestFrom)(this.lastLocalData$), (0,rxjs_operators__WEBPACK_IMPORTED_MODULE_10__.map)(([triggerType, lastLocalData]) => this.findPeriodFromDate(lastLocalData, triggerType)), (0,rxjs_operators__WEBPACK_IMPORTED_MODULE_8__.concatMap)(periodFromDate => this.loadDataFromServer(periodFromDate)), (0,rxjs_operators__WEBPACK_IMPORTED_MODULE_11__.shareReplay)(1));
    this.localData$ = (0,rxjs__WEBPACK_IMPORTED_MODULE_4__.merge)(this.dataFromServer$, this.dataFromPluginDB$).pipe((0,rxjs_operators__WEBPACK_IMPORTED_MODULE_14__.withLatestFrom)(this.lastLocalData$), (0,rxjs_operators__WEBPACK_IMPORTED_MODULE_10__.map)(([newData, lastLocalData]) => this.pairPendingTrips(lastLocalData, newData)), (0,_rxjs_utils__WEBPACK_IMPORTED_MODULE_26__.startFrom)(this.initialLocalData$), (0,rxjs_operators__WEBPACK_IMPORTED_MODULE_11__.shareReplay)(1));
    this.localDataChanges$ = this.localData$.pipe((0,rxjs_operators__WEBPACK_IMPORTED_MODULE_9__.distinctUntilChanged)(lodash_es__WEBPACK_IMPORTED_MODULE_20__["default"]));
    this.newTripsTrigger$ = this.localData$.pipe(
    // this should be the trigger which caused the localData$ to change, not last trigger, but it is close enough
    (0,rxjs_operators__WEBPACK_IMPORTED_MODULE_14__.withLatestFrom)(this.trigger$), (0,rxjs_operators__WEBPACK_IMPORTED_MODULE_10__.map)(([data, isForceTrigger]) => ({
      data,
      isForceTrigger
    })), (0,rxjs_operators__WEBPACK_IMPORTED_MODULE_9__.distinctUntilChanged)((previous, current) => {
      if (!current || !previous) {
        return false;
      }
      if (current.isForceTrigger) {
        return false;
      }
      return (0,lodash_es__WEBPACK_IMPORTED_MODULE_20__["default"])(current.data, previous.data);
    }), (0,_rxjs_utils__WEBPACK_IMPORTED_MODULE_26__.mapTo)(undefined));
    this.initStream.get().subscribe(() => {
      this.initService();
    });
  }
  initService() {
    this.lastLocalData$.subscribe();
    this.localDataChanges$.subscribe(trips => {
      // for creating lastLocalData$ observable
      this.localDataSubject.next(trips);
      this.storeTripsToStorage(trips);
    });
  }
  loadDataFromServer(from) {
    const nowDateTime = luxon__WEBPACK_IMPORTED_MODULE_16__.DateTime.local();
    const to = nowDateTime;
    if (from === NOW) {
      // no pending trips
      return (0,rxjs__WEBPACK_IMPORTED_MODULE_5__.of)([]);
    }
    // console.log(
    //   `LT: Loading trips from ${from.toFormat(
    //     'dd MM yyyy HH:mm'
    //   )} to ${to.toFormat('dd MM yyyy HH:mm')}`
    // );
    return this.trackApiService.getTrackedInstanceInfoList({
      page: 0,
      size: 10000,
      dateFrom: (0,_time_utils__WEBPACK_IMPORTED_MODULE_27__.toServerDateTime)(from),
      dateTo: (0,_time_utils__WEBPACK_IMPORTED_MODULE_27__.toServerDateTime)(to)
    }).pipe((0,rxjs_operators__WEBPACK_IMPORTED_MODULE_10__.map)(pageResult => pageResult.content), (0,rxjs_operators__WEBPACK_IMPORTED_MODULE_10__.map)(serverTrips => serverTrips.map(serverTrip => {
      const localTrip = {
        status: 'fromServer',
        date: new Date(serverTrip.endTime).toISOString(),
        id: serverTrip.clientId,
        tripData: serverTrip
      };
      return localTrip;
    })), (0,rxjs_operators__WEBPACK_IMPORTED_MODULE_7__.catchError)(e => (0,rxjs__WEBPACK_IMPORTED_MODULE_5__.of)([])));
  }
  pairPendingTrips(lastLocalTrips, serverOrPluginTrips) {
    const localOnlyTrips = lastLocalTrips.filter(localTrip => !(0,lodash_es__WEBPACK_IMPORTED_MODULE_23__["default"])(serverOrPluginTrips, {
      id: localTrip.id
    }));
    const onlyLongServerOrPluginTrips = serverOrPluginTrips.filter(serverOrPluginTrip => Math.ceil((serverOrPluginTrip?.tripData?.endTime - serverOrPluginTrip?.tripData?.startTime) / 1000) > 15);
    const onlyLongLocalOnlyTrips = localOnlyTrips.filter(localOnlyTrip => Math.ceil((localOnlyTrip?.tripData?.endTime - localOnlyTrip?.tripData?.startTime) / 1000) > 15);
    return this.sortTrips([...onlyLongServerOrPluginTrips, ...onlyLongLocalOnlyTrips]);
  }
  sortTrips(trips) {
    // sort by date. First the ones with the most recent date, then the ones with the oldest date
    // aka: sort desc by timestamp
    return (0,lodash_es__WEBPACK_IMPORTED_MODULE_24__["default"])(trips, trip => -luxon__WEBPACK_IMPORTED_MODULE_16__.DateTime.fromISO(trip.date).valueOf());
  }
  findPeriodFromDate(trips, triggerType) {
    const fromDate = {
      forWholePeriod: this.localDataFromDate,
      forEmptyPeriod: NOW
    };
    if (triggerType === 'RELOAD_WHOLE_PERIOD') {
      return fromDate.forWholePeriod;
    }
    // find oldest pending trip - aka with last index
    const oldestPendingTrip = (0,lodash_es__WEBPACK_IMPORTED_MODULE_19__["default"])(trips, {
      status: 'syncedButNotReturnedFromServer'
    });
    let oldestPendingTripDate = null;
    if (oldestPendingTrip) {
      oldestPendingTripDate = luxon__WEBPACK_IMPORTED_MODULE_16__.DateTime.fromISO(oldestPendingTrip.date).minus({
        minutes: 1
      });
    }
    // find newest not pending trip - aka with first index
    const newestNotPendingTrip = (0,lodash_es__WEBPACK_IMPORTED_MODULE_18__["default"])(trips, {
      status: 'fromServer'
    });
    let newestNotPendingTripDate = null;
    if (newestNotPendingTrip) {
      newestNotPendingTripDate = luxon__WEBPACK_IMPORTED_MODULE_16__.DateTime.fromISO(newestNotPendingTrip.date).plus({
        minutes: 1
      });
    }
    if (triggerType === 'RELOAD_FROM_LAST_TRIP') {
      const oldestTripDate = findOldest([oldestPendingTripDate, newestNotPendingTripDate]);
      const reloadFromLastTime = oldestTripDate || fromDate.forWholePeriod;
      // console.log(
      //   'LT: processing RELOAD_FROM_LAST_TRIP',
      //   oldestTripDate ? 'oldest trip' : 'whole period',
      //   reloadFromLastTime.toFormat('dd MM yyyy HH:mm:ss')
      // );
      return reloadFromLastTime;
    }
    if (triggerType === 'RELOAD_ONLY_PENDING') {
      return oldestPendingTripDate || fromDate.forEmptyPeriod;
    }
    return this.localDataFromDate;
  }
  getTripsFromStorage(fromDateFilter) {
    var _this = this;
    return (0,_Users_smartcommunitylab_Desktop_newWork_playAndGo_playGo_node_modules_babel_runtime_helpers_esm_asyncToGenerator_js__WEBPACK_IMPORTED_MODULE_0__["default"])(function* () {
      const tripsFromStorage = (yield _this.storage.get()) || [];
      return tripsFromStorage.filter(
      // TODO: check for +-1 errors. Otherwise, we could have same trip loaded twice.
      // once from local trips, once from paging.
      trip => fromDateFilter < luxon__WEBPACK_IMPORTED_MODULE_16__.DateTime.fromISO(trip.date));
    })();
  }
  storeTripsToStorage(trips) {
    this.storage.set(trips);
  }
  static #_ = _staticBlock2 = () => (this.ɵfac = function LocalTripsService_Factory(__ngFactoryType__) {
    return new (__ngFactoryType__ || LocalTripsService)(_angular_core__WEBPACK_IMPORTED_MODULE_28__["ɵɵinject"](InitServiceStream), _angular_core__WEBPACK_IMPORTED_MODULE_28__["ɵɵinject"](_services_local_storage_service__WEBPACK_IMPORTED_MODULE_29__.LocalStorageService), _angular_core__WEBPACK_IMPORTED_MODULE_28__["ɵɵinject"](_track_api_service__WEBPACK_IMPORTED_MODULE_30__.TrackApiService), _angular_core__WEBPACK_IMPORTED_MODULE_28__["ɵɵinject"](_background_tracking_service__WEBPACK_IMPORTED_MODULE_31__.BackgroundTrackingService), _angular_core__WEBPACK_IMPORTED_MODULE_28__["ɵɵinject"](_auth_auth_service__WEBPACK_IMPORTED_MODULE_32__.AuthService), _angular_core__WEBPACK_IMPORTED_MODULE_28__["ɵɵinject"](_services_refresher_service__WEBPACK_IMPORTED_MODULE_33__.RefresherService), _angular_core__WEBPACK_IMPORTED_MODULE_28__["ɵɵinject"](_services_notifications_pushNotification_service__WEBPACK_IMPORTED_MODULE_34__.PushNotificationService));
  }, this.ɵprov = /*@__PURE__*/_angular_core__WEBPACK_IMPORTED_MODULE_28__["ɵɵdefineInjectable"]({
    token: LocalTripsService,
    factory: LocalTripsService.ɵfac,
    providedIn: 'root'
  }));
}
_staticBlock2();
function findOldest(dates) {
  return (0,lodash_es__WEBPACK_IMPORTED_MODULE_22__["default"])(dates, date => date ? date.valueOf() : Number.POSITIVE_INFINITY);
}
const NOW = 'NOW';

/***/ }),

/***/ 23477:
/*!******************************************!*\
  !*** ./node_modules/lodash-es/sortBy.js ***!
  \******************************************/
/***/ ((__unused_webpack___webpack_module__, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "default": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var _baseFlatten_js__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./_baseFlatten.js */ 3474);
/* harmony import */ var _baseOrderBy_js__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ./_baseOrderBy.js */ 34253);
/* harmony import */ var _baseRest_js__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! ./_baseRest.js */ 46124);
/* harmony import */ var _isIterateeCall_js__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! ./_isIterateeCall.js */ 41642);





/**
 * Creates an array of elements, sorted in ascending order by the results of
 * running each element in a collection thru each iteratee. This method
 * performs a stable sort, that is, it preserves the original sort order of
 * equal elements. The iteratees are invoked with one argument: (value).
 *
 * @static
 * @memberOf _
 * @since 0.1.0
 * @category Collection
 * @param {Array|Object} collection The collection to iterate over.
 * @param {...(Function|Function[])} [iteratees=[_.identity]]
 *  The iteratees to sort by.
 * @returns {Array} Returns the new sorted array.
 * @example
 *
 * var users = [
 *   { 'user': 'fred',   'age': 48 },
 *   { 'user': 'barney', 'age': 36 },
 *   { 'user': 'fred',   'age': 30 },
 *   { 'user': 'barney', 'age': 34 }
 * ];
 *
 * _.sortBy(users, [function(o) { return o.user; }]);
 * // => objects for [['barney', 36], ['barney', 34], ['fred', 48], ['fred', 30]]
 *
 * _.sortBy(users, ['user', 'age']);
 * // => objects for [['barney', 34], ['barney', 36], ['fred', 30], ['fred', 48]]
 */
var sortBy = (0,_baseRest_js__WEBPACK_IMPORTED_MODULE_2__["default"])(function (collection, iteratees) {
  if (collection == null) {
    return [];
  }
  var length = iteratees.length;
  if (length > 1 && (0,_isIterateeCall_js__WEBPACK_IMPORTED_MODULE_3__["default"])(collection, iteratees[0], iteratees[1])) {
    iteratees = [];
  } else if (length > 2 && (0,_isIterateeCall_js__WEBPACK_IMPORTED_MODULE_3__["default"])(iteratees[0], iteratees[1], iteratees[2])) {
    iteratees = [iteratees[0]];
  }
  return (0,_baseOrderBy_js__WEBPACK_IMPORTED_MODULE_1__["default"])(collection, (0,_baseFlatten_js__WEBPACK_IMPORTED_MODULE_0__["default"])(iteratees, 1), []);
});
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (sortBy);

/***/ }),

/***/ 26376:
/*!**************************************************************!*\
  !*** ./src/app/pages/trips/trip-card/trip-card.component.ts ***!
  \**************************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   TripCardComponent: () => (/* binding */ TripCardComponent)
/* harmony export */ });
/* harmony import */ var _Users_smartcommunitylab_Desktop_newWork_playAndGo_playGo_node_modules_babel_runtime_helpers_esm_asyncToGenerator_js__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./node_modules/@babel/runtime/helpers/esm/asyncToGenerator.js */ 89204);
/* harmony import */ var src_app_core_shared_tracking_trip_model__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! src/app/core/shared/tracking/trip.model */ 23126);
/* harmony import */ var src_app_core_api_generated_model_trackedInstanceInfo__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! src/app/core/api/generated/model/trackedInstanceInfo */ 54286);
/* harmony import */ var src_app_core_shared_utils__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! src/app/core/shared/utils */ 7497);
/* harmony import */ var rxjs__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! rxjs */ 56196);
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! @angular/core */ 34205);
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! @angular/core */ 12481);
/* harmony import */ var _ionic_angular__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(/*! @ionic/angular */ 4059);
/* harmony import */ var _ionic_angular__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(/*! @ionic/angular */ 21507);
/* harmony import */ var _ngx_translate_core__WEBPACK_IMPORTED_MODULE_9__ = __webpack_require__(/*! @ngx-translate/core */ 48503);
/* harmony import */ var src_app_core_shared_services_user_service__WEBPACK_IMPORTED_MODULE_10__ = __webpack_require__(/*! src/app/core/shared/services/user.service */ 89815);
/* harmony import */ var _angular_common__WEBPACK_IMPORTED_MODULE_11__ = __webpack_require__(/*! @angular/common */ 93683);
/* harmony import */ var _core_shared_ui_icon_icon_component__WEBPACK_IMPORTED_MODULE_12__ = __webpack_require__(/*! ../../../core/shared/ui/icon/icon.component */ 59621);
/* harmony import */ var _core_shared_pipes_localDate_pipe__WEBPACK_IMPORTED_MODULE_13__ = __webpack_require__(/*! ../../../core/shared/pipes/localDate.pipe */ 86451);
/* harmony import */ var _core_shared_pipes_localNumber_pipe__WEBPACK_IMPORTED_MODULE_14__ = __webpack_require__(/*! ../../../core/shared/pipes/localNumber.pipe */ 16024);

var _staticBlock;












function TripCardComponent_div_2_span_5_Template(rf, ctx) {
  if (rf & 1) {
    _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵelementStart"](0, "span", 15);
    _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵtext"](1);
    _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵelementEnd"]();
  }
  if (rf & 2) {
    const ctx_r1 = _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵnextContext"](2);
    _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵadvance"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵtextInterpolate2"](" ", ctx_r1.length - (ctx_r1.indexTrip - 1), "/", ctx_r1.length, " ");
  }
}
function TripCardComponent_div_2_Template(rf, ctx) {
  if (rf & 1) {
    _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵelementStart"](0, "div", 12);
    _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵelement"](1, "app-icon", 13);
    _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵelementStart"](2, "span");
    _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵtext"](3);
    _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵpipe"](4, "translate");
    _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵelementEnd"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵtemplate"](5, TripCardComponent_div_2_span_5_Template, 2, 2, "span", 14);
    _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵelementEnd"]();
  }
  if (rf & 2) {
    const ctx_r1 = _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵnextContext"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵadvance"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵproperty"]("name", ctx_r1.getTransportTypeIcon(ctx_r1.trip.modeType));
    _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵadvance"](2);
    _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵtextInterpolate1"](" ", _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵpipeBind1"](4, 3, ctx_r1.getTransportTypeLabel(ctx_r1.trip.modeType)), " ");
    _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵadvance"](2);
    _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵproperty"]("ngIf", ctx_r1.indexTrip && ctx_r1.length);
  }
}
function TripCardComponent_span_4_Template(rf, ctx) {
  if (rf & 1) {
    _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵelementStart"](0, "span")(1, "span", 16);
    _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵtext"](2);
    _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵpipe"](3, "localDate");
    _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵelementEnd"]()();
  }
  if (rf & 2) {
    const ctx_r1 = _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵnextContext"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵadvance"](2);
    _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵtextInterpolate1"](" ", _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵpipeBind2"](3, 1, ctx_r1.trip.startTime, ctx_r1.noMonthOrYearFormat), " ");
  }
}
function TripCardComponent_span_7_Template(rf, ctx) {
  if (rf & 1) {
    _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵelementStart"](0, "span");
    _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵtext"](1);
    _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵpipe"](2, "localNumber");
    _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵpipe"](3, "translate");
    _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵelementEnd"]();
  }
  if (rf & 2) {
    const ctx_r1 = _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵnextContext"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵadvance"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵtextInterpolate3"]("", _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵpipeBind2"](2, 3, ctx_r1.trip.distance / 1000, "0.0-1"), " ", _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵpipeBind1"](3, 6, "km"), " - ", ctx_r1.durationLabel);
  }
}
function TripCardComponent_ng_template_8_Template(rf, ctx) {
  if (rf & 1) {
    _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵelementStart"](0, "span");
    _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵtext"](1);
    _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵpipe"](2, "translate");
    _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵelementEnd"]();
  }
  if (rf & 2) {
    _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵadvance"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵtextInterpolate1"](" - ", _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵpipeBind1"](2, 1, "km"), " / - min ");
  }
}
function TripCardComponent_ion_text_11_span_1_Template(rf, ctx) {
  if (rf & 1) {
    _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵelementStart"](0, "span");
    _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵtext"](1);
    _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵpipe"](2, "translate");
    _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵelementEnd"]();
  }
  if (rf & 2) {
    _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵadvance"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵtextInterpolate1"](" ", _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵpipeBind1"](2, 1, "trip_detail.status.validation"), " ");
  }
}
function TripCardComponent_ion_text_11_ng_template_2_Template(rf, ctx) {
  if (rf & 1) {
    _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵelementStart"](0, "span");
    _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵtext"](1);
    _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵelementEnd"]();
  }
  if (rf & 2) {
    const ctx_r1 = _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵnextContext"](2);
    _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵadvance"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵtextInterpolate"](ctx_r1.validCampaignsLabel);
  }
}
function TripCardComponent_ion_text_11_Template(rf, ctx) {
  if (rf & 1) {
    _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵelementStart"](0, "ion-text", 17);
    _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵtemplate"](1, TripCardComponent_ion_text_11_span_1_Template, 3, 3, "span", 8)(2, TripCardComponent_ion_text_11_ng_template_2_Template, 2, 1, "ng-template", null, 1, _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵtemplateRefExtractor"]);
    _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵelementEnd"]();
  }
  if (rf & 2) {
    const valid_r3 = _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵreference"](3);
    const ctx_r1 = _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵnextContext"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵproperty"]("color", ctx_r1.oneCampaignUnassigned(ctx_r1.trip) ? "yellowplaygo" : "greenplaygo");
    _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵadvance"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵproperty"]("ngIf", ctx_r1.oneCampaignUnassigned(ctx_r1.trip))("ngIfElse", valid_r3);
  }
}
function TripCardComponent_ion_text_12_Template(rf, ctx) {
  if (rf & 1) {
    _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵelementStart"](0, "ion-text", 18);
    _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵtext"](1);
    _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵpipe"](2, "translate");
    _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵelementEnd"]();
  }
  if (rf & 2) {
    _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵadvance"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵtextInterpolate"](_angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵpipeBind1"](2, 1, "trip_detail.status.invalid"));
  }
}
function TripCardComponent_ion_text_13_Template(rf, ctx) {
  if (rf & 1) {
    _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵelementStart"](0, "ion-text", 19);
    _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵtext"](1);
    _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵpipe"](2, "translate");
    _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵelementEnd"]();
  }
  if (rf & 2) {
    _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵadvance"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵtextInterpolate"](_angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵpipeBind1"](2, 1, "trip_detail.status.pending"));
  }
}
function TripCardComponent_ion_text_14_Template(rf, ctx) {
  if (rf & 1) {
    _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵelementStart"](0, "ion-text", 19);
    _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵtext"](1);
    _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵpipe"](2, "translate");
    _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵelementEnd"]();
  }
  if (rf & 2) {
    _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵadvance"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵtextInterpolate"](_angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵpipeBind1"](2, 1, "trip_detail.status.not_synchronized"));
  }
}
function TripCardComponent_ion_text_15_Template(rf, ctx) {
  if (rf & 1) {
    _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵelementStart"](0, "ion-text", 19);
    _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵtext"](1);
    _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵpipe"](2, "translate");
    _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵelementEnd"]();
  }
  if (rf & 2) {
    _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵadvance"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵtextInterpolate"](_angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵpipeBind1"](2, 1, "trip_detail.status.not_finished"));
  }
}
class TripCardComponent {
  constructor(navController, translateService, userService) {
    this.navController = navController;
    this.translateService = translateService;
    this.userService = userService;
    this.getTransportTypeLabel = src_app_core_shared_tracking_trip_model__WEBPACK_IMPORTED_MODULE_1__.getTransportTypeLabel;
    this.getTransportTypeIcon = src_app_core_shared_tracking_trip_model__WEBPACK_IMPORTED_MODULE_1__.getTransportTypeIcon;
    // eslint-disable-next-line @typescript-eslint/naming-convention
    this.Validity = src_app_core_api_generated_model_trackedInstanceInfo__WEBPACK_IMPORTED_MODULE_2__.TrackedInstanceInfo.ValidityEnum;
    this.isOneDayTrip = true;
    this.multiModalTrip = false;
    this.validCampaignsLabel = '';
    this.durationLabel = '';
    this.noMonthOrYearFormat = {
      weekday: 'long',
      day: 'numeric',
      hour: 'numeric',
      minute: 'numeric'
    };
  }
  openDetail() {
    if (this.isLocal(this.trip)) {
      return;
    }
    this.navController.navigateForward(['/pages/tabs/trips/trip/', this.trip.trackedInstanceId]);
  }
  isLocal(trip) {
    return trip.status === 'NOT_SYNCHRONIZED' || trip.status === 'ONGOING';
  }
  oneCampaignUnassigned(trip) {
    return trip.campaigns?.some(campaign => campaign.scoreStatus === 'UNASSIGNED');
  }
  ngOnInit() {
    if (!this.trip) {
      throw new Error('Trip is not defined');
    }
  }
  ngOnChanges() {
    var _this = this;
    return (0,_Users_smartcommunitylab_Desktop_newWork_playAndGo_playGo_node_modules_babel_runtime_helpers_esm_asyncToGenerator_js__WEBPACK_IMPORTED_MODULE_0__["default"])(function* () {
      _this.durationLabel = (0,src_app_core_shared_utils__WEBPACK_IMPORTED_MODULE_3__.formatDurationToHoursAndMinutes)(_this.trip.endTime - _this.trip.startTime);
      _this.validCampaignsLabel = yield _this.getCampaignsLabel();
    })();
  }
  getCampaignsLabel() {
    var _this2 = this;
    return (0,_Users_smartcommunitylab_Desktop_newWork_playAndGo_playGo_node_modules_babel_runtime_helpers_esm_asyncToGenerator_js__WEBPACK_IMPORTED_MODULE_0__["default"])(function* () {
      const numberOfValidCampaigns = _this2.trip.campaigns.filter(campaign => campaign.valid).length;
      const pluralRules = yield (0,rxjs__WEBPACK_IMPORTED_MODULE_4__.firstValueFrom)(_this2.userService.pluralRules$);
      const pluralForm = pluralRules.select(numberOfValidCampaigns);
      const translated = yield (0,rxjs__WEBPACK_IMPORTED_MODULE_4__.firstValueFrom)(_this2.translateService.get('trip_detail.valid_for_campaigns.plural_form.' + pluralForm, {
        count: numberOfValidCampaigns
      }));
      return translated;
    })();
  }
  static #_ = _staticBlock = () => (this.ɵfac = function TripCardComponent_Factory(__ngFactoryType__) {
    return new (__ngFactoryType__ || TripCardComponent)(_angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵdirectiveInject"](_ionic_angular__WEBPACK_IMPORTED_MODULE_7__.NavController), _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵdirectiveInject"](_ngx_translate_core__WEBPACK_IMPORTED_MODULE_9__.TranslateService), _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵdirectiveInject"](src_app_core_shared_services_user_service__WEBPACK_IMPORTED_MODULE_10__.UserService));
  }, this.ɵcmp = /*@__PURE__*/_angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵdefineComponent"]({
    type: TripCardComponent,
    selectors: [["app-trip-card"]],
    inputs: {
      trip: "trip",
      isOneDayTrip: "isOneDayTrip",
      multiModalTrip: "multiModalTrip",
      indexTrip: "indexTrip",
      length: "length"
    },
    standalone: false,
    features: [_angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵNgOnChangesFeature"]],
    decls: 16,
    vars: 9,
    consts: [["noDistance", ""], ["valid", ""], ["button", "", "detail", "", 3, "click"], ["size", "4"], ["class", "trip-mode", 4, "ngIf"], [1, "ion-text-end"], [4, "ngIf"], [1, "ion-text-start", "time-distance"], [4, "ngIf", "ngIfElse"], [3, "color", 4, "ngIf"], ["color", "redplaygo", 4, "ngIf"], ["color", "yellowplaygo", 4, "ngIf"], [1, "trip-mode"], [3, "name"], ["class", "subnumber", 4, "ngIf"], [1, "subnumber"], [1, "date"], [3, "color"], ["color", "redplaygo"], ["color", "yellowplaygo"]],
    template: function TripCardComponent_Template(rf, ctx) {
      if (rf & 1) {
        const _r1 = _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵgetCurrentView"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵelementStart"](0, "ion-row", 2);
        _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵlistener"]("click", function TripCardComponent_Template_ion_row_click_0_listener() {
          _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵrestoreView"](_r1);
          return _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵresetView"](ctx.openDetail());
        });
        _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵelementStart"](1, "ion-col", 3);
        _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵtemplate"](2, TripCardComponent_div_2_Template, 6, 5, "div", 4);
        _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵelementStart"](3, "ion-col", 5);
        _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵtemplate"](4, TripCardComponent_span_4_Template, 4, 4, "span", 6);
        _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵelementEnd"]()();
        _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵelementStart"](5, "ion-row", 2);
        _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵlistener"]("click", function TripCardComponent_Template_ion_row_click_5_listener() {
          _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵrestoreView"](_r1);
          return _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵresetView"](ctx.openDetail());
        });
        _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵelementStart"](6, "ion-col", 7);
        _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵtemplate"](7, TripCardComponent_span_7_Template, 4, 8, "span", 8)(8, TripCardComponent_ng_template_8_Template, 3, 3, "ng-template", null, 0, _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵtemplateRefExtractor"]);
        _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵelementStart"](10, "ion-col", 5);
        _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵtemplate"](11, TripCardComponent_ion_text_11_Template, 4, 3, "ion-text", 9)(12, TripCardComponent_ion_text_12_Template, 3, 3, "ion-text", 10)(13, TripCardComponent_ion_text_13_Template, 3, 3, "ion-text", 11)(14, TripCardComponent_ion_text_14_Template, 3, 3, "ion-text", 11)(15, TripCardComponent_ion_text_15_Template, 3, 3, "ion-text", 11);
        _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵelementEnd"]()();
      }
      if (rf & 2) {
        const noDistance_r4 = _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵreference"](9);
        _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵadvance"](2);
        _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵproperty"]("ngIf", ctx.trip.modeType);
        _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵadvance"](2);
        _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵproperty"]("ngIf", !ctx.multiModalTrip);
        _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵadvance"](3);
        _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵproperty"]("ngIf", ctx.trip.distance)("ngIfElse", noDistance_r4);
        _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵadvance"](4);
        _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵproperty"]("ngIf", ctx.trip.status === ctx.Validity.VALID);
        _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵadvance"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵproperty"]("ngIf", ctx.trip.status === ctx.Validity.INVALID);
        _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵadvance"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵproperty"]("ngIf", ctx.trip.status === ctx.Validity.PENDING);
        _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵadvance"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵproperty"]("ngIf", ctx.trip.status === "NOT_SYNCHRONIZED");
        _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵadvance"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵproperty"]("ngIf", ctx.trip.status === "ONGOING");
      }
    },
    dependencies: [_angular_common__WEBPACK_IMPORTED_MODULE_11__.NgIf, _ionic_angular__WEBPACK_IMPORTED_MODULE_8__.IonCol, _ionic_angular__WEBPACK_IMPORTED_MODULE_8__.IonRow, _ionic_angular__WEBPACK_IMPORTED_MODULE_8__.IonText, _core_shared_ui_icon_icon_component__WEBPACK_IMPORTED_MODULE_12__.IconComponent, _ngx_translate_core__WEBPACK_IMPORTED_MODULE_9__.TranslatePipe, _core_shared_pipes_localDate_pipe__WEBPACK_IMPORTED_MODULE_13__.LocalDatePipe, _core_shared_pipes_localNumber_pipe__WEBPACK_IMPORTED_MODULE_14__.LocalNumberPipe],
    styles: ["ion-col[_ngcontent-%COMP%] {\n  color: var(--dark-grey);\n}\n\n.date[_ngcontent-%COMP%] {\n  font-size: 14px;\n  font-weight: 500;\n}\n\n.time-distance[_ngcontent-%COMP%] {\n  font-size: 17px;\n  font-weight: 500;\n}\n\n.trip-mode[_ngcontent-%COMP%] {\n  display: flex;\n}\n.trip-mode[_ngcontent-%COMP%]   app-icon[_ngcontent-%COMP%] {\n  font-size: 24px;\n}\n.trip-mode[_ngcontent-%COMP%]   span[_ngcontent-%COMP%] {\n  margin-left: 20px;\n  font-size: 18px;\n  flex-direction: column;\n  display: flex;\n  justify-content: center;\n}\n.trip-mode[_ngcontent-%COMP%]   .subnumber[_ngcontent-%COMP%] {\n  color: #92949c;\n  font-size: 16px;\n}\n\nion-text[_ngcontent-%COMP%] {\n  font-style: italic;\n  font-size: 12px;\n  font-weight: 600;\n}\n/*# sourceMappingURL=data:application/json;charset=utf-8;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbIndlYnBhY2s6Ly8uL3NyYy9hcHAvcGFnZXMvdHJpcHMvdHJpcC1jYXJkL3RyaXAtY2FyZC5jb21wb25lbnQuc2NzcyJdLCJuYW1lcyI6W10sIm1hcHBpbmdzIjoiQUFBQTtFQUVFLHVCQUFBO0FBQUY7O0FBRUE7RUFDRSxlQUFBO0VBQ0EsZ0JBQUE7QUFDRjs7QUFDQTtFQUNFLGVBQUE7RUFDQSxnQkFBQTtBQUVGOztBQUFBO0VBQ0UsYUFBQTtBQUdGO0FBRkU7RUFDRSxlQUFBO0FBSUo7QUFGRTtFQUNFLGlCQUFBO0VBQ0EsZUFBQTtFQUVBLHNCQUFBO0VBQ0EsYUFBQTtFQUNBLHVCQUFBO0FBR0o7QUFERTtFQUNFLGNBQUE7RUFDQSxlQUFBO0FBR0o7O0FBQUE7RUFDRSxrQkFBQTtFQUNBLGVBQUE7RUFDQSxnQkFBQTtBQUdGIiwic291cmNlc0NvbnRlbnQiOlsiaW9uLWNvbCB7XG4gIC8vIG91dGxpbmU6IDFweCBzb2xpZCByZWQ7XG4gIGNvbG9yOiB2YXIoLS1kYXJrLWdyZXkpO1xufVxuLmRhdGUge1xuICBmb250LXNpemU6IDE0cHg7XG4gIGZvbnQtd2VpZ2h0OiA1MDA7XG59XG4udGltZS1kaXN0YW5jZSB7XG4gIGZvbnQtc2l6ZTogMTdweDtcbiAgZm9udC13ZWlnaHQ6IDUwMDtcbn1cbi50cmlwLW1vZGUge1xuICBkaXNwbGF5OiBmbGV4O1xuICBhcHAtaWNvbiB7XG4gICAgZm9udC1zaXplOiAyNHB4O1xuICB9XG4gIHNwYW4ge1xuICAgIG1hcmdpbi1sZWZ0OiAyMHB4O1xuICAgIGZvbnQtc2l6ZTogMThweDtcblxuICAgIGZsZXgtZGlyZWN0aW9uOiBjb2x1bW47XG4gICAgZGlzcGxheTogZmxleDtcbiAgICBqdXN0aWZ5LWNvbnRlbnQ6IGNlbnRlcjtcbiAgfVxuICAuc3VibnVtYmVyIHtcbiAgICBjb2xvcjogIzkyOTQ5YztcbiAgICBmb250LXNpemU6IDE2cHg7XG4gIH1cbn1cbmlvbi10ZXh0IHtcbiAgZm9udC1zdHlsZTogaXRhbGljO1xuICBmb250LXNpemU6IDEycHg7XG4gIGZvbnQtd2VpZ2h0OiA2MDA7XG59XG4iXSwic291cmNlUm9vdCI6IiJ9 */"]
  }));
}
_staticBlock();

/***/ }),

/***/ 28320:
/*!****************************************!*\
  !*** ./node_modules/lodash-es/some.js ***!
  \****************************************/
/***/ ((__unused_webpack___webpack_module__, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "default": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var _arraySome_js__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./_arraySome.js */ 20658);
/* harmony import */ var _baseIteratee_js__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ./_baseIteratee.js */ 65679);
/* harmony import */ var _baseSome_js__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! ./_baseSome.js */ 63658);
/* harmony import */ var _isArray_js__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! ./isArray.js */ 19247);
/* harmony import */ var _isIterateeCall_js__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! ./_isIterateeCall.js */ 41642);






/**
 * Checks if `predicate` returns truthy for **any** element of `collection`.
 * Iteration is stopped once `predicate` returns truthy. The predicate is
 * invoked with three arguments: (value, index|key, collection).
 *
 * @static
 * @memberOf _
 * @since 0.1.0
 * @category Collection
 * @param {Array|Object} collection The collection to iterate over.
 * @param {Function} [predicate=_.identity] The function invoked per iteration.
 * @param- {Object} [guard] Enables use as an iteratee for methods like `_.map`.
 * @returns {boolean} Returns `true` if any element passes the predicate check,
 *  else `false`.
 * @example
 *
 * _.some([null, 0, 'yes', false], Boolean);
 * // => true
 *
 * var users = [
 *   { 'user': 'barney', 'active': true },
 *   { 'user': 'fred',   'active': false }
 * ];
 *
 * // The `_.matches` iteratee shorthand.
 * _.some(users, { 'user': 'barney', 'active': false });
 * // => false
 *
 * // The `_.matchesProperty` iteratee shorthand.
 * _.some(users, ['active', false]);
 * // => true
 *
 * // The `_.property` iteratee shorthand.
 * _.some(users, 'active');
 * // => true
 */
function some(collection, predicate, guard) {
  var func = (0,_isArray_js__WEBPACK_IMPORTED_MODULE_3__["default"])(collection) ? _arraySome_js__WEBPACK_IMPORTED_MODULE_0__["default"] : _baseSome_js__WEBPACK_IMPORTED_MODULE_2__["default"];
  if (guard && (0,_isIterateeCall_js__WEBPACK_IMPORTED_MODULE_4__["default"])(collection, predicate, guard)) {
    predicate = undefined;
  }
  return func(collection, (0,_baseIteratee_js__WEBPACK_IMPORTED_MODULE_1__["default"])(predicate, 3));
}
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (some);

/***/ }),

/***/ 30158:
/*!**************************************************************************!*\
  !*** ./node_modules/backoff-rxjs/dist/esm2015/operators/retryBackoff.js ***!
  \**************************************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   retryBackoff: () => (/* binding */ retryBackoff)
/* harmony export */ });
/* harmony import */ var rxjs__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! rxjs */ 137);
/* harmony import */ var rxjs__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! rxjs */ 47697);
/* harmony import */ var rxjs__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! rxjs */ 77919);
/* harmony import */ var rxjs__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! rxjs */ 14876);
/* harmony import */ var rxjs__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! rxjs */ 51903);
/* harmony import */ var rxjs__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! rxjs */ 72611);
/* harmony import */ var rxjs__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! rxjs */ 98764);
/* harmony import */ var _utils__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(/*! ../utils */ 3417);


function retryBackoff(config) {
  const {
    initialInterval,
    maxRetries = Infinity,
    maxInterval = Infinity,
    shouldRetry = () => true,
    resetOnSuccess = false,
    backoffDelay = _utils__WEBPACK_IMPORTED_MODULE_7__.exponentialBackoffDelay
  } = typeof config === 'number' ? {
    initialInterval: config
  } : config;
  return source => (0,rxjs__WEBPACK_IMPORTED_MODULE_0__.defer)(() => {
    let index = 0;
    return source.pipe((0,rxjs__WEBPACK_IMPORTED_MODULE_5__.retryWhen)(errors => errors.pipe((0,rxjs__WEBPACK_IMPORTED_MODULE_4__.concatMap)(error => {
      const attempt = index++;
      return (0,rxjs__WEBPACK_IMPORTED_MODULE_1__.iif)(() => attempt < maxRetries && shouldRetry(error), (0,rxjs__WEBPACK_IMPORTED_MODULE_3__.timer)((0,_utils__WEBPACK_IMPORTED_MODULE_7__.getDelay)(backoffDelay(attempt, initialInterval), maxInterval)), (0,rxjs__WEBPACK_IMPORTED_MODULE_2__.throwError)(error));
    }))), (0,rxjs__WEBPACK_IMPORTED_MODULE_6__.tap)(() => {
      if (resetOnSuccess) {
        index = 0;
      }
    }));
  });
}

/***/ }),

/***/ 34253:
/*!************************************************!*\
  !*** ./node_modules/lodash-es/_baseOrderBy.js ***!
  \************************************************/
/***/ ((__unused_webpack___webpack_module__, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "default": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var _arrayMap_js__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./_arrayMap.js */ 7786);
/* harmony import */ var _baseGet_js__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ./_baseGet.js */ 59484);
/* harmony import */ var _baseIteratee_js__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! ./_baseIteratee.js */ 65679);
/* harmony import */ var _baseMap_js__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! ./_baseMap.js */ 87554);
/* harmony import */ var _baseSortBy_js__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! ./_baseSortBy.js */ 40055);
/* harmony import */ var _baseUnary_js__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! ./_baseUnary.js */ 45583);
/* harmony import */ var _compareMultiple_js__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! ./_compareMultiple.js */ 59216);
/* harmony import */ var _identity_js__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(/*! ./identity.js */ 45618);
/* harmony import */ var _isArray_js__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(/*! ./isArray.js */ 19247);










/**
 * The base implementation of `_.orderBy` without param guards.
 *
 * @private
 * @param {Array|Object} collection The collection to iterate over.
 * @param {Function[]|Object[]|string[]} iteratees The iteratees to sort by.
 * @param {string[]} orders The sort orders of `iteratees`.
 * @returns {Array} Returns the new sorted array.
 */
function baseOrderBy(collection, iteratees, orders) {
  if (iteratees.length) {
    iteratees = (0,_arrayMap_js__WEBPACK_IMPORTED_MODULE_0__["default"])(iteratees, function (iteratee) {
      if ((0,_isArray_js__WEBPACK_IMPORTED_MODULE_8__["default"])(iteratee)) {
        return function (value) {
          return (0,_baseGet_js__WEBPACK_IMPORTED_MODULE_1__["default"])(value, iteratee.length === 1 ? iteratee[0] : iteratee);
        };
      }
      return iteratee;
    });
  } else {
    iteratees = [_identity_js__WEBPACK_IMPORTED_MODULE_7__["default"]];
  }
  var index = -1;
  iteratees = (0,_arrayMap_js__WEBPACK_IMPORTED_MODULE_0__["default"])(iteratees, (0,_baseUnary_js__WEBPACK_IMPORTED_MODULE_5__["default"])(_baseIteratee_js__WEBPACK_IMPORTED_MODULE_2__["default"]));
  var result = (0,_baseMap_js__WEBPACK_IMPORTED_MODULE_3__["default"])(collection, function (value, key, collection) {
    var criteria = (0,_arrayMap_js__WEBPACK_IMPORTED_MODULE_0__["default"])(iteratees, function (iteratee) {
      return iteratee(value);
    });
    return {
      'criteria': criteria,
      'index': ++index,
      'value': value
    };
  });
  return (0,_baseSortBy_js__WEBPACK_IMPORTED_MODULE_4__["default"])(result, function (object, other) {
    return (0,_compareMultiple_js__WEBPACK_IMPORTED_MODULE_6__["default"])(object, other, orders);
  });
}
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (baseOrderBy);

/***/ }),

/***/ 39499:
/*!***********************************************************!*\
  !*** ./src/app/core/shared/tracking/track-api.service.ts ***!
  \***********************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   TrackApiService: () => (/* binding */ TrackApiService)
/* harmony export */ });
/* harmony import */ var _Users_smartcommunitylab_Desktop_newWork_playAndGo_playGo_node_modules_babel_runtime_helpers_esm_asyncToGenerator_js__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./node_modules/@babel/runtime/helpers/esm/asyncToGenerator.js */ 89204);
/* harmony import */ var rxjs__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! rxjs */ 56196);
/* harmony import */ var rxjs__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! rxjs */ 70271);
/* harmony import */ var _trip_model__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! ./trip.model */ 23126);
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! @angular/core */ 34205);
/* harmony import */ var _api_generated_controllers_trackController_service__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! ../../api/generated/controllers/trackController.service */ 97757);

var _staticBlock;




class TrackApiService {
  constructor(trackControllerService) {
    this.trackControllerService = trackControllerService;
  }
  getTrackedInstanceInfoList(args) {
    return this.trackControllerService.getTrackedInstanceInfoListUsingGET(args).pipe((0,rxjs__WEBPACK_IMPORTED_MODULE_2__.map)(response => this.normalizeTripsResponse(response)));
  }
  getTrackedInstanceInfoDetail(id) {
    var _this = this;
    return (0,_Users_smartcommunitylab_Desktop_newWork_playAndGo_playGo_node_modules_babel_runtime_helpers_esm_asyncToGenerator_js__WEBPACK_IMPORTED_MODULE_0__["default"])(function* () {
      const trip = yield (0,rxjs__WEBPACK_IMPORTED_MODULE_1__.firstValueFrom)(_this.trackControllerService.getTrackedInstanceInfoUsingGET1({
        trackedInstanceId: id
      }));
      return _this.normalizeTrip(trip);
    })();
  }
  normalizeTripsResponse(response) {
    return {
      ...response,
      content: response?.content?.map(trip => this.normalizeTrip(trip))
    };
  }
  normalizeTrip(trip) {
    if (!trip) {
      return trip;
    }
    return {
      ...trip,
      modeType: this.getTripMode(trip)
    };
  }
  getTripMode(trip) {
    const unknownMode = 'unknown';
    if (!trip) {
      return unknownMode;
    }
    if (trip.modeType) {
      return trip.modeType;
    }
    const modeFromId = _trip_model__WEBPACK_IMPORTED_MODULE_3__.transportTypes.find(eachType => trip?.clientId?.startsWith(eachType + '_'));
    if (modeFromId) {
      return modeFromId;
    }
    return unknownMode;
  }
  static #_ = _staticBlock = () => (this.ɵfac = function TrackApiService_Factory(__ngFactoryType__) {
    return new (__ngFactoryType__ || TrackApiService)(_angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵinject"](_api_generated_controllers_trackController_service__WEBPACK_IMPORTED_MODULE_5__.TrackControllerService));
  }, this.ɵprov = /*@__PURE__*/_angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵdefineInjectable"]({
    token: TrackApiService,
    factory: TrackApiService.ɵfac,
    providedIn: 'root'
  }));
}
_staticBlock();

/***/ }),

/***/ 40055:
/*!***********************************************!*\
  !*** ./node_modules/lodash-es/_baseSortBy.js ***!
  \***********************************************/
/***/ ((__unused_webpack___webpack_module__, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "default": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/**
 * The base implementation of `_.sortBy` which uses `comparer` to define the
 * sort order of `array` and replaces criteria objects with their corresponding
 * values.
 *
 * @private
 * @param {Array} array The array to sort.
 * @param {Function} comparer The function to define sort order.
 * @returns {Array} Returns `array`.
 */
function baseSortBy(array, comparer) {
  var length = array.length;
  array.sort(comparer);
  while (length--) {
    array[length] = array[length].value;
  }
  return array;
}
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (baseSortBy);

/***/ }),

/***/ 49107:
/*!*****************************************************!*\
  !*** ./src/app/pages/trips/trips-routing.module.ts ***!
  \*****************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   TripsPageRoutingModule: () => (/* binding */ TripsPageRoutingModule)
/* harmony export */ });
/* harmony import */ var _angular_router__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! @angular/router */ 34487);
/* harmony import */ var _trips_page__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ./trips.page */ 91029);
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @angular/core */ 34205);
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @angular/core */ 12481);
var _staticBlock;




const routes = [{
  path: '',
  component: _trips_page__WEBPACK_IMPORTED_MODULE_1__.TripsPage,
  data: {
    title: 'tripsTitle',
    backButton: false,
    isOfflinePage: true,
    showPlayButton: true,
    refresher: true
  }
}, {
  path: 'campaign/:id',
  component: _trips_page__WEBPACK_IMPORTED_MODULE_1__.TripsPage,
  data: {
    title: 'tripsTitle',
    defaultHref: '/',
    backButton: false,
    isOfflinePage: true,
    showPlayButton: true,
    refresher: true
  }
}, {
  path: 'trip/:id',
  loadChildren: () => __webpack_require__.e(/*! import() */ "src_app_pages_trips_trip-detail_trip-detail_module_ts").then(__webpack_require__.bind(__webpack_require__, /*! ./trip-detail/trip-detail.module */ 11735)).then(m => m.TripDetailPageModule)
}, {
  path: 'campaign-detail/:id',
  loadChildren: () => __webpack_require__.e(/*! import() */ "default-src_app_pages_home_campaign-details_campaign-details_module_ts").then(__webpack_require__.bind(__webpack_require__, /*! ../home/campaign-details/campaign-details.module */ 49658)).then(m => m.CampaignDetailsPageModule)
}];
class TripsPageRoutingModule {
  static #_ = _staticBlock = () => (this.ɵfac = function TripsPageRoutingModule_Factory(__ngFactoryType__) {
    return new (__ngFactoryType__ || TripsPageRoutingModule)();
  }, this.ɵmod = /*@__PURE__*/_angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵdefineNgModule"]({
    type: TripsPageRoutingModule
  }), this.ɵinj = /*@__PURE__*/_angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵdefineInjector"]({
    imports: [_angular_router__WEBPACK_IMPORTED_MODULE_0__.RouterModule.forChild(routes), _angular_router__WEBPACK_IMPORTED_MODULE_0__.RouterModule]
  }));
}
_staticBlock();
(function () {
  (typeof ngJitMode === "undefined" || ngJitMode) && _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵsetNgModuleScope"](TripsPageRoutingModule, {
    imports: [_angular_router__WEBPACK_IMPORTED_MODULE_0__.RouterModule],
    exports: [_angular_router__WEBPACK_IMPORTED_MODULE_0__.RouterModule]
  });
})();

/***/ }),

/***/ 54286:
/*!*****************************************************************!*\
  !*** ./src/app/core/api/generated/model/trackedInstanceInfo.ts ***!
  \*****************************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   TrackedInstanceInfo: () => (/* binding */ TrackedInstanceInfo)
/* harmony export */ });
var TrackedInstanceInfo;
(function (TrackedInstanceInfo) {
  TrackedInstanceInfo.ValidityEnum = {
    INVALID: 'INVALID',
    PENDING: 'PENDING',
    VALID: 'VALID'
  };
})(TrackedInstanceInfo || (TrackedInstanceInfo = {}));

/***/ }),

/***/ 55679:
/*!******************************************************************************!*\
  !*** ./node_modules/backoff-rxjs/dist/esm2015/observable/intervalBackoff.js ***!
  \******************************************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   intervalBackoff: () => (/* binding */ intervalBackoff)
/* harmony export */ });
/* harmony import */ var rxjs__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! rxjs */ 18473);
/* harmony import */ var rxjs__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! rxjs */ 59452);
/* harmony import */ var rxjs__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! rxjs */ 14876);
/* harmony import */ var rxjs__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! rxjs */ 98445);
/* harmony import */ var rxjs__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! rxjs */ 87378);
/* harmony import */ var _utils__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! ../utils */ 3417);


function intervalBackoff(config, scheduler = rxjs__WEBPACK_IMPORTED_MODULE_0__.asyncScheduler) {
  let {
    initialInterval,
    maxInterval = Infinity,
    backoffDelay = _utils__WEBPACK_IMPORTED_MODULE_5__.exponentialBackoffDelay
  } = typeof config === 'number' ? {
    initialInterval: config
  } : config;
  initialInterval = initialInterval < 0 ? 0 : initialInterval;
  return (0,rxjs__WEBPACK_IMPORTED_MODULE_1__.of)(0, scheduler).pipe((0,rxjs__WEBPACK_IMPORTED_MODULE_3__.expand)(iteration => (0,rxjs__WEBPACK_IMPORTED_MODULE_2__.timer)((0,_utils__WEBPACK_IMPORTED_MODULE_5__.getDelay)(backoffDelay(iteration, initialInterval), maxInterval)).pipe((0,rxjs__WEBPACK_IMPORTED_MODULE_4__.mapTo)(iteration + 1))));
}

/***/ }),

/***/ 58023:
/*!*************************************************!*\
  !*** ./node_modules/lodash-es/findLastIndex.js ***!
  \*************************************************/
/***/ ((__unused_webpack___webpack_module__, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "default": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var _baseFindIndex_js__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./_baseFindIndex.js */ 14681);
/* harmony import */ var _baseIteratee_js__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ./_baseIteratee.js */ 65679);
/* harmony import */ var _toInteger_js__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! ./toInteger.js */ 93531);




/* Built-in method references for those with the same name as other `lodash` methods. */
var nativeMax = Math.max,
  nativeMin = Math.min;

/**
 * This method is like `_.findIndex` except that it iterates over elements
 * of `collection` from right to left.
 *
 * @static
 * @memberOf _
 * @since 2.0.0
 * @category Array
 * @param {Array} array The array to inspect.
 * @param {Function} [predicate=_.identity] The function invoked per iteration.
 * @param {number} [fromIndex=array.length-1] The index to search from.
 * @returns {number} Returns the index of the found element, else `-1`.
 * @example
 *
 * var users = [
 *   { 'user': 'barney',  'active': true },
 *   { 'user': 'fred',    'active': false },
 *   { 'user': 'pebbles', 'active': false }
 * ];
 *
 * _.findLastIndex(users, function(o) { return o.user == 'pebbles'; });
 * // => 2
 *
 * // The `_.matches` iteratee shorthand.
 * _.findLastIndex(users, { 'user': 'barney', 'active': true });
 * // => 0
 *
 * // The `_.matchesProperty` iteratee shorthand.
 * _.findLastIndex(users, ['active', false]);
 * // => 2
 *
 * // The `_.property` iteratee shorthand.
 * _.findLastIndex(users, 'active');
 * // => 0
 */
function findLastIndex(array, predicate, fromIndex) {
  var length = array == null ? 0 : array.length;
  if (!length) {
    return -1;
  }
  var index = length - 1;
  if (fromIndex !== undefined) {
    index = (0,_toInteger_js__WEBPACK_IMPORTED_MODULE_2__["default"])(fromIndex);
    index = fromIndex < 0 ? nativeMax(length + index, 0) : nativeMin(index, length - 1);
  }
  return (0,_baseFindIndex_js__WEBPACK_IMPORTED_MODULE_0__["default"])(array, (0,_baseIteratee_js__WEBPACK_IMPORTED_MODULE_1__["default"])(predicate, 3), index, true);
}
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (findLastIndex);

/***/ }),

/***/ 59216:
/*!****************************************************!*\
  !*** ./node_modules/lodash-es/_compareMultiple.js ***!
  \****************************************************/
/***/ ((__unused_webpack___webpack_module__, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "default": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var _compareAscending_js__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./_compareAscending.js */ 94120);


/**
 * Used by `_.orderBy` to compare multiple properties of a value to another
 * and stable sort them.
 *
 * If `orders` is unspecified, all values are sorted in ascending order. Otherwise,
 * specify an order of "desc" for descending or "asc" for ascending sort order
 * of corresponding values.
 *
 * @private
 * @param {Object} object The object to compare.
 * @param {Object} other The other object to compare.
 * @param {boolean[]|string[]} orders The order to sort by for each property.
 * @returns {number} Returns the sort order indicator for `object`.
 */
function compareMultiple(object, other, orders) {
  var index = -1,
    objCriteria = object.criteria,
    othCriteria = other.criteria,
    length = objCriteria.length,
    ordersLength = orders.length;
  while (++index < length) {
    var result = (0,_compareAscending_js__WEBPACK_IMPORTED_MODULE_0__["default"])(objCriteria[index], othCriteria[index]);
    if (result) {
      if (index >= ordersLength) {
        return result;
      }
      var order = orders[index];
      return result * (order == 'desc' ? -1 : 1);
    }
  }
  // Fixes an `Array#sort` bug in the JS engine embedded in Adobe applications
  // that causes it, under certain circumstances, to provide the same value for
  // `object` and `other`. See https://github.com/jashkenas/underscore/pull/1247
  // for more details.
  //
  // This also ensures a stable sort in V8 and other engines.
  // See https://bugs.chromium.org/p/v8/issues/detail?id=90 for more details.
  return object.index - other.index;
}
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (compareMultiple);

/***/ }),

/***/ 61682:
/*!*********************************************!*\
  !*** ./src/app/pages/trips/trips.module.ts ***!
  \*********************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   TripsPageModule: () => (/* binding */ TripsPageModule)
/* harmony export */ });
/* harmony import */ var _trips_routing_module__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./trips-routing.module */ 49107);
/* harmony import */ var _trips_page__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ./trips.page */ 91029);
/* harmony import */ var src_app_core_shared_shared_module__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! src/app/core/shared/shared.module */ 62657);
/* harmony import */ var _trip_card_trip_card_component__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! ./trip-card/trip-card.component */ 26376);
/* harmony import */ var _ionic_angular__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! @ionic/angular */ 21507);
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! @angular/core */ 34205);
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! @angular/core */ 12481);
/* harmony import */ var _angular_common__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(/*! @angular/common */ 93683);
/* harmony import */ var _core_shared_layout_header_header_directive__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(/*! ../../core/shared/layout/header/header.directive */ 85039);
/* harmony import */ var _core_shared_layout_content_content_directive__WEBPACK_IMPORTED_MODULE_9__ = __webpack_require__(/*! ../../core/shared/layout/content/content.directive */ 75855);
/* harmony import */ var _core_shared_infinite_scroll_infinite_scroll_component__WEBPACK_IMPORTED_MODULE_10__ = __webpack_require__(/*! ../../core/shared/infinite-scroll/infinite-scroll.component */ 666);
/* harmony import */ var _ngx_translate_core__WEBPACK_IMPORTED_MODULE_11__ = __webpack_require__(/*! @ngx-translate/core */ 48503);
/* harmony import */ var _core_shared_pipes_localDate_pipe__WEBPACK_IMPORTED_MODULE_12__ = __webpack_require__(/*! ../../core/shared/pipes/localDate.pipe */ 86451);
/* harmony import */ var _core_shared_pipes_languageMap_pipe__WEBPACK_IMPORTED_MODULE_13__ = __webpack_require__(/*! ../../core/shared/pipes/languageMap.pipe */ 69618);
var _staticBlock;














class TripsPageModule {
  static #_ = _staticBlock = () => (this.ɵfac = function TripsPageModule_Factory(__ngFactoryType__) {
    return new (__ngFactoryType__ || TripsPageModule)();
  }, this.ɵmod = /*@__PURE__*/_angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵdefineNgModule"]({
    type: TripsPageModule
  }), this.ɵinj = /*@__PURE__*/_angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵdefineInjector"]({
    imports: [src_app_core_shared_shared_module__WEBPACK_IMPORTED_MODULE_2__.PlayGoSharedModule, _trips_routing_module__WEBPACK_IMPORTED_MODULE_0__.TripsPageRoutingModule, _ionic_angular__WEBPACK_IMPORTED_MODULE_4__.IonicModule]
  }));
}
_staticBlock();
(function () {
  (typeof ngJitMode === "undefined" || ngJitMode) && _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵsetNgModuleScope"](TripsPageModule, {
    declarations: [_trips_page__WEBPACK_IMPORTED_MODULE_1__.TripsPage, _trip_card_trip_card_component__WEBPACK_IMPORTED_MODULE_3__.TripCardComponent],
    imports: [src_app_core_shared_shared_module__WEBPACK_IMPORTED_MODULE_2__.PlayGoSharedModule, _trips_routing_module__WEBPACK_IMPORTED_MODULE_0__.TripsPageRoutingModule, _ionic_angular__WEBPACK_IMPORTED_MODULE_4__.IonicModule]
  });
})();
_angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵsetComponentScope"](_trips_page__WEBPACK_IMPORTED_MODULE_1__.TripsPage, [_angular_common__WEBPACK_IMPORTED_MODULE_7__.NgForOf, _angular_common__WEBPACK_IMPORTED_MODULE_7__.NgIf, _angular_common__WEBPACK_IMPORTED_MODULE_7__.NgStyle, _ionic_angular__WEBPACK_IMPORTED_MODULE_4__.IonCard, _ionic_angular__WEBPACK_IMPORTED_MODULE_4__.IonCol, _ionic_angular__WEBPACK_IMPORTED_MODULE_4__.IonContent, _ionic_angular__WEBPACK_IMPORTED_MODULE_4__.IonGrid, _ionic_angular__WEBPACK_IMPORTED_MODULE_4__.IonHeader, _ionic_angular__WEBPACK_IMPORTED_MODULE_4__.IonItem, _ionic_angular__WEBPACK_IMPORTED_MODULE_4__.IonItemDivider, _ionic_angular__WEBPACK_IMPORTED_MODULE_4__.IonLabel, _ionic_angular__WEBPACK_IMPORTED_MODULE_4__.IonRow, _ionic_angular__WEBPACK_IMPORTED_MODULE_4__.IonSelect, _ionic_angular__WEBPACK_IMPORTED_MODULE_4__.IonSelectOption, _ionic_angular__WEBPACK_IMPORTED_MODULE_4__.SelectValueAccessor, _core_shared_layout_header_header_directive__WEBPACK_IMPORTED_MODULE_8__.HeaderDirective, _core_shared_layout_content_content_directive__WEBPACK_IMPORTED_MODULE_9__.ContentDirective, _core_shared_infinite_scroll_infinite_scroll_component__WEBPACK_IMPORTED_MODULE_10__.InfiniteScrollComponent, _core_shared_infinite_scroll_infinite_scroll_component__WEBPACK_IMPORTED_MODULE_10__.InfiniteScrollContentDirective, _trip_card_trip_card_component__WEBPACK_IMPORTED_MODULE_3__.TripCardComponent], [_angular_common__WEBPACK_IMPORTED_MODULE_7__.AsyncPipe, _ngx_translate_core__WEBPACK_IMPORTED_MODULE_11__.TranslatePipe, _core_shared_pipes_localDate_pipe__WEBPACK_IMPORTED_MODULE_12__.LocalDatePipe, _core_shared_pipes_languageMap_pipe__WEBPACK_IMPORTED_MODULE_13__.LanguageMapPipe]);

/***/ }),

/***/ 63658:
/*!*********************************************!*\
  !*** ./node_modules/lodash-es/_baseSome.js ***!
  \*********************************************/
/***/ ((__unused_webpack___webpack_module__, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "default": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var _baseEach_js__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./_baseEach.js */ 14583);


/**
 * The base implementation of `_.some` without support for iteratee shorthands.
 *
 * @private
 * @param {Array|Object} collection The collection to iterate over.
 * @param {Function} predicate The function invoked per iteration.
 * @returns {boolean} Returns `true` if any element passes the predicate check,
 *  else `false`.
 */
function baseSome(collection, predicate) {
  var result;
  (0,_baseEach_js__WEBPACK_IMPORTED_MODULE_0__["default"])(collection, function (value, index, collection) {
    result = predicate(value, index, collection);
    return !result;
  });
  return !!result;
}
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (baseSome);

/***/ }),

/***/ 72611:
/*!********************************************************************!*\
  !*** ./node_modules/rxjs/dist/esm/internal/operators/retryWhen.js ***!
  \********************************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   retryWhen: () => (/* binding */ retryWhen)
/* harmony export */ });
/* harmony import */ var _observable_innerFrom__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ../observable/innerFrom */ 82645);
/* harmony import */ var _Subject__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ../Subject */ 10819);
/* harmony import */ var _util_lift__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! ../util/lift */ 50819);
/* harmony import */ var _OperatorSubscriber__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! ./OperatorSubscriber */ 91687);




function retryWhen(notifier) {
  return (0,_util_lift__WEBPACK_IMPORTED_MODULE_2__.operate)((source, subscriber) => {
    let innerSub;
    let syncResub = false;
    let errors$;
    const subscribeForRetryWhen = () => {
      innerSub = source.subscribe((0,_OperatorSubscriber__WEBPACK_IMPORTED_MODULE_3__.createOperatorSubscriber)(subscriber, undefined, undefined, err => {
        if (!errors$) {
          errors$ = new _Subject__WEBPACK_IMPORTED_MODULE_1__.Subject();
          (0,_observable_innerFrom__WEBPACK_IMPORTED_MODULE_0__.innerFrom)(notifier(errors$)).subscribe((0,_OperatorSubscriber__WEBPACK_IMPORTED_MODULE_3__.createOperatorSubscriber)(subscriber, () => innerSub ? subscribeForRetryWhen() : syncResub = true));
        }
        if (errors$) {
          errors$.next(err);
        }
      }));
      if (syncResub) {
        innerSub.unsubscribe();
        innerSub = null;
        syncResub = false;
        subscribeForRetryWhen();
      }
    };
    subscribeForRetryWhen();
  });
}

/***/ }),

/***/ 87923:
/*!********************************************!*\
  !*** ./node_modules/lodash-es/findLast.js ***!
  \********************************************/
/***/ ((__unused_webpack___webpack_module__, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "default": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var _createFind_js__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./_createFind.js */ 84436);
/* harmony import */ var _findLastIndex_js__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ./findLastIndex.js */ 58023);



/**
 * This method is like `_.find` except that it iterates over elements of
 * `collection` from right to left.
 *
 * @static
 * @memberOf _
 * @since 2.0.0
 * @category Collection
 * @param {Array|Object} collection The collection to inspect.
 * @param {Function} [predicate=_.identity] The function invoked per iteration.
 * @param {number} [fromIndex=collection.length-1] The index to search from.
 * @returns {*} Returns the matched element, else `undefined`.
 * @example
 *
 * _.findLast([1, 2, 3, 4], function(n) {
 *   return n % 2 == 1;
 * });
 * // => 3
 */
var findLast = (0,_createFind_js__WEBPACK_IMPORTED_MODULE_0__["default"])(_findLastIndex_js__WEBPACK_IMPORTED_MODULE_1__["default"]);
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (findLast);

/***/ }),

/***/ 89951:
/*!*****************************************!*\
  !*** ./node_modules/lodash-es/minBy.js ***!
  \*****************************************/
/***/ ((__unused_webpack___webpack_module__, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "default": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var _baseExtremum_js__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./_baseExtremum.js */ 93185);
/* harmony import */ var _baseIteratee_js__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ./_baseIteratee.js */ 65679);
/* harmony import */ var _baseLt_js__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! ./_baseLt.js */ 14470);




/**
 * This method is like `_.min` except that it accepts `iteratee` which is
 * invoked for each element in `array` to generate the criterion by which
 * the value is ranked. The iteratee is invoked with one argument: (value).
 *
 * @static
 * @memberOf _
 * @since 4.0.0
 * @category Math
 * @param {Array} array The array to iterate over.
 * @param {Function} [iteratee=_.identity] The iteratee invoked per element.
 * @returns {*} Returns the minimum value.
 * @example
 *
 * var objects = [{ 'n': 1 }, { 'n': 2 }];
 *
 * _.minBy(objects, function(o) { return o.n; });
 * // => { 'n': 1 }
 *
 * // The `_.property` iteratee shorthand.
 * _.minBy(objects, 'n');
 * // => { 'n': 1 }
 */
function minBy(array, iteratee) {
  return array && array.length ? (0,_baseExtremum_js__WEBPACK_IMPORTED_MODULE_0__["default"])(array, (0,_baseIteratee_js__WEBPACK_IMPORTED_MODULE_1__["default"])(iteratee, 2), _baseLt_js__WEBPACK_IMPORTED_MODULE_2__["default"]) : undefined;
}
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (minBy);

/***/ }),

/***/ 91029:
/*!*******************************************!*\
  !*** ./src/app/pages/trips/trips.page.ts ***!
  \*******************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   TripsPage: () => (/* binding */ TripsPage)
/* harmony export */ });
/* harmony import */ var _Users_smartcommunitylab_Desktop_newWork_playAndGo_playGo_node_modules_babel_runtime_helpers_esm_asyncToGenerator_js__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./node_modules/@babel/runtime/helpers/esm/asyncToGenerator.js */ 89204);
/* harmony import */ var lodash_es__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! lodash-es */ 95110);
/* harmony import */ var lodash_es__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! lodash-es */ 92434);
/* harmony import */ var lodash_es__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! lodash-es */ 80524);
/* harmony import */ var lodash_es__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! lodash-es */ 23477);
/* harmony import */ var rxjs__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! rxjs */ 10819);
/* harmony import */ var rxjs__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! rxjs */ 75797);
/* harmony import */ var rxjs__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(/*! rxjs */ 56196);
/* harmony import */ var rxjs__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(/*! rxjs */ 19999);
/* harmony import */ var rxjs__WEBPACK_IMPORTED_MODULE_9__ = __webpack_require__(/*! rxjs */ 95429);
/* harmony import */ var rxjs__WEBPACK_IMPORTED_MODULE_10__ = __webpack_require__(/*! rxjs */ 63617);
/* harmony import */ var rxjs__WEBPACK_IMPORTED_MODULE_11__ = __webpack_require__(/*! rxjs */ 59452);
/* harmony import */ var rxjs_operators__WEBPACK_IMPORTED_MODULE_12__ = __webpack_require__(/*! rxjs/operators */ 61318);
/* harmony import */ var rxjs_operators__WEBPACK_IMPORTED_MODULE_13__ = __webpack_require__(/*! rxjs/operators */ 51903);
/* harmony import */ var rxjs_operators__WEBPACK_IMPORTED_MODULE_14__ = __webpack_require__(/*! rxjs/operators */ 91817);
/* harmony import */ var rxjs_operators__WEBPACK_IMPORTED_MODULE_15__ = __webpack_require__(/*! rxjs/operators */ 70271);
/* harmony import */ var rxjs_operators__WEBPACK_IMPORTED_MODULE_16__ = __webpack_require__(/*! rxjs/operators */ 86301);
/* harmony import */ var rxjs_operators__WEBPACK_IMPORTED_MODULE_17__ = __webpack_require__(/*! rxjs/operators */ 63037);
/* harmony import */ var rxjs_operators__WEBPACK_IMPORTED_MODULE_18__ = __webpack_require__(/*! rxjs/operators */ 36647);
/* harmony import */ var src_app_core_shared_tracking_trip_model__WEBPACK_IMPORTED_MODULE_19__ = __webpack_require__(/*! src/app/core/shared/tracking/trip.model */ 23126);
/* harmony import */ var src_app_core_shared_utils__WEBPACK_IMPORTED_MODULE_20__ = __webpack_require__(/*! src/app/core/shared/utils */ 7497);
/* harmony import */ var src_app_core_shared_time_utils__WEBPACK_IMPORTED_MODULE_21__ = __webpack_require__(/*! src/app/core/shared/time.utils */ 27780);
/* harmony import */ var luxon__WEBPACK_IMPORTED_MODULE_22__ = __webpack_require__(/*! luxon */ 45967);
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_23__ = __webpack_require__(/*! @angular/core */ 34205);
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_24__ = __webpack_require__(/*! @angular/core */ 12481);
/* harmony import */ var src_app_core_shared_services_error_service__WEBPACK_IMPORTED_MODULE_25__ = __webpack_require__(/*! src/app/core/shared/services/error.service */ 46078);
/* harmony import */ var src_app_core_shared_tracking_track_api_service__WEBPACK_IMPORTED_MODULE_26__ = __webpack_require__(/*! src/app/core/shared/tracking/track-api.service */ 39499);
/* harmony import */ var src_app_core_shared_tracking_background_tracking_service__WEBPACK_IMPORTED_MODULE_27__ = __webpack_require__(/*! src/app/core/shared/tracking/background-tracking.service */ 27215);
/* harmony import */ var src_app_core_shared_tracking_trip_service__WEBPACK_IMPORTED_MODULE_28__ = __webpack_require__(/*! src/app/core/shared/tracking/trip.service */ 66704);
/* harmony import */ var src_app_core_shared_tracking_local_trips_service__WEBPACK_IMPORTED_MODULE_29__ = __webpack_require__(/*! src/app/core/shared/tracking/local-trips.service */ 20599);
/* harmony import */ var src_app_core_shared_services_alert_service__WEBPACK_IMPORTED_MODULE_30__ = __webpack_require__(/*! src/app/core/shared/services/alert.service */ 67406);
/* harmony import */ var src_app_core_shared_services_campaign_service__WEBPACK_IMPORTED_MODULE_31__ = __webpack_require__(/*! src/app/core/shared/services/campaign.service */ 76658);
/* harmony import */ var _angular_router__WEBPACK_IMPORTED_MODULE_32__ = __webpack_require__(/*! @angular/router */ 85422);

var _staticBlock;
















const _c0 = () => ({
  cssClass: "app-alert"
});
function TripsPage_ion_select_option_13_Template(rf, ctx) {
  if (rf & 1) {
    _angular_core__WEBPACK_IMPORTED_MODULE_24__["ɵɵelementStart"](0, "ion-select-option", 15);
    _angular_core__WEBPACK_IMPORTED_MODULE_24__["ɵɵtext"](1);
    _angular_core__WEBPACK_IMPORTED_MODULE_24__["ɵɵpipe"](2, "localDate");
    _angular_core__WEBPACK_IMPORTED_MODULE_24__["ɵɵelementEnd"]();
  }
  if (rf & 2) {
    const month_r2 = ctx.$implicit;
    _angular_core__WEBPACK_IMPORTED_MODULE_24__["ɵɵproperty"]("value", month_r2);
    _angular_core__WEBPACK_IMPORTED_MODULE_24__["ɵɵadvance"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_24__["ɵɵtextInterpolate1"](" ", _angular_core__WEBPACK_IMPORTED_MODULE_24__["ɵɵpipeBind2"](2, 2, month_r2.from, "MMMM y"), " ");
  }
}
function TripsPage_ion_select_option_23_Template(rf, ctx) {
  if (rf & 1) {
    _angular_core__WEBPACK_IMPORTED_MODULE_24__["ɵɵelementStart"](0, "ion-select-option", 16);
    _angular_core__WEBPACK_IMPORTED_MODULE_24__["ɵɵtext"](1);
    _angular_core__WEBPACK_IMPORTED_MODULE_24__["ɵɵpipe"](2, "languageMap");
    _angular_core__WEBPACK_IMPORTED_MODULE_24__["ɵɵelementEnd"]();
  }
  if (rf & 2) {
    const campaign_r3 = ctx.$implicit;
    _angular_core__WEBPACK_IMPORTED_MODULE_24__["ɵɵproperty"]("value", campaign_r3.campaign.campaignId);
    _angular_core__WEBPACK_IMPORTED_MODULE_24__["ɵɵadvance"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_24__["ɵɵtextInterpolate1"](" ", _angular_core__WEBPACK_IMPORTED_MODULE_24__["ɵɵpipeBind1"](2, 2, campaign_r3.campaign.name), " ");
  }
}
function TripsPage_ng_template_29_ng_container_0_ng_container_1_ion_item_divider_1_Template(rf, ctx) {
  if (rf & 1) {
    _angular_core__WEBPACK_IMPORTED_MODULE_24__["ɵɵelementStart"](0, "ion-item-divider", 20)(1, "ion-label");
    _angular_core__WEBPACK_IMPORTED_MODULE_24__["ɵɵtext"](2);
    _angular_core__WEBPACK_IMPORTED_MODULE_24__["ɵɵpipe"](3, "localDate");
    _angular_core__WEBPACK_IMPORTED_MODULE_24__["ɵɵelementEnd"]()();
  }
  if (rf & 2) {
    const tripGroup_r4 = _angular_core__WEBPACK_IMPORTED_MODULE_24__["ɵɵnextContext"]().$implicit;
    _angular_core__WEBPACK_IMPORTED_MODULE_24__["ɵɵadvance"](2);
    _angular_core__WEBPACK_IMPORTED_MODULE_24__["ɵɵtextInterpolate1"](" ", _angular_core__WEBPACK_IMPORTED_MODULE_24__["ɵɵpipeBind2"](3, 1, tripGroup_r4.monthDate, "MMMM y"), " ");
  }
}
function TripsPage_ng_template_29_ng_container_0_ng_container_1_ion_card_3_app_trip_card_2_Template(rf, ctx) {
  if (rf & 1) {
    _angular_core__WEBPACK_IMPORTED_MODULE_24__["ɵɵelement"](0, "app-trip-card", 23);
  }
  if (rf & 2) {
    const multiTrip_r5 = _angular_core__WEBPACK_IMPORTED_MODULE_24__["ɵɵnextContext"]().$implicit;
    _angular_core__WEBPACK_IMPORTED_MODULE_24__["ɵɵproperty"]("trip", multiTrip_r5.trips[0])("isOneDayTrip", multiTrip_r5.isOneDayTrip)("multiModalTrip", false);
  }
}
function TripsPage_ng_template_29_ng_container_0_ng_container_1_ion_card_3_ng_container_3_ng_container_5_app_trip_card_1_Template(rf, ctx) {
  if (rf & 1) {
    _angular_core__WEBPACK_IMPORTED_MODULE_24__["ɵɵelement"](0, "app-trip-card", 26);
  }
  if (rf & 2) {
    const ctx_r5 = _angular_core__WEBPACK_IMPORTED_MODULE_24__["ɵɵnextContext"]();
    const trip_r7 = ctx_r5.$implicit;
    const i_r8 = ctx_r5.index;
    const multiTrip_r5 = _angular_core__WEBPACK_IMPORTED_MODULE_24__["ɵɵnextContext"](2).$implicit;
    _angular_core__WEBPACK_IMPORTED_MODULE_24__["ɵɵproperty"]("trip", trip_r7)("isOneDayTrip", multiTrip_r5.isOneDayTrip)("indexTrip", i_r8 + 1)("length", multiTrip_r5.trips.length)("multiModalTrip", true);
  }
}
function TripsPage_ng_template_29_ng_container_0_ng_container_1_ion_card_3_ng_container_3_ng_container_5_Template(rf, ctx) {
  if (rf & 1) {
    _angular_core__WEBPACK_IMPORTED_MODULE_24__["ɵɵelementContainerStart"](0);
    _angular_core__WEBPACK_IMPORTED_MODULE_24__["ɵɵtemplate"](1, TripsPage_ng_template_29_ng_container_0_ng_container_1_ion_card_3_ng_container_3_ng_container_5_app_trip_card_1_Template, 1, 5, "app-trip-card", 25);
    _angular_core__WEBPACK_IMPORTED_MODULE_24__["ɵɵelementContainerEnd"]();
  }
  if (rf & 2) {
    const trip_r7 = ctx.$implicit;
    _angular_core__WEBPACK_IMPORTED_MODULE_24__["ɵɵadvance"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_24__["ɵɵproperty"]("ngIf", trip_r7);
  }
}
function TripsPage_ng_template_29_ng_container_0_ng_container_1_ion_card_3_ng_container_3_Template(rf, ctx) {
  if (rf & 1) {
    _angular_core__WEBPACK_IMPORTED_MODULE_24__["ɵɵelementContainerStart"](0);
    _angular_core__WEBPACK_IMPORTED_MODULE_24__["ɵɵelementStart"](1, "ion-row")(2, "ion-col", 24);
    _angular_core__WEBPACK_IMPORTED_MODULE_24__["ɵɵtext"](3);
    _angular_core__WEBPACK_IMPORTED_MODULE_24__["ɵɵpipe"](4, "localDate");
    _angular_core__WEBPACK_IMPORTED_MODULE_24__["ɵɵelementEnd"]()();
    _angular_core__WEBPACK_IMPORTED_MODULE_24__["ɵɵtemplate"](5, TripsPage_ng_template_29_ng_container_0_ng_container_1_ion_card_3_ng_container_3_ng_container_5_Template, 2, 1, "ng-container", 18);
    _angular_core__WEBPACK_IMPORTED_MODULE_24__["ɵɵelementContainerEnd"]();
  }
  if (rf & 2) {
    const multiTrip_r5 = _angular_core__WEBPACK_IMPORTED_MODULE_24__["ɵɵnextContext"]().$implicit;
    const ctx_r8 = _angular_core__WEBPACK_IMPORTED_MODULE_24__["ɵɵnextContext"](4);
    _angular_core__WEBPACK_IMPORTED_MODULE_24__["ɵɵadvance"](3);
    _angular_core__WEBPACK_IMPORTED_MODULE_24__["ɵɵtextInterpolate1"](" ", _angular_core__WEBPACK_IMPORTED_MODULE_24__["ɵɵpipeBind2"](4, 3, multiTrip_r5.date, ctx_r8.noMonthOrYearFormat), " ");
    _angular_core__WEBPACK_IMPORTED_MODULE_24__["ɵɵadvance"](2);
    _angular_core__WEBPACK_IMPORTED_MODULE_24__["ɵɵproperty"]("ngForOf", multiTrip_r5.trips)("ngForTrackBy", ctx_r8.trackTrip);
  }
}
function TripsPage_ng_template_29_ng_container_0_ng_container_1_ion_card_3_Template(rf, ctx) {
  if (rf & 1) {
    _angular_core__WEBPACK_IMPORTED_MODULE_24__["ɵɵelementStart"](0, "ion-card")(1, "ion-grid");
    _angular_core__WEBPACK_IMPORTED_MODULE_24__["ɵɵtemplate"](2, TripsPage_ng_template_29_ng_container_0_ng_container_1_ion_card_3_app_trip_card_2_Template, 1, 3, "app-trip-card", 21)(3, TripsPage_ng_template_29_ng_container_0_ng_container_1_ion_card_3_ng_container_3_Template, 6, 6, "ng-container", 22);
    _angular_core__WEBPACK_IMPORTED_MODULE_24__["ɵɵelementEnd"]()();
  }
  if (rf & 2) {
    const multiTrip_r5 = ctx.$implicit;
    _angular_core__WEBPACK_IMPORTED_MODULE_24__["ɵɵadvance"](2);
    _angular_core__WEBPACK_IMPORTED_MODULE_24__["ɵɵproperty"]("ngIf", multiTrip_r5.trips.length === 1);
    _angular_core__WEBPACK_IMPORTED_MODULE_24__["ɵɵadvance"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_24__["ɵɵproperty"]("ngIf", multiTrip_r5.trips.length !== 1);
  }
}
function TripsPage_ng_template_29_ng_container_0_ng_container_1_Template(rf, ctx) {
  if (rf & 1) {
    _angular_core__WEBPACK_IMPORTED_MODULE_24__["ɵɵelementContainerStart"](0);
    _angular_core__WEBPACK_IMPORTED_MODULE_24__["ɵɵtemplate"](1, TripsPage_ng_template_29_ng_container_0_ng_container_1_ion_item_divider_1_Template, 4, 4, "ion-item-divider", 19);
    _angular_core__WEBPACK_IMPORTED_MODULE_24__["ɵɵpipe"](2, "async");
    _angular_core__WEBPACK_IMPORTED_MODULE_24__["ɵɵtemplate"](3, TripsPage_ng_template_29_ng_container_0_ng_container_1_ion_card_3_Template, 4, 2, "ion-card", 18);
    _angular_core__WEBPACK_IMPORTED_MODULE_24__["ɵɵelementContainerEnd"]();
  }
  if (rf & 2) {
    const tripGroup_r4 = ctx.$implicit;
    const ctx_r8 = _angular_core__WEBPACK_IMPORTED_MODULE_24__["ɵɵnextContext"](3);
    _angular_core__WEBPACK_IMPORTED_MODULE_24__["ɵɵadvance"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_24__["ɵɵproperty"]("ngIf", _angular_core__WEBPACK_IMPORTED_MODULE_24__["ɵɵpipeBind1"](2, 3, ctx_r8.monthFilterSubject) === "NO_FILTER");
    _angular_core__WEBPACK_IMPORTED_MODULE_24__["ɵɵadvance"](2);
    _angular_core__WEBPACK_IMPORTED_MODULE_24__["ɵɵproperty"]("ngForOf", tripGroup_r4.tripsInSameMonth)("ngForTrackBy", ctx_r8.trackMultiTrip);
  }
}
function TripsPage_ng_template_29_ng_container_0_Template(rf, ctx) {
  if (rf & 1) {
    _angular_core__WEBPACK_IMPORTED_MODULE_24__["ɵɵelementContainerStart"](0);
    _angular_core__WEBPACK_IMPORTED_MODULE_24__["ɵɵtemplate"](1, TripsPage_ng_template_29_ng_container_0_ng_container_1_Template, 4, 5, "ng-container", 18);
    _angular_core__WEBPACK_IMPORTED_MODULE_24__["ɵɵpipe"](2, "async");
    _angular_core__WEBPACK_IMPORTED_MODULE_24__["ɵɵelementContainerEnd"]();
  }
  if (rf & 2) {
    const ctx_r8 = _angular_core__WEBPACK_IMPORTED_MODULE_24__["ɵɵnextContext"](2);
    _angular_core__WEBPACK_IMPORTED_MODULE_24__["ɵɵadvance"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_24__["ɵɵproperty"]("ngForOf", _angular_core__WEBPACK_IMPORTED_MODULE_24__["ɵɵpipeBind1"](2, 2, ctx_r8.groupedTrips$))("ngForTrackBy", ctx_r8.trackGroup);
  }
}
function TripsPage_ng_template_29_Template(rf, ctx) {
  if (rf & 1) {
    _angular_core__WEBPACK_IMPORTED_MODULE_24__["ɵɵtemplate"](0, TripsPage_ng_template_29_ng_container_0_Template, 3, 4, "ng-container", 17);
    _angular_core__WEBPACK_IMPORTED_MODULE_24__["ɵɵpipe"](1, "async");
  }
  if (rf & 2) {
    let tmp_2_0;
    const ctx_r8 = _angular_core__WEBPACK_IMPORTED_MODULE_24__["ɵɵnextContext"]();
    const noTrips_r10 = _angular_core__WEBPACK_IMPORTED_MODULE_24__["ɵɵreference"](31);
    _angular_core__WEBPACK_IMPORTED_MODULE_24__["ɵɵproperty"]("ngIf", ((tmp_2_0 = _angular_core__WEBPACK_IMPORTED_MODULE_24__["ɵɵpipeBind1"](1, 2, ctx_r8.groupedTrips$)) == null ? null : tmp_2_0.length) > 0)("ngIfElse", noTrips_r10);
  }
}
function TripsPage_ng_template_30_Template(rf, ctx) {
  if (rf & 1) {
    _angular_core__WEBPACK_IMPORTED_MODULE_24__["ɵɵelementStart"](0, "div", 27);
    _angular_core__WEBPACK_IMPORTED_MODULE_24__["ɵɵtext"](1);
    _angular_core__WEBPACK_IMPORTED_MODULE_24__["ɵɵpipe"](2, "translate");
    _angular_core__WEBPACK_IMPORTED_MODULE_24__["ɵɵelementEnd"]();
  }
  if (rf & 2) {
    _angular_core__WEBPACK_IMPORTED_MODULE_24__["ɵɵadvance"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_24__["ɵɵtextInterpolate"](_angular_core__WEBPACK_IMPORTED_MODULE_24__["ɵɵpipeBind1"](2, 1, "trips.empty"));
  }
}
class TripsPage {
  constructor(errorService, trackApiService, backgroundTrackingService, tripService, localTripsService, alertService, campaignService, activatedRoute) {
    this.errorService = errorService;
    this.trackApiService = trackApiService;
    this.backgroundTrackingService = backgroundTrackingService;
    this.tripService = tripService;
    this.localTripsService = localTripsService;
    this.alertService = alertService;
    this.campaignService = campaignService;
    this.activatedRoute = activatedRoute;
    this.transportTypeLabels = src_app_core_shared_tracking_trip_model__WEBPACK_IMPORTED_MODULE_19__.transportTypeLabels;
    this.scrollRequestSubject = new rxjs__WEBPACK_IMPORTED_MODULE_5__.Subject();
    this.noMonthOrYearFormat = {
      weekday: 'long',
      day: 'numeric',
      hour: 'numeric',
      minute: 'numeric'
    };
    this.months$ = (0,rxjs__WEBPACK_IMPORTED_MODULE_9__.from)(this.getListOfMonths());
    this.monthFilterSubject = new rxjs__WEBPACK_IMPORTED_MODULE_6__.BehaviorSubject('NO_FILTER');
    this.myCampaigns$ = this.campaignService.myCampaigns$;
    this.routingCampaignFilter$ = this.activatedRoute.params.pipe((0,rxjs_operators__WEBPACK_IMPORTED_MODULE_15__.map)(params => params.id ?? 'NO_FILTER'), (0,rxjs_operators__WEBPACK_IMPORTED_MODULE_16__.shareReplay)(1));
    this.campaignFilterSubject = new rxjs__WEBPACK_IMPORTED_MODULE_5__.Subject();
    this.campaignFilter$ = (0,rxjs__WEBPACK_IMPORTED_MODULE_10__.merge)(this.routingCampaignFilter$, this.campaignFilterSubject).pipe((0,rxjs_operators__WEBPACK_IMPORTED_MODULE_16__.shareReplay)(1));
    this.filterOptions$ = (0,rxjs__WEBPACK_IMPORTED_MODULE_8__.combineLatest)({
      campaignId: this.campaignFilter$,
      month: this.monthFilterSubject
    }).pipe((0,rxjs_operators__WEBPACK_IMPORTED_MODULE_16__.shareReplay)(1));
    this.campaignFilterStyle$ = (0,rxjs__WEBPACK_IMPORTED_MODULE_8__.combineLatest)([this.campaignFilter$, this.myCampaigns$]).pipe((0,rxjs_operators__WEBPACK_IMPORTED_MODULE_15__.map)(([campaignId, campaigns]) => {
      if (campaignId === 'NO_FILTER') {
        return undefined;
      }
      const campaign = campaigns.find(c => c?.campaign?.campaignId === campaignId);
      if (campaign) {
        return this.campaignService.getCampaignColor(campaign.campaign);
      }
    }), (0,rxjs_operators__WEBPACK_IMPORTED_MODULE_15__.map)(color => color ? {
      // eslint-disable-next-line @typescript-eslint/naming-convention
      'border-bottom': '5px solid',
      // eslint-disable-next-line @typescript-eslint/naming-convention
      'border-bottom-color': 'var(--ion-color-' + color + ')'
    } : {}));
    this.resetItems$ = this.filterOptions$.pipe((0,rxjs_operators__WEBPACK_IMPORTED_MODULE_15__.map)(() => Symbol()));
    this.tripsResponse$ = this.filterOptions$.pipe((0,rxjs_operators__WEBPACK_IMPORTED_MODULE_18__.switchMap)(filterOptions => this.scrollRequestSubject.pipe((0,rxjs_operators__WEBPACK_IMPORTED_MODULE_17__.startWith)({
      page: 0,
      size: 5
    }), (0,rxjs_operators__WEBPACK_IMPORTED_MODULE_13__.concatMap)(scrollRequest => this.getTripsPage(scrollRequest, filterOptions).pipe((0,rxjs_operators__WEBPACK_IMPORTED_MODULE_12__.catchError)(error => {
      if ((0,src_app_core_shared_utils__WEBPACK_IMPORTED_MODULE_20__.isOfflineError)(error)) {
        // TODO: show better UX
        this.alertService.showToast({
          messageTranslateKey: 'trip_detail.historic_values_offline'
        });
      } else {
        this.errorService.handleError(error);
      }
      return (0,rxjs__WEBPACK_IMPORTED_MODULE_11__.of)({
        error
      });
    }))))));
    /* filled from the infinite scroll component */
    this.serverTripsSubject = new rxjs__WEBPACK_IMPORTED_MODULE_5__.Subject();
    /** trips older than 1 month - available only online as infinite scroll paging*/
    this.deepPastTrips$ = this.serverTripsSubject.pipe((0,rxjs_operators__WEBPACK_IMPORTED_MODULE_15__.map)(trips => trips.map(trip => ({
      ...trip,
      status: trip.validity
    }))), (0,rxjs_operators__WEBPACK_IMPORTED_MODULE_17__.startWith)([]));
    /**
     * Live list of recent trips - changing as user created new trips.
     * If there is no connection, they are loaded from local storage.
     */
    this.recentTrips$ = this.localTripsService.localDataChanges$.pipe((0,rxjs_operators__WEBPACK_IMPORTED_MODULE_15__.map)(storableTrips => storableTrips.map(trip => ({
      status: trip.status === 'fromServer' ? trip.tripData.validity : 'NOT_SYNCHRONIZED',
      ...trip.tripData
    }))));
    /** Content of plugin DB locations represented as trips */
    this.notSynchronizedTrips$ = this.backgroundTrackingService.notSynchronizedLocations$.pipe((0,rxjs_operators__WEBPACK_IMPORTED_MODULE_15__.map)(notSynchronizedLocations => {
      const tripLocations = notSynchronizedLocations.filter(location => location.transportType);
      const locationsAsTrips = (0,src_app_core_shared_utils__WEBPACK_IMPORTED_MODULE_20__.groupByConsecutiveValues)(tripLocations, 'transportType').map(({
        group,
        values
      }) => {
        const transportType = group;
        const locations = values;
        const representativeLocation = (0,lodash_es__WEBPACK_IMPORTED_MODULE_1__["default"])(locations);
        const trip = {
          campaigns: [],
          distance: 0,
          startTime: (0,lodash_es__WEBPACK_IMPORTED_MODULE_1__["default"])(locations).date,
          endTime: (0,lodash_es__WEBPACK_IMPORTED_MODULE_3__["default"])(locations).date,
          modeType: group,
          multimodalId: representativeLocation.multimodalId,
          polyline: '',
          trackedInstanceId: `localId_${transportType}_${representativeLocation.date}`,
          validity: null
        };
        return trip;
      });
      return this.sortTrips(locationsAsTrips);
    }));
    this.fromPluginTrips$ = (0,rxjs__WEBPACK_IMPORTED_MODULE_8__.combineLatest)([this.notSynchronizedTrips$, this.tripService.isInTrip$]).pipe((0,rxjs_operators__WEBPACK_IMPORTED_MODULE_15__.map)(([notSynchronizedTrips, isInTrip]) => notSynchronizedTrips.map((notSynchronizedTrip, idx) => {
      const isFirst = idx === 0;
      const isFinished = !isFirst || !isInTrip;
      const status = isFinished ? 'NOT_SYNCHRONIZED' : 'ONGOING';
      return {
        ...notSynchronizedTrip,
        status
      };
    })), (0,rxjs_operators__WEBPACK_IMPORTED_MODULE_17__.startWith)([]));
    /**
     * All trips displayed on page. Consist of trips from:
     *
     * - fromPluginTrips. Trips that are still in plugin database and not synchronized yet.
     *            Mostly ongoing trip, but it is possible that also some older trip could be not
     *            synchronized yet.
     *
     * - recentTrips. Trips that are synchronized with server, but not older than 7 days.
     *            For some trip, we know that we sent them to server, but verification is still pending.
     *            We store these trips in storage, for offline use.
     *
     * - deepPastTrips. There trips are older than 7 days and are loaded from server using infinite scroll.
     */
    this.trips$ = (0,rxjs__WEBPACK_IMPORTED_MODULE_8__.combineLatest)([this.fromPluginTrips$, this.recentTrips$, this.deepPastTrips$]).pipe((0,rxjs_operators__WEBPACK_IMPORTED_MODULE_15__.map)(([fromPluginTrips, recentTrips, deepPastTrips]) => [...fromPluginTrips.map(t => ({
      ...t,
      source: 'fromPluginTrips'
    })), ...recentTrips.map(t => ({
      ...t,
      source: 'recentTrips'
    })), ...deepPastTrips.map(t => ({
      ...t,
      source: 'deepPastTrips'
    }))]), (0,rxjs_operators__WEBPACK_IMPORTED_MODULE_15__.map)(trips => this.sortTrips(trips)), (0,rxjs_operators__WEBPACK_IMPORTED_MODULE_14__.distinctUntilChanged)(lodash_es__WEBPACK_IMPORTED_MODULE_2__["default"]));
    this.groupedTrips$ = (0,rxjs__WEBPACK_IMPORTED_MODULE_8__.combineLatest)([this.trips$, this.filterOptions$]).pipe((0,rxjs_operators__WEBPACK_IMPORTED_MODULE_15__.map)(([trips, filterOptions]) => this.groupTripsAndFilter(trips, filterOptions)), (0,rxjs_operators__WEBPACK_IMPORTED_MODULE_16__.shareReplay)(1));
    this.trackGroup = (0,src_app_core_shared_utils__WEBPACK_IMPORTED_MODULE_20__.trackByProperty)('monthDate');
    this.trackMultiTrip = (0,src_app_core_shared_utils__WEBPACK_IMPORTED_MODULE_20__.trackByProperty)('multimodalId');
    this.trackTrip = (0,src_app_core_shared_utils__WEBPACK_IMPORTED_MODULE_20__.trackByProperty)('trackedInstanceId');
  }
  ngOnInit() {}
  groupTripsAndFilter(allTrips, filterOptions) {
    // We have to apply all filters for local trips
    const filteredTrips = allTrips.filter(trip => {
      if (filterOptions.campaignId === 'NO_FILTER') {
        return true;
      }
      return (trip.campaigns ?? []).some(campaign => campaign.campaignId === filterOptions.campaignId);
    }).filter(trip => {
      if (filterOptions.month === 'NO_FILTER') {
        return true;
      }
      return filterOptions.month.from <= trip.startTime && trip.startTime <= filterOptions.month.to;
    });
    const groupedByMultimodalId = (0,src_app_core_shared_utils__WEBPACK_IMPORTED_MODULE_20__.groupByConsecutiveValues)(filteredTrips, 'multimodalId').map(({
      group,
      values
    }) => {
      const startDate = new Date(values[0].startTime);
      const endDate = new Date((0,lodash_es__WEBPACK_IMPORTED_MODULE_3__["default"])(values).endTime);
      const isOneDayTrip = this.roundToDay(startDate) === this.roundToDay(endDate);
      const referenceDate = endDate;
      const monthDate = this.roundToMonth(referenceDate);
      return {
        multimodalId: group,
        trips: values,
        startDate,
        endDate,
        isOneDayTrip,
        date: referenceDate,
        monthDate
      };
    });
    const groupedByDate = (0,src_app_core_shared_utils__WEBPACK_IMPORTED_MODULE_20__.groupByConsecutiveValues)(groupedByMultimodalId, 'monthDate').map(({
      group,
      values
    }) => ({
      monthDate: group,
      tripsInSameMonth: values
    }));
    return groupedByDate;
  }
  roundToDay(timestamp) {
    const dateCopy = new Date(timestamp);
    dateCopy.setHours(0, 0, 0, 0);
    return dateCopy.getTime();
  }
  roundToMonth(timestamp) {
    const dateCopy = new Date(timestamp);
    dateCopy.setDate(1);
    dateCopy.setHours(0, 0, 0, 0);
    return dateCopy.getTime();
  }
  getTripsPage(pageRequest, filterOptions) {
    const campaignId = filterOptions.campaignId !== 'NO_FILTER' ? filterOptions.campaignId : undefined;
    let newestDate;
    let oldestDate;
    if (filterOptions.month === 'NO_FILTER') {
      oldestDate = luxon__WEBPACK_IMPORTED_MODULE_22__.DateTime.fromMillis(0);
      newestDate = this.localTripsService.localDataFromDate;
    } else {
      oldestDate = luxon__WEBPACK_IMPORTED_MODULE_22__.DateTime.fromMillis(filterOptions.month.from);
      newestDate = luxon__WEBPACK_IMPORTED_MODULE_22__.DateTime.fromMillis(filterOptions.month.to);
    }
    return this.trackApiService.getTrackedInstanceInfoList({
      page: pageRequest.page,
      size: pageRequest.size,
      dateFrom: (0,src_app_core_shared_time_utils__WEBPACK_IMPORTED_MODULE_21__.toServerDateTime)(oldestDate),
      //from - older
      // TODO: check +-1 day errors!!
      dateTo: (0,src_app_core_shared_time_utils__WEBPACK_IMPORTED_MODULE_21__.toServerDateTime)(newestDate),
      //to - newer
      campaignId
    });
  }
  /* from oldest to newest */
  getListOfMonths() {
    var _this = this;
    return (0,_Users_smartcommunitylab_Desktop_newWork_playAndGo_playGo_node_modules_babel_runtime_helpers_esm_asyncToGenerator_js__WEBPACK_IMPORTED_MODULE_0__["default"])(function* () {
      const newestMonth = luxon__WEBPACK_IMPORTED_MODULE_22__.DateTime.now().startOf('month');
      const oldestMonth = (yield _this.getLastTripDate()).startOf('month');
      const months = [];
      let currentMonth = newestMonth;
      while (currentMonth >= oldestMonth) {
        months.push(currentMonth);
        currentMonth = currentMonth.minus({
          month: 1
        });
      }
      return months.map(dateTime => ({
        from: dateTime.startOf('month').toMillis(),
        to: dateTime.endOf('month').toMillis()
      }));
    })();
  }
  getLastTripDate() {
    var _this2 = this;
    return (0,_Users_smartcommunitylab_Desktop_newWork_playAndGo_playGo_node_modules_babel_runtime_helpers_esm_asyncToGenerator_js__WEBPACK_IMPORTED_MODULE_0__["default"])(function* () {
      try {
        const firstTripPageInfo = yield (0,rxjs__WEBPACK_IMPORTED_MODULE_7__.firstValueFrom)(_this2.trackApiService.getTrackedInstanceInfoList({
          page: 0,
          size: 1
        }));
        const numberOfTrips = firstTripPageInfo.totalElements;
        if (numberOfTrips === 0) {
          return luxon__WEBPACK_IMPORTED_MODULE_22__.DateTime.now();
        }
        const lastTrip = yield (0,rxjs__WEBPACK_IMPORTED_MODULE_7__.firstValueFrom)(_this2.trackApiService.getTrackedInstanceInfoList({
          page: numberOfTrips - 1,
          size: 1
        }));
        if (!(lastTrip?.content?.[0]?.endTime ?? false)) {
          throw new Error('INVALID_LAST_TRIP');
        }
        return luxon__WEBPACK_IMPORTED_MODULE_22__.DateTime.fromMillis(lastTrip?.content?.[0]?.endTime);
      } catch (e) {
        _this2.errorService.handleError(e, 'silent');
        return luxon__WEBPACK_IMPORTED_MODULE_22__.DateTime.now().minus({
          years: 5
        });
      }
    })();
  }
  sortTrips(trips) {
    // sort by date. First the ones with the most recent date, then the ones with the oldest date
    // aka: sort desc by timestamp
    return (0,lodash_es__WEBPACK_IMPORTED_MODULE_4__["default"])(trips, trip => -new Date(trip?.endTime || trip?.startTime).getTime());
  }
  static #_ = _staticBlock = () => (this.ɵfac = function TripsPage_Factory(__ngFactoryType__) {
    return new (__ngFactoryType__ || TripsPage)(_angular_core__WEBPACK_IMPORTED_MODULE_24__["ɵɵdirectiveInject"](src_app_core_shared_services_error_service__WEBPACK_IMPORTED_MODULE_25__.ErrorService), _angular_core__WEBPACK_IMPORTED_MODULE_24__["ɵɵdirectiveInject"](src_app_core_shared_tracking_track_api_service__WEBPACK_IMPORTED_MODULE_26__.TrackApiService), _angular_core__WEBPACK_IMPORTED_MODULE_24__["ɵɵdirectiveInject"](src_app_core_shared_tracking_background_tracking_service__WEBPACK_IMPORTED_MODULE_27__.BackgroundTrackingService), _angular_core__WEBPACK_IMPORTED_MODULE_24__["ɵɵdirectiveInject"](src_app_core_shared_tracking_trip_service__WEBPACK_IMPORTED_MODULE_28__.TripService), _angular_core__WEBPACK_IMPORTED_MODULE_24__["ɵɵdirectiveInject"](src_app_core_shared_tracking_local_trips_service__WEBPACK_IMPORTED_MODULE_29__.LocalTripsService), _angular_core__WEBPACK_IMPORTED_MODULE_24__["ɵɵdirectiveInject"](src_app_core_shared_services_alert_service__WEBPACK_IMPORTED_MODULE_30__.AlertService), _angular_core__WEBPACK_IMPORTED_MODULE_24__["ɵɵdirectiveInject"](src_app_core_shared_services_campaign_service__WEBPACK_IMPORTED_MODULE_31__.CampaignService), _angular_core__WEBPACK_IMPORTED_MODULE_24__["ɵɵdirectiveInject"](_angular_router__WEBPACK_IMPORTED_MODULE_32__.ActivatedRoute));
  }, this.ɵcmp = /*@__PURE__*/_angular_core__WEBPACK_IMPORTED_MODULE_24__["ɵɵdefineComponent"]({
    type: TripsPage,
    selectors: [["app-trips"]],
    standalone: false,
    decls: 32,
    vars: 42,
    consts: [["noTrips", ""], ["appHeader", ""], ["color", "playgo", 3, "ngStyle"], [1, "ion-no-padding", "ion-no-margin"], [1, "ion-align-items-center"], ["size", "6"], ["interface", "popover", 3, "ionChange", "interfaceOptions", "value", "selectedText"], ["value", "NO_FILTER"], [3, "value", 4, "ngFor", "ngForOf"], ["size", "6", 1, "ion-text-right"], ["interface", "popover", 1, "campaign-filter", 3, "ionChange", "interfaceOptions", "value", "selectedText"], ["class", "campaign-filter", 3, "value", 4, "ngFor", "ngForOf"], ["appContent", ""], [3, "request", "items", "allItemsInTemplate", "resetItems", "response"], ["appInfiniteScrollContent", ""], [3, "value"], [1, "campaign-filter", 3, "value"], [4, "ngIf", "ngIfElse"], [4, "ngFor", "ngForOf", "ngForTrackBy"], ["color", "playgo", "sticky", "", "class", "ion-padding", 4, "ngIf"], ["color", "playgo", "sticky", "", 1, "ion-padding"], [3, "trip", "isOneDayTrip", "multiModalTrip", 4, "ngIf"], [4, "ngIf"], [3, "trip", "isOneDayTrip", "multiModalTrip"], [1, "ion-text-end"], [3, "trip", "isOneDayTrip", "indexTrip", "length", "multiModalTrip", 4, "ngIf"], [3, "trip", "isOneDayTrip", "indexTrip", "length", "multiModalTrip"], [1, "empty-trips"]],
    template: function TripsPage_Template(rf, ctx) {
      if (rf & 1) {
        const _r1 = _angular_core__WEBPACK_IMPORTED_MODULE_24__["ɵɵgetCurrentView"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_24__["ɵɵelement"](0, "ion-header", 1);
        _angular_core__WEBPACK_IMPORTED_MODULE_24__["ɵɵelementStart"](1, "ion-item", 2);
        _angular_core__WEBPACK_IMPORTED_MODULE_24__["ɵɵpipe"](2, "async");
        _angular_core__WEBPACK_IMPORTED_MODULE_24__["ɵɵelementStart"](3, "ion-grid", 3)(4, "ion-row", 4)(5, "ion-col", 5)(6, "ion-select", 6);
        _angular_core__WEBPACK_IMPORTED_MODULE_24__["ɵɵpipe"](7, "async");
        _angular_core__WEBPACK_IMPORTED_MODULE_24__["ɵɵpipe"](8, "async");
        _angular_core__WEBPACK_IMPORTED_MODULE_24__["ɵɵpipe"](9, "translate");
        _angular_core__WEBPACK_IMPORTED_MODULE_24__["ɵɵlistener"]("ionChange", function TripsPage_Template_ion_select_ionChange_6_listener($event) {
          _angular_core__WEBPACK_IMPORTED_MODULE_23__["ɵɵrestoreView"](_r1);
          return _angular_core__WEBPACK_IMPORTED_MODULE_23__["ɵɵresetView"](ctx.monthFilterSubject.next($event.target.value));
        });
        _angular_core__WEBPACK_IMPORTED_MODULE_24__["ɵɵelementStart"](10, "ion-select-option", 7);
        _angular_core__WEBPACK_IMPORTED_MODULE_24__["ɵɵtext"](11);
        _angular_core__WEBPACK_IMPORTED_MODULE_24__["ɵɵpipe"](12, "translate");
        _angular_core__WEBPACK_IMPORTED_MODULE_24__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_24__["ɵɵtemplate"](13, TripsPage_ion_select_option_13_Template, 3, 5, "ion-select-option", 8);
        _angular_core__WEBPACK_IMPORTED_MODULE_24__["ɵɵpipe"](14, "async");
        _angular_core__WEBPACK_IMPORTED_MODULE_24__["ɵɵelementEnd"]()();
        _angular_core__WEBPACK_IMPORTED_MODULE_24__["ɵɵelementStart"](15, "ion-col", 9)(16, "ion-select", 10);
        _angular_core__WEBPACK_IMPORTED_MODULE_24__["ɵɵpipe"](17, "async");
        _angular_core__WEBPACK_IMPORTED_MODULE_24__["ɵɵpipe"](18, "async");
        _angular_core__WEBPACK_IMPORTED_MODULE_24__["ɵɵpipe"](19, "translate");
        _angular_core__WEBPACK_IMPORTED_MODULE_24__["ɵɵlistener"]("ionChange", function TripsPage_Template_ion_select_ionChange_16_listener($event) {
          _angular_core__WEBPACK_IMPORTED_MODULE_23__["ɵɵrestoreView"](_r1);
          return _angular_core__WEBPACK_IMPORTED_MODULE_23__["ɵɵresetView"](ctx.campaignFilterSubject.next($event.target.value));
        });
        _angular_core__WEBPACK_IMPORTED_MODULE_24__["ɵɵelementStart"](20, "ion-select-option", 7);
        _angular_core__WEBPACK_IMPORTED_MODULE_24__["ɵɵtext"](21);
        _angular_core__WEBPACK_IMPORTED_MODULE_24__["ɵɵpipe"](22, "translate");
        _angular_core__WEBPACK_IMPORTED_MODULE_24__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_24__["ɵɵtemplate"](23, TripsPage_ion_select_option_23_Template, 3, 4, "ion-select-option", 11);
        _angular_core__WEBPACK_IMPORTED_MODULE_24__["ɵɵpipe"](24, "async");
        _angular_core__WEBPACK_IMPORTED_MODULE_24__["ɵɵelementEnd"]()()()()();
        _angular_core__WEBPACK_IMPORTED_MODULE_24__["ɵɵelementStart"](25, "ion-content", 12)(26, "app-infinite-scroll", 13);
        _angular_core__WEBPACK_IMPORTED_MODULE_24__["ɵɵpipe"](27, "async");
        _angular_core__WEBPACK_IMPORTED_MODULE_24__["ɵɵpipe"](28, "async");
        _angular_core__WEBPACK_IMPORTED_MODULE_24__["ɵɵlistener"]("request", function TripsPage_Template_app_infinite_scroll_request_26_listener($event) {
          _angular_core__WEBPACK_IMPORTED_MODULE_23__["ɵɵrestoreView"](_r1);
          return _angular_core__WEBPACK_IMPORTED_MODULE_23__["ɵɵresetView"](ctx.scrollRequestSubject.next($event));
        })("items", function TripsPage_Template_app_infinite_scroll_items_26_listener($event) {
          _angular_core__WEBPACK_IMPORTED_MODULE_23__["ɵɵrestoreView"](_r1);
          return _angular_core__WEBPACK_IMPORTED_MODULE_23__["ɵɵresetView"](ctx.serverTripsSubject.next($event));
        });
        _angular_core__WEBPACK_IMPORTED_MODULE_24__["ɵɵtemplate"](29, TripsPage_ng_template_29_Template, 2, 4, "ng-template", 14)(30, TripsPage_ng_template_30_Template, 3, 3, "ng-template", null, 0, _angular_core__WEBPACK_IMPORTED_MODULE_24__["ɵɵtemplateRefExtractor"]);
        _angular_core__WEBPACK_IMPORTED_MODULE_24__["ɵɵelementEnd"]()();
      }
      if (rf & 2) {
        _angular_core__WEBPACK_IMPORTED_MODULE_24__["ɵɵadvance"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_24__["ɵɵproperty"]("ngStyle", _angular_core__WEBPACK_IMPORTED_MODULE_24__["ɵɵpipeBind1"](2, 14, ctx.campaignFilterStyle$));
        _angular_core__WEBPACK_IMPORTED_MODULE_24__["ɵɵadvance"](5);
        _angular_core__WEBPACK_IMPORTED_MODULE_24__["ɵɵproperty"]("interfaceOptions", _angular_core__WEBPACK_IMPORTED_MODULE_24__["ɵɵpureFunction0"](40, _c0))("value", _angular_core__WEBPACK_IMPORTED_MODULE_24__["ɵɵpipeBind1"](7, 16, ctx.monthFilterSubject))("selectedText", _angular_core__WEBPACK_IMPORTED_MODULE_24__["ɵɵpipeBind1"](8, 18, ctx.monthFilterSubject) === "NO_FILTER" ? _angular_core__WEBPACK_IMPORTED_MODULE_24__["ɵɵpipeBind1"](9, 20, "trips.filter_all_the_time") : undefined);
        _angular_core__WEBPACK_IMPORTED_MODULE_24__["ɵɵadvance"](5);
        _angular_core__WEBPACK_IMPORTED_MODULE_24__["ɵɵtextInterpolate1"](" ", _angular_core__WEBPACK_IMPORTED_MODULE_24__["ɵɵpipeBind1"](12, 22, "trips.filter_all_the_time"), " ");
        _angular_core__WEBPACK_IMPORTED_MODULE_24__["ɵɵadvance"](2);
        _angular_core__WEBPACK_IMPORTED_MODULE_24__["ɵɵproperty"]("ngForOf", _angular_core__WEBPACK_IMPORTED_MODULE_24__["ɵɵpipeBind1"](14, 24, ctx.months$));
        _angular_core__WEBPACK_IMPORTED_MODULE_24__["ɵɵadvance"](3);
        _angular_core__WEBPACK_IMPORTED_MODULE_24__["ɵɵproperty"]("interfaceOptions", _angular_core__WEBPACK_IMPORTED_MODULE_24__["ɵɵpureFunction0"](41, _c0))("value", _angular_core__WEBPACK_IMPORTED_MODULE_24__["ɵɵpipeBind1"](17, 26, ctx.campaignFilter$))("selectedText", _angular_core__WEBPACK_IMPORTED_MODULE_24__["ɵɵpipeBind1"](18, 28, ctx.campaignFilter$) === "NO_FILTER" ? _angular_core__WEBPACK_IMPORTED_MODULE_24__["ɵɵpipeBind1"](19, 30, "trips.filter_all_campaigns") : undefined);
        _angular_core__WEBPACK_IMPORTED_MODULE_24__["ɵɵadvance"](5);
        _angular_core__WEBPACK_IMPORTED_MODULE_24__["ɵɵtextInterpolate1"](" ", _angular_core__WEBPACK_IMPORTED_MODULE_24__["ɵɵpipeBind1"](22, 32, "trips.filter_all_campaigns"), " ");
        _angular_core__WEBPACK_IMPORTED_MODULE_24__["ɵɵadvance"](2);
        _angular_core__WEBPACK_IMPORTED_MODULE_24__["ɵɵproperty"]("ngForOf", _angular_core__WEBPACK_IMPORTED_MODULE_24__["ɵɵpipeBind1"](24, 34, ctx.myCampaigns$));
        _angular_core__WEBPACK_IMPORTED_MODULE_24__["ɵɵadvance"](3);
        _angular_core__WEBPACK_IMPORTED_MODULE_24__["ɵɵproperty"]("allItemsInTemplate", true)("resetItems", _angular_core__WEBPACK_IMPORTED_MODULE_24__["ɵɵpipeBind1"](27, 36, ctx.resetItems$))("response", _angular_core__WEBPACK_IMPORTED_MODULE_24__["ɵɵpipeBind1"](28, 38, ctx.tripsResponse$));
      }
    },
    styles: [".item-divider-sticky[_ngcontent-%COMP%] {\n  top: -1px;\n}\n\n.empty-trips[_ngcontent-%COMP%] {\n  margin: auto;\n  padding: 8px;\n  font-size: 20px;\n  text-align: center;\n  -ms-transform: translateY(-50%);\n}\n\n.campaign-filter[_ngcontent-%COMP%] {\n  right: 0px;\n}\n\nion-card[_ngcontent-%COMP%] {\n  background: #f2f6fa;\n  font-size: 18px;\n  font-weight: 600;\n}\n/*# sourceMappingURL=data:application/json;charset=utf-8;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbIndlYnBhY2s6Ly8uL3NyYy9hcHAvcGFnZXMvdHJpcHMvdHJpcHMucGFnZS5zY3NzIl0sIm5hbWVzIjpbXSwibWFwcGluZ3MiOiJBQUFBO0VBQ0UsU0FBQTtBQUNGOztBQUNBO0VBQ0UsWUFBQTtFQUNBLFlBQUE7RUFDQSxlQUFBO0VBQ0Esa0JBQUE7RUFDQSwrQkFBQTtBQUVGOztBQUFBO0VBQ0UsVUFBQTtBQUdGOztBQURBO0VBQ0UsbUJBQUE7RUFDQSxlQUFBO0VBQ0EsZ0JBQUE7QUFJRiIsInNvdXJjZXNDb250ZW50IjpbIi5pdGVtLWRpdmlkZXItc3RpY2t5IHtcbiAgdG9wOiAtMXB4O1xufVxuLmVtcHR5LXRyaXBzIHtcbiAgbWFyZ2luOiBhdXRvO1xuICBwYWRkaW5nOiA4cHg7XG4gIGZvbnQtc2l6ZTogMjBweDtcbiAgdGV4dC1hbGlnbjogY2VudGVyO1xuICAtbXMtdHJhbnNmb3JtOiB0cmFuc2xhdGVZKC01MCUpO1xufVxuLmNhbXBhaWduLWZpbHRlciB7XG4gIHJpZ2h0OiAwcHg7XG59XG5pb24tY2FyZCB7XG4gIGJhY2tncm91bmQ6ICNmMmY2ZmE7XG4gIGZvbnQtc2l6ZTogMThweDtcbiAgZm9udC13ZWlnaHQ6IDYwMDtcbn1cbiJdLCJzb3VyY2VSb290IjoiIn0= */"]
  }));
}
_staticBlock();

/***/ }),

/***/ 93185:
/*!*************************************************!*\
  !*** ./node_modules/lodash-es/_baseExtremum.js ***!
  \*************************************************/
/***/ ((__unused_webpack___webpack_module__, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "default": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var _isSymbol_js__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./isSymbol.js */ 31200);


/**
 * The base implementation of methods like `_.max` and `_.min` which accepts a
 * `comparator` to determine the extremum value.
 *
 * @private
 * @param {Array} array The array to iterate over.
 * @param {Function} iteratee The iteratee invoked per iteration.
 * @param {Function} comparator The comparator used to compare values.
 * @returns {*} Returns the extremum value.
 */
function baseExtremum(array, iteratee, comparator) {
  var index = -1,
    length = array.length;
  while (++index < length) {
    var value = array[index],
      current = iteratee(value);
    if (current != null && (computed === undefined ? current === current && !(0,_isSymbol_js__WEBPACK_IMPORTED_MODULE_0__["default"])(current) : comparator(current, computed))) {
      var computed = current,
        result = value;
    }
  }
  return result;
}
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (baseExtremum);

/***/ }),

/***/ 94120:
/*!*****************************************************!*\
  !*** ./node_modules/lodash-es/_compareAscending.js ***!
  \*****************************************************/
/***/ ((__unused_webpack___webpack_module__, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "default": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var _isSymbol_js__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./isSymbol.js */ 31200);


/**
 * Compares values to sort them in ascending order.
 *
 * @private
 * @param {*} value The value to compare.
 * @param {*} other The other value to compare.
 * @returns {number} Returns the sort order indicator for `value`.
 */
function compareAscending(value, other) {
  if (value !== other) {
    var valIsDefined = value !== undefined,
      valIsNull = value === null,
      valIsReflexive = value === value,
      valIsSymbol = (0,_isSymbol_js__WEBPACK_IMPORTED_MODULE_0__["default"])(value);
    var othIsDefined = other !== undefined,
      othIsNull = other === null,
      othIsReflexive = other === other,
      othIsSymbol = (0,_isSymbol_js__WEBPACK_IMPORTED_MODULE_0__["default"])(other);
    if (!othIsNull && !othIsSymbol && !valIsSymbol && value > other || valIsSymbol && othIsDefined && othIsReflexive && !othIsNull && !othIsSymbol || valIsNull && othIsDefined && othIsReflexive || !valIsDefined && othIsReflexive || !valIsReflexive) {
      return 1;
    }
    if (!valIsNull && !valIsSymbol && !othIsSymbol && value < other || othIsSymbol && valIsDefined && valIsReflexive && !valIsNull && !valIsSymbol || othIsNull && valIsDefined && valIsReflexive || !othIsDefined && valIsReflexive || !othIsReflexive) {
      return -1;
    }
  }
  return 0;
}
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (compareAscending);

/***/ }),

/***/ 97757:
/*!***************************************************************************!*\
  !*** ./src/app/core/api/generated/controllers/trackController.service.ts ***!
  \***************************************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   TrackControllerService: () => (/* binding */ TrackControllerService)
/* harmony export */ });
/* harmony import */ var src_environments_environment__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! src/environments/environment */ 45312);
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @angular/core */ 34205);
/* harmony import */ var _angular_common_http__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @angular/common/http */ 63855);
var _staticBlock;
/**
 * Play&Go Project
 * No description provided (generated by Swagger Codegen https://github.com/swagger-api/swagger-codegen)
 *
 * OpenAPI spec version: 2.0
 * Contact: info@smartcommunitylab.it
 *
 * NOTE: This class is auto generated by the swagger code generator program.
 * https://github.com/swagger-api/swagger-codegen.git
 * Do not edit the class manually.
 */



class TrackControllerService {
  constructor(http) {
    this.http = http;
  }
  /**
   * getTrackedInstanceInfoList
   *
   * @param page Results page you want to retrieve (0..N)
   * @param size Number of records per page
   * @param dateFrom UTC millis
   * @param sort Sorting option: field,[asc,desc]
   * @param dateTo UTC millis
   * @param campaignId campaignId
   */
  getTrackedInstanceInfoListUsingGET(args) {
    const {
      page,
      size,
      dateFrom,
      sort,
      dateTo,
      campaignId
    } = args;
    return this.http.request('get', src_environments_environment__WEBPACK_IMPORTED_MODULE_0__.environment.serverUrl.api + `/playandgo/api/track/player`, {
      params: removeNullOrUndefined({
        dateFrom,
        page,
        size,
        sort,
        dateTo,
        campaignId
      })
    });
  }
  /**
   * getTrackedInstanceInfo
   *
   * @param trackedInstanceId trackedInstanceId
   * @param campaignId campaignId
   */
  getTrackedInstanceInfoUsingGET1(args) {
    const {
      trackedInstanceId,
      campaignId
    } = args;
    return this.http.request('get', src_environments_environment__WEBPACK_IMPORTED_MODULE_0__.environment.serverUrl.api + `/playandgo/api/track/player/${encodeURIComponent(String(trackedInstanceId))}`, {
      params: removeNullOrUndefined({
        campaignId
      })
    });
  }
  /**
   * storeGeolocationEvent
   *
   * @param body
   */
  storeGeolocationEventUsingPOST(body) {
    return this.http.request('post', src_environments_environment__WEBPACK_IMPORTED_MODULE_0__.environment.serverUrl.api + `/playandgo/api/track/player/geolocations`, {
      body
    });
  }
  static #_ = _staticBlock = () => (this.ɵfac = function TrackControllerService_Factory(__ngFactoryType__) {
    return new (__ngFactoryType__ || TrackControllerService)(_angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵinject"](_angular_common_http__WEBPACK_IMPORTED_MODULE_2__.HttpClient));
  }, this.ɵprov = /*@__PURE__*/_angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵdefineInjectable"]({
    token: TrackControllerService,
    factory: TrackControllerService.ɵfac,
    providedIn: 'root'
  }));
}
_staticBlock();
function removeNullOrUndefined(obj) {
  const newObj = {};
  Object.keys(obj).forEach(key => {
    if (obj[key] != null) {
      newObj[key] = obj[key];
    }
  });
  return newObj;
}

/***/ }),

/***/ 98445:
/*!*****************************************************************!*\
  !*** ./node_modules/rxjs/dist/esm/internal/operators/expand.js ***!
  \*****************************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   expand: () => (/* binding */ expand)
/* harmony export */ });
/* harmony import */ var _util_lift__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ../util/lift */ 50819);
/* harmony import */ var _mergeInternals__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ./mergeInternals */ 48735);


function expand(project, concurrent = Infinity, scheduler) {
  concurrent = (concurrent || 0) < 1 ? Infinity : concurrent;
  return (0,_util_lift__WEBPACK_IMPORTED_MODULE_0__.operate)((source, subscriber) => (0,_mergeInternals__WEBPACK_IMPORTED_MODULE_1__.mergeInternals)(source, subscriber, project, concurrent, undefined, true, scheduler));
}

/***/ })

}]);
//# sourceMappingURL=src_app_pages_trips_trips_module_ts.js.map