"use strict";
(self["webpackChunkapp"] = self["webpackChunkapp"] || []).push([["src_app_pages_user-profile_user-profile_module_ts"],{

/***/ 16749:
/*!**********************************************!*\
  !*** ./node_modules/lodash-es/_baseIsNaN.js ***!
  \**********************************************/
/***/ ((__unused_webpack___webpack_module__, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "default": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/**
 * The base implementation of `_.isNaN` without support for number objects.
 *
 * @private
 * @param {*} value The value to check.
 * @returns {boolean} Returns `true` if `value` is `NaN`, else `false`.
 */
function baseIsNaN(value) {
  return value !== value;
}
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (baseIsNaN);

/***/ }),

/***/ 27241:
/*!*********************************************************!*\
  !*** ./src/app/pages/user-profile/user-profile.page.ts ***!
  \*********************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   UserProfilePage: () => (/* binding */ UserProfilePage)
/* harmony export */ });
/* harmony import */ var rxjs__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! rxjs */ 19999);
/* harmony import */ var rxjs__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! rxjs */ 91817);
/* harmony import */ var rxjs__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! rxjs */ 70271);
/* harmony import */ var rxjs__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! rxjs */ 86301);
/* harmony import */ var rxjs__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! rxjs */ 36647);
/* harmony import */ var rxjs__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! rxjs */ 98764);
/* harmony import */ var lodash_es__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! lodash-es */ 99009);
/* harmony import */ var lodash_es__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(/*! lodash-es */ 92434);
/* harmony import */ var src_app_core_shared_rxjs_utils__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(/*! src/app/core/shared/rxjs.utils */ 86040);
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_9__ = __webpack_require__(/*! @angular/core */ 12481);
/* harmony import */ var _angular_router__WEBPACK_IMPORTED_MODULE_10__ = __webpack_require__(/*! @angular/router */ 85422);
/* harmony import */ var src_app_core_shared_services_error_service__WEBPACK_IMPORTED_MODULE_11__ = __webpack_require__(/*! src/app/core/shared/services/error.service */ 46078);
/* harmony import */ var src_app_core_shared_services_user_service__WEBPACK_IMPORTED_MODULE_12__ = __webpack_require__(/*! src/app/core/shared/services/user.service */ 89815);
/* harmony import */ var src_app_core_shared_services_campaign_service__WEBPACK_IMPORTED_MODULE_13__ = __webpack_require__(/*! src/app/core/shared/services/campaign.service */ 76658);
/* harmony import */ var _angular_common__WEBPACK_IMPORTED_MODULE_14__ = __webpack_require__(/*! @angular/common */ 93683);
/* harmony import */ var _ionic_angular__WEBPACK_IMPORTED_MODULE_15__ = __webpack_require__(/*! @ionic/angular */ 21507);
/* harmony import */ var _core_shared_layout_header_header_directive__WEBPACK_IMPORTED_MODULE_16__ = __webpack_require__(/*! ../../core/shared/layout/header/header.directive */ 85039);
/* harmony import */ var _core_shared_layout_content_content_directive__WEBPACK_IMPORTED_MODULE_17__ = __webpack_require__(/*! ../../core/shared/layout/content/content.directive */ 75855);
/* harmony import */ var _transport_stat_transport_stat_component__WEBPACK_IMPORTED_MODULE_18__ = __webpack_require__(/*! ./transport-stat/transport-stat.component */ 47673);
/* harmony import */ var _campaign_stat_campaign_stat_component__WEBPACK_IMPORTED_MODULE_19__ = __webpack_require__(/*! ./campaign-stat/campaign-stat.component */ 46943);
var _staticBlock;














function UserProfilePage_ng_container_11_Template(rf, ctx) {
  if (rf & 1) {
    _angular_core__WEBPACK_IMPORTED_MODULE_9__["ɵɵelementContainerStart"](0);
    _angular_core__WEBPACK_IMPORTED_MODULE_9__["ɵɵelement"](1, "app-campaign-stat", 7);
    _angular_core__WEBPACK_IMPORTED_MODULE_9__["ɵɵpipe"](2, "async");
    _angular_core__WEBPACK_IMPORTED_MODULE_9__["ɵɵelementContainerEnd"]();
  }
  if (rf & 2) {
    const campaign_r1 = ctx.$implicit;
    const ctx_r1 = _angular_core__WEBPACK_IMPORTED_MODULE_9__["ɵɵnextContext"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_9__["ɵɵadvance"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_9__["ɵɵproperty"]("playerId", _angular_core__WEBPACK_IMPORTED_MODULE_9__["ɵɵpipeBind1"](2, 2, ctx_r1.userId$))("campaign", campaign_r1);
  }
}
class UserProfilePage {
  // public campaigns: PlayerCampaign[] = [];
  constructor(route, errorService, userService, campaignService) {
    this.route = route;
    this.errorService = errorService;
    this.userService = userService;
    this.campaignService = campaignService;
    this.userId$ = this.route.params.pipe((0,rxjs__WEBPACK_IMPORTED_MODULE_2__.map)(params => params.id), (0,rxjs__WEBPACK_IMPORTED_MODULE_1__.distinctUntilChanged)(), (0,rxjs__WEBPACK_IMPORTED_MODULE_3__.shareReplay)(1));
    this.userNickname$ = this.route.params.pipe((0,rxjs__WEBPACK_IMPORTED_MODULE_2__.map)(params => params.nickname), (0,rxjs__WEBPACK_IMPORTED_MODULE_1__.distinctUntilChanged)(), (0,rxjs__WEBPACK_IMPORTED_MODULE_3__.shareReplay)(1));
    this.userAvatar$ = this.userId$.pipe((0,rxjs__WEBPACK_IMPORTED_MODULE_4__.switchMap)(userId => this.userService.getOtherPlayerAvatar(userId).pipe(this.errorService.getErrorHandler())), (0,rxjs__WEBPACK_IMPORTED_MODULE_3__.shareReplay)(1));
    this.campaigns$ = (0,rxjs__WEBPACK_IMPORTED_MODULE_0__.combineLatest)([this.userId$, this.campaignService.myCampaigns$]).pipe((0,rxjs__WEBPACK_IMPORTED_MODULE_4__.switchMap)(([userId, myCampaigns]) => this.campaignService.getCampaignByPlayerId(userId).pipe((0,src_app_core_shared_rxjs_utils__WEBPACK_IMPORTED_MODULE_8__.tapLog)('Initial Campaign'), (0,rxjs__WEBPACK_IMPORTED_MODULE_2__.map)(
    //filter my campaigns in order to have only common campaigns
    otherUserCampaigns => {
      const intersection = (0,lodash_es__WEBPACK_IMPORTED_MODULE_6__["default"])(otherUserCampaigns.map(campaign => campaign.campaignId), myCampaigns.map(campaign => campaign?.campaign?.campaignId), lodash_es__WEBPACK_IMPORTED_MODULE_7__["default"]);
      return otherUserCampaigns.filter(campaign => intersection.includes(campaign.campaignId) && campaign.type !== 'personal' && campaign.type !== 'company');
    }), (0,src_app_core_shared_rxjs_utils__WEBPACK_IMPORTED_MODULE_8__.tapLog)('filteredcampaign'),
    ////filter personal campaign and campaigns without challenge 'personal' && 'company'
    this.errorService.getErrorHandler())), (0,rxjs__WEBPACK_IMPORTED_MODULE_5__.tap)(campaigns => console.log(campaigns)), (0,rxjs__WEBPACK_IMPORTED_MODULE_3__.shareReplay)(1));
  }
  ngOnInit() {}
  static #_ = _staticBlock = () => (this.ɵfac = function UserProfilePage_Factory(__ngFactoryType__) {
    return new (__ngFactoryType__ || UserProfilePage)(_angular_core__WEBPACK_IMPORTED_MODULE_9__["ɵɵdirectiveInject"](_angular_router__WEBPACK_IMPORTED_MODULE_10__.ActivatedRoute), _angular_core__WEBPACK_IMPORTED_MODULE_9__["ɵɵdirectiveInject"](src_app_core_shared_services_error_service__WEBPACK_IMPORTED_MODULE_11__.ErrorService), _angular_core__WEBPACK_IMPORTED_MODULE_9__["ɵɵdirectiveInject"](src_app_core_shared_services_user_service__WEBPACK_IMPORTED_MODULE_12__.UserService), _angular_core__WEBPACK_IMPORTED_MODULE_9__["ɵɵdirectiveInject"](src_app_core_shared_services_campaign_service__WEBPACK_IMPORTED_MODULE_13__.CampaignService));
  }, this.ɵcmp = /*@__PURE__*/_angular_core__WEBPACK_IMPORTED_MODULE_9__["ɵɵdefineComponent"]({
    type: UserProfilePage,
    selectors: [["app-user-profile"]],
    standalone: false,
    decls: 13,
    vars: 13,
    consts: [["appHeader", ""], ["appContent", "", 3, "fullscreen"], [1, "user-intro"], [3, "src"], [1, "nickname"], [3, "playerId"], [4, "ngFor", "ngForOf"], [3, "playerId", "campaign"]],
    template: function UserProfilePage_Template(rf, ctx) {
      if (rf & 1) {
        _angular_core__WEBPACK_IMPORTED_MODULE_9__["ɵɵelement"](0, "ion-header", 0);
        _angular_core__WEBPACK_IMPORTED_MODULE_9__["ɵɵelementStart"](1, "ion-content", 1)(2, "div", 2)(3, "ion-avatar");
        _angular_core__WEBPACK_IMPORTED_MODULE_9__["ɵɵelement"](4, "img", 3);
        _angular_core__WEBPACK_IMPORTED_MODULE_9__["ɵɵpipe"](5, "async");
        _angular_core__WEBPACK_IMPORTED_MODULE_9__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_9__["ɵɵelementStart"](6, "div", 4);
        _angular_core__WEBPACK_IMPORTED_MODULE_9__["ɵɵtext"](7);
        _angular_core__WEBPACK_IMPORTED_MODULE_9__["ɵɵpipe"](8, "async");
        _angular_core__WEBPACK_IMPORTED_MODULE_9__["ɵɵelementEnd"]()();
        _angular_core__WEBPACK_IMPORTED_MODULE_9__["ɵɵelement"](9, "app-transport-stat", 5);
        _angular_core__WEBPACK_IMPORTED_MODULE_9__["ɵɵpipe"](10, "async");
        _angular_core__WEBPACK_IMPORTED_MODULE_9__["ɵɵtemplate"](11, UserProfilePage_ng_container_11_Template, 3, 4, "ng-container", 6);
        _angular_core__WEBPACK_IMPORTED_MODULE_9__["ɵɵpipe"](12, "async");
        _angular_core__WEBPACK_IMPORTED_MODULE_9__["ɵɵelementEnd"]();
      }
      if (rf & 2) {
        let tmp_1_0;
        _angular_core__WEBPACK_IMPORTED_MODULE_9__["ɵɵadvance"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_9__["ɵɵproperty"]("fullscreen", true);
        _angular_core__WEBPACK_IMPORTED_MODULE_9__["ɵɵadvance"](3);
        _angular_core__WEBPACK_IMPORTED_MODULE_9__["ɵɵproperty"]("src", (tmp_1_0 = _angular_core__WEBPACK_IMPORTED_MODULE_9__["ɵɵpipeBind1"](5, 5, ctx.userAvatar$)) == null ? null : tmp_1_0.avatarUrl, _angular_core__WEBPACK_IMPORTED_MODULE_9__["ɵɵsanitizeUrl"]);
        _angular_core__WEBPACK_IMPORTED_MODULE_9__["ɵɵadvance"](3);
        _angular_core__WEBPACK_IMPORTED_MODULE_9__["ɵɵtextInterpolate"](_angular_core__WEBPACK_IMPORTED_MODULE_9__["ɵɵpipeBind1"](8, 7, ctx.userNickname$));
        _angular_core__WEBPACK_IMPORTED_MODULE_9__["ɵɵadvance"](2);
        _angular_core__WEBPACK_IMPORTED_MODULE_9__["ɵɵproperty"]("playerId", _angular_core__WEBPACK_IMPORTED_MODULE_9__["ɵɵpipeBind1"](10, 9, ctx.userId$));
        _angular_core__WEBPACK_IMPORTED_MODULE_9__["ɵɵadvance"](2);
        _angular_core__WEBPACK_IMPORTED_MODULE_9__["ɵɵproperty"]("ngForOf", _angular_core__WEBPACK_IMPORTED_MODULE_9__["ɵɵpipeBind1"](12, 11, ctx.campaigns$));
      }
    },
    dependencies: [_angular_common__WEBPACK_IMPORTED_MODULE_14__.NgForOf, _ionic_angular__WEBPACK_IMPORTED_MODULE_15__.IonAvatar, _ionic_angular__WEBPACK_IMPORTED_MODULE_15__.IonContent, _ionic_angular__WEBPACK_IMPORTED_MODULE_15__.IonHeader, _core_shared_layout_header_header_directive__WEBPACK_IMPORTED_MODULE_16__.HeaderDirective, _core_shared_layout_content_content_directive__WEBPACK_IMPORTED_MODULE_17__.ContentDirective, _transport_stat_transport_stat_component__WEBPACK_IMPORTED_MODULE_18__.TransportStatComponent, _campaign_stat_campaign_stat_component__WEBPACK_IMPORTED_MODULE_19__.CampaignStatComponent, _angular_common__WEBPACK_IMPORTED_MODULE_14__.AsyncPipe],
    styles: [".user-intro[_ngcontent-%COMP%] {\n  text-align: center;\n  margin: 52px auto;\n  width: 124px;\n  height: 124px;\n}\n.user-intro[_ngcontent-%COMP%]   ion-avatar[_ngcontent-%COMP%] {\n  margin: auto;\n  height: 102px;\n  width: 102px;\n}\n.user-intro[_ngcontent-%COMP%]   .nickname[_ngcontent-%COMP%] {\n  margin-top: 32px;\n  font-weight: 600;\n  font-size: 18px;\n}\n/*# sourceMappingURL=data:application/json;charset=utf-8;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbIndlYnBhY2s6Ly8uL3NyYy9hcHAvcGFnZXMvdXNlci1wcm9maWxlL3VzZXItcHJvZmlsZS5wYWdlLnNjc3MiXSwibmFtZXMiOltdLCJtYXBwaW5ncyI6IkFBQUE7RUFDRSxrQkFBQTtFQUNBLGlCQUFBO0VBQ0EsWUFBQTtFQUNBLGFBQUE7QUFDRjtBQUFFO0VBQ0UsWUFBQTtFQUNBLGFBQUE7RUFDQSxZQUFBO0FBRUo7QUFBRTtFQUNFLGdCQUFBO0VBQ0EsZ0JBQUE7RUFDQSxlQUFBO0FBRUoiLCJzb3VyY2VzQ29udGVudCI6WyIudXNlci1pbnRybyB7XG4gIHRleHQtYWxpZ246IGNlbnRlcjtcbiAgbWFyZ2luOiA1MnB4IGF1dG87XG4gIHdpZHRoOiAxMjRweDtcbiAgaGVpZ2h0OiAxMjRweDtcbiAgaW9uLWF2YXRhciB7XG4gICAgbWFyZ2luOiBhdXRvO1xuICAgIGhlaWdodDogMTAycHg7XG4gICAgd2lkdGg6IDEwMnB4O1xuICB9XG4gIC5uaWNrbmFtZSB7XG4gICAgbWFyZ2luLXRvcDogMzJweDtcbiAgICBmb250LXdlaWdodDogNjAwO1xuICAgIGZvbnQtc2l6ZTogMThweDtcbiAgfVxufVxuIl0sInNvdXJjZVJvb3QiOiIifQ== */"]
  }));
}
_staticBlock();

/***/ }),

/***/ 29281:
/*!************************************************!*\
  !*** ./node_modules/lodash-es/_baseIndexOf.js ***!
  \************************************************/
/***/ ((__unused_webpack___webpack_module__, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "default": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var _baseFindIndex_js__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./_baseFindIndex.js */ 14681);
/* harmony import */ var _baseIsNaN_js__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ./_baseIsNaN.js */ 16749);
/* harmony import */ var _strictIndexOf_js__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! ./_strictIndexOf.js */ 92905);




/**
 * The base implementation of `_.indexOf` without `fromIndex` bounds checks.
 *
 * @private
 * @param {Array} array The array to inspect.
 * @param {*} value The value to search for.
 * @param {number} fromIndex The index to search from.
 * @returns {number} Returns the index of the matched value, else `-1`.
 */
function baseIndexOf(array, value, fromIndex) {
  return value === value ? (0,_strictIndexOf_js__WEBPACK_IMPORTED_MODULE_2__["default"])(array, value, fromIndex) : (0,_baseFindIndex_js__WEBPACK_IMPORTED_MODULE_0__["default"])(array, _baseIsNaN_js__WEBPACK_IMPORTED_MODULE_1__["default"], fromIndex);
}
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (baseIndexOf);

/***/ }),

/***/ 33307:
/*!**************************************************!*\
  !*** ./node_modules/lodash-es/_arrayIncludes.js ***!
  \**************************************************/
/***/ ((__unused_webpack___webpack_module__, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "default": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var _baseIndexOf_js__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./_baseIndexOf.js */ 29281);


/**
 * A specialized version of `_.includes` for arrays without support for
 * specifying an index to search from.
 *
 * @private
 * @param {Array} [array] The array to inspect.
 * @param {*} target The value to search for.
 * @returns {boolean} Returns `true` if `target` is found, else `false`.
 */
function arrayIncludes(array, value) {
  var length = array == null ? 0 : array.length;
  return !!length && (0,_baseIndexOf_js__WEBPACK_IMPORTED_MODULE_0__["default"])(array, value, 0) > -1;
}
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (arrayIncludes);

/***/ }),

/***/ 36551:
/*!*******************************************************************!*\
  !*** ./src/app/pages/user-profile/user-profile-routing.module.ts ***!
  \*******************************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   UserProfilePageRoutingModule: () => (/* binding */ UserProfilePageRoutingModule)
/* harmony export */ });
/* harmony import */ var _angular_router__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! @angular/router */ 34487);
/* harmony import */ var _user_profile_page__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ./user-profile.page */ 27241);
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @angular/core */ 34205);
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @angular/core */ 12481);
var _staticBlock;




const routes = [{
  path: '',
  component: _user_profile_page__WEBPACK_IMPORTED_MODULE_1__.UserProfilePage,
  data: {
    title: 'userprofile.title',
    customHeader: true
  }
}];
class UserProfilePageRoutingModule {
  static #_ = _staticBlock = () => (this.ɵfac = function UserProfilePageRoutingModule_Factory(__ngFactoryType__) {
    return new (__ngFactoryType__ || UserProfilePageRoutingModule)();
  }, this.ɵmod = /*@__PURE__*/_angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵdefineNgModule"]({
    type: UserProfilePageRoutingModule
  }), this.ɵinj = /*@__PURE__*/_angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵdefineInjector"]({
    imports: [_angular_router__WEBPACK_IMPORTED_MODULE_0__.RouterModule.forChild(routes), _angular_router__WEBPACK_IMPORTED_MODULE_0__.RouterModule]
  }));
}
_staticBlock();
(function () {
  (typeof ngJitMode === "undefined" || ngJitMode) && _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵsetNgModuleScope"](UserProfilePageRoutingModule, {
    imports: [_angular_router__WEBPACK_IMPORTED_MODULE_0__.RouterModule],
    exports: [_angular_router__WEBPACK_IMPORTED_MODULE_0__.RouterModule]
  });
})();

/***/ }),

/***/ 38619:
/*!********************************************************!*\
  !*** ./node_modules/lodash-es/_castArrayLikeObject.js ***!
  \********************************************************/
/***/ ((__unused_webpack___webpack_module__, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "default": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var _isArrayLikeObject_js__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./isArrayLikeObject.js */ 92031);


/**
 * Casts `value` to an empty array if it's not an array like object.
 *
 * @private
 * @param {*} value The value to inspect.
 * @returns {Array|Object} Returns the cast array-like object.
 */
function castArrayLikeObject(value) {
  return (0,_isArrayLikeObject_js__WEBPACK_IMPORTED_MODULE_0__["default"])(value) ? value : [];
}
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (castArrayLikeObject);

/***/ }),

/***/ 46943:
/*!*****************************************************************************!*\
  !*** ./src/app/pages/user-profile/campaign-stat/campaign-stat.component.ts ***!
  \*****************************************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   CampaignStatComponent: () => (/* binding */ CampaignStatComponent)
/* harmony export */ });
/* harmony import */ var _Users_smartcommunitylab_Desktop_newWork_playAndGo_playGo_node_modules_babel_runtime_helpers_esm_asyncToGenerator_js__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./node_modules/@babel/runtime/helpers/esm/asyncToGenerator.js */ 89204);
/* harmony import */ var luxon__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! luxon */ 45967);
/* harmony import */ var rxjs__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! rxjs */ 56042);
/* harmony import */ var rxjs__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! rxjs */ 63617);
/* harmony import */ var rxjs__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! rxjs */ 70271);
/* harmony import */ var rxjs__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! rxjs */ 36647);
/* harmony import */ var src_app_core_shared_campaigns_campaign_utils__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! src/app/core/shared/campaigns/campaign.utils */ 14691);
/* harmony import */ var src_app_core_shared_time_utils__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(/*! src/app/core/shared/time.utils */ 27780);
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(/*! @angular/core */ 34205);
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_9__ = __webpack_require__(/*! @angular/core */ 12481);
/* harmony import */ var src_app_core_shared_services_challenge_service__WEBPACK_IMPORTED_MODULE_10__ = __webpack_require__(/*! src/app/core/shared/services/challenge.service */ 16561);
/* harmony import */ var src_app_core_shared_services_report_service__WEBPACK_IMPORTED_MODULE_11__ = __webpack_require__(/*! src/app/core/shared/services/report.service */ 40610);
/* harmony import */ var _ngx_translate_core__WEBPACK_IMPORTED_MODULE_12__ = __webpack_require__(/*! @ngx-translate/core */ 48503);
/* harmony import */ var src_app_core_shared_services_campaign_service__WEBPACK_IMPORTED_MODULE_13__ = __webpack_require__(/*! src/app/core/shared/services/campaign.service */ 76658);
/* harmony import */ var src_app_core_auth_auth_service__WEBPACK_IMPORTED_MODULE_14__ = __webpack_require__(/*! src/app/core/auth/auth.service */ 35524);
/* harmony import */ var src_app_core_shared_services_error_service__WEBPACK_IMPORTED_MODULE_15__ = __webpack_require__(/*! src/app/core/shared/services/error.service */ 46078);
/* harmony import */ var _angular_common__WEBPACK_IMPORTED_MODULE_16__ = __webpack_require__(/*! @angular/common */ 93683);
/* harmony import */ var _ionic_angular__WEBPACK_IMPORTED_MODULE_17__ = __webpack_require__(/*! @ionic/angular */ 21507);
/* harmony import */ var _core_shared_globalization_ordinal_number_ordinal_number_component__WEBPACK_IMPORTED_MODULE_18__ = __webpack_require__(/*! ../../../core/shared/globalization/ordinal-number/ordinal-number.component */ 6972);
/* harmony import */ var _core_shared_ui_icon_icon_component__WEBPACK_IMPORTED_MODULE_19__ = __webpack_require__(/*! ../../../core/shared/ui/icon/icon.component */ 59621);
/* harmony import */ var _core_shared_pipes_localDate_pipe__WEBPACK_IMPORTED_MODULE_20__ = __webpack_require__(/*! ../../../core/shared/pipes/localDate.pipe */ 86451);
/* harmony import */ var _core_shared_pipes_languageMap_pipe__WEBPACK_IMPORTED_MODULE_21__ = __webpack_require__(/*! ../../../core/shared/pipes/languageMap.pipe */ 69618);

var _staticBlock;

















const _c0 = (a0, a1) => ({
  periodFrom: a0,
  periodTo: a1
});
const _c1 = a0 => ({
  won: a0
});
function CampaignStatComponent_div_6_ion_row_2_Template(rf, ctx) {
  if (rf & 1) {
    _angular_core__WEBPACK_IMPORTED_MODULE_9__["ɵɵelementStart"](0, "ion-row")(1, "ion-col", 12);
    _angular_core__WEBPACK_IMPORTED_MODULE_9__["ɵɵelement"](2, "app-icon", 13);
    _angular_core__WEBPACK_IMPORTED_MODULE_9__["ɵɵelementEnd"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_9__["ɵɵelementStart"](3, "ion-col")(4, "span", 14);
    _angular_core__WEBPACK_IMPORTED_MODULE_9__["ɵɵtext"](5);
    _angular_core__WEBPACK_IMPORTED_MODULE_9__["ɵɵpipe"](6, "translate");
    _angular_core__WEBPACK_IMPORTED_MODULE_9__["ɵɵelementEnd"]()()();
  }
  if (rf & 2) {
    _angular_core__WEBPACK_IMPORTED_MODULE_9__["ɵɵadvance"](5);
    _angular_core__WEBPACK_IMPORTED_MODULE_9__["ɵɵtextInterpolate1"](" ", _angular_core__WEBPACK_IMPORTED_MODULE_9__["ɵɵpipeBind1"](6, 1, "userprofile.blacklist_user"), " ");
  }
}
function CampaignStatComponent_div_6_ion_grid_34_div_13_Template(rf, ctx) {
  if (rf & 1) {
    _angular_core__WEBPACK_IMPORTED_MODULE_9__["ɵɵelementStart"](0, "div")(1, "div", 19);
    _angular_core__WEBPACK_IMPORTED_MODULE_9__["ɵɵelement"](2, "app-icon", 20);
    _angular_core__WEBPACK_IMPORTED_MODULE_9__["ɵɵelementStart"](3, "b");
    _angular_core__WEBPACK_IMPORTED_MODULE_9__["ɵɵtext"](4);
    _angular_core__WEBPACK_IMPORTED_MODULE_9__["ɵɵelementEnd"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_9__["ɵɵtext"](5);
    _angular_core__WEBPACK_IMPORTED_MODULE_9__["ɵɵelementStart"](6, "b");
    _angular_core__WEBPACK_IMPORTED_MODULE_9__["ɵɵtext"](7);
    _angular_core__WEBPACK_IMPORTED_MODULE_9__["ɵɵpipe"](8, "translate");
    _angular_core__WEBPACK_IMPORTED_MODULE_9__["ɵɵelementEnd"]()()();
  }
  if (rf & 2) {
    const challengeType_r1 = ctx.$implicit;
    const ctx_r1 = _angular_core__WEBPACK_IMPORTED_MODULE_9__["ɵɵnextContext"](3);
    _angular_core__WEBPACK_IMPORTED_MODULE_9__["ɵɵadvance"](2);
    _angular_core__WEBPACK_IMPORTED_MODULE_9__["ɵɵproperty"]("name", ctx_r1.imgChallenge(challengeType_r1.type));
    _angular_core__WEBPACK_IMPORTED_MODULE_9__["ɵɵadvance"](2);
    _angular_core__WEBPACK_IMPORTED_MODULE_9__["ɵɵtextInterpolate1"](" ", challengeType_r1.completed + challengeType_r1.failed, " ");
    _angular_core__WEBPACK_IMPORTED_MODULE_9__["ɵɵadvance"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_9__["ɵɵtextInterpolate1"](" ", ctx_r1.typeChallenge(challengeType_r1.type), ": ");
    _angular_core__WEBPACK_IMPORTED_MODULE_9__["ɵɵadvance"](2);
    _angular_core__WEBPACK_IMPORTED_MODULE_9__["ɵɵtextInterpolate1"](" ", _angular_core__WEBPACK_IMPORTED_MODULE_9__["ɵɵpipeBind2"](8, 4, "userprofile.won", _angular_core__WEBPACK_IMPORTED_MODULE_9__["ɵɵpureFunction1"](7, _c1, challengeType_r1.completed)));
  }
}
function CampaignStatComponent_div_6_ion_grid_34_Template(rf, ctx) {
  if (rf & 1) {
    _angular_core__WEBPACK_IMPORTED_MODULE_9__["ɵɵelementStart"](0, "ion-grid")(1, "ion-row")(2, "ion-col")(3, "span", 15);
    _angular_core__WEBPACK_IMPORTED_MODULE_9__["ɵɵtext"](4);
    _angular_core__WEBPACK_IMPORTED_MODULE_9__["ɵɵpipe"](5, "localDate");
    _angular_core__WEBPACK_IMPORTED_MODULE_9__["ɵɵpipe"](6, "localDate");
    _angular_core__WEBPACK_IMPORTED_MODULE_9__["ɵɵpipe"](7, "translate");
    _angular_core__WEBPACK_IMPORTED_MODULE_9__["ɵɵelementEnd"]()()();
    _angular_core__WEBPACK_IMPORTED_MODULE_9__["ɵɵelementStart"](8, "ion-row")(9, "ion-col", 16);
    _angular_core__WEBPACK_IMPORTED_MODULE_9__["ɵɵelement"](10, "app-icon", 17);
    _angular_core__WEBPACK_IMPORTED_MODULE_9__["ɵɵelementEnd"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_9__["ɵɵelementStart"](11, "ion-col")(12, "div", 7);
    _angular_core__WEBPACK_IMPORTED_MODULE_9__["ɵɵtemplate"](13, CampaignStatComponent_div_6_ion_grid_34_div_13_Template, 9, 9, "div", 18);
    _angular_core__WEBPACK_IMPORTED_MODULE_9__["ɵɵpipe"](14, "async");
    _angular_core__WEBPACK_IMPORTED_MODULE_9__["ɵɵelementEnd"]()()()();
  }
  if (rf & 2) {
    const ctx_r1 = _angular_core__WEBPACK_IMPORTED_MODULE_9__["ɵɵnextContext"](2);
    _angular_core__WEBPACK_IMPORTED_MODULE_9__["ɵɵadvance"](4);
    _angular_core__WEBPACK_IMPORTED_MODULE_9__["ɵɵtextInterpolate"](_angular_core__WEBPACK_IMPORTED_MODULE_9__["ɵɵpipeBind2"](7, 7, "userprofile.period_challenge", _angular_core__WEBPACK_IMPORTED_MODULE_9__["ɵɵpureFunction2"](12, _c0, _angular_core__WEBPACK_IMPORTED_MODULE_9__["ɵɵpipeBind1"](5, 3, ctx_r1.getChallengeFrom()), _angular_core__WEBPACK_IMPORTED_MODULE_9__["ɵɵpipeBind1"](6, 5, ctx_r1.getChallengeTo()))));
    _angular_core__WEBPACK_IMPORTED_MODULE_9__["ɵɵadvance"](6);
    _angular_core__WEBPACK_IMPORTED_MODULE_9__["ɵɵproperty"]("color", ctx_r1.campaign.type);
    _angular_core__WEBPACK_IMPORTED_MODULE_9__["ɵɵadvance"](3);
    _angular_core__WEBPACK_IMPORTED_MODULE_9__["ɵɵproperty"]("ngForOf", _angular_core__WEBPACK_IMPORTED_MODULE_9__["ɵɵpipeBind1"](14, 10, ctx_r1.challengeStat$));
  }
}
function CampaignStatComponent_div_6_ng_container_37_Template(rf, ctx) {
  if (rf & 1) {
    const _r3 = _angular_core__WEBPACK_IMPORTED_MODULE_9__["ɵɵgetCurrentView"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_9__["ɵɵelementContainerStart"](0);
    _angular_core__WEBPACK_IMPORTED_MODULE_9__["ɵɵelementStart"](1, "ion-button", 21);
    _angular_core__WEBPACK_IMPORTED_MODULE_9__["ɵɵlistener"]("click", function CampaignStatComponent_div_6_ng_container_37_Template_ion_button_click_1_listener() {
      _angular_core__WEBPACK_IMPORTED_MODULE_8__["ɵɵrestoreView"](_r3);
      const ctx_r1 = _angular_core__WEBPACK_IMPORTED_MODULE_9__["ɵɵnextContext"](2);
      return _angular_core__WEBPACK_IMPORTED_MODULE_8__["ɵɵresetView"](ctx_r1.removeBlacklist());
    });
    _angular_core__WEBPACK_IMPORTED_MODULE_9__["ɵɵelement"](2, "app-icon", 22);
    _angular_core__WEBPACK_IMPORTED_MODULE_9__["ɵɵtext"](3);
    _angular_core__WEBPACK_IMPORTED_MODULE_9__["ɵɵpipe"](4, "translate");
    _angular_core__WEBPACK_IMPORTED_MODULE_9__["ɵɵelementEnd"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_9__["ɵɵelementContainerEnd"]();
  }
  if (rf & 2) {
    _angular_core__WEBPACK_IMPORTED_MODULE_9__["ɵɵadvance"](3);
    _angular_core__WEBPACK_IMPORTED_MODULE_9__["ɵɵtextInterpolate1"]("", _angular_core__WEBPACK_IMPORTED_MODULE_9__["ɵɵpipeBind1"](4, 1, "userprofile.remove_blacklist"), " ");
  }
}
function CampaignStatComponent_div_6_ng_template_39_Template(rf, ctx) {
  if (rf & 1) {
    const _r4 = _angular_core__WEBPACK_IMPORTED_MODULE_9__["ɵɵgetCurrentView"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_9__["ɵɵelementStart"](0, "ion-button", 23);
    _angular_core__WEBPACK_IMPORTED_MODULE_9__["ɵɵlistener"]("click", function CampaignStatComponent_div_6_ng_template_39_Template_ion_button_click_0_listener() {
      _angular_core__WEBPACK_IMPORTED_MODULE_8__["ɵɵrestoreView"](_r4);
      const ctx_r1 = _angular_core__WEBPACK_IMPORTED_MODULE_9__["ɵɵnextContext"](2);
      return _angular_core__WEBPACK_IMPORTED_MODULE_8__["ɵɵresetView"](ctx_r1.addBlacklist());
    });
    _angular_core__WEBPACK_IMPORTED_MODULE_9__["ɵɵelement"](1, "app-icon", 24);
    _angular_core__WEBPACK_IMPORTED_MODULE_9__["ɵɵtext"](2);
    _angular_core__WEBPACK_IMPORTED_MODULE_9__["ɵɵpipe"](3, "translate");
    _angular_core__WEBPACK_IMPORTED_MODULE_9__["ɵɵelementEnd"]();
  }
  if (rf & 2) {
    _angular_core__WEBPACK_IMPORTED_MODULE_9__["ɵɵadvance"](2);
    _angular_core__WEBPACK_IMPORTED_MODULE_9__["ɵɵtextInterpolate1"]("", _angular_core__WEBPACK_IMPORTED_MODULE_9__["ɵɵpipeBind1"](3, 1, "userprofile.add_blacklist"), " ");
  }
}
function CampaignStatComponent_div_6_Template(rf, ctx) {
  if (rf & 1) {
    _angular_core__WEBPACK_IMPORTED_MODULE_9__["ɵɵelementStart"](0, "div")(1, "ion-grid");
    _angular_core__WEBPACK_IMPORTED_MODULE_9__["ɵɵtemplate"](2, CampaignStatComponent_div_6_ion_row_2_Template, 7, 3, "ion-row", 4);
    _angular_core__WEBPACK_IMPORTED_MODULE_9__["ɵɵpipe"](3, "async");
    _angular_core__WEBPACK_IMPORTED_MODULE_9__["ɵɵelementStart"](4, "ion-row")(5, "ion-col", 5);
    _angular_core__WEBPACK_IMPORTED_MODULE_9__["ɵɵelement"](6, "app-icon", 6);
    _angular_core__WEBPACK_IMPORTED_MODULE_9__["ɵɵelementEnd"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_9__["ɵɵelementStart"](7, "ion-col")(8, "div", 7)(9, "div");
    _angular_core__WEBPACK_IMPORTED_MODULE_9__["ɵɵelement"](10, "app-ordinal-number", 8);
    _angular_core__WEBPACK_IMPORTED_MODULE_9__["ɵɵpipe"](11, "async");
    _angular_core__WEBPACK_IMPORTED_MODULE_9__["ɵɵtext"](12);
    _angular_core__WEBPACK_IMPORTED_MODULE_9__["ɵɵpipe"](13, "translate");
    _angular_core__WEBPACK_IMPORTED_MODULE_9__["ɵɵelementEnd"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_9__["ɵɵelementStart"](14, "div");
    _angular_core__WEBPACK_IMPORTED_MODULE_9__["ɵɵelement"](15, "app-ordinal-number", 8);
    _angular_core__WEBPACK_IMPORTED_MODULE_9__["ɵɵpipe"](16, "async");
    _angular_core__WEBPACK_IMPORTED_MODULE_9__["ɵɵtext"](17);
    _angular_core__WEBPACK_IMPORTED_MODULE_9__["ɵɵpipe"](18, "translate");
    _angular_core__WEBPACK_IMPORTED_MODULE_9__["ɵɵelementEnd"]()()()()();
    _angular_core__WEBPACK_IMPORTED_MODULE_9__["ɵɵelementStart"](19, "div")(20, "ion-grid")(21, "ion-row")(22, "ion-col", 5);
    _angular_core__WEBPACK_IMPORTED_MODULE_9__["ɵɵelement"](23, "app-icon", 9);
    _angular_core__WEBPACK_IMPORTED_MODULE_9__["ɵɵelementEnd"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_9__["ɵɵelementStart"](24, "ion-col")(25, "div", 7)(26, "div")(27, "span", 10);
    _angular_core__WEBPACK_IMPORTED_MODULE_9__["ɵɵtext"](28);
    _angular_core__WEBPACK_IMPORTED_MODULE_9__["ɵɵpipe"](29, "async");
    _angular_core__WEBPACK_IMPORTED_MODULE_9__["ɵɵelementEnd"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_9__["ɵɵelementStart"](30, "span");
    _angular_core__WEBPACK_IMPORTED_MODULE_9__["ɵɵtext"](31);
    _angular_core__WEBPACK_IMPORTED_MODULE_9__["ɵɵpipe"](32, "translate");
    _angular_core__WEBPACK_IMPORTED_MODULE_9__["ɵɵelementEnd"]()()()()()()();
    _angular_core__WEBPACK_IMPORTED_MODULE_9__["ɵɵelementStart"](33, "div");
    _angular_core__WEBPACK_IMPORTED_MODULE_9__["ɵɵtemplate"](34, CampaignStatComponent_div_6_ion_grid_34_Template, 15, 15, "ion-grid", 4);
    _angular_core__WEBPACK_IMPORTED_MODULE_9__["ɵɵpipe"](35, "async");
    _angular_core__WEBPACK_IMPORTED_MODULE_9__["ɵɵelementEnd"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_9__["ɵɵelementStart"](36, "div", 11);
    _angular_core__WEBPACK_IMPORTED_MODULE_9__["ɵɵtemplate"](37, CampaignStatComponent_div_6_ng_container_37_Template, 5, 3, "ng-container", 3);
    _angular_core__WEBPACK_IMPORTED_MODULE_9__["ɵɵpipe"](38, "async");
    _angular_core__WEBPACK_IMPORTED_MODULE_9__["ɵɵtemplate"](39, CampaignStatComponent_div_6_ng_template_39_Template, 4, 3, "ng-template", null, 1, _angular_core__WEBPACK_IMPORTED_MODULE_9__["ɵɵtemplateRefExtractor"]);
    _angular_core__WEBPACK_IMPORTED_MODULE_9__["ɵɵelementEnd"]()();
  }
  if (rf & 2) {
    let tmp_6_0;
    let tmp_8_0;
    let tmp_12_0;
    let tmp_14_0;
    const addblacklist_r5 = _angular_core__WEBPACK_IMPORTED_MODULE_9__["ɵɵreference"](40);
    const ctx_r1 = _angular_core__WEBPACK_IMPORTED_MODULE_9__["ɵɵnextContext"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_9__["ɵɵadvance"](2);
    _angular_core__WEBPACK_IMPORTED_MODULE_9__["ɵɵproperty"]("ngIf", _angular_core__WEBPACK_IMPORTED_MODULE_9__["ɵɵpipeBind1"](3, 16, ctx_r1.blacklisted$) === true);
    _angular_core__WEBPACK_IMPORTED_MODULE_9__["ɵɵadvance"](2);
    _angular_core__WEBPACK_IMPORTED_MODULE_9__["ɵɵstyleProp"]("border-bottom", "3px solid var(--ion-color-" + ctx_r1.campaign.type + ")");
    _angular_core__WEBPACK_IMPORTED_MODULE_9__["ɵɵadvance"](2);
    _angular_core__WEBPACK_IMPORTED_MODULE_9__["ɵɵproperty"]("color", ctx_r1.campaign.type);
    _angular_core__WEBPACK_IMPORTED_MODULE_9__["ɵɵadvance"](4);
    _angular_core__WEBPACK_IMPORTED_MODULE_9__["ɵɵproperty"]("value", (tmp_6_0 = _angular_core__WEBPACK_IMPORTED_MODULE_9__["ɵɵpipeBind1"](11, 18, ctx_r1.reportWeek$)) == null ? null : tmp_6_0.position);
    _angular_core__WEBPACK_IMPORTED_MODULE_9__["ɵɵadvance"](2);
    _angular_core__WEBPACK_IMPORTED_MODULE_9__["ɵɵtextInterpolate1"](" ", _angular_core__WEBPACK_IMPORTED_MODULE_9__["ɵɵpipeBind1"](13, 20, "userprofile.last_week_position"), " ");
    _angular_core__WEBPACK_IMPORTED_MODULE_9__["ɵɵadvance"](3);
    _angular_core__WEBPACK_IMPORTED_MODULE_9__["ɵɵproperty"]("value", (tmp_8_0 = _angular_core__WEBPACK_IMPORTED_MODULE_9__["ɵɵpipeBind1"](16, 22, ctx_r1.reportTotal$)) == null ? null : tmp_8_0.position);
    _angular_core__WEBPACK_IMPORTED_MODULE_9__["ɵɵadvance"](2);
    _angular_core__WEBPACK_IMPORTED_MODULE_9__["ɵɵtextInterpolate1"](" ", _angular_core__WEBPACK_IMPORTED_MODULE_9__["ɵɵpipeBind1"](18, 24, "userprofile.general_position"), " ");
    _angular_core__WEBPACK_IMPORTED_MODULE_9__["ɵɵadvance"](4);
    _angular_core__WEBPACK_IMPORTED_MODULE_9__["ɵɵstyleProp"]("border-bottom", "3px solid var(--ion-color-" + ctx_r1.campaign.type + ")");
    _angular_core__WEBPACK_IMPORTED_MODULE_9__["ɵɵadvance"](2);
    _angular_core__WEBPACK_IMPORTED_MODULE_9__["ɵɵproperty"]("name", ctx_r1.campaignService.getCampaignTypeIcon(ctx_r1.campaign));
    _angular_core__WEBPACK_IMPORTED_MODULE_9__["ɵɵadvance"](5);
    _angular_core__WEBPACK_IMPORTED_MODULE_9__["ɵɵtextInterpolate"]((tmp_12_0 = _angular_core__WEBPACK_IMPORTED_MODULE_9__["ɵɵpipeBind1"](29, 26, ctx_r1.reportTotal$)) == null ? null : tmp_12_0.value);
    _angular_core__WEBPACK_IMPORTED_MODULE_9__["ɵɵadvance"](3);
    _angular_core__WEBPACK_IMPORTED_MODULE_9__["ɵɵtextInterpolate"](_angular_core__WEBPACK_IMPORTED_MODULE_9__["ɵɵpipeBind1"](32, 28, "userprofile.total_points"));
    _angular_core__WEBPACK_IMPORTED_MODULE_9__["ɵɵadvance"](3);
    _angular_core__WEBPACK_IMPORTED_MODULE_9__["ɵɵproperty"]("ngIf", ((tmp_14_0 = _angular_core__WEBPACK_IMPORTED_MODULE_9__["ɵɵpipeBind1"](35, 30, ctx_r1.challengeStat$)) == null ? null : tmp_14_0.length) > 0);
    _angular_core__WEBPACK_IMPORTED_MODULE_9__["ɵɵadvance"](3);
    _angular_core__WEBPACK_IMPORTED_MODULE_9__["ɵɵproperty"]("ngIf", _angular_core__WEBPACK_IMPORTED_MODULE_9__["ɵɵpipeBind1"](38, 32, ctx_r1.blacklisted$))("ngIfElse", addblacklist_r5);
  }
}
function CampaignStatComponent_ng_template_7_Template(rf, ctx) {
  if (rf & 1) {
    _angular_core__WEBPACK_IMPORTED_MODULE_9__["ɵɵelementStart"](0, "ion-grid")(1, "ion-row")(2, "ion-col")(3, "div", 11);
    _angular_core__WEBPACK_IMPORTED_MODULE_9__["ɵɵtext"](4);
    _angular_core__WEBPACK_IMPORTED_MODULE_9__["ɵɵpipe"](5, "translate");
    _angular_core__WEBPACK_IMPORTED_MODULE_9__["ɵɵelementEnd"]()()()();
  }
  if (rf & 2) {
    _angular_core__WEBPACK_IMPORTED_MODULE_9__["ɵɵadvance"](4);
    _angular_core__WEBPACK_IMPORTED_MODULE_9__["ɵɵtextInterpolate"](_angular_core__WEBPACK_IMPORTED_MODULE_9__["ɵɵpipeBind1"](5, 1, "userprofile.user_joined"));
  }
}
class CampaignStatComponent {
  // public points$
  constructor(challengeService, reportService, translateService, campaignService, authService, errorService) {
    this.challengeService = challengeService;
    this.reportService = reportService;
    this.translateService = translateService;
    this.campaignService = campaignService;
    this.authService = authService;
    this.errorService = errorService;
    this.imgChallenge = src_app_core_shared_campaigns_campaign_utils__WEBPACK_IMPORTED_MODULE_6__.getImgChallenge;
    this.blacklistRefresher$ = new rxjs__WEBPACK_IMPORTED_MODULE_2__.ReplaySubject(1);
    this.blacklistCouldBeChanged$ = (0,rxjs__WEBPACK_IMPORTED_MODULE_3__.merge)(this.authService.isReadyForApi$.pipe((0,rxjs__WEBPACK_IMPORTED_MODULE_4__.map)(() => ({
      isFirst: true
    }))), this.blacklistRefresher$.pipe((0,rxjs__WEBPACK_IMPORTED_MODULE_4__.map)(() => ({
      isFirst: false
    }))));
  }
  getChallengeFrom() {
    return (0,src_app_core_shared_time_utils__WEBPACK_IMPORTED_MODULE_7__.toServerDateOnly)(luxon__WEBPACK_IMPORTED_MODULE_1__.DateTime.utc().minus({
      month: 1
    }));
  }
  getChallengeTo() {
    return (0,src_app_core_shared_time_utils__WEBPACK_IMPORTED_MODULE_7__.toServerDateOnly)(luxon__WEBPACK_IMPORTED_MODULE_1__.DateTime.utc());
  }
  ngOnInit() {
    const campaignId = this.campaign?.campaignId;
    if (!campaignId) {
      console.warn('Campaign ID non definito, impossibile caricare le statistiche.');
      return;
    }
    this.challengeStat$ = this.challengeService.getChallengeStats({
      campaignId,
      playerId: this.playerId,
      groupMode: 'month',
      dateFrom: (0,src_app_core_shared_time_utils__WEBPACK_IMPORTED_MODULE_7__.toServerDateOnly)(luxon__WEBPACK_IMPORTED_MODULE_1__.DateTime.utc().minus({
        month: 1
      })),
      dateTo: (0,src_app_core_shared_time_utils__WEBPACK_IMPORTED_MODULE_7__.toServerDateOnly)(luxon__WEBPACK_IMPORTED_MODULE_1__.DateTime.utc())
    }).pipe((0,rxjs__WEBPACK_IMPORTED_MODULE_4__.map)(challs => challs?.filter(chall => chall?.type !== 'survey') ?? []), (0,rxjs__WEBPACK_IMPORTED_MODULE_4__.map)(challs => challs.map(chall => {
      if (chall.type !== 'groupCooperative' && chall.type !== 'groupCompetitiveTime' && chall.type !== 'groupCompetitivePerformance') {
        chall.type = 'single';
      }
      return chall;
    })), (0,rxjs__WEBPACK_IMPORTED_MODULE_4__.map)(challs => challs.reduce((acc, item) => {
      const existItem = acc.find(({
        type
      }) => item.type === type);
      if (existItem) {
        existItem.completed = (existItem.completed ?? 0) + (item.completed ?? 0);
        existItem.failed = (existItem.failed ?? 0) + (item.failed ?? 0);
      } else {
        acc.push({
          ...item
        });
      }
      return acc;
    }, [])));
    this.reportWeek$ = this.reportService.getGameStats(this.campaign?.campaignId, this.playerId, (0,src_app_core_shared_time_utils__WEBPACK_IMPORTED_MODULE_7__.toServerDateOnly)(luxon__WEBPACK_IMPORTED_MODULE_1__.DateTime.utc().startOf('week')), (0,src_app_core_shared_time_utils__WEBPACK_IMPORTED_MODULE_7__.toServerDateOnly)(luxon__WEBPACK_IMPORTED_MODULE_1__.DateTime.utc()));
    this.reportTotal$ = this.reportService.getGameStats(this.campaign?.campaignId, this.playerId);
    this.blacklisted$ = this.blacklistCouldBeChanged$.pipe((0,rxjs__WEBPACK_IMPORTED_MODULE_5__.switchMap)(() => this.challengeService.getBlacklistByCampaign(this.campaign?.campaignId).pipe((0,rxjs__WEBPACK_IMPORTED_MODULE_4__.map)(blacklist => blacklist.map(user => user.id).includes(this.playerId)))));
  }
  typeChallenge(type) {
    return this.translateService.instant((0,src_app_core_shared_campaigns_campaign_utils__WEBPACK_IMPORTED_MODULE_6__.getTypeStringChallenge)(type));
  }
  removeBlacklist() {
    var _this = this;
    return (0,_Users_smartcommunitylab_Desktop_newWork_playAndGo_playGo_node_modules_babel_runtime_helpers_esm_asyncToGenerator_js__WEBPACK_IMPORTED_MODULE_0__["default"])(function* () {
      try {
        const removed = yield _this.challengeService.removeBlacklist(_this.campaign.campaignId, _this.playerId);
        _this.blacklistRefresher$.next();
      } catch (e) {
        _this.errorService.handleError(e, 'normal');
      }
    })();
  }
  addBlacklist() {
    var _this2 = this;
    return (0,_Users_smartcommunitylab_Desktop_newWork_playAndGo_playGo_node_modules_babel_runtime_helpers_esm_asyncToGenerator_js__WEBPACK_IMPORTED_MODULE_0__["default"])(function* () {
      try {
        const removed = yield _this2.challengeService.addBlacklist(_this2.campaign?.campaignId, _this2.playerId);
        _this2.blacklistRefresher$.next();
      } catch (e) {
        _this2.errorService.handleError(e, 'normal');
      }
    })();
  }
  static #_ = _staticBlock = () => (this.ɵfac = function CampaignStatComponent_Factory(__ngFactoryType__) {
    return new (__ngFactoryType__ || CampaignStatComponent)(_angular_core__WEBPACK_IMPORTED_MODULE_9__["ɵɵdirectiveInject"](src_app_core_shared_services_challenge_service__WEBPACK_IMPORTED_MODULE_10__.ChallengeService), _angular_core__WEBPACK_IMPORTED_MODULE_9__["ɵɵdirectiveInject"](src_app_core_shared_services_report_service__WEBPACK_IMPORTED_MODULE_11__.ReportService), _angular_core__WEBPACK_IMPORTED_MODULE_9__["ɵɵdirectiveInject"](_ngx_translate_core__WEBPACK_IMPORTED_MODULE_12__.TranslateService), _angular_core__WEBPACK_IMPORTED_MODULE_9__["ɵɵdirectiveInject"](src_app_core_shared_services_campaign_service__WEBPACK_IMPORTED_MODULE_13__.CampaignService), _angular_core__WEBPACK_IMPORTED_MODULE_9__["ɵɵdirectiveInject"](src_app_core_auth_auth_service__WEBPACK_IMPORTED_MODULE_14__.AuthService), _angular_core__WEBPACK_IMPORTED_MODULE_9__["ɵɵdirectiveInject"](src_app_core_shared_services_error_service__WEBPACK_IMPORTED_MODULE_15__.ErrorService));
  }, this.ɵcmp = /*@__PURE__*/_angular_core__WEBPACK_IMPORTED_MODULE_9__["ɵɵdefineComponent"]({
    type: CampaignStatComponent,
    selectors: [["app-campaign-stat"]],
    inputs: {
      playerId: "playerId",
      campaign: "campaign"
    },
    standalone: false,
    decls: 9,
    vars: 6,
    consts: [["school", ""], ["addblacklist", ""], [3, "color"], [4, "ngIf", "ngIfElse"], [4, "ngIf"], ["size", "2"], ["name", "leaderboard", 1, "icon-size-medium", 3, "color"], [1, "result"], [3, "value"], [1, "icon-size-medium", 3, "name"], [1, "bolded"], [1, "ion-text-center"], ["size", "auto", 1, "chall-line"], ["name", "blockUserColor", 1, "icon-size-normal"], [1, "blockuser-info"], [1, "challe-text"], ["size", "2", 1, "chall-line"], ["name", "cup", 1, "icon-size-medium", 3, "color"], [4, "ngFor", "ngForOf"], [1, "chall-line"], [1, "challenge-icon", "icon-size-normal", 3, "name"], [1, "remove-button", 3, "click"], ["name", "invitation", 1, "icon-size-normal"], [1, "add-button", 3, "click"], ["name", "blacklist", 1, "icon-size-normal"]],
    template: function CampaignStatComponent_Template(rf, ctx) {
      if (rf & 1) {
        _angular_core__WEBPACK_IMPORTED_MODULE_9__["ɵɵelement"](0, "p");
        _angular_core__WEBPACK_IMPORTED_MODULE_9__["ɵɵelementStart"](1, "ion-card")(2, "ion-card-header", 2);
        _angular_core__WEBPACK_IMPORTED_MODULE_9__["ɵɵtext"](3);
        _angular_core__WEBPACK_IMPORTED_MODULE_9__["ɵɵpipe"](4, "languageMap");
        _angular_core__WEBPACK_IMPORTED_MODULE_9__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_9__["ɵɵelementStart"](5, "ion-card-content");
        _angular_core__WEBPACK_IMPORTED_MODULE_9__["ɵɵtemplate"](6, CampaignStatComponent_div_6_Template, 41, 34, "div", 3)(7, CampaignStatComponent_ng_template_7_Template, 6, 3, "ng-template", null, 0, _angular_core__WEBPACK_IMPORTED_MODULE_9__["ɵɵtemplateRefExtractor"]);
        _angular_core__WEBPACK_IMPORTED_MODULE_9__["ɵɵelementEnd"]()();
      }
      if (rf & 2) {
        const school_r6 = _angular_core__WEBPACK_IMPORTED_MODULE_9__["ɵɵreference"](8);
        _angular_core__WEBPACK_IMPORTED_MODULE_9__["ɵɵadvance"](2);
        _angular_core__WEBPACK_IMPORTED_MODULE_9__["ɵɵproperty"]("color", ctx.campaign.type);
        _angular_core__WEBPACK_IMPORTED_MODULE_9__["ɵɵadvance"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_9__["ɵɵtextInterpolate1"](" ", _angular_core__WEBPACK_IMPORTED_MODULE_9__["ɵɵpipeBind1"](4, 4, ctx.campaign.name), " ");
        _angular_core__WEBPACK_IMPORTED_MODULE_9__["ɵɵadvance"](3);
        _angular_core__WEBPACK_IMPORTED_MODULE_9__["ɵɵproperty"]("ngIf", ctx.campaign.type !== "school")("ngIfElse", school_r6);
      }
    },
    dependencies: [_angular_common__WEBPACK_IMPORTED_MODULE_16__.NgForOf, _angular_common__WEBPACK_IMPORTED_MODULE_16__.NgIf, _ionic_angular__WEBPACK_IMPORTED_MODULE_17__.IonButton, _ionic_angular__WEBPACK_IMPORTED_MODULE_17__.IonCard, _ionic_angular__WEBPACK_IMPORTED_MODULE_17__.IonCardContent, _ionic_angular__WEBPACK_IMPORTED_MODULE_17__.IonCardHeader, _ionic_angular__WEBPACK_IMPORTED_MODULE_17__.IonCol, _ionic_angular__WEBPACK_IMPORTED_MODULE_17__.IonGrid, _ionic_angular__WEBPACK_IMPORTED_MODULE_17__.IonRow, _core_shared_globalization_ordinal_number_ordinal_number_component__WEBPACK_IMPORTED_MODULE_18__.OrdinalNumberComponent, _core_shared_ui_icon_icon_component__WEBPACK_IMPORTED_MODULE_19__.IconComponent, _angular_common__WEBPACK_IMPORTED_MODULE_16__.AsyncPipe, _ngx_translate_core__WEBPACK_IMPORTED_MODULE_12__.TranslatePipe, _core_shared_pipes_localDate_pipe__WEBPACK_IMPORTED_MODULE_20__.LocalDatePipe, _core_shared_pipes_languageMap_pipe__WEBPACK_IMPORTED_MODULE_21__.LanguageMapPipe],
    styles: ["ion-card[_ngcontent-%COMP%] {\n  color: var(--dark-grey);\n}\nion-card[_ngcontent-%COMP%]   ion-card-header[_ngcontent-%COMP%] {\n  height: 21px;\n  display: flex;\n  justify-content: space-around;\n  flex-direction: column;\n  font-weight: 300;\n  font-size: 13px;\n  font-style: italic;\n}\nion-card[_ngcontent-%COMP%]   .challe-text[_ngcontent-%COMP%] {\n  font-size: 13px;\n  font-style: italic;\n}\nion-card[_ngcontent-%COMP%]   .blockuser-info[_ngcontent-%COMP%] {\n  font-size: 11px;\n  font-style: italic;\n}\nion-card[_ngcontent-%COMP%]   .chall-line[_ngcontent-%COMP%] {\n  display: flex;\n  align-items: center !important;\n}\nion-card[_ngcontent-%COMP%]   .result[_ngcontent-%COMP%] {\n  display: flex;\n  flex-flow: column;\n  height: 100%;\n  justify-content: center;\n  margin-left: 10px;\n  font-style: italic;\n  font-weight: 300;\n  font-size: 13px;\n}\nion-card[_ngcontent-%COMP%]   .result[_ngcontent-%COMP%]   .bolded[_ngcontent-%COMP%] {\n  font-weight: 600;\n}\nion-card[_ngcontent-%COMP%]   app-ordinal-number[_ngcontent-%COMP%] {\n  font-weight: 600;\n}\nion-card[_ngcontent-%COMP%]   .add-button[_ngcontent-%COMP%] {\n  --background: rgba(198, 16, 16, 1);\n}\nion-card[_ngcontent-%COMP%]   .remove-button[_ngcontent-%COMP%] {\n  --background: rgba(53, 150, 117, 1);\n}\nion-card[_ngcontent-%COMP%]   ion-button[_ngcontent-%COMP%]   app-icon[_ngcontent-%COMP%] {\n  padding: 0px 8px 0px 0px;\n}\n/*# sourceMappingURL=data:application/json;charset=utf-8;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbIndlYnBhY2s6Ly8uL3NyYy9hcHAvcGFnZXMvdXNlci1wcm9maWxlL2NhbXBhaWduLXN0YXQvY2FtcGFpZ24tc3RhdC5jb21wb25lbnQuc2NzcyJdLCJuYW1lcyI6W10sIm1hcHBpbmdzIjoiQUFBQTtFQUNFLHVCQUFBO0FBQ0Y7QUFDRTtFQUNFLFlBQUE7RUFDQSxhQUFBO0VBQ0EsNkJBQUE7RUFDQSxzQkFBQTtFQUNBLGdCQUFBO0VBQ0EsZUFBQTtFQUNBLGtCQUFBO0FBQ0o7QUFDRTtFQUNFLGVBQUE7RUFDQSxrQkFBQTtBQUNKO0FBQ0U7RUFDRSxlQUFBO0VBQ0Esa0JBQUE7QUFDSjtBQUNFO0VBQ0UsYUFBQTtFQUNBLDhCQUFBO0FBQ0o7QUFDRTtFQUNFLGFBQUE7RUFDQSxpQkFBQTtFQUNBLFlBQUE7RUFDQSx1QkFBQTtFQUNBLGlCQUFBO0VBQ0Esa0JBQUE7RUFDQSxnQkFBQTtFQUNBLGVBQUE7QUFDSjtBQUNJO0VBQ0UsZ0JBQUE7QUFDTjtBQU1FO0VBQ0UsZ0JBQUE7QUFKSjtBQU1FO0VBQ0Usa0NBQUE7QUFKSjtBQU1FO0VBQ0UsbUNBQUE7QUFKSjtBQU9JO0VBQ0Usd0JBQUE7QUFMTiIsInNvdXJjZXNDb250ZW50IjpbImlvbi1jYXJkIHtcbiAgY29sb3I6IHZhcigtLWRhcmstZ3JleSk7XG5cbiAgaW9uLWNhcmQtaGVhZGVyIHtcbiAgICBoZWlnaHQ6IDIxcHg7XG4gICAgZGlzcGxheTogZmxleDtcbiAgICBqdXN0aWZ5LWNvbnRlbnQ6IHNwYWNlLWFyb3VuZDtcbiAgICBmbGV4LWRpcmVjdGlvbjogY29sdW1uO1xuICAgIGZvbnQtd2VpZ2h0OiAzMDA7XG4gICAgZm9udC1zaXplOiAxM3B4O1xuICAgIGZvbnQtc3R5bGU6IGl0YWxpYztcbiAgfVxuICAuY2hhbGxlLXRleHQge1xuICAgIGZvbnQtc2l6ZTogMTNweDtcbiAgICBmb250LXN0eWxlOiBpdGFsaWM7XG4gIH1cbiAgLmJsb2NrdXNlci1pbmZvIHtcbiAgICBmb250LXNpemU6IDExcHg7XG4gICAgZm9udC1zdHlsZTogaXRhbGljO1xuICB9XG4gIC5jaGFsbC1saW5lIHtcbiAgICBkaXNwbGF5OiBmbGV4O1xuICAgIGFsaWduLWl0ZW1zOiBjZW50ZXIgIWltcG9ydGFudDtcbiAgfVxuICAucmVzdWx0IHtcbiAgICBkaXNwbGF5OiBmbGV4O1xuICAgIGZsZXgtZmxvdzogY29sdW1uO1xuICAgIGhlaWdodDogMTAwJTtcbiAgICBqdXN0aWZ5LWNvbnRlbnQ6IGNlbnRlcjtcbiAgICBtYXJnaW4tbGVmdDogMTBweDtcbiAgICBmb250LXN0eWxlOiBpdGFsaWM7XG4gICAgZm9udC13ZWlnaHQ6IDMwMDtcbiAgICBmb250LXNpemU6IDEzcHg7XG5cbiAgICAuYm9sZGVkIHtcbiAgICAgIGZvbnQtd2VpZ2h0OiA2MDA7XG4gICAgfVxuICB9XG5cbiAgLy8gLmJvcmRlciB7XG4gIC8vICAgYm9yZGVyLWJvdHRvbTogMnB4IHNvbGlkIGJsYWNrO1xuICAvLyB9XG4gIGFwcC1vcmRpbmFsLW51bWJlciB7XG4gICAgZm9udC13ZWlnaHQ6IDYwMDtcbiAgfVxuICAuYWRkLWJ1dHRvbiB7XG4gICAgLS1iYWNrZ3JvdW5kOiByZ2JhKDE5OCwgMTYsIDE2LCAxKTtcbiAgfVxuICAucmVtb3ZlLWJ1dHRvbiB7XG4gICAgLS1iYWNrZ3JvdW5kOiByZ2JhKDUzLCAxNTAsIDExNywgMSk7XG4gIH1cbiAgaW9uLWJ1dHRvbiB7XG4gICAgYXBwLWljb24ge1xuICAgICAgcGFkZGluZzogMHB4IDhweCAwcHggMHB4O1xuICAgIH1cbiAgfVxufVxuIl0sInNvdXJjZVJvb3QiOiIifQ== */"]
  }));
}
_staticBlock();

/***/ }),

/***/ 47673:
/*!*******************************************************************************!*\
  !*** ./src/app/pages/user-profile/transport-stat/transport-stat.component.ts ***!
  \*******************************************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   TransportStatComponent: () => (/* binding */ TransportStatComponent)
/* harmony export */ });
/* harmony import */ var rxjs__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! rxjs */ 86301);
/* harmony import */ var rxjs__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! rxjs */ 36647);
/* harmony import */ var src_app_core_shared_time_utils__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! src/app/core/shared/time.utils */ 27780);
/* harmony import */ var luxon__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! luxon */ 45967);
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! @angular/core */ 12481);
/* harmony import */ var src_app_core_shared_services_campaign_service__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! src/app/core/shared/services/campaign.service */ 76658);
/* harmony import */ var src_app_core_api_generated_controllers_reportController_service__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! src/app/core/api/generated/controllers/reportController.service */ 32076);
/* harmony import */ var _angular_common__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(/*! @angular/common */ 93683);
/* harmony import */ var _ionic_angular__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(/*! @ionic/angular */ 21507);
/* harmony import */ var _core_shared_ui_icon_icon_component__WEBPACK_IMPORTED_MODULE_9__ = __webpack_require__(/*! ../../../core/shared/ui/icon/icon.component */ 59621);
/* harmony import */ var _ngx_translate_core__WEBPACK_IMPORTED_MODULE_10__ = __webpack_require__(/*! @ngx-translate/core */ 48503);
/* harmony import */ var _core_shared_pipes_localNumber_pipe__WEBPACK_IMPORTED_MODULE_11__ = __webpack_require__(/*! ../../../core/shared/pipes/localNumber.pipe */ 16024);
var _staticBlock;











function TransportStatComponent_ng_container_7_ion_col_1_Template(rf, ctx) {
  if (rf & 1) {
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵelementStart"](0, "ion-col", 4);
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵelement"](1, "app-icon", 5);
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵelementStart"](2, "span");
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵtext"](3);
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵpipe"](4, "localNumber");
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵpipe"](5, "translate");
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵpipe"](6, "translate");
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵelementEnd"]()();
  }
  if (rf & 2) {
    const stat_r1 = ctx.$implicit;
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵadvance"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵproperty"]("name", "directions_" + stat_r1.mean);
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵadvance"](2);
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵtextInterpolate3"](" ", _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵpipeBind2"](4, 4, stat_r1.value / 1000, "0.0-1"), " ", _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵpipeBind1"](5, 7, "km"), " ", _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵpipeBind1"](6, 9, "userprofile.personal_stat_" + stat_r1.mean), " ");
  }
}
function TransportStatComponent_ng_container_7_Template(rf, ctx) {
  if (rf & 1) {
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵelementContainerStart"](0);
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵtemplate"](1, TransportStatComponent_ng_container_7_ion_col_1_Template, 7, 11, "ion-col", 3);
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵpipe"](2, "async");
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵelementContainerEnd"]();
  }
  if (rf & 2) {
    const ctx_r1 = _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵnextContext"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵadvance"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵproperty"]("ngForOf", _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵpipeBind1"](2, 1, ctx_r1.personalStat$));
  }
}
function TransportStatComponent_ng_template_9_Template(rf, ctx) {
  if (rf & 1) {
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵelementStart"](0, "ion-col")(1, "div", 6);
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵtext"](2);
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵpipe"](3, "translate");
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵelementEnd"]()();
  }
  if (rf & 2) {
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵadvance"](2);
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵtextInterpolate"](_angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵpipeBind1"](3, 1, "userprofile.empty"));
  }
}
class TransportStatComponent {
  constructor(campaignService, reportController) {
    this.campaignService = campaignService;
    this.reportController = reportController;
    this.personalCampaign$ = this.campaignService.getPersonalCampaign();
    this.personalStat$ = this.personalCampaign$.pipe((0,rxjs__WEBPACK_IMPORTED_MODULE_1__.switchMap)(personalCampaign => this.reportController.getPlayerTransportStatsGroupByMeanUsingGET({
      campaignId: personalCampaign?.campaign?.campaignId,
      playerId: this.playerId,
      metric: 'km',
      dateFrom: (0,src_app_core_shared_time_utils__WEBPACK_IMPORTED_MODULE_2__.toServerDateOnly)(luxon__WEBPACK_IMPORTED_MODULE_3__.DateTime.utc().minus({
        month: 1
      })),
      dateTo: (0,src_app_core_shared_time_utils__WEBPACK_IMPORTED_MODULE_2__.toServerDateOnly)(luxon__WEBPACK_IMPORTED_MODULE_3__.DateTime.utc())
    })), (0,rxjs__WEBPACK_IMPORTED_MODULE_0__.shareReplay)(1));
  }
  ngOnInit() {}
  static #_ = _staticBlock = () => (this.ɵfac = function TransportStatComponent_Factory(__ngFactoryType__) {
    return new (__ngFactoryType__ || TransportStatComponent)(_angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵdirectiveInject"](src_app_core_shared_services_campaign_service__WEBPACK_IMPORTED_MODULE_5__.CampaignService), _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵdirectiveInject"](src_app_core_api_generated_controllers_reportController_service__WEBPACK_IMPORTED_MODULE_6__.ReportControllerService));
  }, this.ɵcmp = /*@__PURE__*/_angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵdefineComponent"]({
    type: TransportStatComponent,
    selectors: [["app-transport-stat"]],
    inputs: {
      playerId: "playerId"
    },
    standalone: false,
    decls: 11,
    vars: 7,
    consts: [["emptyStat", ""], ["color", "personal"], [4, "ngIf", "ngIfElse"], ["size", "6", 4, "ngFor", "ngForOf"], ["size", "6"], [1, "icon-size-normal", 3, "name"], [1, "empty-stats"]],
    template: function TransportStatComponent_Template(rf, ctx) {
      if (rf & 1) {
        _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵelementStart"](0, "ion-card")(1, "ion-card-header", 1);
        _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵtext"](2);
        _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵpipe"](3, "translate");
        _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵelementStart"](4, "ion-card-content")(5, "ion-grid")(6, "ion-row");
        _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵtemplate"](7, TransportStatComponent_ng_container_7_Template, 3, 3, "ng-container", 2);
        _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵpipe"](8, "async");
        _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵtemplate"](9, TransportStatComponent_ng_template_9_Template, 4, 3, "ng-template", null, 0, _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵtemplateRefExtractor"]);
        _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵelementEnd"]()()()();
      }
      if (rf & 2) {
        let tmp_2_0;
        const emptyStat_r3 = _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵreference"](10);
        _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵadvance"](2);
        _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵtextInterpolate1"](" ", _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵpipeBind1"](3, 3, "userprofile.last_month"));
        _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵadvance"](5);
        _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵproperty"]("ngIf", ((tmp_2_0 = _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵpipeBind1"](8, 5, ctx.personalStat$)) == null ? null : tmp_2_0.length) > 0)("ngIfElse", emptyStat_r3);
      }
    },
    dependencies: [_angular_common__WEBPACK_IMPORTED_MODULE_7__.NgForOf, _angular_common__WEBPACK_IMPORTED_MODULE_7__.NgIf, _ionic_angular__WEBPACK_IMPORTED_MODULE_8__.IonCard, _ionic_angular__WEBPACK_IMPORTED_MODULE_8__.IonCardContent, _ionic_angular__WEBPACK_IMPORTED_MODULE_8__.IonCardHeader, _ionic_angular__WEBPACK_IMPORTED_MODULE_8__.IonCol, _ionic_angular__WEBPACK_IMPORTED_MODULE_8__.IonGrid, _ionic_angular__WEBPACK_IMPORTED_MODULE_8__.IonRow, _core_shared_ui_icon_icon_component__WEBPACK_IMPORTED_MODULE_9__.IconComponent, _angular_common__WEBPACK_IMPORTED_MODULE_7__.AsyncPipe, _ngx_translate_core__WEBPACK_IMPORTED_MODULE_10__.TranslatePipe, _core_shared_pipes_localNumber_pipe__WEBPACK_IMPORTED_MODULE_11__.LocalNumberPipe],
    styles: ["ion-card[_ngcontent-%COMP%] {\n  color: var(--dark-grey);\n}\nion-card[_ngcontent-%COMP%]   ion-card-content[_ngcontent-%COMP%] {\n  font-size: 13px;\n}\nion-card[_ngcontent-%COMP%]   ion-card-header[_ngcontent-%COMP%] {\n  height: 21px;\n  display: flex;\n  justify-content: space-around;\n  flex-direction: column;\n  font-weight: 600;\n  font-size: 13px;\n  font-style: italic;\n}\nion-card[_ngcontent-%COMP%]   app-icon[_ngcontent-%COMP%] {\n  margin-right: 11px;\n}\nion-card[_ngcontent-%COMP%]   ion-col[_ngcontent-%COMP%] {\n  display: flex;\n  align-items: center !important;\n}\nion-card[_ngcontent-%COMP%]   .empty-stats[_ngcontent-%COMP%] {\n  margin: auto;\n  padding: 8px;\n  font-size: 20px;\n  text-align: center;\n  -ms-transform: translateY(-50%);\n}\n/*# sourceMappingURL=data:application/json;charset=utf-8;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbIndlYnBhY2s6Ly8uL3NyYy9hcHAvcGFnZXMvdXNlci1wcm9maWxlL3RyYW5zcG9ydC1zdGF0L3RyYW5zcG9ydC1zdGF0LmNvbXBvbmVudC5zY3NzIl0sIm5hbWVzIjpbXSwibWFwcGluZ3MiOiJBQUFBO0VBQ0UsdUJBQUE7QUFDRjtBQUFFO0VBQ0UsZUFBQTtBQUVKO0FBQUU7RUFDRSxZQUFBO0VBQ0EsYUFBQTtFQUNBLDZCQUFBO0VBQ0Esc0JBQUE7RUFDQSxnQkFBQTtFQUNBLGVBQUE7RUFDQSxrQkFBQTtBQUVKO0FBQUU7RUFDRSxrQkFBQTtBQUVKO0FBQUU7RUFDRSxhQUFBO0VBQ0EsOEJBQUE7QUFFSjtBQUFFO0VBQ0UsWUFBQTtFQUNBLFlBQUE7RUFDQSxlQUFBO0VBQ0Esa0JBQUE7RUFDQSwrQkFBQTtBQUVKIiwic291cmNlc0NvbnRlbnQiOlsiaW9uLWNhcmQge1xuICBjb2xvcjogdmFyKC0tZGFyay1ncmV5KTtcbiAgaW9uLWNhcmQtY29udGVudCB7XG4gICAgZm9udC1zaXplOiAxM3B4O1xuICB9XG4gIGlvbi1jYXJkLWhlYWRlciB7XG4gICAgaGVpZ2h0OiAyMXB4O1xuICAgIGRpc3BsYXk6IGZsZXg7XG4gICAganVzdGlmeS1jb250ZW50OiBzcGFjZS1hcm91bmQ7XG4gICAgZmxleC1kaXJlY3Rpb246IGNvbHVtbjtcbiAgICBmb250LXdlaWdodDogNjAwO1xuICAgIGZvbnQtc2l6ZTogMTNweDtcbiAgICBmb250LXN0eWxlOiBpdGFsaWM7XG4gIH1cbiAgYXBwLWljb24ge1xuICAgIG1hcmdpbi1yaWdodDogMTFweDtcbiAgfVxuICBpb24tY29sIHtcbiAgICBkaXNwbGF5OiBmbGV4O1xuICAgIGFsaWduLWl0ZW1zOiBjZW50ZXIgIWltcG9ydGFudDtcbiAgfVxuICAuZW1wdHktc3RhdHMge1xuICAgIG1hcmdpbjogYXV0bztcbiAgICBwYWRkaW5nOiA4cHg7XG4gICAgZm9udC1zaXplOiAyMHB4O1xuICAgIHRleHQtYWxpZ246IGNlbnRlcjtcbiAgICAtbXMtdHJhbnNmb3JtOiB0cmFuc2xhdGVZKC01MCUpO1xuICB9XG59XG4iXSwic291cmNlUm9vdCI6IiJ9 */"]
  }));
}
_staticBlock();

/***/ }),

/***/ 49267:
/*!******************************************************!*\
  !*** ./node_modules/lodash-es/_arrayIncludesWith.js ***!
  \******************************************************/
/***/ ((__unused_webpack___webpack_module__, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "default": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/**
 * This function is like `arrayIncludes` except that it accepts a comparator.
 *
 * @private
 * @param {Array} [array] The array to inspect.
 * @param {*} target The value to search for.
 * @param {Function} comparator The comparator invoked per element.
 * @returns {boolean} Returns `true` if `target` is found, else `false`.
 */
function arrayIncludesWith(array, value, comparator) {
  var index = -1,
    length = array == null ? 0 : array.length;
  while (++index < length) {
    if (comparator(value, array[index])) {
      return true;
    }
  }
  return false;
}
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (arrayIncludesWith);

/***/ }),

/***/ 80823:
/*!*****************************************************!*\
  !*** ./node_modules/lodash-es/_baseIntersection.js ***!
  \*****************************************************/
/***/ ((__unused_webpack___webpack_module__, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "default": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var _SetCache_js__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./_SetCache.js */ 82133);
/* harmony import */ var _arrayIncludes_js__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ./_arrayIncludes.js */ 33307);
/* harmony import */ var _arrayIncludesWith_js__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! ./_arrayIncludesWith.js */ 49267);
/* harmony import */ var _arrayMap_js__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! ./_arrayMap.js */ 7786);
/* harmony import */ var _baseUnary_js__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! ./_baseUnary.js */ 45583);
/* harmony import */ var _cacheHas_js__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! ./_cacheHas.js */ 64989);







/* Built-in method references for those with the same name as other `lodash` methods. */
var nativeMin = Math.min;

/**
 * The base implementation of methods like `_.intersection`, without support
 * for iteratee shorthands, that accepts an array of arrays to inspect.
 *
 * @private
 * @param {Array} arrays The arrays to inspect.
 * @param {Function} [iteratee] The iteratee invoked per element.
 * @param {Function} [comparator] The comparator invoked per element.
 * @returns {Array} Returns the new array of shared values.
 */
function baseIntersection(arrays, iteratee, comparator) {
  var includes = comparator ? _arrayIncludesWith_js__WEBPACK_IMPORTED_MODULE_2__["default"] : _arrayIncludes_js__WEBPACK_IMPORTED_MODULE_1__["default"],
    length = arrays[0].length,
    othLength = arrays.length,
    othIndex = othLength,
    caches = Array(othLength),
    maxLength = Infinity,
    result = [];
  while (othIndex--) {
    var array = arrays[othIndex];
    if (othIndex && iteratee) {
      array = (0,_arrayMap_js__WEBPACK_IMPORTED_MODULE_3__["default"])(array, (0,_baseUnary_js__WEBPACK_IMPORTED_MODULE_4__["default"])(iteratee));
    }
    maxLength = nativeMin(array.length, maxLength);
    caches[othIndex] = !comparator && (iteratee || length >= 120 && array.length >= 120) ? new _SetCache_js__WEBPACK_IMPORTED_MODULE_0__["default"](othIndex && array) : undefined;
  }
  array = arrays[0];
  var index = -1,
    seen = caches[0];
  outer: while (++index < length && result.length < maxLength) {
    var value = array[index],
      computed = iteratee ? iteratee(value) : value;
    value = comparator || value !== 0 ? value : 0;
    if (!(seen ? (0,_cacheHas_js__WEBPACK_IMPORTED_MODULE_5__["default"])(seen, computed) : includes(result, computed, comparator))) {
      othIndex = othLength;
      while (--othIndex) {
        var cache = caches[othIndex];
        if (!(cache ? (0,_cacheHas_js__WEBPACK_IMPORTED_MODULE_5__["default"])(cache, computed) : includes(arrays[othIndex], computed, comparator))) {
          continue outer;
        }
      }
      if (seen) {
        seen.push(computed);
      }
      result.push(value);
    }
  }
  return result;
}
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (baseIntersection);

/***/ }),

/***/ 83606:
/*!***********************************************************!*\
  !*** ./src/app/pages/user-profile/user-profile.module.ts ***!
  \***********************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   UserProfilePageModule: () => (/* binding */ UserProfilePageModule)
/* harmony export */ });
/* harmony import */ var _user_profile_routing_module__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./user-profile-routing.module */ 36551);
/* harmony import */ var _user_profile_page__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ./user-profile.page */ 27241);
/* harmony import */ var src_app_core_shared_shared_module__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! src/app/core/shared/shared.module */ 62657);
/* harmony import */ var _transport_stat_transport_stat_component__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! ./transport-stat/transport-stat.component */ 47673);
/* harmony import */ var _campaign_stat_campaign_stat_component__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! ./campaign-stat/campaign-stat.component */ 46943);
/* harmony import */ var _ionic_angular__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! @ionic/angular */ 21507);
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! @angular/core */ 34205);
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(/*! @angular/core */ 12481);
var _staticBlock;







class UserProfilePageModule {
  static #_ = _staticBlock = () => (this.ɵfac = function UserProfilePageModule_Factory(__ngFactoryType__) {
    return new (__ngFactoryType__ || UserProfilePageModule)();
  }, this.ɵmod = /*@__PURE__*/_angular_core__WEBPACK_IMPORTED_MODULE_7__["ɵɵdefineNgModule"]({
    type: UserProfilePageModule
  }), this.ɵinj = /*@__PURE__*/_angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵdefineInjector"]({
    imports: [src_app_core_shared_shared_module__WEBPACK_IMPORTED_MODULE_2__.PlayGoSharedModule, _user_profile_routing_module__WEBPACK_IMPORTED_MODULE_0__.UserProfilePageRoutingModule, _ionic_angular__WEBPACK_IMPORTED_MODULE_5__.IonicModule]
  }));
}
_staticBlock();
(function () {
  (typeof ngJitMode === "undefined" || ngJitMode) && _angular_core__WEBPACK_IMPORTED_MODULE_7__["ɵɵsetNgModuleScope"](UserProfilePageModule, {
    declarations: [_user_profile_page__WEBPACK_IMPORTED_MODULE_1__.UserProfilePage, _transport_stat_transport_stat_component__WEBPACK_IMPORTED_MODULE_3__.TransportStatComponent, _campaign_stat_campaign_stat_component__WEBPACK_IMPORTED_MODULE_4__.CampaignStatComponent],
    imports: [src_app_core_shared_shared_module__WEBPACK_IMPORTED_MODULE_2__.PlayGoSharedModule, _user_profile_routing_module__WEBPACK_IMPORTED_MODULE_0__.UserProfilePageRoutingModule, _ionic_angular__WEBPACK_IMPORTED_MODULE_5__.IonicModule]
  });
})();

/***/ }),

/***/ 92905:
/*!**************************************************!*\
  !*** ./node_modules/lodash-es/_strictIndexOf.js ***!
  \**************************************************/
/***/ ((__unused_webpack___webpack_module__, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "default": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/**
 * A specialized version of `_.indexOf` which performs strict equality
 * comparisons of values, i.e. `===`.
 *
 * @private
 * @param {Array} array The array to inspect.
 * @param {*} value The value to search for.
 * @param {number} fromIndex The index to search from.
 * @returns {number} Returns the index of the matched value, else `-1`.
 */
function strictIndexOf(array, value, fromIndex) {
  var index = fromIndex - 1,
    length = array.length;
  while (++index < length) {
    if (array[index] === value) {
      return index;
    }
  }
  return -1;
}
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (strictIndexOf);

/***/ }),

/***/ 99009:
/*!****************************************************!*\
  !*** ./node_modules/lodash-es/intersectionWith.js ***!
  \****************************************************/
/***/ ((__unused_webpack___webpack_module__, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "default": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var _arrayMap_js__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./_arrayMap.js */ 7786);
/* harmony import */ var _baseIntersection_js__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ./_baseIntersection.js */ 80823);
/* harmony import */ var _baseRest_js__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! ./_baseRest.js */ 46124);
/* harmony import */ var _castArrayLikeObject_js__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! ./_castArrayLikeObject.js */ 38619);
/* harmony import */ var _last_js__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! ./last.js */ 80524);






/**
 * This method is like `_.intersection` except that it accepts `comparator`
 * which is invoked to compare elements of `arrays`. The order and references
 * of result values are determined by the first array. The comparator is
 * invoked with two arguments: (arrVal, othVal).
 *
 * @static
 * @memberOf _
 * @since 4.0.0
 * @category Array
 * @param {...Array} [arrays] The arrays to inspect.
 * @param {Function} [comparator] The comparator invoked per element.
 * @returns {Array} Returns the new array of intersecting values.
 * @example
 *
 * var objects = [{ 'x': 1, 'y': 2 }, { 'x': 2, 'y': 1 }];
 * var others = [{ 'x': 1, 'y': 1 }, { 'x': 1, 'y': 2 }];
 *
 * _.intersectionWith(objects, others, _.isEqual);
 * // => [{ 'x': 1, 'y': 2 }]
 */
var intersectionWith = (0,_baseRest_js__WEBPACK_IMPORTED_MODULE_2__["default"])(function (arrays) {
  var comparator = (0,_last_js__WEBPACK_IMPORTED_MODULE_4__["default"])(arrays),
    mapped = (0,_arrayMap_js__WEBPACK_IMPORTED_MODULE_0__["default"])(arrays, _castArrayLikeObject_js__WEBPACK_IMPORTED_MODULE_3__["default"]);
  comparator = typeof comparator == 'function' ? comparator : undefined;
  if (comparator) {
    mapped.pop();
  }
  return mapped.length && mapped[0] === arrays[0] ? (0,_baseIntersection_js__WEBPACK_IMPORTED_MODULE_1__["default"])(mapped, undefined, comparator) : [];
});
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (intersectionWith);

/***/ })

}]);
//# sourceMappingURL=src_app_pages_user-profile_user-profile_module_ts.js.map