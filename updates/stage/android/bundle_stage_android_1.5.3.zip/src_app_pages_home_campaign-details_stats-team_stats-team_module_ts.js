"use strict";
(self["webpackChunkapp"] = self["webpackChunkapp"] || []).push([["src_app_pages_home_campaign-details_stats-team_stats-team_module_ts"],{

/***/ 17641:
/*!*************************************************************************************!*\
  !*** ./src/app/pages/home/campaign-details/stats-team/stats-team-routing.module.ts ***!
  \*************************************************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   StatsTeamPageRoutingModule: () => (/* binding */ StatsTeamPageRoutingModule)
/* harmony export */ });
/* harmony import */ var _angular_router__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! @angular/router */ 34487);
/* harmony import */ var _stats_team_page__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ./stats-team.page */ 54811);
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @angular/core */ 34205);
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @angular/core */ 12481);
var _staticBlock;




const routes = [{
  path: '',
  component: _stats_team_page__WEBPACK_IMPORTED_MODULE_1__.StatsTeamPage,
  data: {
    title: 'report.stats.title_team'
  }
}];
class StatsTeamPageRoutingModule {
  static #_ = _staticBlock = () => (this.ɵfac = function StatsTeamPageRoutingModule_Factory(__ngFactoryType__) {
    return new (__ngFactoryType__ || StatsTeamPageRoutingModule)();
  }, this.ɵmod = /*@__PURE__*/_angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵdefineNgModule"]({
    type: StatsTeamPageRoutingModule
  }), this.ɵinj = /*@__PURE__*/_angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵdefineInjector"]({
    imports: [_angular_router__WEBPACK_IMPORTED_MODULE_0__.RouterModule.forChild(routes), _angular_router__WEBPACK_IMPORTED_MODULE_0__.RouterModule]
  }));
}
_staticBlock();
(function () {
  (typeof ngJitMode === "undefined" || ngJitMode) && _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵsetNgModuleScope"](StatsTeamPageRoutingModule, {
    imports: [_angular_router__WEBPACK_IMPORTED_MODULE_0__.RouterModule],
    exports: [_angular_router__WEBPACK_IMPORTED_MODULE_0__.RouterModule]
  });
})();

/***/ }),

/***/ 54811:
/*!***************************************************************************!*\
  !*** ./src/app/pages/home/campaign-details/stats-team/stats-team.page.ts ***!
  \***************************************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   StatsTeamPage: () => (/* binding */ StatsTeamPage)
/* harmony export */ });
/* harmony import */ var _ionic_angular__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! @ionic/angular */ 21507);
/* harmony import */ var chart_js__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! chart.js */ 36792);
/* harmony import */ var rxjs__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! rxjs */ 10819);
/* harmony import */ var rxjs__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! rxjs */ 19999);
/* harmony import */ var rxjs__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! rxjs */ 47697);
/* harmony import */ var rxjs__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! rxjs */ 59452);
/* harmony import */ var luxon__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! luxon */ 45967);
/* harmony import */ var rxjs_operators__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(/*! rxjs/operators */ 70271);
/* harmony import */ var rxjs_operators__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(/*! rxjs/operators */ 86301);
/* harmony import */ var rxjs_operators__WEBPACK_IMPORTED_MODULE_9__ = __webpack_require__(/*! rxjs/operators */ 63037);
/* harmony import */ var rxjs_operators__WEBPACK_IMPORTED_MODULE_10__ = __webpack_require__(/*! rxjs/operators */ 36647);
/* harmony import */ var rxjs_operators__WEBPACK_IMPORTED_MODULE_11__ = __webpack_require__(/*! rxjs/operators */ 98764);
/* harmony import */ var src_app_core_shared_time_utils__WEBPACK_IMPORTED_MODULE_12__ = __webpack_require__(/*! src/app/core/shared/time.utils */ 27780);
/* harmony import */ var src_app_core_shared_campaigns_campaign_utils__WEBPACK_IMPORTED_MODULE_13__ = __webpack_require__(/*! src/app/core/shared/campaigns/campaign.utils */ 14691);
/* harmony import */ var src_app_core_shared_tracking_trip_model__WEBPACK_IMPORTED_MODULE_14__ = __webpack_require__(/*! src/app/core/shared/tracking/trip.model */ 23126);
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_15__ = __webpack_require__(/*! @angular/core */ 34205);
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_16__ = __webpack_require__(/*! @angular/core */ 12481);
/* harmony import */ var _angular_router__WEBPACK_IMPORTED_MODULE_17__ = __webpack_require__(/*! @angular/router */ 85422);
/* harmony import */ var src_app_core_shared_services_team_service__WEBPACK_IMPORTED_MODULE_18__ = __webpack_require__(/*! src/app/core/shared/services/team.service */ 62625);
/* harmony import */ var src_app_core_shared_services_user_service__WEBPACK_IMPORTED_MODULE_19__ = __webpack_require__(/*! src/app/core/shared/services/user.service */ 89815);
/* harmony import */ var src_app_core_shared_services_error_service__WEBPACK_IMPORTED_MODULE_20__ = __webpack_require__(/*! src/app/core/shared/services/error.service */ 46078);
/* harmony import */ var src_app_core_shared_services_campaign_service__WEBPACK_IMPORTED_MODULE_21__ = __webpack_require__(/*! src/app/core/shared/services/campaign.service */ 76658);
/* harmony import */ var src_app_core_shared_services_page_settings_service__WEBPACK_IMPORTED_MODULE_22__ = __webpack_require__(/*! src/app/core/shared/services/page-settings.service */ 40147);
/* harmony import */ var src_app_core_shared_pipes_localDate_pipe__WEBPACK_IMPORTED_MODULE_23__ = __webpack_require__(/*! src/app/core/shared/pipes/localDate.pipe */ 86451);
/* harmony import */ var _angular_common__WEBPACK_IMPORTED_MODULE_24__ = __webpack_require__(/*! @angular/common */ 93683);
/* harmony import */ var _angular_forms__WEBPACK_IMPORTED_MODULE_25__ = __webpack_require__(/*! @angular/forms */ 34456);
/* harmony import */ var _core_shared_layout_header_header_directive__WEBPACK_IMPORTED_MODULE_26__ = __webpack_require__(/*! ../../../../core/shared/layout/header/header.directive */ 85039);
/* harmony import */ var _core_shared_layout_content_content_directive__WEBPACK_IMPORTED_MODULE_27__ = __webpack_require__(/*! ../../../../core/shared/layout/content/content.directive */ 75855);
/* harmony import */ var _ngx_translate_core__WEBPACK_IMPORTED_MODULE_28__ = __webpack_require__(/*! @ngx-translate/core */ 48503);
/* harmony import */ var _core_shared_pipes_localNumber_pipe__WEBPACK_IMPORTED_MODULE_29__ = __webpack_require__(/*! ../../../../core/shared/pipes/localNumber.pipe */ 16024);
var _staticBlock;























const _c0 = ["barCanvas"];
const _c1 = ["refresher"];
const _c2 = () => ({
  cssClass: "app-alert"
});
function StatsTeamPage_ion_select_option_9_Template(rf, ctx) {
  if (rf & 1) {
    _angular_core__WEBPACK_IMPORTED_MODULE_16__["ɵɵelementStart"](0, "ion-select-option", 21);
    _angular_core__WEBPACK_IMPORTED_MODULE_16__["ɵɵtext"](1);
    _angular_core__WEBPACK_IMPORTED_MODULE_16__["ɵɵpipe"](2, "translate");
    _angular_core__WEBPACK_IMPORTED_MODULE_16__["ɵɵelementEnd"]();
  }
  if (rf & 2) {
    const mean_r2 = ctx.$implicit;
    const ctx_r2 = _angular_core__WEBPACK_IMPORTED_MODULE_16__["ɵɵnextContext"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_16__["ɵɵproperty"]("value", mean_r2);
    _angular_core__WEBPACK_IMPORTED_MODULE_16__["ɵɵadvance"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_16__["ɵɵtextInterpolate1"](" ", _angular_core__WEBPACK_IMPORTED_MODULE_16__["ɵɵpipeBind1"](2, 2, ctx_r2.meanLabels[mean_r2]), " ");
  }
}
function StatsTeamPage_ion_col_14_ion_select_option_4_Template(rf, ctx) {
  if (rf & 1) {
    _angular_core__WEBPACK_IMPORTED_MODULE_16__["ɵɵelementStart"](0, "ion-select-option", 21);
    _angular_core__WEBPACK_IMPORTED_MODULE_16__["ɵɵtext"](1);
    _angular_core__WEBPACK_IMPORTED_MODULE_16__["ɵɵpipe"](2, "translate");
    _angular_core__WEBPACK_IMPORTED_MODULE_16__["ɵɵelementEnd"]();
  }
  if (rf & 2) {
    const metric_r5 = ctx.$implicit;
    const ctx_r2 = _angular_core__WEBPACK_IMPORTED_MODULE_16__["ɵɵnextContext"](2);
    _angular_core__WEBPACK_IMPORTED_MODULE_16__["ɵɵproperty"]("value", metric_r5);
    _angular_core__WEBPACK_IMPORTED_MODULE_16__["ɵɵadvance"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_16__["ɵɵtextInterpolate1"](" ", _angular_core__WEBPACK_IMPORTED_MODULE_16__["ɵɵpipeBind1"](2, 2, ctx_r2.metricToSelectLabel[metric_r5]), " ");
  }
}
function StatsTeamPage_ion_col_14_Template(rf, ctx) {
  if (rf & 1) {
    const _r4 = _angular_core__WEBPACK_IMPORTED_MODULE_16__["ɵɵgetCurrentView"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_16__["ɵɵelementStart"](0, "ion-col")(1, "ion-item", 22)(2, "ion-select", 6);
    _angular_core__WEBPACK_IMPORTED_MODULE_16__["ɵɵpipe"](3, "async");
    _angular_core__WEBPACK_IMPORTED_MODULE_16__["ɵɵlistener"]("ionChange", function StatsTeamPage_ion_col_14_Template_ion_select_ionChange_2_listener($event) {
      _angular_core__WEBPACK_IMPORTED_MODULE_15__["ɵɵrestoreView"](_r4);
      const ctx_r2 = _angular_core__WEBPACK_IMPORTED_MODULE_16__["ɵɵnextContext"]();
      return _angular_core__WEBPACK_IMPORTED_MODULE_15__["ɵɵresetView"](ctx_r2.selectedMetricChangedSubject.next($event));
    });
    _angular_core__WEBPACK_IMPORTED_MODULE_16__["ɵɵtemplate"](4, StatsTeamPage_ion_col_14_ion_select_option_4_Template, 3, 4, "ion-select-option", 7);
    _angular_core__WEBPACK_IMPORTED_MODULE_16__["ɵɵelementEnd"]()()();
  }
  if (rf & 2) {
    const ctx_r2 = _angular_core__WEBPACK_IMPORTED_MODULE_16__["ɵɵnextContext"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_16__["ɵɵadvance"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_16__["ɵɵproperty"]("color", ctx_r2.campaignContainer.campaign.type);
    _angular_core__WEBPACK_IMPORTED_MODULE_16__["ɵɵadvance"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_16__["ɵɵproperty"]("interfaceOptions", _angular_core__WEBPACK_IMPORTED_MODULE_16__["ɵɵpureFunction0"](6, _c2))("value", _angular_core__WEBPACK_IMPORTED_MODULE_16__["ɵɵpipeBind1"](3, 4, ctx_r2.selectedMetric$));
    _angular_core__WEBPACK_IMPORTED_MODULE_16__["ɵɵadvance"](2);
    _angular_core__WEBPACK_IMPORTED_MODULE_16__["ɵɵproperty"]("ngForOf", ctx_r2.metrics);
  }
}
function StatsTeamPage_ion_col_16_Template(rf, ctx) {
  if (rf & 1) {
    _angular_core__WEBPACK_IMPORTED_MODULE_16__["ɵɵelementStart"](0, "ion-col")(1, "ion-item", 23);
    _angular_core__WEBPACK_IMPORTED_MODULE_16__["ɵɵtext"](2);
    _angular_core__WEBPACK_IMPORTED_MODULE_16__["ɵɵpipe"](3, "translate");
    _angular_core__WEBPACK_IMPORTED_MODULE_16__["ɵɵelementEnd"]()();
  }
  if (rf & 2) {
    const ctx_r2 = _angular_core__WEBPACK_IMPORTED_MODULE_16__["ɵɵnextContext"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_16__["ɵɵadvance"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_16__["ɵɵproperty"]("color", ctx_r2.campaignContainer == null ? null : ctx_r2.campaignContainer.campaign == null ? null : ctx_r2.campaignContainer.campaign.type);
    _angular_core__WEBPACK_IMPORTED_MODULE_16__["ɵɵadvance"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_16__["ɵɵtextInterpolate1"](" ", _angular_core__WEBPACK_IMPORTED_MODULE_16__["ɵɵpipeBind1"](3, 2, "campaigns.leaderboard.leaderboard_type.GL"), " ");
  }
}
function StatsTeamPage_ion_segment_button_22_Template(rf, ctx) {
  if (rf & 1) {
    _angular_core__WEBPACK_IMPORTED_MODULE_16__["ɵɵelementStart"](0, "ion-segment-button", 24)(1, "ion-label");
    _angular_core__WEBPACK_IMPORTED_MODULE_16__["ɵɵtext"](2);
    _angular_core__WEBPACK_IMPORTED_MODULE_16__["ɵɵpipe"](3, "translate");
    _angular_core__WEBPACK_IMPORTED_MODULE_16__["ɵɵelementEnd"]()();
  }
  if (rf & 2) {
    const period_r6 = ctx.$implicit;
    const ctx_r2 = _angular_core__WEBPACK_IMPORTED_MODULE_16__["ɵɵnextContext"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_16__["ɵɵstyleProp"]("--radius", "10px")("--color", "var(--ion-color-" + ctx_r2.campaignContainer.campaign.type + "-contrast)")("--color-checked", "black");
    _angular_core__WEBPACK_IMPORTED_MODULE_16__["ɵɵproperty"]("value", period_r6);
    _angular_core__WEBPACK_IMPORTED_MODULE_16__["ɵɵadvance"](2);
    _angular_core__WEBPACK_IMPORTED_MODULE_16__["ɵɵtextInterpolate"](_angular_core__WEBPACK_IMPORTED_MODULE_16__["ɵɵpipeBind1"](3, 8, period_r6.labelKey));
  }
}
function StatsTeamPage_ion_button_26_Template(rf, ctx) {
  if (rf & 1) {
    const _r7 = _angular_core__WEBPACK_IMPORTED_MODULE_16__["ɵɵgetCurrentView"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_16__["ɵɵelementStart"](0, "ion-button", 25);
    _angular_core__WEBPACK_IMPORTED_MODULE_16__["ɵɵlistener"]("click", function StatsTeamPage_ion_button_26_Template_ion_button_click_0_listener() {
      _angular_core__WEBPACK_IMPORTED_MODULE_15__["ɵɵrestoreView"](_r7);
      const ctx_r2 = _angular_core__WEBPACK_IMPORTED_MODULE_16__["ɵɵnextContext"]();
      return _angular_core__WEBPACK_IMPORTED_MODULE_15__["ɵɵresetView"](ctx_r2.backPeriod());
    });
    _angular_core__WEBPACK_IMPORTED_MODULE_16__["ɵɵelement"](1, "ion-icon", 26);
    _angular_core__WEBPACK_IMPORTED_MODULE_16__["ɵɵelementEnd"]();
  }
  if (rf & 2) {
    const ctx_r2 = _angular_core__WEBPACK_IMPORTED_MODULE_16__["ɵɵnextContext"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_16__["ɵɵstyleProp"]("color", "var(--ion-color-" + ctx_r2.campaignContainer.campaign.type + "-dark-contrast)");
  }
}
function StatsTeamPage_p_30_Template(rf, ctx) {
  if (rf & 1) {
    _angular_core__WEBPACK_IMPORTED_MODULE_16__["ɵɵelementStart"](0, "p", 27);
    _angular_core__WEBPACK_IMPORTED_MODULE_16__["ɵɵtext"](1);
    _angular_core__WEBPACK_IMPORTED_MODULE_16__["ɵɵpipe"](2, "localNumber");
    _angular_core__WEBPACK_IMPORTED_MODULE_16__["ɵɵpipe"](3, "async");
    _angular_core__WEBPACK_IMPORTED_MODULE_16__["ɵɵpipe"](4, "translate");
    _angular_core__WEBPACK_IMPORTED_MODULE_16__["ɵɵelementEnd"]();
  }
  if (rf & 2) {
    const ctx_r2 = _angular_core__WEBPACK_IMPORTED_MODULE_16__["ɵɵnextContext"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_16__["ɵɵstyleProp"]("color", "var(--ion-color-" + ctx_r2.campaignContainer.campaign.type + "-dark-contrast)");
    _angular_core__WEBPACK_IMPORTED_MODULE_16__["ɵɵadvance"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_16__["ɵɵtextInterpolate2"](" ", _angular_core__WEBPACK_IMPORTED_MODULE_16__["ɵɵpipeBind2"](2, 4, ctx_r2.totalValue, "0.0-1"), " ", _angular_core__WEBPACK_IMPORTED_MODULE_16__["ɵɵpipeBind1"](4, 9, ctx_r2.metricToUnitLabel[_angular_core__WEBPACK_IMPORTED_MODULE_16__["ɵɵpipeBind1"](3, 7, ctx_r2.selectedMetric$)]), " ");
  }
}
function StatsTeamPage_p_32_Template(rf, ctx) {
  if (rf & 1) {
    _angular_core__WEBPACK_IMPORTED_MODULE_16__["ɵɵelementStart"](0, "p", 27);
    _angular_core__WEBPACK_IMPORTED_MODULE_16__["ɵɵtext"](1);
    _angular_core__WEBPACK_IMPORTED_MODULE_16__["ɵɵpipe"](2, "localNumber");
    _angular_core__WEBPACK_IMPORTED_MODULE_16__["ɵɵelementEnd"]();
  }
  if (rf & 2) {
    const ctx_r2 = _angular_core__WEBPACK_IMPORTED_MODULE_16__["ɵɵnextContext"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_16__["ɵɵstyleProp"]("color", "var(--ion-color-" + ctx_r2.campaignContainer.campaign.type + "-dark-contrast)");
    _angular_core__WEBPACK_IMPORTED_MODULE_16__["ɵɵadvance"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_16__["ɵɵtextInterpolate1"](" ", _angular_core__WEBPACK_IMPORTED_MODULE_16__["ɵɵpipeBind2"](2, 3, ctx_r2.totalValue, "0.0-1"), " ecoLeaves ");
  }
}
function StatsTeamPage_ion_button_35_Template(rf, ctx) {
  if (rf & 1) {
    const _r8 = _angular_core__WEBPACK_IMPORTED_MODULE_16__["ɵɵgetCurrentView"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_16__["ɵɵelementStart"](0, "ion-button", 25);
    _angular_core__WEBPACK_IMPORTED_MODULE_16__["ɵɵlistener"]("click", function StatsTeamPage_ion_button_35_Template_ion_button_click_0_listener() {
      _angular_core__WEBPACK_IMPORTED_MODULE_15__["ɵɵrestoreView"](_r8);
      const ctx_r2 = _angular_core__WEBPACK_IMPORTED_MODULE_16__["ɵɵnextContext"]();
      return _angular_core__WEBPACK_IMPORTED_MODULE_15__["ɵɵresetView"](ctx_r2.forwardPeriod());
    });
    _angular_core__WEBPACK_IMPORTED_MODULE_16__["ɵɵelement"](1, "ion-icon", 28);
    _angular_core__WEBPACK_IMPORTED_MODULE_16__["ɵɵelementEnd"]();
  }
  if (rf & 2) {
    const ctx_r2 = _angular_core__WEBPACK_IMPORTED_MODULE_16__["ɵɵnextContext"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_16__["ɵɵstyleProp"]("color", "var(--ion-color-" + ctx_r2.campaignContainer.campaign.type + "-dark-contrast)");
  }
}
class StatsTeamPage {
  constructor(route, teamService, userService, errorService, campaignService, pageSettingsService, localDatePipe) {
    this.route = route;
    this.teamService = teamService;
    this.userService = userService;
    this.errorService = errorService;
    this.campaignService = campaignService;
    this.pageSettingsService = pageSettingsService;
    this.localDatePipe = localDatePipe;
    this.selectedMeanChangedSubject = new rxjs__WEBPACK_IMPORTED_MODULE_2__.Subject();
    this.selectedMetricChangedSubject = new rxjs__WEBPACK_IMPORTED_MODULE_2__.Subject();
    this.meanLabels = {
      ...src_app_core_shared_tracking_trip_model__WEBPACK_IMPORTED_MODULE_14__.transportTypeLabels,
      [ALL_MEANS]: 'campaigns.leaderboard.all_means',
      [GL]: 'campaigns.leaderboard.gl'
    };
    this.metricToNumberWithUnitLabel = {
      co2: 'campaigns.leaderboard.leaderboard_type_unit.co2',
      km: 'campaigns.leaderboard.leaderboard_type_unit.km',
      time: 'campaigns.leaderboard.leaderboard_type_unit.duration',
      tracks: 'campaigns.leaderboard.leaderboard_type_unit.tracks'
    };
    this.metricToSelectLabel = {
      co2: 'campaigns.leaderboard.select.co2',
      km: 'campaigns.leaderboard.select.km',
      time: 'campaigns.leaderboard.select.duration',
      tracks: 'campaigns.leaderboard.select.tracks'
    };
    this.metricToUnitLabel = {
      co2: 'campaigns.leaderboard.unit.co2',
      km: 'campaigns.leaderboard.unit.km',
      time: 'campaigns.leaderboard.unit.duration',
      tracks: 'campaigns.leaderboard.unit.tracks'
    };
    this.selectedMean$ = this.selectedMeanChangedSubject.pipe((0,rxjs_operators__WEBPACK_IMPORTED_MODULE_7__.map)(event => event.detail.value), (0,rxjs_operators__WEBPACK_IMPORTED_MODULE_9__.startWith)(ALL_MEANS), (0,rxjs_operators__WEBPACK_IMPORTED_MODULE_8__.shareReplay)(1));
    this.selectedMetric$ = this.selectedMetricChangedSubject.pipe((0,rxjs_operators__WEBPACK_IMPORTED_MODULE_7__.map)(event => event.detail.value), (0,rxjs_operators__WEBPACK_IMPORTED_MODULE_11__.tap)(metric => this.setDivider(metric)), (0,rxjs_operators__WEBPACK_IMPORTED_MODULE_9__.startWith)(
    // initial select value
    'km'), (0,rxjs_operators__WEBPACK_IMPORTED_MODULE_8__.shareReplay)(1));
    this.referenceDate = luxon__WEBPACK_IMPORTED_MODULE_6__.DateTime.local();
    this.todayDate = luxon__WEBPACK_IMPORTED_MODULE_6__.DateTime.local();
    this.totalValue = 0;
    this.periods = (0,src_app_core_shared_campaigns_campaign_utils__WEBPACK_IMPORTED_MODULE_13__.getPeriods)(this.referenceDate);
    this.selectedPeriod = this.periods[0];
    this.statPeriodChangedSubject = new rxjs__WEBPACK_IMPORTED_MODULE_2__.Subject();
    this.selectedPeriod$ = this.statPeriodChangedSubject.pipe((0,rxjs_operators__WEBPACK_IMPORTED_MODULE_7__.map)(period => {
      this.selectedPeriod = period;
      return this.getPeriodByReference(period);
    }), (0,rxjs_operators__WEBPACK_IMPORTED_MODULE_9__.startWith)(this.periods[0]), (0,rxjs_operators__WEBPACK_IMPORTED_MODULE_8__.shareReplay)(1));
    this.campaignId$ = this.route.params.pipe((0,rxjs_operators__WEBPACK_IMPORTED_MODULE_7__.map)(params => params.id), (0,rxjs_operators__WEBPACK_IMPORTED_MODULE_8__.shareReplay)(1));
    this.teamIdSubject = new rxjs__WEBPACK_IMPORTED_MODULE_2__.Subject();
    this.teamId$ = this.teamIdSubject.pipe((0,rxjs_operators__WEBPACK_IMPORTED_MODULE_11__.tap)(id => console.log(id)), (0,rxjs_operators__WEBPACK_IMPORTED_MODULE_8__.shareReplay)(1));
    // teamId$: Observable<string> = this.userService.userProfile$.pipe(
    //   map((userProfile) => userProfile.playerId),
    //   shareReplay(1)
    // );
    this.filterOptions$ = (0,rxjs__WEBPACK_IMPORTED_MODULE_3__.combineLatest)({
      mean: this.selectedMean$,
      metric: this.selectedMetric$,
      period: this.selectedPeriod$,
      campaignId: this.campaignId$,
      teamId: this.teamId$
    });
    this.statResponse$ = this.filterOptions$.pipe((0,rxjs_operators__WEBPACK_IMPORTED_MODULE_10__.switchMap)(({
      mean,
      metric,
      period,
      campaignId,
      teamId
    }) => (0,rxjs__WEBPACK_IMPORTED_MODULE_4__.iif)(() => mean !== 'GL', this.teamService.getGroupStat(campaignId, teamId, metric, period.group, mean === ALL_MEANS ? null : mean, (0,src_app_core_shared_time_utils__WEBPACK_IMPORTED_MODULE_12__.toServerDateOnly)(period.from), (0,src_app_core_shared_time_utils__WEBPACK_IMPORTED_MODULE_12__.toServerDateOnly)(period.to)), this.teamService.getGroupGameStats(campaignId, teamId, period.group, (0,src_app_core_shared_time_utils__WEBPACK_IMPORTED_MODULE_12__.toServerDateOnly)(period.from), (0,src_app_core_shared_time_utils__WEBPACK_IMPORTED_MODULE_12__.toServerDateOnly)(period.to)).pipe(this.errorService.getErrorHandler()))));
    this.divider = 1000;
    this.style = getComputedStyle(document.body);
    this.statsSubs = this.statResponse$.subscribe(stats => {
      let convertedStat = stats.map(stat => stat?.value >= 0 ? {
        ...stat,
        value: stat.value / this.divider
      } : {
        ...stat,
        value: 0
      });
      this.barChartMethod(convertedStat);
      this.setTotal(convertedStat);
    });
    this.subId = this.route.params.subscribe(params => {
      this.id = params.id;
      this.subCampaign = this.campaignService.myCampaigns$.subscribe(campaigns => {
        this.campaignContainer = campaigns.find(campaignContainer => campaignContainer?.campaign?.campaignId === this.id);
        if (this.campaignContainer) {
          this.initMeanAndMetrics();
        }
      });
    });
  }
  initMeanAndMetrics() {
    this.metrics = this.campaignContainer?.campaign?.type === 'company' ? ['co2', 'km'] : ['co2', 'km', 'time', 'tracks'];
    this.means$ = (0,rxjs__WEBPACK_IMPORTED_MODULE_5__.of)([ALL_MEANS, ...this.campaignContainer?.campaign?.validationData.means]);
    // this.selectedMeanChangedSubject.next({
    //   detail: { value: this.campaignContainer?.campaign?.validationData?.means[0] },
    // } as SelectCustomEvent<TransportType>);
  }
  ionViewWillEnter() {
    this.changePageSettings();
  }
  setDivider(metric) {
    switch (metric) {
      case 'co2':
        this.divider = 1;
        break;
      case 'km':
        this.divider = 1000;
        break;
      case 'time':
        this.divider = 3600;
        break;
      case 'tracks':
        this.divider = 1;
        break;
      default:
        this.divider = 1000;
        break;
    }
  }
  changePageSettings() {
    this.pageSettingsService.set({
      color: this.campaignContainer?.campaign?.type
    });
  }
  setTotal(stats) {
    this.totalValue = stats.map(stat => stat.totalScore ? stat.totalScore : stat.value >= 0 ? stat.value : 0).reduce((prev, next) => prev + next, 0);
  }
  ngOnInit() {
    this.selectedSegment = this.periods[0];
    this.teamService.getMyTeam(this.campaignContainer?.campaign?.campaignId, this.campaignContainer?.subscription?.campaignData?.teamId).pipe((0,rxjs_operators__WEBPACK_IMPORTED_MODULE_7__.map)(team => team.id), (0,rxjs_operators__WEBPACK_IMPORTED_MODULE_11__.tap)(id => this.teamIdSubject.next(id))).subscribe();
  }
  ngOnDestroy() {}
  ionViewDidLeave() {
    this.statsSubs.unsubscribe();
  }
  getPeriodByReference(value) {
    return this.periods.find(period => period.group === value.group);
  }
  segmentChanged(ev) {
    console.log('Segment changed, change the selected period', ev);
  }
  thereIsPast() {
    // Check if  is not in actual period
    // get future of the button
    let refDate = this.referenceDate.plus({
      [this.selectedPeriod.add]: -1
    });
    return refDate.startOf(this.selectedPeriod.add) >= luxon__WEBPACK_IMPORTED_MODULE_6__.DateTime.fromMillis(this.campaignContainer?.campaign?.dateFrom).startOf(this.selectedPeriod.add);
  }
  thereIsFuture() {
    // Check if  is not in actual period
    // get future of the button
    let refDate = this.referenceDate.plus({
      [this.selectedPeriod.add]: 1
    });
    return refDate.startOf(this.selectedPeriod.add) <= this.todayDate.startOf(this.selectedPeriod.add);
  }
  backPeriod() {
    //change referenceDate
    this.referenceDate = this.referenceDate.plus({
      [this.selectedPeriod.add]: -1
    });
    //only get but it doesn't write on subject
    this.periods = (0,src_app_core_shared_campaigns_campaign_utils__WEBPACK_IMPORTED_MODULE_13__.getPeriods)(this.referenceDate);
    const tabIndex = this.periods.findIndex(period => period.group === this.selectedPeriod.group);
    this.selectedSegment = this.periods[tabIndex];
    this.statPeriodChangedSubject.next(this.periods[tabIndex]);
  }
  forwardPeriod() {
    this.referenceDate = this.referenceDate.plus({
      [this.selectedPeriod.add]: 1
    });
    this.periods = (0,src_app_core_shared_campaigns_campaign_utils__WEBPACK_IMPORTED_MODULE_13__.getPeriods)(this.referenceDate);
    const tabIndex = this.periods.findIndex(period => period.group === this.selectedPeriod.group);
    this.selectedSegment = this.periods[tabIndex];
    this.statPeriodChangedSubject.next(this.periods[tabIndex]);
  }
  daysFromInterval() {
    const retArr = [];
    const start = this.selectedPeriod.from;
    const end = this.selectedPeriod.to;
    const interval = luxon__WEBPACK_IMPORTED_MODULE_6__.Interval.fromDateTimes(start, end);
    let cursor = interval.start;
    cursor = cursor.startOf(this.selectedPeriod.group);
    while (cursor < interval.end) {
      //begin of the element
      if (this.selectedPeriod.group !== 'week') {
        retArr.push({
          label: cursor.toFormat(this.selectedPeriod.chartFormat),
          date: cursor
        });
      } else {
        retArr.push({
          label: cursor.toFormat(this.selectedPeriod.chartFormat) + '-' + cursor.endOf('week').toFormat(this.selectedPeriod.chartFormat),
          date: cursor
        });
      }
      cursor = cursor.plus({
        [this.selectedPeriod.group]: 1
      });
    }
    return retArr;
  }
  getObjectDate(statPeriod) {
    //anno - mese o anno numero settimana o anno mese giorno in base alla selezione
    const periodSplitted = statPeriod.split('-');
    switch (this.selectedPeriod.group) {
      case 'day':
        return {
          year: Number(periodSplitted[0]),
          month: Number(periodSplitted[1]),
          day: Number(periodSplitted[2])
        };
      case 'week':
        return {
          weekYear: Number(periodSplitted[0]),
          weekNumber: Number(periodSplitted[1])
        };
      case 'month':
        return {
          year: Number(periodSplitted[0]),
          month: Number(periodSplitted[1])
        };
    }
  }
  valuesFromStat(arrOfPeriod, stats) {
    //  check if stats[i] is part of arrOfPeriod
    let statsArrayDate = stats.map(stat => {
      console.log(stat);
      return luxon__WEBPACK_IMPORTED_MODULE_6__.DateTime.fromObject(this.getObjectDate(stat.period));
    });
    console.log(statsArrayDate);
    const retArr = [];
    for (let period of arrOfPeriod) {
      //check if statsArrayDate has a period
      const i = statsArrayDate.findIndex(statPeriod => statPeriod.toISO() === period.toISO());
      if (i !== -1) {
        if (stats[i].hasOwnProperty('totalScore')) {
          retArr.push(stats[i].value >= 0 ? stats[i].totalScore : 0);
        } else {
          retArr.push(stats[i].value >= 0 ? stats[i].value : 0);
        }
      } else {
        retArr.push(0);
      }
    }
    return retArr;
  }
  barChartMethod(stats) {
    // Now we need to supply a Chart element reference with an
    //object that defines the type of chart we want to use, and the type of data we want to display.
    // eslint-disable-next-line max-len
    chart_js__WEBPACK_IMPORTED_MODULE_1__.Chart.register(chart_js__WEBPACK_IMPORTED_MODULE_1__.LineController, chart_js__WEBPACK_IMPORTED_MODULE_1__.BarController, chart_js__WEBPACK_IMPORTED_MODULE_1__.CategoryScale, chart_js__WEBPACK_IMPORTED_MODULE_1__.LinearScale, chart_js__WEBPACK_IMPORTED_MODULE_1__.BarElement, chart_js__WEBPACK_IMPORTED_MODULE_1__.DoughnutController, chart_js__WEBPACK_IMPORTED_MODULE_1__.ArcElement, chart_js__WEBPACK_IMPORTED_MODULE_1__.PointElement, chart_js__WEBPACK_IMPORTED_MODULE_1__.LineElement);
    if (!this.barCanvas) {
      return;
    } else {
      const chartExist = chart_js__WEBPACK_IMPORTED_MODULE_1__.Chart.getChart('statsChart');
      if (chartExist !== undefined) {
        chartExist.destroy();
      }
    }
    //build using stats and this.selectedPeriod
    const arrOfPeriod = this.daysFromInterval();
    const arrOfValues = this.valuesFromStat(arrOfPeriod.map(period => period.date), stats);
    this.barChart = new chart_js__WEBPACK_IMPORTED_MODULE_1__.Chart(this.barCanvas.nativeElement, {
      type: 'bar',
      options: {
        onClick: e => {
          const points = this.barChart.getElementsAtEventForMode(e, 'nearest', {
            intersect: true
          }, true);
          if (points.length) {
            const firstPoint = points[0];
            const label = arrOfPeriod.find(data => data.label === this.barChart.data.labels[firstPoint.index])?.date;
            //const label = this.barChart.data.labels[firstPoint.index];
            //clicked on label x so I have to switch to that view base on what I'm watching
            this.changeView(label.toFormat(this.selectedPeriod.format));
            //const value = this.barChart.data.datasets[firstPoint.datasetIndex].data[firstPoint.index];
          }
        },
        scales: {
          x: {
            grid: {
              display: false
            },
            ticks: {
              font: {
                size: 17,
                weight: 'bold'
              }
            }
          }
        },
        responsive: true,
        maintainAspectRatio: false
      },
      data: {
        labels: arrOfPeriod.map(period => period.label),
        datasets: [{
          data: arrOfValues,
          backgroundColor: this.style.getPropertyValue('--ion-color-' + this.campaignContainer.campaign.type),
          borderColor: this.style.getPropertyValue('--ion-color-' + this.campaignContainer.campaign.type),
          borderWidth: 1,
          borderRadius: 5
        }]
      }
    });
  }
  getSelectedPeriod() {
    let date = this.localDatePipe.transform(this.selectedPeriod.from, this.selectedPeriod.label);
    if (this.selectedSegment.group === 'day') {
      date += ' / ' + this.localDatePipe.transform(this.selectedPeriod.to, this.selectedPeriod.label);
    }
    return date.replace(/(^\w|\s\w)/g, m => m.toUpperCase());
  }
  changeView(label) {
    // segmentChanged($event); statPeriodChangedSubject.next(selectedSegment)
    const switchToPeriod = null;
    switch (this.selectedSegment.group) {
      case 'month':
        label = luxon__WEBPACK_IMPORTED_MODULE_6__.DateTime.fromFormat(label, 'MM-yyyy').toFormat('yyyy-MM-dd');
        break;
      case 'week':
        label = luxon__WEBPACK_IMPORTED_MODULE_6__.DateTime.fromFormat(label, 'dd-MM-yyyy').toFormat('yyyy-WW');
        break;
      case 'day':
        // label = DateTime.fromFormat(label, 'dd-MM').toFormat('yyyy-MM-dd');
        return;
      default:
        break;
    }
    // change reference date
    //only get but it doesn't write on subject
    this.referenceDate = luxon__WEBPACK_IMPORTED_MODULE_6__.DateTime.fromObject(this.getObjectDate(label));
    this.periods = (0,src_app_core_shared_campaigns_campaign_utils__WEBPACK_IMPORTED_MODULE_13__.getPeriods)(this.referenceDate);
    this.selectedSegment = this.periods.find(a => a.group === this.selectedSegment.switchTo);
    this.statPeriodChangedSubject.next(this.selectedSegment);
  }
  static #_ = _staticBlock = () => (this.ɵfac = function StatsTeamPage_Factory(__ngFactoryType__) {
    return new (__ngFactoryType__ || StatsTeamPage)(_angular_core__WEBPACK_IMPORTED_MODULE_16__["ɵɵdirectiveInject"](_angular_router__WEBPACK_IMPORTED_MODULE_17__.ActivatedRoute), _angular_core__WEBPACK_IMPORTED_MODULE_16__["ɵɵdirectiveInject"](src_app_core_shared_services_team_service__WEBPACK_IMPORTED_MODULE_18__.TeamService), _angular_core__WEBPACK_IMPORTED_MODULE_16__["ɵɵdirectiveInject"](src_app_core_shared_services_user_service__WEBPACK_IMPORTED_MODULE_19__.UserService), _angular_core__WEBPACK_IMPORTED_MODULE_16__["ɵɵdirectiveInject"](src_app_core_shared_services_error_service__WEBPACK_IMPORTED_MODULE_20__.ErrorService), _angular_core__WEBPACK_IMPORTED_MODULE_16__["ɵɵdirectiveInject"](src_app_core_shared_services_campaign_service__WEBPACK_IMPORTED_MODULE_21__.CampaignService), _angular_core__WEBPACK_IMPORTED_MODULE_16__["ɵɵdirectiveInject"](src_app_core_shared_services_page_settings_service__WEBPACK_IMPORTED_MODULE_22__.PageSettingsService), _angular_core__WEBPACK_IMPORTED_MODULE_16__["ɵɵdirectiveInject"](src_app_core_shared_pipes_localDate_pipe__WEBPACK_IMPORTED_MODULE_23__.LocalDatePipe));
  }, this.ɵcmp = /*@__PURE__*/_angular_core__WEBPACK_IMPORTED_MODULE_16__["ɵɵdefineComponent"]({
    type: StatsTeamPage,
    selectors: [["app-stats"]],
    viewQuery: function StatsTeamPage_Query(rf, ctx) {
      if (rf & 1) {
        _angular_core__WEBPACK_IMPORTED_MODULE_16__["ɵɵviewQuery"](_c0, 5);
        _angular_core__WEBPACK_IMPORTED_MODULE_16__["ɵɵviewQuery"](_ionic_angular__WEBPACK_IMPORTED_MODULE_0__.IonInfiniteScroll, 5);
        _angular_core__WEBPACK_IMPORTED_MODULE_16__["ɵɵviewQuery"](_c1, 5);
      }
      if (rf & 2) {
        let _t;
        _angular_core__WEBPACK_IMPORTED_MODULE_16__["ɵɵqueryRefresh"](_t = _angular_core__WEBPACK_IMPORTED_MODULE_16__["ɵɵloadQuery"]()) && (ctx.barCanvas = _t.first);
        _angular_core__WEBPACK_IMPORTED_MODULE_16__["ɵɵqueryRefresh"](_t = _angular_core__WEBPACK_IMPORTED_MODULE_16__["ɵɵloadQuery"]()) && (ctx.infiniteScroll = _t.first);
        _angular_core__WEBPACK_IMPORTED_MODULE_16__["ɵɵqueryRefresh"](_t = _angular_core__WEBPACK_IMPORTED_MODULE_16__["ɵɵloadQuery"]()) && (ctx.refresher = _t.first);
      }
    },
    standalone: false,
    decls: 39,
    vars: 42,
    consts: [["barCanvas", ""], ["appHeader", ""], ["appContent", "", 3, "fullscreen"], [1, "header-margin"], [1, "header-sticky"], ["lines", "none", 1, "header-radius", 3, "color"], ["interface", "popover", 3, "ionChange", "interfaceOptions", "value"], [3, "value", 4, "ngFor", "ngForOf"], ["value", "GL"], [4, "ngIf"], [1, "white-line"], ["mode", "md", "scrollable", "", 1, "app-segment", 3, "ngModelChange", "ionChange", "ngModel"], ["checked", "", "mode", "ios", "class", "app-segment-button", 3, "value", "--radius", "--color", "--color-checked", 4, "ngFor", "ngForOf"], [1, "table-header"], ["size", "2"], ["fill", "clear", 3, "color", "click", 4, "ngIf"], ["size", "8"], [1, "ion-text-center", "period-value"], ["class", "ion-text-center total-value", 3, "color", 4, "ngIf"], [1, "chart-container"], ["id", "statsChart"], [3, "value"], ["lines", "none", 3, "color"], [3, "color"], ["checked", "", "mode", "ios", 1, "app-segment-button", 3, "value"], ["fill", "clear", 3, "click"], ["name", "chevron-back"], [1, "ion-text-center", "total-value"], ["name", "chevron-forward"]],
    template: function StatsTeamPage_Template(rf, ctx) {
      if (rf & 1) {
        const _r1 = _angular_core__WEBPACK_IMPORTED_MODULE_16__["ɵɵgetCurrentView"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_16__["ɵɵelement"](0, "ion-header", 1);
        _angular_core__WEBPACK_IMPORTED_MODULE_16__["ɵɵelementStart"](1, "ion-content", 2)(2, "div", 3)(3, "div", 4)(4, "ion-row")(5, "ion-col")(6, "ion-item", 5)(7, "ion-select", 6);
        _angular_core__WEBPACK_IMPORTED_MODULE_16__["ɵɵpipe"](8, "async");
        _angular_core__WEBPACK_IMPORTED_MODULE_16__["ɵɵlistener"]("ionChange", function StatsTeamPage_Template_ion_select_ionChange_7_listener($event) {
          _angular_core__WEBPACK_IMPORTED_MODULE_15__["ɵɵrestoreView"](_r1);
          return _angular_core__WEBPACK_IMPORTED_MODULE_15__["ɵɵresetView"](ctx.selectedMeanChangedSubject.next($event));
        });
        _angular_core__WEBPACK_IMPORTED_MODULE_16__["ɵɵtemplate"](9, StatsTeamPage_ion_select_option_9_Template, 3, 4, "ion-select-option", 7);
        _angular_core__WEBPACK_IMPORTED_MODULE_16__["ɵɵpipe"](10, "async");
        _angular_core__WEBPACK_IMPORTED_MODULE_16__["ɵɵelementStart"](11, "ion-select-option", 8);
        _angular_core__WEBPACK_IMPORTED_MODULE_16__["ɵɵtext"](12);
        _angular_core__WEBPACK_IMPORTED_MODULE_16__["ɵɵpipe"](13, "translate");
        _angular_core__WEBPACK_IMPORTED_MODULE_16__["ɵɵelementEnd"]()()()();
        _angular_core__WEBPACK_IMPORTED_MODULE_16__["ɵɵtemplate"](14, StatsTeamPage_ion_col_14_Template, 5, 7, "ion-col", 9);
        _angular_core__WEBPACK_IMPORTED_MODULE_16__["ɵɵpipe"](15, "async");
        _angular_core__WEBPACK_IMPORTED_MODULE_16__["ɵɵtemplate"](16, StatsTeamPage_ion_col_16_Template, 4, 4, "ion-col", 9);
        _angular_core__WEBPACK_IMPORTED_MODULE_16__["ɵɵpipe"](17, "async");
        _angular_core__WEBPACK_IMPORTED_MODULE_16__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_16__["ɵɵelementStart"](18, "ion-row")(19, "ion-col");
        _angular_core__WEBPACK_IMPORTED_MODULE_16__["ɵɵelement"](20, "div", 10);
        _angular_core__WEBPACK_IMPORTED_MODULE_16__["ɵɵelementEnd"]()()();
        _angular_core__WEBPACK_IMPORTED_MODULE_16__["ɵɵelementStart"](21, "ion-segment", 11);
        _angular_core__WEBPACK_IMPORTED_MODULE_16__["ɵɵtwoWayListener"]("ngModelChange", function StatsTeamPage_Template_ion_segment_ngModelChange_21_listener($event) {
          _angular_core__WEBPACK_IMPORTED_MODULE_15__["ɵɵrestoreView"](_r1);
          _angular_core__WEBPACK_IMPORTED_MODULE_16__["ɵɵtwoWayBindingSet"](ctx.selectedSegment, $event) || (ctx.selectedSegment = $event);
          return _angular_core__WEBPACK_IMPORTED_MODULE_15__["ɵɵresetView"]($event);
        });
        _angular_core__WEBPACK_IMPORTED_MODULE_16__["ɵɵlistener"]("ionChange", function StatsTeamPage_Template_ion_segment_ionChange_21_listener($event) {
          _angular_core__WEBPACK_IMPORTED_MODULE_15__["ɵɵrestoreView"](_r1);
          ctx.segmentChanged($event);
          return _angular_core__WEBPACK_IMPORTED_MODULE_15__["ɵɵresetView"](ctx.statPeriodChangedSubject.next(ctx.selectedSegment));
        });
        _angular_core__WEBPACK_IMPORTED_MODULE_16__["ɵɵtemplate"](22, StatsTeamPage_ion_segment_button_22_Template, 4, 10, "ion-segment-button", 12);
        _angular_core__WEBPACK_IMPORTED_MODULE_16__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_16__["ɵɵelementStart"](23, "ion-grid", 13)(24, "ion-row")(25, "ion-col", 14);
        _angular_core__WEBPACK_IMPORTED_MODULE_16__["ɵɵtemplate"](26, StatsTeamPage_ion_button_26_Template, 2, 2, "ion-button", 15);
        _angular_core__WEBPACK_IMPORTED_MODULE_16__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_16__["ɵɵelementStart"](27, "ion-col", 16)(28, "p", 17);
        _angular_core__WEBPACK_IMPORTED_MODULE_16__["ɵɵtext"](29);
        _angular_core__WEBPACK_IMPORTED_MODULE_16__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_16__["ɵɵtemplate"](30, StatsTeamPage_p_30_Template, 5, 11, "p", 18);
        _angular_core__WEBPACK_IMPORTED_MODULE_16__["ɵɵpipe"](31, "async");
        _angular_core__WEBPACK_IMPORTED_MODULE_16__["ɵɵtemplate"](32, StatsTeamPage_p_32_Template, 3, 6, "p", 18);
        _angular_core__WEBPACK_IMPORTED_MODULE_16__["ɵɵpipe"](33, "async");
        _angular_core__WEBPACK_IMPORTED_MODULE_16__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_16__["ɵɵelementStart"](34, "ion-col", 14);
        _angular_core__WEBPACK_IMPORTED_MODULE_16__["ɵɵtemplate"](35, StatsTeamPage_ion_button_35_Template, 2, 2, "ion-button", 15);
        _angular_core__WEBPACK_IMPORTED_MODULE_16__["ɵɵelementEnd"]()()();
        _angular_core__WEBPACK_IMPORTED_MODULE_16__["ɵɵelementStart"](36, "div", 19);
        _angular_core__WEBPACK_IMPORTED_MODULE_16__["ɵɵelement"](37, "canvas", 20, 0);
        _angular_core__WEBPACK_IMPORTED_MODULE_16__["ɵɵelementEnd"]()()();
      }
      if (rf & 2) {
        _angular_core__WEBPACK_IMPORTED_MODULE_16__["ɵɵadvance"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_16__["ɵɵproperty"]("fullscreen", true);
        _angular_core__WEBPACK_IMPORTED_MODULE_16__["ɵɵadvance"](2);
        _angular_core__WEBPACK_IMPORTED_MODULE_16__["ɵɵstyleProp"]("color", "var(--ion-color-" + ctx.campaignContainer.campaign.type + "-stat-contrast)")("background-color", "var(--ion-color-" + ctx.campaignContainer.campaign.type + ")");
        _angular_core__WEBPACK_IMPORTED_MODULE_16__["ɵɵadvance"](3);
        _angular_core__WEBPACK_IMPORTED_MODULE_16__["ɵɵproperty"]("color", ctx.campaignContainer.campaign.type);
        _angular_core__WEBPACK_IMPORTED_MODULE_16__["ɵɵadvance"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_16__["ɵɵproperty"]("interfaceOptions", _angular_core__WEBPACK_IMPORTED_MODULE_16__["ɵɵpureFunction0"](41, _c2))("value", _angular_core__WEBPACK_IMPORTED_MODULE_16__["ɵɵpipeBind1"](8, 27, ctx.selectedMean$));
        _angular_core__WEBPACK_IMPORTED_MODULE_16__["ɵɵadvance"](2);
        _angular_core__WEBPACK_IMPORTED_MODULE_16__["ɵɵproperty"]("ngForOf", _angular_core__WEBPACK_IMPORTED_MODULE_16__["ɵɵpipeBind1"](10, 29, ctx.means$));
        _angular_core__WEBPACK_IMPORTED_MODULE_16__["ɵɵadvance"](3);
        _angular_core__WEBPACK_IMPORTED_MODULE_16__["ɵɵtextInterpolate1"](" ", _angular_core__WEBPACK_IMPORTED_MODULE_16__["ɵɵpipeBind1"](13, 31, ctx.meanLabels["GL"]), " ");
        _angular_core__WEBPACK_IMPORTED_MODULE_16__["ɵɵadvance"](2);
        _angular_core__WEBPACK_IMPORTED_MODULE_16__["ɵɵproperty"]("ngIf", _angular_core__WEBPACK_IMPORTED_MODULE_16__["ɵɵpipeBind1"](15, 33, ctx.selectedMean$) !== "GL");
        _angular_core__WEBPACK_IMPORTED_MODULE_16__["ɵɵadvance"](2);
        _angular_core__WEBPACK_IMPORTED_MODULE_16__["ɵɵproperty"]("ngIf", _angular_core__WEBPACK_IMPORTED_MODULE_16__["ɵɵpipeBind1"](17, 35, ctx.selectedMean$) === "GL");
        _angular_core__WEBPACK_IMPORTED_MODULE_16__["ɵɵadvance"](4);
        _angular_core__WEBPACK_IMPORTED_MODULE_16__["ɵɵstyleProp"]("background-color", "var(--ion-color-" + ctx.campaignContainer.campaign.type + "-stat-contrast)");
        _angular_core__WEBPACK_IMPORTED_MODULE_16__["ɵɵadvance"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_16__["ɵɵstyleProp"]("--background", "var(--ion-color-" + ctx.campaignContainer.campaign.type + ")");
        _angular_core__WEBPACK_IMPORTED_MODULE_16__["ɵɵtwoWayProperty"]("ngModel", ctx.selectedSegment);
        _angular_core__WEBPACK_IMPORTED_MODULE_16__["ɵɵadvance"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_16__["ɵɵproperty"]("ngForOf", ctx.periods);
        _angular_core__WEBPACK_IMPORTED_MODULE_16__["ɵɵadvance"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_16__["ɵɵstyleProp"]("background-color", "var(--ion-color-" + ctx.campaignContainer.campaign.type + "-dark)");
        _angular_core__WEBPACK_IMPORTED_MODULE_16__["ɵɵadvance"](3);
        _angular_core__WEBPACK_IMPORTED_MODULE_16__["ɵɵproperty"]("ngIf", ctx.thereIsPast());
        _angular_core__WEBPACK_IMPORTED_MODULE_16__["ɵɵadvance"](2);
        _angular_core__WEBPACK_IMPORTED_MODULE_16__["ɵɵstyleProp"]("color", "var(--ion-color-" + ctx.campaignContainer.campaign.type + "-dark-contrast)");
        _angular_core__WEBPACK_IMPORTED_MODULE_16__["ɵɵadvance"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_16__["ɵɵtextInterpolate1"](" ", ctx.getSelectedPeriod(), " ");
        _angular_core__WEBPACK_IMPORTED_MODULE_16__["ɵɵadvance"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_16__["ɵɵproperty"]("ngIf", _angular_core__WEBPACK_IMPORTED_MODULE_16__["ɵɵpipeBind1"](31, 37, ctx.selectedMean$) !== "GL");
        _angular_core__WEBPACK_IMPORTED_MODULE_16__["ɵɵadvance"](2);
        _angular_core__WEBPACK_IMPORTED_MODULE_16__["ɵɵproperty"]("ngIf", _angular_core__WEBPACK_IMPORTED_MODULE_16__["ɵɵpipeBind1"](33, 39, ctx.selectedMean$) === "GL");
        _angular_core__WEBPACK_IMPORTED_MODULE_16__["ɵɵadvance"](3);
        _angular_core__WEBPACK_IMPORTED_MODULE_16__["ɵɵproperty"]("ngIf", ctx.thereIsFuture());
      }
    },
    dependencies: [_angular_common__WEBPACK_IMPORTED_MODULE_24__.NgForOf, _angular_common__WEBPACK_IMPORTED_MODULE_24__.NgIf, _angular_forms__WEBPACK_IMPORTED_MODULE_25__.NgControlStatus, _angular_forms__WEBPACK_IMPORTED_MODULE_25__.NgModel, _ionic_angular__WEBPACK_IMPORTED_MODULE_0__.IonButton, _ionic_angular__WEBPACK_IMPORTED_MODULE_0__.IonCol, _ionic_angular__WEBPACK_IMPORTED_MODULE_0__.IonContent, _ionic_angular__WEBPACK_IMPORTED_MODULE_0__.IonGrid, _ionic_angular__WEBPACK_IMPORTED_MODULE_0__.IonHeader, _ionic_angular__WEBPACK_IMPORTED_MODULE_0__.IonIcon, _ionic_angular__WEBPACK_IMPORTED_MODULE_0__.IonItem, _ionic_angular__WEBPACK_IMPORTED_MODULE_0__.IonLabel, _ionic_angular__WEBPACK_IMPORTED_MODULE_0__.IonRow, _ionic_angular__WEBPACK_IMPORTED_MODULE_0__.IonSegment, _ionic_angular__WEBPACK_IMPORTED_MODULE_0__.IonSegmentButton, _ionic_angular__WEBPACK_IMPORTED_MODULE_0__.IonSelect, _ionic_angular__WEBPACK_IMPORTED_MODULE_0__.IonSelectOption, _ionic_angular__WEBPACK_IMPORTED_MODULE_0__.SelectValueAccessor, _core_shared_layout_header_header_directive__WEBPACK_IMPORTED_MODULE_26__.HeaderDirective, _core_shared_layout_content_content_directive__WEBPACK_IMPORTED_MODULE_27__.ContentDirective, _angular_common__WEBPACK_IMPORTED_MODULE_24__.AsyncPipe, _ngx_translate_core__WEBPACK_IMPORTED_MODULE_28__.TranslatePipe, _core_shared_pipes_localNumber_pipe__WEBPACK_IMPORTED_MODULE_29__.LocalNumberPipe],
    styles: [".header-margin[_ngcontent-%COMP%] {\n  margin: 8px;\n}\n.header-margin[_ngcontent-%COMP%]   ion-select[_ngcontent-%COMP%] {\n  font-weight: 500;\n  font-size: 17px;\n}\n.header-margin[_ngcontent-%COMP%]   .header-radius[_ngcontent-%COMP%] {\n  border-radius: 8px 8px 0 0;\n}\n.header-margin[_ngcontent-%COMP%]   .table-header[_ngcontent-%COMP%] {\n  font-size: 22px;\n}\n.header-margin[_ngcontent-%COMP%]   .period-value[_ngcontent-%COMP%] {\n  margin: 4px;\n  font-weight: 300;\n  font-size: 17px;\n  line-height: 20px;\n}\n.header-margin[_ngcontent-%COMP%]   .total-value[_ngcontent-%COMP%] {\n  margin: 4px;\n  font-weight: 500;\n  font-size: 14px;\n}\n.header-margin[_ngcontent-%COMP%]   .white-line[_ngcontent-%COMP%] {\n  height: 2px;\n}\n\n.chart-container[_ngcontent-%COMP%] {\n  position: relative;\n  height: calc(100vh - 400px);\n  width: 100%;\n}\n/*# sourceMappingURL=data:application/json;charset=utf-8;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbIndlYnBhY2s6Ly8uL3NyYy9hcHAvcGFnZXMvaG9tZS9jYW1wYWlnbi1kZXRhaWxzL3N0YXRzLXRlYW0vc3RhdHMucGFnZS5zY3NzIl0sIm5hbWVzIjpbXSwibWFwcGluZ3MiOiJBQUFBO0VBQ0UsV0FBQTtBQUNGO0FBQUU7RUFDRSxnQkFBQTtFQUNBLGVBQUE7QUFFSjtBQUFFO0VBQ0UsMEJBQUE7QUFFSjtBQUFFO0VBQ0UsZUFBQTtBQUVKO0FBQUU7RUFDRSxXQUFBO0VBQ0EsZ0JBQUE7RUFDQSxlQUFBO0VBQ0EsaUJBQUE7QUFFSjtBQUFFO0VBQ0UsV0FBQTtFQUNBLGdCQUFBO0VBQ0EsZUFBQTtBQUVKO0FBQUU7RUFDRSxXQUFBO0FBRUo7O0FBQ0E7RUFDRSxrQkFBQTtFQUNBLDJCQUFBO0VBQ0EsV0FBQTtBQUVGIiwic291cmNlc0NvbnRlbnQiOlsiLmhlYWRlci1tYXJnaW4ge1xuICBtYXJnaW46IDhweDtcbiAgaW9uLXNlbGVjdCB7XG4gICAgZm9udC13ZWlnaHQ6IDUwMDtcbiAgICBmb250LXNpemU6IDE3cHg7XG4gIH1cbiAgLmhlYWRlci1yYWRpdXMge1xuICAgIGJvcmRlci1yYWRpdXM6IDhweCA4cHggMCAwO1xuICB9XG4gIC50YWJsZS1oZWFkZXIge1xuICAgIGZvbnQtc2l6ZTogMjJweDtcbiAgfVxuICAucGVyaW9kLXZhbHVlIHtcbiAgICBtYXJnaW46IDRweDtcbiAgICBmb250LXdlaWdodDogMzAwO1xuICAgIGZvbnQtc2l6ZTogMTdweDtcbiAgICBsaW5lLWhlaWdodDogMjBweDtcbiAgfVxuICAudG90YWwtdmFsdWUge1xuICAgIG1hcmdpbjogNHB4O1xuICAgIGZvbnQtd2VpZ2h0OiA1MDA7XG4gICAgZm9udC1zaXplOiAxNHB4O1xuICB9XG4gIC53aGl0ZS1saW5lIHtcbiAgICBoZWlnaHQ6IDJweDtcbiAgfVxufVxuLmNoYXJ0LWNvbnRhaW5lciB7XG4gIHBvc2l0aW9uOiByZWxhdGl2ZTtcbiAgaGVpZ2h0OiBjYWxjKDEwMHZoIC0gNDAwcHgpO1xuICB3aWR0aDogMTAwJTtcbn1cbiJdLCJzb3VyY2VSb290IjoiIn0= */"]
  }));
}
_staticBlock();
const ALL_MEANS = 'ALL_MEANS';
const GL = 'GL';

/***/ }),

/***/ 87520:
/*!*****************************************************************************!*\
  !*** ./src/app/pages/home/campaign-details/stats-team/stats-team.module.ts ***!
  \*****************************************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   StatsTeamPageModule: () => (/* binding */ StatsTeamPageModule)
/* harmony export */ });
/* harmony import */ var _stats_team_routing_module__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./stats-team-routing.module */ 17641);
/* harmony import */ var _stats_team_page__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ./stats-team.page */ 54811);
/* harmony import */ var src_app_core_shared_shared_module__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! src/app/core/shared/shared.module */ 62657);
/* harmony import */ var src_app_core_shared_pipes_localDate_pipe__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! src/app/core/shared/pipes/localDate.pipe */ 86451);
/* harmony import */ var _ionic_angular__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! @ionic/angular */ 21507);
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! @angular/core */ 34205);
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! @angular/core */ 12481);
var _staticBlock;






class StatsTeamPageModule {
  static #_ = _staticBlock = () => (this.ɵfac = function StatsTeamPageModule_Factory(__ngFactoryType__) {
    return new (__ngFactoryType__ || StatsTeamPageModule)();
  }, this.ɵmod = /*@__PURE__*/_angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵdefineNgModule"]({
    type: StatsTeamPageModule
  }), this.ɵinj = /*@__PURE__*/_angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵdefineInjector"]({
    providers: [src_app_core_shared_pipes_localDate_pipe__WEBPACK_IMPORTED_MODULE_3__.LocalDatePipe],
    imports: [src_app_core_shared_shared_module__WEBPACK_IMPORTED_MODULE_2__.PlayGoSharedModule, _stats_team_routing_module__WEBPACK_IMPORTED_MODULE_0__.StatsTeamPageRoutingModule, _ionic_angular__WEBPACK_IMPORTED_MODULE_4__.IonicModule]
  }));
}
_staticBlock();
(function () {
  (typeof ngJitMode === "undefined" || ngJitMode) && _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵsetNgModuleScope"](StatsTeamPageModule, {
    declarations: [_stats_team_page__WEBPACK_IMPORTED_MODULE_1__.StatsTeamPage],
    imports: [src_app_core_shared_shared_module__WEBPACK_IMPORTED_MODULE_2__.PlayGoSharedModule, _stats_team_routing_module__WEBPACK_IMPORTED_MODULE_0__.StatsTeamPageRoutingModule, _ionic_angular__WEBPACK_IMPORTED_MODULE_4__.IonicModule]
  });
})();

/***/ })

}]);
//# sourceMappingURL=src_app_pages_home_campaign-details_stats-team_stats-team_module_ts.js.map